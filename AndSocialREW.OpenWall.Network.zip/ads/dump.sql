DROP TABLE IF EXISTS %%TBL-PREFIX%%ads_banner;

CREATE TABLE `%%TBL-PREFIX%%ads_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%ads_banner(`id`,`label`,`code`) VALUES 
( '1','Ads','<script type=\"text/javascript\"><!--\r\ngoogle_ad_client = \"ca-pub-8332818377522866\";\r\n/* Advertisement */\r\ngoogle_ad_slot = \"6001989633\";\r\ngoogle_ad_width = 728;\r\ngoogle_ad_height = 90;\r\n//-->\r\n</script>\r\n<script type=\"text/javascript\"\r\nsrc=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\">\r\n</script>' );





DROP TABLE IF EXISTS %%TBL-PREFIX%%ads_banner_location;

CREATE TABLE `%%TBL-PREFIX%%ads_banner_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bannerId` int(11) NOT NULL,
  `location` char(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bannerId` (`bannerId`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%ads_banner_position;

CREATE TABLE `%%TBL-PREFIX%%ads_banner_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bannerId` int(11) NOT NULL,
  `position` enum('top','sidebar','bottom') NOT NULL,
  `pluginKey` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bannerId` (`bannerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




