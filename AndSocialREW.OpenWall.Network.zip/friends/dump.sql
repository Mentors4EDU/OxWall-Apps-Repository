DROP TABLE IF EXISTS %%TBL-PREFIX%%friends_friendship;

CREATE TABLE `%%TBL-PREFIX%%friends_friendship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `friendId` int(11) NOT NULL,
  `status` enum('active','pending','ignored') NOT NULL DEFAULT 'pending',
  `timeStamp` int(11) NOT NULL,
  `viewed` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `notificationSent` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId_friendId` (`userId`,`friendId`),
  KEY `friendId` (`friendId`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%friends_friendship(`id`,`userId`,`friendId`,`status`,`timeStamp`,`viewed`,`active`,`notificationSent`) VALUES 
( '1','1','11','pending','0','0','1','1' ),
( '2','1','139','pending','1369498004','0','1','0' );





