DROP TABLE IF EXISTS %%TBL-PREFIX%%birthdays_privacy;

CREATE TABLE `%%TBL-PREFIX%%birthdays_privacy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `privacy` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




