DROP TABLE IF EXISTS %%TBL-PREFIX%%mailbox_attachment;

CREATE TABLE `%%TBL-PREFIX%%mailbox_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `messageId` int(11) NOT NULL,
  `hash` varchar(13) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `fileSize` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `messageId` (`messageId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%mailbox_conversation;

CREATE TABLE `%%TBL-PREFIX%%mailbox_conversation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `initiatorId` int(10) NOT NULL DEFAULT '0',
  `interlocutorId` int(10) NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `read` tinyint(3) NOT NULL DEFAULT '1' COMMENT 'bitmap, values: 0 - none, 1 - read by initiator, 2 - read by interlocutor, 3 - read all',
  `deleted` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'bitmap, values: 0 - none, 1 - deleted by initiator, 2 - deleted by interlocutor.',
  `createStamp` int(10) DEFAULT '0',
  `viewed` int(11) NOT NULL DEFAULT '0',
  `notificationSent` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `initiatorId` (`initiatorId`),
  KEY `interlocutorId` (`interlocutorId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%mailbox_file_upload;

CREATE TABLE `%%TBL-PREFIX%%mailbox_file_upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entityId` varchar(32) NOT NULL,
  `filePath` varchar(2048) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `fileSize` int(10) NOT NULL DEFAULT '0',
  `timestamp` int(10) NOT NULL DEFAULT '0',
  `userId` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`,`userId`),
  KEY `entityId` (`entityId`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%mailbox_last_message;

CREATE TABLE `%%TBL-PREFIX%%mailbox_last_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `conversationId` int(10) NOT NULL DEFAULT '0',
  `initiatorMessageId` int(10) NOT NULL DEFAULT '0',
  `interlocutorMessageId` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `conversationId` (`conversationId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%mailbox_message;

CREATE TABLE `%%TBL-PREFIX%%mailbox_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `conversationId` int(10) NOT NULL DEFAULT '0',
  `timeStamp` bigint(10) NOT NULL DEFAULT '0',
  `senderId` int(10) NOT NULL DEFAULT '0',
  `recipientId` int(10) NOT NULL DEFAULT '0',
  `text` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `senderId` (`senderId`),
  KEY `recipientId` (`recipientId`),
  KEY `conversationId` (`conversationId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




