DROP TABLE IF EXISTS %%TBL-PREFIX%%photo_album;

CREATE TABLE `%%TBL-PREFIX%%photo_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `createDatetime` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%photo_album(`id`,`userId`,`name`,`createDatetime`) VALUES 
( '1','1','Amazing','1330232972' );





DROP TABLE IF EXISTS %%TBL-PREFIX%%photo_featured;

CREATE TABLE `%%TBL-PREFIX%%photo_featured` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photoId` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%photo_temporary;

CREATE TABLE `%%TBL-PREFIX%%photo_temporary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `addDatetime` int(11) NOT NULL,
  `hasFullsize` tinyint(1) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%photo;

CREATE TABLE `%%TBL-PREFIX%%photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `albumId` int(11) NOT NULL,
  `description` text,
  `addDatetime` int(10) DEFAULT NULL,
  `status` enum('approval','approved','blocked') NOT NULL DEFAULT 'approved',
  `hasFullsize` tinyint(1) NOT NULL DEFAULT '1',
  `privacy` varchar(50) NOT NULL DEFAULT 'everybody',
  PRIMARY KEY (`id`),
  KEY `albumId` (`albumId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%photo(`id`,`albumId`,`description`,`addDatetime`,`status`,`hasFullsize`,`privacy`) VALUES 
( '1','1','','1330232972','approved','0','everybody' ),
( '2','1','','1330232972','approved','0','everybody' ),
( '3','1','','1330232973','approved','0','everybody' ),
( '4','1','','1330232974','approved','0','everybody' ),
( '5','1','Pictures of shroud of turin digitally enhanced','1330232975','approved','0','everybody' ),
( '6','1','Pictures of shroud of turin digitally enhanced','1330232976','approved','0','everybody' );





