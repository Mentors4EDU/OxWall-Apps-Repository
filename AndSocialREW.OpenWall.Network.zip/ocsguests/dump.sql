DROP TABLE IF EXISTS %%TBL-PREFIX%%ocsguests_guest;

CREATE TABLE `%%TBL-PREFIX%%ocsguests_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `guestId` int(11) NOT NULL,
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `visitTimestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId` (`userId`,`guestId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%ocsguests_guest(`id`,`userId`,`guestId`,`viewed`,`visitTimestamp`) VALUES 
( '1','139','1','0','1369498005' );





