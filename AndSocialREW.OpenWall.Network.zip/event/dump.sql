DROP TABLE IF EXISTS %%TBL-PREFIX%%event_invite;

CREATE TABLE `%%TBL-PREFIX%%event_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `inviterId` int(11) NOT NULL,
  `timeStamp` int(11) NOT NULL,
  `displayInvitation` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inviteUnique` (`userId`,`inviterId`,`eventId`),
  KEY `userId` (`userId`),
  KEY `inviterId` (`inviterId`),
  KEY `eventId` (`eventId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%event_item;

CREATE TABLE `%%TBL-PREFIX%%event_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `location` text NOT NULL,
  `createTimeStamp` int(11) NOT NULL,
  `startTimeStamp` int(11) NOT NULL,
  `endTimeStamp` int(11) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `whoCanView` tinyint(4) NOT NULL,
  `whoCanInvite` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `image` varchar(32) DEFAULT NULL,
  `endDateFlag` tinyint(1) NOT NULL DEFAULT '1',
  `startTimeDisabled` tinyint(1) NOT NULL DEFAULT '0',
  `endTimeDisabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%event_user;

CREATE TABLE `%%TBL-PREFIX%%event_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `timeStamp` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `eventUser` (`eventId`,`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




