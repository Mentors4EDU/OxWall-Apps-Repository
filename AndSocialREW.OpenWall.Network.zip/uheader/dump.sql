DROP TABLE IF EXISTS %%TBL-PREFIX%%uheader_cover;

CREATE TABLE `%%TBL-PREFIX%%uheader_cover` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `settings` text NOT NULL,
  `timeStamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId_2` (`userId`,`status`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




