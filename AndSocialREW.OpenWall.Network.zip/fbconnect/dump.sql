DROP TABLE IF EXISTS %%TBL-PREFIX%%fbconnect_field;

CREATE TABLE `%%TBL-PREFIX%%fbconnect_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(50) NOT NULL,
  `fbField` varchar(100) NOT NULL,
  `converter` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%fbconnect_field(`id`,`question`,`fbField`,`converter`) VALUES 
( '1','realname','first_name','FBCONNECT_FC_TextFieldConverter' ),
( '2','username','name','FBCONNECT_FC_Username' ),
( '3','email','email','FBCONNECT_FC_TextFieldConverter' ),
( '4','picture_small','pic_square','FBCONNECT_FC_Picture' ),
( '5','picture_big','pic_big','FBCONNECT_FC_Picture' ),
( '6','birthdate','birthday_date','FBCONNECT_FC_Date' );





