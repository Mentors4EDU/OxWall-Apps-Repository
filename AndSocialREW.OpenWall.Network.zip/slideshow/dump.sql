DROP TABLE IF EXISTS %%TBL-PREFIX%%slideshow_slide;

CREATE TABLE `%%TBL-PREFIX%%slideshow_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `widgetId` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT '0',
  `width` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0',
  `ext` varchar(5) DEFAULT NULL,
  `addStamp` int(11) DEFAULT '0',
  `status` enum('active','delete') DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `order` (`order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




