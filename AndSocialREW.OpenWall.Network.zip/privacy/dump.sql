DROP TABLE IF EXISTS %%TBL-PREFIX%%privacy_action_data;

CREATE TABLE `%%TBL-PREFIX%%privacy_action_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL,
  `pluginKey` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `value` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId` (`userId`,`key`),
  KEY `key` (`key`),
  KEY `pluginKey` (`pluginKey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%privacy_cron;

CREATE TABLE `%%TBL-PREFIX%%privacy_cron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `action` varchar(32) NOT NULL,
  `value` varchar(50) NOT NULL,
  `inProcess` tinyint(1) NOT NULL DEFAULT '0',
  `timeStamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId` (`userId`,`action`,`inProcess`),
  KEY `timeStamp` (`timeStamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




