DROP TABLE IF EXISTS %%TBL-PREFIX%%blogs_post;

CREATE TABLE `%%TBL-PREFIX%%blogs_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authorId` int(11) NOT NULL,
  `title` varchar(512) NOT NULL DEFAULT '',
  `post` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `isDraft` tinyint(1) NOT NULL,
  `privacy` varchar(50) NOT NULL DEFAULT 'everybody',
  PRIMARY KEY (`id`),
  KEY `authorId` (`authorId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




