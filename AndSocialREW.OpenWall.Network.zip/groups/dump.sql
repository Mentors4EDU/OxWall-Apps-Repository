DROP TABLE IF EXISTS %%TBL-PREFIX%%groups_group;

CREATE TABLE `%%TBL-PREFIX%%groups_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `imageHash` varchar(32) DEFAULT NULL,
  `timeStamp` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `whoCanView` varchar(100) NOT NULL DEFAULT 'anyone',
  `whoCanInvite` varchar(100) NOT NULL DEFAULT 'participant',
  PRIMARY KEY (`id`),
  KEY `timeStamp` (`timeStamp`),
  KEY `userId` (`userId`),
  KEY `whoCanView` (`whoCanView`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%groups_group_user;

CREATE TABLE `%%TBL-PREFIX%%groups_group_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `timeStamp` int(11) NOT NULL,
  `privacy` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupId` (`groupId`,`userId`),
  KEY `timeStamp` (`timeStamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%groups_invite;

CREATE TABLE `%%TBL-PREFIX%%groups_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `inviterId` int(11) NOT NULL,
  `timeStamp` int(11) NOT NULL,
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `inviteUniq` (`groupId`,`userId`,`inviterId`),
  KEY `timeStamp` (`timeStamp`),
  KEY `userId` (`userId`),
  KEY `groupId` (`groupId`),
  KEY `viewed` (`viewed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




