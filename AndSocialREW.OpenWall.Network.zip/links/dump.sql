DROP TABLE IF EXISTS %%TBL-PREFIX%%links_link;

CREATE TABLE `%%TBL-PREFIX%%links_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `url` mediumtext NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `timestamp` int(11) NOT NULL,
  `privacy` varchar(50) NOT NULL DEFAULT 'everybody',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




