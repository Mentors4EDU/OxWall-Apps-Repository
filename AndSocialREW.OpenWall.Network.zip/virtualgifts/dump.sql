DROP TABLE IF EXISTS %%TBL-PREFIX%%virtualgifts_category;

CREATE TABLE `%%TBL-PREFIX%%virtualgifts_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS %%TBL-PREFIX%%virtualgifts_template;

CREATE TABLE `%%TBL-PREFIX%%virtualgifts_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryId` int(11) DEFAULT NULL,
  `extension` varchar(10) NOT NULL,
  `uploadTimestamp` int(11) NOT NULL DEFAULT '0',
  `price` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categoryId` (`categoryId`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO %%TBL-PREFIX%%virtualgifts_template(`id`,`categoryId`,`extension`,`uploadTimestamp`,`price`) VALUES 
( '1',NULL,'jpg','1319195707','0' ),
( '2',NULL,'jpg','1319195707','0' ),
( '3',NULL,'jpg','1319195707','0' ),
( '4',NULL,'jpg','1319195707','0' ),
( '5',NULL,'jpg','1319195707','0' ),
( '6',NULL,'jpg','1319195707','0' ),
( '7',NULL,'jpg','1319195707','0' ),
( '8',NULL,'jpg','1319195707','0' ),
( '9',NULL,'jpg','1319195707','0' ),
( '10',NULL,'jpg','1319195707','0' ),
( '11',NULL,'jpg','1319195707','0' ),
( '12',NULL,'jpg','1319195707','0' ),
( '13',NULL,'jpg','1319195707','0' ),
( '14',NULL,'jpg','1319195707','0' ),
( '15',NULL,'jpg','1319195707','0' ),
( '16',NULL,'jpg','1319195707','0' ),
( '17',NULL,'jpg','1319195707','0' );





DROP TABLE IF EXISTS %%TBL-PREFIX%%virtualgifts_user_gift;

CREATE TABLE `%%TBL-PREFIX%%virtualgifts_user_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateId` int(11) NOT NULL,
  `senderId` int(11) NOT NULL,
  `recipientId` int(11) NOT NULL,
  `sendTimestamp` int(11) NOT NULL,
  `message` text,
  `private` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `senderId` (`senderId`),
  KEY `recipientId` (`recipientId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




