Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.reverbnation.com\/\" rel=\"nofollow\"\u003EReverbNation\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/gpI2lB2n",
      "expanded_url" : "http:\/\/soc.li\/uHEMPxj",
      "display_url" : "soc.li\/uHEMPxj"
    } ]
  },
  "geo" : { },
  "id_str" : "161143256711831552",
  "text" : "We're number 27 on the ReverbNation Blues charts\nhttp:\/\/t.co\/gpI2lB2n",
  "id" : 161143256711831552,
  "created_at" : "2012-01-22 17:48:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.reverbnation.com\/\" rel=\"nofollow\"\u003EReverbNation\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/gpI2lB2n",
      "expanded_url" : "http:\/\/soc.li\/uHEMPxj",
      "display_url" : "soc.li\/uHEMPxj"
    } ]
  },
  "geo" : { },
  "id_str" : "160413814356062208",
  "text" : "We're number 33 on the ReverbNation Blues charts for http:\/\/t.co\/gpI2lB2n",
  "id" : 160413814356062208,
  "created_at" : "2012-01-20 17:30:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.reverbnation.com\/\" rel=\"nofollow\"\u003EReverbNation\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/gpI2lB2n",
      "expanded_url" : "http:\/\/soc.li\/uHEMPxj",
      "display_url" : "soc.li\/uHEMPxj"
    } ]
  },
  "geo" : { },
  "id_str" : "159422594511159296",
  "text" : "We're number 42 on the ReverbNation Blues charts \nWE MADE IT TO THE TOP 50 SONGS\nhttp:\/\/t.co\/gpI2lB2n",
  "id" : 159422594511159296,
  "created_at" : "2012-01-17 23:51:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158622468406390785",
  "geo" : { },
  "id_str" : "158623279425392640",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 do u have a facebook?",
  "id" : 158623279425392640,
  "in_reply_to_status_id" : 158622468406390785,
  "created_at" : "2012-01-15 18:55:11 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]