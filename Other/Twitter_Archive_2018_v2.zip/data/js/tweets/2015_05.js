Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605086964325351424",
  "text" : "God bless you Marina. Always try your best following the one who saves. @Mariiana0_o",
  "id" : 605086964325351424,
  "created_at" : "2015-05-31 19:02:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603677083248754688",
  "geo" : { },
  "id_str" : "603712270007443457",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Just shows what times we are heading towards, sadly",
  "id" : 603712270007443457,
  "in_reply_to_status_id" : 603677083248754688,
  "created_at" : "2015-05-27 23:59:56 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Cenk Uygur",
      "screen_name" : "cenkuygur",
      "indices" : [ 10, 20 ],
      "id_str" : "429227921",
      "id" : 429227921
    }, {
      "name" : "Ana Kasparian",
      "screen_name" : "AnaKasparian",
      "indices" : [ 21, 34 ],
      "id_str" : "23865382",
      "id" : 23865382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603687611522273280",
  "geo" : { },
  "id_str" : "603712162725519361",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice @cenkuygur @AnaKasparian Who cares about them? TheYoungTurk's is a bias, liberal channel with a bunch of mindless propaganda.",
  "id" : 603712162725519361,
  "in_reply_to_status_id" : 603687611522273280,
  "created_at" : "2015-05-27 23:59:30 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603711655441211392",
  "text" : "RT @slidenerdtech: @gamer456148 make it 4 :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "600739424947699713",
    "geo" : { },
    "id_str" : "603373442243563520",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 make it 4 :)",
    "id" : 603373442243563520,
    "in_reply_to_status_id" : 600739424947699713,
    "created_at" : "2015-05-27 01:33:33 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918078120674058240\/-qudg3y2_normal.jpg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 603711655441211392,
  "created_at" : "2015-05-27 23:57:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Family",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603000683340566528",
  "text" : "Had a fun memorial day party #Family \uD83D\uDD53",
  "id" : 603000683340566528,
  "created_at" : "2015-05-26 00:52:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/602222098434625536\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/5XRAf95auB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFuFzsLWMAA1PFl.jpg",
      "id_str" : "602222098262667264",
      "id" : 602222098262667264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFuFzsLWMAA1PFl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/5XRAf95auB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602222098434625536",
  "text" : "Got these three items today :) http:\/\/t.co\/5XRAf95auB",
  "id" : 602222098434625536,
  "created_at" : "2015-05-23 21:18:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601809801211879424",
  "text" : "RT @CouponTrump: @gamer456148 You're welcome - hope for (mutual) success!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "600738530277527552",
    "geo" : { },
    "id_str" : "600773630096777216",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 You're welcome - hope for (mutual) success!",
    "id" : 600773630096777216,
    "in_reply_to_status_id" : 600738530277527552,
    "created_at" : "2015-05-19 21:22:49 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 601809801211879424,
  "created_at" : "2015-05-22 18:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CodeBabes",
      "screen_name" : "CodeBabes",
      "indices" : [ 0, 10 ],
      "id_str" : "85252025",
      "id" : 85252025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600740470789050368",
  "in_reply_to_user_id" : 85252025,
  "text" : "@CodeBabes Well you guys turned coding, a respectable practice, and made it degrading. Congrats..",
  "id" : 600740470789050368,
  "created_at" : "2015-05-19 19:11:04 +0000",
  "in_reply_to_screen_name" : "CodeBabes",
  "in_reply_to_user_id_str" : "85252025",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600739424947699713",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech You guys just reached 3k students on Udemy, I need to step up my game!!!",
  "id" : 600739424947699713,
  "created_at" : "2015-05-19 19:06:54 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 0, 12 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600368032284856320",
  "geo" : { },
  "id_str" : "600738530277527552",
  "in_reply_to_user_id" : 2370179022,
  "text" : "@CouponTrump Thanks for the shoutouts!!!",
  "id" : 600738530277527552,
  "in_reply_to_status_id" : 600368032284856320,
  "created_at" : "2015-05-19 19:03:21 +0000",
  "in_reply_to_screen_name" : "CouponTrump",
  "in_reply_to_user_id_str" : "2370179022",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 0, 8 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "toddstarnes",
      "screen_name" : "toddstarnes",
      "indices" : [ 9, 21 ],
      "id_str" : "15515169",
      "id" : 15515169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599686693503913984",
  "geo" : { },
  "id_str" : "599718400265355264",
  "in_reply_to_user_id" : 1367531,
  "text" : "@FoxNews @toddstarnes What a fallen world!!!",
  "id" : 599718400265355264,
  "in_reply_to_status_id" : 599686693503913984,
  "created_at" : "2015-05-16 23:29:43 +0000",
  "in_reply_to_screen_name" : "FoxNews",
  "in_reply_to_user_id_str" : "1367531",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 0, 15 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595186919539089408",
  "geo" : { },
  "id_str" : "599718019292483584",
  "in_reply_to_user_id" : 2687742392,
  "text" : "@VigilantChrist Very inspiring, but you couldn't have done it without the big man in the heavens!!!",
  "id" : 599718019292483584,
  "in_reply_to_status_id" : 595186919539089408,
  "created_at" : "2015-05-16 23:28:12 +0000",
  "in_reply_to_screen_name" : "VigilantChrist",
  "in_reply_to_user_id_str" : "2687742392",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 0, 15 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Disturbing",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596701871399641088",
  "geo" : { },
  "id_str" : "599717896307146752",
  "in_reply_to_user_id" : 2687742392,
  "text" : "@VigilantChrist Wait this is a real thing? Who would think of this? Why? #Disturbing",
  "id" : 599717896307146752,
  "in_reply_to_status_id" : 596701871399641088,
  "created_at" : "2015-05-16 23:27:43 +0000",
  "in_reply_to_screen_name" : "VigilantChrist",
  "in_reply_to_user_id_str" : "2687742392",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599634587220725761",
  "geo" : { },
  "id_str" : "599717680036192257",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Are you planning on publishing a Udemy or Skillshare course in the near future? Either way can't wait for the new book!!!",
  "id" : 599717680036192257,
  "in_reply_to_status_id" : 599634587220725761,
  "created_at" : "2015-05-16 23:26:51 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALLLIVESMATTERBUTYOUNEEDTOBECIVILIZED",
      "indices" : [ 28, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599646428743340033",
  "geo" : { },
  "id_str" : "599717491128991744",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice I am starting the #ALLLIVESMATTERBUTYOUNEEDTOBECIVILIZED movement, wanna join?",
  "id" : 599717491128991744,
  "in_reply_to_status_id" : 599646428743340033,
  "created_at" : "2015-05-16 23:26:06 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Insanity",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599716513541558273",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze is living out every boy's childhood dreams. A superhero, a mad scientist, a crazed inventor, and explosives expert!!! #Insanity",
  "id" : 599716513541558273,
  "created_at" : "2015-05-16 23:22:13 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599184639459196928",
  "geo" : { },
  "id_str" : "599715990876889088",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Well it is Mental, I will give you that!!!",
  "id" : 599715990876889088,
  "in_reply_to_status_id" : 599184639459196928,
  "created_at" : "2015-05-16 23:20:09 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/599023921187393537\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/VByryqtyPr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFApFRNWMAE7_Ve.jpg",
      "id_str" : "599023920935743489",
      "id" : 599023920935743489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFApFRNWMAE7_Ve.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1279
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1279
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/VByryqtyPr"
    } ],
    "hashtags" : [ {
      "text" : "fake",
      "indices" : [ 3, 8 ]
    }, {
      "text" : "studio",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599023921187393537",
  "text" : "My #fake #studio is almost done \uD83D\uDE0A http:\/\/t.co\/VByryqtyPr",
  "id" : 599023921187393537,
  "created_at" : "2015-05-15 01:30:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 118, 127 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598316493038694400",
  "text" : "These people should be banned from voting. No wonder most Californians are liberals. Just watched \"Man on the Street\" @MarkDice",
  "id" : 598316493038694400,
  "created_at" : "2015-05-13 02:39:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dimitri",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "Full",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598273320652443648",
  "text" : "ATE ALOT TODAY #Dimitri's #Full",
  "id" : 598273320652443648,
  "created_at" : "2015-05-12 23:47:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sleepy",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598213343963287552",
  "text" : "Some day #sleepy",
  "id" : 598213343963287552,
  "created_at" : "2015-05-12 19:49:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597468650677764096",
  "text" : "Some day, college tomorrow, oh \u26F3",
  "id" : 597468650677764096,
  "created_at" : "2015-05-10 18:30:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596382614820356096",
  "geo" : { },
  "id_str" : "596389615436746752",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze @YouTube Oh my goodness!!!",
  "id" : 596389615436746752,
  "in_reply_to_status_id" : 596382614820356096,
  "created_at" : "2015-05-07 19:02:19 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/595659586067111936\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/u8zNarPwRz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEQ1PMwWMAEBtt5.jpg",
      "id_str" : "595659585958064129",
      "id" : 595659585958064129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEQ1PMwWMAEBtt5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/u8zNarPwRz"
    } ],
    "hashtags" : [ {
      "text" : "Ticket",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595659586067111936",
  "text" : "Had a tough day #Ticket\/Warning but I did go to firehouse subs and my aunt's house :) http:\/\/t.co\/u8zNarPwRz",
  "id" : 595659586067111936,
  "created_at" : "2015-05-05 18:41:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EDUREPO",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "Mentors4EDU",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/vyAcN8yqsk",
      "expanded_url" : "http:\/\/hfht.co\/XapVZ",
      "display_url" : "hfht.co\/XapVZ"
    } ]
  },
  "geo" : { },
  "id_str" : "595619077260980225",
  "text" : "Want online courses for $9, check out this Hackathon winning company!!! #EDUREPO #Mentors4EDU http:\/\/t.co\/vyAcN8yqsk",
  "id" : 595619077260980225,
  "created_at" : "2015-05-05 16:00:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tired",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595273378367320065",
  "text" : "Had a tough day, me too, but it could be worse, and I am very blessed. #Tired",
  "id" : 595273378367320065,
  "created_at" : "2015-05-04 17:06:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595273114079993857",
  "text" : "If I was the judge in the James Holmes case, I would give him the death penalty. Why pay thousands in tax payer money to keep him alive?",
  "id" : 595273114079993857,
  "created_at" : "2015-05-04 17:05:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Reality",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595242028449058816",
  "geo" : { },
  "id_str" : "595261479609327616",
  "in_reply_to_user_id" : 587770470,
  "text" : "@LlVELaughLuv Comes with free floods, hurricanes, and rain storms #Reality",
  "id" : 595261479609327616,
  "in_reply_to_status_id" : 595242028449058816,
  "created_at" : "2015-05-04 16:19:30 +0000",
  "in_reply_to_screen_name" : "TruthOrFunnies",
  "in_reply_to_user_id_str" : "587770470",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 0, 9 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/JOhHGsUaAw",
      "expanded_url" : "http:\/\/Mr.Green",
      "display_url" : "Mr.Green"
    } ]
  },
  "geo" : { },
  "id_str" : "595259371812171776",
  "in_reply_to_user_id" : 44196397,
  "text" : "@elonmusk Are you the real life http:\/\/t.co\/JOhHGsUaAw or Nickola Tesla's biggest fan?",
  "id" : 595259371812171776,
  "created_at" : "2015-05-04 16:11:08 +0000",
  "in_reply_to_screen_name" : "elonmusk",
  "in_reply_to_user_id_str" : "44196397",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]