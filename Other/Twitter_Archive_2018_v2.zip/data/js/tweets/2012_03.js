Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 57 ],
      "url" : "https:\/\/t.co\/ufBIq2xj",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.ens.threedeecamera.lite",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178888104290168832",
  "text" : "Check out 3D Camera on Google Play! https:\/\/t.co\/ufBIq2xj",
  "id" : 178888104290168832,
  "created_at" : "2012-03-11 17:00:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https:\/\/t.co\/9xo9CAtm",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=droidbean.hologramlwplite",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178886811827970048",
  "text" : "Check out Hologram Live Wallpaper Lite on Google Play! https:\/\/t.co\/9xo9CAtm",
  "id" : 178886811827970048,
  "created_at" : "2012-03-11 16:55:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178306374290251776",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 hey follow me",
  "id" : 178306374290251776,
  "created_at" : "2012-03-10 02:28:47 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176035603450822656",
  "text" : "@ColemanArmy hey",
  "id" : 176035603450822656,
  "created_at" : "2012-03-03 20:05:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]