Grailbird.data.tweets_2018_11 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "indices" : [ 3, 10 ],
      "id_str" : "712685130",
      "id" : 712685130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Ln63uLbvCJ",
      "expanded_url" : "https:\/\/www.tindie.com\/products\/EccentricWkshp\/grblduino-mega-shield-grbl-11-arduino-cnc-shield\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
      "display_url" : "tindie.com\/products\/Eccen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060929051156713472",
  "text" : "RT @tindie: Back in Stock! GRBLDuino Mega Shield-GRBL 1.1 Arduino CNC Shield https:\/\/t.co\/Ln63uLbvCJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.tindie.com\" rel=\"nofollow\"\u003ETindie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/Ln63uLbvCJ",
        "expanded_url" : "https:\/\/www.tindie.com\/products\/EccentricWkshp\/grblduino-mega-shield-grbl-11-arduino-cnc-shield\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
        "display_url" : "tindie.com\/products\/Eccen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060926320568229889",
    "text" : "Back in Stock! GRBLDuino Mega Shield-GRBL 1.1 Arduino CNC Shield https:\/\/t.co\/Ln63uLbvCJ",
    "id" : 1060926320568229889,
    "created_at" : "2018-11-09 16:05:20 +0000",
    "user" : {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "protected" : false,
      "id_str" : "712685130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694634209567068160\/R8oCIMeb_normal.png",
      "id" : 712685130,
      "verified" : true
    }
  },
  "id" : 1060929051156713472,
  "created_at" : "2018-11-09 16:16:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060928959079170049",
  "text" : "RT @BTCticker: One Bitcoin now worth $6367.175. Market Cap $110.582 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060925007776399360",
    "text" : "One Bitcoin now worth $6367.175. Market Cap $110.582 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1060925007776399360,
    "created_at" : "2018-11-09 16:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1060928959079170049,
  "created_at" : "2018-11-09 16:15:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1060928880863838209\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/LO9JmQArCh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Drks_j8WoAI_D3u.jpg",
      "id_str" : "1060928657714225154",
      "id" : 1060928657714225154,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Drks_j8WoAI_D3u.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/LO9JmQArCh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060928880863838209",
  "text" : "That wasn't even telling all my recommendations, lol. My LinkedIn is like a book.... https:\/\/t.co\/LO9JmQArCh",
  "id" : 1060928880863838209,
  "created_at" : "2018-11-09 16:15:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060923305639714816",
  "text" : "RT @TipsyBartender: Spiked Toasted Marshmallow Milkshake \uD83C\uDF6B\uD83D\uDD25",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060919944345354241",
    "text" : "Spiked Toasted Marshmallow Milkshake \uD83C\uDF6B\uD83D\uDD25",
    "id" : 1060919944345354241,
    "created_at" : "2018-11-09 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1060923305639714816,
  "created_at" : "2018-11-09 15:53:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1060923158772047872\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/jDkIg207fn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Drkn4hbXcAA6PUw.jpg",
      "id_str" : "1060923039221772288",
      "id" : 1060923039221772288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Drkn4hbXcAA6PUw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jDkIg207fn"
    } ],
    "hashtags" : [ {
      "text" : "innovate",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "create",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "STEM",
      "indices" : [ 44, 49 ]
    }, {
      "text" : "Technology",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "Research",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060923158772047872",
  "text" : "What I do in my free time #innovate #create #STEM #Technology #Research https:\/\/t.co\/jDkIg207fn",
  "id" : 1060923158772047872,
  "created_at" : "2018-11-09 15:52:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/tPwT4UbTKp",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/907658029495930880",
      "display_url" : "minds.com\/newsfeed\/90765\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060922971823452160",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/tPwT4UbTKp",
  "id" : 1060922971823452160,
  "created_at" : "2018-11-09 15:52:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060909697396629504",
  "text" : "RT @ausecure: Streaming #Gold $1219.4 -$5\/0.41% #Silver $14.36 -$0.12\/0.84% #Platinum $863.2 -$3.3\/0.38% #Palladium $1121.4 -$9.5\/0.85%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 34, 41 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060879744491839488",
    "text" : "Streaming #Gold $1219.4 -$5\/0.41% #Silver $14.36 -$0.12\/0.84% #Platinum $863.2 -$3.3\/0.38% #Palladium $1121.4 -$9.5\/0.85%",
    "id" : 1060879744491839488,
    "created_at" : "2018-11-09 13:00:15 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 1060909697396629504,
  "created_at" : "2018-11-09 14:59:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060909621387378688",
  "text" : "RT @UberFacts: The opposite of ambidextrous is ambilevous, which describes someone who is equally clumsy using either hand.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060846208485330944",
    "text" : "The opposite of ambidextrous is ambilevous, which describes someone who is equally clumsy using either hand.",
    "id" : 1060846208485330944,
    "created_at" : "2018-11-09 10:47:00 +0000",
    "user" : {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "protected" : false,
      "id_str" : "95023423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615696617165885440\/JDbUuo9H_normal.jpg",
      "id" : 95023423,
      "verified" : true
    }
  },
  "id" : 1060909621387378688,
  "created_at" : "2018-11-09 14:58:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060908688557379585",
  "text" : "RT @instructables: Level up your 3D design skills by checking out this free class on how to get started with 3D Scanning! https:\/\/t.co\/4AeB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/4AeBTVKgp0",
        "expanded_url" : "http:\/\/bit.ly\/2pydpSu",
        "display_url" : "bit.ly\/2pydpSu"
      } ]
    },
    "geo" : { },
    "id_str" : "1060655954331615232",
    "text" : "Level up your 3D design skills by checking out this free class on how to get started with 3D Scanning! https:\/\/t.co\/4AeBTVKgp0",
    "id" : 1060655954331615232,
    "created_at" : "2018-11-08 22:11:00 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1060908688557379585,
  "created_at" : "2018-11-09 14:55:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joule",
      "screen_name" : "Joule_CP",
      "indices" : [ 3, 12 ],
      "id_str" : "832269702818885632",
      "id" : 832269702818885632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/bzs5CmGDcx",
      "expanded_url" : "http:\/\/bit.ly\/2FeEtkS",
      "display_url" : "bit.ly\/2FeEtkS"
    } ]
  },
  "geo" : { },
  "id_str" : "1060655163772452864",
  "text" : "RT @Joule_CP: Preview - Boosting the Single-Pass Conversion for Renewable Chemical Electrosynthesis https:\/\/t.co\/bzs5CmGDcx Free to downloa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.spredfast.com\/\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sargent Group UofT",
        "screen_name" : "Sargent_Group",
        "indices" : [ 228, 242 ],
        "id_str" : "968509662277652480",
        "id" : 968509662277652480
      }, {
        "name" : "Stanford Chemistry",
        "screen_name" : "StanfordUChem",
        "indices" : [ 243, 257 ],
        "id_str" : "3063734826",
        "id" : 3063734826
      }, {
        "name" : "ECE U of T",
        "screen_name" : "eceuoft",
        "indices" : [ 258, 266 ],
        "id_str" : "109564250",
        "id" : 109564250
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Energy",
        "indices" : [ 172, 179 ]
      }, {
        "text" : "EnergyResearch",
        "indices" : [ 180, 195 ]
      }, {
        "text" : "Catalysis",
        "indices" : [ 196, 206 ]
      }, {
        "text" : "CO2",
        "indices" : [ 207, 211 ]
      }, {
        "text" : "RenewableFuels",
        "indices" : [ 212, 227 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/bzs5CmGDcx",
        "expanded_url" : "http:\/\/bit.ly\/2FeEtkS",
        "display_url" : "bit.ly\/2FeEtkS"
      }, {
        "indices" : [ 147, 170 ],
        "url" : "https:\/\/t.co\/338zOQ8VAP",
        "expanded_url" : "http:\/\/bit.ly\/2FeEzJg",
        "display_url" : "bit.ly\/2FeEzJg"
      } ]
    },
    "geo" : { },
    "id_str" : "1059532638959165441",
    "text" : "Preview - Boosting the Single-Pass Conversion for Renewable Chemical Electrosynthesis https:\/\/t.co\/bzs5CmGDcx Free to download on Joule mobile app https:\/\/t.co\/338zOQ8VAP. #Energy #EnergyResearch #Catalysis #CO2 #RenewableFuels @Sargent_Group @StanfordUChem @eceuoft",
    "id" : 1059532638959165441,
    "created_at" : "2018-11-05 19:47:20 +0000",
    "user" : {
      "name" : "Joule",
      "screen_name" : "Joule_CP",
      "protected" : false,
      "id_str" : "832269702818885632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/977157517821259777\/GfYKcusX_normal.jpg",
      "id" : 832269702818885632,
      "verified" : false
    }
  },
  "id" : 1060655163772452864,
  "created_at" : "2018-11-08 22:07:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Joule",
      "screen_name" : "Joule_CP",
      "indices" : [ 95, 104 ],
      "id_str" : "832269702818885632",
      "id" : 832269702818885632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "renewableenergy",
      "indices" : [ 31, 47 ]
    }, {
      "text" : "space",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/fKPx2xa8pH",
      "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-harvesting-renewable-energy-sun-outer.html",
      "display_url" : "techxplore.com\/news\/2018-11-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060654657503141900",
  "text" : "RT @TechXplore_com: Harvesting #renewableenergy from the sun and outer #space at the same time @Joule_CP https:\/\/t.co\/fKPx2xa8pH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joule",
        "screen_name" : "Joule_CP",
        "indices" : [ 75, 84 ],
        "id_str" : "832269702818885632",
        "id" : 832269702818885632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "renewableenergy",
        "indices" : [ 11, 27 ]
      }, {
        "text" : "space",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/fKPx2xa8pH",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-harvesting-renewable-energy-sun-outer.html",
        "display_url" : "techxplore.com\/news\/2018-11-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060562618736394241",
    "text" : "Harvesting #renewableenergy from the sun and outer #space at the same time @Joule_CP https:\/\/t.co\/fKPx2xa8pH",
    "id" : 1060562618736394241,
    "created_at" : "2018-11-08 16:00:07 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1060654657503141900,
  "created_at" : "2018-11-08 22:05:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060654122301566976",
  "text" : "RT @BTCticker: One Bitcoin now worth $6439.642. Market Cap $111.833 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060653221847416833",
    "text" : "One Bitcoin now worth $6439.642. Market Cap $111.833 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1060653221847416833,
    "created_at" : "2018-11-08 22:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1060654122301566976,
  "created_at" : "2018-11-08 22:03:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/u5Zo6r4idw",
      "expanded_url" : "https:\/\/fstoppers.com\/contests\/winner-flashlight-photo-challenge-304092?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/contests\/winne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060653944408604672",
  "text" : "RT @JayHoque: Winner of the Flashlight Photo Challenge: https:\/\/t.co\/u5Zo6r4idw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/u5Zo6r4idw",
        "expanded_url" : "https:\/\/fstoppers.com\/contests\/winner-flashlight-photo-challenge-304092?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/contests\/winne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060643744586887169",
    "text" : "Winner of the Flashlight Photo Challenge: https:\/\/t.co\/u5Zo6r4idw",
    "id" : 1060643744586887169,
    "created_at" : "2018-11-08 21:22:29 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1060653944408604672,
  "created_at" : "2018-11-08 22:03:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/evYk0vCw0D",
      "expanded_url" : "https:\/\/nikonrumors.com\/2018\/11\/08\/used-nikon-z7-cameras-now-available-at-bh-up-to-15-off-regular-price.aspx\/",
      "display_url" : "nikonrumors.com\/2018\/11\/08\/use\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060653802255278080",
  "text" : "RT @JayHoque: Used Nikon Z7 cameras now available at B&amp;H (up to 15% off regular price): https:\/\/t.co\/evYk0vCw0D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/evYk0vCw0D",
        "expanded_url" : "https:\/\/nikonrumors.com\/2018\/11\/08\/used-nikon-z7-cameras-now-available-at-bh-up-to-15-off-regular-price.aspx\/",
        "display_url" : "nikonrumors.com\/2018\/11\/08\/use\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060637404346892288",
    "text" : "Used Nikon Z7 cameras now available at B&amp;H (up to 15% off regular price): https:\/\/t.co\/evYk0vCw0D",
    "id" : 1060637404346892288,
    "created_at" : "2018-11-08 20:57:17 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1060653802255278080,
  "created_at" : "2018-11-08 22:02:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "indices" : [ 3, 9 ],
      "id_str" : "4020532937",
      "id" : 4020532937
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1060640032619483136\/video\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/dUha5QfTyV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrgmLPoWwAAKRif.jpg",
      "id_str" : "1060639689353424896",
      "id" : 1060639689353424896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrgmLPoWwAAKRif.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dUha5QfTyV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060653788900540421",
  "text" : "RT @tasty: This stunning Cookies 'N' Cream Icebox Cake is the giant, fancy cookie of your dreams\u2728\uD83D\uDE0D https:\/\/t.co\/dUha5QfTyV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/pubhub.buzzfeed.com\" rel=\"nofollow\"\u003EBF PubHub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1060640032619483136\/video\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/dUha5QfTyV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrgmLPoWwAAKRif.jpg",
        "id_str" : "1060639689353424896",
        "id" : 1060639689353424896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrgmLPoWwAAKRif.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/dUha5QfTyV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060640032619483136",
    "text" : "This stunning Cookies 'N' Cream Icebox Cake is the giant, fancy cookie of your dreams\u2728\uD83D\uDE0D https:\/\/t.co\/dUha5QfTyV",
    "id" : 1060640032619483136,
    "created_at" : "2018-11-08 21:07:44 +0000",
    "user" : {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "protected" : false,
      "id_str" : "4020532937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887725624105738240\/enrb4x3-_normal.jpg",
      "id" : 4020532937,
      "verified" : true
    }
  },
  "id" : 1060653788900540421,
  "created_at" : "2018-11-08 22:02:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/tvg8mwE9ew",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/11\/how-to-make-american-buttercream.html",
      "display_url" : "seriouseats.com\/2018\/11\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060653641126854658",
  "text" : "RT @seriouseats: *So* much better than the supermarket stuff. https:\/\/t.co\/tvg8mwE9ew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/tvg8mwE9ew",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/11\/how-to-make-american-buttercream.html",
        "display_url" : "seriouseats.com\/2018\/11\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060638741419696128",
    "text" : "*So* much better than the supermarket stuff. https:\/\/t.co\/tvg8mwE9ew",
    "id" : 1060638741419696128,
    "created_at" : "2018-11-08 21:02:36 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1060653641126854658,
  "created_at" : "2018-11-08 22:01:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1060638590546276352\/video\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/MWUH9HtiW5",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/917351457069916160\/pu\/img\/bqQBSURbsfip7SHQ.jpg",
      "id_str" : "917351457069916160",
      "id" : 917351457069916160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/917351457069916160\/pu\/img\/bqQBSURbsfip7SHQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/MWUH9HtiW5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060653616237891586",
  "text" : "RT @epicurious: Lunch in a pita. https:\/\/t.co\/MWUH9HtiW5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1060638590546276352\/video\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/MWUH9HtiW5",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/917351457069916160\/pu\/img\/bqQBSURbsfip7SHQ.jpg",
        "id_str" : "917351457069916160",
        "id" : 917351457069916160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/917351457069916160\/pu\/img\/bqQBSURbsfip7SHQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/MWUH9HtiW5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060638590546276352",
    "text" : "Lunch in a pita. https:\/\/t.co\/MWUH9HtiW5",
    "id" : 1060638590546276352,
    "created_at" : "2018-11-08 21:02:00 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1060653616237891586,
  "created_at" : "2018-11-08 22:01:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060653201853243392",
  "text" : "My research is coming along nicely...",
  "id" : 1060653201853243392,
  "created_at" : "2018-11-08 22:00:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "byte",
      "screen_name" : "byte_app",
      "indices" : [ 3, 12 ],
      "id_str" : "937756451380088838",
      "id" : 937756451380088838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060653093480751104",
  "text" : "RT @byte_app: \uD83D\uDC4B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060637539030233090",
    "text" : "\uD83D\uDC4B",
    "id" : 1060637539030233090,
    "created_at" : "2018-11-08 20:57:49 +0000",
    "user" : {
      "name" : "byte",
      "screen_name" : "byte_app",
      "protected" : false,
      "id_str" : "937756451380088838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1060617373982572544\/appZSdI4_normal.jpg",
      "id" : 937756451380088838,
      "verified" : false
    }
  },
  "id" : 1060653093480751104,
  "created_at" : "2018-11-08 21:59:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060638113574334470",
  "text" : "RT @TipsyBartender: Blackberry Lemonade Margarita \uD83C\uDF4B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060582722631032834",
    "text" : "Blackberry Lemonade Margarita \uD83C\uDF4B",
    "id" : 1060582722631032834,
    "created_at" : "2018-11-08 17:20:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1060638113574334470,
  "created_at" : "2018-11-08 21:00:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/G5IkM5oxjw",
      "expanded_url" : "https:\/\/buff.ly\/2P7LfNX",
      "display_url" : "buff.ly\/2P7LfNX"
    } ]
  },
  "geo" : { },
  "id_str" : "1060637801039978497",
  "text" : "RT @analyticbridge: Comparison of open source software suites for data mining https:\/\/t.co\/G5IkM5oxjw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/G5IkM5oxjw",
        "expanded_url" : "https:\/\/buff.ly\/2P7LfNX",
        "display_url" : "buff.ly\/2P7LfNX"
      } ]
    },
    "geo" : { },
    "id_str" : "1060623512384212993",
    "text" : "Comparison of open source software suites for data mining https:\/\/t.co\/G5IkM5oxjw",
    "id" : 1060623512384212993,
    "created_at" : "2018-11-08 20:02:05 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 1060637801039978497,
  "created_at" : "2018-11-08 20:58:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/DfBgEGrpTY",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/best-google-fonts-for-headings\/",
      "display_url" : "webdesigndev.com\/best-google-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060637449762889734",
  "text" : "RT @WebDesignDev: 20 Best Google Fonts for Headings and Body Text: https:\/\/t.co\/DfBgEGrpTY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/DfBgEGrpTY",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/best-google-fonts-for-headings\/",
        "display_url" : "webdesigndev.com\/best-google-fo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060626112135479296",
    "text" : "20 Best Google Fonts for Headings and Body Text: https:\/\/t.co\/DfBgEGrpTY",
    "id" : 1060626112135479296,
    "created_at" : "2018-11-08 20:12:25 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1060637449762889734,
  "created_at" : "2018-11-08 20:57:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/brLlxpuyFR",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/907368427376242688",
      "display_url" : "minds.com\/newsfeed\/90736\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060637318288150529",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/brLlxpuyFR",
  "id" : 1060637318288150529,
  "created_at" : "2018-11-08 20:56:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060620677550669825",
  "text" : "RT @TheSharkDaymond: \u201CA brilliant idea doesn't guarantee a successful invention. Real magic comes from a brilliant idea combined with willp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori Greiner",
        "screen_name" : "LoriGreiner",
        "indices" : [ 173, 185 ],
        "id_str" : "31869934",
        "id" : 31869934
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060594047407046656",
    "text" : "\u201CA brilliant idea doesn't guarantee a successful invention. Real magic comes from a brilliant idea combined with willpower, tenacity, and a willingness to make mistakes.\u201D - @LoriGreiner",
    "id" : 1060594047407046656,
    "created_at" : "2018-11-08 18:05:00 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1060620677550669825,
  "created_at" : "2018-11-08 19:50:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Massachusetts Institute of Technology (MIT)",
      "screen_name" : "MIT",
      "indices" : [ 83, 87 ],
      "id_str" : "15460048",
      "id" : 15460048
    }, {
      "name" : "Science Magazine",
      "screen_name" : "sciencemagazine",
      "indices" : [ 88, 104 ],
      "id_str" : "32372834",
      "id" : 32372834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/JzxTwyPuCi",
      "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-life-low-cost-compact-lightweight-batteries.html",
      "display_url" : "techxplore.com\/news\/2018-11-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060620279641182208",
  "text" : "RT @TechXplore_com: Extending the life of low-cost, compact, lightweight batteries @MIT @sciencemagazine https:\/\/t.co\/JzxTwyPuCi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Massachusetts Institute of Technology (MIT)",
        "screen_name" : "MIT",
        "indices" : [ 63, 67 ],
        "id_str" : "15460048",
        "id" : 15460048
      }, {
        "name" : "Science Magazine",
        "screen_name" : "sciencemagazine",
        "indices" : [ 68, 84 ],
        "id_str" : "32372834",
        "id" : 32372834
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/JzxTwyPuCi",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-life-low-cost-compact-lightweight-batteries.html",
        "display_url" : "techxplore.com\/news\/2018-11-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060607945027784704",
    "text" : "Extending the life of low-cost, compact, lightweight batteries @MIT @sciencemagazine https:\/\/t.co\/JzxTwyPuCi",
    "id" : 1060607945027784704,
    "created_at" : "2018-11-08 19:00:13 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1060620279641182208,
  "created_at" : "2018-11-08 19:49:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/UyTunimfOn",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/08\/vine-revives-as-byte-next-spring\/",
      "display_url" : "engadget.com\/2018\/11\/08\/vin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060620062518841346",
  "text" : "RT @engadget: Vine will revive as Byte next spring https:\/\/t.co\/UyTunimfOn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/UyTunimfOn",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/08\/vine-revives-as-byte-next-spring\/",
        "display_url" : "engadget.com\/2018\/11\/08\/vin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060619109765996552",
    "text" : "Vine will revive as Byte next spring https:\/\/t.co\/UyTunimfOn",
    "id" : 1060619109765996552,
    "created_at" : "2018-11-08 19:44:35 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1060620062518841346,
  "created_at" : "2018-11-08 19:48:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060619858633744385",
  "text" : "It is a good thing I started contributing towards research for Asteroid mining....",
  "id" : 1060619858633744385,
  "created_at" : "2018-11-08 19:47:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hern\u00E1n Moya Carrera \uD83C\uDDE8\uD83C\uDDF1 \uD83C\uDF32\uD83C\uDF32\uD83C\uDF7A\uD83C\uDF7A",
      "screen_name" : "hernan_moya",
      "indices" : [ 3, 15 ],
      "id_str" : "33179025",
      "id" : 33179025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/JdPvY5OYvD",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/04\/planetary-resources-acquired-by-blockchain-company\/",
      "display_url" : "engadget.com\/2018\/11\/04\/pla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060619775364227072",
  "text" : "RT @hernan_moya: Blockchain company buys asteroid mining firm Planetary Resources https:\/\/t.co\/JdPvY5OYvD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/JdPvY5OYvD",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/04\/planetary-resources-acquired-by-blockchain-company\/",
        "display_url" : "engadget.com\/2018\/11\/04\/pla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060600937377492992",
    "text" : "Blockchain company buys asteroid mining firm Planetary Resources https:\/\/t.co\/JdPvY5OYvD",
    "id" : 1060600937377492992,
    "created_at" : "2018-11-08 18:32:23 +0000",
    "user" : {
      "name" : "Hern\u00E1n Moya Carrera \uD83C\uDDE8\uD83C\uDDF1 \uD83C\uDF32\uD83C\uDF32\uD83C\uDF7A\uD83C\uDF7A",
      "screen_name" : "hernan_moya",
      "protected" : false,
      "id_str" : "33179025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916328427116023808\/WJa9ipdR_normal.jpg",
      "id" : 33179025,
      "verified" : false
    }
  },
  "id" : 1060619775364227072,
  "created_at" : "2018-11-08 19:47:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3Dprinter",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060619152589840385",
  "text" : "RT @instructables: This cute kitty coffee table was cast from concrete and molded with the help of a #3Dprinter. This is one of the most br\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3Dprinter",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 188, 211 ],
        "url" : "https:\/\/t.co\/kIynzou0jv",
        "expanded_url" : "http:\/\/bit.ly\/2SVwaxe",
        "display_url" : "bit.ly\/2SVwaxe"
      } ]
    },
    "geo" : { },
    "id_str" : "1060536417309388800",
    "text" : "This cute kitty coffee table was cast from concrete and molded with the help of a #3Dprinter. This is one of the most brilliant mold making techniques we've seen in a while, take a look \uD83D\uDC40 https:\/\/t.co\/kIynzou0jv",
    "id" : 1060536417309388800,
    "created_at" : "2018-11-08 14:16:00 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1060619152589840385,
  "created_at" : "2018-11-08 19:44:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060619105659768832",
  "text" : "RT @TipsyBartender: Cereal Milk \uD83C\uDF7C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060557557041782784",
    "text" : "Cereal Milk \uD83C\uDF7C",
    "id" : 1060557557041782784,
    "created_at" : "2018-11-08 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1060619105659768832,
  "created_at" : "2018-11-08 19:44:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060619095811518466",
  "text" : "I have my research disclosures published... stay tuned...",
  "id" : 1060619095811518466,
  "created_at" : "2018-11-08 19:44:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060618989162901510",
  "text" : "RT @BarbaraCorcoran: Every great accomplishment is a result of a clear deadline and great motivation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060550288988389384",
    "text" : "Every great accomplishment is a result of a clear deadline and great motivation.",
    "id" : 1060550288988389384,
    "created_at" : "2018-11-08 15:11:07 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1060618989162901510,
  "created_at" : "2018-11-08 19:44:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060306131099226112",
  "text" : "RT @TipsyBartender: Ghoulish Shooters \uD83D\uDC7B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057643354710859776",
    "text" : "Ghoulish Shooters \uD83D\uDC7B",
    "id" : 1057643354710859776,
    "created_at" : "2018-10-31 14:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1060306131099226112,
  "created_at" : "2018-11-07 23:00:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ozCInnQVw5",
      "expanded_url" : "https:\/\/makezine.com\/projects\/led-nixie-display\/",
      "display_url" : "makezine.com\/projects\/led-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1060305753037246464",
  "text" : "RT @make: Ever heard of Lixie displays? Here's how to build one! https:\/\/t.co\/ozCInnQVw5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/ozCInnQVw5",
        "expanded_url" : "https:\/\/makezine.com\/projects\/led-nixie-display\/",
        "display_url" : "makezine.com\/projects\/led-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1060269695461457920",
    "text" : "Ever heard of Lixie displays? Here's how to build one! https:\/\/t.co\/ozCInnQVw5",
    "id" : 1060269695461457920,
    "created_at" : "2018-11-07 20:36:08 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1060305753037246464,
  "created_at" : "2018-11-07 22:59:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staytuned",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060305635919740930",
  "text" : "Waiting for my defensive publications to be live... #staytuned",
  "id" : 1060305635919740930,
  "created_at" : "2018-11-07 22:58:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shell Capital Management, LLC",
      "screen_name" : "ShellCapital",
      "indices" : [ 3, 16 ],
      "id_str" : "923564411142443019",
      "id" : 923564411142443019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060305353341132800",
  "text" : "RT @ShellCapital: Investors may shift from the fear of losing money and the fear of missing out if they reduced exposure after the stock ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060261673599225856",
    "text" : "Investors may shift from the fear of losing money and the fear of missing out if they reduced exposure after the stock market falls and then miss out as stocks trends back up. \n\nAn active risk management system for drawdown control may help avoid emotional decisions.",
    "id" : 1060261673599225856,
    "created_at" : "2018-11-07 20:04:16 +0000",
    "user" : {
      "name" : "Shell Capital Management, LLC",
      "screen_name" : "ShellCapital",
      "protected" : false,
      "id_str" : "923564411142443019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/998551055234301953\/6v6Ib_7X_normal.jpg",
      "id" : 923564411142443019,
      "verified" : false
    }
  },
  "id" : 1060305353341132800,
  "created_at" : "2018-11-07 22:57:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/R39uoFuN1I",
      "expanded_url" : "https:\/\/trib.al\/ASJGZQR",
      "display_url" : "trib.al\/ASJGZQR"
    } ]
  },
  "geo" : { },
  "id_str" : "1060305022548873217",
  "text" : "RT @epicurious: Cheesecake is forever. \nhttps:\/\/t.co\/R39uoFuN1I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/R39uoFuN1I",
        "expanded_url" : "https:\/\/trib.al\/ASJGZQR",
        "display_url" : "trib.al\/ASJGZQR"
      } ]
    },
    "geo" : { },
    "id_str" : "1060181843796987905",
    "text" : "Cheesecake is forever. \nhttps:\/\/t.co\/R39uoFuN1I",
    "id" : 1060181843796987905,
    "created_at" : "2018-11-07 14:47:03 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1060305022548873217,
  "created_at" : "2018-11-07 22:56:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060304992534437889",
  "text" : "RT @elonmusk: Mod to SpaceX tech tree build: Falcon 9 second stage will be upgraded to be like a mini-BFR Ship",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060253333116473344",
    "text" : "Mod to SpaceX tech tree build: Falcon 9 second stage will be upgraded to be like a mini-BFR Ship",
    "id" : 1060253333116473344,
    "created_at" : "2018-11-07 19:31:07 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1060304992534437889,
  "created_at" : "2018-11-07 22:56:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/BnS4erxKX6",
      "expanded_url" : "https:\/\/osf.io\/fxqru\/",
      "display_url" : "osf.io\/fxqru\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1060304914923040773",
  "text" : "Hosted on Academia as well, these preprints are giving me trouble: https:\/\/t.co\/BnS4erxKX6",
  "id" : 1060304914923040773,
  "created_at" : "2018-11-07 22:56:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/o7QryTCVKe",
      "expanded_url" : "https:\/\/tcrn.ch\/2Doj0EA",
      "display_url" : "tcrn.ch\/2Doj0EA"
    } ]
  },
  "geo" : { },
  "id_str" : "1059996249322151936",
  "text" : "RT @TechCrunch: Nikola Motor unveils a new hydrogen semi truck designed for Europe https:\/\/t.co\/o7QryTCVKe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/o7QryTCVKe",
        "expanded_url" : "https:\/\/tcrn.ch\/2Doj0EA",
        "display_url" : "tcrn.ch\/2Doj0EA"
      } ]
    },
    "geo" : { },
    "id_str" : "1059909798265798656",
    "text" : "Nikola Motor unveils a new hydrogen semi truck designed for Europe https:\/\/t.co\/o7QryTCVKe",
    "id" : 1059909798265798656,
    "created_at" : "2018-11-06 20:46:02 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969240943671955456\/mGuud28F_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 1059996249322151936,
  "created_at" : "2018-11-07 02:29:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakerEducation",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ECvmrGwBk2",
      "expanded_url" : "https:\/\/adafru.it\/CYJ",
      "display_url" : "adafru.it\/CYJ"
    } ]
  },
  "geo" : { },
  "id_str" : "1059995037784829952",
  "text" : "RT @adafruit: Top US STEM Prize Won By 13 Year Old Designer Of Solar Panels #MakerEducation https:\/\/t.co\/ECvmrGwBk2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakerEducation",
        "indices" : [ 62, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/ECvmrGwBk2",
        "expanded_url" : "https:\/\/adafru.it\/CYJ",
        "display_url" : "adafru.it\/CYJ"
      } ]
    },
    "geo" : { },
    "id_str" : "1059747429849927680",
    "text" : "Top US STEM Prize Won By 13 Year Old Designer Of Solar Panels #MakerEducation https:\/\/t.co\/ECvmrGwBk2",
    "id" : 1059747429849927680,
    "created_at" : "2018-11-06 10:00:51 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1059995037784829952,
  "created_at" : "2018-11-07 02:24:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "indices" : [ 3, 15 ],
      "id_str" : "908383032767369216",
      "id" : 908383032767369216
    }, {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 98, 112 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "voted",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "TARDIS",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "Furniture",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "Contest",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059993687059505153",
  "text" : "RT @shea_street: Thanks to all those #DoctorWho fans who #voted for my #TARDIS inspired CARTIS in @instructables #Furniture #Contest 2018!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "instructables",
        "screen_name" : "instructables",
        "indices" : [ 81, 95 ],
        "id_str" : "7597362",
        "id" : 7597362
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 20, 30 ]
      }, {
        "text" : "voted",
        "indices" : [ 40, 46 ]
      }, {
        "text" : "TARDIS",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "Furniture",
        "indices" : [ 96, 106 ]
      }, {
        "text" : "Contest",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 257, 280 ],
        "url" : "https:\/\/t.co\/XkEuWuKeWX",
        "expanded_url" : "https:\/\/bit.ly\/2qst9Yq",
        "display_url" : "bit.ly\/2qst9Yq"
      } ]
    },
    "geo" : { },
    "id_str" : "1059899049124474880",
    "text" : "Thanks to all those #DoctorWho fans who #voted for my #TARDIS inspired CARTIS in @instructables #Furniture #Contest 2018! I GOT FIRST PRIZE! I am overly happy and excited for the honor but it was all of you \"who\" got me there. Keep being brilliant! GO LOOK https:\/\/t.co\/XkEuWuKeWX",
    "id" : 1059899049124474880,
    "created_at" : "2018-11-06 20:03:19 +0000",
    "user" : {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "protected" : false,
      "id_str" : "908383032767369216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908394866639589377\/KRY3inx7_normal.jpg",
      "id" : 908383032767369216,
      "verified" : false
    }
  },
  "id" : 1059993687059505153,
  "created_at" : "2018-11-07 02:19:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/UgMubuHZ5T",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2010\/11\/how-to-make-mashed-potatoes-thanksgiving-sides-fluffy-creamy.html",
      "display_url" : "seriouseats.com\/2010\/11\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059993424038936578",
  "text" : "RT @seriouseats: Are you a creamy pur\u00E9e type or a light and fluffy?\nhttps:\/\/t.co\/UgMubuHZ5T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/UgMubuHZ5T",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2010\/11\/how-to-make-mashed-potatoes-thanksgiving-sides-fluffy-creamy.html",
        "display_url" : "seriouseats.com\/2010\/11\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059988809721368576",
    "text" : "Are you a creamy pur\u00E9e type or a light and fluffy?\nhttps:\/\/t.co\/UgMubuHZ5T",
    "id" : 1059988809721368576,
    "created_at" : "2018-11-07 02:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1059993424038936578,
  "created_at" : "2018-11-07 02:18:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MacBook",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059993230056570881",
  "text" : "RT @instructables: Want a brand new #MacBook? That's the grand prize in our Plastics Contest! If you've got a great idea for epoxy, acrylic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MacBook",
        "indices" : [ 17, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 239, 262 ],
        "url" : "https:\/\/t.co\/BII3zUgnmi",
        "expanded_url" : "http:\/\/bit.ly\/2NWTzQ0",
        "display_url" : "bit.ly\/2NWTzQ0"
      } ]
    },
    "geo" : { },
    "id_str" : "1059910295055974400",
    "text" : "Want a brand new #MacBook? That's the grand prize in our Plastics Contest! If you've got a great idea for epoxy, acrylic, resin, or any other kind of plastic - publish it to the Plastics Contest for you chance at a haul of amazing prizes! https:\/\/t.co\/BII3zUgnmi",
    "id" : 1059910295055974400,
    "created_at" : "2018-11-06 20:48:01 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1059993230056570881,
  "created_at" : "2018-11-07 02:17:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cryptohopper",
      "screen_name" : "cryptohopper",
      "indices" : [ 3, 16 ],
      "id_str" : "903007348905701376",
      "id" : 903007348905701376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hoptothetop",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059993169201381378",
  "text" : "RT @cryptohopper: Our hoppers are working hard while we're hardly working on trading.\nPost your trading screenshots below!\n#Hoptothetop #cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cryptohopper\/status\/1055434887556161542\/photo\/1",
        "indices" : [ 176, 199 ],
        "url" : "https:\/\/t.co\/edAw2g9FS5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DqWobnRWkAI6EHK.jpg",
        "id_str" : "1055434880039948290",
        "id" : 1055434880039948290,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DqWobnRWkAI6EHK.jpg",
        "sizes" : [ {
          "h" : 843,
          "resize" : "fit",
          "w" : 1591
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 843,
          "resize" : "fit",
          "w" : 1591
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/edAw2g9FS5"
      } ],
      "hashtags" : [ {
        "text" : "Hoptothetop",
        "indices" : [ 105, 117 ]
      }, {
        "text" : "cryptohopper",
        "indices" : [ 118, 131 ]
      }, {
        "text" : "trading",
        "indices" : [ 132, 140 ]
      }, {
        "text" : "btc",
        "indices" : [ 141, 145 ]
      }, {
        "text" : "eth",
        "indices" : [ 146, 150 ]
      }, {
        "text" : "cryptocurrency",
        "indices" : [ 151, 166 ]
      }, {
        "text" : "trading",
        "indices" : [ 167, 175 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1055434887556161542",
    "text" : "Our hoppers are working hard while we're hardly working on trading.\nPost your trading screenshots below!\n#Hoptothetop #cryptohopper #trading #btc #eth #cryptocurrency #trading https:\/\/t.co\/edAw2g9FS5",
    "id" : 1055434887556161542,
    "created_at" : "2018-10-25 12:24:20 +0000",
    "user" : {
      "name" : "Cryptohopper",
      "screen_name" : "cryptohopper",
      "protected" : false,
      "id_str" : "903007348905701376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/976432165507489792\/hX_MTK3f_normal.jpg",
      "id" : 903007348905701376,
      "verified" : false
    }
  },
  "id" : 1059993169201381378,
  "created_at" : "2018-11-07 02:17:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059971596474048514",
  "text" : "RT @seriouseats: Make this into a one-pan dish by using the same skillet for the tortillas that you used to cook the chorizo. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/0kRO065Up9",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/08\/quick-easy-dinner-in-20-chorizo-quesadillas-radish-fennel-salsa.html",
        "display_url" : "seriouseats.com\/2016\/08\/quick-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059943513108946946",
    "text" : "Make this into a one-pan dish by using the same skillet for the tortillas that you used to cook the chorizo. https:\/\/t.co\/0kRO065Up9",
    "id" : 1059943513108946946,
    "created_at" : "2018-11-06 23:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1059971596474048514,
  "created_at" : "2018-11-07 00:51:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/LNfnULnsBl",
      "expanded_url" : "https:\/\/trib.al\/GDwBmz2",
      "display_url" : "trib.al\/GDwBmz2"
    } ]
  },
  "geo" : { },
  "id_str" : "1059971536763920386",
  "text" : "RT @epicurious: She\u2019s beauty and she\u2019s grace. \nhttps:\/\/t.co\/LNfnULnsBl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/LNfnULnsBl",
        "expanded_url" : "https:\/\/trib.al\/GDwBmz2",
        "display_url" : "trib.al\/GDwBmz2"
      } ]
    },
    "geo" : { },
    "id_str" : "1059970453438164995",
    "text" : "She\u2019s beauty and she\u2019s grace. \nhttps:\/\/t.co\/LNfnULnsBl",
    "id" : 1059970453438164995,
    "created_at" : "2018-11-07 00:47:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1059971536763920386,
  "created_at" : "2018-11-07 00:51:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059971518959140864",
  "text" : "RT @BarbaraCorcoran: The best reason for going for it is you won't live to regret it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059943821558067200",
    "text" : "The best reason for going for it is you won't live to regret it.",
    "id" : 1059943821558067200,
    "created_at" : "2018-11-06 23:01:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1059971518959140864,
  "created_at" : "2018-11-07 00:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059971482229575680",
  "text" : "Voted today. Full blown conservative...",
  "id" : 1059971482229575680,
  "created_at" : "2018-11-07 00:51:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "indices" : [ 3, 10 ],
      "id_str" : "712685130",
      "id" : 712685130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Bu0CM9wT9i",
      "expanded_url" : "https:\/\/www.tindie.com\/products\/elecrab\/attiny841-breakout-board-2\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
      "display_url" : "tindie.com\/products\/elecr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059897835028709377",
  "text" : "RT @tindie: Back in Stock! ATtiny841 breakout board https:\/\/t.co\/Bu0CM9wT9i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.tindie.com\" rel=\"nofollow\"\u003ETindie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/Bu0CM9wT9i",
        "expanded_url" : "https:\/\/www.tindie.com\/products\/elecrab\/attiny841-breakout-board-2\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
        "display_url" : "tindie.com\/products\/elecr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059891045230465025",
    "text" : "Back in Stock! ATtiny841 breakout board https:\/\/t.co\/Bu0CM9wT9i",
    "id" : 1059891045230465025,
    "created_at" : "2018-11-06 19:31:31 +0000",
    "user" : {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "protected" : false,
      "id_str" : "712685130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694634209567068160\/R8oCIMeb_normal.png",
      "id" : 712685130,
      "verified" : true
    }
  },
  "id" : 1059897835028709377,
  "created_at" : "2018-11-06 19:58:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 3, 10 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/nBsaS7bcSb",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/antonyleather\/2018\/11\/06\/amd-reveals-first-7nm-zen-2-processor-details-faster-higher-core-density-and-lower-power\/?utm_source=TWITTER&utm_medium=social&utm_term=Valerie\/#76616c657269",
      "display_url" : "forbes.com\/sites\/antonyle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059897370752794624",
  "text" : "RT @Forbes: https:\/\/t.co\/nBsaS7bcSb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.forbes.com\" rel=\"nofollow\"\u003EMalorie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/nBsaS7bcSb",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/antonyleather\/2018\/11\/06\/amd-reveals-first-7nm-zen-2-processor-details-faster-higher-core-density-and-lower-power\/?utm_source=TWITTER&utm_medium=social&utm_term=Valerie\/#76616c657269",
        "display_url" : "forbes.com\/sites\/antonyle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059896457434677254",
    "text" : "https:\/\/t.co\/nBsaS7bcSb",
    "id" : 1059896457434677254,
    "created_at" : "2018-11-06 19:53:02 +0000",
    "user" : {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "protected" : false,
      "id_str" : "91478624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1017039596083974149\/6AUhxLpr_normal.jpg",
      "id" : 91478624,
      "verified" : true
    }
  },
  "id" : 1059897370752794624,
  "created_at" : "2018-11-06 19:56:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059897167614279681",
  "text" : "RT @TipsyBartender: Autumn Punch \uD83C\uDF41\uD83C\uDF4D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059495559009103874",
    "text" : "Autumn Punch \uD83C\uDF41\uD83C\uDF4D",
    "id" : 1059495559009103874,
    "created_at" : "2018-11-05 17:20:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1059897167614279681,
  "created_at" : "2018-11-06 19:55:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Entrepreneur",
      "screen_name" : "YoungEnt",
      "indices" : [ 3, 12 ],
      "id_str" : "278691695",
      "id" : 278691695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/VxyrbnM6qF",
      "expanded_url" : "https:\/\/www.entrepreneur.com\/article\/320105",
      "display_url" : "entrepreneur.com\/article\/320105"
    } ]
  },
  "geo" : { },
  "id_str" : "1059897119333646343",
  "text" : "RT @YoungEnt: How to Be Invisible Online -- Without Going Off the Grid (Infographic) https:\/\/t.co\/VxyrbnM6qF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/VxyrbnM6qF",
        "expanded_url" : "https:\/\/www.entrepreneur.com\/article\/320105",
        "display_url" : "entrepreneur.com\/article\/320105"
      } ]
    },
    "geo" : { },
    "id_str" : "1043983374002606080",
    "text" : "How to Be Invisible Online -- Without Going Off the Grid (Infographic) https:\/\/t.co\/VxyrbnM6qF",
    "id" : 1043983374002606080,
    "created_at" : "2018-09-23 22:00:07 +0000",
    "user" : {
      "name" : "Young Entrepreneur",
      "screen_name" : "YoungEnt",
      "protected" : false,
      "id_str" : "278691695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760185769134690304\/ZJbjFVLq_normal.jpg",
      "id" : 278691695,
      "verified" : true
    }
  },
  "id" : 1059897119333646343,
  "created_at" : "2018-11-06 19:55:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059894892183371779",
  "text" : "RT @epicurious: \u201CThis dish is compulsively delicious. One adult could easily eat the entire head of cauliflower for dinner and feel good ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/gK4QscseOL",
        "expanded_url" : "https:\/\/trib.al\/umcHT0b",
        "display_url" : "trib.al\/umcHT0b"
      } ]
    },
    "geo" : { },
    "id_str" : "1059894708686733312",
    "text" : "\u201CThis dish is compulsively delicious. One adult could easily eat the entire head of cauliflower for dinner and feel good about it.\u201D\nhttps:\/\/t.co\/gK4QscseOL",
    "id" : 1059894708686733312,
    "created_at" : "2018-11-06 19:46:05 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1059894892183371779,
  "created_at" : "2018-11-06 19:46:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/AJ9frpTeHT",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=QKHKD8bRAro",
      "display_url" : "youtube.com\/watch?v=QKHKD8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059893410000261120",
  "text" : "So many stuff I want to research... \n\nThis is one of them, but Quantum similarity is also a bigger topic\n\nhttps:\/\/t.co\/AJ9frpTeHT",
  "id" : 1059893410000261120,
  "created_at" : "2018-11-06 19:40:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1059893410000261120",
  "geo" : { },
  "id_str" : "1059893410818076672",
  "in_reply_to_user_id" : 210979938,
  "text" : "Theoretically it is infinite, but how shall we prove it?",
  "id" : 1059893410818076672,
  "in_reply_to_status_id" : 1059893410000261120,
  "created_at" : "2018-11-06 19:40:55 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1059893410818076672",
  "geo" : { },
  "id_str" : "1059893412038615041",
  "in_reply_to_user_id" : 210979938,
  "text" : "It never halts.....",
  "id" : 1059893412038615041,
  "in_reply_to_status_id" : 1059893410818076672,
  "created_at" : "2018-11-06 19:40:55 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1059892258567319553\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/xjm0ZAmVrD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrV-UBVU8AAxOon.jpg",
      "id_str" : "1059892169735991296",
      "id" : 1059892169735991296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrV-UBVU8AAxOon.jpg",
      "sizes" : [ {
        "h" : 206,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 648
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/xjm0ZAmVrD"
    } ],
    "hashtags" : [ {
      "text" : "research",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059892258567319553",
  "text" : "A very nice small paper with some mathematics have come together... Working on some other stuff too... Stay tuned #research https:\/\/t.co\/xjm0ZAmVrD",
  "id" : 1059892258567319553,
  "created_at" : "2018-11-06 19:36:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1059891668135174144\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/kSMzrLQemm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrV90PYV4AA_5vh.jpg",
      "id_str" : "1059891623750918144",
      "id" : 1059891623750918144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrV90PYV4AA_5vh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1123
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1123
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1123
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/kSMzrLQemm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059891668135174144",
  "text" : "Look at those charts... https:\/\/t.co\/kSMzrLQemm",
  "id" : 1059891668135174144,
  "created_at" : "2018-11-06 19:34:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059891426165735424",
  "text" : "RT @TipsyBartender: Rainbow White Wine Spritzer \uD83C\uDF77\uD83C\uDF53\uD83C\uDF4F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059832784364089344",
    "text" : "Rainbow White Wine Spritzer \uD83C\uDF77\uD83C\uDF53\uD83C\uDF4F",
    "id" : 1059832784364089344,
    "created_at" : "2018-11-06 15:40:01 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1059891426165735424,
  "created_at" : "2018-11-06 19:33:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059794686750216195",
  "text" : "RT @BTCticker: One Bitcoin now worth $6426.401. Market Cap $111.579 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059792551572635648",
    "text" : "One Bitcoin now worth $6426.401. Market Cap $111.579 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1059792551572635648,
    "created_at" : "2018-11-06 13:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1059794686750216195,
  "created_at" : "2018-11-06 13:08:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shan Li",
      "screen_name" : "ByShanLi",
      "indices" : [ 3, 12 ],
      "id_str" : "431385079",
      "id" : 431385079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/VaVxeF8BDq",
      "expanded_url" : "http:\/\/www.latimes.com\/business\/la-fi-tn-dollar-shave-exit-20160722-snap-story.html",
      "display_url" : "latimes.com\/business\/la-fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059666347787980800",
  "text" : "RT @ByShanLi: Stubble, champagne &amp; tacos: How Dollar Shave Club employees celebrated $1-billion sale: https:\/\/t.co\/VaVxeF8BDq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/VaVxeF8BDq",
        "expanded_url" : "http:\/\/www.latimes.com\/business\/la-fi-tn-dollar-shave-exit-20160722-snap-story.html",
        "display_url" : "latimes.com\/business\/la-fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757061469921955840",
    "text" : "Stubble, champagne &amp; tacos: How Dollar Shave Club employees celebrated $1-billion sale: https:\/\/t.co\/VaVxeF8BDq",
    "id" : 757061469921955840,
    "created_at" : "2016-07-24 03:54:54 +0000",
    "user" : {
      "name" : "Shan Li",
      "screen_name" : "ByShanLi",
      "protected" : false,
      "id_str" : "431385079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1807123974\/profile_normal.jpg",
      "id" : 431385079,
      "verified" : true
    }
  },
  "id" : 1059666347787980800,
  "created_at" : "2018-11-06 04:38:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "indices" : [ 3, 15 ],
      "id_str" : "28140646",
      "id" : 28140646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059665173873655808",
  "text" : "RT @WSJbusiness: Videogames are under a harsh spotlight by government regulators in China these days, but one piece of the market is growin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shan Li",
        "screen_name" : "ByShanLi",
        "indices" : [ 161, 170 ],
        "id_str" : "431385079",
        "id" : 431385079
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/JvsFVwWoHI",
        "expanded_url" : "https:\/\/on.wsj.com\/2QhCzBl",
        "display_url" : "on.wsj.com\/2QhCzBl"
      } ]
    },
    "geo" : { },
    "id_str" : "1058904179572379649",
    "text" : "Videogames are under a harsh spotlight by government regulators in China these days, but one piece of the market is growing: esports https:\/\/t.co\/JvsFVwWoHI via @ByShanLi",
    "id" : 1058904179572379649,
    "created_at" : "2018-11-04 02:10:04 +0000",
    "user" : {
      "name" : "WSJ Business News",
      "screen_name" : "WSJbusiness",
      "protected" : false,
      "id_str" : "28140646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/954403794057662464\/kTFdxq55_normal.jpg",
      "id" : 28140646,
      "verified" : true
    }
  },
  "id" : 1059665173873655808,
  "created_at" : "2018-11-06 04:33:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059664374107787264",
  "text" : "RT @BTCticker: One Bitcoin now worth $6407.291. Market Cap $111.244 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059664207577317376",
    "text" : "One Bitcoin now worth $6407.291. Market Cap $111.244 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1059664207577317376,
    "created_at" : "2018-11-06 04:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1059664374107787264,
  "created_at" : "2018-11-06 04:30:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059662525019623425",
  "text" : "RT @WSJ: Thanks to volatility, investors often fail to beat the market with a proven strategy\u2014even if they stick to it for as long as 10 ye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/ksxMXXNxQx",
        "expanded_url" : "https:\/\/on.wsj.com\/2DonhHU",
        "display_url" : "on.wsj.com\/2DonhHU"
      } ]
    },
    "geo" : { },
    "id_str" : "1059573615216287745",
    "text" : "Thanks to volatility, investors often fail to beat the market with a proven strategy\u2014even if they stick to it for as long as 10 years https:\/\/t.co\/ksxMXXNxQx",
    "id" : 1059573615216287745,
    "created_at" : "2018-11-05 22:30:10 +0000",
    "user" : {
      "name" : "The Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/971415515754266624\/zCX0q9d5_normal.jpg",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 1059662525019623425,
  "created_at" : "2018-11-06 04:23:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/24mVYGuH9w",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-404-page-templates-psd-html\/",
      "display_url" : "webdesigndev.com\/free-404-page-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059660555449962496",
  "text" : "RT @WebDesignDev: 20 Best HTML &amp; PSD 404 Page Templates: https:\/\/t.co\/24mVYGuH9w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/24mVYGuH9w",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-404-page-templates-psd-html\/",
        "display_url" : "webdesigndev.com\/free-404-page-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059501415712911361",
    "text" : "20 Best HTML &amp; PSD 404 Page Templates: https:\/\/t.co\/24mVYGuH9w",
    "id" : 1059501415712911361,
    "created_at" : "2018-11-05 17:43:16 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1059660555449962496,
  "created_at" : "2018-11-06 04:15:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mTyryiFPvj",
      "expanded_url" : "https:\/\/tcrn.ch\/2Dnioim",
      "display_url" : "tcrn.ch\/2Dnioim"
    } ]
  },
  "geo" : { },
  "id_str" : "1059659921455792128",
  "text" : "RT @TechCrunch: Lime announces a new safety program after its scooters caught on fire https:\/\/t.co\/mTyryiFPvj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/mTyryiFPvj",
        "expanded_url" : "https:\/\/tcrn.ch\/2Dnioim",
        "display_url" : "tcrn.ch\/2Dnioim"
      } ]
    },
    "geo" : { },
    "id_str" : "1059546415326785536",
    "text" : "Lime announces a new safety program after its scooters caught on fire https:\/\/t.co\/mTyryiFPvj",
    "id" : 1059546415326785536,
    "created_at" : "2018-11-05 20:42:05 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969240943671955456\/mGuud28F_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 1059659921455792128,
  "created_at" : "2018-11-06 04:13:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Shapiro",
      "screen_name" : "benshapiro",
      "indices" : [ 3, 14 ],
      "id_str" : "17995040",
      "id" : 17995040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/SRk12WShvz",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=HBDNbpWSUx8",
      "display_url" : "m.youtube.com\/watch?v=HBDNbp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059658976026152961",
  "text" : "RT @benshapiro: Okay, this is actually epic https:\/\/t.co\/SRk12WShvz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/SRk12WShvz",
        "expanded_url" : "https:\/\/m.youtube.com\/watch?v=HBDNbpWSUx8",
        "display_url" : "m.youtube.com\/watch?v=HBDNbp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058447575748042752",
    "text" : "Okay, this is actually epic https:\/\/t.co\/SRk12WShvz",
    "id" : 1058447575748042752,
    "created_at" : "2018-11-02 19:55:41 +0000",
    "user" : {
      "name" : "Ben Shapiro",
      "screen_name" : "benshapiro",
      "protected" : false,
      "id_str" : "17995040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746059589146140672\/ursN3OVD_normal.jpg",
      "id" : 17995040,
      "verified" : true
    }
  },
  "id" : 1059658976026152961,
  "created_at" : "2018-11-06 04:09:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science News",
      "screen_name" : "ScienceNews",
      "indices" : [ 3, 15 ],
      "id_str" : "19402238",
      "id" : 19402238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059655343402311681",
  "text" : "RT @ScienceNews: \u201CI haven\u2019t been this excited about a finding in chemistry in a long time. It\u2019s going to change the way everybody works.\u201D h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/hHsBcSYGmi",
        "expanded_url" : "http:\/\/ow.ly\/UqKh30mpOsb",
        "display_url" : "ow.ly\/UqKh30mpOsb"
      } ]
    },
    "geo" : { },
    "id_str" : "1059617631739744256",
    "text" : "\u201CI haven\u2019t been this excited about a finding in chemistry in a long time. It\u2019s going to change the way everybody works.\u201D https:\/\/t.co\/hHsBcSYGmi",
    "id" : 1059617631739744256,
    "created_at" : "2018-11-06 01:25:04 +0000",
    "user" : {
      "name" : "Science News",
      "screen_name" : "ScienceNews",
      "protected" : false,
      "id_str" : "19402238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000564879746\/1b6204ccf804be6a180408c8f76ab923_normal.png",
      "id" : 19402238,
      "verified" : true
    }
  },
  "id" : 1059655343402311681,
  "created_at" : "2018-11-06 03:54:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "PNAS",
      "screen_name" : "PNASNews",
      "indices" : [ 80, 89 ],
      "id_str" : "258847118",
      "id" : 258847118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hydropower",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "dam",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/gP0JiyYk3d",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-11-hydropower-international-shame.html",
      "display_url" : "phys.org\/news\/2018-11-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059652536158822404",
  "text" : "RT @physorg_com: #Hydropower, innovations and avoiding international #dam shame @PNASNews https:\/\/t.co\/gP0JiyYk3d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PNAS",
        "screen_name" : "PNASNews",
        "indices" : [ 63, 72 ],
        "id_str" : "258847118",
        "id" : 258847118
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hydropower",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "dam",
        "indices" : [ 52, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/gP0JiyYk3d",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-11-hydropower-international-shame.html",
        "display_url" : "phys.org\/news\/2018-11-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059535846641229827",
    "text" : "#Hydropower, innovations and avoiding international #dam shame @PNASNews https:\/\/t.co\/gP0JiyYk3d",
    "id" : 1059535846641229827,
    "created_at" : "2018-11-05 20:00:05 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1059652536158822404,
  "created_at" : "2018-11-06 03:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059488577153839109\/video\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/C5dwpoBYQK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DR90cAfVQAAAwcV.jpg",
      "id_str" : "945602368636203008",
      "id" : 945602368636203008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DR90cAfVQAAAwcV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/C5dwpoBYQK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059652039557423106",
  "text" : "RT @epicurious: Toasted! Coconut! Cold brew! https:\/\/t.co\/C5dwpoBYQK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059488577153839109\/video\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/C5dwpoBYQK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DR90cAfVQAAAwcV.jpg",
        "id_str" : "945602368636203008",
        "id" : 945602368636203008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DR90cAfVQAAAwcV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/C5dwpoBYQK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059488577153839109",
    "text" : "Toasted! Coconut! Cold brew! https:\/\/t.co\/C5dwpoBYQK",
    "id" : 1059488577153839109,
    "created_at" : "2018-11-05 16:52:15 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1059652039557423106,
  "created_at" : "2018-11-06 03:41:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651946397732865",
  "text" : "RT @instructables: Adding cast concrete to your woodworking project is the perfect way to add an easy and affordable modern touch to your d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/WRyiHDCtUW",
        "expanded_url" : "http:\/\/bit.ly\/2SNwkH5",
        "display_url" : "bit.ly\/2SNwkH5"
      } ]
    },
    "geo" : { },
    "id_str" : "1059586410930417664",
    "text" : "Adding cast concrete to your woodworking project is the perfect way to add an easy and affordable modern touch to your design. https:\/\/t.co\/WRyiHDCtUW",
    "id" : 1059586410930417664,
    "created_at" : "2018-11-05 23:21:01 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1059651946397732865,
  "created_at" : "2018-11-06 03:41:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/1059649335023951872\/video\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/knR96rfTiJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrShcyhV4AEk48D.jpg",
      "id_str" : "1059649098981105664",
      "id" : 1059649098981105664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrShcyhV4AEk48D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/knR96rfTiJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651618369617921",
  "text" : "RT @engadget: The dual-display Cosmo Communicator is trying to make PDA phones happen again https:\/\/t.co\/knR96rfTiJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/1059649335023951872\/video\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/knR96rfTiJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrShcyhV4AEk48D.jpg",
        "id_str" : "1059649098981105664",
        "id" : 1059649098981105664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrShcyhV4AEk48D.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/knR96rfTiJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059649335023951872",
    "text" : "The dual-display Cosmo Communicator is trying to make PDA phones happen again https:\/\/t.co\/knR96rfTiJ",
    "id" : 1059649335023951872,
    "created_at" : "2018-11-06 03:31:03 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1059651618369617921,
  "created_at" : "2018-11-06 03:40:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059529031559905280\/video\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/OJYPp8Gxzp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMbLoJDUMAAWLBb.jpg",
      "id_str" : "920646937111511040",
      "id" : 920646937111511040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMbLoJDUMAAWLBb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/OJYPp8Gxzp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651528787742720",
  "text" : "RT @epicurious: Matcha, meet white chocolate. https:\/\/t.co\/OJYPp8Gxzp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059529031559905280\/video\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/OJYPp8Gxzp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DMbLoJDUMAAWLBb.jpg",
        "id_str" : "920646937111511040",
        "id" : 920646937111511040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMbLoJDUMAAWLBb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/OJYPp8Gxzp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059529031559905280",
    "text" : "Matcha, meet white chocolate. https:\/\/t.co\/OJYPp8Gxzp",
    "id" : 1059529031559905280,
    "created_at" : "2018-11-05 19:33:00 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1059651528787742720,
  "created_at" : "2018-11-06 03:39:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3Dprinter",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "OpenSource",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651516515135493",
  "text" : "RT @instructables: Building your own #3Dprinter is rapidly becoming more affordable and accessible! Check out this #OpenSource Design for a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/instructables\/status\/1059613346129952770\/photo\/1",
        "indices" : [ 192, 215 ],
        "url" : "https:\/\/t.co\/V7xJrCxxe3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrSAuPoWkAUnwog.jpg",
        "id_str" : "1059613344297029637",
        "id" : 1059613344297029637,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrSAuPoWkAUnwog.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/V7xJrCxxe3"
      } ],
      "hashtags" : [ {
        "text" : "3Dprinter",
        "indices" : [ 18, 28 ]
      }, {
        "text" : "OpenSource",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 168, 191 ],
        "url" : "https:\/\/t.co\/1AxO0OuMO3",
        "expanded_url" : "http:\/\/bit.ly\/2SOaXp4",
        "display_url" : "bit.ly\/2SOaXp4"
      } ]
    },
    "geo" : { },
    "id_str" : "1059613346129952770",
    "text" : "Building your own #3Dprinter is rapidly becoming more affordable and accessible! Check out this #OpenSource Design for a 3D printer, and get inspired to get tinkering! https:\/\/t.co\/1AxO0OuMO3 https:\/\/t.co\/V7xJrCxxe3",
    "id" : 1059613346129952770,
    "created_at" : "2018-11-06 01:08:03 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1059651516515135493,
  "created_at" : "2018-11-06 03:39:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651310918819840",
  "text" : "RT @TipsyBartender: Toffee Apple Jello Shots \uD83C\uDF4F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059470393042522112",
    "text" : "Toffee Apple Jello Shots \uD83C\uDF4F",
    "id" : 1059470393042522112,
    "created_at" : "2018-11-05 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1059651310918819840,
  "created_at" : "2018-11-06 03:38:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059619626903105536\/video\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/jtndEQ1RdM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DLLhTOdVYAEEf19.jpg",
      "id_str" : "915041266663952384",
      "id" : 915041266663952384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLLhTOdVYAEEf19.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jtndEQ1RdM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651285262221312",
  "text" : "RT @epicurious: The cheesiest enchiladas. https:\/\/t.co\/jtndEQ1RdM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1059619626903105536\/video\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/jtndEQ1RdM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DLLhTOdVYAEEf19.jpg",
        "id_str" : "915041266663952384",
        "id" : 915041266663952384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLLhTOdVYAEEf19.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jtndEQ1RdM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059619626903105536",
    "text" : "The cheesiest enchiladas. https:\/\/t.co\/jtndEQ1RdM",
    "id" : 1059619626903105536,
    "created_at" : "2018-11-06 01:33:00 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1059651285262221312,
  "created_at" : "2018-11-06 03:38:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651235123527680",
  "text" : "RT @BarbaraCorcoran: Attitude is 99% of everything. If you have the right attitude opportunity has a way of finding you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1059548700983345158",
    "text" : "Attitude is 99% of everything. If you have the right attitude opportunity has a way of finding you.",
    "id" : 1059548700983345158,
    "created_at" : "2018-11-05 20:51:10 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1059651235123527680,
  "created_at" : "2018-11-06 03:38:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "innovationXchange",
      "screen_name" : "dfat_iXc",
      "indices" : [ 3, 12 ],
      "id_str" : "3433517413",
      "id" : 3433517413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "tech",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059651189254619136",
  "text" : "RT @dfat_iXc: Need your Monday #science and #tech fix? \n\nLook no further! \n\nDiscover how the Skysource\/Skywater alliance drew water out of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "XPRIZE",
        "screen_name" : "xprize",
        "indices" : [ 168, 175 ],
        "id_str" : "15919988",
        "id" : 15919988
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dfat_iXc\/status\/1059305425693077504\/photo\/1",
        "indices" : [ 201, 224 ],
        "url" : "https:\/\/t.co\/boE9BvWFje",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrNoT8yUUAA2DqY.jpg",
        "id_str" : "1059305029306175488",
        "id" : 1059305029306175488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrNoT8yUUAA2DqY.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/boE9BvWFje"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 17, 25 ]
      }, {
        "text" : "tech",
        "indices" : [ 30, 35 ]
      }, {
        "text" : "WaterAbundanceXPRIZE",
        "indices" : [ 145, 166 ]
      } ],
      "urls" : [ {
        "indices" : [ 177, 200 ],
        "url" : "https:\/\/t.co\/iete649V0D",
        "expanded_url" : "https:\/\/www.xprize.org\/prizes\/water-abundance\/articles\/the-path-to-a-water-abundance-xprize-winner",
        "display_url" : "xprize.org\/prizes\/water-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1059305425693077504",
    "text" : "Need your Monday #science and #tech fix? \n\nLook no further! \n\nDiscover how the Skysource\/Skywater alliance drew water out of thin air to win the #WaterAbundanceXPRIZE. @xprize\n\nhttps:\/\/t.co\/iete649V0D https:\/\/t.co\/boE9BvWFje",
    "id" : 1059305425693077504,
    "created_at" : "2018-11-05 04:44:29 +0000",
    "user" : {
      "name" : "innovationXchange",
      "screen_name" : "dfat_iXc",
      "protected" : false,
      "id_str" : "3433517413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639306314301083648\/awlfDbaw_normal.png",
      "id" : 3433517413,
      "verified" : true
    }
  },
  "id" : 1059651189254619136,
  "created_at" : "2018-11-06 03:38:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "foodchats",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/FL4yYltkc0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bp0u_FMBJFT\/?utm_source=ig_twitter_share&igshid=1928d2d3v21v4",
      "display_url" : "instagram.com\/p\/Bp0u_FMBJFT\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059650228272291840",
  "text" : "Brisket sandwich #foodie #foodpics #foodchats https:\/\/t.co\/FL4yYltkc0",
  "id" : 1059650228272291840,
  "created_at" : "2018-11-06 03:34:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 88, 97 ]
    }, {
      "text" : "foodiechats",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/gowbgbAT06",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bp0u5ZRBYK4\/?utm_source=ig_twitter_share&igshid=18tgpbs28eufg",
      "display_url" : "instagram.com\/p\/Bp0u5ZRBYK4\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1059650031098257408",
  "text" : "From a deli, corned beef and swiss egg rolls. Great with mustard, great without #foodie #foodpics #foodiechats https:\/\/t.co\/gowbgbAT06",
  "id" : 1059650031098257408,
  "created_at" : "2018-11-06 03:33:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058885632393646080",
  "text" : "RT @TipsyBartender: Rice Krispies Shot Glasses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058730517795889152",
    "text" : "Rice Krispies Shot Glasses",
    "id" : 1058730517795889152,
    "created_at" : "2018-11-03 14:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1058885632393646080,
  "created_at" : "2018-11-04 00:56:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9gWLotZbGr",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/09\/ideas-in-food-gluten-free-fried-chicken-japanese.html",
      "display_url" : "seriouseats.com\/2015\/09\/ideas-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058885570221563905",
  "text" : "RT @seriouseats: Double-dredging is the key to extra-crisp Japanese fried chicken.\nhttps:\/\/t.co\/9gWLotZbGr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/9gWLotZbGr",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/09\/ideas-in-food-gluten-free-fried-chicken-japanese.html",
        "display_url" : "seriouseats.com\/2015\/09\/ideas-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058841247232618496",
    "text" : "Double-dredging is the key to extra-crisp Japanese fried chicken.\nhttps:\/\/t.co\/9gWLotZbGr",
    "id" : 1058841247232618496,
    "created_at" : "2018-11-03 22:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1058885570221563905,
  "created_at" : "2018-11-04 00:56:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melfistoyan",
      "screen_name" : "farmarrocan",
      "indices" : [ 3, 15 ],
      "id_str" : "4129934061",
      "id" : 4129934061
    }, {
      "name" : "tum1903",
      "screen_name" : "tum1903",
      "indices" : [ 17, 25 ],
      "id_str" : "1490802372",
      "id" : 1490802372
    }, {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 26, 33 ],
      "id_str" : "110396781",
      "id" : 110396781
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058885426730188800",
  "text" : "RT @farmarrocan: @tum1903 @ajplus @gamer456148 That's their original land, they're there since the patriarch of Alexandria, post Roman times",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tum1903",
        "screen_name" : "tum1903",
        "indices" : [ 0, 8 ],
        "id_str" : "1490802372",
        "id" : 1490802372
      }, {
        "name" : "AJ+",
        "screen_name" : "ajplus",
        "indices" : [ 9, 16 ],
        "id_str" : "110396781",
        "id" : 110396781
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 17, 29 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1058433923888414726",
    "geo" : { },
    "id_str" : "1058569890825682944",
    "in_reply_to_user_id" : 1490802372,
    "text" : "@tum1903 @ajplus @gamer456148 That's their original land, they're there since the patriarch of Alexandria, post Roman times",
    "id" : 1058569890825682944,
    "in_reply_to_status_id" : 1058433923888414726,
    "created_at" : "2018-11-03 04:01:43 +0000",
    "in_reply_to_screen_name" : "tum1903",
    "in_reply_to_user_id_str" : "1490802372",
    "user" : {
      "name" : "Melfistoyan",
      "screen_name" : "farmarrocan",
      "protected" : false,
      "id_str" : "4129934061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1029762680582799360\/krphKTDY_normal.jpg",
      "id" : 4129934061,
      "verified" : false
    }
  },
  "id" : 1058885426730188800,
  "created_at" : "2018-11-04 00:55:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/zxEDJyGF1I",
      "expanded_url" : "https:\/\/trib.al\/pG5rzAp",
      "display_url" : "trib.al\/pG5rzAp"
    } ]
  },
  "geo" : { },
  "id_str" : "1058885112669052929",
  "text" : "RT @epicurious: It\u2019s a Cuban sandwich, but dipped in an egg batter and fried. \nhttps:\/\/t.co\/zxEDJyGF1I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/zxEDJyGF1I",
        "expanded_url" : "https:\/\/trib.al\/pG5rzAp",
        "display_url" : "trib.al\/pG5rzAp"
      } ]
    },
    "geo" : { },
    "id_str" : "1058436852083032064",
    "text" : "It\u2019s a Cuban sandwich, but dipped in an egg batter and fried. \nhttps:\/\/t.co\/zxEDJyGF1I",
    "id" : 1058436852083032064,
    "created_at" : "2018-11-02 19:13:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058885112669052929,
  "created_at" : "2018-11-04 00:54:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058558884527386625",
  "text" : "RT @TheSharkDaymond: Once you make joy your biggest asset, you\u2019re way ahead of the game.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057576416349433856",
    "text" : "Once you make joy your biggest asset, you\u2019re way ahead of the game.",
    "id" : 1057576416349433856,
    "created_at" : "2018-10-31 10:14:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1058558884527386625,
  "created_at" : "2018-11-03 03:17:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/sM7lOl2kXz",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/put-image-list-item-css\/",
      "display_url" : "webdesigndev.com\/put-image-list\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058557966180335616",
  "text" : "RT @WebDesignDev: How to Put Your Image in List Item with CSS: https:\/\/t.co\/sM7lOl2kXz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/sM7lOl2kXz",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/put-image-list-item-css\/",
        "display_url" : "webdesigndev.com\/put-image-list\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058557154012135424",
    "text" : "How to Put Your Image in List Item with CSS: https:\/\/t.co\/sM7lOl2kXz",
    "id" : 1058557154012135424,
    "created_at" : "2018-11-03 03:11:07 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1058557966180335616,
  "created_at" : "2018-11-03 03:14:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/AIg3E3H7jz",
      "expanded_url" : "https:\/\/trib.al\/XmF8l43",
      "display_url" : "trib.al\/XmF8l43"
    } ]
  },
  "geo" : { },
  "id_str" : "1058537404326391814",
  "text" : "RT @epicurious: TGIF.\nhttps:\/\/t.co\/AIg3E3H7jz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/AIg3E3H7jz",
        "expanded_url" : "https:\/\/trib.al\/XmF8l43",
        "display_url" : "trib.al\/XmF8l43"
      } ]
    },
    "geo" : { },
    "id_str" : "1058527458461388801",
    "text" : "TGIF.\nhttps:\/\/t.co\/AIg3E3H7jz",
    "id" : 1058527458461388801,
    "created_at" : "2018-11-03 01:13:07 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058537404326391814,
  "created_at" : "2018-11-03 01:52:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/SKjFLr7p7c",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2017\/10\/the-best-kitchen-scales-equipment-review.html",
      "display_url" : "seriouseats.com\/2017\/10\/the-be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058537395304480768",
  "text" : "RT @seriouseats: If you think scales are just for pastry wizards, you are sorely mistaken. \nhttps:\/\/t.co\/SKjFLr7p7c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/SKjFLr7p7c",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2017\/10\/the-best-kitchen-scales-equipment-review.html",
        "display_url" : "seriouseats.com\/2017\/10\/the-be\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058524158433218560",
    "text" : "If you think scales are just for pastry wizards, you are sorely mistaken. \nhttps:\/\/t.co\/SKjFLr7p7c",
    "id" : 1058524158433218560,
    "created_at" : "2018-11-03 01:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1058537395304480768,
  "created_at" : "2018-11-03 01:52:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 5, 12 ]
    }, {
      "text" : "instafood",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "veggieeats",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/BcgkAPdgwD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bps006wljp3\/?utm_source=ig_twitter_share&igshid=1qx5a3vjypen8",
      "display_url" : "instagram.com\/p\/Bps006wljp3\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058537168501723139",
  "text" : "Nice #foodie #instafood #foodpics #veggieeats https:\/\/t.co\/BcgkAPdgwD",
  "id" : 1058537168501723139,
  "created_at" : "2018-11-03 01:51:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "indices" : [ 3, 14 ],
      "id_str" : "25170188",
      "id" : 25170188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/w3obclD4RR",
      "expanded_url" : "http:\/\/bonap.it\/eglOfUL",
      "display_url" : "bonap.it\/eglOfUL"
    } ]
  },
  "geo" : { },
  "id_str" : "1058521293828616192",
  "text" : "RT @bonappetit: This is our yam https:\/\/t.co\/w3obclD4RR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/w3obclD4RR",
        "expanded_url" : "http:\/\/bonap.it\/eglOfUL",
        "display_url" : "bonap.it\/eglOfUL"
      } ]
    },
    "geo" : { },
    "id_str" : "1058480885681606657",
    "text" : "This is our yam https:\/\/t.co\/w3obclD4RR",
    "id" : 1058480885681606657,
    "created_at" : "2018-11-02 22:08:03 +0000",
    "user" : {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "protected" : false,
      "id_str" : "25170188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308597170\/bon-appetit-twitter-icon_normal.jpg",
      "id" : 25170188,
      "verified" : true
    }
  },
  "id" : 1058521293828616192,
  "created_at" : "2018-11-03 00:48:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/450PVBQF7U",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/10-creative-about-me-pages\/",
      "display_url" : "webdesigndev.com\/10-creative-ab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058521022050254848",
  "text" : "RT @WebDesignDev: 10 Creative About Me Pages: https:\/\/t.co\/450PVBQF7U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/450PVBQF7U",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/10-creative-about-me-pages\/",
        "display_url" : "webdesigndev.com\/10-creative-ab\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058518230015328257",
    "text" : "10 Creative About Me Pages: https:\/\/t.co\/450PVBQF7U",
    "id" : 1058518230015328257,
    "created_at" : "2018-11-03 00:36:27 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1058521022050254848,
  "created_at" : "2018-11-03 00:47:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurel Pfahler",
      "screen_name" : "LaurelPfahler",
      "indices" : [ 3, 17 ],
      "id_str" : "809517912",
      "id" : 809517912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058520963007037446",
  "text" : "RT @LaurelPfahler: Fairfield 28, Milford 7, 11:39 left in 3Q: Hajiere Pitts took the kickoff return to the 1-yard line to set up Jeff Tyus'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Cassano",
        "screen_name" : "rickcassano",
        "indices" : [ 184, 196 ],
        "id_str" : "240936544",
        "id" : 240936544
      }, {
        "name" : "GMC Sports",
        "screen_name" : "gmcsports",
        "indices" : [ 197, 207 ],
        "id_str" : "35191980",
        "id" : 35191980
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058518403831529478",
    "text" : "Fairfield 28, Milford 7, 11:39 left in 3Q: Hajiere Pitts took the kickoff return to the 1-yard line to set up Jeff Tyus' 1-yard TD run (Phillips kick) on the only play from scrimmage. @rickcassano @gmcsports",
    "id" : 1058518403831529478,
    "created_at" : "2018-11-03 00:37:08 +0000",
    "user" : {
      "name" : "Laurel Pfahler",
      "screen_name" : "LaurelPfahler",
      "protected" : false,
      "id_str" : "809517912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557936793215975424\/mGaDQZQn_normal.jpeg",
      "id" : 809517912,
      "verified" : false
    }
  },
  "id" : 1058520963007037446,
  "created_at" : "2018-11-03 00:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058520305205952518",
  "text" : "RT @sparkfun: \"[The] Syndrum, a take on an Atari 2600 drum machine,\u00A0is nearly a work of art. It\u2019s a custom cartridge for the wood-paneled #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Atari",
        "indices" : [ 124, 130 ]
      }, {
        "text" : "DIY",
        "indices" : [ 217, 221 ]
      }, {
        "text" : "technology",
        "indices" : [ 222, 233 ]
      } ],
      "urls" : [ {
        "indices" : [ 234, 257 ],
        "url" : "https:\/\/t.co\/GxrmxtbXuC",
        "expanded_url" : "http:\/\/bit.ly\/2PZAnyl",
        "display_url" : "bit.ly\/2PZAnyl"
      } ]
    },
    "geo" : { },
    "id_str" : "1058405634465501191",
    "text" : "\"[The] Syndrum, a take on an Atari 2600 drum machine,\u00A0is nearly a work of art. It\u2019s a custom cartridge for the wood-paneled #Atari, and an impressive input device that turns this classic console into a beat machine.\" #DIY #technology https:\/\/t.co\/GxrmxtbXuC",
    "id" : 1058405634465501191,
    "created_at" : "2018-11-02 17:09:02 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 1058520305205952518,
  "created_at" : "2018-11-03 00:44:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/BAyasVpmkl",
      "expanded_url" : "https:\/\/makezine.com\/2018\/11\/01\/planning-and-building-your-own-custom-tool-wall\/",
      "display_url" : "makezine.com\/2018\/11\/01\/pla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058520210574061568",
  "text" : "RT @make: get serious with your tool organization https:\/\/t.co\/BAyasVpmkl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/BAyasVpmkl",
        "expanded_url" : "https:\/\/makezine.com\/2018\/11\/01\/planning-and-building-your-own-custom-tool-wall\/",
        "display_url" : "makezine.com\/2018\/11\/01\/pla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058102340975243264",
    "text" : "get serious with your tool organization https:\/\/t.co\/BAyasVpmkl",
    "id" : 1058102340975243264,
    "created_at" : "2018-11-01 21:03:51 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1058520210574061568,
  "created_at" : "2018-11-03 00:44:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/cQEZNJuFQe",
      "expanded_url" : "https:\/\/github.com\/EtherStone",
      "display_url" : "github.com\/EtherStone"
    } ]
  },
  "in_reply_to_status_id_str" : "1058456650397503488",
  "geo" : { },
  "id_str" : "1058519494698635270",
  "in_reply_to_user_id" : 210979938,
  "text" : "https:\/\/t.co\/cQEZNJuFQe",
  "id" : 1058519494698635270,
  "in_reply_to_status_id" : 1058456650397503488,
  "created_at" : "2018-11-03 00:41:28 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "indices" : [ 3, 15 ],
      "id_str" : "908383032767369216",
      "id" : 908383032767369216
    }, {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 67, 81 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "finalist",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "Furniture",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "Contest",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058461775065178114",
  "text" : "RT @shea_street: Exciting day! I just got word I am a #finalist in @instructables #Furniture #Contest 2018! Thanks for everyone who voted a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "instructables",
        "screen_name" : "instructables",
        "indices" : [ 50, 64 ],
        "id_str" : "7597362",
        "id" : 7597362
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "finalist",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "Furniture",
        "indices" : [ 65, 75 ]
      }, {
        "text" : "Contest",
        "indices" : [ 76, 84 ]
      }, {
        "text" : "finalists",
        "indices" : [ 246, 256 ]
      } ],
      "urls" : [ {
        "indices" : [ 257, 280 ],
        "url" : "https:\/\/t.co\/Z8wYvMky9t",
        "expanded_url" : "https:\/\/bit.ly\/2SE1xw9",
        "display_url" : "bit.ly\/2SE1xw9"
      } ]
    },
    "geo" : { },
    "id_str" : "1058449058128371715",
    "text" : "Exciting day! I just got word I am a #finalist in @instructables #Furniture #Contest 2018! Thanks for everyone who voted and took interest in the CARTIS but there where many other amazing projects in this event. Make sure to check out all of the #finalists https:\/\/t.co\/Z8wYvMky9t",
    "id" : 1058449058128371715,
    "created_at" : "2018-11-02 20:01:35 +0000",
    "user" : {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "protected" : false,
      "id_str" : "908383032767369216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908394866639589377\/KRY3inx7_normal.jpg",
      "id" : 908383032767369216,
      "verified" : false
    }
  },
  "id" : 1058461775065178114,
  "created_at" : "2018-11-02 20:52:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/8CLSl5SqHS",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-jquery-search-forms\/",
      "display_url" : "webdesigndev.com\/free-jquery-se\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058456776838914048",
  "text" : "RT @WebDesignDev: 20 Free jQuery Search Forms to Use on Your Website: https:\/\/t.co\/8CLSl5SqHS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/8CLSl5SqHS",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-jquery-search-forms\/",
        "display_url" : "webdesigndev.com\/free-jquery-se\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058452834495160321",
    "text" : "20 Free jQuery Search Forms to Use on Your Website: https:\/\/t.co\/8CLSl5SqHS",
    "id" : 1058452834495160321,
    "created_at" : "2018-11-02 20:16:35 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1058456776838914048,
  "created_at" : "2018-11-02 20:32:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/BlrrI5GeAH",
      "expanded_url" : "https:\/\/trib.al\/BzD9iBj",
      "display_url" : "trib.al\/BzD9iBj"
    } ]
  },
  "geo" : { },
  "id_str" : "1058456731334905859",
  "text" : "RT @epicurious: The prettiest pumpkin dish there ever was.\nhttps:\/\/t.co\/BlrrI5GeAH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/BlrrI5GeAH",
        "expanded_url" : "https:\/\/trib.al\/BzD9iBj",
        "display_url" : "trib.al\/BzD9iBj"
      } ]
    },
    "geo" : { },
    "id_str" : "1058451941452328961",
    "text" : "The prettiest pumpkin dish there ever was.\nhttps:\/\/t.co\/BlrrI5GeAH",
    "id" : 1058451941452328961,
    "created_at" : "2018-11-02 20:13:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058456731334905859,
  "created_at" : "2018-11-02 20:32:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/u7HukAR3sC",
      "expanded_url" : "https:\/\/makezine.com\/2018\/11\/02\/tips-of-the-week-soaking-out-rust-picking-an-arduino-wire-wrangling-reorganize-and-be-happy\/",
      "display_url" : "makezine.com\/2018\/11\/02\/tip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058456676297256960",
  "text" : "RT @make: this weeks tips column is abolishing rust and helping with tough decisions. https:\/\/t.co\/u7HukAR3sC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/u7HukAR3sC",
        "expanded_url" : "https:\/\/makezine.com\/2018\/11\/02\/tips-of-the-week-soaking-out-rust-picking-an-arduino-wire-wrangling-reorganize-and-be-happy\/",
        "display_url" : "makezine.com\/2018\/11\/02\/tip\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058449959522091010",
    "text" : "this weeks tips column is abolishing rust and helping with tough decisions. https:\/\/t.co\/u7HukAR3sC",
    "id" : 1058449959522091010,
    "created_at" : "2018-11-02 20:05:10 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1058456676297256960,
  "created_at" : "2018-11-02 20:31:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EtherStone",
      "screen_name" : "StoneEther",
      "indices" : [ 11, 22 ],
      "id_str" : "1019960278887403520",
      "id" : 1019960278887403520
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058456650397503488\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ujCA9FO7ZM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrBksdKUUAAvO1O.jpg",
      "id_str" : "1058456627336990720",
      "id" : 1058456627336990720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrBksdKUUAAvO1O.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 341
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 341
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 341
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 341
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ujCA9FO7ZM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/kMnfuSbmN7",
      "expanded_url" : "https:\/\/github.com\/Mentors4EDU\/HashStake",
      "display_url" : "github.com\/Mentors4EDU\/Ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058456650397503488",
  "text" : "HashStake, @StoneEther fitted for Ethereum Classic: https:\/\/t.co\/kMnfuSbmN7 https:\/\/t.co\/ujCA9FO7ZM",
  "id" : 1058456650397503488,
  "created_at" : "2018-11-02 20:31:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/5rAxKTv2AQ",
      "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-biofuel.html",
      "display_url" : "techxplore.com\/news\/2018-11-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058437085504385024",
  "text" : "RT @TechXplore_com: Biofuel from a container https:\/\/t.co\/5rAxKTv2AQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/5rAxKTv2AQ",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-11-biofuel.html",
        "display_url" : "techxplore.com\/news\/2018-11-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058395824894496768",
    "text" : "Biofuel from a container https:\/\/t.co\/5rAxKTv2AQ",
    "id" : 1058395824894496768,
    "created_at" : "2018-11-02 16:30:03 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1058437085504385024,
  "created_at" : "2018-11-02 19:14:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Hubbard",
      "screen_name" : "bml_khubbard",
      "indices" : [ 3, 16 ],
      "id_str" : "812829868895309824",
      "id" : 812829868895309824
    }, {
      "name" : "Victor Joukov",
      "screen_name" : "rivig",
      "indices" : [ 18, 24 ],
      "id_str" : "40095040",
      "id" : 40095040
    }, {
      "name" : "H\u20D6enning P\u20D6aul",
      "screen_name" : "hennichodernich",
      "indices" : [ 25, 41 ],
      "id_str" : "64996442",
      "id" : 64996442
    }, {
      "name" : "whitequark",
      "screen_name" : "whitequark",
      "indices" : [ 42, 53 ],
      "id_str" : "162337124",
      "id" : 162337124
    }, {
      "name" : "OSH Park",
      "screen_name" : "oshpark",
      "indices" : [ 122, 130 ],
      "id_str" : "243342953",
      "id" : 243342953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058436681156739073",
  "text" : "RT @bml_khubbard: @rivig @hennichodernich @whitequark I have an entire family that is OSH and available for purchase from @oshpark.  Just G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victor Joukov",
        "screen_name" : "rivig",
        "indices" : [ 0, 6 ],
        "id_str" : "40095040",
        "id" : 40095040
      }, {
        "name" : "H\u20D6enning P\u20D6aul",
        "screen_name" : "hennichodernich",
        "indices" : [ 7, 23 ],
        "id_str" : "64996442",
        "id" : 64996442
      }, {
        "name" : "whitequark",
        "screen_name" : "whitequark",
        "indices" : [ 24, 35 ],
        "id_str" : "162337124",
        "id" : 162337124
      }, {
        "name" : "OSH Park",
        "screen_name" : "oshpark",
        "indices" : [ 104, 112 ],
        "id_str" : "243342953",
        "id" : 243342953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 173, 196 ],
        "url" : "https:\/\/t.co\/o9sMpOBWCx",
        "expanded_url" : "https:\/\/blackmesalabs.wordpress.com\/2017\/12\/03\/bml-50mil-0-050-proto-boards-for-rapid-surface-mount-prototyping\/",
        "display_url" : "blackmesalabs.wordpress.com\/2017\/12\/03\/bml\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "1058017896138457088",
    "geo" : { },
    "id_str" : "1058018261801914369",
    "in_reply_to_user_id" : 40095040,
    "text" : "@rivig @hennichodernich @whitequark I have an entire family that is OSH and available for purchase from @oshpark.  Just Google on \"50mil proto boards\" or follow this link:  https:\/\/t.co\/o9sMpOBWCx",
    "id" : 1058018261801914369,
    "in_reply_to_status_id" : 1058017896138457088,
    "created_at" : "2018-11-01 15:29:45 +0000",
    "in_reply_to_screen_name" : "rivig",
    "in_reply_to_user_id_str" : "40095040",
    "user" : {
      "name" : "Kevin Hubbard",
      "screen_name" : "bml_khubbard",
      "protected" : false,
      "id_str" : "812829868895309824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813023610273079296\/nz_TeZqD_normal.jpg",
      "id" : 812829868895309824,
      "verified" : false
    }
  },
  "id" : 1058436681156739073,
  "created_at" : "2018-11-02 19:12:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eater",
      "screen_name" : "Eater",
      "indices" : [ 3, 9 ],
      "id_str" : "26329195",
      "id" : 26329195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MIhVdVJQfY",
      "expanded_url" : "https:\/\/bit.ly\/2AD7AKm",
      "display_url" : "bit.ly\/2AD7AKm"
    } ]
  },
  "geo" : { },
  "id_str" : "1058436288007860225",
  "text" : "RT @Eater: Take a look around David Chang\u2019s new spit-roasted meat stall in NYC https:\/\/t.co\/MIhVdVJQfY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/MIhVdVJQfY",
        "expanded_url" : "https:\/\/bit.ly\/2AD7AKm",
        "display_url" : "bit.ly\/2AD7AKm"
      } ]
    },
    "geo" : { },
    "id_str" : "1057682866824511491",
    "text" : "Take a look around David Chang\u2019s new spit-roasted meat stall in NYC https:\/\/t.co\/MIhVdVJQfY",
    "id" : 1057682866824511491,
    "created_at" : "2018-10-31 17:17:00 +0000",
    "user" : {
      "name" : "Eater",
      "screen_name" : "Eater",
      "protected" : false,
      "id_str" : "26329195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513845495882477568\/UDiDBo66_normal.png",
      "id" : 26329195,
      "verified" : true
    }
  },
  "id" : 1058436288007860225,
  "created_at" : "2018-11-02 19:10:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "indices" : [ 3, 16 ],
      "id_str" : "19407053",
      "id" : 19407053
    }, {
      "name" : "Hamlet \uD83C\uDDE9\uD83C\uDDF4",
      "screen_name" : "hamletbatista",
      "indices" : [ 106, 120 ],
      "id_str" : "9941892",
      "id" : 9941892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058435670363070464",
  "text" : "RT @Entrepreneur: Maintain Your Competitive Advantage by Focusing on Your Most Valuable Asset -- You | by @hamletbatista https:\/\/t.co\/WnkZx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hamlet \uD83C\uDDE9\uD83C\uDDF4",
        "screen_name" : "hamletbatista",
        "indices" : [ 88, 102 ],
        "id_str" : "9941892",
        "id" : 9941892
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/WnkZxw0412",
        "expanded_url" : "http:\/\/entm.ag\/k5t",
        "display_url" : "entm.ag\/k5t"
      } ]
    },
    "geo" : { },
    "id_str" : "1058427284233863170",
    "text" : "Maintain Your Competitive Advantage by Focusing on Your Most Valuable Asset -- You | by @hamletbatista https:\/\/t.co\/WnkZxw0412",
    "id" : 1058427284233863170,
    "created_at" : "2018-11-02 18:35:03 +0000",
    "user" : {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "protected" : false,
      "id_str" : "19407053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474753665970868224\/GcoCzmcI_normal.jpeg",
      "id" : 19407053,
      "verified" : true
    }
  },
  "id" : 1058435670363070464,
  "created_at" : "2018-11-02 19:08:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deadal Nix",
      "screen_name" : "deadalnix",
      "indices" : [ 3, 13 ],
      "id_str" : "112916339",
      "id" : 112916339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058435035357941760",
  "text" : "RT @deadalnix: Devcon has people from eth, zcoin, zcash, eff, internet archive, whole earth catalog, and so many more.\n\nThis industry is sm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058321713946128384",
    "text" : "Devcon has people from eth, zcoin, zcash, eff, internet archive, whole earth catalog, and so many more.\n\nThis industry is small. We all benefit more by growing the pie than fighting to get a bigger slice of a ridiculously small one.",
    "id" : 1058321713946128384,
    "created_at" : "2018-11-02 11:35:33 +0000",
    "user" : {
      "name" : "Deadal Nix",
      "screen_name" : "deadalnix",
      "protected" : false,
      "id_str" : "112916339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687782195\/146_normal.png",
      "id" : 112916339,
      "verified" : false
    }
  },
  "id" : 1058435035357941760,
  "created_at" : "2018-11-02 19:05:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kraken Exchange",
      "screen_name" : "krakenfx",
      "indices" : [ 3, 12 ],
      "id_str" : "1399148563",
      "id" : 1399148563
    }, {
      "name" : "Monero || #xmr",
      "screen_name" : "monero",
      "indices" : [ 39, 46 ],
      "id_str" : "2478439963",
      "id" : 2478439963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058434672101855233",
  "text" : "RT @krakenfx: We have just reduced the @monero XMR withdrawal fee to 0.00010.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monero || #xmr",
        "screen_name" : "monero",
        "indices" : [ 25, 32 ],
        "id_str" : "2478439963",
        "id" : 2478439963
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057097814012944384",
    "text" : "We have just reduced the @monero XMR withdrawal fee to 0.00010.",
    "id" : 1057097814012944384,
    "created_at" : "2018-10-30 02:32:13 +0000",
    "user" : {
      "name" : "Kraken Exchange",
      "screen_name" : "krakenfx",
      "protected" : false,
      "id_str" : "1399148563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781247043800997888\/1R1pdAKq_normal.jpg",
      "id" : 1399148563,
      "verified" : true
    }
  },
  "id" : 1058434672101855233,
  "created_at" : "2018-11-02 19:04:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoinDesk",
      "screen_name" : "coindesk",
      "indices" : [ 3, 12 ],
      "id_str" : "1333467482",
      "id" : 1333467482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058434558528573442",
  "text" : "RT @coindesk: BREAKING: Cryptocurrency exchange Bitstamp has been acquired by NXMH, an investment firm owned by South Korean conglomerate N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/2fyRsEczlN",
        "expanded_url" : "http:\/\/ow.ly\/5lZ330mpoPZ",
        "display_url" : "ow.ly\/5lZ330mpoPZ"
      } ]
    },
    "geo" : { },
    "id_str" : "1056848361884696576",
    "text" : "BREAKING: Cryptocurrency exchange Bitstamp has been acquired by NXMH, an investment firm owned by South Korean conglomerate NXC. https:\/\/t.co\/2fyRsEczlN",
    "id" : 1056848361884696576,
    "created_at" : "2018-10-29 10:00:59 +0000",
    "user" : {
      "name" : "CoinDesk",
      "screen_name" : "coindesk",
      "protected" : false,
      "id_str" : "1333467482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875399204218126339\/W3zmmuWz_normal.jpg",
      "id" : 1333467482,
      "verified" : true
    }
  },
  "id" : 1058434558528573442,
  "created_at" : "2018-11-02 19:03:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cointelegraph",
      "screen_name" : "Cointelegraph",
      "indices" : [ 3, 17 ],
      "id_str" : "2207129125",
      "id" : 2207129125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IzbgmlPlIQ",
      "expanded_url" : "https:\/\/cointelegraph.com\/news\/crypto-exchange-bitstamp-acquired-by-belgian-investment-firm-in-all-cash-deal",
      "display_url" : "cointelegraph.com\/news\/crypto-ex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058434504468164608",
  "text" : "RT @Cointelegraph: 80% stake in Bitstamp acquired by Belgian investment firm in \u201Call cash deal\u201D\nhttps:\/\/t.co\/IzbgmlPlIQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/amplifr.com\" rel=\"nofollow\"\u003EAmplifr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/IzbgmlPlIQ",
        "expanded_url" : "https:\/\/cointelegraph.com\/news\/crypto-exchange-bitstamp-acquired-by-belgian-investment-firm-in-all-cash-deal",
        "display_url" : "cointelegraph.com\/news\/crypto-ex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1056886081591959552",
    "text" : "80% stake in Bitstamp acquired by Belgian investment firm in \u201Call cash deal\u201D\nhttps:\/\/t.co\/IzbgmlPlIQ",
    "id" : 1056886081591959552,
    "created_at" : "2018-10-29 12:30:52 +0000",
    "user" : {
      "name" : "Cointelegraph",
      "screen_name" : "Cointelegraph",
      "protected" : false,
      "id_str" : "2207129125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922892062462226432\/9mNS0Jab_normal.jpg",
      "id" : 2207129125,
      "verified" : false
    }
  },
  "id" : 1058434504468164608,
  "created_at" : "2018-11-02 19:03:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FORTUNE",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "25053299",
      "id" : 25053299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Kxifh04sIw",
      "expanded_url" : "https:\/\/for.tn\/2DaRASE",
      "display_url" : "for.tn\/2DaRASE"
    } ]
  },
  "geo" : { },
  "id_str" : "1058434480946450432",
  "text" : "RT @FortuneMagazine: Bitcoin exchange Bitstamp acquired in latest cryptocurrency deal https:\/\/t.co\/Kxifh04sIw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/Kxifh04sIw",
        "expanded_url" : "https:\/\/for.tn\/2DaRASE",
        "display_url" : "for.tn\/2DaRASE"
      } ]
    },
    "geo" : { },
    "id_str" : "1056919875451568133",
    "text" : "Bitcoin exchange Bitstamp acquired in latest cryptocurrency deal https:\/\/t.co\/Kxifh04sIw",
    "id" : 1056919875451568133,
    "created_at" : "2018-10-29 14:45:09 +0000",
    "user" : {
      "name" : "FORTUNE",
      "screen_name" : "FortuneMagazine",
      "protected" : false,
      "id_str" : "25053299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875382047216467972\/3119VjuE_normal.jpg",
      "id" : 25053299,
      "verified" : true
    }
  },
  "id" : 1058434480946450432,
  "created_at" : "2018-11-02 19:03:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Phil Murphy",
      "screen_name" : "GovMurphy",
      "indices" : [ 3, 13 ],
      "id_str" : "948946378939609089",
      "id" : 948946378939609089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433963231010818",
  "text" : "RT @GovMurphy: Heartbroken by today's attack on Coptic Christians in Egypt. We stand with New Jersey's Coptic Christian community and with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 166, 189 ],
        "url" : "https:\/\/t.co\/b17k89gTtk",
        "expanded_url" : "https:\/\/twitter.com\/time\/status\/1058384505805914112",
        "display_url" : "twitter.com\/time\/status\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058427182438141959",
    "text" : "Heartbroken by today's attack on Coptic Christians in Egypt. We stand with New Jersey's Coptic Christian community and with the Egyptian people. Hate will never win. https:\/\/t.co\/b17k89gTtk",
    "id" : 1058427182438141959,
    "created_at" : "2018-11-02 18:34:39 +0000",
    "user" : {
      "name" : "Governor Phil Murphy",
      "screen_name" : "GovMurphy",
      "protected" : false,
      "id_str" : "948946378939609089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/951161235403190272\/4_vjPXRB_normal.jpg",
      "id" : 948946378939609089,
      "verified" : true
    }
  },
  "id" : 1058433963231010818,
  "created_at" : "2018-11-02 19:01:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AFP news agency",
      "screen_name" : "AFP",
      "indices" : [ 3, 7 ],
      "id_str" : "380648579",
      "id" : 380648579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UPDATE",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433911565492224",
  "text" : "RT @AFP: #UPDATE The Islamic State group claimed an attack by gunmen on a bus carrying Coptic Christians in central Egypt, killing seven in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UPDATE",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 176, 199 ],
        "url" : "https:\/\/t.co\/SNcZhUBIp3",
        "expanded_url" : "http:\/\/u.afp.com\/oKbQ",
        "display_url" : "u.afp.com\/oKbQ"
      } ]
    },
    "in_reply_to_status_id_str" : "1058409993140092928",
    "geo" : { },
    "id_str" : "1058430541744275457",
    "in_reply_to_user_id" : 380648579,
    "text" : "#UPDATE The Islamic State group claimed an attack by gunmen on a bus carrying Coptic Christians in central Egypt, killing seven in the latest assault on the religious minority https:\/\/t.co\/SNcZhUBIp3",
    "id" : 1058430541744275457,
    "in_reply_to_status_id" : 1058409993140092928,
    "created_at" : "2018-11-02 18:48:00 +0000",
    "in_reply_to_screen_name" : "AFP",
    "in_reply_to_user_id_str" : "380648579",
    "user" : {
      "name" : "AFP news agency",
      "screen_name" : "AFP",
      "protected" : false,
      "id_str" : "380648579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697343883630481408\/c08JBfBB_normal.jpg",
      "id" : 380648579,
      "verified" : true
    }
  },
  "id" : 1058433911565492224,
  "created_at" : "2018-11-02 19:01:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DW News",
      "screen_name" : "dwnews",
      "indices" : [ 3, 10 ],
      "id_str" : "6134882",
      "id" : 6134882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433853684150274",
  "text" : "RT @dwnews: The pilgrims were on their way to a monastery when their buses were fired on by suspected Islamist gunmen.\n\nhttps:\/\/t.co\/VUyhog\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/VUyhogAwD0",
        "expanded_url" : "https:\/\/www.dw.com\/en\/gunmen-kill-coptic-christians-on-pilgrimage-to-egypts-st-samuel-monastery\/a-46135832?maca=en-rss-en-all-1573-rdf",
        "display_url" : "dw.com\/en\/gunmen-kill\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058407306046697474",
    "text" : "The pilgrims were on their way to a monastery when their buses were fired on by suspected Islamist gunmen.\n\nhttps:\/\/t.co\/VUyhogAwD0",
    "id" : 1058407306046697474,
    "created_at" : "2018-11-02 17:15:40 +0000",
    "user" : {
      "name" : "DW News",
      "screen_name" : "dwnews",
      "protected" : false,
      "id_str" : "6134882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900261211509489666\/-1Fu5hU8_normal.jpg",
      "id" : 6134882,
      "verified" : true
    }
  },
  "id" : 1058433853684150274,
  "created_at" : "2018-11-02 19:01:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breaking911",
      "screen_name" : "Breaking911",
      "indices" : [ 3, 15 ],
      "id_str" : "375721095",
      "id" : 375721095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433736226885635",
  "text" : "RT @Breaking911: BREAKING: Egypt\u2019s Coptic Church says gunmen opened fire on bus carrying Christians south of Cairo killing at least 7 peopl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058357982340304897",
    "text" : "BREAKING: Egypt\u2019s Coptic Church says gunmen opened fire on bus carrying Christians south of Cairo killing at least 7 people. - AP",
    "id" : 1058357982340304897,
    "created_at" : "2018-11-02 13:59:40 +0000",
    "user" : {
      "name" : "Breaking911",
      "screen_name" : "Breaking911",
      "protected" : false,
      "id_str" : "375721095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619546088995979264\/KuG27bBK_normal.jpg",
      "id" : 375721095,
      "verified" : true
    }
  },
  "id" : 1058433736226885635,
  "created_at" : "2018-11-02 19:00:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "indices" : [ 3, 12 ],
      "id_str" : "742143",
      "id" : 742143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/4FjWYZos6l",
      "expanded_url" : "https:\/\/bbc.in\/2DjdV06",
      "display_url" : "bbc.in\/2DjdV06"
    } ]
  },
  "geo" : { },
  "id_str" : "1058433704375320576",
  "text" : "RT @BBCWorld: Egypt attack: Gunmen target bus with Coptic Christians https:\/\/t.co\/4FjWYZos6l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/4FjWYZos6l",
        "expanded_url" : "https:\/\/bbc.in\/2DjdV06",
        "display_url" : "bbc.in\/2DjdV06"
      } ]
    },
    "geo" : { },
    "id_str" : "1058380981747544064",
    "text" : "Egypt attack: Gunmen target bus with Coptic Christians https:\/\/t.co\/4FjWYZos6l",
    "id" : 1058380981747544064,
    "created_at" : "2018-11-02 15:31:04 +0000",
    "user" : {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "protected" : false,
      "id_str" : "742143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702138680246273\/BfQLzf7G_normal.jpg",
      "id" : 742143,
      "verified" : true
    }
  },
  "id" : 1058433704375320576,
  "created_at" : "2018-11-02 19:00:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 3, 10 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433610448076800",
  "text" : "RT @ajplus: Gunmen in Egypt killed at least 7 people, all Coptic Christians, in a bus headed toward a monastery. Another 14 people were wou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ajplus\/status\/1058387836594905088\/photo\/1",
        "indices" : [ 216, 239 ],
        "url" : "https:\/\/t.co\/8G0g0X5JnQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrAlHalUwAE3Yvq.jpg",
        "id_str" : "1058386721757249537",
        "id" : 1058386721757249537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrAlHalUwAE3Yvq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1392,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2784,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/8G0g0X5JnQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058387836594905088",
    "text" : "Gunmen in Egypt killed at least 7 people, all Coptic Christians, in a bus headed toward a monastery. Another 14 people were wounded. The attack took place close to where gunmen killed 28 Coptic Christians last year. https:\/\/t.co\/8G0g0X5JnQ",
    "id" : 1058387836594905088,
    "created_at" : "2018-11-02 15:58:18 +0000",
    "user" : {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "protected" : false,
      "id_str" : "110396781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1012020793348198401\/ohNwCtH9_normal.jpg",
      "id" : 110396781,
      "verified" : true
    }
  },
  "id" : 1058433610448076800,
  "created_at" : "2018-11-02 19:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aus Coptic Movement",
      "screen_name" : "auscma",
      "indices" : [ 0, 7 ],
      "id_str" : "243585349",
      "id" : 243585349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1058363010455003136",
  "geo" : { },
  "id_str" : "1058433600503365632",
  "in_reply_to_user_id" : 243585349,
  "text" : "@auscma So sad!",
  "id" : 1058433600503365632,
  "in_reply_to_status_id" : 1058363010455003136,
  "created_at" : "2018-11-02 19:00:09 +0000",
  "in_reply_to_screen_name" : "auscma",
  "in_reply_to_user_id_str" : "243585349",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433516411731968",
  "text" : "RT @CopticOrphans: We stand with our brothers and sisters in Egypt today, another day marred by tragedy. Our condolences to the martyrs\u2019 fa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 193, 216 ],
        "url" : "https:\/\/t.co\/spe9K1GOLD",
        "expanded_url" : "https:\/\/buff.ly\/2DiHPl5",
        "display_url" : "buff.ly\/2DiHPl5"
      } ]
    },
    "geo" : { },
    "id_str" : "1058370233830912005",
    "text" : "We stand with our brothers and sisters in Egypt today, another day marred by tragedy. Our condolences to the martyrs\u2019 families, and our prayers for peace and safety for every Copt everywhere.\n\nhttps:\/\/t.co\/spe9K1GOLD",
    "id" : 1058370233830912005,
    "created_at" : "2018-11-02 14:48:21 +0000",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 1058433516411731968,
  "created_at" : "2018-11-02 18:59:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433475777314818",
  "text" : "RT @ABC: At least seven people killed and more than 20 others injured in an attack on a bus carrying Coptic Christians to a monastery in Eg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/1058407406311522304\/photo\/1",
        "indices" : [ 159, 182 ],
        "url" : "https:\/\/t.co\/eOrXDgWct8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrA37TTX0AYJK10.jpg",
        "id_str" : "1058407404365402118",
        "id" : 1058407404365402118,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrA37TTX0AYJK10.jpg",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 992
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 992
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/eOrXDgWct8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/qRReyAgG33",
        "expanded_url" : "https:\/\/abcn.ws\/2Qbydvr",
        "display_url" : "abcn.ws\/2Qbydvr"
      } ]
    },
    "geo" : { },
    "id_str" : "1058407406311522304",
    "text" : "At least seven people killed and more than 20 others injured in an attack on a bus carrying Coptic Christians to a monastery in Egypt. https:\/\/t.co\/qRReyAgG33 https:\/\/t.co\/eOrXDgWct8",
    "id" : 1058407406311522304,
    "created_at" : "2018-11-02 17:16:04 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877547979363758080\/ny06RNTT_normal.jpg",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 1058433475777314818,
  "created_at" : "2018-11-02 18:59:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/OluZ0Qm6U9",
      "expanded_url" : "https:\/\/www.foxnews.com\/world\/islamic-attack-on-bus-carrying-coptic-christians-pilgrims-kills-at-least-7-in-egypt",
      "display_url" : "foxnews.com\/world\/islamic-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058433271917408258",
  "text" : "RT @FoxNews: Islamic attack against Coptic Christians pilgrims kills at least 7 in Egypt https:\/\/t.co\/OluZ0Qm6U9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/OluZ0Qm6U9",
        "expanded_url" : "https:\/\/www.foxnews.com\/world\/islamic-attack-on-bus-carrying-coptic-christians-pilgrims-kills-at-least-7-in-egypt",
        "display_url" : "foxnews.com\/world\/islamic-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058425840889929728",
    "text" : "Islamic attack against Coptic Christians pilgrims kills at least 7 in Egypt https:\/\/t.co\/OluZ0Qm6U9",
    "id" : 1058425840889929728,
    "created_at" : "2018-11-02 18:29:19 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 1058433271917408258,
  "created_at" : "2018-11-02 18:58:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Desert Fathers",
      "screen_name" : "desert__fathers",
      "indices" : [ 3, 19 ],
      "id_str" : "2762692036",
      "id" : 2762692036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433208470126593",
  "text" : "RT @desert__fathers: Today, at least 8 new Coptic martyrs shine brightly with the light of Christ,for a witness to the world for the conver\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/desert__fathers\/status\/1058431386829258752\/photo\/1",
        "indices" : [ 280, 303 ],
        "url" : "https:\/\/t.co\/On7YBnGba8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrBNu0iUwAAv-yJ.jpg",
        "id_str" : "1058431379203997696",
        "id" : 1058431379203997696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrBNu0iUwAAv-yJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 470
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/On7YBnGba8"
      } ],
      "hashtags" : [ {
        "text" : "isis",
        "indices" : [ 151, 156 ]
      }, {
        "text" : "Minya",
        "indices" : [ 266, 272 ]
      }, {
        "text" : "Egypt",
        "indices" : [ 273, 279 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058431386829258752",
    "text" : "Today, at least 8 new Coptic martyrs shine brightly with the light of Christ,for a witness to the world for the conversion of many.They were killed by #isis while on their way to visit St Samuel monastery.May they be ever remembered.May their memory be everlasting! #Minya #Egypt https:\/\/t.co\/On7YBnGba8",
    "id" : 1058431386829258752,
    "created_at" : "2018-11-02 18:51:21 +0000",
    "user" : {
      "name" : "Coptic Desert Fathers",
      "screen_name" : "desert__fathers",
      "protected" : false,
      "id_str" : "2762692036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510305109801455617\/NaHg24QA_normal.jpeg",
      "id" : 2762692036,
      "verified" : false
    }
  },
  "id" : 1058433208470126593,
  "created_at" : "2018-11-02 18:58:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058433113867599872",
  "text" : "RT @instructables: The most common reason an AC motor can fail is because of a toasted capacitor. Learn how to restore a 3-phase motor in t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FixItFriday",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 159, 182 ],
        "url" : "https:\/\/t.co\/n2NEV9ih0C",
        "expanded_url" : "http:\/\/bit.ly\/2D0VpZN",
        "display_url" : "bit.ly\/2D0VpZN"
      } ]
    },
    "geo" : { },
    "id_str" : "1058410935268921345",
    "text" : "The most common reason an AC motor can fail is because of a toasted capacitor. Learn how to restore a 3-phase motor in this helpful #FixItFriday Instructable! https:\/\/t.co\/n2NEV9ih0C",
    "id" : 1058410935268921345,
    "created_at" : "2018-11-02 17:30:05 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1058433113867599872,
  "created_at" : "2018-11-02 18:58:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breaking911",
      "screen_name" : "Breaking911",
      "indices" : [ 3, 15 ],
      "id_str" : "375721095",
      "id" : 375721095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058427390349791232",
  "text" : "RT @Breaking911: JUST IN: Alec Baldwin arrested for allegedly punching man in face in West Village, NYC parking spot fight - WNBC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058420910456213505",
    "text" : "JUST IN: Alec Baldwin arrested for allegedly punching man in face in West Village, NYC parking spot fight - WNBC",
    "id" : 1058420910456213505,
    "created_at" : "2018-11-02 18:09:44 +0000",
    "user" : {
      "name" : "Breaking911",
      "screen_name" : "Breaking911",
      "protected" : false,
      "id_str" : "375721095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619546088995979264\/KuG27bBK_normal.jpg",
      "id" : 375721095,
      "verified" : true
    }
  },
  "id" : 1058427390349791232,
  "created_at" : "2018-11-02 18:35:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GridcoinNetwork",
      "screen_name" : "GridcoinNetwork",
      "indices" : [ 3, 19 ],
      "id_str" : "2159897706",
      "id" : 2159897706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Fhf3omq1d8",
      "expanded_url" : "https:\/\/medium.com\/@gridcoinnetwork\/gridcoin-state-of-the-network-29-october-2018-d80f619d41cc",
      "display_url" : "medium.com\/@gridcoinnetwo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058408756365680641",
  "text" : "RT @GridcoinNetwork: Gridcoin State of the Network for October 29th. Happy crunching!\n\nhttps:\/\/t.co\/Fhf3omq1d8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Fhf3omq1d8",
        "expanded_url" : "https:\/\/medium.com\/@gridcoinnetwork\/gridcoin-state-of-the-network-29-october-2018-d80f619d41cc",
        "display_url" : "medium.com\/@gridcoinnetwo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1057011047129853952",
    "text" : "Gridcoin State of the Network for October 29th. Happy crunching!\n\nhttps:\/\/t.co\/Fhf3omq1d8",
    "id" : 1057011047129853952,
    "created_at" : "2018-10-29 20:47:26 +0000",
    "user" : {
      "name" : "GridcoinNetwork",
      "screen_name" : "GridcoinNetwork",
      "protected" : false,
      "id_str" : "2159897706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906628324360953856\/5TFApahe_normal.jpg",
      "id" : 2159897706,
      "verified" : false
    }
  },
  "id" : 1058408756365680641,
  "created_at" : "2018-11-02 17:21:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "indices" : [ 3, 16 ],
      "id_str" : "19407053",
      "id" : 19407053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058408511493849089",
  "text" : "RT @Entrepreneur: Apple earnings disappoint the market, but Verisign shares are soaring on a new deal with the government on internet domai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/Y7tdH3ewwr",
        "expanded_url" : "https:\/\/www.entrepreneur.com\/snapshot?tvwidgetsymbol=INDEX:ENTREPRENEUR",
        "display_url" : "entrepreneur.com\/snapshot?tvwid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058399140336558082",
    "text" : "Apple earnings disappoint the market, but Verisign shares are soaring on a new deal with the government on internet domain names. https:\/\/t.co\/Y7tdH3ewwr",
    "id" : 1058399140336558082,
    "created_at" : "2018-11-02 16:43:13 +0000",
    "user" : {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "protected" : false,
      "id_str" : "19407053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474753665970868224\/GcoCzmcI_normal.jpeg",
      "id" : 19407053,
      "verified" : true
    }
  },
  "id" : 1058408511493849089,
  "created_at" : "2018-11-02 17:20:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "indices" : [ 3, 15 ],
      "id_str" : "798906869582544896",
      "id" : 798906869582544896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "Blockchain",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "Cryptocurrency",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058405182831239168",
  "text" : "RT @SmartcoinFr: Le cours du #Bitcoin est de 5559.192039699999\u20AC\uD83C\uDDEA\uD83C\uDDFA  (6382.8285685$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smartcoin.fr\" rel=\"nofollow\"\u003EBitcoinPriceReal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Blockchain",
        "indices" : [ 68, 79 ]
      }, {
        "text" : "Cryptocurrency",
        "indices" : [ 80, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058326109715079174",
    "text" : "Le cours du #Bitcoin est de 5559.192039699999\u20AC\uD83C\uDDEA\uD83C\uDDFA  (6382.8285685$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
    "id" : 1058326109715079174,
    "created_at" : "2018-11-02 11:53:01 +0000",
    "user" : {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "protected" : false,
      "id_str" : "798906869582544896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911003345342599168\/Yu2M7_bQ_normal.jpg",
      "id" : 798906869582544896,
      "verified" : false
    }
  },
  "id" : 1058405182831239168,
  "created_at" : "2018-11-02 17:07:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058404854949920769",
  "text" : "RT @TipsyBartender: H-Bomb \uD83C\uDF4D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058393295884300288",
    "text" : "H-Bomb \uD83C\uDF4D",
    "id" : 1058393295884300288,
    "created_at" : "2018-11-02 16:20:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1058404854949920769,
  "created_at" : "2018-11-02 17:05:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058404802487554051\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/LTmPbOXGnO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DrA1jUDUUAApTzp.jpg",
      "id_str" : "1058404793226383360",
      "id" : 1058404793226383360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrA1jUDUUAApTzp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 465
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/LTmPbOXGnO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058404802487554051",
  "text" : "I like stacked charts... https:\/\/t.co\/LTmPbOXGnO",
  "id" : 1058404802487554051,
  "created_at" : "2018-11-02 17:05:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/EdBDoUK9wJ",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/15-top-free-ecommerce-themes-for-your-store\/",
      "display_url" : "webdesigndev.com\/15-top-free-ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058205866988593152",
  "text" : "RT @WebDesignDev: 20 Best Free Online Store Templates from Wix: https:\/\/t.co\/EdBDoUK9wJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/EdBDoUK9wJ",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/15-top-free-ecommerce-themes-for-your-store\/",
        "display_url" : "webdesigndev.com\/15-top-free-ec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058203829911601152",
    "text" : "20 Best Free Online Store Templates from Wix: https:\/\/t.co\/EdBDoUK9wJ",
    "id" : 1058203829911601152,
    "created_at" : "2018-11-02 03:47:08 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1058205866988593152,
  "created_at" : "2018-11-02 03:55:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 62, 67 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dawn",
      "indices" : [ 17, 22 ]
    }, {
      "text" : "mission",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/H7KvMlAIDF",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-11-dawn-mission-asteroid-belt.html",
      "display_url" : "phys.org\/news\/2018-11-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058188314677862400",
  "text" : "RT @physorg_com: #Dawn #mission to asteroid belt comes to end @NASA https:\/\/t.co\/H7KvMlAIDF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 45, 50 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dawn",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "mission",
        "indices" : [ 6, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/H7KvMlAIDF",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-11-dawn-mission-asteroid-belt.html",
        "display_url" : "phys.org\/news\/2018-11-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058051302159237120",
    "text" : "#Dawn #mission to asteroid belt comes to end @NASA https:\/\/t.co\/H7KvMlAIDF",
    "id" : 1058051302159237120,
    "created_at" : "2018-11-01 17:41:02 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1058188314677862400,
  "created_at" : "2018-11-02 02:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ArWSSa5IZ3",
      "expanded_url" : "https:\/\/trib.al\/rRIKSfv",
      "display_url" : "trib.al\/rRIKSfv"
    } ]
  },
  "geo" : { },
  "id_str" : "1058187753987411968",
  "text" : "RT @epicurious: Pumpkin Pie x Cheesecake F\/W 2018. \nhttps:\/\/t.co\/ArWSSa5IZ3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/ArWSSa5IZ3",
        "expanded_url" : "https:\/\/trib.al\/rRIKSfv",
        "display_url" : "trib.al\/rRIKSfv"
      } ]
    },
    "geo" : { },
    "id_str" : "1058179899712827394",
    "text" : "Pumpkin Pie x Cheesecake F\/W 2018. \nhttps:\/\/t.co\/ArWSSa5IZ3",
    "id" : 1058179899712827394,
    "created_at" : "2018-11-02 02:12:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058187753987411968,
  "created_at" : "2018-11-02 02:43:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Oqh6MlIjgT",
      "expanded_url" : "https:\/\/www.lightstalking.com\/wow-transform-your-photo-into-a-film-clip-using-adobe-movingstills\/",
      "display_url" : "lightstalking.com\/wow-transform-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058187429021126661",
  "text" : "RT @JayHoque: Wow! Transform Your Photo Into a Film Clip Using Adobe MovingStills!: https:\/\/t.co\/Oqh6MlIjgT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Oqh6MlIjgT",
        "expanded_url" : "https:\/\/www.lightstalking.com\/wow-transform-your-photo-into-a-film-clip-using-adobe-movingstills\/",
        "display_url" : "lightstalking.com\/wow-transform-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058185232942272512",
    "text" : "Wow! Transform Your Photo Into a Film Clip Using Adobe MovingStills!: https:\/\/t.co\/Oqh6MlIjgT",
    "id" : 1058185232942272512,
    "created_at" : "2018-11-02 02:33:14 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1058187429021126661,
  "created_at" : "2018-11-02 02:41:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "indices" : [ 3, 18 ],
      "id_str" : "1626294277",
      "id" : 1626294277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058187210346905606",
  "text" : "RT @spectatorindex: BREAKING: Brazil's president-elect says his country will move its embassy to Jerusalem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058091156024647680",
    "text" : "BREAKING: Brazil's president-elect says his country will move its embassy to Jerusalem",
    "id" : 1058091156024647680,
    "created_at" : "2018-11-01 20:19:24 +0000",
    "user" : {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "protected" : false,
      "id_str" : "1626294277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839067030904922112\/LH4xqz-d_normal.jpg",
      "id" : 1626294277,
      "verified" : false
    }
  },
  "id" : 1058187210346905606,
  "created_at" : "2018-11-02 02:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058187109255786496",
  "text" : "I create amazing things. I research amazing topics. It is what I do...",
  "id" : 1058187109255786496,
  "created_at" : "2018-11-02 02:40:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058158513787203584",
  "text" : "RT @instructables: Having a wave form generator on your work bench can be a helpful electronics testing tool - learn how to make your own u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "arduino",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/6wvp6Ho0GG",
        "expanded_url" : "http:\/\/bit.ly\/2EPhWuW",
        "display_url" : "bit.ly\/2EPhWuW"
      } ]
    },
    "geo" : { },
    "id_str" : "1058119243781337089",
    "text" : "Having a wave form generator on your work bench can be a helpful electronics testing tool - learn how to make your own using #arduino! https:\/\/t.co\/6wvp6Ho0GG",
    "id" : 1058119243781337089,
    "created_at" : "2018-11-01 22:11:01 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1058158513787203584,
  "created_at" : "2018-11-02 00:47:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/KCFqiWGkus",
      "expanded_url" : "https:\/\/trib.al\/JOHkmuZ",
      "display_url" : "trib.al\/JOHkmuZ"
    } ]
  },
  "geo" : { },
  "id_str" : "1058158389342203905",
  "text" : "RT @epicurious: Your cast-iron skillet is the key to perfect pizza.\nhttps:\/\/t.co\/KCFqiWGkus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/KCFqiWGkus",
        "expanded_url" : "https:\/\/trib.al\/JOHkmuZ",
        "display_url" : "trib.al\/JOHkmuZ"
      } ]
    },
    "geo" : { },
    "id_str" : "1058134609580490753",
    "text" : "Your cast-iron skillet is the key to perfect pizza.\nhttps:\/\/t.co\/KCFqiWGkus",
    "id" : 1058134609580490753,
    "created_at" : "2018-11-01 23:12:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058158389342203905,
  "created_at" : "2018-11-02 00:46:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058158342747705344",
  "text" : "RT @BarbaraCorcoran: \u00B7 You can\u2019t turn a failure around, but you can stay firmly in the game not feeling sorry for yourself. Opportunity is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058117792094998529",
    "text" : "\u00B7 You can\u2019t turn a failure around, but you can stay firmly in the game not feeling sorry for yourself. Opportunity is always right there within reach if you're smart enough to look for it.",
    "id" : 1058117792094998529,
    "created_at" : "2018-11-01 22:05:15 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1058158342747705344,
  "created_at" : "2018-11-02 00:46:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "instafood",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "meats",
      "indices" : [ 34, 40 ]
    }, {
      "text" : "wings",
      "indices" : [ 41, 47 ]
    }, {
      "text" : "carnivore",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/d2GKxRVIVk",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bpps5sLBHhr\/?utm_source=ig_twitter_share&igshid=1nxkz4ds4yw1d",
      "display_url" : "instagram.com\/p\/Bpps5sLBHhr\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058097528804179970",
  "text" : "Best diet ever #foodie #instafood #meats #wings #carnivore https:\/\/t.co\/d2GKxRVIVk",
  "id" : 1058097528804179970,
  "created_at" : "2018-11-01 20:44:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GameSpot",
      "screen_name" : "GameSpot",
      "indices" : [ 3, 12 ],
      "id_str" : "7157132",
      "id" : 7157132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmashBrosUltimate",
      "indices" : [ 38, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Znhmz5ERRK",
      "expanded_url" : "https:\/\/www.gamespot.com\/articles\/piranha-plant-is-a-free-super-smash-bros-ultimate-\/1100-6462933\/ftag=GSS-05-10aaa0b",
      "display_url" : "gamespot.com\/articles\/piran\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058083731704029184",
  "text" : "RT @GameSpot: Piranha Plant is a free #SmashBrosUltimate DLC character, here\u2019s how to get it https:\/\/t.co\/Znhmz5ERRK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmashBrosUltimate",
        "indices" : [ 24, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/Znhmz5ERRK",
        "expanded_url" : "https:\/\/www.gamespot.com\/articles\/piranha-plant-is-a-free-super-smash-bros-ultimate-\/1100-6462933\/ftag=GSS-05-10aaa0b",
        "display_url" : "gamespot.com\/articles\/piran\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "1058004887047413760",
    "geo" : { },
    "id_str" : "1058078370376732672",
    "in_reply_to_user_id" : 7157132,
    "text" : "Piranha Plant is a free #SmashBrosUltimate DLC character, here\u2019s how to get it https:\/\/t.co\/Znhmz5ERRK",
    "id" : 1058078370376732672,
    "in_reply_to_status_id" : 1058004887047413760,
    "created_at" : "2018-11-01 19:28:36 +0000",
    "in_reply_to_screen_name" : "GameSpot",
    "in_reply_to_user_id_str" : "7157132",
    "user" : {
      "name" : "GameSpot",
      "screen_name" : "GameSpot",
      "protected" : false,
      "id_str" : "7157132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692411160470118400\/E9crfJih_normal.png",
      "id" : 7157132,
      "verified" : true
    }
  },
  "id" : 1058083731704029184,
  "created_at" : "2018-11-01 19:49:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "indices" : [ 3, 7 ],
      "id_str" : "16896485",
      "id" : 16896485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/d0inQmDdv6",
      "expanded_url" : "http:\/\/on.inc.com\/zyeir9h",
      "display_url" : "on.inc.com\/zyeir9h"
    } ]
  },
  "geo" : { },
  "id_str" : "1058083292841476097",
  "text" : "RT @Inc: It\u2019s hard to think about retirement when you\u2019re focused on growing your business, but necessary https:\/\/t.co\/d0inQmDdv6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/d0inQmDdv6",
        "expanded_url" : "http:\/\/on.inc.com\/zyeir9h",
        "display_url" : "on.inc.com\/zyeir9h"
      } ]
    },
    "geo" : { },
    "id_str" : "1058082257871749125",
    "text" : "It\u2019s hard to think about retirement when you\u2019re focused on growing your business, but necessary https:\/\/t.co\/d0inQmDdv6",
    "id" : 1058082257871749125,
    "created_at" : "2018-11-01 19:44:03 +0000",
    "user" : {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "protected" : false,
      "id_str" : "16896485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794517026672967680\/M4bp9e6f_normal.jpg",
      "id" : 16896485,
      "verified" : true
    }
  },
  "id" : 1058083292841476097,
  "created_at" : "2018-11-01 19:48:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liquor.com",
      "screen_name" : "Liquor",
      "indices" : [ 3, 10 ],
      "id_str" : "65716459",
      "id" : 65716459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/0eOayD305K",
      "expanded_url" : "http:\/\/bit.ly\/2CUXp5q",
      "display_url" : "bit.ly\/2CUXp5q"
    } ]
  },
  "geo" : { },
  "id_str" : "1058082592447234048",
  "text" : "RT @Liquor: Classics You Should Know: Aperol Spritz https:\/\/t.co\/0eOayD305K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/trueanthem.com\/\" rel=\"nofollow\"\u003EtrueAnthem\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/0eOayD305K",
        "expanded_url" : "http:\/\/bit.ly\/2CUXp5q",
        "display_url" : "bit.ly\/2CUXp5q"
      } ]
    },
    "geo" : { },
    "id_str" : "1058033558038683650",
    "text" : "Classics You Should Know: Aperol Spritz https:\/\/t.co\/0eOayD305K",
    "id" : 1058033558038683650,
    "created_at" : "2018-11-01 16:30:32 +0000",
    "user" : {
      "name" : "Liquor.com",
      "screen_name" : "Liquor",
      "protected" : false,
      "id_str" : "65716459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593877808063062017\/H2Mluuci_normal.png",
      "id" : 65716459,
      "verified" : true
    }
  },
  "id" : 1058082592447234048,
  "created_at" : "2018-11-01 19:45:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/4Dy9cGyZl6",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/01\/flickr-free-account-photo-video-limits-pro-plan-smugmug\/",
      "display_url" : "engadget.com\/2018\/11\/01\/fli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058082399609896966",
  "text" : "RT @engadget: Flickr limits free plan to 1,000 photos or videos https:\/\/t.co\/4Dy9cGyZl6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/4Dy9cGyZl6",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/01\/flickr-free-account-photo-video-limits-pro-plan-smugmug\/",
        "display_url" : "engadget.com\/2018\/11\/01\/fli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058082264020647937",
    "text" : "Flickr limits free plan to 1,000 photos or videos https:\/\/t.co\/4Dy9cGyZl6",
    "id" : 1058082264020647937,
    "created_at" : "2018-11-01 19:44:04 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1058082399609896966,
  "created_at" : "2018-11-01 19:44:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Id8xgAgEJd",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/11\/01\/ms-optics-new-lightweight-sonnetar-73mm\/",
      "display_url" : "thephoblographer.com\/2018\/11\/01\/ms-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058082314884923393",
  "text" : "RT @JayHoque: MS Optics Develops New Lightweight Sonnetar 73mm Portrait Lens for Leica M-Mount: https:\/\/t.co\/Id8xgAgEJd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Id8xgAgEJd",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/11\/01\/ms-optics-new-lightweight-sonnetar-73mm\/",
        "display_url" : "thephoblographer.com\/2018\/11\/01\/ms-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058082131639971841",
    "text" : "MS Optics Develops New Lightweight Sonnetar 73mm Portrait Lens for Leica M-Mount: https:\/\/t.co\/Id8xgAgEJd",
    "id" : 1058082131639971841,
    "created_at" : "2018-11-01 19:43:33 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1058082314884923393,
  "created_at" : "2018-11-01 19:44:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "W. B. Yeats",
      "screen_name" : "Yeats_Quotes",
      "indices" : [ 3, 16 ],
      "id_str" : "435202527",
      "id" : 435202527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058082220043395072",
  "text" : "RT @Yeats_Quotes: Let's talk and grieve, For that's the sweetest music for sad souls.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745710428949385216",
    "text" : "Let's talk and grieve, For that's the sweetest music for sad souls.",
    "id" : 745710428949385216,
    "created_at" : "2016-06-22 20:09:55 +0000",
    "user" : {
      "name" : "W. B. Yeats",
      "screen_name" : "Yeats_Quotes",
      "protected" : false,
      "id_str" : "435202527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1823046124\/yeats1_normal.jpg",
      "id" : 435202527,
      "verified" : false
    }
  },
  "id" : 1058082220043395072,
  "created_at" : "2018-11-01 19:43:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Manzanares",
      "screen_name" : "qtz3003",
      "indices" : [ 3, 11 ],
      "id_str" : "811315954713915392",
      "id" : 811315954713915392
    }, {
      "name" : "The Teachers Guild",
      "screen_name" : "TeachersGuild",
      "indices" : [ 13, 27 ],
      "id_str" : "1129130894",
      "id" : 1129130894
    }, {
      "name" : "Paula Mitchell",
      "screen_name" : "Mitchellteach87",
      "indices" : [ 28, 44 ],
      "id_str" : "967263080282406913",
      "id" : 967263080282406913
    }, {
      "name" : "Digital Promise",
      "screen_name" : "DigitalPromise",
      "indices" : [ 45, 60 ],
      "id_str" : "373421465",
      "id" : 373421465
    }, {
      "name" : "Maker Ed",
      "screen_name" : "MakerEdOrg",
      "indices" : [ 61, 72 ],
      "id_str" : "581540879",
      "id" : 581540879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058081345333837824",
  "text" : "RT @qtz3003: @TeachersGuild @Mitchellteach87 @DigitalPromise @MakerEdOrg It is important that students are actively involved in their educa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Teachers Guild",
        "screen_name" : "TeachersGuild",
        "indices" : [ 0, 14 ],
        "id_str" : "1129130894",
        "id" : 1129130894
      }, {
        "name" : "Paula Mitchell",
        "screen_name" : "Mitchellteach87",
        "indices" : [ 15, 31 ],
        "id_str" : "967263080282406913",
        "id" : 967263080282406913
      }, {
        "name" : "Digital Promise",
        "screen_name" : "DigitalPromise",
        "indices" : [ 32, 47 ],
        "id_str" : "373421465",
        "id" : 373421465
      }, {
        "name" : "Maker Ed",
        "screen_name" : "MakerEdOrg",
        "indices" : [ 48, 59 ],
        "id_str" : "581540879",
        "id" : 581540879
      }, {
        "name" : "Molly Jameson",
        "screen_name" : "MollyJameson3",
        "indices" : [ 237, 251 ],
        "id_str" : "4776809298",
        "id" : 4776809298
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "educationalassessment",
        "indices" : [ 252, 274 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1053075222750871552",
    "geo" : { },
    "id_str" : "1055476691370274816",
    "in_reply_to_user_id" : 1129130894,
    "text" : "@TeachersGuild @Mitchellteach87 @DigitalPromise @MakerEdOrg It is important that students are actively involved in their education, which makes hands on learning so beneficial. All students should have the opportunity to learn this way. @MollyJameson3 #educationalassessment",
    "id" : 1055476691370274816,
    "in_reply_to_status_id" : 1053075222750871552,
    "created_at" : "2018-10-25 15:10:27 +0000",
    "in_reply_to_screen_name" : "TeachersGuild",
    "in_reply_to_user_id_str" : "1129130894",
    "user" : {
      "name" : "Amanda Manzanares",
      "screen_name" : "qtz3003",
      "protected" : false,
      "id_str" : "811315954713915392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1045316860890107905\/1GPqE_MB_normal.jpg",
      "id" : 811315954713915392,
      "verified" : false
    }
  },
  "id" : 1058081345333837824,
  "created_at" : "2018-11-01 19:40:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    }, {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 64, 73 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/lro5GXMkiG",
      "expanded_url" : "https:\/\/makezine.com\/2018\/10\/30\/prop-building-gets-easy-with-the-adafruit-prop-maker-featherwing\/",
      "display_url" : "makezine.com\/2018\/10\/30\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058081135429931010",
  "text" : "RT @make: add interactivity and sound to your props easily with @adafruit's new prop wing! https:\/\/t.co\/lro5GXMkiG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "adafruit industries",
        "screen_name" : "adafruit",
        "indices" : [ 54, 63 ],
        "id_str" : "20731304",
        "id" : 20731304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/lro5GXMkiG",
        "expanded_url" : "https:\/\/makezine.com\/2018\/10\/30\/prop-building-gets-easy-with-the-adafruit-prop-maker-featherwing\/",
        "display_url" : "makezine.com\/2018\/10\/30\/pro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1057360962766954497",
    "text" : "add interactivity and sound to your props easily with @adafruit's new prop wing! https:\/\/t.co\/lro5GXMkiG",
    "id" : 1057360962766954497,
    "created_at" : "2018-10-30 19:57:52 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1058081135429931010,
  "created_at" : "2018-11-01 19:39:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Thor",
      "screen_name" : "BradThor",
      "indices" : [ 3, 12 ],
      "id_str" : "20748745",
      "id" : 20748745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BradThor\/status\/1058052156627058688\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/hjxUbDCyJI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq70vG2XgAUMdtv.jpg",
      "id_str" : "1058052052608319493",
      "id" : 1058052052608319493,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq70vG2XgAUMdtv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hjxUbDCyJI"
    } ],
    "hashtags" : [ {
      "text" : "NationalAuthorsDay",
      "indices" : [ 20, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058081036918317056",
  "text" : "RT @BradThor: Happy #NationalAuthorsDay everyone!  To all of you aspiring writers out there - never forget: https:\/\/t.co\/hjxUbDCyJI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BradThor\/status\/1058052156627058688\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/hjxUbDCyJI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq70vG2XgAUMdtv.jpg",
        "id_str" : "1058052052608319493",
        "id" : 1058052052608319493,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq70vG2XgAUMdtv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 1392
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 1392
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hjxUbDCyJI"
      } ],
      "hashtags" : [ {
        "text" : "NationalAuthorsDay",
        "indices" : [ 6, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058052156627058688",
    "text" : "Happy #NationalAuthorsDay everyone!  To all of you aspiring writers out there - never forget: https:\/\/t.co\/hjxUbDCyJI",
    "id" : 1058052156627058688,
    "created_at" : "2018-11-01 17:44:26 +0000",
    "user" : {
      "name" : "Brad Thor",
      "screen_name" : "BradThor",
      "protected" : false,
      "id_str" : "20748745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1002612521424031744\/1pLnMghb_normal.jpg",
      "id" : 20748745,
      "verified" : true
    }
  },
  "id" : 1058081036918317056,
  "created_at" : "2018-11-01 19:39:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat Geo Photography",
      "screen_name" : "NatGeoPhotos",
      "indices" : [ 3, 16 ],
      "id_str" : "117662694",
      "id" : 117662694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/FXdwc0uRBt",
      "expanded_url" : "https:\/\/on.natgeo.com\/2CS40hb",
      "display_url" : "on.natgeo.com\/2CS40hb"
    } ]
  },
  "geo" : { },
  "id_str" : "1058080845863489536",
  "text" : "RT @NatGeoPhotos: Photo of the Day: Shake It Off https:\/\/t.co\/FXdwc0uRBt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.spredfast.com\/\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/FXdwc0uRBt",
        "expanded_url" : "https:\/\/on.natgeo.com\/2CS40hb",
        "display_url" : "on.natgeo.com\/2CS40hb"
      } ]
    },
    "geo" : { },
    "id_str" : "1057988316933615616",
    "text" : "Photo of the Day: Shake It Off https:\/\/t.co\/FXdwc0uRBt",
    "id" : 1057988316933615616,
    "created_at" : "2018-11-01 13:30:45 +0000",
    "user" : {
      "name" : "Nat Geo Photography",
      "screen_name" : "NatGeoPhotos",
      "protected" : false,
      "id_str" : "117662694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798176802325794816\/25mLqDKA_normal.jpg",
      "id" : 117662694,
      "verified" : true
    }
  },
  "id" : 1058080845863489536,
  "created_at" : "2018-11-01 19:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058080512139558914",
  "text" : "Our universe is mathematics...",
  "id" : 1058080512139558914,
  "created_at" : "2018-11-01 19:37:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/GGBEnRj0PP",
      "expanded_url" : "https:\/\/trib.al\/uhkZMxA",
      "display_url" : "trib.al\/uhkZMxA"
    } ]
  },
  "geo" : { },
  "id_str" : "1058079220205805568",
  "text" : "RT @epicurious: Post-trick-or-treat provisions. \nhttps:\/\/t.co\/GGBEnRj0PP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/GGBEnRj0PP",
        "expanded_url" : "https:\/\/trib.al\/uhkZMxA",
        "display_url" : "trib.al\/uhkZMxA"
      } ]
    },
    "geo" : { },
    "id_str" : "1057801672284610566",
    "text" : "Post-trick-or-treat provisions. \nhttps:\/\/t.co\/GGBEnRj0PP",
    "id" : 1057801672284610566,
    "created_at" : "2018-11-01 01:09:06 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058079220205805568,
  "created_at" : "2018-11-01 19:31:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Pham",
      "screen_name" : "_Kevin_Pham",
      "indices" : [ 3, 15 ],
      "id_str" : "2395318063",
      "id" : 2395318063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058078711952670721",
  "text" : "RT @_Kevin_Pham: Often times the oppressed become the oppressors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058067591976050688",
    "text" : "Often times the oppressed become the oppressors.",
    "id" : 1058067591976050688,
    "created_at" : "2018-11-01 18:45:46 +0000",
    "user" : {
      "name" : "Kevin Pham",
      "screen_name" : "_Kevin_Pham",
      "protected" : false,
      "id_str" : "2395318063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1058152052952522753\/_OxjQU_l_normal.jpg",
      "id" : 2395318063,
      "verified" : false
    }
  },
  "id" : 1058078711952670721,
  "created_at" : "2018-11-01 19:29:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter McCormack #FreeRoss",
      "screen_name" : "PeterMcCormack",
      "indices" : [ 3, 18 ],
      "id_str" : "893818632089763840",
      "id" : 893818632089763840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058078686770065408",
  "text" : "RT @PeterMcCormack: Things used by criminals:\n1. Bitcoin\n2. The internet\n3. Cars\n4. Mobile phones\n5. Banks\n6. Cash\n7. Water\n8. Air\n\nSave ev\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058057494809870336",
    "text" : "Things used by criminals:\n1. Bitcoin\n2. The internet\n3. Cars\n4. Mobile phones\n5. Banks\n6. Cash\n7. Water\n8. Air\n\nSave everyone.\nBan everything.",
    "id" : 1058057494809870336,
    "created_at" : "2018-11-01 18:05:39 +0000",
    "user" : {
      "name" : "Peter McCormack #FreeRoss",
      "screen_name" : "PeterMcCormack",
      "protected" : false,
      "id_str" : "893818632089763840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1000571799644659712\/HV4ndCLo_normal.jpg",
      "id" : 893818632089763840,
      "verified" : false
    }
  },
  "id" : 1058078686770065408,
  "created_at" : "2018-11-01 19:29:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u26A1\uFE0FMaestro\u26A1\uFE0F",
      "screen_name" : "ethereumweekly",
      "indices" : [ 3, 18 ],
      "id_str" : "866822872731398144",
      "id" : 866822872731398144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/L5X65u10H8",
      "expanded_url" : "https:\/\/twitter.com\/openbazaar\/status\/1058044776266821637",
      "display_url" : "twitter.com\/openbazaar\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058078355902394368",
  "text" : "RT @ethereumweekly: \uD83D\uDE02\uD83D\uDE02\uD83E\uDD23\uD83E\uDD23\uD83E\uDD23 https:\/\/t.co\/L5X65u10H8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/L5X65u10H8",
        "expanded_url" : "https:\/\/twitter.com\/openbazaar\/status\/1058044776266821637",
        "display_url" : "twitter.com\/openbazaar\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058048931748286464",
    "text" : "\uD83D\uDE02\uD83D\uDE02\uD83E\uDD23\uD83E\uDD23\uD83E\uDD23 https:\/\/t.co\/L5X65u10H8",
    "id" : 1058048931748286464,
    "created_at" : "2018-11-01 17:31:37 +0000",
    "user" : {
      "name" : "\u26A1\uFE0FMaestro\u26A1\uFE0F",
      "screen_name" : "ethereumweekly",
      "protected" : false,
      "id_str" : "866822872731398144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1025923682550595584\/0RBbG_3q_normal.jpg",
      "id" : 866822872731398144,
      "verified" : false
    }
  },
  "id" : 1058078355902394368,
  "created_at" : "2018-11-01 19:28:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058077764824248321\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/vGHL8Ataot",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Dq8MBL1X4AAcLvS.jpg",
      "id_str" : "1058077651951411200",
      "id" : 1058077651951411200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Dq8MBL1X4AAcLvS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 350
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/vGHL8Ataot"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058077764824248321",
  "text" : "Nice...\n.................\n............................ https:\/\/t.co\/vGHL8Ataot",
  "id" : 1058077764824248321,
  "created_at" : "2018-11-01 19:26:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058076482826878978",
  "text" : "RT @instructables: You have just over a month to enter our Optics Contest!  What DIY project will you post that uses a lens in its build? \uD83D\uDD0D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/KWCGRNzAe6",
        "expanded_url" : "http:\/\/bit.ly\/2QCks8R",
        "display_url" : "bit.ly\/2QCks8R"
      } ]
    },
    "geo" : { },
    "id_str" : "1058076220393512961",
    "text" : "You have just over a month to enter our Optics Contest!  What DIY project will you post that uses a lens in its build? \uD83D\uDD0D https:\/\/t.co\/KWCGRNzAe6",
    "id" : 1058076220393512961,
    "created_at" : "2018-11-01 19:20:03 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1058076482826878978,
  "created_at" : "2018-11-01 19:21:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058076249644511232\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/ukREipMgXK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq8KsIdXQAM_Rvc.jpg",
      "id_str" : "1058076190756519939",
      "id" : 1058076190756519939,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq8KsIdXQAM_Rvc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ukREipMgXK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058076249644511232",
  "text" : "I am bored.... https:\/\/t.co\/ukREipMgXK",
  "id" : 1058076249644511232,
  "created_at" : "2018-11-01 19:20:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/RIdWz9j6x3",
      "expanded_url" : "https:\/\/www.minds.com\/media\/904808826823811072",
      "display_url" : "minds.com\/media\/90480882\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058075627918639104",
  "text" : "https:\/\/t.co\/RIdWz9j6x3",
  "id" : 1058075627918639104,
  "created_at" : "2018-11-01 19:17:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/udWsK2JqkK",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/904810575434989568",
      "display_url" : "minds.com\/newsfeed\/90481\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058075487170424832",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/udWsK2JqkK",
  "id" : 1058075487170424832,
  "created_at" : "2018-11-01 19:17:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/uZvsYJpCXX",
      "expanded_url" : "https:\/\/nyti.ms\/2D2aM4H",
      "display_url" : "nyti.ms\/2D2aM4H"
    } ]
  },
  "geo" : { },
  "id_str" : "1058056029236330496",
  "text" : "RT @nytfood: A lemon cake unlike any other https:\/\/t.co\/uZvsYJpCXX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/uZvsYJpCXX",
        "expanded_url" : "https:\/\/nyti.ms\/2D2aM4H",
        "display_url" : "nyti.ms\/2D2aM4H"
      } ]
    },
    "geo" : { },
    "id_str" : "1055421691344625664",
    "text" : "A lemon cake unlike any other https:\/\/t.co\/uZvsYJpCXX",
    "id" : 1055421691344625664,
    "created_at" : "2018-10-25 11:31:54 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 1058056029236330496,
  "created_at" : "2018-11-01 17:59:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058055260437184513",
  "text" : "RT @SpaceX: T-60 minutes until Falcon 9 launch of SAOCOM 1A. Launch webcast will go live about 15 minutes before liftoff \u2192 https:\/\/t.co\/gtC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/gtC39uBC7z",
        "expanded_url" : "http:\/\/spacex.com\/webcast",
        "display_url" : "spacex.com\/webcast"
      } ]
    },
    "geo" : { },
    "id_str" : "1049107569547997185",
    "text" : "T-60 minutes until Falcon 9 launch of SAOCOM 1A. Launch webcast will go live about 15 minutes before liftoff \u2192 https:\/\/t.co\/gtC39uBC7z",
    "id" : 1049107569547997185,
    "created_at" : "2018-10-08 01:21:50 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1058055260437184513,
  "created_at" : "2018-11-01 17:56:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058054618364686336",
  "text" : "RT @TipsyBartender: Wicked Worm Punch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057280966706683904",
    "text" : "Wicked Worm Punch",
    "id" : 1057280966706683904,
    "created_at" : "2018-10-30 14:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1058054618364686336,
  "created_at" : "2018-11-01 17:54:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WPExplorer",
      "screen_name" : "WPExplorer",
      "indices" : [ 3, 14 ],
      "id_str" : "83471831",
      "id" : 83471831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/CQzm6fz2Wr",
      "expanded_url" : "https:\/\/www.wpexplorer.com\/appointment-wordpress-plugins\/",
      "display_url" : "wpexplorer.com\/appointment-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058054222363660290",
  "text" : "RT @WPExplorer: Not sure which appointment booking plugin should you use on your #WordPress site? We can help. https:\/\/t.co\/CQzm6fz2Wr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/CQzm6fz2Wr",
        "expanded_url" : "https:\/\/www.wpexplorer.com\/appointment-wordpress-plugins\/",
        "display_url" : "wpexplorer.com\/appointment-wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1056976852932149249",
    "text" : "Not sure which appointment booking plugin should you use on your #WordPress site? We can help. https:\/\/t.co\/CQzm6fz2Wr",
    "id" : 1056976852932149249,
    "created_at" : "2018-10-29 18:31:34 +0000",
    "user" : {
      "name" : "WPExplorer",
      "screen_name" : "WPExplorer",
      "protected" : false,
      "id_str" : "83471831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/990742683474837504\/7rxjI_WI_normal.jpg",
      "id" : 83471831,
      "verified" : false
    }
  },
  "id" : 1058054222363660290,
  "created_at" : "2018-11-01 17:52:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WP Engine",
      "screen_name" : "wpengine",
      "indices" : [ 3, 12 ],
      "id_str" : "121880027",
      "id" : 121880027
    }, {
      "name" : "Google",
      "screen_name" : "Google",
      "indices" : [ 74, 81 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wpesummit",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058054108517728256",
  "text" : "RT @wpengine: \"Start looking at performance as a product\" -Scott Frieson, @google #wpesummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.salesforce.com\" rel=\"nofollow\"\u003ESalesforce - Social Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "Google",
        "indices" : [ 60, 67 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wpesummit",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058007659050348544",
    "text" : "\"Start looking at performance as a product\" -Scott Frieson, @google #wpesummit",
    "id" : 1058007659050348544,
    "created_at" : "2018-11-01 14:47:37 +0000",
    "user" : {
      "name" : "WP Engine",
      "screen_name" : "wpengine",
      "protected" : false,
      "id_str" : "121880027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875512018035331072\/T-bDcrEW_normal.jpg",
      "id" : 121880027,
      "verified" : true
    }
  },
  "id" : 1058054108517728256,
  "created_at" : "2018-11-01 17:52:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/SgekQViWCa",
      "expanded_url" : "https:\/\/wpbeg.in\/2v1eJB6",
      "display_url" : "wpbeg.in\/2v1eJB6"
    } ]
  },
  "geo" : { },
  "id_str" : "1058053976032247808",
  "text" : "RT @wpbeginner: How to Disable XML-RPC in #WordPress - https:\/\/t.co\/SgekQViWCa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/SgekQViWCa",
        "expanded_url" : "https:\/\/wpbeg.in\/2v1eJB6",
        "display_url" : "wpbeg.in\/2v1eJB6"
      } ]
    },
    "geo" : { },
    "id_str" : "1057822065032654848",
    "text" : "How to Disable XML-RPC in #WordPress - https:\/\/t.co\/SgekQViWCa",
    "id" : 1057822065032654848,
    "created_at" : "2018-11-01 02:30:08 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 1058053976032247808,
  "created_at" : "2018-11-01 17:51:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DesignerDepot\/status\/1057696232691417089\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/z9r6y7nnY7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq2xHjeW4AE7i_f.jpg",
      "id_str" : "1057696230841704449",
      "id" : 1057696230841704449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq2xHjeW4AE7i_f.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 1000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/z9r6y7nnY7"
    } ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 50, 53 ]
    }, {
      "text" : "SEO",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/pRVPsLMi0F",
      "expanded_url" : "http:\/\/depot.ly\/GurL30mrt4v",
      "display_url" : "depot.ly\/GurL30mrt4v"
    } ]
  },
  "geo" : { },
  "id_str" : "1058053797602308096",
  "text" : "RT @DesignerDepot: Understanding the link between #UX design and #SEO https:\/\/t.co\/pRVPsLMi0F https:\/\/t.co\/z9r6y7nnY7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DesignerDepot\/status\/1057696232691417089\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/z9r6y7nnY7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq2xHjeW4AE7i_f.jpg",
        "id_str" : "1057696230841704449",
        "id" : 1057696230841704449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq2xHjeW4AE7i_f.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 1000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/z9r6y7nnY7"
      } ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 31, 34 ]
      }, {
        "text" : "SEO",
        "indices" : [ 46, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/pRVPsLMi0F",
        "expanded_url" : "http:\/\/depot.ly\/GurL30mrt4v",
        "display_url" : "depot.ly\/GurL30mrt4v"
      } ]
    },
    "geo" : { },
    "id_str" : "1057696232691417089",
    "text" : "Understanding the link between #UX design and #SEO https:\/\/t.co\/pRVPsLMi0F https:\/\/t.co\/z9r6y7nnY7",
    "id" : 1057696232691417089,
    "created_at" : "2018-10-31 18:10:07 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938857270888112128\/fueDq6et_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 1058053797602308096,
  "created_at" : "2018-11-01 17:50:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cleveland Water Alliance",
      "screen_name" : "CLEH2OAlliance",
      "indices" : [ 3, 18 ],
      "id_str" : "749956992",
      "id" : 749956992
    }, {
      "name" : "Xylem Inc.",
      "screen_name" : "XylemInc",
      "indices" : [ 50, 59 ],
      "id_str" : "328818263",
      "id" : 328818263
    }, {
      "name" : "YSI Systems",
      "screen_name" : "YSI_Systems",
      "indices" : [ 64, 76 ],
      "id_str" : "115385965",
      "id" : 115385965
    }, {
      "name" : "NALMS",
      "screen_name" : "NALMStweets",
      "indices" : [ 80, 92 ],
      "id_str" : "1601413508",
      "id" : 1601413508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058053583478906881",
  "text" : "RT @CLEH2OAlliance: Great to see our friends from @XylemInc and @YSI_Systems at @NALMStweets in Cincinnati! We're all working to #solvewate\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xylem Inc.",
        "screen_name" : "XylemInc",
        "indices" : [ 30, 39 ],
        "id_str" : "328818263",
        "id" : 328818263
      }, {
        "name" : "YSI Systems",
        "screen_name" : "YSI_Systems",
        "indices" : [ 44, 56 ],
        "id_str" : "115385965",
        "id" : 115385965
      }, {
        "name" : "NALMS",
        "screen_name" : "NALMStweets",
        "indices" : [ 60, 72 ],
        "id_str" : "1601413508",
        "id" : 1601413508
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CLEH2OAlliance\/status\/1058039964871655424\/photo\/1",
        "indices" : [ 158, 181 ],
        "url" : "https:\/\/t.co\/LPO2vQKXyI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq7pvB7WwAADbzm.jpg",
        "id_str" : "1058039956659159040",
        "id" : 1058039956659159040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq7pvB7WwAADbzm.jpg",
        "sizes" : [ {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1080
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/LPO2vQKXyI"
      } ],
      "hashtags" : [ {
        "text" : "solvewater",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058039964871655424",
    "text" : "Great to see our friends from @XylemInc and @YSI_Systems at @NALMStweets in Cincinnati! We're all working to #solvewater in our lakes. Thanks for the swag ;) https:\/\/t.co\/LPO2vQKXyI",
    "id" : 1058039964871655424,
    "created_at" : "2018-11-01 16:55:59 +0000",
    "user" : {
      "name" : "Cleveland Water Alliance",
      "screen_name" : "CLEH2OAlliance",
      "protected" : false,
      "id_str" : "749956992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1057288237176242177\/OGawcKK2_normal.jpg",
      "id" : 749956992,
      "verified" : false
    }
  },
  "id" : 1058053583478906881,
  "created_at" : "2018-11-01 17:50:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OCTO",
      "screen_name" : "OCTODC",
      "indices" : [ 3, 10 ],
      "id_str" : "85450171",
      "id" : 85450171
    }, {
      "name" : "Mayor Muriel Bowser",
      "screen_name" : "MayorBowser",
      "indices" : [ 19, 31 ],
      "id_str" : "976542720",
      "id" : 976542720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058053379279204359",
  "text" : "RT @OCTODC: Thanks @MayorBowser ! Join us tomorrow at @weworklabs at M Street as we kick off this exciting event! RSVP now: https:\/\/t.co\/w6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Muriel Bowser",
        "screen_name" : "MayorBowser",
        "indices" : [ 7, 19 ],
        "id_str" : "976542720",
        "id" : 976542720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/w69hF7y8Ns",
        "expanded_url" : "http:\/\/gigabitdcx.splashthat.com",
        "display_url" : "gigabitdcx.splashthat.com"
      }, {
        "indices" : [ 189, 212 ],
        "url" : "https:\/\/t.co\/b9um1z355o",
        "expanded_url" : "https:\/\/twitter.com\/MayorBowser\/status\/1050563511095611392",
        "display_url" : "twitter.com\/MayorBowser\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1050738997335605249",
    "text" : "Thanks @MayorBowser ! Join us tomorrow at @weworklabs at M Street as we kick off this exciting event! RSVP now: https:\/\/t.co\/w69hF7y8Ns\n\uD83D\uDCC6 Sat. October 13\n\u23F0 10:30AM-12:30PM\n\uD83D\uDCCD 80 M STREET SE https:\/\/t.co\/b9um1z355o",
    "id" : 1050738997335605249,
    "created_at" : "2018-10-12 13:24:33 +0000",
    "user" : {
      "name" : "OCTO",
      "screen_name" : "OCTODC",
      "protected" : false,
      "id_str" : "85450171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1014156794392915968\/SVInWqNo_normal.jpg",
      "id" : 85450171,
      "verified" : true
    }
  },
  "id" : 1058053379279204359,
  "created_at" : "2018-11-01 17:49:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cathy Wicks",
      "screen_name" : "univcathy",
      "indices" : [ 3, 13 ],
      "id_str" : "46576999",
      "id" : 46576999
    }, {
      "name" : "BeagleBoard.org",
      "screen_name" : "beagleboardorg",
      "indices" : [ 73, 88 ],
      "id_str" : "110009988",
      "id" : 110009988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058053070901469184",
  "text" : "RT @univcathy: Educators and Students - this is a great opportunity from @beagleboardorg to build up your lab.  Deadline for applications i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BeagleBoard.org",
        "screen_name" : "beagleboardorg",
        "indices" : [ 58, 73 ],
        "id_str" : "110009988",
        "id" : 110009988
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "engineeringeducation",
        "indices" : [ 138, 159 ]
      }, {
        "text" : "STEMeducation",
        "indices" : [ 160, 174 ]
      }, {
        "text" : "STEM",
        "indices" : [ 175, 180 ]
      } ],
      "urls" : [ {
        "indices" : [ 181, 204 ],
        "url" : "https:\/\/t.co\/o74I8EUfEi",
        "expanded_url" : "https:\/\/twitter.com\/beagleboardorg\/status\/1042867063432335365",
        "display_url" : "twitter.com\/beagleboardorg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1050803992119242752",
    "text" : "Educators and Students - this is a great opportunity from @beagleboardorg to build up your lab.  Deadline for applications is coming up.  #engineeringeducation #STEMeducation #STEM https:\/\/t.co\/o74I8EUfEi",
    "id" : 1050803992119242752,
    "created_at" : "2018-10-12 17:42:49 +0000",
    "user" : {
      "name" : "Cathy Wicks",
      "screen_name" : "univcathy",
      "protected" : false,
      "id_str" : "46576999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912481952288010241\/1Ni-GbBe_normal.jpg",
      "id" : 46576999,
      "verified" : false
    }
  },
  "id" : 1058053070901469184,
  "created_at" : "2018-11-01 17:48:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058052185039220736",
  "text" : "RT @elonmusk: Also, you\u2019ll be able to drive it from your phone remotely like a big RC car if in line of sight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1057881371174035456",
    "geo" : { },
    "id_str" : "1057884071005569024",
    "in_reply_to_user_id" : 44196397,
    "text" : "Also, you\u2019ll be able to drive it from your phone remotely like a big RC car if in line of sight",
    "id" : 1057884071005569024,
    "in_reply_to_status_id" : 1057881371174035456,
    "created_at" : "2018-11-01 06:36:31 +0000",
    "in_reply_to_screen_name" : "elonmusk",
    "in_reply_to_user_id_str" : "44196397",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1058052185039220736,
  "created_at" : "2018-11-01 17:44:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/5SEVdSVI9l",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/01\/league-legends-world-championship-america-2021\/",
      "display_url" : "engadget.com\/2018\/11\/01\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058052005309177856",
  "text" : "RT @engadget: League of Legends World Championship returns to NA in 2021 https:\/\/t.co\/5SEVdSVI9l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/5SEVdSVI9l",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/11\/01\/league-legends-world-championship-america-2021\/",
        "display_url" : "engadget.com\/2018\/11\/01\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058050806925193216",
    "text" : "League of Legends World Championship returns to NA in 2021 https:\/\/t.co\/5SEVdSVI9l",
    "id" : 1058050806925193216,
    "created_at" : "2018-11-01 17:39:04 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1058052005309177856,
  "created_at" : "2018-11-01 17:43:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RJaFuPhxjk",
      "expanded_url" : "https:\/\/petapixel.com\/2018\/11\/01\/how-to-build-a-long-term-weatherproof-timelapse-rig\/",
      "display_url" : "petapixel.com\/2018\/11\/01\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058050815443787777",
  "text" : "RT @JayHoque: How to Build a DIY Long-Term Weatherproof Timelapse Rig: https:\/\/t.co\/RJaFuPhxjk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/RJaFuPhxjk",
        "expanded_url" : "https:\/\/petapixel.com\/2018\/11\/01\/how-to-build-a-long-term-weatherproof-timelapse-rig\/",
        "display_url" : "petapixel.com\/2018\/11\/01\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058050646811774976",
    "text" : "How to Build a DIY Long-Term Weatherproof Timelapse Rig: https:\/\/t.co\/RJaFuPhxjk",
    "id" : 1058050646811774976,
    "created_at" : "2018-11-01 17:38:26 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1058050815443787777,
  "created_at" : "2018-11-01 17:39:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    }, {
      "name" : "Ben Krasnow",
      "screen_name" : "BenKrasnow",
      "indices" : [ 55, 66 ],
      "id_str" : "551534612",
      "id" : 551534612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/rVff7N7MKS",
      "expanded_url" : "https:\/\/makezine.com\/2018\/10\/30\/making-plastic-pcbs-with-a-laser-cutter-and-chemicals\/",
      "display_url" : "makezine.com\/2018\/10\/30\/mak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058046965454376960",
  "text" : "RT @make: check out this clever pcb creation method by @BenKrasnow https:\/\/t.co\/rVff7N7MKS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Krasnow",
        "screen_name" : "BenKrasnow",
        "indices" : [ 45, 56 ],
        "id_str" : "551534612",
        "id" : 551534612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/rVff7N7MKS",
        "expanded_url" : "https:\/\/makezine.com\/2018\/10\/30\/making-plastic-pcbs-with-a-laser-cutter-and-chemicals\/",
        "display_url" : "makezine.com\/2018\/10\/30\/mak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1057374593395122176",
    "text" : "check out this clever pcb creation method by @BenKrasnow https:\/\/t.co\/rVff7N7MKS",
    "id" : 1057374593395122176,
    "created_at" : "2018-10-30 20:52:02 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1058046965454376960,
  "created_at" : "2018-11-01 17:23:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mionne",
      "screen_name" : "MiworldMiway7",
      "indices" : [ 3, 17 ],
      "id_str" : "204166599",
      "id" : 204166599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/TqLBgGlg9z",
      "expanded_url" : "https:\/\/ift.tt\/2PBPG2U",
      "display_url" : "ift.tt\/2PBPG2U"
    } ]
  },
  "geo" : { },
  "id_str" : "1058046254662512641",
  "text" : "RT @MiworldMiway7: NASA\u2019s Dawn Mission to Asteroid Belt Comes to End via NASA https:\/\/t.co\/TqLBgGlg9z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/TqLBgGlg9z",
        "expanded_url" : "https:\/\/ift.tt\/2PBPG2U",
        "display_url" : "ift.tt\/2PBPG2U"
      } ]
    },
    "geo" : { },
    "id_str" : "1058046143911858176",
    "text" : "NASA\u2019s Dawn Mission to Asteroid Belt Comes to End via NASA https:\/\/t.co\/TqLBgGlg9z",
    "id" : 1058046143911858176,
    "created_at" : "2018-11-01 17:20:32 +0000",
    "user" : {
      "name" : "Mionne",
      "screen_name" : "MiworldMiway7",
      "protected" : false,
      "id_str" : "204166599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1059366183236001793\/Ja9lWqyY_normal.jpg",
      "id" : 204166599,
      "verified" : false
    }
  },
  "id" : 1058046254662512641,
  "created_at" : "2018-11-01 17:20:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058045826000400385\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/qoHAP5frQp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq7vDMZXgAE-cUB.jpg",
      "id_str" : "1058045800624914433",
      "id" : 1058045800624914433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq7vDMZXgAE-cUB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1421
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1421
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qoHAP5frQp"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058045826000400385\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/qoHAP5frQp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq7vEKRW4AAWzEa.jpg",
      "id_str" : "1058045817234317312",
      "id" : 1058045817234317312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq7vEKRW4AAWzEa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 771
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qoHAP5frQp"
    } ],
    "hashtags" : [ {
      "text" : "trading",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "stocks",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "markets",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "finance",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058045826000400385",
  "text" : "Back at it again w\/ an Alibaba price analysis #trading #stocks #markets #finance https:\/\/t.co\/qoHAP5frQp",
  "id" : 1058045826000400385,
  "created_at" : "2018-11-01 17:19:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BABA",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/42kCyWgzmB",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BABA\/I5gUykex-Alibaba-2-Month-Target\/",
      "display_url" : "tradingview.com\/chart\/BABA\/I5g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058045516334825472",
  "text" : "Alibaba: 2 Month Target - #BABA chart https:\/\/t.co\/42kCyWgzmB",
  "id" : 1058045516334825472,
  "created_at" : "2018-11-01 17:18:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "computer",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "space",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/LX2xaQS3z1",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-11-super-computer-cloud-astronauts-space.html",
      "display_url" : "phys.org\/news\/2018-11-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058043958977314824",
  "text" : "RT @physorg_com: Super-#computer brings 'cloud' to astronauts in #space https:\/\/t.co\/LX2xaQS3z1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "computer",
        "indices" : [ 6, 15 ]
      }, {
        "text" : "space",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/LX2xaQS3z1",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-11-super-computer-cloud-astronauts-space.html",
        "display_url" : "phys.org\/news\/2018-11-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1058019227372793856",
    "text" : "Super-#computer brings 'cloud' to astronauts in #space https:\/\/t.co\/LX2xaQS3z1",
    "id" : 1058019227372793856,
    "created_at" : "2018-11-01 15:33:35 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1058043958977314824,
  "created_at" : "2018-11-01 17:11:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058043850772672512",
  "text" : "RT @BarbaraCorcoran: Write down the task or project you\u2019ve been procrastinating tonight and cross it off your list first thing tomorrow. Yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057960491883130881",
    "text" : "Write down the task or project you\u2019ve been procrastinating tonight and cross it off your list first thing tomorrow. You\u2019ll boost your personal confidence and feel like a million bucks.",
    "id" : 1057960491883130881,
    "created_at" : "2018-11-01 11:40:11 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1058043850772672512,
  "created_at" : "2018-11-01 17:11:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u1D05\u0280\u1D07\u1D21 \u1D21\u026As\u1D07 \uD83C\uDFA8",
      "screen_name" : "Dreweyes",
      "indices" : [ 3, 12 ],
      "id_str" : "30049467",
      "id" : 30049467
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Dreweyes\/status\/1057767107163815939\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/IOdnVU98xJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq3xjmcX4AAX3k4.jpg",
      "id_str" : "1057767081419202560",
      "id" : 1057767081419202560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq3xjmcX4AAX3k4.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/IOdnVU98xJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058043627052695552",
  "text" : "RT @Dreweyes: SCARY COSTUME https:\/\/t.co\/IOdnVU98xJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dreweyes\/status\/1057767107163815939\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/IOdnVU98xJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq3xjmcX4AAX3k4.jpg",
        "id_str" : "1057767081419202560",
        "id" : 1057767081419202560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq3xjmcX4AAX3k4.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/IOdnVU98xJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057767107163815939",
    "text" : "SCARY COSTUME https:\/\/t.co\/IOdnVU98xJ",
    "id" : 1057767107163815939,
    "created_at" : "2018-10-31 22:51:45 +0000",
    "user" : {
      "name" : "\u1D05\u0280\u1D07\u1D21 \u1D21\u026As\u1D07 \uD83C\uDFA8",
      "screen_name" : "Dreweyes",
      "protected" : false,
      "id_str" : "30049467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/973003732551168000\/64rSdqYw_normal.jpg",
      "id" : 30049467,
      "verified" : false
    }
  },
  "id" : 1058043627052695552,
  "created_at" : "2018-11-01 17:10:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/0Dtx3Jm56k",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/10-awesome-jquery-and-html5-audio-players\/",
      "display_url" : "webdesigndev.com\/10-awesome-jqu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058043561210449920",
  "text" : "RT @WebDesignDev: 10 Awesome jQuery and HTML5 Audio Players: https:\/\/t.co\/0Dtx3Jm56k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/0Dtx3Jm56k",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/10-awesome-jquery-and-html5-audio-players\/",
        "display_url" : "webdesigndev.com\/10-awesome-jqu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1057877479581511680",
    "text" : "10 Awesome jQuery and HTML5 Audio Players: https:\/\/t.co\/0Dtx3Jm56k",
    "id" : 1057877479581511680,
    "created_at" : "2018-11-01 06:10:20 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1058043561210449920,
  "created_at" : "2018-11-01 17:10:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "3511430425",
      "id" : 3511430425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058043548807892992",
  "text" : "RT @fermatslibrary: Quick proof that \u03C0\/\u221A2 is irrational\nIf \u03C0\/\u221A2=a\/b (rational), we could write \u03C0\u00B2b\u00B2-2a\u00B2=0. This would mean that \u03C0 is the ro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057977052924727296",
    "text" : "Quick proof that \u03C0\/\u221A2 is irrational\nIf \u03C0\/\u221A2=a\/b (rational), we could write \u03C0\u00B2b\u00B2-2a\u00B2=0. This would mean that \u03C0 is the root of the polynomial x\u00B2b\u00B2-2a\u00B2, which is not possible since \u03C0 is transcendental- is not the root of any non-zero polynomial equation with integer coefficients",
    "id" : 1057977052924727296,
    "created_at" : "2018-11-01 12:46:00 +0000",
    "user" : {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "protected" : false,
      "id_str" : "3511430425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641822497457860608\/zd6kUAag_normal.png",
      "id" : 3511430425,
      "verified" : false
    }
  },
  "id" : 1058043548807892992,
  "created_at" : "2018-11-01 17:10:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/6VVhLQ7BrN",
      "expanded_url" : "https:\/\/trib.al\/J8PKBI9",
      "display_url" : "trib.al\/J8PKBI9"
    } ]
  },
  "geo" : { },
  "id_str" : "1058043479807455232",
  "text" : "RT @epicurious: All hail the Instant Pot.  \nhttps:\/\/t.co\/6VVhLQ7BrN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/6VVhLQ7BrN",
        "expanded_url" : "https:\/\/trib.al\/J8PKBI9",
        "display_url" : "trib.al\/J8PKBI9"
      } ]
    },
    "geo" : { },
    "id_str" : "1058028755950751745",
    "text" : "All hail the Instant Pot.  \nhttps:\/\/t.co\/6VVhLQ7BrN",
    "id" : 1058028755950751745,
    "created_at" : "2018-11-01 16:11:27 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1058043479807455232,
  "created_at" : "2018-11-01 17:09:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Mr Bean",
      "screen_name" : "MrBean",
      "indices" : [ 13, 20 ],
      "id_str" : "158331222",
      "id" : 158331222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1057981894632054784",
  "geo" : { },
  "id_str" : "1058043361981014017",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze @MrBean Dreams do come true! LOL XD",
  "id" : 1058043361981014017,
  "in_reply_to_status_id" : 1057981894632054784,
  "created_at" : "2018-11-01 17:09:29 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Mr Bean",
      "screen_name" : "MrBean",
      "indices" : [ 73, 80 ],
      "id_str" : "158331222",
      "id" : 158331222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "furze",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058043299737600000",
  "text" : "RT @colin_furze: Today\u2019s youtube video is a build I\u2019ve made to celebrate @mrbean hitting his 10milion subscribers see you at 4pm gmt #furze\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mr Bean",
        "screen_name" : "MrBean",
        "indices" : [ 56, 63 ],
        "id_str" : "158331222",
        "id" : 158331222
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/1057981894632054784\/photo\/1",
        "indices" : [ 200, 223 ],
        "url" : "https:\/\/t.co\/E5Miz3NwM4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq607AEWoAA92iZ.jpg",
        "id_str" : "1057981888202186752",
        "id" : 1057981888202186752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq607AEWoAA92iZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1021,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1021,
          "resize" : "fit",
          "w" : 1500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/E5Miz3NwM4"
      } ],
      "hashtags" : [ {
        "text" : "furze",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "mrbean",
        "indices" : [ 123, 130 ]
      }, {
        "text" : "bean",
        "indices" : [ 131, 136 ]
      }, {
        "text" : "10million",
        "indices" : [ 137, 147 ]
      }, {
        "text" : "subscribe",
        "indices" : [ 148, 158 ]
      }, {
        "text" : "diamondplaybutton",
        "indices" : [ 159, 177 ]
      }, {
        "text" : "youtube",
        "indices" : [ 178, 186 ]
      }, {
        "text" : "video",
        "indices" : [ 187, 193 ]
      }, {
        "text" : "hype",
        "indices" : [ 194, 199 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1057981894632054784",
    "text" : "Today\u2019s youtube video is a build I\u2019ve made to celebrate @mrbean hitting his 10milion subscribers see you at 4pm gmt #furze #mrbean #bean #10million #subscribe #diamondplaybutton #youtube #video #hype https:\/\/t.co\/E5Miz3NwM4",
    "id" : 1057981894632054784,
    "created_at" : "2018-11-01 13:05:14 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 1058043299737600000,
  "created_at" : "2018-11-01 17:09:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058043220087762944",
  "text" : "RT @TipsyBartender: J\u00E4germeister Root Beer Float \uD83C\uDF52",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1058030908152991745",
    "text" : "J\u00E4germeister Root Beer Float \uD83C\uDF52",
    "id" : 1058030908152991745,
    "created_at" : "2018-11-01 16:20:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1058043220087762944,
  "created_at" : "2018-11-01 17:08:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1058043112268926976\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/OBMfimbJuD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq7sl3SXQAA5U3V.jpg",
      "id_str" : "1058043097718931456",
      "id" : 1058043097718931456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq7sl3SXQAA5U3V.jpg",
      "sizes" : [ {
        "h" : 1153,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2306,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/OBMfimbJuD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1058042450252648453",
  "geo" : { },
  "id_str" : "1058043112268926976",
  "in_reply_to_user_id" : 210979938,
  "text" : "Just nice... https:\/\/t.co\/OBMfimbJuD",
  "id" : 1058043112268926976,
  "in_reply_to_status_id" : 1058042450252648453,
  "created_at" : "2018-11-01 17:08:30 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/EqYZQfrJn8",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5485304-Dashboard-Help?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Dashboard%20Help&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5485304-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058042450252648453",
  "text" : "Dashboard Help by @gamer456148 https:\/\/t.co\/EqYZQfrJn8",
  "id" : 1058042450252648453,
  "created_at" : "2018-11-01 17:05:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "delicious",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "instafood",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/tYzlj5l7t5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BppN95ghZGF\/?utm_source=ig_twitter_share&igshid=1wl1sxrpwnes",
      "display_url" : "instagram.com\/p\/BppN95ghZGF\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058029846968877057",
  "text" : "The correct way to eat eggs #foodie #delicious #instafood https:\/\/t.co\/tYzlj5l7t5",
  "id" : 1058029846968877057,
  "created_at" : "2018-11-01 16:15:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]