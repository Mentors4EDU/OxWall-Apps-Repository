Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648970827359240192",
  "text" : "RT @colin_furze: No man can say truthfully say that they would not want to do this in there garden, or have this in the garden https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sky 1",
        "screen_name" : "sky1",
        "indices" : [ 134, 139 ],
        "id_str" : "36909344",
        "id" : 36909344
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/kD5yMoQPVt",
        "expanded_url" : "https:\/\/youtu.be\/8UKNajCgpEs",
        "display_url" : "youtu.be\/8UKNajCgpEs"
      } ]
    },
    "geo" : { },
    "id_str" : "644041543016415232",
    "text" : "No man can say truthfully say that they would not want to do this in there garden, or have this in the garden https:\/\/t.co\/kD5yMoQPVt @sky1",
    "id" : 644041543016415232,
    "created_at" : "2015-09-16 06:54:04 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 648970827359240192,
  "created_at" : "2015-09-29 21:21:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648970635377516545",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze You are like the real life Harold Allnut, but doesn't like to follow a guy in a bat costume who likes punching clowns",
  "id" : 648970635377516545,
  "created_at" : "2015-09-29 21:20:31 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Planet",
      "screen_name" : "dailyplanetshow",
      "indices" : [ 0, 16 ],
      "id_str" : "23767584",
      "id" : 23767584
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 17, 29 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646844318611865600",
  "geo" : { },
  "id_str" : "648969889768714240",
  "in_reply_to_user_id" : 23767584,
  "text" : "@dailyplanetshow @colin_furze My crazy invention, which one?",
  "id" : 648969889768714240,
  "in_reply_to_status_id" : 646844318611865600,
  "created_at" : "2015-09-29 21:17:33 +0000",
  "in_reply_to_screen_name" : "dailyplanetshow",
  "in_reply_to_user_id_str" : "23767584",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647478634660429824",
  "geo" : { },
  "id_str" : "648969651930558464",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Better have your YouTube channel on fire than you :P",
  "id" : 648969651930558464,
  "in_reply_to_status_id" : 647478634660429824,
  "created_at" : "2015-09-29 21:16:36 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 128, 136 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/FzqgSk5u6L",
      "expanded_url" : "https:\/\/youtu.be\/p1t7r3SKT2o",
      "display_url" : "youtu.be\/p1t7r3SKT2o"
    } ]
  },
  "geo" : { },
  "id_str" : "648969525262577665",
  "text" : "RT @colin_furze: Every mans dream right here! Apocalyptic BUNKER project part 3 - Making the Bunker https:\/\/t.co\/FzqgSk5u6L via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 111, 119 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/FzqgSk5u6L",
        "expanded_url" : "https:\/\/youtu.be\/p1t7r3SKT2o",
        "display_url" : "youtu.be\/p1t7r3SKT2o"
      } ]
    },
    "geo" : { },
    "id_str" : "648152409366265857",
    "text" : "Every mans dream right here! Apocalyptic BUNKER project part 3 - Making the Bunker https:\/\/t.co\/FzqgSk5u6L via @YouTube",
    "id" : 648152409366265857,
    "created_at" : "2015-09-27 15:09:11 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 648969525262577665,
  "created_at" : "2015-09-29 21:16:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ApocalypseSky1",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648969480605822977",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Can I borrow you for the apocalypse? Together we can beat the cyborg zombies #ApocalypseSky1",
  "id" : 648969480605822977,
  "created_at" : "2015-09-29 21:15:56 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ApocalypseSky1",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648969124836732928",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze I wonder how this bunker project will turn out, if it gets weaponized than you have a happy camper :) #ApocalypseSky1",
  "id" : 648969124836732928,
  "created_at" : "2015-09-29 21:14:31 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 0, 11 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648850909406081024",
  "geo" : { },
  "id_str" : "648851154554748928",
  "in_reply_to_user_id" : 74998076,
  "text" : "@Eniolasays Salvation, because it required God to lay down his life for us, nothing is as priceless as that or comes close",
  "id" : 648851154554748928,
  "in_reply_to_status_id" : 648850909406081024,
  "created_at" : "2015-09-29 13:25:44 +0000",
  "in_reply_to_screen_name" : "Eniolasays",
  "in_reply_to_user_id_str" : "74998076",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oluyinka Oyeniyi",
      "screen_name" : "Datzmenoni",
      "indices" : [ 0, 11 ],
      "id_str" : "177195399",
      "id" : 177195399
    }, {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 12, 23 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648850144868335616",
  "geo" : { },
  "id_str" : "648850758448873472",
  "in_reply_to_user_id" : 177195399,
  "text" : "@Datzmenoni @Eniolasays Goat meat, better yet lamb",
  "id" : 648850758448873472,
  "in_reply_to_status_id" : 648850144868335616,
  "created_at" : "2015-09-29 13:24:10 +0000",
  "in_reply_to_screen_name" : "Datzmenoni",
  "in_reply_to_user_id_str" : "177195399",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/PbvrbpvKRL",
      "expanded_url" : "https:\/\/twitter.com\/olinvard\/status\/648850350494064640",
      "display_url" : "twitter.com\/olinvard\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648850627204907008",
  "text" : "Some of us are also looking at the universe from a metaphysical perspective, point is? https:\/\/t.co\/PbvrbpvKRL",
  "id" : 648850627204907008,
  "created_at" : "2015-09-29 13:23:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 0, 11 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648850060072067074",
  "geo" : { },
  "id_str" : "648850315295522816",
  "in_reply_to_user_id" : 74998076,
  "text" : "@Eniolasays  Just flip them over \uD83D\uDE02",
  "id" : 648850315295522816,
  "in_reply_to_status_id" : 648850060072067074,
  "created_at" : "2015-09-29 13:22:24 +0000",
  "in_reply_to_screen_name" : "Eniolasays",
  "in_reply_to_user_id_str" : "74998076",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/648850063788220417\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hD65cHI4bM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQEtq_lU8AAZXvU.jpg",
      "id_str" : "648850037963812864",
      "id" : 648850037963812864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQEtq_lU8AAZXvU.jpg",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hD65cHI4bM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648850063788220417",
  "text" : "I took a selfie. Selfies are stupid. You are welcome Twitter world- http:\/\/t.co\/hD65cHI4bM",
  "id" : 648850063788220417,
  "created_at" : "2015-09-29 13:21:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common White Girl",
      "screen_name" : "girlposts",
      "indices" : [ 0, 10 ],
      "id_str" : "132774626",
      "id" : 132774626
    }, {
      "name" : "Lake Bender",
      "screen_name" : "LakeKBender",
      "indices" : [ 11, 23 ],
      "id_str" : "117906332",
      "id" : 117906332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648532707220307968",
  "geo" : { },
  "id_str" : "648604832425734144",
  "in_reply_to_user_id" : 132774626,
  "text" : "@girlposts @LakeKBender You watch too much TV missy",
  "id" : 648604832425734144,
  "in_reply_to_status_id" : 648532707220307968,
  "created_at" : "2015-09-28 21:06:57 +0000",
  "in_reply_to_screen_name" : "girlposts",
  "in_reply_to_user_id_str" : "132774626",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/BSbO8samh3",
      "expanded_url" : "http:\/\/wrd.cm\/1QIL29Z",
      "display_url" : "wrd.cm\/1QIL29Z"
    } ]
  },
  "geo" : { },
  "id_str" : "648604603236380672",
  "text" : "RT @WIRED: NASA discovers evidence for liquid water on Mars http:\/\/t.co\/BSbO8samh3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/BSbO8samh3",
        "expanded_url" : "http:\/\/wrd.cm\/1QIL29Z",
        "display_url" : "wrd.cm\/1QIL29Z"
      } ]
    },
    "geo" : { },
    "id_str" : "648513259117629440",
    "text" : "NASA discovers evidence for liquid water on Mars http:\/\/t.co\/BSbO8samh3",
    "id" : 648513259117629440,
    "created_at" : "2015-09-28 15:03:04 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 648604603236380672,
  "created_at" : "2015-09-28 21:06:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648604238554234882",
  "text" : "@josef_lokmani Look at my profile, lol",
  "id" : 648604238554234882,
  "created_at" : "2015-09-28 21:04:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648604175786491904",
  "text" : "Children are gifts from God. The laugh of a child is very precious because it reminds us of what we once were \uD83D\uDE00",
  "id" : 648604175786491904,
  "created_at" : "2015-09-28 21:04:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648482942302461952",
  "text" : "I feel like all I drink nowadays is caffeinated \uD83D\uDE13",
  "id" : 648482942302461952,
  "created_at" : "2015-09-28 13:02:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corey Fernandez",
      "screen_name" : "coreywolfgang",
      "indices" : [ 3, 17 ],
      "id_str" : "25213743",
      "id" : 25213743
    }, {
      "name" : "Justine Ezarik \u2615\uFE0F",
      "screen_name" : "ijustine",
      "indices" : [ 19, 28 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "648325554349936640",
  "text" : "RT @coreywolfgang: @ijustine 10\/10 IGN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justine Ezarik \u2615\uFE0F",
        "screen_name" : "ijustine",
        "indices" : [ 0, 9 ],
        "id_str" : "7846",
        "id" : 7846
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "648322889771565056",
    "geo" : { },
    "id_str" : "648322958583164928",
    "in_reply_to_user_id" : 7846,
    "text" : "@ijustine 10\/10 IGN",
    "id" : 648322958583164928,
    "in_reply_to_status_id" : 648322889771565056,
    "created_at" : "2015-09-28 02:26:53 +0000",
    "in_reply_to_screen_name" : "ijustine",
    "in_reply_to_user_id_str" : "7846",
    "user" : {
      "name" : "Corey Fernandez",
      "screen_name" : "coreywolfgang",
      "protected" : false,
      "id_str" : "25213743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794180222765539328\/HQxuI0i5_normal.jpg",
      "id" : 25213743,
      "verified" : false
    }
  },
  "id" : 648325554349936640,
  "created_at" : "2015-09-28 02:37:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \u2615\uFE0F",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/648324483246366721\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ptDuo8fs34",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP9PrW5UwAAiStD.jpg",
      "id_str" : "648324477663625216",
      "id" : 648324477663625216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP9PrW5UwAAiStD.jpg",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 488
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 488
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 488
      } ],
      "display_url" : "pic.twitter.com\/ptDuo8fs34"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648322889771565056",
  "geo" : { },
  "id_str" : "648324483246366721",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine Better than me, I think I took a picture of the wrong moon http:\/\/t.co\/ptDuo8fs34",
  "id" : 648324483246366721,
  "in_reply_to_status_id" : 648322889771565056,
  "created_at" : "2015-09-28 02:32:56 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/647837064042561537\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/K85gpmIRpK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP2UXgIUkAAxsKe.jpg",
      "id_str" : "647837052893958144",
      "id" : 647837052893958144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP2UXgIUkAAxsKe.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K85gpmIRpK"
    } ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647837064042561537",
  "text" : "Donut #selfie http:\/\/t.co\/K85gpmIRpK",
  "id" : 647837064042561537,
  "created_at" : "2015-09-26 18:16:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647811759923953664",
  "text" : "Most who agree with evolution, don't know Darwin was a Freemason",
  "id" : 647811759923953664,
  "created_at" : "2015-09-26 16:35:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VideoGamesFacts\/status\/458383441462325248\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/LawgYgbzlC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BlyBT7KIMAAXoBs.jpg",
      "id_str" : "458383441382617088",
      "id" : 458383441382617088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlyBT7KIMAAXoBs.jpg",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LawgYgbzlC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647779761935089664",
  "text" : "RT @BestGamezUp: http:\/\/t.co\/LawgYgbzlC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VideoGamesFacts\/status\/458383441462325248\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/LawgYgbzlC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BlyBT7KIMAAXoBs.jpg",
        "id_str" : "458383441382617088",
        "id" : 458383441382617088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BlyBT7KIMAAXoBs.jpg",
        "sizes" : [ {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LawgYgbzlC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647777759482281985",
    "text" : "http:\/\/t.co\/LawgYgbzlC",
    "id" : 647777759482281985,
    "created_at" : "2015-09-26 14:20:27 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 647779761935089664,
  "created_at" : "2015-09-26 14:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 0, 12 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647699778579615744",
  "geo" : { },
  "id_str" : "647779600706048000",
  "in_reply_to_user_id" : 2370179022,
  "text" : "@CouponTrump thanks for your shoutouts",
  "id" : 647779600706048000,
  "in_reply_to_status_id" : 647699778579615744,
  "created_at" : "2015-09-26 14:27:46 +0000",
  "in_reply_to_screen_name" : "CouponTrump",
  "in_reply_to_user_id_str" : "2370179022",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/647779457659310080\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/xzMFyD21IH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP1f-hVWwAIblAO.jpg",
      "id_str" : "647779449115688962",
      "id" : 647779449115688962,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP1f-hVWwAIblAO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 645,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/xzMFyD21IH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647779457659310080",
  "text" : "Some artwork http:\/\/t.co\/xzMFyD21IH",
  "id" : 647779457659310080,
  "created_at" : "2015-09-26 14:27:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Walker",
      "screen_name" : "ScottWalker",
      "indices" : [ 0, 12 ],
      "id_str" : "33750798",
      "id" : 33750798
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 61, 69 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647559274827132928",
  "in_reply_to_user_id" : 33750798,
  "text" : "@ScottWalker dropped out of the race, now we definitely need @tedcruz to stay",
  "id" : 647559274827132928,
  "created_at" : "2015-09-25 23:52:16 +0000",
  "in_reply_to_screen_name" : "ScottWalker",
  "in_reply_to_user_id_str" : "33750798",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/C503jdVJmd",
      "expanded_url" : "https:\/\/twitter.com\/josef_lokmani\/status\/647547700775395332",
      "display_url" : "twitter.com\/josef_lokmani\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647547826436722689",
  "text" : "Nope https:\/\/t.co\/C503jdVJmd",
  "id" : 647547826436722689,
  "created_at" : "2015-09-25 23:06:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647547737383247873",
  "text" : "@josef_lokmani haha, that is what you are studying, don't sweat it",
  "id" : 647547737383247873,
  "created_at" : "2015-09-25 23:06:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/647430820454637568\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/WHKyaJLqC9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPwi5MFWcAAfgwe.jpg",
      "id_str" : "647430812326064128",
      "id" : 647430812326064128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPwi5MFWcAAfgwe.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WHKyaJLqC9"
    } ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 46, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647430820454637568",
  "text" : "Had pulled pork nachos from the Grizz Cave at #OU, not doing that again, lol 2.9\/5 stars http:\/\/t.co\/WHKyaJLqC9",
  "id" : 647430820454637568,
  "created_at" : "2015-09-25 15:21:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u264D\uFE0F Babe.",
      "screen_name" : "LeeBonitax3",
      "indices" : [ 14, 26 ],
      "id_str" : "96185674",
      "id" : 96185674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644963223876333569",
  "geo" : { },
  "id_str" : "647395478808711168",
  "in_reply_to_user_id" : 2990999770,
  "text" : "@NoFilter_Jay @LeeBonitax3 Exodus reference perhaps?",
  "id" : 647395478808711168,
  "in_reply_to_status_id" : 644963223876333569,
  "created_at" : "2015-09-25 13:01:24 +0000",
  "in_reply_to_screen_name" : "lifewjohn",
  "in_reply_to_user_id_str" : "2990999770",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simmons",
      "screen_name" : "AverageBlackMan",
      "indices" : [ 3, 19 ],
      "id_str" : "722964112213307392",
      "id" : 722964112213307392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647395228714975232",
  "text" : "RT @AverageBlackMan: What if people prayed as much as they complained?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426141794146222080",
    "text" : "What if people prayed as much as they complained?",
    "id" : 426141794146222080,
    "created_at" : "2014-01-22 23:58:15 +0000",
    "user" : {
      "name" : "Alex Simmons",
      "screen_name" : "_AlexSimmons",
      "protected" : false,
      "id_str" : "76976987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843292013818757120\/YRQNoScv_normal.jpg",
      "id" : 76976987,
      "verified" : false
    }
  },
  "id" : 647395228714975232,
  "created_at" : "2015-09-25 13:00:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Look@MyPinnedTweet",
      "screen_name" : "MichaelRello",
      "indices" : [ 3, 16 ],
      "id_str" : "77080603",
      "id" : 77080603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647395204526403584",
  "text" : "RT @MichaelRello: Feel energized this morning. Let's get it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647392177144864768",
    "text" : "Feel energized this morning. Let's get it!",
    "id" : 647392177144864768,
    "created_at" : "2015-09-25 12:48:17 +0000",
    "user" : {
      "name" : "Look@MyPinnedTweet",
      "screen_name" : "MichaelRello",
      "protected" : false,
      "id_str" : "77080603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841999743127568386\/zxU1MzCe_normal.jpg",
      "id" : 77080603,
      "verified" : false
    }
  },
  "id" : 647395204526403584,
  "created_at" : "2015-09-25 13:00:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WiHL Silent H",
      "screen_name" : "ElevateMindz",
      "indices" : [ 3, 16 ],
      "id_str" : "53506003",
      "id" : 53506003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647395170833580032",
  "text" : "RT @ElevateMindz: Some people are going to love you no matter what you do. And some people will never love you no matter what you do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647392219511435264",
    "text" : "Some people are going to love you no matter what you do. And some people will never love you no matter what you do.",
    "id" : 647392219511435264,
    "created_at" : "2015-09-25 12:48:27 +0000",
    "user" : {
      "name" : "WiHL Silent H",
      "screen_name" : "ElevateMindz",
      "protected" : false,
      "id_str" : "53506003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814034117708972032\/84Vcu4P8_normal.jpg",
      "id" : 53506003,
      "verified" : false
    }
  },
  "id" : 647395170833580032,
  "created_at" : "2015-09-25 13:00:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WiHL Silent H",
      "screen_name" : "ElevateMindz",
      "indices" : [ 3, 16 ],
      "id_str" : "53506003",
      "id" : 53506003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647395053468581888",
  "text" : "RT @ElevateMindz: It doesn\u2019t matter if the glass is half empty or half full. Be thankful that you have a glass- and grateful that there\u2019s s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "647392700094808064",
    "text" : "It doesn\u2019t matter if the glass is half empty or half full. Be thankful that you have a glass- and grateful that there\u2019s something in it.",
    "id" : 647392700094808064,
    "created_at" : "2015-09-25 12:50:22 +0000",
    "user" : {
      "name" : "WiHL Silent H",
      "screen_name" : "ElevateMindz",
      "protected" : false,
      "id_str" : "53506003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814034117708972032\/84Vcu4P8_normal.jpg",
      "id" : 53506003,
      "verified" : false
    }
  },
  "id" : 647395053468581888,
  "created_at" : "2015-09-25 12:59:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647394634382053376",
  "text" : "y=mx+b; y-y1=m(x-x1), simple algebra, not that difficult",
  "id" : 647394634382053376,
  "created_at" : "2015-09-25 12:58:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Econ",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647394253723836417",
  "text" : "Set profit equal to zero to find the break even #Econ",
  "id" : 647394253723836417,
  "created_at" : "2015-09-25 12:56:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647393942653304832",
  "text" : "Revenue minus cost equal profit, that is simple Econ #ThisIsOU",
  "id" : 647393942653304832,
  "created_at" : "2015-09-25 12:55:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Joseph Volpe",
      "screen_name" : "jrvolpe",
      "indices" : [ 16, 24 ],
      "id_str" : "284908506",
      "id" : 284908506
    }, {
      "name" : "Oculus",
      "screen_name" : "oculus",
      "indices" : [ 36, 43 ],
      "id_str" : "714758552",
      "id" : 714758552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647393080723701760",
  "geo" : { },
  "id_str" : "647393372265676800",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @jrvolpe Yeah right @oculus",
  "id" : 647393372265676800,
  "in_reply_to_status_id" : 647393080723701760,
  "created_at" : "2015-09-25 12:53:02 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SimpleMath",
      "indices" : [ 73, 84 ]
    }, {
      "text" : "Standards",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647393244117123076",
  "text" : "Horizontal means y=; vertical means x=, come on I learned that years ago #SimpleMath #Standards",
  "id" : 647393244117123076,
  "created_at" : "2015-09-25 12:52:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647392889509687296",
  "text" : "% Profit= % C(x) in terms of upfront sales, wait what? #ThisIsOU",
  "id" : 647392889509687296,
  "created_at" : "2015-09-25 12:51:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsLife",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647378616167329792",
  "text" : "I am an honest man of God, at least I want to be :) #ThisIsLife",
  "id" : 647378616167329792,
  "created_at" : "2015-09-25 11:54:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Underdown",
      "screen_name" : "camunderdown",
      "indices" : [ 3, 16 ],
      "id_str" : "18236844",
      "id" : 18236844
    }, {
      "name" : "Google",
      "screen_name" : "Google",
      "indices" : [ 18, 25 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647206408346279936",
  "text" : "RT @camunderdown: @google Still no ability to upgrade legacy google apps. Your help documentation is completely off, and there's no way to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "Google",
        "indices" : [ 0, 7 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nice",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609010528493539328",
    "in_reply_to_user_id" : 20536157,
    "text" : "@google Still no ability to upgrade legacy google apps. Your help documentation is completely off, and there's no way to contact you. #nice",
    "id" : 609010528493539328,
    "created_at" : "2015-06-11 14:53:19 +0000",
    "in_reply_to_screen_name" : "Google",
    "in_reply_to_user_id_str" : "20536157",
    "user" : {
      "name" : "Cameron Underdown",
      "screen_name" : "camunderdown",
      "protected" : false,
      "id_str" : "18236844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444324529\/cam_twitter_normal.png",
      "id" : 18236844,
      "verified" : false
    }
  },
  "id" : 647206408346279936,
  "created_at" : "2015-09-25 00:30:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647144020376879105",
  "text" : "Although I feel like sometimes I have a breaking point, like I don't know what to say or do, I know God loves me and has a plan for me :)",
  "id" : 647144020376879105,
  "created_at" : "2015-09-24 20:22:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647097611455987713",
  "text" : "@josef_lokmani I try :(",
  "id" : 647097611455987713,
  "created_at" : "2015-09-24 17:17:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/647097228050452480\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/HGrQvjYekw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPrzfp0WEAA2kUv.jpg",
      "id_str" : "647097221607985152",
      "id" : 647097221607985152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPrzfp0WEAA2kUv.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HGrQvjYekw"
    } ],
    "hashtags" : [ {
      "text" : "notreally",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647097228050452480",
  "text" : "This was blended so well #notreally http:\/\/t.co\/HGrQvjYekw",
  "id" : 647097228050452480,
  "created_at" : "2015-09-24 17:16:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD40",
      "screen_name" : "vxntful",
      "indices" : [ 3, 11 ],
      "id_str" : "2777432150",
      "id" : 2777432150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646874231221972992",
  "text" : "RT @vxntful: Stay humble. Stay focused. Stay blessed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646873324765741056",
    "text" : "Stay humble. Stay focused. Stay blessed.",
    "id" : 646873324765741056,
    "created_at" : "2015-09-24 02:26:33 +0000",
    "user" : {
      "name" : "\uD83E\uDD40",
      "screen_name" : "vxntful",
      "protected" : false,
      "id_str" : "2777432150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844330382644465665\/vbftJOd3_normal.jpg",
      "id" : 2777432150,
      "verified" : false
    }
  },
  "id" : 646874231221972992,
  "created_at" : "2015-09-24 02:30:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646874095360049152",
  "text" : "Glory be to God in the highest, every time I suffer or am at a breaking point, I need to remember to always say Glory be to the savior",
  "id" : 646874095360049152,
  "created_at" : "2015-09-24 02:29:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLB Stat of the Day",
      "screen_name" : "MLBStatoftheDay",
      "indices" : [ 3, 19 ],
      "id_str" : "282154125",
      "id" : 282154125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646736784802582528",
  "text" : "RT @MLBStatoftheDay: From 1933 through 2014, Tom Seaver is only pitcher to make at least 15 post-ASG starts &amp; have an ERA as low as 1.10. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MLBStatoftheDay\/status\/646718173694181376\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/dqvuba1f3F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPmawFiUsAArt45.jpg",
        "id_str" : "646718172414914560",
        "id" : 646718172414914560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPmawFiUsAArt45.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dqvuba1f3F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "646718173694181376",
    "text" : "From 1933 through 2014, Tom Seaver is only pitcher to make at least 15 post-ASG starts &amp; have an ERA as low as 1.10. http:\/\/t.co\/dqvuba1f3F",
    "id" : 646718173694181376,
    "created_at" : "2015-09-23 16:10:02 +0000",
    "user" : {
      "name" : "MLB Stat of the Day",
      "screen_name" : "MLBStatoftheDay",
      "protected" : false,
      "id_str" : "282154125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459394568287297536\/S9cMa_Kq_normal.jpeg",
      "id" : 282154125,
      "verified" : true
    }
  },
  "id" : 646736784802582528,
  "created_at" : "2015-09-23 17:23:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "StudentProbs",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646736512856494080",
  "text" : "I try to act smooth, but than I continue talking.... #ThisIsOU #StudentProbs",
  "id" : 646736512856494080,
  "created_at" : "2015-09-23 17:22:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646719448653672449",
  "text" : "Some people have zero sense of humor or a non-conversationalist personality :( It is what it is, \uD83D\uDC4E\uD83C\uDFFC",
  "id" : 646719448653672449,
  "created_at" : "2015-09-23 16:15:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Mark R. Levin",
      "screen_name" : "marklevinshow",
      "indices" : [ 9, 23 ],
      "id_str" : "38495835",
      "id" : 38495835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646149271431962624",
  "geo" : { },
  "id_str" : "646357257102487552",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz @marklevinshow You guys are awesome :)",
  "id" : 646357257102487552,
  "in_reply_to_status_id" : 646149271431962624,
  "created_at" : "2015-09-22 16:15:53 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644502768166678528",
  "geo" : { },
  "id_str" : "646357089456009218",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz I hope :)",
  "id" : 646357089456009218,
  "in_reply_to_status_id" : 644502768166678528,
  "created_at" : "2015-09-22 16:15:13 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CruzCrew",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "CruzToVictory",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pK0UgKT1jb",
      "expanded_url" : "https:\/\/www.tedcruz.org\/donate\/?cid=FO0161",
      "display_url" : "tedcruz.org\/donate\/?cid=FO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646357056845389828",
  "text" : "RT @tedcruz: This is what I'll do if elected President. Help make it a reality: https:\/\/t.co\/pK0UgKT1jb #CruzCrew #CruzToVictory http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/644502768166678528\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/1tJJNxz75k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPG72isVAAEdHIL.png",
        "id_str" : "644502767390752769",
        "id" : 644502767390752769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPG72isVAAEdHIL.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1tJJNxz75k"
      } ],
      "hashtags" : [ {
        "text" : "CruzCrew",
        "indices" : [ 91, 100 ]
      }, {
        "text" : "CruzToVictory",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/pK0UgKT1jb",
        "expanded_url" : "https:\/\/www.tedcruz.org\/donate\/?cid=FO0161",
        "display_url" : "tedcruz.org\/donate\/?cid=FO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644502768166678528",
    "text" : "This is what I'll do if elected President. Help make it a reality: https:\/\/t.co\/pK0UgKT1jb #CruzCrew #CruzToVictory http:\/\/t.co\/1tJJNxz75k",
    "id" : 644502768166678528,
    "created_at" : "2015-09-17 13:26:48 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 646357056845389828,
  "created_at" : "2015-09-22 16:15:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOP",
      "screen_name" : "GOP",
      "indices" : [ 3, 7 ],
      "id_str" : "11134252",
      "id" : 11134252
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/646081486454718465\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/8Vv1AZb2RK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPdXsFOW8AEB1nx.png",
      "id_str" : "646081486379216897",
      "id" : 646081486379216897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPdXsFOW8AEB1nx.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8Vv1AZb2RK"
    } ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/dcljG66KMB",
      "expanded_url" : "http:\/\/gop.cm\/6019BKJ7W",
      "display_url" : "gop.cm\/6019BKJ7W"
    } ]
  },
  "geo" : { },
  "id_str" : "646356962284830721",
  "text" : "RT @GOP: SILENCE from the Obama Admin. http:\/\/t.co\/dcljG66KMB Retweet &amp; Sign to stop a nuclear #Iran. http:\/\/t.co\/8Vv1AZb2RK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/646081486454718465\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/8Vv1AZb2RK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPdXsFOW8AEB1nx.png",
        "id_str" : "646081486379216897",
        "id" : 646081486379216897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPdXsFOW8AEB1nx.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8Vv1AZb2RK"
      } ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 90, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/dcljG66KMB",
        "expanded_url" : "http:\/\/gop.cm\/6019BKJ7W",
        "display_url" : "gop.cm\/6019BKJ7W"
      } ]
    },
    "geo" : { },
    "id_str" : "646081486454718465",
    "text" : "SILENCE from the Obama Admin. http:\/\/t.co\/dcljG66KMB Retweet &amp; Sign to stop a nuclear #Iran. http:\/\/t.co\/8Vv1AZb2RK",
    "id" : 646081486454718465,
    "created_at" : "2015-09-21 22:00:04 +0000",
    "user" : {
      "name" : "GOP",
      "screen_name" : "GOP",
      "protected" : false,
      "id_str" : "11134252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843068737272119296\/DNuuPIbk_normal.jpg",
      "id" : 11134252,
      "verified" : true
    }
  },
  "id" : 646356962284830721,
  "created_at" : "2015-09-22 16:14:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOP",
      "screen_name" : "GOP",
      "indices" : [ 3, 7 ],
      "id_str" : "11134252",
      "id" : 11134252
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/646141873900417024\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/kn2I5q9S9b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPeOnFiWwAEx8UX.png",
      "id_str" : "646141873703272449",
      "id" : 646141873703272449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPeOnFiWwAEx8UX.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kn2I5q9S9b"
    } ],
    "hashtags" : [ {
      "text" : "KeystoneXL",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/cT0L4icnOa",
      "expanded_url" : "http:\/\/gop.cm\/6018BK3bY",
      "display_url" : "gop.cm\/6018BK3bY"
    } ]
  },
  "geo" : { },
  "id_str" : "646356918173331456",
  "text" : "RT @GOP: Hillary STILL has no position on #KeystoneXL. http:\/\/t.co\/cT0L4icnOa More reason not to trust her. http:\/\/t.co\/kn2I5q9S9b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/646141873900417024\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/kn2I5q9S9b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPeOnFiWwAEx8UX.png",
        "id_str" : "646141873703272449",
        "id" : 646141873703272449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPeOnFiWwAEx8UX.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kn2I5q9S9b"
      } ],
      "hashtags" : [ {
        "text" : "KeystoneXL",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/cT0L4icnOa",
        "expanded_url" : "http:\/\/gop.cm\/6018BK3bY",
        "display_url" : "gop.cm\/6018BK3bY"
      } ]
    },
    "geo" : { },
    "id_str" : "646141873900417024",
    "text" : "Hillary STILL has no position on #KeystoneXL. http:\/\/t.co\/cT0L4icnOa More reason not to trust her. http:\/\/t.co\/kn2I5q9S9b",
    "id" : 646141873900417024,
    "created_at" : "2015-09-22 02:00:02 +0000",
    "user" : {
      "name" : "GOP",
      "screen_name" : "GOP",
      "protected" : false,
      "id_str" : "11134252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843068737272119296\/DNuuPIbk_normal.jpg",
      "id" : 11134252,
      "verified" : true
    }
  },
  "id" : 646356918173331456,
  "created_at" : "2015-09-22 16:14:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOP",
      "screen_name" : "GOP",
      "indices" : [ 3, 7 ],
      "id_str" : "11134252",
      "id" : 11134252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "StopHillary",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/494QmRjozm",
      "expanded_url" : "http:\/\/gop.cm\/6010BKp40",
      "display_url" : "gop.cm\/6010BKp40"
    } ]
  },
  "geo" : { },
  "id_str" : "646356830420119552",
  "text" : "RT @GOP: We can't trust Hillary to fix the #ObamaCare problems she helped create. http:\/\/t.co\/494QmRjozm #StopHillary",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 34, 44 ]
      }, {
        "text" : "StopHillary",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/494QmRjozm",
        "expanded_url" : "http:\/\/gop.cm\/6010BKp40",
        "display_url" : "gop.cm\/6010BKp40"
      } ]
    },
    "geo" : { },
    "id_str" : "646349487686946816",
    "text" : "We can't trust Hillary to fix the #ObamaCare problems she helped create. http:\/\/t.co\/494QmRjozm #StopHillary",
    "id" : 646349487686946816,
    "created_at" : "2015-09-22 15:45:01 +0000",
    "user" : {
      "name" : "GOP",
      "screen_name" : "GOP",
      "protected" : false,
      "id_str" : "11134252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843068737272119296\/DNuuPIbk_normal.jpg",
      "id" : 11134252,
      "verified" : true
    }
  },
  "id" : 646356830420119552,
  "created_at" : "2015-09-22 16:14:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/646356766486302724\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MfjwBLqrFX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPhSDFLWwAAKdOw.jpg",
      "id_str" : "646356759410556928",
      "id" : 646356759410556928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPhSDFLWwAAKdOw.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MfjwBLqrFX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646356766486302724",
  "text" : "Me next to a Mustang made by my favorite car company :) Nearly $40k of ingenuity :P Still long before I get one ;) http:\/\/t.co\/MfjwBLqrFX",
  "id" : 646356766486302724,
  "created_at" : "2015-09-22 16:13:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/O0DWnjhrjp",
      "expanded_url" : "https:\/\/twitter.com\/askaaronlee\/status\/646023558687121408",
      "display_url" : "twitter.com\/askaaronlee\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646024249778524160",
  "text" : "To some extent that is true https:\/\/t.co\/O0DWnjhrjp",
  "id" : 646024249778524160,
  "created_at" : "2015-09-21 18:12:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646007248246976512",
  "geo" : { },
  "id_str" : "646007520767672320",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech Oh my goodness",
  "id" : 646007520767672320,
  "in_reply_to_status_id" : 646007248246976512,
  "created_at" : "2015-09-21 17:06:09 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "indices" : [ 0, 11 ],
      "id_str" : "36912323",
      "id" : 36912323
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 12, 18 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646002472524337152",
  "geo" : { },
  "id_str" : "646006865600585728",
  "in_reply_to_user_id" : 36912323,
  "text" : "@grattonboy @WIRED Attack, where!!!",
  "id" : 646006865600585728,
  "in_reply_to_status_id" : 646002472524337152,
  "created_at" : "2015-09-21 17:03:33 +0000",
  "in_reply_to_screen_name" : "grattonboy",
  "in_reply_to_user_id_str" : "36912323",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "indices" : [ 3, 14 ],
      "id_str" : "36912323",
      "id" : 36912323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/fprbJGK0nM",
      "expanded_url" : "http:\/\/ow.ly\/34g4YF",
      "display_url" : "ow.ly\/34g4YF"
    } ]
  },
  "geo" : { },
  "id_str" : "646006793798348800",
  "text" : "RT @grattonboy: Upgrade To iOS 9 To Avoid A Bluetooth iPhone Attack http:\/\/t.co\/fprbJGK0nM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/fprbJGK0nM",
        "expanded_url" : "http:\/\/ow.ly\/34g4YF",
        "display_url" : "ow.ly\/34g4YF"
      } ]
    },
    "geo" : { },
    "id_str" : "646002472524337152",
    "text" : "Upgrade To iOS 9 To Avoid A Bluetooth iPhone Attack http:\/\/t.co\/fprbJGK0nM",
    "id" : 646002472524337152,
    "created_at" : "2015-09-21 16:46:06 +0000",
    "user" : {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "protected" : false,
      "id_str" : "36912323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819521494371934208\/8cPchIQ-_normal.jpg",
      "id" : 36912323,
      "verified" : true
    }
  },
  "id" : 646006793798348800,
  "created_at" : "2015-09-21 17:03:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 0, 11 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646004712559497218",
  "geo" : { },
  "id_str" : "646006545554243585",
  "in_reply_to_user_id" : 74998076,
  "text" : "@Eniolasays Only the lost brainwashed sheep",
  "id" : 646006545554243585,
  "in_reply_to_status_id" : 646004712559497218,
  "created_at" : "2015-09-21 17:02:17 +0000",
  "in_reply_to_screen_name" : "Eniolasays",
  "in_reply_to_user_id_str" : "74998076",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 0, 14 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646002818143404036",
  "geo" : { },
  "id_str" : "646005712452231169",
  "in_reply_to_user_id" : 200751709,
  "text" : "@SexxAndBlunts Not until they put a ring on that finger, in all seriousness though, I can name better feelings",
  "id" : 646005712452231169,
  "in_reply_to_status_id" : 646002818143404036,
  "created_at" : "2015-09-21 16:58:58 +0000",
  "in_reply_to_screen_name" : "sexxandblunts",
  "in_reply_to_user_id_str" : "200751709",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645966529335533568",
  "text" : "If the economy was fair, everyone would pay an equal percentage and we would stop monopolizing the system to allow jobless cheaters",
  "id" : 645966529335533568,
  "created_at" : "2015-09-21 14:23:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645011396879495168",
  "text" : "@josef_lokmani haha, they are great",
  "id" : 645011396879495168,
  "created_at" : "2015-09-18 23:07:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644840159524061184",
  "geo" : { },
  "id_str" : "645011276880482304",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze @YouTube :P",
  "id" : 645011276880482304,
  "in_reply_to_status_id" : 644840159524061184,
  "created_at" : "2015-09-18 23:07:26 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/644919186955874304\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/MFcME91trH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPM2k62WcAApxmL.jpg",
      "id_str" : "644919179544522752",
      "id" : 644919179544522752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPM2k62WcAApxmL.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MFcME91trH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644919186955874304",
  "text" : "This is photographic evidence I need to diet http:\/\/t.co\/MFcME91trH",
  "id" : 644919186955874304,
  "created_at" : "2015-09-18 17:01:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "indices" : [ 3, 14 ],
      "id_str" : "836656141",
      "id" : 836656141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644873280957116416",
  "text" : "RT @TheJoyCamp: @VelvetLeague Nothing is off-limits. ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621164805387202560",
    "text" : "@VelvetLeague Nothing is off-limits. ;)",
    "id" : 621164805387202560,
    "created_at" : "2015-07-15 03:50:04 +0000",
    "user" : {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "protected" : false,
      "id_str" : "836656141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420722584498364416\/TLr800yk_normal.jpeg",
      "id" : 836656141,
      "verified" : false
    }
  },
  "id" : 644873280957116416,
  "created_at" : "2015-09-18 13:59:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Au Bon Pain",
      "screen_name" : "AuBonPain",
      "indices" : [ 0, 10 ],
      "id_str" : "62625416",
      "id" : 62625416
    }, {
      "name" : "Starbucks UK",
      "screen_name" : "StarbucksUK",
      "indices" : [ 23, 35 ],
      "id_str" : "369629233",
      "id" : 369629233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644872996629401601",
  "in_reply_to_user_id" : 62625416,
  "text" : "@AuBonPain Better than @StarbucksUK",
  "id" : 644872996629401601,
  "created_at" : "2015-09-18 13:57:58 +0000",
  "in_reply_to_screen_name" : "AuBonPain",
  "in_reply_to_user_id_str" : "62625416",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644863720057925632",
  "text" : "Just had one of those white cupcakes from an OU Pre-Law Society bake-sell, it was so good #ThisIsOU",
  "id" : 644863720057925632,
  "created_at" : "2015-09-18 13:21:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Havas Sports & Ent.",
      "screen_name" : "Havas_SE",
      "indices" : [ 0, 9 ],
      "id_str" : "74397115",
      "id" : 74397115
    }, {
      "name" : "Rugby World Cup",
      "screen_name" : "rugbyworldcup",
      "indices" : [ 10, 24 ],
      "id_str" : "55459700",
      "id" : 55459700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644852222594052096",
  "geo" : { },
  "id_str" : "644852891929444352",
  "in_reply_to_user_id" : 74397115,
  "text" : "@Havas_SE @rugbyworldcup Too much",
  "id" : 644852891929444352,
  "in_reply_to_status_id" : 644852222594052096,
  "created_at" : "2015-09-18 12:38:04 +0000",
  "in_reply_to_screen_name" : "Havas_SE",
  "in_reply_to_user_id_str" : "74397115",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/644852641198157824\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/6m0rBxIE47",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPL6DkMUEAA8qNe.jpg",
      "id_str" : "644852635829276672",
      "id" : 644852635829276672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPL6DkMUEAA8qNe.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/6m0rBxIE47"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644852641198157824",
  "text" : "Doesn't taste as good as Marley's coffee http:\/\/t.co\/6m0rBxIE47",
  "id" : 644852641198157824,
  "created_at" : "2015-09-18 12:37:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/644660798908956672\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Et6w7KmBbM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPJLkyfXAAASjIH.jpg",
      "id_str" : "644660792068079616",
      "id" : 644660792068079616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPJLkyfXAAASjIH.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Et6w7KmBbM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644660798908956672",
  "text" : "Tried some Foie Gras, definitely some rich flavor, better than Caviar http:\/\/t.co\/Et6w7KmBbM",
  "id" : 644660798908956672,
  "created_at" : "2015-09-17 23:54:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644555601079459840",
  "text" : "I am having fun on Campus #ThisIsOU",
  "id" : 644555601079459840,
  "created_at" : "2015-09-17 16:56:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/644555097192566784\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/NbYLFOSP7m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPHrcdfUEAAVUwn.jpg",
      "id_str" : "644555095875522560",
      "id" : 644555095875522560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPHrcdfUEAAVUwn.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NbYLFOSP7m"
    } ],
    "hashtags" : [ {
      "text" : "HappyConstitutionDay",
      "indices" : [ 78, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644555415695417344",
  "text" : "RT @tedcruz: As President, I'll defend the Constitution -- every single word! #HappyConstitutionDay http:\/\/t.co\/NbYLFOSP7m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/644555097192566784\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/NbYLFOSP7m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPHrcdfUEAAVUwn.jpg",
        "id_str" : "644555095875522560",
        "id" : 644555095875522560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPHrcdfUEAAVUwn.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NbYLFOSP7m"
      } ],
      "hashtags" : [ {
        "text" : "HappyConstitutionDay",
        "indices" : [ 65, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644555097192566784",
    "text" : "As President, I'll defend the Constitution -- every single word! #HappyConstitutionDay http:\/\/t.co\/NbYLFOSP7m",
    "id" : 644555097192566784,
    "created_at" : "2015-09-17 16:54:45 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 644555415695417344,
  "created_at" : "2015-09-17 16:56:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/644555216595976193\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/AbRpy9crln",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPHrjJXWwAAEcuO.jpg",
      "id_str" : "644555210732519424",
      "id" : 644555210732519424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPHrjJXWwAAEcuO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/AbRpy9crln"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644555216595976193",
  "text" : "The new IOS 9 got me confused, what is the difference? http:\/\/t.co\/AbRpy9crln",
  "id" : 644555216595976193,
  "created_at" : "2015-09-17 16:55:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "indices" : [ 0, 13 ],
      "id_str" : "43532936",
      "id" : 43532936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643913491242446848",
  "geo" : { },
  "id_str" : "643920997901578240",
  "in_reply_to_user_id" : 43532936,
  "text" : "@cohasset_kid IPhone but I do prefer Android",
  "id" : 643920997901578240,
  "in_reply_to_status_id" : 643913491242446848,
  "created_at" : "2015-09-15 22:55:04 +0000",
  "in_reply_to_screen_name" : "cohasset_kid",
  "in_reply_to_user_id_str" : "43532936",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643912344951738369",
  "text" : "Oh how days pass by, and you grow older and wiser",
  "id" : 643912344951738369,
  "created_at" : "2015-09-15 22:20:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643911725918593024",
  "text" : "RT @Fact: You can judge a lot about a person's character by what they laugh at.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.grabinbox.com\" rel=\"nofollow\"\u003EGrabInbox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643888642159611904",
    "text" : "You can judge a lot about a person's character by what they laugh at.",
    "id" : 643888642159611904,
    "created_at" : "2015-09-15 20:46:29 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 643911725918593024,
  "created_at" : "2015-09-15 22:18:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643911680649482240",
  "text" : "RT @Fact: The word \"listen\" has the same letters as the word \"silent\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.grabinbox.com\" rel=\"nofollow\"\u003EGrabInbox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643890391549243392",
    "text" : "The word \"listen\" has the same letters as the word \"silent\"",
    "id" : 643890391549243392,
    "created_at" : "2015-09-15 20:53:26 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 643911680649482240,
  "created_at" : "2015-09-15 22:18:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643911391179603968",
  "text" : "RT @Fact: Simply looking at a picture of a loved one can help relieve pain.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.grabinbox.com\" rel=\"nofollow\"\u003EGrabInbox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643910234679848960",
    "text" : "Simply looking at a picture of a loved one can help relieve pain.",
    "id" : 643910234679848960,
    "created_at" : "2015-09-15 22:12:17 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 643911391179603968,
  "created_at" : "2015-09-15 22:16:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/502954642805112832\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/FPnNQxHhBu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvralSvIYAARMcR.jpg",
      "id_str" : "502954642624765952",
      "id" : 502954642624765952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvralSvIYAARMcR.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/FPnNQxHhBu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643911053890428928",
  "text" : "RT @BestGamezUp: I appreicate this http:\/\/t.co\/FPnNQxHhBu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/502954642805112832\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/FPnNQxHhBu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvralSvIYAARMcR.jpg",
        "id_str" : "502954642624765952",
        "id" : 502954642624765952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvralSvIYAARMcR.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/FPnNQxHhBu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643909752104316928",
    "text" : "I appreicate this http:\/\/t.co\/FPnNQxHhBu",
    "id" : 643909752104316928,
    "created_at" : "2015-09-15 22:10:22 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 643911053890428928,
  "created_at" : "2015-09-15 22:15:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643910483720863744\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/1vQuMKho5G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO-hLFeVEAAPck0.jpg",
      "id_str" : "643910483557289984",
      "id" : 643910483557289984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO-hLFeVEAAPck0.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1vQuMKho5G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643910483720863744",
  "text" : "These are my 5 favorite business and editing apps http:\/\/t.co\/1vQuMKho5G",
  "id" : 643910483720863744,
  "created_at" : "2015-09-15 22:13:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643806531415343104",
  "text" : "God makes things work for the best of things",
  "id" : 643806531415343104,
  "created_at" : "2015-09-15 15:20:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643806257003036673\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tzq81CAHw3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO9CX7SUwAAqV99.jpg",
      "id_str" : "643806250556243968",
      "id" : 643806250556243968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO9CX7SUwAAqV99.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tzq81CAHw3"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "Awesome",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643806257003036673",
  "text" : "Took a pic next to a Super Car, wish I could drive it :( #ThisIsOU #Awesome American Engineering at its best :P http:\/\/t.co\/tzq81CAHw3",
  "id" : 643806257003036673,
  "created_at" : "2015-09-15 15:19:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643797155107500033\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/xu1vN1SEcZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO86GJNWwAAOBjJ.jpg",
      "id_str" : "643797148962832384",
      "id" : 643797148962832384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO86GJNWwAAOBjJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xu1vN1SEcZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643797155107500033",
  "text" : "Eating Mexican Quesadilla, man fast food became expensive :( http:\/\/t.co\/xu1vN1SEcZ",
  "id" : 643797155107500033,
  "created_at" : "2015-09-15 14:42:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Fowler",
      "screen_name" : "SteveFowler",
      "indices" : [ 0, 12 ],
      "id_str" : "19767212",
      "id" : 19767212
    }, {
      "name" : "Yav\u00AE",
      "screen_name" : "Yav_R",
      "indices" : [ 13, 19 ],
      "id_str" : "28304859",
      "id" : 28304859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643772848964829184",
  "geo" : { },
  "id_str" : "643782763087306752",
  "in_reply_to_user_id" : 19767212,
  "text" : "@SteveFowler @Yav_R love it",
  "id" : 643782763087306752,
  "in_reply_to_status_id" : 643772848964829184,
  "created_at" : "2015-09-15 13:45:46 +0000",
  "in_reply_to_screen_name" : "SteveFowler",
  "in_reply_to_user_id_str" : "19767212",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/95E7QkKW2r",
      "expanded_url" : "http:\/\/fb.me\/7znWd5PtB",
      "display_url" : "fb.me\/7znWd5PtB"
    } ]
  },
  "geo" : { },
  "id_str" : "643782642547212288",
  "text" : "RT @EmperorDarroux: ISP wins 11-year battle to reveal warrantless FBI spying http:\/\/t.co\/95E7QkKW2r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/95E7QkKW2r",
        "expanded_url" : "http:\/\/fb.me\/7znWd5PtB",
        "display_url" : "fb.me\/7znWd5PtB"
      } ]
    },
    "geo" : { },
    "id_str" : "643780414167871488",
    "text" : "ISP wins 11-year battle to reveal warrantless FBI spying http:\/\/t.co\/95E7QkKW2r",
    "id" : 643780414167871488,
    "created_at" : "2015-09-15 13:36:26 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 643782642547212288,
  "created_at" : "2015-09-15 13:45:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DefundPlannedParenthood",
      "indices" : [ 74, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/LErUGUiI2I",
      "expanded_url" : "https:\/\/www.tedcruz.org\/l\/defund-planned-parenthood\/",
      "display_url" : "tedcruz.org\/l\/defund-plann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643782361403027456",
  "text" : "RT @tedcruz: Not one more taxpayer cent should go to Planned Parenthood!\n\n#DefundPlannedParenthood: https:\/\/t.co\/LErUGUiI2I http:\/\/t.co\/ack\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/643449117885140992\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/ackjj9lWYq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO39j9jU8AAjWro.png",
        "id_str" : "643449116043833344",
        "id" : 643449116043833344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO39j9jU8AAjWro.png",
        "sizes" : [ {
          "h" : 555,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ackjj9lWYq"
      } ],
      "hashtags" : [ {
        "text" : "DefundPlannedParenthood",
        "indices" : [ 61, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/LErUGUiI2I",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/defund-planned-parenthood\/",
        "display_url" : "tedcruz.org\/l\/defund-plann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643449117885140992",
    "text" : "Not one more taxpayer cent should go to Planned Parenthood!\n\n#DefundPlannedParenthood: https:\/\/t.co\/LErUGUiI2I http:\/\/t.co\/ackjj9lWYq",
    "id" : 643449117885140992,
    "created_at" : "2015-09-14 15:39:59 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 643782361403027456,
  "created_at" : "2015-09-15 13:44:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndCommonCore",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/PHQo7zFf8O",
      "expanded_url" : "https:\/\/twitter.com\/AndrewWMullins\/status\/643777895274553344",
      "display_url" : "twitter.com\/AndrewWMullins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643782304251428865",
  "text" : "RT @tedcruz: #EndCommonCore now! https:\/\/t.co\/PHQo7zFf8O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EndCommonCore",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/PHQo7zFf8O",
        "expanded_url" : "https:\/\/twitter.com\/AndrewWMullins\/status\/643777895274553344",
        "display_url" : "twitter.com\/AndrewWMullins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643780303916412928",
    "text" : "#EndCommonCore now! https:\/\/t.co\/PHQo7zFf8O",
    "id" : 643780303916412928,
    "created_at" : "2015-09-15 13:35:59 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 643782304251428865,
  "created_at" : "2015-09-15 13:43:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643782218867965952",
  "text" : "You need to believe in something or else you have a lack of knowledge",
  "id" : 643782218867965952,
  "created_at" : "2015-09-15 13:43:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643762642960711680",
  "text" : "The reason I believe agnosticism doesn't make sense is theoretically they are confused &amp; almost like a midpoint of theism &amp; non-theism",
  "id" : 643762642960711680,
  "created_at" : "2015-09-15 12:25:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 15, 30 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643761849360625664",
  "text" : "@josef_lokmani @chknfriedsteak I was basically stating the U.S. Economy is failing due to deficit spending and hyperinflation",
  "id" : 643761849360625664,
  "created_at" : "2015-09-15 12:22:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveSaeed",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643581187273809920",
  "text" : "RT @tedcruz: Join #SaveSaeed Prayer Vigil on 9\/26 -- the 3-yr anniversary of Pastor Saeed Abedini's unjust imprisonment in Iran. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaveSaeed",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/mK3qK9IzoY",
        "expanded_url" : "https:\/\/twitter.com\/NaghmehAbedini\/status\/643531527998058497",
        "display_url" : "twitter.com\/NaghmehAbedini\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643547504546463744",
    "text" : "Join #SaveSaeed Prayer Vigil on 9\/26 -- the 3-yr anniversary of Pastor Saeed Abedini's unjust imprisonment in Iran. https:\/\/t.co\/mK3qK9IzoY",
    "id" : 643547504546463744,
    "created_at" : "2015-09-14 22:10:56 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 643581187273809920,
  "created_at" : "2015-09-15 00:24:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 44, 59 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "indices" : [ 60, 73 ],
      "id_str" : "65691824",
      "id" : 65691824
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 74, 82 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643581003831709696\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/exNejFlbfc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO51gzFWoAA_R2v.jpg",
      "id_str" : "643581003089485824",
      "id" : 643581003089485824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO51gzFWoAA_R2v.jpg",
      "sizes" : [ {
        "h" : 552,
        "resize" : "fit",
        "w" : 365
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 552,
        "resize" : "fit",
        "w" : 365
      } ],
      "display_url" : "pic.twitter.com\/exNejFlbfc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643581003831709696",
  "text" : "The US Economy is far from Economic Freedom @chknfriedsteak @CarlyFiorina @tedcruz http:\/\/t.co\/exNejFlbfc",
  "id" : 643581003831709696,
  "created_at" : "2015-09-15 00:24:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Solo",
      "screen_name" : "thandojo",
      "indices" : [ 3, 12 ],
      "id_str" : "1376011723",
      "id" : 1376011723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3Dprinted",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643128735638532096",
  "text" : "RT @thandojo: French engineer &amp; professional violinist Laurent B with the \"3Dvarius\", #3Dprinted violin made of transparent resin http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thandojo\/status\/643043953864937472\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/KdcUoWYwZd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COyNDnBUsAAizrd.jpg",
        "id_str" : "643043939960795136",
        "id" : 643043939960795136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COyNDnBUsAAizrd.jpg",
        "sizes" : [ {
          "h" : 633,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KdcUoWYwZd"
      } ],
      "hashtags" : [ {
        "text" : "3Dprinted",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643043953864937472",
    "text" : "French engineer &amp; professional violinist Laurent B with the \"3Dvarius\", #3Dprinted violin made of transparent resin http:\/\/t.co\/KdcUoWYwZd",
    "id" : 643043953864937472,
    "created_at" : "2015-09-13 12:50:00 +0000",
    "user" : {
      "name" : "Hans Solo",
      "screen_name" : "thandojo",
      "protected" : false,
      "id_str" : "1376011723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000523899959\/d2c2cc996fbeba43eaf7544d273de572_normal.png",
      "id" : 1376011723,
      "verified" : false
    }
  },
  "id" : 643128735638532096,
  "created_at" : "2015-09-13 18:26:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643094627923402756",
  "text" : "@josef_lokmani haha",
  "id" : 643094627923402756,
  "created_at" : "2015-09-13 16:11:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643094557383630848\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Naq8m1Uwkt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COy7FxkUEAQ9ueC.jpg",
      "id_str" : "643094554686525444",
      "id" : 643094554686525444,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COy7FxkUEAQ9ueC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 153
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 153
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 153
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 153
      } ],
      "display_url" : "pic.twitter.com\/Naq8m1Uwkt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643094557383630848",
  "text" : "Does anyone else see what is wrong with this picture? http:\/\/t.co\/Naq8m1Uwkt",
  "id" : 643094557383630848,
  "created_at" : "2015-09-13 16:11:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Box",
      "screen_name" : "calebbox",
      "indices" : [ 3, 12 ],
      "id_str" : "46001654",
      "id" : 46001654
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 14, 23 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643047680265068544",
  "text" : "RT @calebbox: @RandPaul Ok. I'm in no way a Trump Supporter, but he successfully created a muti-billion dollar company. So please don't sto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Rand Paul",
        "screen_name" : "RandPaul",
        "indices" : [ 0, 9 ],
        "id_str" : "216881337",
        "id" : 216881337
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "642482877448351744",
    "geo" : { },
    "id_str" : "642484249153667077",
    "in_reply_to_user_id" : 216881337,
    "text" : "@RandPaul Ok. I'm in no way a Trump Supporter, but he successfully created a muti-billion dollar company. So please don't stoop down.",
    "id" : 642484249153667077,
    "in_reply_to_status_id" : 642482877448351744,
    "created_at" : "2015-09-11 23:45:56 +0000",
    "in_reply_to_screen_name" : "RandPaul",
    "in_reply_to_user_id_str" : "216881337",
    "user" : {
      "name" : "Caleb Box",
      "screen_name" : "calebbox",
      "protected" : false,
      "id_str" : "46001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2432840848\/image_normal.jpg",
      "id" : 46001654,
      "verified" : false
    }
  },
  "id" : 643047680265068544,
  "created_at" : "2015-09-13 13:04:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 3, 12 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643047436722827264",
  "text" : "RT @RandPaul: What does it say about GOP when a 3 &amp; half term Gov w\/ a successful record of creating jobs bows out as a reality star leads \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642482877448351744",
    "text" : "What does it say about GOP when a 3 &amp; half term Gov w\/ a successful record of creating jobs bows out as a reality star leads in the polls?",
    "id" : 642482877448351744,
    "created_at" : "2015-09-11 23:40:29 +0000",
    "user" : {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "protected" : false,
      "id_str" : "216881337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681152691461042177\/_PrgDgFA_normal.jpg",
      "id" : 216881337,
      "verified" : true
    }
  },
  "id" : 643047436722827264,
  "created_at" : "2015-09-13 13:03:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643046606791667716",
  "text" : "@josef_lokmani Where are the games, lol \uD83C\uDFAE",
  "id" : 643046606791667716,
  "created_at" : "2015-09-13 13:00:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643036521910661120",
  "text" : "@josef_lokmani If I could buy a phone it would probably be a Samsung Note or the s6",
  "id" : 643036521910661120,
  "created_at" : "2015-09-13 12:20:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/BCld3PQBX1",
      "expanded_url" : "https:\/\/twitter.com\/josef_lokmani\/status\/643036195082104832",
      "display_url" : "twitter.com\/josef_lokmani\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643036243891212292",
  "text" : "Lol https:\/\/t.co\/BCld3PQBX1",
  "id" : 643036243891212292,
  "created_at" : "2015-09-13 12:19:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643036099846238208",
  "text" : "@josef_lokmani I know but this is my sister's old phone",
  "id" : 643036099846238208,
  "created_at" : "2015-09-13 12:18:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643035924302032896",
  "text" : "@josef_lokmani not much",
  "id" : 643035924302032896,
  "created_at" : "2015-09-13 12:18:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643035753942020096",
  "text" : "@josef_lokmani Better then a Windows Phone",
  "id" : 643035753942020096,
  "created_at" : "2015-09-13 12:17:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathie Obradovich",
      "screen_name" : "KObradovich",
      "indices" : [ 3, 15 ],
      "id_str" : "27948604",
      "id" : 27948604
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 18, 27 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643028513952538624",
  "text" : "RT @KObradovich: .@RandPaul talking about police seizure of property w\/o any charges or convictions against the owners. \"We are fighting ba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Rand Paul",
        "screen_name" : "RandPaul",
        "indices" : [ 1, 10 ],
        "id_str" : "216881337",
        "id" : 216881337
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iacaucus",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642508809697665025",
    "text" : ".@RandPaul talking about police seizure of property w\/o any charges or convictions against the owners. \"We are fighting back.\" #iacaucus",
    "id" : 642508809697665025,
    "created_at" : "2015-09-12 01:23:32 +0000",
    "user" : {
      "name" : "Kathie Obradovich",
      "screen_name" : "KObradovich",
      "protected" : false,
      "id_str" : "27948604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1318905243\/obradovich_online_normal.jpg",
      "id" : 27948604,
      "verified" : true
    }
  },
  "id" : 643028513952538624,
  "created_at" : "2015-09-13 11:48:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/643028203611754496\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/JNYhJsEhN4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COx-vn7WcAAx1VU.jpg",
      "id_str" : "643028203444006912",
      "id" : 643028203444006912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COx-vn7WcAAx1VU.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JNYhJsEhN4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643028203611754496",
  "text" : "What's on my IPhone? http:\/\/t.co\/JNYhJsEhN4",
  "id" : 643028203611754496,
  "created_at" : "2015-09-13 11:47:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642714284871565312",
  "text" : "Thank God for all the good that happens in this world",
  "id" : 642714284871565312,
  "created_at" : "2015-09-12 15:00:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC St Louis KDNL",
      "screen_name" : "KDNLABC30",
      "indices" : [ 3, 13 ],
      "id_str" : "309133754",
      "id" : 309133754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/yxeJOfWrh8",
      "expanded_url" : "http:\/\/fb.me\/2nryi1ajK",
      "display_url" : "fb.me\/2nryi1ajK"
    } ]
  },
  "geo" : { },
  "id_str" : "642714143410253824",
  "text" : "RT @KDNLABC30: Senator Ted Cruz addresses the Missouri Eagle Forum in St Louis. http:\/\/t.co\/yxeJOfWrh8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/yxeJOfWrh8",
        "expanded_url" : "http:\/\/fb.me\/2nryi1ajK",
        "display_url" : "fb.me\/2nryi1ajK"
      } ]
    },
    "geo" : { },
    "id_str" : "642713005642280960",
    "text" : "Senator Ted Cruz addresses the Missouri Eagle Forum in St Louis. http:\/\/t.co\/yxeJOfWrh8",
    "id" : 642713005642280960,
    "created_at" : "2015-09-12 14:54:56 +0000",
    "user" : {
      "name" : "ABC St Louis KDNL",
      "screen_name" : "KDNLABC30",
      "protected" : false,
      "id_str" : "309133754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609023648066863104\/UvmiqQLy_normal.jpg",
      "id" : 309133754,
      "verified" : true
    }
  },
  "id" : 642714143410253824,
  "created_at" : "2015-09-12 14:59:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/642713535508795392\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/eRkL4YybZy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COtgjiKW8AAd7FH.jpg",
      "id_str" : "642713535412367360",
      "id" : 642713535412367360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COtgjiKW8AAd7FH.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eRkL4YybZy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642713535508795392",
  "text" : "Had pasta from the Macaroni Grill, it was okay http:\/\/t.co\/eRkL4YybZy",
  "id" : 642713535508795392,
  "created_at" : "2015-09-12 14:57:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642468653011705856",
  "text" : "God saved the world, you just need to accept him rather then turn to the face of evil and hate",
  "id" : 642468653011705856,
  "created_at" : "2015-09-11 22:43:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cruz2016",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "Logic2016",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "Vote",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "tcot",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642468493317832704",
  "text" : "#Cruz2016 #Logic2016 #Vote #tcot",
  "id" : 642468493317832704,
  "created_at" : "2015-09-11 22:43:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/642333836471324672\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ggYKd9rxO1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COoHOI3WcAEleqA.jpg",
      "id_str" : "642333836332920833",
      "id" : 642333836332920833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COoHOI3WcAEleqA.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ggYKd9rxO1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642333836471324672",
  "text" : "Had like over 1.2k calories today!!! http:\/\/t.co\/ggYKd9rxO1",
  "id" : 642333836471324672,
  "created_at" : "2015-09-11 13:48:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642314947221831680",
  "text" : "No drink like home-style lemonade to start your day!!!",
  "id" : 642314947221831680,
  "created_at" : "2015-09-11 12:33:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/CVwASogdIN",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-1269591",
      "display_url" : "ireport.cnn.com\/docs\/DOC-12695\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642114315181518848",
  "text" : "Trader Education, and Its Importance http:\/\/t.co\/CVwASogdIN #ireport",
  "id" : 642114315181518848,
  "created_at" : "2015-09-10 23:15:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/641969953181179904\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/rnbNuNoJNt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COi8RWNWsAIF1mC.jpg",
      "id_str" : "641969953105686530",
      "id" : 641969953105686530,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COi8RWNWsAIF1mC.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rnbNuNoJNt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641969953181179904",
  "text" : "Drank so much Tea :( http:\/\/t.co\/rnbNuNoJNt",
  "id" : 641969953181179904,
  "created_at" : "2015-09-10 13:42:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PE",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641615506982633472",
  "text" : "Crab Ragoons with Teriyaki sauce taste so good, #PE",
  "id" : 641615506982633472,
  "created_at" : "2015-09-09 14:13:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641021885074042880",
  "text" : "Went out with the family today. We had Panara then went to McDonalds for Ice Cream, that is when you know you are an American, lol",
  "id" : 641021885074042880,
  "created_at" : "2015-09-07 22:55:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Copt",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640594538009133056",
  "text" : "Went out with some church friends to Kim's Tea Place and had the Coffee Vanilla Ice Cream Smoothie, it was fine ;) #Copt",
  "id" : 640594538009133056,
  "created_at" : "2015-09-06 18:36:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639756070148177922",
  "text" : "Made a few people laughed, glad I did :) God Bless America",
  "id" : 639756070148177922,
  "created_at" : "2015-09-04 11:05:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639443375771545600",
  "text" : "I tried Chick-Fil-A for the first time, better then McDonalds but a bit expensive :P At least they are conservatives though :)",
  "id" : 639443375771545600,
  "created_at" : "2015-09-03 14:22:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639167613306863616",
  "text" : "Fun day so far, met many new people, go free T-Shirts, exchanged a few jokes, but a bit tiring ;) #ThisIsOU",
  "id" : 639167613306863616,
  "created_at" : "2015-09-02 20:06:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/638773983689764864\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/x8718j9nx5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN1hjb5WwAAZGHJ.jpg",
      "id_str" : "638773983568117760",
      "id" : 638773983568117760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN1hjb5WwAAZGHJ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x8718j9nx5"
    } ],
    "hashtags" : [ {
      "text" : "Junkie",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638773983689764864",
  "text" : "After this, I went to Wendy's and had a large chocolate Frosty, just enjoying my week #Junkie http:\/\/t.co\/x8718j9nx5",
  "id" : 638773983689764864,
  "created_at" : "2015-09-01 18:02:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]