Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704070014685618177",
  "geo" : { },
  "id_str" : "704322260400742401",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani Yeah I don't know why it didn't appear in my inbox.",
  "id" : 704322260400742401,
  "in_reply_to_status_id" : 704070014685618177,
  "created_at" : "2016-02-29 15:08:07 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703573970352676864",
  "geo" : { },
  "id_str" : "703683042381053952",
  "in_reply_to_user_id" : 144078841,
  "text" : "@imGodalmighty But having that as your Twitter handle, seems blasphemous",
  "id" : 703683042381053952,
  "in_reply_to_status_id" : 703573970352676864,
  "created_at" : "2016-02-27 20:48:05 +0000",
  "in_reply_to_screen_name" : "101BibleVerses",
  "in_reply_to_user_id_str" : "144078841",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703682926744096769",
  "text" : "RT @imGodalmighty: Sometimes the best thing you can do is not think, not worry, not obsess. Just have faith that everything will work out f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703604133006151680",
    "text" : "Sometimes the best thing you can do is not think, not worry, not obsess. Just have faith that everything will work out for the best.",
    "id" : 703604133006151680,
    "created_at" : "2016-02-27 15:34:32 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 703682926744096769,
  "created_at" : "2016-02-27 20:47:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703682888634597376",
  "text" : "RT @imGodalmighty: I don't thank God nearly enough. Even in times when I'm uncertain I trust Him. Thank you God for giving me everything yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703573970352676864",
    "text" : "I don't thank God nearly enough. Even in times when I'm uncertain I trust Him. Thank you God for giving me everything you have given me.",
    "id" : 703573970352676864,
    "created_at" : "2016-02-27 13:34:40 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 703682888634597376,
  "created_at" : "2016-02-27 20:47:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UeL58Zwsnc",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNF_6h0w4sYpZTyVL5zHCsPTnfJ9IQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779053332048&ei=zwbSVpi2FZCmwQHe9qmgDg&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Ffootball%2F35679497&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703682788516630530",
  "text" : "RT @andikhm01: Cristiano Ronaldo: Real Madrid forward appears unhappy with team-mates - BBC Sport https:\/\/t.co\/UeL58Zwsnc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/UeL58Zwsnc",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNF_6h0w4sYpZTyVL5zHCsPTnfJ9IQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779053332048&ei=zwbSVpi2FZCmwQHe9qmgDg&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Ffootball%2F35679497&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703681540564213760",
    "text" : "Cristiano Ronaldo: Real Madrid forward appears unhappy with team-mates - BBC Sport https:\/\/t.co\/UeL58Zwsnc",
    "id" : 703681540564213760,
    "created_at" : "2016-02-27 20:42:07 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 703682788516630530,
  "created_at" : "2016-02-27 20:47:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "703541821662765056",
  "geo" : { },
  "id_str" : "703682439009472512",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani What? Lol, no, that's a bad habit",
  "id" : 703682439009472512,
  "in_reply_to_status_id" : 703541821662765056,
  "created_at" : "2016-02-27 20:45:41 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 3, 14 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/tTFpluGLrb",
      "expanded_url" : "http:\/\/vine.co\/v\/OBLPm1IOnXX",
      "display_url" : "vine.co\/v\/OBLPm1IOnXX"
    } ]
  },
  "geo" : { },
  "id_str" : "703428515992117248",
  "text" : "RT @WWEXStream: Parents on the 1st Day of School https:\/\/t.co\/tTFpluGLrb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/tTFpluGLrb",
        "expanded_url" : "http:\/\/vine.co\/v\/OBLPm1IOnXX",
        "display_url" : "vine.co\/v\/OBLPm1IOnXX"
      } ]
    },
    "geo" : { },
    "id_str" : "703427500739829760",
    "text" : "Parents on the 1st Day of School https:\/\/t.co\/tTFpluGLrb",
    "id" : 703427500739829760,
    "created_at" : "2016-02-27 03:52:39 +0000",
    "user" : {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "protected" : false,
      "id_str" : "305791165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465976113496223744\/iEGR6Kkr_normal.jpeg",
      "id" : 305791165,
      "verified" : false
    }
  },
  "id" : 703428515992117248,
  "created_at" : "2016-02-27 03:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703427912830160896",
  "text" : "Ted Cruz nailed the debate last night",
  "id" : 703427912830160896,
  "created_at" : "2016-02-27 03:54:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald T. Trump",
      "screen_name" : "reaDonaldTrump",
      "indices" : [ 0, 15 ],
      "id_str" : "3685449739",
      "id" : 3685449739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "701572256686673920",
  "geo" : { },
  "id_str" : "701872703616188416",
  "in_reply_to_user_id" : 3685449739,
  "text" : "@reaDonaldTrump Nice fake profile \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
  "id" : 701872703616188416,
  "in_reply_to_status_id" : 701572256686673920,
  "created_at" : "2016-02-22 20:54:27 +0000",
  "in_reply_to_screen_name" : "reaDonaldTrump",
  "in_reply_to_user_id_str" : "3685449739",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Conservative",
      "screen_name" : "ChooseCruzUSA",
      "indices" : [ 3, 17 ],
      "id_str" : "2298584603",
      "id" : 2298584603
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 19, 27 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cruz",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701872433112997889",
  "text" : "RT @ChooseCruzUSA: @tedcruz Don't be fooled by Trump, the only Conservative is #Cruz &amp; he's not afraid to say he'll support Israel #ChooseC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 0, 8 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cruz",
        "indices" : [ 60, 65 ]
      }, {
        "text" : "ChooseCruz",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "701571990281277440",
    "geo" : { },
    "id_str" : "701572085001404416",
    "in_reply_to_user_id" : 23022687,
    "text" : "@tedcruz Don't be fooled by Trump, the only Conservative is #Cruz &amp; he's not afraid to say he'll support Israel #ChooseCruz",
    "id" : 701572085001404416,
    "in_reply_to_status_id" : 701571990281277440,
    "created_at" : "2016-02-22 00:59:54 +0000",
    "in_reply_to_screen_name" : "tedcruz",
    "in_reply_to_user_id_str" : "23022687",
    "user" : {
      "name" : "Real Conservative",
      "screen_name" : "ChooseCruzUSA",
      "protected" : false,
      "id_str" : "2298584603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344882354749440\/KyKjV0rD_normal.jpg",
      "id" : 2298584603,
      "verified" : false
    }
  },
  "id" : 701872433112997889,
  "created_at" : "2016-02-22 20:53:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChooseCruz",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701872389966135297",
  "text" : "RT @tedcruz: #ChooseCruz and I'll fight to return full control of Nevada\u2019s lands to its rightful owners \u2013 its citizens!\nhttps:\/\/t.co\/r1eU3x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChooseCruz",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/r1eU3xPurK",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/5277ede7-038c-42ff-8c1f-ab8f63b494a9",
        "display_url" : "amp.twimg.com\/v\/5277ede7-038\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701571990281277440",
    "text" : "#ChooseCruz and I'll fight to return full control of Nevada\u2019s lands to its rightful owners \u2013 its citizens!\nhttps:\/\/t.co\/r1eU3xPurK",
    "id" : 701571990281277440,
    "created_at" : "2016-02-22 00:59:31 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 701872389966135297,
  "created_at" : "2016-02-22 20:53:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angry Birds",
      "screen_name" : "AngryBirds",
      "indices" : [ 3, 14 ],
      "id_str" : "17337554",
      "id" : 17337554
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AngryBirds\/status\/701844151156002818\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Ps4Gf4AOOc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cb1ziR0W4AALyrw.jpg",
      "id_str" : "701844149675417600",
      "id" : 701844149675417600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cb1ziR0W4AALyrw.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 886
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 886
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ps4Gf4AOOc"
    } ],
    "hashtags" : [ {
      "text" : "Mondays",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "MondayMotivation",
      "indices" : [ 36, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701872187431641089",
  "text" : "RT @AngryBirds: #Mondays be like...\n#MondayMotivation https:\/\/t.co\/Ps4Gf4AOOc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.falcon.io\" rel=\"nofollow\"\u003EFalcon Social Media Management \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AngryBirds\/status\/701844151156002818\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/Ps4Gf4AOOc",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cb1ziR0W4AALyrw.jpg",
        "id_str" : "701844149675417600",
        "id" : 701844149675417600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cb1ziR0W4AALyrw.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 886
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 886
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ps4Gf4AOOc"
      } ],
      "hashtags" : [ {
        "text" : "Mondays",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "MondayMotivation",
        "indices" : [ 20, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701844151156002818",
    "text" : "#Mondays be like...\n#MondayMotivation https:\/\/t.co\/Ps4Gf4AOOc",
    "id" : 701844151156002818,
    "created_at" : "2016-02-22 19:00:59 +0000",
    "user" : {
      "name" : "Angry Birds",
      "screen_name" : "AngryBirds",
      "protected" : false,
      "id_str" : "17337554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826219343604101123\/eUf4Ydgf_normal.jpg",
      "id" : 17337554,
      "verified" : true
    }
  },
  "id" : 701872187431641089,
  "created_at" : "2016-02-22 20:52:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breeders' Cup",
      "screen_name" : "BreedersCup",
      "indices" : [ 3, 15 ],
      "id_str" : "29723393",
      "id" : 29723393
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BreedersCup\/status\/701870332982919168\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/5oVrev2zhl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb2LWVgUMAEQoW4.jpg",
      "id_str" : "701870332785733633",
      "id" : 701870332785733633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb2LWVgUMAEQoW4.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/5oVrev2zhl"
    } ],
    "hashtags" : [ {
      "text" : "MondayMotivation",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701871702142279685",
  "text" : "RT @BreedersCup: Live like the gates just opened... #MondayMotivation https:\/\/t.co\/5oVrev2zhl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BreedersCup\/status\/701870332982919168\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/5oVrev2zhl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb2LWVgUMAEQoW4.jpg",
        "id_str" : "701870332785733633",
        "id" : 701870332785733633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb2LWVgUMAEQoW4.jpg",
        "sizes" : [ {
          "h" : 432,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/5oVrev2zhl"
      } ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 35, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701870332982919168",
    "text" : "Live like the gates just opened... #MondayMotivation https:\/\/t.co\/5oVrev2zhl",
    "id" : 701870332982919168,
    "created_at" : "2016-02-22 20:45:02 +0000",
    "user" : {
      "name" : "Breeders' Cup",
      "screen_name" : "BreedersCup",
      "protected" : false,
      "id_str" : "29723393",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566736882500141058\/uhg_QCwg_normal.jpeg",
      "id" : 29723393,
      "verified" : true
    }
  },
  "id" : 701871702142279685,
  "created_at" : "2016-02-22 20:50:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoga Tree \u0950",
      "screen_name" : "Yoga_Tree",
      "indices" : [ 3, 13 ],
      "id_str" : "67927272",
      "id" : 67927272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MondayMotivation",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701871618642092032",
  "text" : "RT @Yoga_Tree: #MondayMotivation: You Got This! Simple as that. You are right where you're meant to be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701870847729004546",
    "text" : "#MondayMotivation: You Got This! Simple as that. You are right where you're meant to be.",
    "id" : 701870847729004546,
    "created_at" : "2016-02-22 20:47:04 +0000",
    "user" : {
      "name" : "Yoga Tree \u0950",
      "screen_name" : "Yoga_Tree",
      "protected" : false,
      "id_str" : "67927272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749810118980726785\/pRqZ8d0w_normal.jpg",
      "id" : 67927272,
      "verified" : false
    }
  },
  "id" : 701871618642092032,
  "created_at" : "2016-02-22 20:50:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Forsyth",
      "screen_name" : "AlexForsythBBC",
      "indices" : [ 3, 18 ],
      "id_str" : "36334366",
      "id" : 36334366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701871276957310976",
  "text" : "RT @AlexForsythBBC: Conservatives announce four-strong shortlist for London Mayor candidate; Andrew Boff, Zac Goldsmith, Syed Kamal and Ste\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624950729866911744",
    "text" : "Conservatives announce four-strong shortlist for London Mayor candidate; Andrew Boff, Zac Goldsmith, Syed Kamal and Stephen Greenhalgh",
    "id" : 624950729866911744,
    "created_at" : "2015-07-25 14:33:59 +0000",
    "user" : {
      "name" : "Alex Forsyth",
      "screen_name" : "AlexForsythBBC",
      "protected" : false,
      "id_str" : "36334366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750456346248671233\/8KJEM3rS_normal.jpg",
      "id" : 36334366,
      "verified" : false
    }
  },
  "id" : 701871276957310976,
  "created_at" : "2016-02-22 20:48:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/700477532127236096\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/Q7Oq5F0biP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbiYlsDUkAAH_Z8.jpg",
      "id_str" : "700477515303784448",
      "id" : 700477515303784448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbiYlsDUkAAH_Z8.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Q7Oq5F0biP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700477532127236096",
  "text" : "Nice burger :) https:\/\/t.co\/Q7Oq5F0biP",
  "id" : 700477532127236096,
  "created_at" : "2016-02-19 00:30:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/699646190103605248\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/I9ifPGrZGA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbWj-ntWIAYvwFt.jpg",
      "id_str" : "699645613332373510",
      "id" : 699645613332373510,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbWj-ntWIAYvwFt.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I9ifPGrZGA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699646190103605248",
  "text" : "Went to Burgerz 4.74\/5 stars, almost made the mark https:\/\/t.co\/I9ifPGrZGA",
  "id" : 699646190103605248,
  "created_at" : "2016-02-16 17:27:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699066154510389248",
  "text" : "Scalia was a great constitutionalist, and a proud American",
  "id" : 699066154510389248,
  "created_at" : "2016-02-15 03:02:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698934459488432129",
  "text" : "Went to Troy Kitchen 4.68\/5 stars",
  "id" : 698934459488432129,
  "created_at" : "2016-02-14 18:18:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698934335458697217",
  "text" : "The bishop at St.Mark's gave such a nice sermon today",
  "id" : 698934335458697217,
  "created_at" : "2016-02-14 18:18:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/698174336759369729\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/bRO0CV66To",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBp2ExWwAE3t2F.jpg",
      "id_str" : "698174319957032961",
      "id" : 698174319957032961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBp2ExWwAE3t2F.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bRO0CV66To"
    } ],
    "hashtags" : [ {
      "text" : "Pillsburyminis",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698174336759369729",
  "text" : "So happy, free gift, lol #Pillsburyminis My favorite way companies advertise https:\/\/t.co\/bRO0CV66To",
  "id" : 698174336759369729,
  "created_at" : "2016-02-12 15:58:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LisaPopeil.com",
      "screen_name" : "Lisa_Popeil",
      "indices" : [ 3, 15 ],
      "id_str" : "158827012",
      "id" : 158827012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695341122906750976",
  "text" : "RT @Lisa_Popeil: Beethoven: Sonata Op 106; Schubert: Impromptus D899; Three Pieces D946, etc CD review \u2013 thoroughly - the guardian https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Tl3o49YPXA",
        "expanded_url" : "https:\/\/apple.news\/ApX309s_jQXCgr2n3iVLedg",
        "display_url" : "apple.news\/ApX309s_jQXCgr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695308594380537856",
    "text" : "Beethoven: Sonata Op 106; Schubert: Impromptus D899; Three Pieces D946, etc CD review \u2013 thoroughly - the guardian https:\/\/t.co\/Tl3o49YPXA",
    "id" : 695308594380537856,
    "created_at" : "2016-02-04 18:11:01 +0000",
    "user" : {
      "name" : "LisaPopeil.com",
      "screen_name" : "Lisa_Popeil",
      "protected" : false,
      "id_str" : "158827012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1288396959\/Pink_Crop_LSP_normal.jpg",
      "id" : 158827012,
      "verified" : false
    }
  },
  "id" : 695341122906750976,
  "created_at" : "2016-02-04 20:20:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pillsburyminis",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/3m1d5E7lEJ",
      "expanded_url" : "https:\/\/klout.com\/brand\/pillsbury\/pillsburys-new-mini-baked-goods?n=tw&v=perks_claimed_tw&qid=569fd4dae4b050576ec743dd",
      "display_url" : "klout.com\/brand\/pillsbur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695339615725563908",
  "text" : "Pumped for these new Pillsbury Minis! Cinnamon rolls without all the work!  #Pillsburyminis https:\/\/t.co\/3m1d5E7lEJ",
  "id" : 695339615725563908,
  "created_at" : "2016-02-04 20:14:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/694586528174116864\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/vpOMHmhdML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaOqxGWWQAQDgO5.jpg",
      "id_str" : "694586528039845892",
      "id" : 694586528039845892,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaOqxGWWQAQDgO5.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vpOMHmhdML"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694586528174116864",
  "text" : "Nachos, still like Chipotle more https:\/\/t.co\/vpOMHmhdML",
  "id" : 694586528174116864,
  "created_at" : "2016-02-02 18:21:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KRON4 News",
      "screen_name" : "kron4news",
      "indices" : [ 3, 13 ],
      "id_str" : "19031057",
      "id" : 19031057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/28czkEfwnI",
      "expanded_url" : "http:\/\/wp.me\/p5hgGs-1hCV",
      "display_url" : "wp.me\/p5hgGs-1hCV"
    } ]
  },
  "geo" : { },
  "id_str" : "694144163764424704",
  "text" : "RT @kron4news: Hoverboard found in area where fire started in a San Leandro home https:\/\/t.co\/28czkEfwnI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/28czkEfwnI",
        "expanded_url" : "http:\/\/wp.me\/p5hgGs-1hCV",
        "display_url" : "wp.me\/p5hgGs-1hCV"
      } ]
    },
    "geo" : { },
    "id_str" : "694132673355190273",
    "text" : "Hoverboard found in area where fire started in a San Leandro home https:\/\/t.co\/28czkEfwnI",
    "id" : 694132673355190273,
    "created_at" : "2016-02-01 12:18:20 +0000",
    "user" : {
      "name" : "KRON4 News",
      "screen_name" : "kron4news",
      "protected" : false,
      "id_str" : "19031057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000639069470\/6d4b41afcb0ad5e5d5fd04dc68787a4d_normal.jpeg",
      "id" : 19031057,
      "verified" : true
    }
  },
  "id" : 694144163764424704,
  "created_at" : "2016-02-01 13:03:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katlin Elizabeth",
      "screen_name" : "katlinelizabeth",
      "indices" : [ 0, 16 ],
      "id_str" : "17929165",
      "id" : 17929165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "in_reply_to_status_id_str" : "694130483249168384",
  "geo" : { },
  "id_str" : "694144083254714368",
  "in_reply_to_user_id" : 17929165,
  "text" : "@katlinelizabeth They shouldn't be even called Hoverboards, there needs to be a real one https:\/\/t.co\/HfViSZFgjj",
  "id" : 694144083254714368,
  "in_reply_to_status_id" : 694130483249168384,
  "created_at" : "2016-02-01 13:03:40 +0000",
  "in_reply_to_screen_name" : "katlinelizabeth",
  "in_reply_to_user_id_str" : "17929165",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Twine",
      "screen_name" : "ajnt",
      "indices" : [ 0, 5 ],
      "id_str" : "39074324",
      "id" : 39074324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "in_reply_to_status_id_str" : "694138391122804742",
  "geo" : { },
  "id_str" : "694143768761634817",
  "in_reply_to_user_id" : 39074324,
  "text" : "@ajnt This is why real Hoverboards need to be made, we can't even get a Chinese Segway right? https:\/\/t.co\/HfViSZFgjj",
  "id" : 694143768761634817,
  "in_reply_to_status_id" : 694138391122804742,
  "created_at" : "2016-02-01 13:02:25 +0000",
  "in_reply_to_screen_name" : "ajnt",
  "in_reply_to_user_id_str" : "39074324",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Bin - Envirobot",
      "screen_name" : "mrbin_app",
      "indices" : [ 0, 10 ],
      "id_str" : "2838496518",
      "id" : 2838496518
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 11, 20 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "in_reply_to_status_id_str" : "694141930960191488",
  "geo" : { },
  "id_str" : "694143564842950656",
  "in_reply_to_user_id" : 2838496518,
  "text" : "@mrbin_app @mashable I am still waiting for real Hoverboards https:\/\/t.co\/HfViSZFgjj",
  "id" : 694143564842950656,
  "in_reply_to_status_id" : 694141930960191488,
  "created_at" : "2016-02-01 13:01:37 +0000",
  "in_reply_to_screen_name" : "mrbin_app",
  "in_reply_to_user_id_str" : "2838496518",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CreateSpace",
      "screen_name" : "CreateSpace",
      "indices" : [ 0, 12 ],
      "id_str" : "25155970",
      "id" : 25155970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "geo" : { },
  "id_str" : "694143279781298176",
  "in_reply_to_user_id" : 25155970,
  "text" : "@CreateSpace Published my book, can use a bit of a boost https:\/\/t.co\/HfViSZFgjj",
  "id" : 694143279781298176,
  "created_at" : "2016-02-01 13:00:29 +0000",
  "in_reply_to_screen_name" : "CreateSpace",
  "in_reply_to_user_id_str" : "25155970",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "geo" : { },
  "id_str" : "694142846232850432",
  "text" : "When will real Hoverboards come? https:\/\/t.co\/HfViSZFgjj",
  "id" : 694142846232850432,
  "created_at" : "2016-02-01 12:58:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "indices" : [ 3, 19 ],
      "id_str" : "18992010",
      "id" : 18992010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "behavioralfinance",
      "indices" : [ 54, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/HgaSzBt765",
      "expanded_url" : "https:\/\/medium.com\/@edukate\/you-re-using-all-the-wrong-words-af298767e6f0",
      "display_url" : "medium.com\/@edukate\/you-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694139509726904320",
  "text" : "RT @victorricciardi: You\u2019re Using All the Wrong Words #behavioralfinance \nhttps:\/\/t.co\/HgaSzBt765",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "behavioralfinance",
        "indices" : [ 33, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/HgaSzBt765",
        "expanded_url" : "https:\/\/medium.com\/@edukate\/you-re-using-all-the-wrong-words-af298767e6f0",
        "display_url" : "medium.com\/@edukate\/you-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694137882131480576",
    "text" : "You\u2019re Using All the Wrong Words #behavioralfinance \nhttps:\/\/t.co\/HgaSzBt765",
    "id" : 694137882131480576,
    "created_at" : "2016-02-01 12:39:02 +0000",
    "user" : {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "protected" : false,
      "id_str" : "18992010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566693508296085504\/-v5kzmcw_normal.jpeg",
      "id" : 18992010,
      "verified" : false
    }
  },
  "id" : 694139509726904320,
  "created_at" : "2016-02-01 12:45:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694139439031934976",
  "text" : "RT @BarbaraCorcoran: Don't ever underestimate the power of your own instinct. Every good decision I\u2019ve made, I\u2019ve trusted my gut.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693872706924724224",
    "text" : "Don't ever underestimate the power of your own instinct. Every good decision I\u2019ve made, I\u2019ve trusted my gut.",
    "id" : 693872706924724224,
    "created_at" : "2016-01-31 19:05:19 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 694139439031934976,
  "created_at" : "2016-02-01 12:45:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "indices" : [ 3, 12 ],
      "id_str" : "96013710",
      "id" : 96013710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694138944238280704",
  "text" : "RT @FactSoup: Seek respect, not attention. It lasts longer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694137383952990208",
    "text" : "Seek respect, not attention. It lasts longer.",
    "id" : 694137383952990208,
    "created_at" : "2016-02-01 12:37:03 +0000",
    "user" : {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "protected" : false,
      "id_str" : "96013710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000696923068\/4391acb040884e51fc35a3e4631cde7a_normal.jpeg",
      "id" : 96013710,
      "verified" : false
    }
  },
  "id" : 694138944238280704,
  "created_at" : "2016-02-01 12:43:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iacaucus",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694138599462309888",
  "text" : "RT @tedcruz: We let Caroline &amp; Catherine off the bus for some exercise by Ames. They said they were \"running to caucus\" #iacaucus https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/693867780576129025\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/l7ZoCWs9kA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaEdD03UsAAm0ft.jpg",
        "id_str" : "693867769159266304",
        "id" : 693867769159266304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaEdD03UsAAm0ft.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 952
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 952
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/l7ZoCWs9kA"
      } ],
      "hashtags" : [ {
        "text" : "iacaucus",
        "indices" : [ 111, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693867780576129025",
    "text" : "We let Caroline &amp; Catherine off the bus for some exercise by Ames. They said they were \"running to caucus\" #iacaucus https:\/\/t.co\/l7ZoCWs9kA",
    "id" : 693867780576129025,
    "created_at" : "2016-01-31 18:45:44 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 694138599462309888,
  "created_at" : "2016-02-01 12:41:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Einstein Bros.",
      "screen_name" : "EinsteinBros",
      "indices" : [ 0, 13 ],
      "id_str" : "59834052",
      "id" : 59834052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/694138263322415104\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/8WQllShili",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaITDtvWYAAdBq0.jpg",
      "id_str" : "694138247107207168",
      "id" : 694138247107207168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaITDtvWYAAdBq0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8WQllShili"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694138263322415104",
  "in_reply_to_user_id" : 59834052,
  "text" : "@EinsteinBros Starting my day off with a fruit smoothie https:\/\/t.co\/8WQllShili",
  "id" : 694138263322415104,
  "created_at" : "2016-02-01 12:40:33 +0000",
  "in_reply_to_screen_name" : "EinsteinBros",
  "in_reply_to_user_id_str" : "59834052",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]