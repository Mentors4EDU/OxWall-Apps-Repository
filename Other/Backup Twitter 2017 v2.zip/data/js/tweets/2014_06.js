Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/2JfXA7nSFX",
      "expanded_url" : "http:\/\/youtu.be\/Oc7nVSyWdBk",
      "display_url" : "youtu.be\/Oc7nVSyWdBk"
    } ]
  },
  "geo" : { },
  "id_str" : "483329242483027968",
  "text" : "RT @MarkDice: Obama is Doing a Great Job...Destroying America  http:\/\/t.co\/2JfXA7nSFX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/2JfXA7nSFX",
        "expanded_url" : "http:\/\/youtu.be\/Oc7nVSyWdBk",
        "display_url" : "youtu.be\/Oc7nVSyWdBk"
      } ]
    },
    "geo" : { },
    "id_str" : "483063418841477120",
    "text" : "Obama is Doing a Great Job...Destroying America  http:\/\/t.co\/2JfXA7nSFX",
    "id" : 483063418841477120,
    "created_at" : "2014-06-29 01:44:28 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 483329242483027968,
  "created_at" : "2014-06-29 19:20:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Anne's",
      "screen_name" : "AuntieAnnes",
      "indices" : [ 15, 27 ],
      "id_str" : "35737873",
      "id" : 35737873
    }, {
      "name" : "Wetzel's Pretzels",
      "screen_name" : "wetzelspretzels",
      "indices" : [ 33, 49 ],
      "id_str" : "41132999",
      "id" : 41132999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483329128628641792",
  "text" : "I would choose @AuntieAnnes over @wetzelspretzels any day",
  "id" : 483329128628641792,
  "created_at" : "2014-06-29 19:20:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SweetwatersCoffeeTea",
      "screen_name" : "Sweetwaters",
      "indices" : [ 0, 12 ],
      "id_str" : "19991592",
      "id" : 19991592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483013345822261249",
  "in_reply_to_user_id" : 19991592,
  "text" : "@Sweetwaters I tried you earlier this week when I was so tired for work, your mocha frappe is the best, just expensive, but amazing quality",
  "id" : 483013345822261249,
  "created_at" : "2014-06-28 22:25:30 +0000",
  "in_reply_to_screen_name" : "Sweetwaters",
  "in_reply_to_user_id_str" : "19991592",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Danno Santiago",
      "screen_name" : "DannoTheManno",
      "indices" : [ 14, 28 ],
      "id_str" : "954799008",
      "id" : 954799008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482655409971286016",
  "text" : "RT @MarkDice: @DannoTheManno thanks.  its sad so few people actually READ a BOOK these days.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Danno Santiago",
        "screen_name" : "DannoTheManno",
        "indices" : [ 0, 14 ],
        "id_str" : "954799008",
        "id" : 954799008
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "482607214688239616",
    "geo" : { },
    "id_str" : "482607402718875648",
    "in_reply_to_user_id" : 954799008,
    "text" : "@DannoTheManno thanks.  its sad so few people actually READ a BOOK these days.",
    "id" : 482607402718875648,
    "in_reply_to_status_id" : 482607214688239616,
    "created_at" : "2014-06-27 19:32:25 +0000",
    "in_reply_to_screen_name" : "DannoTheManno",
    "in_reply_to_user_id_str" : "954799008",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 482655409971286016,
  "created_at" : "2014-06-27 22:43:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/bxwzXXeLKB",
      "expanded_url" : "http:\/\/1drv.ms\/1qCptMA",
      "display_url" : "1drv.ms\/1qCptMA"
    } ]
  },
  "geo" : { },
  "id_str" : "482655121650622464",
  "text" : "Went to Olga's kitchen 3.2\/5 stars http:\/\/t.co\/bxwzXXeLKB",
  "id" : 482655121650622464,
  "created_at" : "2014-06-27 22:42:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/eZCU5evavD",
      "expanded_url" : "http:\/\/1drv.ms\/Vp5dns",
      "display_url" : "1drv.ms\/Vp5dns"
    } ]
  },
  "geo" : { },
  "id_str" : "481958169237671936",
  "text" : "Went to Al Ameers 4.7\/5 http:\/\/t.co\/eZCU5evavD",
  "id" : 481958169237671936,
  "created_at" : "2014-06-26 00:32:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/i9Pzqg4Dbu",
      "expanded_url" : "http:\/\/1drv.ms\/1lHtsaZ",
      "display_url" : "1drv.ms\/1lHtsaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "480327719280852992",
  "text" : "Vanilla bean coffee, so sweet http:\/\/t.co\/i9Pzqg4Dbu",
  "id" : 480327719280852992,
  "created_at" : "2014-06-21 12:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479655341156597760",
  "text" : "RT @MarkDice: A lot of rappers always ask, \"You know what I'm saying?\" cuz their gibberish is hard to make out by those who speak actual En\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479347917741121536",
    "text" : "A lot of rappers always ask, \"You know what I'm saying?\" cuz their gibberish is hard to make out by those who speak actual English.",
    "id" : 479347917741121536,
    "created_at" : "2014-06-18 19:40:24 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 479655341156597760,
  "created_at" : "2014-06-19 16:01:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/m5pdhg5N9S",
      "expanded_url" : "http:\/\/1drv.ms\/1ragH8c",
      "display_url" : "1drv.ms\/1ragH8c"
    } ]
  },
  "geo" : { },
  "id_str" : "479471727420792832",
  "text" : "Chocolate pudding http:\/\/t.co\/m5pdhg5N9S",
  "id" : 479471727420792832,
  "created_at" : "2014-06-19 03:52:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479330526319222784",
  "text" : "Will be developing on ouya soon, please wait",
  "id" : 479330526319222784,
  "created_at" : "2014-06-18 18:31:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Oliwer Harlig",
      "screen_name" : "oliwerhar4",
      "indices" : [ 14, 25 ],
      "id_str" : "2321931911",
      "id" : 2321931911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478535278034833408",
  "text" : "RT @MarkDice: @oliwerhar4 that's been in the their playbook for years, it just depends when Israel and or America pulls the trigger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oliwer Harlig",
        "screen_name" : "oliwerhar4",
        "indices" : [ 0, 11 ],
        "id_str" : "2321931911",
        "id" : 2321931911
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "478234061346177024",
    "geo" : { },
    "id_str" : "478238645393305600",
    "in_reply_to_user_id" : 2321931911,
    "text" : "@oliwerhar4 that's been in the their playbook for years, it just depends when Israel and or America pulls the trigger.",
    "id" : 478238645393305600,
    "in_reply_to_status_id" : 478234061346177024,
    "created_at" : "2014-06-15 18:12:32 +0000",
    "in_reply_to_screen_name" : "oliwerhar4",
    "in_reply_to_user_id_str" : "2321931911",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 478535278034833408,
  "created_at" : "2014-06-16 13:51:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 3, 16 ],
      "id_str" : "580255414",
      "id" : 580255414
    }, {
      "name" : "Henry fisher",
      "screen_name" : "Henryfisher17",
      "indices" : [ 18, 32 ],
      "id_str" : "774231710431006720",
      "id" : 774231710431006720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478535044189806593",
  "text" : "RT @RockerCyborg: @henryfisher17 too many for an adult.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Henry fisher",
        "screen_name" : "Henryfisher17",
        "indices" : [ 0, 14 ],
        "id_str" : "774231710431006720",
        "id" : 774231710431006720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469157073134301184",
    "text" : "@henryfisher17 too many for an adult.",
    "id" : 469157073134301184,
    "created_at" : "2014-05-21 16:45:37 +0000",
    "user" : {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "protected" : false,
      "id_str" : "580255414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818919561214865408\/NAHNRL36_normal.jpg",
      "id" : 580255414,
      "verified" : false
    }
  },
  "id" : 478535044189806593,
  "created_at" : "2014-06-16 13:50:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/jWXzrS5QdC",
      "expanded_url" : "http:\/\/1drv.ms\/UE7Dhz",
      "display_url" : "1drv.ms\/UE7Dhz"
    } ]
  },
  "geo" : { },
  "id_str" : "478267307211255808",
  "text" : "Cinnamon French vanilla pudding http:\/\/t.co\/jWXzrS5QdC",
  "id" : 478267307211255808,
  "created_at" : "2014-06-15 20:06:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/AtTQYwf9rY",
      "expanded_url" : "http:\/\/1drv.ms\/1qfTaF6",
      "display_url" : "1drv.ms\/1qfTaF6"
    } ]
  },
  "geo" : { },
  "id_str" : "477966043889946624",
  "text" : "Cherry and banana pudding http:\/\/t.co\/AtTQYwf9rY",
  "id" : 477966043889946624,
  "created_at" : "2014-06-15 00:09:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darlin (cuz Joseph)",
      "screen_name" : "Jessibelle03",
      "indices" : [ 3, 16 ],
      "id_str" : "204547097",
      "id" : 204547097
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheVigilantChristian",
      "indices" : [ 22, 43 ]
    }, {
      "text" : "goodday",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "thankYouJesus",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477599099869360129",
  "text" : "RT @Jessibelle03: YES #TheVigilantChristian IS BACK YESSSS #goodday #thankYouJesus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheVigilantChristian",
        "indices" : [ 4, 25 ]
      }, {
        "text" : "goodday",
        "indices" : [ 41, 49 ]
      }, {
        "text" : "thankYouJesus",
        "indices" : [ 50, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476903013492084736",
    "text" : "YES #TheVigilantChristian IS BACK YESSSS #goodday #thankYouJesus",
    "id" : 476903013492084736,
    "created_at" : "2014-06-12 01:45:13 +0000",
    "user" : {
      "name" : "Darlin (cuz Joseph)",
      "screen_name" : "Jessibelle03",
      "protected" : false,
      "id_str" : "204547097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820879944368750592\/agzhimOJ_normal.jpg",
      "id" : 204547097,
      "verified" : false
    }
  },
  "id" : 477599099869360129,
  "created_at" : "2014-06-13 23:51:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/477597902739484673\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Wh486lNyio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqDEwq7CEAAohNc.jpg",
      "id_str" : "477597900935925760",
      "id" : 477597900935925760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqDEwq7CEAAohNc.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 170
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 170
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 170
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 170
      } ],
      "display_url" : "pic.twitter.com\/Wh486lNyio"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477597902739484673",
  "text" : "That is some good stuff http:\/\/t.co\/Wh486lNyio",
  "id" : 477597902739484673,
  "created_at" : "2014-06-13 23:46:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/07kbHfisCT",
      "expanded_url" : "http:\/\/1drv.ms\/1mNhPdV",
      "display_url" : "1drv.ms\/1mNhPdV"
    } ]
  },
  "geo" : { },
  "id_str" : "477144060000337921",
  "text" : "Had the roast beef supreme yesterday http:\/\/t.co\/07kbHfisCT",
  "id" : 477144060000337921,
  "created_at" : "2014-06-12 17:43:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "indices" : [ 3, 10 ],
      "id_str" : "150248263",
      "id" : 150248263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/CrTiVDUTJp",
      "expanded_url" : "http:\/\/bit.ly\/1kEHFnN",
      "display_url" : "bit.ly\/1kEHFnN"
    } ]
  },
  "geo" : { },
  "id_str" : "476088941309722626",
  "text" : "RT @fiverr: This just in: Mutual cancellations no longer affect seller cancellation ratings! http:\/\/t.co\/CrTiVDUTJp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/CrTiVDUTJp",
        "expanded_url" : "http:\/\/bit.ly\/1kEHFnN",
        "display_url" : "bit.ly\/1kEHFnN"
      } ]
    },
    "geo" : { },
    "id_str" : "474694676952272898",
    "text" : "This just in: Mutual cancellations no longer affect seller cancellation ratings! http:\/\/t.co\/CrTiVDUTJp",
    "id" : 474694676952272898,
    "created_at" : "2014-06-05 23:30:05 +0000",
    "user" : {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "protected" : false,
      "id_str" : "150248263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818489482345201665\/owRu5UmW_normal.jpg",
      "id" : 150248263,
      "verified" : true
    }
  },
  "id" : 476088941309722626,
  "created_at" : "2014-06-09 19:50:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5AQ4gATJbr",
      "expanded_url" : "http:\/\/1drv.ms\/1mxX0mK",
      "display_url" : "1drv.ms\/1mxX0mK"
    } ]
  },
  "geo" : { },
  "id_str" : "476083691324583937",
  "text" : "Roast beef, Doritos, and mozerella sandwich plus had 4 glazed donuts http:\/\/t.co\/5AQ4gATJbr",
  "id" : 476083691324583937,
  "created_at" : "2014-06-09 19:29:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/T9RaamGYXv",
      "expanded_url" : "http:\/\/1drv.ms\/1qchC7N",
      "display_url" : "1drv.ms\/1qchC7N"
    } ]
  },
  "geo" : { },
  "id_str" : "475688102468395008",
  "text" : "Candy!!! http:\/\/t.co\/T9RaamGYXv",
  "id" : 475688102468395008,
  "created_at" : "2014-06-08 17:17:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RpYVo3gtXd",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Q1W-fJpgZr0",
      "display_url" : "youtube.com\/watch?v=Q1W-fJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475171488333438976",
  "text" : "RT @MarkDice: 16-year-old confronts Nancy Pelosi for her support of the NSA spying on Americans.  Hahaha.  VIDEO: https:\/\/t.co\/RpYVo3gtXd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/RpYVo3gtXd",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Q1W-fJpgZr0",
        "display_url" : "youtube.com\/watch?v=Q1W-fJ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474417288901578752",
    "text" : "16-year-old confronts Nancy Pelosi for her support of the NSA spying on Americans.  Hahaha.  VIDEO: https:\/\/t.co\/RpYVo3gtXd",
    "id" : 474417288901578752,
    "created_at" : "2014-06-05 05:07:50 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 475171488333438976,
  "created_at" : "2014-06-07 07:04:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/jIlXbOA1NS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=TwwH6xBn4mg",
      "display_url" : "youtube.com\/watch?v=TwwH6x\u2026"
    }, {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/toy6GorObr",
      "expanded_url" : "http:\/\/fb.me\/3veWc4bMX",
      "display_url" : "fb.me\/3veWc4bMX"
    } ]
  },
  "geo" : { },
  "id_str" : "475166065702735872",
  "text" : "https:\/\/t.co\/jIlXbOA1NS http:\/\/t.co\/toy6GorObr",
  "id" : 475166065702735872,
  "created_at" : "2014-06-07 06:43:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/9MQgHajzlY",
      "expanded_url" : "http:\/\/bit.ly\/1i86X9c",
      "display_url" : "bit.ly\/1i86X9c"
    } ]
  },
  "geo" : { },
  "id_str" : "474846112843448320",
  "text" : "You gotta check out the youtube channel at http:\/\/t.co\/9MQgHajzlY, made me awesome graphics",
  "id" : 474846112843448320,
  "created_at" : "2014-06-06 09:31:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474714092746178561",
  "in_reply_to_user_id" : 35039490,
  "text" : "@Markdice can you expose illuminati puppet youtubers, there are tons of them, some the most subscribed youtube channels.",
  "id" : 474714092746178561,
  "created_at" : "2014-06-06 00:47:14 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Bo2tqJtpJA",
      "expanded_url" : "http:\/\/youtu.be\/R4elK1awVdM",
      "display_url" : "youtu.be\/R4elK1awVdM"
    } ]
  },
  "geo" : { },
  "id_str" : "474713718660403201",
  "text" : "RT @MarkDice: 91-Year-Old Woman Breaks Marathon Record!!!   http:\/\/t.co\/Bo2tqJtpJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Bo2tqJtpJA",
        "expanded_url" : "http:\/\/youtu.be\/R4elK1awVdM",
        "display_url" : "youtu.be\/R4elK1awVdM"
      } ]
    },
    "geo" : { },
    "id_str" : "474344147584057344",
    "text" : "91-Year-Old Woman Breaks Marathon Record!!!   http:\/\/t.co\/Bo2tqJtpJA",
    "id" : 474344147584057344,
    "created_at" : "2014-06-05 00:17:12 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 474713718660403201,
  "created_at" : "2014-06-06 00:45:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/0YqJJORS1N",
      "expanded_url" : "http:\/\/1drv.ms\/1rPFUcg",
      "display_url" : "1drv.ms\/1rPFUcg"
    } ]
  },
  "geo" : { },
  "id_str" : "474712923768893440",
  "text" : "Went to Dimitris, ate the lamb http:\/\/t.co\/0YqJJORS1N",
  "id" : 474712923768893440,
  "created_at" : "2014-06-06 00:42:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]