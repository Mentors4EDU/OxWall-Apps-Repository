Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Voelker \uD83C\uDF39",
      "screen_name" : "petevoelker",
      "indices" : [ 0, 12 ],
      "id_str" : "26341654",
      "id" : 26341654
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 13, 21 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593130695528157184",
  "geo" : { },
  "id_str" : "593525571872632832",
  "in_reply_to_user_id" : 26341654,
  "text" : "@petevoelker @tedcruz Say that and not be surprised when we have a total economic collapse and downfall on the American dollar.",
  "id" : 593525571872632832,
  "in_reply_to_status_id" : 593130695528157184,
  "created_at" : "2015-04-29 21:21:38 +0000",
  "in_reply_to_screen_name" : "petevoelker",
  "in_reply_to_user_id_str" : "26341654",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593505090314510336",
  "geo" : { },
  "id_str" : "593524966634622977",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz How about no taxes, lol.",
  "id" : 593524966634622977,
  "in_reply_to_status_id" : 593505090314510336,
  "created_at" : "2015-04-29 21:19:13 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AbolishtheIRS",
      "indices" : [ 24, 38 ]
    }, {
      "text" : "USHCC",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593524903485120512",
  "text" : "RT @tedcruz: We need to #AbolishtheIRS and institute a simple flat tax #USHCC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AbolishtheIRS",
        "indices" : [ 11, 25 ]
      }, {
        "text" : "USHCC",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593505090314510336",
    "text" : "We need to #AbolishtheIRS and institute a simple flat tax #USHCC",
    "id" : 593505090314510336,
    "created_at" : "2015-04-29 20:00:14 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 593524903485120512,
  "created_at" : "2015-04-29 21:18:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593524700199849985",
  "text" : "RT @tedcruz: People are fed up with politicians who say one thing on the campaign trail and then don\u2019t follow through and do what they said\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USHCC",
        "indices" : [ 127, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593519092843159552",
    "text" : "People are fed up with politicians who say one thing on the campaign trail and then don\u2019t follow through and do what they said #USHCC",
    "id" : 593519092843159552,
    "created_at" : "2015-04-29 20:55:53 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 593524700199849985,
  "created_at" : "2015-04-29 21:18:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "indices" : [ 0, 12 ],
      "id_str" : "207784631",
      "id" : 207784631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593524550656110593",
  "in_reply_to_user_id" : 207784631,
  "text" : "@JonTronShow Thanks for the free nightmares!!!",
  "id" : 593524550656110593,
  "created_at" : "2015-04-29 21:17:34 +0000",
  "in_reply_to_screen_name" : "JonTronShow",
  "in_reply_to_user_id_str" : "207784631",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593524295457853441",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Tomorrow is the big day, man Colin, you never fail to impress us, except when you injure yourself, that part isn't impressive",
  "id" : 593524295457853441,
  "created_at" : "2015-04-29 21:16:33 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marouane Bembli",
      "screen_name" : "MBembli",
      "indices" : [ 0, 8 ],
      "id_str" : "2168984765",
      "id" : 2168984765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593523932818329600",
  "in_reply_to_user_id" : 2168984765,
  "text" : "@MBembli Are you open to collaborations? :)",
  "id" : 593523932818329600,
  "created_at" : "2015-04-29 21:15:07 +0000",
  "in_reply_to_screen_name" : "MBembli",
  "in_reply_to_user_id_str" : "2168984765",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592618492182016000",
  "geo" : { },
  "id_str" : "593167347705348096",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Yeah",
  "id" : 593167347705348096,
  "in_reply_to_status_id" : 592618492182016000,
  "created_at" : "2015-04-28 21:38:10 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigpulsejetaction",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593167303216373760",
  "text" : "RT @colin_furze: This Thursday is new video day and I start turning the Internet up again. Boom #bigpulsejetaction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bigpulsejetaction",
        "indices" : [ 79, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592618492182016000",
    "text" : "This Thursday is new video day and I start turning the Internet up again. Boom #bigpulsejetaction",
    "id" : 592618492182016000,
    "created_at" : "2015-04-27 09:17:13 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 593167303216373760,
  "created_at" : "2015-04-28 21:38:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/593114766534680577\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/E1lB2dRGwA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsqvHRW0AEZwWz.jpg",
      "id_str" : "593114764823416833",
      "id" : 593114764823416833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsqvHRW0AEZwWz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/E1lB2dRGwA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/k9QscrdSob",
      "expanded_url" : "https:\/\/www.youtube.com\/colinfurze",
      "display_url" : "youtube.com\/colinfurze"
    } ]
  },
  "geo" : { },
  "id_str" : "593167249730621440",
  "text" : "RT @colin_furze: This THURSDAY the internet is getting turned back up again.\nhttps:\/\/t.co\/k9QscrdSob http:\/\/t.co\/E1lB2dRGwA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/593114766534680577\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/E1lB2dRGwA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsqvHRW0AEZwWz.jpg",
        "id_str" : "593114764823416833",
        "id" : 593114764823416833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsqvHRW0AEZwWz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/E1lB2dRGwA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/k9QscrdSob",
        "expanded_url" : "https:\/\/www.youtube.com\/colinfurze",
        "display_url" : "youtube.com\/colinfurze"
      } ]
    },
    "geo" : { },
    "id_str" : "593114766534680577",
    "text" : "This THURSDAY the internet is getting turned back up again.\nhttps:\/\/t.co\/k9QscrdSob http:\/\/t.co\/E1lB2dRGwA",
    "id" : 593114766534680577,
    "created_at" : "2015-04-28 18:09:14 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 593167249730621440,
  "created_at" : "2015-04-28 21:37:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker Supporter",
      "screen_name" : "HT_Supporter",
      "indices" : [ 0, 13 ],
      "id_str" : "20353836",
      "id" : 20353836
    }, {
      "name" : "GoViral @HeadTalker",
      "screen_name" : "loveheadtalker",
      "indices" : [ 14, 29 ],
      "id_str" : "539539884",
      "id" : 539539884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/koJ3ETwmOs",
      "expanded_url" : "https:\/\/headtalker.com\/campaigns\/mentors4edu\/",
      "display_url" : "headtalker.com\/campaigns\/ment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593167073636950016",
  "in_reply_to_user_id" : 20353836,
  "text" : "@HT_Supporter @loveheadtalker Please support my campaign https:\/\/t.co\/koJ3ETwmOs",
  "id" : 593167073636950016,
  "created_at" : "2015-04-28 21:37:05 +0000",
  "in_reply_to_screen_name" : "HT_Supporter",
  "in_reply_to_user_id_str" : "20353836",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "America",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "cruz2015",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592833518360723456",
  "text" : "We need to get #America back to its former self. We need a leader who can step up, man up, and take this country uphill #cruz2015",
  "id" : 592833518360723456,
  "created_at" : "2015-04-27 23:31:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Islam",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "NO2ISIS",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592832933649584128",
  "text" : "RT @FarrukhHussaini: and today the so called Defenders of #Islam are persecuting and killing Christians...#NO2ISIS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Islam",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "NO2ISIS",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "590189237678379008",
    "geo" : { },
    "id_str" : "590189460655984640",
    "in_reply_to_user_id" : 77916923,
    "text" : "and today the so called Defenders of #Islam are persecuting and killing Christians...#NO2ISIS",
    "id" : 590189460655984640,
    "in_reply_to_status_id" : 590189237678379008,
    "created_at" : "2015-04-20 16:25:07 +0000",
    "in_reply_to_screen_name" : "Farrukh_Abbas12",
    "in_reply_to_user_id_str" : "77916923",
    "user" : {
      "name" : "Farrukh Abbas",
      "screen_name" : "Farrukh_Abbas12",
      "protected" : false,
      "id_str" : "77916923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/935838972311429121\/-OoOiFjr_normal.jpg",
      "id" : 77916923,
      "verified" : false
    }
  },
  "id" : 592832933649584128,
  "created_at" : "2015-04-27 23:29:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreRiots",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lBkGr9e4nr",
      "expanded_url" : "http:\/\/fxn.ws\/1zgGl42",
      "display_url" : "fxn.ws\/1zgGl42"
    } ]
  },
  "geo" : { },
  "id_str" : "592832540639113216",
  "text" : "RT @FoxNews: PHOTOS: Violent riots break out following the funeral of Freddie Gray. #BaltimoreRiots http:\/\/t.co\/lBkGr9e4nr http:\/\/t.co\/mG1v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/592818293800607745\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mG1vQeVVYf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDodGAFWIAApyNd.jpg",
        "id_str" : "592818289891483648",
        "id" : 592818289891483648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDodGAFWIAApyNd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mG1vQeVVYf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/592818293800607745\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mG1vQeVVYf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDodGJ-WgAEqTZe.jpg",
        "id_str" : "592818292546502657",
        "id" : 592818292546502657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDodGJ-WgAEqTZe.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mG1vQeVVYf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/592818293800607745\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mG1vQeVVYf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDodGBTWIAEKrR-.jpg",
        "id_str" : "592818290218639361",
        "id" : 592818290218639361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDodGBTWIAEKrR-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mG1vQeVVYf"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/592818293800607745\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mG1vQeVVYf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDodGJ9WEAAUh1n.jpg",
        "id_str" : "592818292542279680",
        "id" : 592818292542279680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDodGJ9WEAAUh1n.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mG1vQeVVYf"
      } ],
      "hashtags" : [ {
        "text" : "BaltimoreRiots",
        "indices" : [ 71, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/lBkGr9e4nr",
        "expanded_url" : "http:\/\/fxn.ws\/1zgGl42",
        "display_url" : "fxn.ws\/1zgGl42"
      } ]
    },
    "geo" : { },
    "id_str" : "592818293800607745",
    "text" : "PHOTOS: Violent riots break out following the funeral of Freddie Gray. #BaltimoreRiots http:\/\/t.co\/lBkGr9e4nr http:\/\/t.co\/mG1vQeVVYf",
    "id" : 592818293800607745,
    "created_at" : "2015-04-27 22:31:09 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 592832540639113216,
  "created_at" : "2015-04-27 23:27:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 9, 17 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/592832020373463040\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Ui19XHZOwi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDoplJ8WIAALXNj.png",
      "id_str" : "592832019253567488",
      "id" : 592832019253567488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDoplJ8WIAALXNj.png",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ui19XHZOwi"
    } ],
    "hashtags" : [ {
      "text" : "NO2ISIS",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592832020373463040",
  "in_reply_to_user_id" : 17874544,
  "text" : "@Support @Twitter I think these accounts need to be reported and removed from twitter. #NO2ISIS http:\/\/t.co\/Ui19XHZOwi",
  "id" : 592832020373463040,
  "created_at" : "2015-04-27 23:25:42 +0000",
  "in_reply_to_screen_name" : "TwitterSupport",
  "in_reply_to_user_id_str" : "17874544",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coptic",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592373630987710464",
  "text" : "I love the #Coptic Church",
  "id" : 592373630987710464,
  "created_at" : "2015-04-26 17:04:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Awesomeness",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592152494433677312",
  "text" : "Had a Graduation party today, was super nice, saw lots of awesome people!!! :) #Awesomeness",
  "id" : 592152494433677312,
  "created_at" : "2015-04-26 02:25:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591676732941316096",
  "text" : "Vinson Mansour made my day!!! Really cool person!!! :P",
  "id" : 591676732941316096,
  "created_at" : "2015-04-24 18:55:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "indices" : [ 0, 11 ],
      "id_str" : "836656141",
      "id" : 836656141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583680541469323264",
  "geo" : { },
  "id_str" : "591401066001997824",
  "in_reply_to_user_id" : 836656141,
  "text" : "@TheJoyCamp LOL",
  "id" : 591401066001997824,
  "in_reply_to_status_id" : 583680541469323264,
  "created_at" : "2015-04-24 00:39:36 +0000",
  "in_reply_to_screen_name" : "TheJoyCamp",
  "in_reply_to_user_id_str" : "836656141",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "indices" : [ 3, 14 ],
      "id_str" : "836656141",
      "id" : 836656141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zdNcUCLLd0",
      "expanded_url" : "http:\/\/fb.me\/7aXzBdf2s",
      "display_url" : "fb.me\/7aXzBdf2s"
    } ]
  },
  "geo" : { },
  "id_str" : "591401042727800832",
  "text" : "RT @TheJoyCamp: Amazon drone delivers its first package, and you won't believe what happens next! **MUST WATCH**... http:\/\/t.co\/zdNcUCLLd0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/zdNcUCLLd0",
        "expanded_url" : "http:\/\/fb.me\/7aXzBdf2s",
        "display_url" : "fb.me\/7aXzBdf2s"
      } ]
    },
    "geo" : { },
    "id_str" : "583680541469323264",
    "text" : "Amazon drone delivers its first package, and you won't believe what happens next! **MUST WATCH**... http:\/\/t.co\/zdNcUCLLd0",
    "id" : 583680541469323264,
    "created_at" : "2015-04-02 17:21:00 +0000",
    "user" : {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "protected" : false,
      "id_str" : "836656141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420722584498364416\/TLr800yk_normal.jpeg",
      "id" : 836656141,
      "verified" : false
    }
  },
  "id" : 591401042727800832,
  "created_at" : "2015-04-24 00:39:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591400735612530688",
  "text" : "Goodness Gracious great balls of tired!!!",
  "id" : 591400735612530688,
  "created_at" : "2015-04-24 00:38:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Udemy",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591400633498001409",
  "text" : "Man I need more #Udemy Students :P",
  "id" : 591400633498001409,
  "created_at" : "2015-04-24 00:37:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590888027817439232",
  "geo" : { },
  "id_str" : "591399058431938561",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Can't wait Colin, and I pray for your safety :P",
  "id" : 591399058431938561,
  "in_reply_to_status_id" : 590888027817439232,
  "created_at" : "2015-04-24 00:31:37 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591398953754750976",
  "text" : "RT @colin_furze: @gamer456148 next Thursday we should be running every week till July I hope and beyond.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "590872503389523968",
    "geo" : { },
    "id_str" : "590888027817439232",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 next Thursday we should be running every week till July I hope and beyond.",
    "id" : 590888027817439232,
    "in_reply_to_status_id" : 590872503389523968,
    "created_at" : "2015-04-22 14:40:58 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 591398953754750976,
  "created_at" : "2015-04-24 00:31:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590872503389523968",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze When is the next new video coming around?",
  "id" : 590872503389523968,
  "created_at" : "2015-04-22 13:39:17 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/589862016363405312\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xZ2YB2WzEo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC-cWfgWMAEtc4P.jpg",
      "id_str" : "589861986437050369",
      "id" : 589861986437050369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC-cWfgWMAEtc4P.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xZ2YB2WzEo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590872187264901121",
  "text" : "RT @colin_furze: New videos are on the horizon as the parts come together. It's rocking that's for sure. http:\/\/t.co\/xZ2YB2WzEo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/589862016363405312\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/xZ2YB2WzEo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CC-cWfgWMAEtc4P.jpg",
        "id_str" : "589861986437050369",
        "id" : 589861986437050369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC-cWfgWMAEtc4P.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xZ2YB2WzEo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589862016363405312",
    "text" : "New videos are on the horizon as the parts come together. It's rocking that's for sure. http:\/\/t.co\/xZ2YB2WzEo",
    "id" : 589862016363405312,
    "created_at" : "2015-04-19 18:43:58 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 590872187264901121,
  "created_at" : "2015-04-22 13:38:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/590470149314056193\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jRYQnipCFA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDHFdBtWAAA_waf.jpg",
      "id_str" : "590470128627744768",
      "id" : 590470128627744768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDHFdBtWAAA_waf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jRYQnipCFA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590872168575078400",
  "text" : "RT @colin_furze: The sun is shining and the shed look out is open. Lots of creating going on today. http:\/\/t.co\/jRYQnipCFA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/590470149314056193\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/jRYQnipCFA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDHFdBtWAAA_waf.jpg",
        "id_str" : "590470128627744768",
        "id" : 590470128627744768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDHFdBtWAAA_waf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jRYQnipCFA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590470149314056193",
    "text" : "The sun is shining and the shed look out is open. Lots of creating going on today. http:\/\/t.co\/jRYQnipCFA",
    "id" : 590470149314056193,
    "created_at" : "2015-04-21 11:00:28 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 590872168575078400,
  "created_at" : "2015-04-22 13:37:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590871711878287360",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech You are so close to 50k subscribers!!!",
  "id" : 590871711878287360,
  "created_at" : "2015-04-22 13:36:08 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Purcell",
      "screen_name" : "CaveOfProgram",
      "indices" : [ 0, 14 ],
      "id_str" : "1026900296",
      "id" : 1026900296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590870849185390592",
  "in_reply_to_user_id" : 1026900296,
  "text" : "@CaveOfProgram I see you have more and more students each day. Frankly, I am impressed!!!",
  "id" : 590870849185390592,
  "created_at" : "2015-04-22 13:32:42 +0000",
  "in_reply_to_screen_name" : "CaveOfProgram",
  "in_reply_to_user_id_str" : "1026900296",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590870319730008065",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki What advice do you have for a young aspiring entrepreneur and inventor?",
  "id" : 590870319730008065,
  "created_at" : "2015-04-22 13:30:36 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Lemonis",
      "screen_name" : "marcuslemonis",
      "indices" : [ 83, 97 ],
      "id_str" : "27801361",
      "id" : 27801361
    }, {
      "name" : "CNBC's The Profit",
      "screen_name" : "TheProfitCNBC",
      "indices" : [ 98, 112 ],
      "id_str" : "2800292898",
      "id" : 2800292898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShareTheProfit",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590719358437085184",
  "text" : "That Hank person was so disrespectful after all Mr.Lemonis done for his business.  @marcuslemonis @TheProfitCNBC #ShareTheProfit",
  "id" : 590719358437085184,
  "created_at" : "2015-04-22 03:30:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Awesomeness",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590265492733984768",
  "text" : "Went to my Aunt's house and saw two bundles of Joy as always #Awesomeness",
  "id" : 590265492733984768,
  "created_at" : "2015-04-20 21:27:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TGIF",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "Food",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "Shoes",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "Stuff",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588732946548273152",
  "text" : "Had a fun day, again, can you guess what happened, lol, jk #TGIF #Food #Shoes #Stuff",
  "id" : 588732946548273152,
  "created_at" : "2015-04-16 15:57:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/588391573030703105\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/sJlbrHg2ee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpjBKLUwAAoMvs.jpg",
      "id_str" : "588391572888141824",
      "id" : 588391572888141824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpjBKLUwAAoMvs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sJlbrHg2ee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588391573030703105",
  "text" : "Had a frozen Mocha at Biggby's, then ate a cheeseburger at Sahara's Grill, now for orientation. http:\/\/t.co\/sJlbrHg2ee",
  "id" : 588391573030703105,
  "created_at" : "2015-04-15 17:20:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coded",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588095880156295170",
  "text" : "What have you #coded?",
  "id" : 588095880156295170,
  "created_at" : "2015-04-14 21:45:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588095741689786370",
  "text" : "RT @elonmusk: Ascent successful. Dragon enroute to Space Station. Rocket landed on droneship, but too hard for survival.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588076749562318849",
    "text" : "Ascent successful. Dragon enroute to Space Station. Rocket landed on droneship, but too hard for survival.",
    "id" : 588076749562318849,
    "created_at" : "2015-04-14 20:29:57 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 588095741689786370,
  "created_at" : "2015-04-14 21:45:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/588082574183903232\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/eJWzN6KSJa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CClJ-UsW0AEpNnd.jpg",
      "id_str" : "588082561404030977",
      "id" : 588082561404030977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClJ-UsW0AEpNnd.jpg",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 941
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 941
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 941
      } ],
      "display_url" : "pic.twitter.com\/eJWzN6KSJa"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/588082574183903232\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/eJWzN6KSJa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CClJ-UuW4AAKOog.jpg",
      "id_str" : "588082561412423680",
      "id" : 588082561412423680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClJ-UuW4AAKOog.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 929
      } ],
      "display_url" : "pic.twitter.com\/eJWzN6KSJa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588095581039501312",
  "text" : "RT @elonmusk: Looks like Falcon landed fine, but excess lateral velocity caused it to tip over post landing http:\/\/t.co\/eJWzN6KSJa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/588082574183903232\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/eJWzN6KSJa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CClJ-UsW0AEpNnd.jpg",
        "id_str" : "588082561404030977",
        "id" : 588082561404030977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClJ-UsW0AEpNnd.jpg",
        "sizes" : [ {
          "h" : 522,
          "resize" : "fit",
          "w" : 941
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 941
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 941
        } ],
        "display_url" : "pic.twitter.com\/eJWzN6KSJa"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/588082574183903232\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/eJWzN6KSJa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CClJ-UuW4AAKOog.jpg",
        "id_str" : "588082561412423680",
        "id" : 588082561412423680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClJ-UuW4AAKOog.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 929
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 929
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 929
        } ],
        "display_url" : "pic.twitter.com\/eJWzN6KSJa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588082574183903232",
    "text" : "Looks like Falcon landed fine, but excess lateral velocity caused it to tip over post landing http:\/\/t.co\/eJWzN6KSJa",
    "id" : 588082574183903232,
    "created_at" : "2015-04-14 20:53:06 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 588095581039501312,
  "created_at" : "2015-04-14 21:44:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jinri Park",
      "screen_name" : "jinri_88",
      "indices" : [ 0, 9 ],
      "id_str" : "298516405",
      "id" : 298516405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588093774666059776",
  "in_reply_to_user_id" : 298516405,
  "text" : "@jinri_88 I wonder if I ask the beautiful and talented Jinri Park for a retweet, she would do it!!! :P",
  "id" : 588093774666059776,
  "created_at" : "2015-04-14 21:37:36 +0000",
  "in_reply_to_screen_name" : "jinri_88",
  "in_reply_to_user_id_str" : "298516405",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Is the Bible Moral?",
      "screen_name" : "isthebiblemoral",
      "indices" : [ 0, 16 ],
      "id_str" : "2523267661",
      "id" : 2523267661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584579743133081600",
  "geo" : { },
  "id_str" : "587262524699111424",
  "in_reply_to_user_id" : 2523267661,
  "text" : "@isthebiblemoral Your whole twitter account is a mockery to yourself. Instead of mocking others, why not get into intellectual discussions?",
  "id" : 587262524699111424,
  "in_reply_to_status_id" : 584579743133081600,
  "created_at" : "2015-04-12 14:34:31 +0000",
  "in_reply_to_screen_name" : "isthebiblemoral",
  "in_reply_to_user_id_str" : "2523267661",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coletta Kariger",
      "screen_name" : "ColettaKariger",
      "indices" : [ 0, 15 ],
      "id_str" : "3015963139",
      "id" : 3015963139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586798294636060672",
  "geo" : { },
  "id_str" : "587009658801491968",
  "in_reply_to_user_id" : 3015963139,
  "text" : "@ColettaKariger What help do you have in mind sir?",
  "id" : 587009658801491968,
  "in_reply_to_status_id" : 586798294636060672,
  "created_at" : "2015-04-11 21:49:43 +0000",
  "in_reply_to_screen_name" : "ColettaKariger",
  "in_reply_to_user_id_str" : "3015963139",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Larry Kudlow",
      "screen_name" : "larry_kudlow",
      "indices" : [ 36, 49 ],
      "id_str" : "44401911",
      "id" : 44401911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ikaz51zpHE",
      "expanded_url" : "http:\/\/player.listenlive.co\/25211",
      "display_url" : "player.listenlive.co\/25211"
    } ]
  },
  "geo" : { },
  "id_str" : "587007213820059649",
  "text" : "RT @tedcruz: On the radio LIVE with @larry_kudlow right now. Listen here: http:\/\/t.co\/ikaz51zpHE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Larry Kudlow",
        "screen_name" : "larry_kudlow",
        "indices" : [ 23, 36 ],
        "id_str" : "44401911",
        "id" : 44401911
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/ikaz51zpHE",
        "expanded_url" : "http:\/\/player.listenlive.co\/25211",
        "display_url" : "player.listenlive.co\/25211"
      } ]
    },
    "geo" : { },
    "id_str" : "586901019948294146",
    "text" : "On the radio LIVE with @larry_kudlow right now. Listen here: http:\/\/t.co\/ikaz51zpHE",
    "id" : 586901019948294146,
    "created_at" : "2015-04-11 14:38:01 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 587007213820059649,
  "created_at" : "2015-04-11 21:40:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/587006929618264066\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/4eZrMLegGo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCV3sTDWgAAfbge.jpg",
      "id_str" : "587006929353998336",
      "id" : 587006929353998336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCV3sTDWgAAfbge.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4eZrMLegGo"
    } ],
    "hashtags" : [ {
      "text" : "Fun",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587006929618264066",
  "text" : "Got this new today #Fun http:\/\/t.co\/4eZrMLegGo",
  "id" : 587006929618264066,
  "created_at" : "2015-04-11 21:38:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/586180974108606466\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/1nKios8LQb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKIfXfWgAEryC9.jpg",
      "id_str" : "586180973974421505",
      "id" : 586180973974421505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKIfXfWgAEryC9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1nKios8LQb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586180974108606466",
  "text" : "Had Blueberry pancakes \uD83D\uDE0A http:\/\/t.co\/1nKios8LQb",
  "id" : 586180974108606466,
  "created_at" : "2015-04-09 14:56:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585564477535477762",
  "text" : "Goodness gracious, it is all over the place, LOL",
  "id" : 585564477535477762,
  "created_at" : "2015-04-07 22:07:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kotaku",
      "screen_name" : "Kotaku",
      "indices" : [ 3, 10 ],
      "id_str" : "11928542",
      "id" : 11928542
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kotaku\/status\/585507784592072705\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/EaXWvZ3ubd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAkOiBW4AA4NGM.png",
      "id_str" : "585507783627431936",
      "id" : 585507783627431936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAkOiBW4AA4NGM.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EaXWvZ3ubd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/AJuGK5G1pN",
      "expanded_url" : "http:\/\/bit.ly\/1N4rrUu",
      "display_url" : "bit.ly\/1N4rrUu"
    } ]
  },
  "geo" : { },
  "id_str" : "585564417179439104",
  "text" : "RT @Kotaku: Warning: scammers are hiding malware behind fake Steam pages http:\/\/t.co\/AJuGK5G1pN http:\/\/t.co\/EaXWvZ3ubd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kotaku\/status\/585507784592072705\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/EaXWvZ3ubd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAkOiBW4AA4NGM.png",
        "id_str" : "585507783627431936",
        "id" : 585507783627431936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAkOiBW4AA4NGM.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/EaXWvZ3ubd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/AJuGK5G1pN",
        "expanded_url" : "http:\/\/bit.ly\/1N4rrUu",
        "display_url" : "bit.ly\/1N4rrUu"
      } ]
    },
    "geo" : { },
    "id_str" : "585507784592072705",
    "text" : "Warning: scammers are hiding malware behind fake Steam pages http:\/\/t.co\/AJuGK5G1pN http:\/\/t.co\/EaXWvZ3ubd",
    "id" : 585507784592072705,
    "created_at" : "2015-04-07 18:21:48 +0000",
    "user" : {
      "name" : "Kotaku",
      "screen_name" : "Kotaku",
      "protected" : false,
      "id_str" : "11928542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925726499294011398\/s2kPEKGx_normal.jpg",
      "id" : 11928542,
      "verified" : true
    }
  },
  "id" : 585564417179439104,
  "created_at" : "2015-04-07 22:06:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sponsored",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "automate",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "share",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "retweet",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "socialmedia",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/1lUMhJKuIA",
      "expanded_url" : "http:\/\/buff.ly\/1ahsfki",
      "display_url" : "buff.ly\/1ahsfki"
    } ]
  },
  "geo" : { },
  "id_str" : "585563387083546626",
  "text" : "#Sponsored I will teach you #automate #share #retweet your link 5 times a day for $25 http:\/\/t.co\/1lUMhJKuIA #socialmedia",
  "id" : 585563387083546626,
  "created_at" : "2015-04-07 22:02:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Family",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "Party",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "Headache",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584889412762206208",
  "text" : "Had so much fun!!! #Family #Party #Headache",
  "id" : 584889412762206208,
  "created_at" : "2015-04-06 01:24:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Awesomeness Bot",
      "screen_name" : "AwesomenessBot",
      "indices" : [ 3, 18 ],
      "id_str" : "1447732447",
      "id" : 1447732447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOOC",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "Blogposts",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "Awesomeness",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Czddme5SeH",
      "expanded_url" : "http:\/\/edustudio.org",
      "display_url" : "edustudio.org"
    } ]
  },
  "geo" : { },
  "id_str" : "584578016006799360",
  "text" : "RT @AwesomenessBot: I love making #MOOC Courses and #Blogposts on STEM, IT, and Design #Awesomeness http:\/\/t.co\/Czddme5SeH\n\n\u2014 Andrew Kamal \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOOC",
        "indices" : [ 14, 19 ]
      }, {
        "text" : "Blogposts",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "Awesomeness",
        "indices" : [ 67, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Czddme5SeH",
        "expanded_url" : "http:\/\/edustudio.org",
        "display_url" : "edustudio.org"
      } ]
    },
    "geo" : { },
    "id_str" : "581184648618835968",
    "text" : "I love making #MOOC Courses and #Blogposts on STEM, IT, and Design #Awesomeness http:\/\/t.co\/Czddme5SeH\n\n\u2014 Andrew Kamal (gamer456148) Marc\u2026",
    "id" : 581184648618835968,
    "created_at" : "2015-03-26 20:03:12 +0000",
    "user" : {
      "name" : "The Awesomeness Bot",
      "screen_name" : "AwesomenessBot",
      "protected" : false,
      "id_str" : "1447732447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574216295412973568\/oKKQMEtH_normal.png",
      "id" : 1447732447,
      "verified" : false
    }
  },
  "id" : 584578016006799360,
  "created_at" : "2015-04-05 04:47:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FULyAnWLEX",
      "expanded_url" : "http:\/\/youtu.be\/PhKJaKA0wLw?a",
      "display_url" : "youtu.be\/PhKJaKA0wLw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "584575571318943744",
  "text" : "RT @VigilantChrist: Radical Sex Ed Curriculum Being Pushed in Ontario Canada! FIGHT BACK PARENTS !!! http:\/\/t.co\/FULyAnWLEX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/FULyAnWLEX",
        "expanded_url" : "http:\/\/youtu.be\/PhKJaKA0wLw?a",
        "display_url" : "youtu.be\/PhKJaKA0wLw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "582567616297836544",
    "text" : "Radical Sex Ed Curriculum Being Pushed in Ontario Canada! FIGHT BACK PARENTS !!! http:\/\/t.co\/FULyAnWLEX",
    "id" : 582567616297836544,
    "created_at" : "2015-03-30 15:38:37 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 584575571318943744,
  "created_at" : "2015-04-05 04:37:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Df4hGnEz9u",
      "expanded_url" : "http:\/\/fb.me\/7tcdhIPZ9",
      "display_url" : "fb.me\/7tcdhIPZ9"
    } ]
  },
  "geo" : { },
  "id_str" : "584147674636619777",
  "text" : "I already chose Ted Cruz as the one I would likely vote for. This just proves my point. My original choice was... http:\/\/t.co\/Df4hGnEz9u",
  "id" : 584147674636619777,
  "created_at" : "2015-04-04 00:17:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vxn8TvOahA",
      "expanded_url" : "http:\/\/fb.me\/6DPmNYHmx",
      "display_url" : "fb.me\/6DPmNYHmx"
    } ]
  },
  "geo" : { },
  "id_str" : "584142573637394432",
  "text" : "I am done with Bill O'Reilly, this isn't his first slip. Michael Savage, Rush Limbaugh and Sean Hannity will be... http:\/\/t.co\/vxn8TvOahA",
  "id" : 584142573637394432,
  "created_at" : "2015-04-03 23:56:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sponsored",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ZkFBDHqr55",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.Tokmak.DragonSimulator",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    }, {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/zSefnou6HJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=VxUYSOjfsHo",
      "display_url" : "youtube.com\/watch?v=VxUYSO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583760433779204098",
  "text" : "New 3D Dragon Game: (HD graphics) #Sponsored \nhttps:\/\/t.co\/ZkFBDHqr55\nhttps:\/\/t.co\/zSefnou6HJ",
  "id" : 583760433779204098,
  "created_at" : "2015-04-02 22:38:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "April",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583448067346718720",
  "text" : "I need to stop going so far on #April Fools, jk",
  "id" : 583448067346718720,
  "created_at" : "2015-04-02 01:57:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maple",
      "indices" : [ 11, 17 ]
    }, {
      "text" : "eating",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583447956889542656",
  "text" : "I just had #Maple chocolate, what have I been #eating all these years!!!",
  "id" : 583447956889542656,
  "created_at" : "2015-04-02 01:56:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]