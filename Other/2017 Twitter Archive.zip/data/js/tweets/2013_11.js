Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zsUDXfziKN",
      "expanded_url" : "http:\/\/sdrv.ms\/1jVY8j1",
      "display_url" : "sdrv.ms\/1jVY8j1"
    } ]
  },
  "geo" : { },
  "id_str" : "406950699264512000",
  "text" : "Took astropics today, went to a party, hung out with little ones, yeah it was that day http:\/\/t.co\/zsUDXfziKN",
  "id" : 406950699264512000,
  "created_at" : "2013-12-01 00:59:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406636503385640960",
  "text" : "Goat cheese on Italian bread= yum",
  "id" : 406636503385640960,
  "created_at" : "2013-11-30 04:11:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406593779022307328",
  "text" : "Vids dang spell checker",
  "id" : 406593779022307328,
  "created_at" : "2013-11-30 01:21:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406593654351204352",
  "text" : "Watched the first 43min of the host, it sucked, guess how many movies and bids I watched so far, lol",
  "id" : 406593654351204352,
  "created_at" : "2013-11-30 01:20:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406166094307946496",
  "text" : "When I said something big is happing yesterday I was talking about comet ison and its meet with the sun",
  "id" : 406166094307946496,
  "created_at" : "2013-11-28 21:01:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406165867248902144",
  "text" : "The little ones are so cute, thanksgiving is a time for the family",
  "id" : 406165867248902144,
  "created_at" : "2013-11-28 21:01:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406165027813466113",
  "text" : "Will comet ison survive? :)",
  "id" : 406165027813466113,
  "created_at" : "2013-11-28 20:57:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406149053559627776",
  "text" : "It snowed today",
  "id" : 406149053559627776,
  "created_at" : "2013-11-28 19:54:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406039038416924672",
  "text" : "So sleepy still",
  "id" : 406039038416924672,
  "created_at" : "2013-11-28 12:37:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406038936247869440",
  "text" : "Missed the comet, was woken up late, sorry guys, but their are more chances, anyways look at my last photos",
  "id" : 406038936247869440,
  "created_at" : "2013-11-28 12:36:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978562152247296",
  "text" : "Lol :)",
  "id" : 405978562152247296,
  "created_at" : "2013-11-28 08:36:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978483261579264",
  "text" : "Man why am I even explaining it to you",
  "id" : 405978483261579264,
  "created_at" : "2013-11-28 08:36:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978375581229056",
  "text" : "Later",
  "id" : 405978375581229056,
  "created_at" : "2013-11-28 08:36:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978351351111680",
  "text" : "And something even bigger will happen layer on",
  "id" : 405978351351111680,
  "created_at" : "2013-11-28 08:35:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978250025127936",
  "text" : "Today something is happening,.lets just say it involves astrophysics, lol",
  "id" : 405978250025127936,
  "created_at" : "2013-11-28 08:35:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405978100497801216",
  "text" : "Lol",
  "id" : 405978100497801216,
  "created_at" : "2013-11-28 08:34:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405977997058265088",
  "text" : "Guess what movies and vids I watched",
  "id" : 405977997058265088,
  "created_at" : "2013-11-28 08:34:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/TN5Lnw0Ytw",
      "expanded_url" : "http:\/\/sdrv.ms\/1jMFMkh",
      "display_url" : "sdrv.ms\/1jMFMkh"
    } ]
  },
  "geo" : { },
  "id_str" : "405970874320158720",
  "text" : "Zoom in this photo http:\/\/t.co\/TN5Lnw0Ytw",
  "id" : 405970874320158720,
  "created_at" : "2013-11-28 08:06:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405947622592360449",
  "text" : "My astrophotography will hopefully be awesome tommorow, lol",
  "id" : 405947622592360449,
  "created_at" : "2013-11-28 06:33:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405920282797686784",
  "text" : "Take amazing astrophotos Tommorow guys",
  "id" : 405920282797686784,
  "created_at" : "2013-11-28 04:45:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405919927229370369",
  "text" : "Lol, bye for now",
  "id" : 405919927229370369,
  "created_at" : "2013-11-28 04:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405919813249150976",
  "text" : "Comet Ison appears, Tommorow everything changes",
  "id" : 405919813249150976,
  "created_at" : "2013-11-28 04:43:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405919310624735232",
  "text" : "Mom made me wings today, awesome mom",
  "id" : 405919310624735232,
  "created_at" : "2013-11-28 04:41:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405900845805756416",
  "text" : "My mom got me a rasberry pi Linux board with tft screen, gonna make a review when it comes, my mom is so kind and generous",
  "id" : 405900845805756416,
  "created_at" : "2013-11-28 03:27:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/88ZEDO1bV0",
      "expanded_url" : "http:\/\/sdrv.ms\/1iUMLdi",
      "display_url" : "sdrv.ms\/1iUMLdi"
    } ]
  },
  "geo" : { },
  "id_str" : "405846764424413186",
  "text" : "Zoom into this http:\/\/t.co\/88ZEDO1bV0",
  "id" : 405846764424413186,
  "created_at" : "2013-11-27 23:53:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/aQJhy4DZDE",
      "expanded_url" : "http:\/\/sdrv.ms\/1boLFFa",
      "display_url" : "sdrv.ms\/1boLFFa"
    } ]
  },
  "geo" : { },
  "id_str" : "405796763358871552",
  "text" : "They came http:\/\/t.co\/aQJhy4DZDE",
  "id" : 405796763358871552,
  "created_at" : "2013-11-27 20:34:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405756707928039426",
  "text" : "Do it",
  "id" : 405756707928039426,
  "created_at" : "2013-11-27 17:55:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405756678777606144",
  "text" : "Become Coptic today",
  "id" : 405756678777606144,
  "created_at" : "2013-11-27 17:55:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405756622406180864",
  "text" : "The previous pope of the catholic church turned out gay, wow, where are Catholics heading",
  "id" : 405756622406180864,
  "created_at" : "2013-11-27 17:54:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/UOk3pn5LZ7",
      "expanded_url" : "http:\/\/sdrv.ms\/1bmFoKd",
      "display_url" : "sdrv.ms\/1bmFoKd"
    } ]
  },
  "geo" : { },
  "id_str" : "405543969049686016",
  "text" : "Roastbeef sandwich oh yeah http:\/\/t.co\/UOk3pn5LZ7",
  "id" : 405543969049686016,
  "created_at" : "2013-11-27 03:49:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405536875688902656",
  "text" : "I am gonna go eat",
  "id" : 405536875688902656,
  "created_at" : "2013-11-27 03:21:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405536771087159298",
  "text" : "Lol the world messed up big time",
  "id" : 405536771087159298,
  "created_at" : "2013-11-27 03:21:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405536707832852480",
  "text" : "Pope Francis may just be a false profit, and Obama is surely the antichrist. I am Coptic orthodox by the way, nor catholic. God bless",
  "id" : 405536707832852480,
  "created_at" : "2013-11-27 03:21:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405135038343577600",
  "text" : "Something big will happen on the end of the year this is a warning",
  "id" : 405135038343577600,
  "created_at" : "2013-11-26 00:44:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405111407580311555",
  "text" : "Finally met the qualifications to get my drovers permit",
  "id" : 405111407580311555,
  "created_at" : "2013-11-25 23:11:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/57zzJRBnXj",
      "expanded_url" : "http:\/\/sdrv.ms\/1jxBZY4",
      "display_url" : "sdrv.ms\/1jxBZY4"
    } ]
  },
  "geo" : { },
  "id_str" : "404584098741514240",
  "text" : "Hello beardy http:\/\/t.co\/57zzJRBnXj",
  "id" : 404584098741514240,
  "created_at" : "2013-11-24 12:15:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404474797847228416",
  "text" : "Can you bros guess how many robots I have and what models they are",
  "id" : 404474797847228416,
  "created_at" : "2013-11-24 05:01:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404041091831582720",
  "text" : "Had nice lamb",
  "id" : 404041091831582720,
  "created_at" : "2013-11-23 00:17:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403865050500182016",
  "text" : "I like food",
  "id" : 403865050500182016,
  "created_at" : "2013-11-22 12:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403701193400389632",
  "text" : "Lol",
  "id" : 403701193400389632,
  "created_at" : "2013-11-22 01:47:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403701176988094464",
  "text" : "Watched Stanny Tendergrass on Netflix for Nintendo 3Ds",
  "id" : 403701176988094464,
  "created_at" : "2013-11-22 01:47:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403362910522466304",
  "text" : "Watched some episodes of how I met your mother on Nintendo 3Ds, I think the first episode of season 8 and the last two episodes",
  "id" : 403362910522466304,
  "created_at" : "2013-11-21 03:23:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/gofundme.com\" rel=\"nofollow\"\u003EGoFundMe\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gofundme",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/y3OcqeQzQO",
      "expanded_url" : "http:\/\/www.gofundme.com\/5df4yk",
      "display_url" : "gofundme.com\/5df4yk"
    } ]
  },
  "geo" : { },
  "id_str" : "403310070215098371",
  "text" : "I'm raising money for Help Change the World. Click to Donate: http:\/\/t.co\/y3OcqeQzQO #gofundme",
  "id" : 403310070215098371,
  "created_at" : "2013-11-20 23:53:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402936191664001024",
  "text" : "Ugg",
  "id" : 402936191664001024,
  "created_at" : "2013-11-19 23:07:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/6RHBsLXsip",
      "expanded_url" : "http:\/\/sdrv.ms\/1isxgJv",
      "display_url" : "sdrv.ms\/1isxgJv"
    } ]
  },
  "geo" : { },
  "id_str" : "402915527389368320",
  "text" : "hello http:\/\/t.co\/6RHBsLXsip",
  "id" : 402915527389368320,
  "created_at" : "2013-11-19 21:45:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401921210105483264",
  "text" : "Watched a movie :)",
  "id" : 401921210105483264,
  "created_at" : "2013-11-17 03:54:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401823443274170368",
  "text" : "Gonna get a subway, lol",
  "id" : 401823443274170368,
  "created_at" : "2013-11-16 21:25:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/rzgJ4HoIuP",
      "expanded_url" : "http:\/\/sdrv.ms\/1btMXJK",
      "display_url" : "sdrv.ms\/1btMXJK"
    } ]
  },
  "geo" : { },
  "id_str" : "401560723752779776",
  "text" : "Accessories for my future phone, lol http:\/\/t.co\/rzgJ4HoIuP",
  "id" : 401560723752779776,
  "created_at" : "2013-11-16 04:01:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401438217503014912",
  "text" : "Slurpee",
  "id" : 401438217503014912,
  "created_at" : "2013-11-15 19:55:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399740113896624128",
  "text" : "Celebrities are nasty, lol",
  "id" : 399740113896624128,
  "created_at" : "2013-11-11 03:27:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399628451579457536",
  "text" : "Had middle eastern cuisine, guess what, LOL",
  "id" : 399628451579457536,
  "created_at" : "2013-11-10 20:03:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399272776382832640",
  "text" : "Bet you can't guess what subway I had, LOL",
  "id" : 399272776382832640,
  "created_at" : "2013-11-09 20:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/tsE5Wcy31Z",
      "expanded_url" : "http:\/\/sdrv.ms\/1exuSB0",
      "display_url" : "sdrv.ms\/1exuSB0"
    } ]
  },
  "geo" : { },
  "id_str" : "399267567702786048",
  "text" : "Got a haircut http:\/\/t.co\/tsE5Wcy31Z",
  "id" : 399267567702786048,
  "created_at" : "2013-11-09 20:09:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399000211257040896",
  "text" : "Watched Jackass 2 on Netflix for Nintendo 3Ds 2\/5 stars",
  "id" : 399000211257040896,
  "created_at" : "2013-11-09 02:27:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398688431322464256",
  "text" : "Watched the rest on my phone to see if it deserves a second chance, it didn't and I am ashamed, lol",
  "id" : 398688431322464256,
  "created_at" : "2013-11-08 05:48:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398647967990951937",
  "text" : "Watched The the first 1hr and 49min of hunger games on Netflix for Nintendo 3Ds, total boring piece of crap",
  "id" : 398647967990951937,
  "created_at" : "2013-11-08 03:07:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398611909991477248",
  "text" : "Just had a sherma 2 xd",
  "id" : 398611909991477248,
  "created_at" : "2013-11-08 00:44:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398320357448638464",
  "text" : "Watched the avengers on Netflix for Nintendo 3Ds 4.5\/5 stars, a must see animation, lol",
  "id" : 398320357448638464,
  "created_at" : "2013-11-07 05:25:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397918070741946368",
  "text" : "He made fun of me at the end to",
  "id" : 397918070741946368,
  "created_at" : "2013-11-06 02:47:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397917703841009664",
  "text" : "I was thinking to myself, this guy doesn't  like me",
  "id" : 397917703841009664,
  "created_at" : "2013-11-06 02:45:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397917545367633921",
  "text" : "CEO of oculus rift harassed me on Facebook, LOL :P I blocked him",
  "id" : 397917545367633921,
  "created_at" : "2013-11-06 02:45:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397074238156591104",
  "text" : "I wish little Cesar's buffalo wings were spicier",
  "id" : 397074238156591104,
  "created_at" : "2013-11-03 18:54:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396864087864672256",
  "text" : "See the corruption going on",
  "id" : 396864087864672256,
  "created_at" : "2013-11-03 04:59:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396864011398307840",
  "text" : "See how the world changes",
  "id" : 396864011398307840,
  "created_at" : "2013-11-03 04:58:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396863965063819264",
  "text" : "See what's really crazy and what's not",
  "id" : 396863965063819264,
  "created_at" : "2013-11-03 04:58:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396863899007737857",
  "text" : "See what goes on and what happens",
  "id" : 396863899007737857,
  "created_at" : "2013-11-03 04:58:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396863846885105664",
  "text" : "Lol you guys think I am crazy but let's wait and see",
  "id" : 396863846885105664,
  "created_at" : "2013-11-03 04:58:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396863769324060672",
  "text" : "Michael Jackson, Oprah Winfrey, Joel Osteen, Miley Cyrus, all did satanic stuff, and Obama is the antichrist. Obama proclaimed evil words.",
  "id" : 396863769324060672,
  "created_at" : "2013-11-03 04:57:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396779683775537153",
  "text" : "Little kids are so cute, especially Hannah, went up and I carried get, lol, you guys got no idea who I am talking about, lol",
  "id" : 396779683775537153,
  "created_at" : "2013-11-02 23:23:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396650730540777472",
  "text" : "Yesterday I cried for the first time when reading the bible, such beautiful words",
  "id" : 396650730540777472,
  "created_at" : "2013-11-02 14:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396278645909884928",
  "text" : "When family talk bad about you behind your back, it hurts",
  "id" : 396278645909884928,
  "created_at" : "2013-11-01 14:12:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]