Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725803488781975553",
  "text" : "Had the Steak Fajita Quesadilla at El Patio in Troy, was amazing, 5\/5 stars",
  "id" : 725803488781975553,
  "created_at" : "2016-04-28 21:46:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "recycle_it",
      "screen_name" : "Recycle___it",
      "indices" : [ 3, 16 ],
      "id_str" : "379820199",
      "id" : 379820199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725402212801896449",
  "text" : "RT @Recycle___it: Mars landing by 2018 says SpaceX: Billionaire Elon Musk plans to send his Dragon spacecraft to Mars as early ... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/CDZD1Do7iH",
        "expanded_url" : "http:\/\/bbc.in\/1qUqDrJ",
        "display_url" : "bbc.in\/1qUqDrJ"
      } ]
    },
    "geo" : { },
    "id_str" : "725396856541306881",
    "text" : "Mars landing by 2018 says SpaceX: Billionaire Elon Musk plans to send his Dragon spacecraft to Mars as early ... https:\/\/t.co\/CDZD1Do7iH",
    "id" : 725396856541306881,
    "created_at" : "2016-04-27 18:51:02 +0000",
    "user" : {
      "name" : "recycle_it",
      "screen_name" : "Recycle___it",
      "protected" : false,
      "id_str" : "379820199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1559405270\/recycleitlogo2_normal.jpg",
      "id" : 379820199,
      "verified" : false
    }
  },
  "id" : 725402212801896449,
  "created_at" : "2016-04-27 19:12:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 0, 11 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725392076699889664",
  "geo" : { },
  "id_str" : "725401163709976577",
  "in_reply_to_user_id" : 305791165,
  "text" : "@WWEXStream Kids these days, all they have is a potty mouth mindlessly following godless media",
  "id" : 725401163709976577,
  "in_reply_to_status_id" : 725392076699889664,
  "created_at" : "2016-04-27 19:08:09 +0000",
  "in_reply_to_screen_name" : "WWEXStream",
  "in_reply_to_user_id_str" : "305791165",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725400931865600003",
  "text" : "RT @BarbaraCorcoran: Want to know my secrets to success? Persistence and instinct. And a whole lot of hard work!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725390363645583360",
    "text" : "Want to know my secrets to success? Persistence and instinct. And a whole lot of hard work!",
    "id" : 725390363645583360,
    "created_at" : "2016-04-27 18:25:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 725400931865600003,
  "created_at" : "2016-04-27 19:07:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 14, 26 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725399084736110594",
  "text" : "RT @Gillette: @gamer456148 We appreciate the love. Thanks for shaving with us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "725380295961223168",
    "geo" : { },
    "id_str" : "725382900401754112",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 We appreciate the love. Thanks for shaving with us.",
    "id" : 725382900401754112,
    "in_reply_to_status_id" : 725380295961223168,
    "created_at" : "2016-04-27 17:55:35 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 725399084736110594,
  "created_at" : "2016-04-27 18:59:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxwell",
      "screen_name" : "WalzMax22",
      "indices" : [ 3, 13 ],
      "id_str" : "910267698",
      "id" : 910267698
    }, {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 22, 31 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725380801559465984",
  "text" : "RT @WalzMax22: Thanks @Gillette for sending me another razor for my 18th bday.. (2 years later) keep sending them my way! My peach fuzz tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gillette",
        "screen_name" : "Gillette",
        "indices" : [ 7, 16 ],
        "id_str" : "33522196",
        "id" : 33522196
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725058599731482626",
    "text" : "Thanks @Gillette for sending me another razor for my 18th bday.. (2 years later) keep sending them my way! My peach fuzz thanks you!!",
    "id" : 725058599731482626,
    "created_at" : "2016-04-26 20:26:55 +0000",
    "user" : {
      "name" : "Maxwell",
      "screen_name" : "WalzMax22",
      "protected" : false,
      "id_str" : "910267698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919395063184134144\/CL9J2D8Q_normal.jpg",
      "id" : 910267698,
      "verified" : false
    }
  },
  "id" : 725380801559465984,
  "created_at" : "2016-04-27 17:47:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 0, 9 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/725380295961223168\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/odpROR3JuX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChERgesWgAMSsQ7.jpg",
      "id_str" : "725380264675934211",
      "id" : 725380264675934211,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChERgesWgAMSsQ7.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/odpROR3JuX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725380295961223168",
  "in_reply_to_user_id" : 33522196,
  "text" : "@Gillette This is why you guys are my favorite, always the best in razors https:\/\/t.co\/odpROR3JuX",
  "id" : 725380295961223168,
  "created_at" : "2016-04-27 17:45:14 +0000",
  "in_reply_to_screen_name" : "Gillette",
  "in_reply_to_user_id_str" : "33522196",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83C\uDF89",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725197706851835905",
  "geo" : { },
  "id_str" : "725351500671778817",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine Just wow!!!",
  "id" : 725351500671778817,
  "in_reply_to_status_id" : 725197706851835905,
  "created_at" : "2016-04-27 15:50:48 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/725215035212062720\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/PHHYkBYuMu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChB7O1fWIAAeb5r.jpg",
      "id_str" : "725215034813587456",
      "id" : 725215034813587456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChB7O1fWIAAeb5r.jpg",
      "sizes" : [ {
        "h" : 694,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/PHHYkBYuMu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725351426071867394",
  "text" : "RT @saatchi_gallery: Fallen Furniture has repurposed a Boeing 737 Engine into its '737 Cowling Chair'. https:\/\/t.co\/PHHYkBYuMu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/725215035212062720\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/PHHYkBYuMu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChB7O1fWIAAeb5r.jpg",
        "id_str" : "725215034813587456",
        "id" : 725215034813587456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChB7O1fWIAAeb5r.jpg",
        "sizes" : [ {
          "h" : 694,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 860
        } ],
        "display_url" : "pic.twitter.com\/PHHYkBYuMu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725215035212062720",
    "text" : "Fallen Furniture has repurposed a Boeing 737 Engine into its '737 Cowling Chair'. https:\/\/t.co\/PHHYkBYuMu",
    "id" : 725215035212062720,
    "created_at" : "2016-04-27 06:48:32 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 725351426071867394,
  "created_at" : "2016-04-27 15:50:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725351268458352644",
  "text" : "RT @Matthiasiam: One of the biggest proponents to success in any avenue, is simply not shooting yourself in the foot.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725332704258973697",
    "text" : "One of the biggest proponents to success in any avenue, is simply not shooting yourself in the foot.",
    "id" : 725332704258973697,
    "created_at" : "2016-04-27 14:36:07 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929487527995510784\/Hzr8H3DU_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 725351268458352644,
  "created_at" : "2016-04-27 15:49:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donny Goines",
      "screen_name" : "DonnyGoines",
      "indices" : [ 3, 15 ],
      "id_str" : "16744854",
      "id" : 16744854
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Positive",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725351241040203780",
  "text" : "RT @DonnyGoines: #Positive I was never here for competition. I was always a fan of cooperation. They didn't get it though. Cool. They'll un\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Positive",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725334729516527618",
    "text" : "#Positive I was never here for competition. I was always a fan of cooperation. They didn't get it though. Cool. They'll understand later.",
    "id" : 725334729516527618,
    "created_at" : "2016-04-27 14:44:10 +0000",
    "user" : {
      "name" : "Donny Goines",
      "screen_name" : "DonnyGoines",
      "protected" : false,
      "id_str" : "16744854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/939572300315283456\/YLYZUAVS_normal.jpg",
      "id" : 16744854,
      "verified" : false
    }
  },
  "id" : 725351241040203780,
  "created_at" : "2016-04-27 15:49:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN Politics",
      "screen_name" : "CNNPolitics",
      "indices" : [ 3, 15 ],
      "id_str" : "13850422",
      "id" : 13850422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/6OZtrfIwim",
      "expanded_url" : "http:\/\/cnnpolitics.com",
      "display_url" : "cnnpolitics.com"
    } ]
  },
  "geo" : { },
  "id_str" : "725351196073009152",
  "text" : "RT @CNNPolitics: Ted Cruz asks Indiana to unify behind a \"positive, optimistic, forward-looking\" campaign https:\/\/t.co\/6OZtrfIwim https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/6OZtrfIwim",
        "expanded_url" : "http:\/\/cnnpolitics.com",
        "display_url" : "cnnpolitics.com"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/6YA1LdhGtn",
        "expanded_url" : "http:\/\/cnn.it\/1NTd5lq",
        "display_url" : "cnn.it\/1NTd5lq"
      } ]
    },
    "geo" : { },
    "id_str" : "725323565336289280",
    "text" : "Ted Cruz asks Indiana to unify behind a \"positive, optimistic, forward-looking\" campaign https:\/\/t.co\/6OZtrfIwim https:\/\/t.co\/6YA1LdhGtn",
    "id" : 725323565336289280,
    "created_at" : "2016-04-27 13:59:48 +0000",
    "user" : {
      "name" : "CNN Politics",
      "screen_name" : "CNNPolitics",
      "protected" : false,
      "id_str" : "13850422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918899077168934912\/NrRRE0_b_normal.jpg",
      "id" : 13850422,
      "verified" : true
    }
  },
  "id" : 725351196073009152,
  "created_at" : "2016-04-27 15:49:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725351137369534465",
  "text" : "RT @seanhannity: .@realDonaldTrump: \"In business they put you in jail for collusion. In politics you're allowed to get away with it.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725144323730317312",
    "text" : ".@realDonaldTrump: \"In business they put you in jail for collusion. In politics you're allowed to get away with it.\"",
    "id" : 725144323730317312,
    "created_at" : "2016-04-27 02:07:33 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 725351137369534465,
  "created_at" : "2016-04-27 15:49:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strayer University",
      "screen_name" : "StrayerU",
      "indices" : [ 0, 9 ],
      "id_str" : "27076996",
      "id" : 27076996
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/725351029450149890\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Js5xvo6wEV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChD26usVEAEk3Fp.jpg",
      "id_str" : "725351028833456129",
      "id" : 725351028833456129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChD26usVEAEk3Fp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 302
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 302
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 302
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 302
      } ],
      "display_url" : "pic.twitter.com\/Js5xvo6wEV"
    } ],
    "hashtags" : [ {
      "text" : "Entreprenurship",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725351029450149890",
  "in_reply_to_user_id" : 27076996,
  "text" : "@StrayerU Oh Yeah #Entreprenurship https:\/\/t.co\/Js5xvo6wEV",
  "id" : 725351029450149890,
  "created_at" : "2016-04-27 15:48:56 +0000",
  "in_reply_to_screen_name" : "StrayerU",
  "in_reply_to_user_id_str" : "27076996",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/725126062670229509\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/UniZaZeR2k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChAqLuHWYAAnZ_P.jpg",
      "id_str" : "725125920852434944",
      "id" : 725125920852434944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChAqLuHWYAAnZ_P.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/UniZaZeR2k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725126062670229509",
  "text" : "Cherry Turkish Delight \uD83D\uDE0D https:\/\/t.co\/UniZaZeR2k",
  "id" : 725126062670229509,
  "created_at" : "2016-04-27 00:55:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Chen",
      "screen_name" : "OOFAFAC0C0",
      "indices" : [ 0, 11 ],
      "id_str" : "2974660052",
      "id" : 2974660052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725051171421966338",
  "geo" : { },
  "id_str" : "725102176582942720",
  "in_reply_to_user_id" : 2974660052,
  "text" : "@OOFAFAC0C0 That's one of the worst ideas I heard in a while",
  "id" : 725102176582942720,
  "in_reply_to_status_id" : 725051171421966338,
  "created_at" : "2016-04-26 23:20:05 +0000",
  "in_reply_to_screen_name" : "OOFAFAC0C0",
  "in_reply_to_user_id_str" : "2974660052",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "flaggETERNAL",
      "screen_name" : "alexelbourne42",
      "indices" : [ 3, 18 ],
      "id_str" : "128103430",
      "id" : 128103430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ElectionPlotTwist",
      "indices" : [ 62, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725101872256827393",
  "text" : "RT @alexelbourne42: It turns out your vote REALLY does count. #ElectionPlotTwist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ElectionPlotTwist",
        "indices" : [ 42, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725076650933772288",
    "text" : "It turns out your vote REALLY does count. #ElectionPlotTwist",
    "id" : 725076650933772288,
    "created_at" : "2016-04-26 21:38:39 +0000",
    "user" : {
      "name" : "flaggETERNAL",
      "screen_name" : "alexelbourne42",
      "protected" : false,
      "id_str" : "128103430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722914610714517504\/Q7lXF2HC_normal.jpg",
      "id" : 128103430,
      "verified" : false
    }
  },
  "id" : 725101872256827393,
  "created_at" : "2016-04-26 23:18:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillaryClinton",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725101548007727104",
  "text" : "RT @laguna4bernie: #HillaryClinton's approval numbers skyrocket across U.S. upon announcing she's withdrawing from Democratic primary race.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillaryClinton",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "ElectionPlotTwist",
        "indices" : [ 121, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725092280210718720",
    "text" : "#HillaryClinton's approval numbers skyrocket across U.S. upon announcing she's withdrawing from Democratic primary race. #ElectionPlotTwist",
    "id" : 725092280210718720,
    "created_at" : "2016-04-26 22:40:45 +0000",
    "user" : {
      "name" : "The Worthy Struggle",
      "screen_name" : "visionofjustice",
      "protected" : false,
      "id_str" : "277800457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814993841732235264\/M2YvPWvU_normal.jpg",
      "id" : 277800457,
      "verified" : false
    }
  },
  "id" : 725101548007727104,
  "created_at" : "2016-04-26 23:17:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier P\u00E9rez",
      "screen_name" : "DOUBTMYPROGRESS",
      "indices" : [ 3, 19 ],
      "id_str" : "365889796",
      "id" : 365889796
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 42, 57 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DOUBTMYPROGRESS\/status\/725094227885989888\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Qmq3PacI5L",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChANSunVEAA5HtL.jpg",
      "id_str" : "725094155408445440",
      "id" : 725094155408445440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChANSunVEAA5HtL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 490
      } ],
      "display_url" : "pic.twitter.com\/Qmq3PacI5L"
    } ],
    "hashtags" : [ {
      "text" : "ElectionPlotTwist",
      "indices" : [ 21, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725101493750251520",
  "text" : "RT @DOUBTMYPROGRESS: #ElectionPlotTwist \n\n@HillaryClinton tells the truth... https:\/\/t.co\/Qmq3PacI5L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 21, 36 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DOUBTMYPROGRESS\/status\/725094227885989888\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Qmq3PacI5L",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChANSunVEAA5HtL.jpg",
        "id_str" : "725094155408445440",
        "id" : 725094155408445440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChANSunVEAA5HtL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 490
        } ],
        "display_url" : "pic.twitter.com\/Qmq3PacI5L"
      } ],
      "hashtags" : [ {
        "text" : "ElectionPlotTwist",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725094227885989888",
    "text" : "#ElectionPlotTwist \n\n@HillaryClinton tells the truth... https:\/\/t.co\/Qmq3PacI5L",
    "id" : 725094227885989888,
    "created_at" : "2016-04-26 22:48:30 +0000",
    "user" : {
      "name" : "Xavier P\u00E9rez",
      "screen_name" : "DOUBTMYPROGRESS",
      "protected" : false,
      "id_str" : "365889796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801959883167907842\/TJu_BQY3_normal.jpg",
      "id" : 365889796,
      "verified" : false
    }
  },
  "id" : 725101493750251520,
  "created_at" : "2016-04-26 23:17:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Confused Electorate",
      "screen_name" : "Conf_Electorate",
      "indices" : [ 3, 19 ],
      "id_str" : "724813213171355650",
      "id" : 724813213171355650
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 91, 106 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ElectionPlotTwist",
      "indices" : [ 107, 125 ]
    }, {
      "text" : "DemPrimary",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725101446438506496",
  "text" : "RT @Conf_Electorate: Bill at polling stations with his sax hoping to woo female voters for @HillaryClinton #ElectionPlotTwist #DemPrimary h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 70, 85 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Conf_Electorate\/status\/725095891720359937\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LefhxC6jxF",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChAOPKRWYAAtZ_Z.jpg",
        "id_str" : "725095193624600576",
        "id" : 725095193624600576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChAOPKRWYAAtZ_Z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 402
        } ],
        "display_url" : "pic.twitter.com\/LefhxC6jxF"
      } ],
      "hashtags" : [ {
        "text" : "ElectionPlotTwist",
        "indices" : [ 86, 104 ]
      }, {
        "text" : "DemPrimary",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725095891720359937",
    "text" : "Bill at polling stations with his sax hoping to woo female voters for @HillaryClinton #ElectionPlotTwist #DemPrimary https:\/\/t.co\/LefhxC6jxF",
    "id" : 725095891720359937,
    "created_at" : "2016-04-26 22:55:06 +0000",
    "user" : {
      "name" : "Confused Electorate",
      "screen_name" : "Conf_Electorate",
      "protected" : false,
      "id_str" : "724813213171355650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732728738551468032\/rREHTK8e_normal.jpg",
      "id" : 724813213171355650,
      "verified" : false
    }
  },
  "id" : 725101446438506496,
  "created_at" : "2016-04-26 23:17:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DNCuLater",
      "screen_name" : "threatcon5",
      "indices" : [ 3, 14 ],
      "id_str" : "242980410",
      "id" : 242980410
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/threatcon5\/status\/725099648638017536\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/M3PSjb0jHm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChASSQ0U8AEtLv4.jpg",
      "id_str" : "725099644968038401",
      "id" : 725099644968038401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChASSQ0U8AEtLv4.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/M3PSjb0jHm"
    } ],
    "hashtags" : [ {
      "text" : "ElectionPlotTwist",
      "indices" : [ 16, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725101180825784320",
  "text" : "RT @threatcon5: #ElectionPlotTwist -Clinton releases Goldman Sachs' transcript https:\/\/t.co\/M3PSjb0jHm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/threatcon5\/status\/725099648638017536\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/M3PSjb0jHm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChASSQ0U8AEtLv4.jpg",
        "id_str" : "725099644968038401",
        "id" : 725099644968038401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChASSQ0U8AEtLv4.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/M3PSjb0jHm"
      } ],
      "hashtags" : [ {
        "text" : "ElectionPlotTwist",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725099648638017536",
    "text" : "#ElectionPlotTwist -Clinton releases Goldman Sachs' transcript https:\/\/t.co\/M3PSjb0jHm",
    "id" : 725099648638017536,
    "created_at" : "2016-04-26 23:10:02 +0000",
    "user" : {
      "name" : "DNCuLater",
      "screen_name" : "threatcon5",
      "protected" : false,
      "id_str" : "242980410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911423406289104896\/HNawk97h_normal.jpg",
      "id" : 242980410,
      "verified" : false
    }
  },
  "id" : 725101180825784320,
  "created_at" : "2016-04-26 23:16:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean",
      "screen_name" : "sergebomba",
      "indices" : [ 3, 14 ],
      "id_str" : "298247947",
      "id" : 298247947
    }, {
      "name" : "Jillian",
      "screen_name" : "Pheramuse",
      "indices" : [ 68, 78 ],
      "id_str" : "27112844",
      "id" : 27112844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsTodayin4Words",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725100867091861505",
  "text" : "RT @sergebomba: Can't function without cellphone #KidsTodayin4Words @Pheramuse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jillian",
        "screen_name" : "Pheramuse",
        "indices" : [ 52, 62 ],
        "id_str" : "27112844",
        "id" : 27112844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsTodayin4Words",
        "indices" : [ 33, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725085730716946434",
    "text" : "Can't function without cellphone #KidsTodayin4Words @Pheramuse",
    "id" : 725085730716946434,
    "created_at" : "2016-04-26 22:14:44 +0000",
    "user" : {
      "name" : "Sean",
      "screen_name" : "sergebomba",
      "protected" : false,
      "id_str" : "298247947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922585005800460289\/uSSqGM_G_normal.jpg",
      "id" : 298247947,
      "verified" : false
    }
  },
  "id" : 725100867091861505,
  "created_at" : "2016-04-26 23:14:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JESS",
      "screen_name" : "imjessjackson",
      "indices" : [ 3, 17 ],
      "id_str" : "384390029",
      "id" : 384390029
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsTodayin4Words",
      "indices" : [ 38, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725100756886536192",
  "text" : "RT @imjessjackson: I PRAY FOR THEM \uD83D\uDE4C\uD83C\uDFFE #KidsTodayin4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsTodayin4Words",
        "indices" : [ 19, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725090491046498304",
    "text" : "I PRAY FOR THEM \uD83D\uDE4C\uD83C\uDFFE #KidsTodayin4Words",
    "id" : 725090491046498304,
    "created_at" : "2016-04-26 22:33:39 +0000",
    "user" : {
      "name" : "JESS",
      "screen_name" : "imjessjackson",
      "protected" : false,
      "id_str" : "384390029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947670547143553025\/GvXP7QcU_normal.jpg",
      "id" : 384390029,
      "verified" : false
    }
  },
  "id" : 725100756886536192,
  "created_at" : "2016-04-26 23:14:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S",
      "screen_name" : "FoundersGirl",
      "indices" : [ 3, 16 ],
      "id_str" : "887905129",
      "id" : 887905129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsTodayin4Words",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725100688129298438",
  "text" : "RT @FoundersGirl: Every one's a winner.\n\n #KidsTodayin4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsTodayin4Words",
        "indices" : [ 24, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725096582866071554",
    "text" : "Every one's a winner.\n\n #KidsTodayin4Words",
    "id" : 725096582866071554,
    "created_at" : "2016-04-26 22:57:51 +0000",
    "user" : {
      "name" : "S",
      "screen_name" : "FoundersGirl",
      "protected" : false,
      "id_str" : "887905129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/949009314252902401\/1-m0cKVp_normal.jpg",
      "id" : 887905129,
      "verified" : false
    }
  },
  "id" : 725100688129298438,
  "created_at" : "2016-04-26 23:14:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New year, same me.",
      "screen_name" : "A_A_Ron_Rodgers",
      "indices" : [ 3, 19 ],
      "id_str" : "417564363",
      "id" : 417564363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsTodayin4Words",
      "indices" : [ 41, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725100666105024512",
  "text" : "RT @A_A_Ron_Rodgers: Pluto was a planet? #KidsTodayin4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsTodayin4Words",
        "indices" : [ 20, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725100166529732608",
    "text" : "Pluto was a planet? #KidsTodayin4Words",
    "id" : 725100166529732608,
    "created_at" : "2016-04-26 23:12:06 +0000",
    "user" : {
      "name" : "New year, same me.",
      "screen_name" : "A_A_Ron_Rodgers",
      "protected" : false,
      "id_str" : "417564363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925222199539130369\/U15EON_A_normal.jpg",
      "id" : 417564363,
      "verified" : false
    }
  },
  "id" : 725100666105024512,
  "created_at" : "2016-04-26 23:14:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/724946992250642432\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Vx1hbWVhaA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-HcqLUUAEIDC4.jpg",
      "id_str" : "724946991457783809",
      "id" : 724946991457783809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-HcqLUUAEIDC4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Vx1hbWVhaA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/HsBlCTnrTb",
      "expanded_url" : "http:\/\/engt.co\/1Tb1vUv",
      "display_url" : "engt.co\/1Tb1vUv"
    } ]
  },
  "geo" : { },
  "id_str" : "725099678778462209",
  "text" : "RT @engadget: Giroptic's 360-degree waterproof camera starts shipping https:\/\/t.co\/HsBlCTnrTb https:\/\/t.co\/Vx1hbWVhaA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/724946992250642432\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/Vx1hbWVhaA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-HcqLUUAEIDC4.jpg",
        "id_str" : "724946991457783809",
        "id" : 724946991457783809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-HcqLUUAEIDC4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Vx1hbWVhaA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/HsBlCTnrTb",
        "expanded_url" : "http:\/\/engt.co\/1Tb1vUv",
        "display_url" : "engt.co\/1Tb1vUv"
      } ]
    },
    "geo" : { },
    "id_str" : "724946992250642432",
    "text" : "Giroptic's 360-degree waterproof camera starts shipping https:\/\/t.co\/HsBlCTnrTb https:\/\/t.co\/Vx1hbWVhaA",
    "id" : 724946992250642432,
    "created_at" : "2016-04-26 13:03:26 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 725099678778462209,
  "created_at" : "2016-04-26 23:10:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/725072379353960449\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/lcAMZaZGyk",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg_5fA-WIAAOdHe.jpg",
      "id_str" : "725072376262696960",
      "id" : 725072376262696960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg_5fA-WIAAOdHe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/lcAMZaZGyk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/5jIKb9hMvx",
      "expanded_url" : "http:\/\/engt.co\/1qQUnFT",
      "display_url" : "engt.co\/1qQUnFT"
    } ]
  },
  "geo" : { },
  "id_str" : "725099360489508864",
  "text" : "RT @engadget: Hover Camera is a safe and foldable drone that follows you https:\/\/t.co\/5jIKb9hMvx https:\/\/t.co\/lcAMZaZGyk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/725072379353960449\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/lcAMZaZGyk",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg_5fA-WIAAOdHe.jpg",
        "id_str" : "725072376262696960",
        "id" : 725072376262696960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cg_5fA-WIAAOdHe.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/lcAMZaZGyk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/5jIKb9hMvx",
        "expanded_url" : "http:\/\/engt.co\/1qQUnFT",
        "display_url" : "engt.co\/1qQUnFT"
      } ]
    },
    "geo" : { },
    "id_str" : "725072379353960449",
    "text" : "Hover Camera is a safe and foldable drone that follows you https:\/\/t.co\/5jIKb9hMvx https:\/\/t.co\/lcAMZaZGyk",
    "id" : 725072379353960449,
    "created_at" : "2016-04-26 21:21:41 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 725099360489508864,
  "created_at" : "2016-04-26 23:08:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/725078455642107906\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/w5oBYwGNeS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg__A1tVEAAfmmQ.jpg",
      "id_str" : "725078454912225280",
      "id" : 725078454912225280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg__A1tVEAAfmmQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/w5oBYwGNeS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/WgCkNgGEgq",
      "expanded_url" : "http:\/\/engt.co\/1Tcl8LK",
      "display_url" : "engt.co\/1Tcl8LK"
    } ]
  },
  "geo" : { },
  "id_str" : "725099312238190593",
  "text" : "RT @engadget: Tech giants push Congress for K-12 computer science education https:\/\/t.co\/WgCkNgGEgq https:\/\/t.co\/w5oBYwGNeS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/725078455642107906\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/w5oBYwGNeS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg__A1tVEAAfmmQ.jpg",
        "id_str" : "725078454912225280",
        "id" : 725078454912225280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg__A1tVEAAfmmQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/w5oBYwGNeS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/WgCkNgGEgq",
        "expanded_url" : "http:\/\/engt.co\/1Tcl8LK",
        "display_url" : "engt.co\/1Tcl8LK"
      } ]
    },
    "geo" : { },
    "id_str" : "725078455642107906",
    "text" : "Tech giants push Congress for K-12 computer science education https:\/\/t.co\/WgCkNgGEgq https:\/\/t.co\/w5oBYwGNeS",
    "id" : 725078455642107906,
    "created_at" : "2016-04-26 21:45:49 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 725099312238190593,
  "created_at" : "2016-04-26 23:08:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTBOG",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/AlYcfVX8JQ",
      "expanded_url" : "http:\/\/engt.co\/1WhwF1i",
      "display_url" : "engt.co\/1WhwF1i"
    } ]
  },
  "geo" : { },
  "id_str" : "725099254671400960",
  "text" : "RT @engadget: (WATCH) 'On the Brink of Greatness' Episode 8: Startup pitches to first graders &gt;&gt; https:\/\/t.co\/AlYcfVX8JQ #OTBOG https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTBOG",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/AlYcfVX8JQ",
        "expanded_url" : "http:\/\/engt.co\/1WhwF1i",
        "display_url" : "engt.co\/1WhwF1i"
      }, {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Y4AuDLNLMO",
        "expanded_url" : "http:\/\/snpy.tv\/1VHn0Tt",
        "display_url" : "snpy.tv\/1VHn0Tt"
      } ]
    },
    "geo" : { },
    "id_str" : "723568333333766145",
    "text" : "(WATCH) 'On the Brink of Greatness' Episode 8: Startup pitches to first graders &gt;&gt; https:\/\/t.co\/AlYcfVX8JQ #OTBOG https:\/\/t.co\/Y4AuDLNLMO",
    "id" : 723568333333766145,
    "created_at" : "2016-04-22 17:45:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 725099254671400960,
  "created_at" : "2016-04-26 23:08:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fatty Fanegas",
      "screen_name" : "_drfatty",
      "indices" : [ 3, 12 ],
      "id_str" : "4311069562",
      "id" : 4311069562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/VuiPI3L2Ji",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=N6W3US8Luo8&ab_channel=colinfurze",
      "display_url" : "youtube.com\/watch?v=N6W3US\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725099173306048512",
  "text" : "RT @_drfatty: srsly tho https:\/\/t.co\/VuiPI3L2Ji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/VuiPI3L2Ji",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=N6W3US8Luo8&ab_channel=colinfurze",
        "display_url" : "youtube.com\/watch?v=N6W3US\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716771008364077060",
    "text" : "srsly tho https:\/\/t.co\/VuiPI3L2Ji",
    "id" : 716771008364077060,
    "created_at" : "2016-04-03 23:35:00 +0000",
    "user" : {
      "name" : "Fatty Fanegas",
      "screen_name" : "_drfatty",
      "protected" : false,
      "id_str" : "4311069562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903751181759107073\/2sqy9k4t_normal.jpg",
      "id" : 4311069562,
      "verified" : false
    }
  },
  "id" : 725099173306048512,
  "created_at" : "2016-04-26 23:08:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Drool",
      "screen_name" : "_thedailydrool",
      "indices" : [ 3, 18 ],
      "id_str" : "3728020872",
      "id" : 3728020872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/EyCBAHEdPZ",
      "expanded_url" : "http:\/\/9GAG.tv",
      "display_url" : "9GAG.tv"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fH9SBBMmNP",
      "expanded_url" : "http:\/\/fb.me\/7I40Hu0yk",
      "display_url" : "fb.me\/7I40Hu0yk"
    } ]
  },
  "geo" : { },
  "id_str" : "725098947732234241",
  "text" : "RT @_thedailydrool: Watch This British Dude Go Crazy With His Homemade Thermite Launcher | https:\/\/t.co\/EyCBAHEdPZ https:\/\/t.co\/fH9SBBMmNP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/EyCBAHEdPZ",
        "expanded_url" : "http:\/\/9GAG.tv",
        "display_url" : "9GAG.tv"
      }, {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/fH9SBBMmNP",
        "expanded_url" : "http:\/\/fb.me\/7I40Hu0yk",
        "display_url" : "fb.me\/7I40Hu0yk"
      } ]
    },
    "geo" : { },
    "id_str" : "718120298663571457",
    "text" : "Watch This British Dude Go Crazy With His Homemade Thermite Launcher | https:\/\/t.co\/EyCBAHEdPZ https:\/\/t.co\/fH9SBBMmNP",
    "id" : 718120298663571457,
    "created_at" : "2016-04-07 16:56:35 +0000",
    "user" : {
      "name" : "The Daily Drool",
      "screen_name" : "_thedailydrool",
      "protected" : false,
      "id_str" : "3728020872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648915789370658816\/8FEdwmRw_normal.png",
      "id" : 3728020872,
      "verified" : false
    }
  },
  "id" : 725098947732234241,
  "created_at" : "2016-04-26 23:07:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/722455448893419520\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Nla8FoK7LC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgatYpHW4AAs43F.jpg",
      "id_str" : "722455429104721920",
      "id" : 722455429104721920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgatYpHW4AAs43F.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/Nla8FoK7LC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725098782363422721",
  "text" : "RT @colin_furze: Got a new apprentice on the colinfurze youtube channel, he's on a week trial. https:\/\/t.co\/Nla8FoK7LC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/722455448893419520\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/Nla8FoK7LC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgatYpHW4AAs43F.jpg",
        "id_str" : "722455429104721920",
        "id" : 722455429104721920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgatYpHW4AAs43F.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/Nla8FoK7LC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722455448893419520",
    "text" : "Got a new apprentice on the colinfurze youtube channel, he's on a week trial. https:\/\/t.co\/Nla8FoK7LC",
    "id" : 722455448893419520,
    "created_at" : "2016-04-19 16:02:56 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 725098782363422721,
  "created_at" : "2016-04-26 23:06:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShortyShifter",
      "screen_name" : "ShortyShifter",
      "indices" : [ 3, 17 ],
      "id_str" : "4916773099",
      "id" : 4916773099
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fly",
      "indices" : [ 94, 98 ]
    }, {
      "text" : "motorcycle",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725098689782505474",
  "text" : "RT @ShortyShifter: It's not a bike with wheels, it's a bike with 2 prop engines! Make it fly! #fly #colinfurze#motovlog #motorcycle  https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fly",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "motorcycle",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/cmvxWYzfhP",
        "expanded_url" : "http:\/\/youtu.be\/1ToBgypNwL4",
        "display_url" : "youtu.be\/1ToBgypNwL4"
      } ]
    },
    "geo" : { },
    "id_str" : "723451230924595201",
    "text" : "It's not a bike with wheels, it's a bike with 2 prop engines! Make it fly! #fly #colinfurze#motovlog #motorcycle  https:\/\/t.co\/cmvxWYzfhP",
    "id" : 723451230924595201,
    "created_at" : "2016-04-22 09:59:49 +0000",
    "user" : {
      "name" : "ShortyShifter",
      "screen_name" : "ShortyShifter",
      "protected" : false,
      "id_str" : "4916773099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699631804991471616\/CeX7VPSs_normal.jpg",
      "id" : 4916773099,
      "verified" : false
    }
  },
  "id" : 725098689782505474,
  "created_at" : "2016-04-26 23:06:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vessel",
      "screen_name" : "Vessel",
      "indices" : [ 3, 10 ],
      "id_str" : "2395399387",
      "id" : 2395399387
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 45, 57 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/OLc9idwrRg",
      "expanded_url" : "https:\/\/www.vessel.com\/videos\/IwyFsIqHT",
      "display_url" : "vessel.com\/videos\/IwyFsIq\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725098327994470403",
  "text" : "RT @Vessel: The masses have spoken: You want @colin_furze to FLY! So, here's the plan of attack: https:\/\/t.co\/OLc9idwrRg https:\/\/t.co\/IKez6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 33, 45 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Vessel\/status\/720721056764444673\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/IKez66NvKE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCD-zyW8AA3kF8.jpg",
        "id_str" : "720721055455834112",
        "id" : 720721055455834112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCD-zyW8AA3kF8.jpg",
        "sizes" : [ {
          "h" : 693,
          "resize" : "fit",
          "w" : 1277
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 1277
        } ],
        "display_url" : "pic.twitter.com\/IKez66NvKE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/OLc9idwrRg",
        "expanded_url" : "https:\/\/www.vessel.com\/videos\/IwyFsIqHT",
        "display_url" : "vessel.com\/videos\/IwyFsIq\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720721056764444673",
    "text" : "The masses have spoken: You want @colin_furze to FLY! So, here's the plan of attack: https:\/\/t.co\/OLc9idwrRg https:\/\/t.co\/IKez66NvKE",
    "id" : 720721056764444673,
    "created_at" : "2016-04-14 21:11:04 +0000",
    "user" : {
      "name" : "Vessel",
      "screen_name" : "Vessel",
      "protected" : false,
      "id_str" : "2395399387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621484111530627072\/jgbjI6YI_normal.jpg",
      "id" : 2395399387,
      "verified" : true
    }
  },
  "id" : 725098327994470403,
  "created_at" : "2016-04-26 23:04:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725098067830165504",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze You remind me of myself but with 100 times more energy, seriously keep doing awesome builds!!!",
  "id" : 725098067830165504,
  "created_at" : "2016-04-26 23:03:45 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Unlearn",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/LdQ111h4Uv",
      "expanded_url" : "http:\/\/bit.ly\/23LTlwP",
      "display_url" : "bit.ly\/23LTlwP"
    } ]
  },
  "geo" : { },
  "id_str" : "725097780017004546",
  "text" : "RT @colin_furze: Will it get of the ground? Will it just flip over? My hardest ever build for sure  #Unlearn https:\/\/t.co\/LdQ111h4Uv https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/724126451457495040\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/kl6RUf3XXF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgydK4PWkAA6uRs.jpg",
        "id_str" : "724126450320838656",
        "id" : 724126450320838656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgydK4PWkAA6uRs.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/kl6RUf3XXF"
      } ],
      "hashtags" : [ {
        "text" : "Unlearn",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/LdQ111h4Uv",
        "expanded_url" : "http:\/\/bit.ly\/23LTlwP",
        "display_url" : "bit.ly\/23LTlwP"
      } ]
    },
    "geo" : { },
    "id_str" : "724126451457495040",
    "text" : "Will it get of the ground? Will it just flip over? My hardest ever build for sure  #Unlearn https:\/\/t.co\/LdQ111h4Uv https:\/\/t.co\/kl6RUf3XXF",
    "id" : 724126451457495040,
    "created_at" : "2016-04-24 06:42:54 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 725097780017004546,
  "created_at" : "2016-04-26 23:02:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alcantara",
      "screen_name" : "AlcantaraSpa",
      "indices" : [ 0, 13 ],
      "id_str" : "518470631",
      "id" : 518470631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721699738068889600",
  "geo" : { },
  "id_str" : "724628543246733312",
  "in_reply_to_user_id" : 518470631,
  "text" : "@AlcantaraSpa Alternative energy is a viable solution for when we run out of diesel as a commodity",
  "id" : 724628543246733312,
  "in_reply_to_status_id" : 721699738068889600,
  "created_at" : "2016-04-25 15:58:02 +0000",
  "in_reply_to_screen_name" : "AlcantaraSpa",
  "in_reply_to_user_id_str" : "518470631",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alcantara",
      "screen_name" : "AlcantaraSpa",
      "indices" : [ 3, 16 ],
      "id_str" : "518470631",
      "id" : 518470631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInItaly",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724628326287986688",
  "text" : "RT @AlcantaraSpa: Polishing our silver on Mondays: here's the Adularia mood from our #MadeInItaly fashion collection. https:\/\/t.co\/vn2eu36X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlcantaraSpa\/status\/722062132100141056\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/vn2eu36Xt8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVHrtaWcAAih5_.jpg",
        "id_str" : "722062131512897536",
        "id" : 722062131512897536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVHrtaWcAAih5_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vn2eu36Xt8"
      } ],
      "hashtags" : [ {
        "text" : "MadeInItaly",
        "indices" : [ 67, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722062132100141056",
    "text" : "Polishing our silver on Mondays: here's the Adularia mood from our #MadeInItaly fashion collection. https:\/\/t.co\/vn2eu36Xt8",
    "id" : 722062132100141056,
    "created_at" : "2016-04-18 14:00:02 +0000",
    "user" : {
      "name" : "Alcantara",
      "screen_name" : "AlcantaraSpa",
      "protected" : false,
      "id_str" : "518470631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606002441562267648\/MrnoAkRH_normal.jpg",
      "id" : 518470631,
      "verified" : false
    }
  },
  "id" : 724628326287986688,
  "created_at" : "2016-04-25 15:57:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon Carrington",
      "screen_name" : "LeonCarrington",
      "indices" : [ 3, 18 ],
      "id_str" : "136102085",
      "id" : 136102085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724627920736514048",
  "text" : "RT @LeonCarrington: Until people's opinions start paying your bills, tell them to go kick a bag of rocks and take several seats!\n#mondaymot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 109, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724624078661890050",
    "text" : "Until people's opinions start paying your bills, tell them to go kick a bag of rocks and take several seats!\n#mondaymotivation",
    "id" : 724624078661890050,
    "created_at" : "2016-04-25 15:40:17 +0000",
    "user" : {
      "name" : "Leon Carrington",
      "screen_name" : "LeonCarrington",
      "protected" : false,
      "id_str" : "136102085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441670223800717312\/pgw7UJ4v_normal.png",
      "id" : 136102085,
      "verified" : false
    }
  },
  "id" : 724627920736514048,
  "created_at" : "2016-04-25 15:55:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "indices" : [ 3, 10 ],
      "id_str" : "263814100",
      "id" : 263814100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnergyToExcel",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724391090514726913",
  "text" : "RT @uptime: Use the weekend wisely, this is a great opportunity to recharge and take on next week with a full head of steam #EnergyToExcel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EnergyToExcel",
        "indices" : [ 112, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614854438776238084",
    "text" : "Use the weekend wisely, this is a great opportunity to recharge and take on next week with a full head of steam #EnergyToExcel",
    "id" : 614854438776238084,
    "created_at" : "2015-06-27 17:54:56 +0000",
    "user" : {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "protected" : false,
      "id_str" : "263814100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504330138230616065\/sKW4KfgD_normal.png",
      "id" : 263814100,
      "verified" : false
    }
  },
  "id" : 724391090514726913,
  "created_at" : "2016-04-25 00:14:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "indices" : [ 0, 7 ],
      "id_str" : "263814100",
      "id" : 263814100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724390755603759105",
  "in_reply_to_user_id" : 263814100,
  "text" : "@uptime I like your drinks, just has a kick after taste, like most energy drinks do.",
  "id" : 724390755603759105,
  "created_at" : "2016-04-25 00:13:09 +0000",
  "in_reply_to_screen_name" : "uptime",
  "in_reply_to_user_id_str" : "263814100",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/seanhannity\/status\/724015253365895168\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/S8JuBOvqer",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgw4CWZWIAAbmdM.jpg",
      "id_str" : "724015253122588672",
      "id" : 724015253122588672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgw4CWZWIAAbmdM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/S8JuBOvqer"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724090979658027008",
  "text" : "RT @seanhannity: Meet Marley. New pup. Thank you Majestic Manor Golden's in Indiana. https:\/\/t.co\/S8JuBOvqer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/seanhannity\/status\/724015253365895168\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/S8JuBOvqer",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgw4CWZWIAAbmdM.jpg",
        "id_str" : "724015253122588672",
        "id" : 724015253122588672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgw4CWZWIAAbmdM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/S8JuBOvqer"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724015253365895168",
    "text" : "Meet Marley. New pup. Thank you Majestic Manor Golden's in Indiana. https:\/\/t.co\/S8JuBOvqer",
    "id" : 724015253365895168,
    "created_at" : "2016-04-23 23:21:02 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 724090979658027008,
  "created_at" : "2016-04-24 04:21:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724079713099079680",
  "geo" : { },
  "id_str" : "724090500240707587",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget Well",
  "id" : 724090500240707587,
  "in_reply_to_status_id" : 724079713099079680,
  "created_at" : "2016-04-24 04:20:02 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Averebely",
      "screen_name" : "AVerebely",
      "indices" : [ 3, 13 ],
      "id_str" : "20413959",
      "id" : 20413959
    }, {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "indices" : [ 15, 30 ],
      "id_str" : "78523300",
      "id" : 78523300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724090055153721346",
  "text" : "RT @AVerebely: @RealJamesWoods A symbol of the world he lives in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Woods",
        "screen_name" : "RealJamesWoods",
        "indices" : [ 0, 15 ],
        "id_str" : "78523300",
        "id" : 78523300
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723914001235644416",
    "geo" : { },
    "id_str" : "723958098659008512",
    "in_reply_to_user_id" : 78523300,
    "text" : "@RealJamesWoods A symbol of the world he lives in",
    "id" : 723958098659008512,
    "in_reply_to_status_id" : 723914001235644416,
    "created_at" : "2016-04-23 19:33:55 +0000",
    "in_reply_to_screen_name" : "RealJamesWoods",
    "in_reply_to_user_id_str" : "78523300",
    "user" : {
      "name" : "Averebely",
      "screen_name" : "AVerebely",
      "protected" : false,
      "id_str" : "20413959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943487954525261825\/RVt2oIQo_normal.jpg",
      "id" : 20413959,
      "verified" : false
    }
  },
  "id" : 724090055153721346,
  "created_at" : "2016-04-24 04:18:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Gingold",
      "screen_name" : "ScottGingold",
      "indices" : [ 3, 16 ],
      "id_str" : "31953101",
      "id" : 31953101
    }, {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "indices" : [ 22, 37 ],
      "id_str" : "78523300",
      "id" : 78523300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724089999264632834",
  "text" : "RT @ScottGingold: Hey @RealJamesWoods how about \"look what I learned to do in my 2 terms?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Woods",
        "screen_name" : "RealJamesWoods",
        "indices" : [ 4, 19 ],
        "id_str" : "78523300",
        "id" : 78523300
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723914001235644416",
    "geo" : { },
    "id_str" : "723924695511367680",
    "in_reply_to_user_id" : 78523300,
    "text" : "Hey @RealJamesWoods how about \"look what I learned to do in my 2 terms?\"",
    "id" : 723924695511367680,
    "in_reply_to_status_id" : 723914001235644416,
    "created_at" : "2016-04-23 17:21:11 +0000",
    "in_reply_to_screen_name" : "RealJamesWoods",
    "in_reply_to_user_id_str" : "78523300",
    "user" : {
      "name" : "Scott Gingold",
      "screen_name" : "ScottGingold",
      "protected" : false,
      "id_str" : "31953101",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2772967624\/afff4fa151d86dabc687dbade9321e0e_normal.png",
      "id" : 31953101,
      "verified" : false
    }
  },
  "id" : 724089999264632834,
  "created_at" : "2016-04-24 04:18:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razor",
      "screen_name" : "hale_razor",
      "indices" : [ 3, 14 ],
      "id_str" : "21888595",
      "id" : 21888595
    }, {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "indices" : [ 16, 31 ],
      "id_str" : "78523300",
      "id" : 78523300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724089790388293632",
  "text" : "RT @hale_razor: @RealJamesWoods an empty transparent mass of hot air... and a bubble.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Woods",
        "screen_name" : "RealJamesWoods",
        "indices" : [ 0, 15 ],
        "id_str" : "78523300",
        "id" : 78523300
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723914001235644416",
    "geo" : { },
    "id_str" : "723914587960016897",
    "in_reply_to_user_id" : 78523300,
    "text" : "@RealJamesWoods an empty transparent mass of hot air... and a bubble.",
    "id" : 723914587960016897,
    "in_reply_to_status_id" : 723914001235644416,
    "created_at" : "2016-04-23 16:41:02 +0000",
    "in_reply_to_screen_name" : "RealJamesWoods",
    "in_reply_to_user_id_str" : "78523300",
    "user" : {
      "name" : "Razor",
      "screen_name" : "hale_razor",
      "protected" : false,
      "id_str" : "21888595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2380046121\/m8z6jimxzlj8vikfnu4f_normal.png",
      "id" : 21888595,
      "verified" : false
    }
  },
  "id" : 724089790388293632,
  "created_at" : "2016-04-24 04:17:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/723924397065641984\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/MRDQnlpWjD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgvlXhXU4AAkcYw.jpg",
      "id_str" : "723924357379055616",
      "id" : 723924357379055616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgvlXhXU4AAkcYw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/MRDQnlpWjD"
    } ],
    "hashtags" : [ {
      "text" : "Eco",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723924397065641984",
  "text" : "Shell's new concept car #Eco https:\/\/t.co\/MRDQnlpWjD",
  "id" : 723924397065641984,
  "created_at" : "2016-04-23 17:20:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723924134187700224",
  "text" : "Had the Detroit Motown Burger @ Cobo 3.94\/5 stars",
  "id" : 723924134187700224,
  "created_at" : "2016-04-23 17:18:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 3, 9 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 11, 23 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723704307057610752",
  "text" : "RT @klout: @gamer456148 Hi there- thanks for reaching out. Understand your disappointment. We're investing in other areas of Klout's data a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723237018193506304",
    "geo" : { },
    "id_str" : "723422887659499520",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Hi there- thanks for reaching out. Understand your disappointment. We're investing in other areas of Klout's data assets. Thx!",
    "id" : 723422887659499520,
    "in_reply_to_status_id" : 723237018193506304,
    "created_at" : "2016-04-22 08:07:11 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Klout",
      "screen_name" : "klout",
      "protected" : false,
      "id_str" : "15134782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475053521167847424\/ddqeQG36_normal.png",
      "id" : 15134782,
      "verified" : true
    }
  },
  "id" : 723704307057610752,
  "created_at" : "2016-04-23 02:45:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "influencer",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723238097786429440",
  "text" : "You either got it or you don't #influencer",
  "id" : 723238097786429440,
  "created_at" : "2016-04-21 19:52:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/723233915931099136\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ecnqnaQoVI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CglxadsWsAA3QBO.png",
      "id_str" : "723233914630877184",
      "id" : 723233914630877184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CglxadsWsAA3QBO.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ecnqnaQoVI"
    } ],
    "hashtags" : [ {
      "text" : "HootChat",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723237918958084096",
  "text" : "RT @hootsuite: Q5: What makes an awesome influencer\/brand collaboration video? (bonus\u2014share an example!) #HootChat https:\/\/t.co\/ecnqnaQoVI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/723233915931099136\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/ecnqnaQoVI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CglxadsWsAA3QBO.png",
        "id_str" : "723233914630877184",
        "id" : 723233914630877184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CglxadsWsAA3QBO.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ecnqnaQoVI"
      } ],
      "hashtags" : [ {
        "text" : "HootChat",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "723233915931099136",
    "text" : "Q5: What makes an awesome influencer\/brand collaboration video? (bonus\u2014share an example!) #HootChat https:\/\/t.co\/ecnqnaQoVI",
    "id" : 723233915931099136,
    "created_at" : "2016-04-21 19:36:17 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 723237918958084096,
  "created_at" : "2016-04-21 19:52:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tari",
      "screen_name" : "ihateyourules",
      "indices" : [ 0, 14 ],
      "id_str" : "709589079709638658",
      "id" : 709589079709638658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723212892405899265",
  "geo" : { },
  "id_str" : "723237362449440768",
  "in_reply_to_user_id" : 709589079709638658,
  "text" : "@ihateyourules What is wrong with you?",
  "id" : 723237362449440768,
  "in_reply_to_status_id" : 723212892405899265,
  "created_at" : "2016-04-21 19:49:58 +0000",
  "in_reply_to_screen_name" : "ihateyourules",
  "in_reply_to_user_id_str" : "709589079709638658",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bristol City FC",
      "screen_name" : "bcfctweets",
      "indices" : [ 3, 14 ],
      "id_str" : "104167025",
      "id" : 104167025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/0X8SBuRbIa",
      "expanded_url" : "http:\/\/www.bcfc.co.uk\/news\/article\/fielding-to-miss-three-to-four-months-3072518.aspx",
      "display_url" : "bcfc.co.uk\/news\/article\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723237187949465600",
  "text" : "RT @bcfctweets: NEWS: Frank Fielding faces three to four months out after suffering ankle ligament damage. https:\/\/t.co\/0X8SBuRbIa https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bcfctweets\/status\/723108148580503553\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/jIZ3pClUmL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgj_B3AWIAAT-PX.jpg",
        "id_str" : "723108147603316736",
        "id" : 723108147603316736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgj_B3AWIAAT-PX.jpg",
        "sizes" : [ {
          "h" : 355,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 478
        } ],
        "display_url" : "pic.twitter.com\/jIZ3pClUmL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/0X8SBuRbIa",
        "expanded_url" : "http:\/\/www.bcfc.co.uk\/news\/article\/fielding-to-miss-three-to-four-months-3072518.aspx",
        "display_url" : "bcfc.co.uk\/news\/article\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723108148580503553",
    "text" : "NEWS: Frank Fielding faces three to four months out after suffering ankle ligament damage. https:\/\/t.co\/0X8SBuRbIa https:\/\/t.co\/jIZ3pClUmL",
    "id" : 723108148580503553,
    "created_at" : "2016-04-21 11:16:31 +0000",
    "user" : {
      "name" : "Bristol City FC",
      "screen_name" : "bcfctweets",
      "protected" : false,
      "id_str" : "104167025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/937627438045188096\/I6wli7yP_normal.jpg",
      "id" : 104167025,
      "verified" : true
    }
  },
  "id" : 723237187949465600,
  "created_at" : "2016-04-21 19:49:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RSG Plc",
      "screen_name" : "RSG_Plc",
      "indices" : [ 3, 11 ],
      "id_str" : "462958905",
      "id" : 462958905
    }, {
      "name" : "Bristol City FC",
      "screen_name" : "bcfctweets",
      "indices" : [ 13, 24 ],
      "id_str" : "104167025",
      "id" : 104167025
    }, {
      "name" : "Bristol Sport",
      "screen_name" : "Bristol_Sport",
      "indices" : [ 25, 39 ],
      "id_str" : "1451018796",
      "id" : 1451018796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723237128914780161",
  "text" : "RT @RSG_Plc: @bcfctweets @Bristol_Sport It's been a great few years between the two of us &amp; we wish you all the best for next season! #Maki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bristol City FC",
        "screen_name" : "bcfctweets",
        "indices" : [ 0, 11 ],
        "id_str" : "104167025",
        "id" : 104167025
      }, {
        "name" : "Bristol Sport",
        "screen_name" : "Bristol_Sport",
        "indices" : [ 12, 26 ],
        "id_str" : "1451018796",
        "id" : 1451018796
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakingBristolProud",
        "indices" : [ 125, 144 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723178198825979904",
    "geo" : { },
    "id_str" : "723184473886449664",
    "in_reply_to_user_id" : 104167025,
    "text" : "@bcfctweets @Bristol_Sport It's been a great few years between the two of us &amp; we wish you all the best for next season! #MakingBristolProud",
    "id" : 723184473886449664,
    "in_reply_to_status_id" : 723178198825979904,
    "created_at" : "2016-04-21 16:19:49 +0000",
    "in_reply_to_screen_name" : "bcfctweets",
    "in_reply_to_user_id_str" : "104167025",
    "user" : {
      "name" : "RSG Plc",
      "screen_name" : "RSG_Plc",
      "protected" : false,
      "id_str" : "462958905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877201119793090561\/SQlNBc5p_normal.jpg",
      "id" : 462958905,
      "verified" : false
    }
  },
  "id" : 723237128914780161,
  "created_at" : "2016-04-21 19:49:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 0, 6 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723237018193506304",
  "in_reply_to_user_id" : 15134782,
  "text" : "@klout I can't believe you got rid of perks, why?",
  "id" : 723237018193506304,
  "created_at" : "2016-04-21 19:48:36 +0000",
  "in_reply_to_screen_name" : "klout",
  "in_reply_to_user_id_str" : "15134782",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "indices" : [ 3, 15 ],
      "id_str" : "231971209",
      "id" : 231971209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722917020723912704",
  "text" : "RT @DJPROEBEATS: \"You either corny or an opportunist\" my favorite Kendrick line",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "722916587670519808",
    "text" : "\"You either corny or an opportunist\" my favorite Kendrick line",
    "id" : 722916587670519808,
    "created_at" : "2016-04-20 22:35:20 +0000",
    "user" : {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "protected" : false,
      "id_str" : "231971209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943587710220079104\/0stt_yN1_normal.jpg",
      "id" : 231971209,
      "verified" : false
    }
  },
  "id" : 722917020723912704,
  "created_at" : "2016-04-20 22:37:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/lhswC5LctC",
      "expanded_url" : "http:\/\/dailycaller.com\/2016\/02\/17\/poll-hillary-clinton-least-honest-and-trustworthy-of-all-presidential-candidates\/#ixzz46PLPjUXy",
      "display_url" : "dailycaller.com\/2016\/02\/17\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722916821368709120",
  "text" : "RT @tedcruz: Poll: Hillary Clinton Least Honest And Trustworthy Of All Presidential Candidates: https:\/\/t.co\/lhswC5LctC https:\/\/t.co\/xQvNMa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/lhswC5LctC",
        "expanded_url" : "http:\/\/dailycaller.com\/2016\/02\/17\/poll-hillary-clinton-least-honest-and-trustworthy-of-all-presidential-candidates\/#ixzz46PLPjUXy",
        "display_url" : "dailycaller.com\/2016\/02\/17\/pol\u2026"
      }, {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/xQvNMah924",
        "expanded_url" : "https:\/\/twitter.com\/townhallcom\/status\/722911792150614016",
        "display_url" : "twitter.com\/townhallcom\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722913052031496194",
    "text" : "Poll: Hillary Clinton Least Honest And Trustworthy Of All Presidential Candidates: https:\/\/t.co\/lhswC5LctC https:\/\/t.co\/xQvNMah924",
    "id" : 722913052031496194,
    "created_at" : "2016-04-20 22:21:17 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 722916821368709120,
  "created_at" : "2016-04-20 22:36:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ZjnJi7yG4k",
      "expanded_url" : "http:\/\/bit.ly\/1VG6hiM",
      "display_url" : "bit.ly\/1VG6hiM"
    } ]
  },
  "geo" : { },
  "id_str" : "722916749851557890",
  "text" : "RT @Tearieeror: Real Madrid Menang, La Liga Kembali Panas https:\/\/t.co\/ZjnJi7yG4k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/ZjnJi7yG4k",
        "expanded_url" : "http:\/\/bit.ly\/1VG6hiM",
        "display_url" : "bit.ly\/1VG6hiM"
      } ]
    },
    "geo" : { },
    "id_str" : "722911595169390593",
    "text" : "Real Madrid Menang, La Liga Kembali Panas https:\/\/t.co\/ZjnJi7yG4k",
    "id" : 722911595169390593,
    "created_at" : "2016-04-20 22:15:29 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 722916749851557890,
  "created_at" : "2016-04-20 22:35:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722916626669154305",
  "text" : "I can eat like a bulldozer and still lose weight because of how active I am. Today I walked to my meetings.",
  "id" : 722916626669154305,
  "created_at" : "2016-04-20 22:35:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/722916420149858305\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ufpBubYcZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CghQpGdWsAA_V8L.jpg",
      "id_str" : "722916407231557632",
      "id" : 722916407231557632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CghQpGdWsAA_V8L.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ufpBubYcZK"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/722916420149858305\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ufpBubYcZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CghQpHnWEAAYLwe.jpg",
      "id_str" : "722916407541895168",
      "id" : 722916407541895168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CghQpHnWEAAYLwe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ufpBubYcZK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722916420149858305",
  "text" : "Had chili cheese fries and a chicken quesadilla from Wise Guy's bar, definitely a 5 star meal https:\/\/t.co\/ufpBubYcZK",
  "id" : 722916420149858305,
  "created_at" : "2016-04-20 22:34:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/722495555000233984\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/3dNWR9YkV0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgbR3Z_UMAE5gM5.jpg",
      "id_str" : "722495540039004161",
      "id" : 722495540039004161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgbR3Z_UMAE5gM5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3dNWR9YkV0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722495555000233984",
  "text" : "Had buddy's pizza 4.5\/5 stars https:\/\/t.co\/3dNWR9YkV0",
  "id" : 722495555000233984,
  "created_at" : "2016-04-19 18:42:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/722092886146347009\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Qwnt2bXqK6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgVjpMeVAAEaD-K.jpg",
      "id_str" : "722092874637049857",
      "id" : 722092874637049857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgVjpMeVAAEaD-K.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Qwnt2bXqK6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722092886146347009",
  "text" : "I like concept cars https:\/\/t.co\/Qwnt2bXqK6",
  "id" : 722092886146347009,
  "created_at" : "2016-04-18 16:02:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bristol City FC",
      "screen_name" : "bcfctweets",
      "indices" : [ 3, 14 ],
      "id_str" : "104167025",
      "id" : 104167025
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bcfctweets\/status\/721366588922982400\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/5msG3xPzfz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgLPFvlUsAAjkYK.jpg",
      "id_str" : "721366587912007680",
      "id" : 721366587912007680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgLPFvlUsAAjkYK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/5msG3xPzfz"
    } ],
    "hashtags" : [ {
      "text" : "BristolCity",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721369928729649152",
  "text" : "RT @bcfctweets: Brentford steal a point at the death. #BristolCity https:\/\/t.co\/5msG3xPzfz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bcfctweets\/status\/721366588922982400\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/5msG3xPzfz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgLPFvlUsAAjkYK.jpg",
        "id_str" : "721366587912007680",
        "id" : 721366587912007680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgLPFvlUsAAjkYK.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/5msG3xPzfz"
      } ],
      "hashtags" : [ {
        "text" : "BristolCity",
        "indices" : [ 38, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "721366588922982400",
    "text" : "Brentford steal a point at the death. #BristolCity https:\/\/t.co\/5msG3xPzfz",
    "id" : 721366588922982400,
    "created_at" : "2016-04-16 15:56:11 +0000",
    "user" : {
      "name" : "Bristol City FC",
      "screen_name" : "bcfctweets",
      "protected" : false,
      "id_str" : "104167025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/937627438045188096\/I6wli7yP_normal.jpg",
      "id" : 104167025,
      "verified" : true
    }
  },
  "id" : 721369928729649152,
  "created_at" : "2016-04-16 16:09:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/E8yAMYBbCw",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNF_a3JNuj89xv8C4xykq85fjmpiAw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779083065752&ei=cGESV9jNIoHXwQHH9rzwCA&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Ffootball%2F36063673&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721369900191617028",
  "text" : "RT @andikhm01: Leicester City: Season-ticket holders banned for illegal resale - BBC Sport https:\/\/t.co\/E8yAMYBbCw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/E8yAMYBbCw",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNF_a3JNuj89xv8C4xykq85fjmpiAw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779083065752&ei=cGESV9jNIoHXwQHH9rzwCA&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Ffootball%2F36063673&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "721369525493444608",
    "text" : "Leicester City: Season-ticket holders banned for illegal resale - BBC Sport https:\/\/t.co\/E8yAMYBbCw",
    "id" : 721369525493444608,
    "created_at" : "2016-04-16 16:07:51 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 721369900191617028,
  "created_at" : "2016-04-16 16:09:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Hortons",
      "screen_name" : "TimHortons",
      "indices" : [ 37, 48 ],
      "id_str" : "382177545",
      "id" : 382177545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721369318731067392",
  "text" : "I don't care what people say, I like @TimHortons better than Starbucks, let the flame wars begin, miss their honey mustard chicken though",
  "id" : 721369318731067392,
  "created_at" : "2016-04-16 16:07:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/719212566363377665\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/yzZAYKqzn8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfsn_rWUUAARIe3.jpg",
      "id_str" : "719212540417298432",
      "id" : 719212540417298432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfsn_rWUUAARIe3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1834
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1834
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1075
      } ],
      "display_url" : "pic.twitter.com\/yzZAYKqzn8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719212566363377665",
  "text" : "Had the Boston Cooler at Kim's Tea Time; 4.94\/5 stars https:\/\/t.co\/yzZAYKqzn8",
  "id" : 719212566363377665,
  "created_at" : "2016-04-10 17:16:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/717060255524462593\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/e7PCfevpOq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfOCefwUAAA5tP2.jpg",
      "id_str" : "717060226113863680",
      "id" : 717060226113863680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfOCefwUAAA5tP2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/e7PCfevpOq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717060255524462593",
  "text" : "Had the Chicken Pita at Lukich, 4.1\/5 stars https:\/\/t.co\/e7PCfevpOq",
  "id" : 717060255524462593,
  "created_at" : "2016-04-04 18:44:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]