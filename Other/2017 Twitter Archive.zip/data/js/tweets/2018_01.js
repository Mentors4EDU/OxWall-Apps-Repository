Grailbird.data.tweets_2018_01 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "949005861460029440",
  "text" : "RT @Snapzu_Earth: Fun Fact: House flies have a lifespan of two weeks.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "949002309052252160",
    "text" : "Fun Fact: House flies have a lifespan of two weeks.",
    "id" : 949002309052252160,
    "created_at" : "2018-01-04 19:39:16 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 949005861460029440,
  "created_at" : "2018-01-04 19:53:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sukhi",
      "screen_name" : "mairanotmaria2",
      "indices" : [ 3, 18 ],
      "id_str" : "1912435230",
      "id" : 1912435230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "949005731147206656",
  "text" : "RT @mairanotmaria2: The most pathetic feeling is when u get in a fight with someone bc u expressed what made u upset and instead of apologi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948408689039421440",
    "text" : "The most pathetic feeling is when u get in a fight with someone bc u expressed what made u upset and instead of apologizing they find a way to make u feel bad abt it so ur left regretting even saying anything at all",
    "id" : 948408689039421440,
    "created_at" : "2018-01-03 04:20:26 +0000",
    "user" : {
      "name" : "sukhi",
      "screen_name" : "mairanotmaria2",
      "protected" : false,
      "id_str" : "1912435230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946929149154938881\/1c0lj5B2_normal.jpg",
      "id" : 1912435230,
      "verified" : false
    }
  },
  "id" : 949005731147206656,
  "created_at" : "2018-01-04 19:52:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8Rzl5Cz9Gy",
      "expanded_url" : "https:\/\/www.diyphotography.net\/build-diy-sound-booth-items-around-home-without-spending-money\/",
      "display_url" : "diyphotography.net\/build-diy-soun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "949005288065159168",
  "text" : "RT @JayHoque: Build your own DIY sound booth with items from around the home without spending any money: https:\/\/t.co\/8Rzl5Cz9Gy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/8Rzl5Cz9Gy",
        "expanded_url" : "https:\/\/www.diyphotography.net\/build-diy-sound-booth-items-around-home-without-spending-money\/",
        "display_url" : "diyphotography.net\/build-diy-soun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "949004896363261952",
    "text" : "Build your own DIY sound booth with items from around the home without spending any money: https:\/\/t.co\/8Rzl5Cz9Gy",
    "id" : 949004896363261952,
    "created_at" : "2018-01-04 19:49:33 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 949005288065159168,
  "created_at" : "2018-01-04 19:51:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "949005018144870402",
  "text" : "RT @make: First-party video game controllers have never been very accessible, so it's up to us to find new ways for everyone to game https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/qI88BL2s79",
        "expanded_url" : "https:\/\/makezine.com\/2018\/01\/04\/3d-printed-nintendo-switch-controller-adapter\/",
        "display_url" : "makezine.com\/2018\/01\/04\/3d-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "949001274216845313",
    "text" : "First-party video game controllers have never been very accessible, so it's up to us to find new ways for everyone to game https:\/\/t.co\/qI88BL2s79",
    "id" : 949001274216845313,
    "created_at" : "2018-01-04 19:35:10 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 949005018144870402,
  "created_at" : "2018-01-04 19:50:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashing",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "cryptocurrency",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "949004978508705792",
  "text" : "Ah, waiting for send transactions on the blockchain, nice way to spend time #hashing #cryptocurrency",
  "id" : 949004978508705792,
  "created_at" : "2018-01-04 19:49:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Simkins",
      "screen_name" : "SusanMSimkins",
      "indices" : [ 3, 17 ],
      "id_str" : "495096905",
      "id" : 495096905
    }, {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 46, 58 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ux",
      "indices" : [ 84, 87 ]
    }, {
      "text" : "webdesign",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/JJm0INgmRR",
      "expanded_url" : "https:\/\/www.pluralsight.com\/courses\/ux-design-creating-wireframes",
      "display_url" : "pluralsight.com\/courses\/ux-des\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948984518622502912",
  "text" : "RT @SusanMSimkins: My newest course is out on @pluralsight! https:\/\/t.co\/JJm0INgmRR #ux #webdesign",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pluralsight",
        "screen_name" : "pluralsight",
        "indices" : [ 27, 39 ],
        "id_str" : "19253334",
        "id" : 19253334
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ux",
        "indices" : [ 65, 68 ]
      }, {
        "text" : "webdesign",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/JJm0INgmRR",
        "expanded_url" : "https:\/\/www.pluralsight.com\/courses\/ux-design-creating-wireframes",
        "display_url" : "pluralsight.com\/courses\/ux-des\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948942977921150976",
    "text" : "My newest course is out on @pluralsight! https:\/\/t.co\/JJm0INgmRR #ux #webdesign",
    "id" : 948942977921150976,
    "created_at" : "2018-01-04 15:43:31 +0000",
    "user" : {
      "name" : "Susan Simkins",
      "screen_name" : "SusanMSimkins",
      "protected" : false,
      "id_str" : "495096905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817586053305356288\/9NpDyJ2B_normal.jpg",
      "id" : 495096905,
      "verified" : false
    }
  },
  "id" : 948984518622502912,
  "created_at" : "2018-01-04 18:28:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "octopus",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948984218071306240",
  "text" : "RT @Snapzu_Science: Did you know? The pupil of an #octopus' eye is rectangular.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "octopus",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948972473390804992",
    "text" : "Did you know? The pupil of an #octopus' eye is rectangular.",
    "id" : 948972473390804992,
    "created_at" : "2018-01-04 17:40:43 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948984218071306240,
  "created_at" : "2018-01-04 18:27:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GwMxFdcTeX",
      "expanded_url" : "https:\/\/makezine.com\/2018\/01\/03\/build-a-retro-arcade-game-from-a-raspberry-pi-and-an-ikea-table\/",
      "display_url" : "makezine.com\/2018\/01\/03\/bui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948984177566896128",
  "text" : "RT @make: The arcades of today are missing some true classics, so it's best to just outfit your own arcade at home https:\/\/t.co\/GwMxFdcTeX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/GwMxFdcTeX",
        "expanded_url" : "https:\/\/makezine.com\/2018\/01\/03\/build-a-retro-arcade-game-from-a-raspberry-pi-and-an-ikea-table\/",
        "display_url" : "makezine.com\/2018\/01\/03\/bui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948979919983439872",
    "text" : "The arcades of today are missing some true classics, so it's best to just outfit your own arcade at home https:\/\/t.co\/GwMxFdcTeX",
    "id" : 948979919983439872,
    "created_at" : "2018-01-04 18:10:18 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 948984177566896128,
  "created_at" : "2018-01-04 18:27:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "ASUS",
      "screen_name" : "ASUS",
      "indices" : [ 20, 25 ],
      "id_str" : "591646425",
      "id" : 591646425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/LObvPlJZGe",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/asus-xg-station-pro-tb3,36224.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/asus-xg-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948984140401176577",
  "text" : "RT @tomshardware: \u25B8 @Asus Goes Pro With New XG Station eGPU Dock https:\/\/t.co\/LObvPlJZGe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ASUS",
        "screen_name" : "ASUS",
        "indices" : [ 2, 7 ],
        "id_str" : "591646425",
        "id" : 591646425
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/LObvPlJZGe",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/asus-xg-station-pro-tb3,36224.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/asus-xg-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948980881829457920",
    "text" : "\u25B8 @Asus Goes Pro With New XG Station eGPU Dock https:\/\/t.co\/LObvPlJZGe",
    "id" : 948980881829457920,
    "created_at" : "2018-01-04 18:14:08 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948984140401176577,
  "created_at" : "2018-01-04 18:27:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948984127923027970",
  "text" : "RT @lorenridinger: \u201CIf you want others to be happy, practice compassion. If you want to be happy, practice compassion.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948977710923157504",
    "text" : "\u201CIf you want others to be happy, practice compassion. If you want to be happy, practice compassion.\u201D",
    "id" : 948977710923157504,
    "created_at" : "2018-01-04 18:01:32 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948984127923027970,
  "created_at" : "2018-01-04 18:27:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948984110420242437",
  "text" : "RT @BarbaraCorcoran: There\u2019s great power in moving forward, whether you\u2019re moving in the right direction or not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948964829599092736",
    "text" : "There\u2019s great power in moving forward, whether you\u2019re moving in the right direction or not.",
    "id" : 948964829599092736,
    "created_at" : "2018-01-04 17:10:20 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948984110420242437,
  "created_at" : "2018-01-04 18:26:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jxyIWKXZA4",
      "expanded_url" : "https:\/\/fstoppers.com\/gear\/moment-announces-62mm-filter-mount-their-smartphone-lenses-210697?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/gear\/moment-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948984087942967297",
  "text" : "RT @JayHoque: Moment Announces a 62mm Filter Mount for Their Smartphone Lenses: https:\/\/t.co\/jxyIWKXZA4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/jxyIWKXZA4",
        "expanded_url" : "https:\/\/fstoppers.com\/gear\/moment-announces-62mm-filter-mount-their-smartphone-lenses-210697?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/gear\/moment-an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948983524618637313",
    "text" : "Moment Announces a 62mm Filter Mount for Their Smartphone Lenses: https:\/\/t.co\/jxyIWKXZA4",
    "id" : 948983524618637313,
    "created_at" : "2018-01-04 18:24:38 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948984087942967297,
  "created_at" : "2018-01-04 18:26:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948984067432828928\/photo\/1",
      "indices" : [ 255, 278 ],
      "url" : "https:\/\/t.co\/f1FOvdgGdS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSt37cjW0AACYLw.jpg",
      "id_str" : "948984009652097024",
      "id" : 948984009652097024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSt37cjW0AACYLw.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/f1FOvdgGdS"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948984067432828928\/photo\/1",
      "indices" : [ 255, 278 ],
      "url" : "https:\/\/t.co\/f1FOvdgGdS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSt38tuXcAA-u3R.jpg",
      "id_str" : "948984031441547264",
      "id" : 948984031441547264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSt38tuXcAA-u3R.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1755
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1755
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1028
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 583
      } ],
      "display_url" : "pic.twitter.com\/f1FOvdgGdS"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948984067432828928\/photo\/1",
      "indices" : [ 255, 278 ],
      "url" : "https:\/\/t.co\/f1FOvdgGdS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSt399hWkAETbpe.jpg",
      "id_str" : "948984052861800449",
      "id" : 948984052861800449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSt399hWkAETbpe.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 614
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1850
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1084
      } ],
      "display_url" : "pic.twitter.com\/f1FOvdgGdS"
    } ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 222, 227 ]
    }, {
      "text" : "CoolCoil",
      "indices" : [ 228, 237 ]
    }, {
      "text" : "Water4ThePeople",
      "indices" : [ 238, 254 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948984067432828928",
  "text" : "Doing brackets to support the side bars. That isn't all, this thing will have so much structural support. Then add the electronics, move it, and make report. Still not likely I will finish on time or win but try your best #STEM #CoolCoil #Water4ThePeople https:\/\/t.co\/f1FOvdgGdS",
  "id" : 948984067432828928,
  "created_at" : "2018-01-04 18:26:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Power Networks",
      "screen_name" : "UKPowerNetworks",
      "indices" : [ 3, 19 ],
      "id_str" : "355439889",
      "id" : 355439889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948953416457424899",
  "text" : "RT @UKPowerNetworks: Good afternoon. Dave S and Will are here to help with any power cuts or related queries you may have",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.conversocial.com\" rel=\"nofollow\"\u003EConversocial\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948952383064887296",
    "text" : "Good afternoon. Dave S and Will are here to help with any power cuts or related queries you may have",
    "id" : 948952383064887296,
    "created_at" : "2018-01-04 16:20:53 +0000",
    "user" : {
      "name" : "UK Power Networks",
      "screen_name" : "UKPowerNetworks",
      "protected" : false,
      "id_str" : "355439889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799550913090375681\/MCNJd0nH_normal.jpg",
      "id" : 355439889,
      "verified" : true
    }
  },
  "id" : 948953416457424899,
  "created_at" : "2018-01-04 16:24:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/5WtbXISGNI",
      "expanded_url" : "https:\/\/www.photographytalk.com\/post-processing\/8168-how-to-pump-life-into-your-landscape-photo-in-under-15-minutes",
      "display_url" : "photographytalk.com\/post-processin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948949148434386947",
  "text" : "RT @PhotographyTalk: Learn how to post-process your landscape photos from Serge Ramelli\n\nhttps:\/\/t.co\/5WtbXISGNI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/5WtbXISGNI",
        "expanded_url" : "https:\/\/www.photographytalk.com\/post-processing\/8168-how-to-pump-life-into-your-landscape-photo-in-under-15-minutes",
        "display_url" : "photographytalk.com\/post-processin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948944546930491392",
    "text" : "Learn how to post-process your landscape photos from Serge Ramelli\n\nhttps:\/\/t.co\/5WtbXISGNI",
    "id" : 948944546930491392,
    "created_at" : "2018-01-04 15:49:45 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948949148434386947,
  "created_at" : "2018-01-04 16:08:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "G.SKILL",
      "screen_name" : "GSkillTech",
      "indices" : [ 20, 31 ],
      "id_str" : "237631420",
      "id" : 237631420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Pj6sKgJKSY",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/gskill-sniper-x-ddr4-memory,36211.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/gskill-sn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948944176745500673",
  "text" : "RT @tomshardware: \u25B8 @GSkillTech Stealthily Reveals Camouflaged Sniper X DDR4 Memory Kits https:\/\/t.co\/Pj6sKgJKSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "G.SKILL",
        "screen_name" : "GSkillTech",
        "indices" : [ 2, 13 ],
        "id_str" : "237631420",
        "id" : 237631420
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Pj6sKgJKSY",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/gskill-sniper-x-ddr4-memory,36211.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/gskill-sn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948630814736007168",
    "text" : "\u25B8 @GSkillTech Stealthily Reveals Camouflaged Sniper X DDR4 Memory Kits https:\/\/t.co\/Pj6sKgJKSY",
    "id" : 948630814736007168,
    "created_at" : "2018-01-03 19:03:05 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948944176745500673,
  "created_at" : "2018-01-04 15:48:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/RFucCTGrA0",
      "expanded_url" : "http:\/\/www.lanl.gov\/discover\/news-release-archive\/2018\/January\/0102-quantum-dots.php?source=Snapzu",
      "display_url" : "lanl.gov\/discover\/news-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948936955202555904",
  "text" : "RT @Snapzu_Science: Tweaking quantum dots powers-up double-pane solar windows https:\/\/t.co\/RFucCTGrA0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/RFucCTGrA0",
        "expanded_url" : "http:\/\/www.lanl.gov\/discover\/news-release-archive\/2018\/January\/0102-quantum-dots.php?source=Snapzu",
        "display_url" : "lanl.gov\/discover\/news-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948936712042024960",
    "text" : "Tweaking quantum dots powers-up double-pane solar windows https:\/\/t.co\/RFucCTGrA0",
    "id" : 948936712042024960,
    "created_at" : "2018-01-04 15:18:37 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948936955202555904,
  "created_at" : "2018-01-04 15:19:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/PwCkjqb4Fi",
      "expanded_url" : "http:\/\/ift.tt\/2CEwmN3",
      "display_url" : "ift.tt\/2CEwmN3"
    } ]
  },
  "geo" : { },
  "id_str" : "948935491549790213",
  "text" : "RT @dronepilots: Israel to invest over $300 million to boost manufacturing sector | DronePilots - https:\/\/t.co\/PwCkjqb4Fi #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/PwCkjqb4Fi",
        "expanded_url" : "http:\/\/ift.tt\/2CEwmN3",
        "display_url" : "ift.tt\/2CEwmN3"
      } ]
    },
    "geo" : { },
    "id_str" : "948933002628825089",
    "text" : "Israel to invest over $300 million to boost manufacturing sector | DronePilots - https:\/\/t.co\/PwCkjqb4Fi #drones",
    "id" : 948933002628825089,
    "created_at" : "2018-01-04 15:03:52 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948935491549790213,
  "created_at" : "2018-01-04 15:13:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "indices" : [ 3, 16 ],
      "id_str" : "61417559",
      "id" : 61417559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948935403981205505",
  "text" : "RT @ErikVoorhees: Two major theme predictions for crypto in 2018:  1) Blockchain-based gaming and tokenized game assets, and 2) tokenized s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948932707886747648",
    "text" : "Two major theme predictions for crypto in 2018:  1) Blockchain-based gaming and tokenized game assets, and 2) tokenized securities (equities or other registered securities as tokens).",
    "id" : 948932707886747648,
    "created_at" : "2018-01-04 15:02:42 +0000",
    "user" : {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "protected" : false,
      "id_str" : "61417559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/339147710\/atlas_02-1_normal.jpg",
      "id" : 61417559,
      "verified" : true
    }
  },
  "id" : 948935403981205505,
  "created_at" : "2018-01-04 15:13:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swan",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948935357760000000",
  "text" : "RT @Snapzu_Earth: Did you know? The #swan has over 25,000 feathers in its body.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "swan",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948933507874566144",
    "text" : "Did you know? The #swan has over 25,000 feathers in its body.",
    "id" : 948933507874566144,
    "created_at" : "2018-01-04 15:05:53 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948935357760000000,
  "created_at" : "2018-01-04 15:13:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/BjSKLIItTX",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-code-editors-for-web-developers\/",
      "display_url" : "webdesigndev.com\/free-code-edit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948935210510495744",
  "text" : "RT @WebDesignDev: 18 Free Code Editors for Web Developers: https:\/\/t.co\/BjSKLIItTX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/BjSKLIItTX",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-code-editors-for-web-developers\/",
        "display_url" : "webdesigndev.com\/free-code-edit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948928300596031489",
    "text" : "18 Free Code Editors for Web Developers: https:\/\/t.co\/BjSKLIItTX",
    "id" : 948928300596031489,
    "created_at" : "2018-01-04 14:45:11 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948935210510495744,
  "created_at" : "2018-01-04 15:12:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "salamander",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948932343791841280",
  "text" : "RT @Snapzu_Science: Did you know? The world's largest amphibian is the giant #salamander. It can grow up to 5 ft. in length.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "salamander",
        "indices" : [ 57, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948926881436352513",
    "text" : "Did you know? The world's largest amphibian is the giant #salamander. It can grow up to 5 ft. in length.",
    "id" : 948926881436352513,
    "created_at" : "2018-01-04 14:39:33 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948932343791841280,
  "created_at" : "2018-01-04 15:01:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948921954010050560",
  "text" : "RT @PhotographyTalk: If you've done things the right way and you have a solid portrait with which to work, there are tons of tools at your\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 164, 187 ],
        "url" : "https:\/\/t.co\/u71DV3iIzD",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/231-portrait-photography-tips\/8159-use-these-5-lightroom-tips-to-instantly-improve-your-portraits",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947852888583344129",
    "text" : "If you've done things the right way and you have a solid portrait with which to work, there are tons of tools at your disposal in Lightroom to enhance your photo.\n\nhttps:\/\/t.co\/u71DV3iIzD",
    "id" : 947852888583344129,
    "created_at" : "2018-01-01 15:31:53 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948921954010050560,
  "created_at" : "2018-01-04 14:19:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948921247903207424",
  "text" : "RT @buysellshort: $CNET another monster chart alert members booking 200% gains there on the swing from last month!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948921214445142016",
    "text" : "$CNET another monster chart alert members booking 200% gains there on the swing from last month!",
    "id" : 948921214445142016,
    "created_at" : "2018-01-04 14:17:02 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : false,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 948921247903207424,
  "created_at" : "2018-01-04 14:17:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/vGnM6jYdfg",
      "expanded_url" : "http:\/\/a.msn.com\/01\/en-us\/BBHPuDl?ocid=st",
      "display_url" : "a.msn.com\/01\/en-us\/BBHPu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948920983188099072",
  "text" : "RT @HamzeiAnalytics: 19,000-pound space lab falling \"uncontrolled\" back to Earth https:\/\/t.co\/vGnM6jYdfg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/vGnM6jYdfg",
        "expanded_url" : "http:\/\/a.msn.com\/01\/en-us\/BBHPuDl?ocid=st",
        "display_url" : "a.msn.com\/01\/en-us\/BBHPu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948913112937304064",
    "text" : "19,000-pound space lab falling \"uncontrolled\" back to Earth https:\/\/t.co\/vGnM6jYdfg",
    "id" : 948913112937304064,
    "created_at" : "2018-01-04 13:44:50 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 948920983188099072,
  "created_at" : "2018-01-04 14:16:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948920939357655040",
  "text" : "RT @BarbaraCorcoran: Play up what you got and forget about what you don\u2019t have.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948913224405209088",
    "text" : "Play up what you got and forget about what you don\u2019t have.",
    "id" : 948913224405209088,
    "created_at" : "2018-01-04 13:45:17 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948920939357655040,
  "created_at" : "2018-01-04 14:15:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948920917186445312",
  "text" : "Always talking to people about ICOs and Crypto nowadays in the startup world",
  "id" : 948920917186445312,
  "created_at" : "2018-01-04 14:15:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Peitz",
      "screen_name" : "IT_Supertramp",
      "indices" : [ 3, 17 ],
      "id_str" : "791697331",
      "id" : 791697331
    }, {
      "name" : "Felix Rieseberg",
      "screen_name" : "felixrieseberg",
      "indices" : [ 49, 64 ],
      "id_str" : "28576494",
      "id" : 28576494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/3io67riAuX",
      "expanded_url" : "https:\/\/www.meetup.com\/Webworker-NRW\/events\/245814170\/",
      "display_url" : "meetup.com\/Webworker-NRW\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948913095484805120",
  "text" : "RT @IT_Supertramp: Building Apps with Electron - @felixrieseberg (slack) next wednesday in D\u00FCsseldorf - https:\/\/t.co\/3io67riAuX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Felix Rieseberg",
        "screen_name" : "felixrieseberg",
        "indices" : [ 30, 45 ],
        "id_str" : "28576494",
        "id" : 28576494
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/3io67riAuX",
        "expanded_url" : "https:\/\/www.meetup.com\/Webworker-NRW\/events\/245814170\/",
        "display_url" : "meetup.com\/Webworker-NRW\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948902862641336320",
    "text" : "Building Apps with Electron - @felixrieseberg (slack) next wednesday in D\u00FCsseldorf - https:\/\/t.co\/3io67riAuX",
    "id" : 948902862641336320,
    "created_at" : "2018-01-04 13:04:06 +0000",
    "user" : {
      "name" : "Thomas Peitz",
      "screen_name" : "IT_Supertramp",
      "protected" : false,
      "id_str" : "791697331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932243225729011714\/LoryLBvU_normal.jpg",
      "id" : 791697331,
      "verified" : false
    }
  },
  "id" : 948913095484805120,
  "created_at" : "2018-01-04 13:44:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Jackson",
      "screen_name" : "internetsurfing",
      "indices" : [ 3, 19 ],
      "id_str" : "176737258",
      "id" : 176737258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kubernetes",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/gZ08MLKK1r",
      "expanded_url" : "https:\/\/draft.sh",
      "display_url" : "draft.sh"
    } ]
  },
  "geo" : { },
  "id_str" : "948913082876743680",
  "text" : "RT @internetsurfing: A tool for developers to create cloud-native applications on #Kubernetes. https:\/\/t.co\/gZ08MLKK1r &amp; https:\/\/t.co\/K3tQd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kubernetes",
        "indices" : [ 61, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/gZ08MLKK1r",
        "expanded_url" : "https:\/\/draft.sh",
        "display_url" : "draft.sh"
      }, {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/K3tQdHJfoj",
        "expanded_url" : "https:\/\/github.com\/Azure\/draft",
        "display_url" : "github.com\/Azure\/draft"
      } ]
    },
    "geo" : { },
    "id_str" : "947877781639229440",
    "text" : "A tool for developers to create cloud-native applications on #Kubernetes. https:\/\/t.co\/gZ08MLKK1r &amp; https:\/\/t.co\/K3tQdHJfoj by Microsoft Azure Team",
    "id" : 947877781639229440,
    "created_at" : "2018-01-01 17:10:48 +0000",
    "user" : {
      "name" : "James Jackson",
      "screen_name" : "internetsurfing",
      "protected" : false,
      "id_str" : "176737258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1627275100\/photo_bw_normal.jpg",
      "id" : 176737258,
      "verified" : false
    }
  },
  "id" : 948913082876743680,
  "created_at" : "2018-01-04 13:44:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948912828165091332",
  "text" : "RT @Fact: Before you talk, listen. Before you react, think. Before you criticize, wait. Before you pray, forgive. Before you quit, try.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948690530136928256",
    "text" : "Before you talk, listen. Before you react, think. Before you criticize, wait. Before you pray, forgive. Before you quit, try.",
    "id" : 948690530136928256,
    "created_at" : "2018-01-03 23:00:22 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 948912828165091332,
  "created_at" : "2018-01-04 13:43:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Zlth1P1bmk",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/01\/04\/reports-digital-full-frame-ricoh-gr-e-circulating-wed\/",
      "display_url" : "thephoblographer.com\/2018\/01\/04\/rep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948912646077800448",
  "text" : "RT @JayHoque: Ricoh GR-E Reported to Have 36MP Curved Full Frame Sensor, 28mm f2.4 Lens: https:\/\/t.co\/Zlth1P1bmk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Zlth1P1bmk",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/01\/04\/reports-digital-full-frame-ricoh-gr-e-circulating-wed\/",
        "display_url" : "thephoblographer.com\/2018\/01\/04\/rep\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948905573550120960",
    "text" : "Ricoh GR-E Reported to Have 36MP Curved Full Frame Sensor, 28mm f2.4 Lens: https:\/\/t.co\/Zlth1P1bmk",
    "id" : 948905573550120960,
    "created_at" : "2018-01-04 13:14:53 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948912646077800448,
  "created_at" : "2018-01-04 13:42:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 3, 16 ],
      "id_str" : "302666251",
      "id" : 302666251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/UENz7Rcw83",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XTHH30S8Aao",
      "display_url" : "youtube.com\/watch?v=XTHH30\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948912473880621057",
  "text" : "RT @Raspberry_Pi: Switch between Dutch and English with this awesome 3D-printed word clock from Ruud Rademaker\nhttps:\/\/t.co\/UENz7Rcw83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/UENz7Rcw83",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XTHH30S8Aao",
        "display_url" : "youtube.com\/watch?v=XTHH30\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948907748745506817",
    "text" : "Switch between Dutch and English with this awesome 3D-printed word clock from Ruud Rademaker\nhttps:\/\/t.co\/UENz7Rcw83",
    "id" : 948907748745506817,
    "created_at" : "2018-01-04 13:23:31 +0000",
    "user" : {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "protected" : false,
      "id_str" : "302666251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948144512341245952\/5pw6pkFu_normal.jpg",
      "id" : 302666251,
      "verified" : true
    }
  },
  "id" : 948912473880621057,
  "created_at" : "2018-01-04 13:42:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948912435687317504",
  "text" : "RT @Snapzu_Earth: \"Should you shield the canyons from the windstorms you would never see the true beauty of their carvings.\" - Elisabeth K\u00FC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948909449078452224",
    "text" : "\"Should you shield the canyons from the windstorms you would never see the true beauty of their carvings.\" - Elisabeth K\u00FCbler-Ross",
    "id" : 948909449078452224,
    "created_at" : "2018-01-04 13:30:17 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948912435687317504,
  "created_at" : "2018-01-04 13:42:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/2RWZLEuWXj",
      "expanded_url" : "http:\/\/snapzu.com\/t\/Wildlife",
      "display_url" : "snapzu.com\/t\/Wildlife"
    } ]
  },
  "geo" : { },
  "id_str" : "948912361406173184",
  "text" : "RT @Snapzu_Earth: Jump in the discussion about: Wildlife @ https:\/\/t.co\/2RWZLEuWXj Vote on your favourite posts to see them climb.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/2RWZLEuWXj",
        "expanded_url" : "http:\/\/snapzu.com\/t\/Wildlife",
        "display_url" : "snapzu.com\/t\/Wildlife"
      } ]
    },
    "geo" : { },
    "id_str" : "948910076479209473",
    "text" : "Jump in the discussion about: Wildlife @ https:\/\/t.co\/2RWZLEuWXj Vote on your favourite posts to see them climb.",
    "id" : 948910076479209473,
    "created_at" : "2018-01-04 13:32:46 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948912361406173184,
  "created_at" : "2018-01-04 13:41:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Husky's",
      "screen_name" : "69xylem",
      "indices" : [ 3, 11 ],
      "id_str" : "434026744",
      "id" : 434026744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948912254547881989",
  "text" : "RT @69xylem: People change... time change...  it is inevitable...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948910586942832641",
    "text" : "People change... time change...  it is inevitable...",
    "id" : 948910586942832641,
    "created_at" : "2018-01-04 13:34:48 +0000",
    "user" : {
      "name" : "Husky's",
      "screen_name" : "69xylem",
      "protected" : false,
      "id_str" : "434026744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855966255118827522\/IANs9Zwf_normal.jpg",
      "id" : 434026744,
      "verified" : false
    }
  },
  "id" : 948912254547881989,
  "created_at" : "2018-01-04 13:41:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948912157491687425",
  "text" : "RT @HamzeiAnalytics: My Real-Time Audio\/Video Sharing for OTF &amp; Options Members is starting now on Skype for Business....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948911857900797953",
    "text" : "My Real-Time Audio\/Video Sharing for OTF &amp; Options Members is starting now on Skype for Business....",
    "id" : 948911857900797953,
    "created_at" : "2018-01-04 13:39:51 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 948912157491687425,
  "created_at" : "2018-01-04 13:41:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startups",
      "indices" : [ 167, 176 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948912109232050176",
  "text" : "Just applied to speak at a tech conference. Wondering if I will be accepted to any of them this year. Likely at least some good ones ;) Although, schedule been heptic #startups",
  "id" : 948912109232050176,
  "created_at" : "2018-01-04 13:40:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/TxK1mojK5O",
      "expanded_url" : "https:\/\/trib.al\/npQ4Wa2",
      "display_url" : "trib.al\/npQ4Wa2"
    } ]
  },
  "geo" : { },
  "id_str" : "948898319799119873",
  "text" : "RT @epicurious: \u201CThis is the best waffle I know.\u201D \nhttps:\/\/t.co\/TxK1mojK5O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/TxK1mojK5O",
        "expanded_url" : "https:\/\/trib.al\/npQ4Wa2",
        "display_url" : "trib.al\/npQ4Wa2"
      } ]
    },
    "geo" : { },
    "id_str" : "948697741269651456",
    "text" : "\u201CThis is the best waffle I know.\u201D \nhttps:\/\/t.co\/TxK1mojK5O",
    "id" : 948697741269651456,
    "created_at" : "2018-01-03 23:29:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948898319799119873,
  "created_at" : "2018-01-04 12:46:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dogs",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948897875886526464",
  "text" : "RT @Snapzu_Earth: Daily Fact: Apple and pear seeds contain arsenic, which may be deadly to #dogs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dogs",
        "indices" : [ 73, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948842085582454785",
    "text" : "Daily Fact: Apple and pear seeds contain arsenic, which may be deadly to #dogs.",
    "id" : 948842085582454785,
    "created_at" : "2018-01-04 09:02:36 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948897875886526464,
  "created_at" : "2018-01-04 12:44:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/yUH9cTZFlu",
      "expanded_url" : "https:\/\/www.diyphotography.net\/godox-accidentally-leaks-new-ad600pro-strobe-much-needed-upgrades\/",
      "display_url" : "diyphotography.net\/godox-accident\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948896460225110017",
  "text" : "RT @JayHoque: Godox accidentally leaks new AD600Pro strobe with much needed upgrades: https:\/\/t.co\/yUH9cTZFlu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/yUH9cTZFlu",
        "expanded_url" : "https:\/\/www.diyphotography.net\/godox-accidentally-leaks-new-ad600pro-strobe-much-needed-upgrades\/",
        "display_url" : "diyphotography.net\/godox-accident\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948865194335309825",
    "text" : "Godox accidentally leaks new AD600Pro strobe with much needed upgrades: https:\/\/t.co\/yUH9cTZFlu",
    "id" : 948865194335309825,
    "created_at" : "2018-01-04 10:34:26 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948896460225110017,
  "created_at" : "2018-01-04 12:38:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cricket",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948896414175776768",
  "text" : "RT @Snapzu_Science: Daily Fact: The ears of a #cricket are located on the front legs, just below the knee.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cricket",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948790456862752769",
    "text" : "Daily Fact: The ears of a #cricket are located on the front legs, just below the knee.",
    "id" : 948790456862752769,
    "created_at" : "2018-01-04 05:37:27 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948896414175776768,
  "created_at" : "2018-01-04 12:38:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "Dell",
      "screen_name" : "Dell",
      "indices" : [ 27, 32 ],
      "id_str" : "58561993",
      "id" : 58561993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Ec383wKl8R",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/dell-xps-13-ultra-thin-laptop-2018,36220.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/dell-xps-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948870602567372800",
  "text" : "RT @tomshardware: \u25B8 Latest @Dell XPS 13 Laptop Sports Kaby Lake-R, New Cooling https:\/\/t.co\/Ec383wKl8R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dell",
        "screen_name" : "Dell",
        "indices" : [ 9, 14 ],
        "id_str" : "58561993",
        "id" : 58561993
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/Ec383wKl8R",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/dell-xps-13-ultra-thin-laptop-2018,36220.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/dell-xps-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948795145406767104",
    "text" : "\u25B8 Latest @Dell XPS 13 Laptop Sports Kaby Lake-R, New Cooling https:\/\/t.co\/Ec383wKl8R",
    "id" : 948795145406767104,
    "created_at" : "2018-01-04 05:56:05 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948870602567372800,
  "created_at" : "2018-01-04 10:55:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WooCommerce",
      "screen_name" : "WooCommerce",
      "indices" : [ 3, 15 ],
      "id_str" : "3250053558",
      "id" : 3250053558
    }, {
      "name" : "Amazon Pay",
      "screen_name" : "amazonpay",
      "indices" : [ 26, 36 ],
      "id_str" : "17445595",
      "id" : 17445595
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WooCommerce",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948790832580190208",
  "text" : "RT @WooCommerce: Our free @AmazonPay plugin for #WooCommerce may help your Amazon customers skip a few steps, allowing them to checkout usi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon Pay",
        "screen_name" : "amazonpay",
        "indices" : [ 9, 19 ],
        "id_str" : "17445595",
        "id" : 17445595
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WooCommerce",
        "indices" : [ 31, 43 ]
      }, {
        "text" : "Amazon",
        "indices" : [ 146, 153 ]
      } ],
      "urls" : [ {
        "indices" : [ 200, 223 ],
        "url" : "https:\/\/t.co\/ElJYkK1amx",
        "expanded_url" : "http:\/\/amzn.to\/APWooPlugin?utm_campaign=coschedule&utm_source=twitter&utm_medium=WooCommerce",
        "display_url" : "amzn.to\/APWooPlugin?ut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "946304235150471168",
    "text" : "Our free @AmazonPay plugin for #WooCommerce may help your Amazon customers skip a few steps, allowing them to checkout using information in their #Amazon accounts \u2013 without ever leaving your site. \uD83D\uDE4C\n\nhttps:\/\/t.co\/ElJYkK1amx",
    "id" : 946304235150471168,
    "created_at" : "2017-12-28 08:58:05 +0000",
    "user" : {
      "name" : "WooCommerce",
      "screen_name" : "WooCommerce",
      "protected" : false,
      "id_str" : "3250053558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941189640530382848\/XwM9hS5r_normal.jpg",
      "id" : 3250053558,
      "verified" : true
    }
  },
  "id" : 948790832580190208,
  "created_at" : "2018-01-04 05:38:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WP Engine Support",
      "screen_name" : "WPESupport",
      "indices" : [ 3, 14 ],
      "id_str" : "627901257",
      "id" : 627901257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/SvvjeMBcAh",
      "expanded_url" : "https:\/\/wpengine.com\/resources\/the-ultimate-guide-to-the-wordpress-rest-api\/",
      "display_url" : "wpengine.com\/resources\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948790739097530375",
  "text" : "RT @WPESupport: The Ultimate Guide to the #WordPress API [Ebook] https:\/\/t.co\/SvvjeMBcAh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/SvvjeMBcAh",
        "expanded_url" : "https:\/\/wpengine.com\/resources\/the-ultimate-guide-to-the-wordpress-rest-api\/",
        "display_url" : "wpengine.com\/resources\/the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "847886224530567169",
    "text" : "The Ultimate Guide to the #WordPress API [Ebook] https:\/\/t.co\/SvvjeMBcAh",
    "id" : 847886224530567169,
    "created_at" : "2017-03-31 19:00:03 +0000",
    "user" : {
      "name" : "WP Engine Support",
      "screen_name" : "WPESupport",
      "protected" : false,
      "id_str" : "627901257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889521424242585602\/YubW9sFx_normal.jpg",
      "id" : 627901257,
      "verified" : false
    }
  },
  "id" : 948790739097530375,
  "created_at" : "2018-01-04 05:38:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WP Engine",
      "screen_name" : "wpengine",
      "indices" : [ 3, 12 ],
      "id_str" : "121880027",
      "id" : 121880027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ecommerce",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/gDrbemtpPL",
      "expanded_url" : "https:\/\/wpeng.in\/71dd98\/",
      "display_url" : "wpeng.in\/71dd98\/"
    } ]
  },
  "geo" : { },
  "id_str" : "948790692482113537",
  "text" : "RT @wpengine: How to choose the best #ecommerce platform for your business. https:\/\/t.co\/gDrbemtpPL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ecommerce",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/gDrbemtpPL",
        "expanded_url" : "https:\/\/wpeng.in\/71dd98\/",
        "display_url" : "wpeng.in\/71dd98\/"
      } ]
    },
    "geo" : { },
    "id_str" : "948592304809480192",
    "text" : "How to choose the best #ecommerce platform for your business. https:\/\/t.co\/gDrbemtpPL",
    "id" : 948592304809480192,
    "created_at" : "2018-01-03 16:30:04 +0000",
    "user" : {
      "name" : "WP Engine",
      "screen_name" : "wpengine",
      "protected" : false,
      "id_str" : "121880027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875512018035331072\/T-bDcrEW_normal.jpg",
      "id" : 121880027,
      "verified" : true
    }
  },
  "id" : 948790692482113537,
  "created_at" : "2018-01-04 05:38:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/7AVHrgjkGn",
      "expanded_url" : "http:\/\/wpbeg.in\/2o6MdNy",
      "display_url" : "wpbeg.in\/2o6MdNy"
    } ]
  },
  "geo" : { },
  "id_str" : "948790668683632640",
  "text" : "RT @wpbeginner: How to Insert Ads within your Post Content in #WordPress -  https:\/\/t.co\/7AVHrgjkGn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/7AVHrgjkGn",
        "expanded_url" : "http:\/\/wpbeg.in\/2o6MdNy",
        "display_url" : "wpbeg.in\/2o6MdNy"
      } ]
    },
    "geo" : { },
    "id_str" : "948758392507641856",
    "text" : "How to Insert Ads within your Post Content in #WordPress -  https:\/\/t.co\/7AVHrgjkGn",
    "id" : 948758392507641856,
    "created_at" : "2018-01-04 03:30:02 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 948790668683632640,
  "created_at" : "2018-01-04 05:38:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/OdsPeArR0J",
      "expanded_url" : "http:\/\/wpbeg.in\/2o2RZQ2",
      "display_url" : "wpbeg.in\/2o2RZQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "948790658982203393",
  "text" : "RT @wpbeginner: How to Add Tables in #WordPress Posts and Pages (No HTML Required) - https:\/\/t.co\/OdsPeArR0J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/OdsPeArR0J",
        "expanded_url" : "http:\/\/wpbeg.in\/2o2RZQ2",
        "display_url" : "wpbeg.in\/2o2RZQ2"
      } ]
    },
    "geo" : { },
    "id_str" : "948708809295450112",
    "text" : "How to Add Tables in #WordPress Posts and Pages (No HTML Required) - https:\/\/t.co\/OdsPeArR0J",
    "id" : 948708809295450112,
    "created_at" : "2018-01-04 00:13:00 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 948790658982203393,
  "created_at" : "2018-01-04 05:38:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "indices" : [ 3, 13 ],
      "id_str" : "685513",
      "id" : 685513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/PdbIdhRGKb",
      "expanded_url" : "https:\/\/wordpress.org\/news\/2018\/01\/the-month-in-wordpress-december-2017\/",
      "display_url" : "wordpress.org\/news\/2018\/01\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948790616275783680",
  "text" : "RT @WordPress: The Month in WordPress: December 2017 https:\/\/t.co\/PdbIdhRGKb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/PdbIdhRGKb",
        "expanded_url" : "https:\/\/wordpress.org\/news\/2018\/01\/the-month-in-wordpress-december-2017\/",
        "display_url" : "wordpress.org\/news\/2018\/01\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948494314140766209",
    "text" : "The Month in WordPress: December 2017 https:\/\/t.co\/PdbIdhRGKb",
    "id" : 948494314140766209,
    "created_at" : "2018-01-03 10:00:41 +0000",
    "user" : {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "protected" : false,
      "id_str" : "685513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59801350\/logo_normal.png",
      "id" : 685513,
      "verified" : true
    }
  },
  "id" : 948790616275783680,
  "created_at" : "2018-01-04 05:38:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948790342622613505",
  "text" : "RT @ausecure: Streaming #Gold $1315.6 -$3.3\/0.25% #Silver $17.15 -$0.08\/0.47% #Platinum $949.3 +$1.7\/0.18% #Palladium $1087 -$10.4\/0.96%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948539483028410368",
    "text" : "Streaming #Gold $1315.6 -$3.3\/0.25% #Silver $17.15 -$0.08\/0.47% #Platinum $949.3 +$1.7\/0.18% #Palladium $1087 -$10.4\/0.96%",
    "id" : 948539483028410368,
    "created_at" : "2018-01-03 13:00:10 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 948790342622613505,
  "created_at" : "2018-01-04 05:37:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AdafruitTopTen",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/geR9JFnmvT",
      "expanded_url" : "https:\/\/adafru.it\/ApT",
      "display_url" : "adafru.it\/ApT"
    } ]
  },
  "geo" : { },
  "id_str" : "948789695487643648",
  "text" : "RT @adafruit: Adafruit\u2019s Top Ten 3D Printed Projects on Thingiverse of 2017 #AdafruitTopTen https:\/\/t.co\/geR9JFnmvT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AdafruitTopTen",
        "indices" : [ 62, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/geR9JFnmvT",
        "expanded_url" : "https:\/\/adafru.it\/ApT",
        "display_url" : "adafru.it\/ApT"
      } ]
    },
    "geo" : { },
    "id_str" : "948788802625179649",
    "text" : "Adafruit\u2019s Top Ten 3D Printed Projects on Thingiverse of 2017 #AdafruitTopTen https:\/\/t.co\/geR9JFnmvT",
    "id" : 948788802625179649,
    "created_at" : "2018-01-04 05:30:52 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 948789695487643648,
  "created_at" : "2018-01-04 05:34:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Tito Hamze",
      "screen_name" : "titoyooo",
      "indices" : [ 114, 123 ],
      "id_str" : "1853470208",
      "id" : 1853470208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/zs8iw4L3b2",
      "expanded_url" : "http:\/\/tcrn.ch\/2ESTq8i",
      "display_url" : "tcrn.ch\/2ESTq8i"
    } ]
  },
  "geo" : { },
  "id_str" : "948789138312060928",
  "text" : "RT @TechCrunch: Crunch Report | MoneyGram's Sale to Alibaba Blocked by U\u2024S\u2024 Government https:\/\/t.co\/zs8iw4L3b2 by @titoyooo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tito Hamze",
        "screen_name" : "titoyooo",
        "indices" : [ 98, 107 ],
        "id_str" : "1853470208",
        "id" : 1853470208
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/zs8iw4L3b2",
        "expanded_url" : "http:\/\/tcrn.ch\/2ESTq8i",
        "display_url" : "tcrn.ch\/2ESTq8i"
      } ]
    },
    "geo" : { },
    "id_str" : "948766091131711488",
    "text" : "Crunch Report | MoneyGram's Sale to Alibaba Blocked by U\u2024S\u2024 Government https:\/\/t.co\/zs8iw4L3b2 by @titoyooo",
    "id" : 948766091131711488,
    "created_at" : "2018-01-04 04:00:38 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879359733936701440\/sitcq7wY_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 948789138312060928,
  "created_at" : "2018-01-04 05:32:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "indices" : [ 3, 13 ],
      "id_str" : "76997832",
      "id" : 76997832
    }, {
      "name" : "Derek Halpern",
      "screen_name" : "derekhalpern",
      "indices" : [ 15, 28 ],
      "id_str" : "15323979",
      "id" : 15323979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948788775366418433",
  "text" : "RT @zachbraff: @derekhalpern The controversy will bring him millions of views. He plugs his merch. He\u2019s the talk of the planet. He will mak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Derek Halpern",
        "screen_name" : "derekhalpern",
        "indices" : [ 0, 13 ],
        "id_str" : "15323979",
        "id" : 15323979
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948300690463617025",
    "geo" : { },
    "id_str" : "948304527148666880",
    "in_reply_to_user_id" : 15323979,
    "text" : "@derekhalpern The controversy will bring him millions of views. He plugs his merch. He\u2019s the talk of the planet. He will make money off of this video. The choice to be evil was monetized.",
    "id" : 948304527148666880,
    "in_reply_to_status_id" : 948300690463617025,
    "created_at" : "2018-01-02 21:26:32 +0000",
    "in_reply_to_screen_name" : "derekhalpern",
    "in_reply_to_user_id_str" : "15323979",
    "user" : {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "protected" : false,
      "id_str" : "76997832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588958455370625025\/xm8yowKs_normal.jpg",
      "id" : 76997832,
      "verified" : true
    }
  },
  "id" : 948788775366418433,
  "created_at" : "2018-01-04 05:30:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/G7SlOBP8Vq",
      "expanded_url" : "http:\/\/engt.co\/2E4Ob3Q",
      "display_url" : "engt.co\/2E4Ob3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "948788469425426432",
  "text" : "RT @engadget: AT&amp;T will launch real mobile 5G in 12 cities this year https:\/\/t.co\/G7SlOBP8Vq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/G7SlOBP8Vq",
        "expanded_url" : "http:\/\/engt.co\/2E4Ob3Q",
        "display_url" : "engt.co\/2E4Ob3Q"
      } ]
    },
    "geo" : { },
    "id_str" : "948782947884290048",
    "text" : "AT&amp;T will launch real mobile 5G in 12 cities this year https:\/\/t.co\/G7SlOBP8Vq",
    "id" : 948782947884290048,
    "created_at" : "2018-01-04 05:07:36 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948788469425426432,
  "created_at" : "2018-01-04 05:29:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/S4fT3iMu4g",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/best-free-backgrounds-logo\/",
      "display_url" : "webdesigndev.com\/best-free-back\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948788383001841665",
  "text" : "RT @WebDesignDev: 100+ Best Free Backgrounds for Logo Presentations: https:\/\/t.co\/S4fT3iMu4g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/S4fT3iMu4g",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/best-free-backgrounds-logo\/",
        "display_url" : "webdesigndev.com\/best-free-back\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948784333590093825",
    "text" : "100+ Best Free Backgrounds for Logo Presentations: https:\/\/t.co\/S4fT3iMu4g",
    "id" : 948784333590093825,
    "created_at" : "2018-01-04 05:13:07 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948788383001841665,
  "created_at" : "2018-01-04 05:29:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torrey Gazette",
      "screen_name" : "TorreyGazette",
      "indices" : [ 0, 14 ],
      "id_str" : "2705601589",
      "id" : 2705601589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948776844446388224",
  "geo" : { },
  "id_str" : "948788351309615105",
  "in_reply_to_user_id" : 2705601589,
  "text" : "@TorreyGazette Done :)",
  "id" : 948788351309615105,
  "in_reply_to_status_id" : 948776844446388224,
  "created_at" : "2018-01-04 05:29:05 +0000",
  "in_reply_to_screen_name" : "TorreyGazette",
  "in_reply_to_user_id_str" : "2705601589",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948787897695653888\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/LFplOUMkCV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSrFStXW4AExPd2.jpg",
      "id_str" : "948787596720791553",
      "id" : 948787596720791553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSrFStXW4AExPd2.jpg",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 1512
      } ],
      "display_url" : "pic.twitter.com\/LFplOUMkCV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948787897695653888",
  "text" : "I said a week ago, $XRP should pass a $3 target before mid January. This prediction already came true. https:\/\/t.co\/LFplOUMkCV",
  "id" : 948787897695653888,
  "created_at" : "2018-01-04 05:27:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948775900379799553",
  "text" : "RT @BONNIELYNN2015: Go do some sit ups and drink some water you\u2019ll feel better maybe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948774485552873472",
    "text" : "Go do some sit ups and drink some water you\u2019ll feel better maybe",
    "id" : 948774485552873472,
    "created_at" : "2018-01-04 04:33:59 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946587001930711040\/6K0BSqwc_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 948775900379799553,
  "created_at" : "2018-01-04 04:39:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Webb design",
      "screen_name" : "owebbdesign",
      "indices" : [ 3, 15 ],
      "id_str" : "946147297653592064",
      "id" : 946147297653592064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948775653918330880",
  "text" : "RT @owebbdesign: Bit late to the show, but I'm now on twitter, will be posting my thoughts on design, sustainability and anything else that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "productdesign",
        "indices" : [ 142, 156 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948620305676800000",
    "text" : "Bit late to the show, but I'm now on twitter, will be posting my thoughts on design, sustainability and anything else that I find interesting #productdesign",
    "id" : 948620305676800000,
    "created_at" : "2018-01-03 18:21:20 +0000",
    "user" : {
      "name" : "Oliver Webb design",
      "screen_name" : "owebbdesign",
      "protected" : false,
      "id_str" : "946147297653592064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948613498803838976\/xm2WPmsV_normal.jpg",
      "id" : 946147297653592064,
      "verified" : false
    }
  },
  "id" : 948775653918330880,
  "created_at" : "2018-01-04 04:38:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhruti Krishnan",
      "screen_name" : "DhrutiKrishnan",
      "indices" : [ 3, 18 ],
      "id_str" : "2934317616",
      "id" : 2934317616
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CustomerExperience",
      "indices" : [ 97, 116 ]
    }, {
      "text" : "concepttesting",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948775612956672000",
  "text" : "RT @DhrutiKrishnan: \u201CCustomers do know what they want, but only AFTER they see or experience it\" #CustomerExperience  #concepttesting #cust\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CustomerExperience",
        "indices" : [ 77, 96 ]
      }, {
        "text" : "concepttesting",
        "indices" : [ 98, 113 ]
      }, {
        "text" : "custserv",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "productdesign",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948722963615965184",
    "text" : "\u201CCustomers do know what they want, but only AFTER they see or experience it\" #CustomerExperience  #concepttesting #custserv #productdesign",
    "id" : 948722963615965184,
    "created_at" : "2018-01-04 01:09:15 +0000",
    "user" : {
      "name" : "Dhruti Krishnan",
      "screen_name" : "DhrutiKrishnan",
      "protected" : false,
      "id_str" : "2934317616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650161066186440705\/5rIBfyZG_normal.jpg",
      "id" : 2934317616,
      "verified" : false
    }
  },
  "id" : 948775612956672000,
  "created_at" : "2018-01-04 04:38:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrys Sbily",
      "screen_name" : "CSbily",
      "indices" : [ 3, 10 ],
      "id_str" : "108633810",
      "id" : 108633810
    }, {
      "name" : "Dezeen",
      "screen_name" : "dezeen",
      "indices" : [ 12, 19 ],
      "id_str" : "26012202",
      "id" : 26012202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948775541775241216",
  "text" : "RT @CSbily: @dezeen's top design stories of 2017 -- my personal fave is the \"chair that you wear\".  Can't wait to see what 2018 will bring!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dezeen",
        "screen_name" : "dezeen",
        "indices" : [ 0, 7 ],
        "id_str" : "26012202",
        "id" : 26012202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "productdesign",
        "indices" : [ 128, 142 ]
      }, {
        "text" : "innovation",
        "indices" : [ 143, 154 ]
      }, {
        "text" : "designforgood",
        "indices" : [ 155, 169 ]
      } ],
      "urls" : [ {
        "indices" : [ 170, 193 ],
        "url" : "https:\/\/t.co\/bmvjeTa6sM",
        "expanded_url" : "https:\/\/www.dezeen.com\/2017\/12\/24\/top-10-biggest-architecture-design-stories-review-2017\/",
        "display_url" : "dezeen.com\/2017\/12\/24\/top\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948742145258770432",
    "in_reply_to_user_id" : 26012202,
    "text" : "@dezeen's top design stories of 2017 -- my personal fave is the \"chair that you wear\".  Can't wait to see what 2018 will bring! #productdesign #innovation #designforgood\nhttps:\/\/t.co\/bmvjeTa6sM",
    "id" : 948742145258770432,
    "created_at" : "2018-01-04 02:25:28 +0000",
    "in_reply_to_screen_name" : "dezeen",
    "in_reply_to_user_id_str" : "26012202",
    "user" : {
      "name" : "Chrys Sbily",
      "screen_name" : "CSbily",
      "protected" : false,
      "id_str" : "108633810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867704865778266112\/IpPTPJ9q_normal.jpg",
      "id" : 108633810,
      "verified" : false
    }
  },
  "id" : 948775541775241216,
  "created_at" : "2018-01-04 04:38:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univet Eyewear",
      "screen_name" : "UnivetEyewear",
      "indices" : [ 3, 17 ],
      "id_str" : "1534347818",
      "id" : 1534347818
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "protective",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "GermanDesignAward",
      "indices" : [ 71, 89 ]
    }, {
      "text" : "ProductDesign",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948775267857813504",
  "text" : "RT @UnivetEyewear: Univet 6X3 #protective goggles is the Winner of the #GermanDesignAward 2018 for the \u201CExcellent #ProductDesign\u201D in the \u201C#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "protective",
        "indices" : [ 11, 22 ]
      }, {
        "text" : "GermanDesignAward",
        "indices" : [ 52, 70 ]
      }, {
        "text" : "ProductDesign",
        "indices" : [ 95, 109 ]
      }, {
        "text" : "Industry",
        "indices" : [ 119, 128 ]
      }, {
        "text" : "Design",
        "indices" : [ 154, 161 ]
      } ],
      "urls" : [ {
        "indices" : [ 245, 268 ],
        "url" : "https:\/\/t.co\/KJiDKTJKm6",
        "expanded_url" : "http:\/\/bit.ly\/2Cngfis",
        "display_url" : "bit.ly\/2Cngfis"
      } ]
    },
    "geo" : { },
    "id_str" : "948630085959061505",
    "text" : "Univet 6X3 #protective goggles is the Winner of the #GermanDesignAward 2018 for the \u201CExcellent #ProductDesign\u201D in the \u201C#Industry\u201D category. Download the \u2018#Design Explorer\u2019 app and vote us in the \u201CPublic's Choice selection\u201D to make it win again: https:\/\/t.co\/KJiDKTJKm6",
    "id" : 948630085959061505,
    "created_at" : "2018-01-03 19:00:11 +0000",
    "user" : {
      "name" : "Univet Eyewear",
      "screen_name" : "UnivetEyewear",
      "protected" : false,
      "id_str" : "1534347818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604670343408693248\/w1i_DRAR_normal.jpg",
      "id" : 1534347818,
      "verified" : false
    }
  },
  "id" : 948775267857813504,
  "created_at" : "2018-01-04 04:37:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "25053299",
      "id" : 25053299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/VnZNPEKvIb",
      "expanded_url" : "http:\/\/for.tn\/2DZGHiU",
      "display_url" : "for.tn\/2DZGHiU"
    } ]
  },
  "geo" : { },
  "id_str" : "948775150148882433",
  "text" : "RT @FortuneMagazine: Look at these incredible photos of the SpaceX Falcon Heavy rocket https:\/\/t.co\/VnZNPEKvIb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/VnZNPEKvIb",
        "expanded_url" : "http:\/\/for.tn\/2DZGHiU",
        "display_url" : "for.tn\/2DZGHiU"
      } ]
    },
    "geo" : { },
    "id_str" : "948750933873299458",
    "text" : "Look at these incredible photos of the SpaceX Falcon Heavy rocket https:\/\/t.co\/VnZNPEKvIb",
    "id" : 948750933873299458,
    "created_at" : "2018-01-04 03:00:24 +0000",
    "user" : {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "protected" : false,
      "id_str" : "25053299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875382047216467972\/3119VjuE_normal.jpg",
      "id" : 25053299,
      "verified" : true
    }
  },
  "id" : 948775150148882433,
  "created_at" : "2018-01-04 04:36:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "25053299",
      "id" : 25053299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/4yimJeKq0g",
      "expanded_url" : "http:\/\/for.tn\/2E2XfXk",
      "display_url" : "for.tn\/2E2XfXk"
    } ]
  },
  "geo" : { },
  "id_str" : "948774853284376576",
  "text" : "RT @FortuneMagazine: Silicon Valley, if you\u2019re not watching \u2018Black Mirror,\u2019 you should https:\/\/t.co\/4yimJeKq0g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/4yimJeKq0g",
        "expanded_url" : "http:\/\/for.tn\/2E2XfXk",
        "display_url" : "for.tn\/2E2XfXk"
      } ]
    },
    "geo" : { },
    "id_str" : "948773554748870656",
    "text" : "Silicon Valley, if you\u2019re not watching \u2018Black Mirror,\u2019 you should https:\/\/t.co\/4yimJeKq0g",
    "id" : 948773554748870656,
    "created_at" : "2018-01-04 04:30:17 +0000",
    "user" : {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "protected" : false,
      "id_str" : "25053299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875382047216467972\/3119VjuE_normal.jpg",
      "id" : 25053299,
      "verified" : true
    }
  },
  "id" : 948774853284376576,
  "created_at" : "2018-01-04 04:35:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schwartz",
      "screen_name" : "JoelKatz",
      "indices" : [ 3, 12 ],
      "id_str" : "35749949",
      "id" : 35749949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/DN4VmZs3Ic",
      "expanded_url" : "https:\/\/twitter.com\/cryptocoley\/status\/948331369662373888",
      "display_url" : "twitter.com\/cryptocoley\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948774584379166720",
  "text" : "RT @JoelKatz: This would make me so happy! https:\/\/t.co\/DN4VmZs3Ic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/DN4VmZs3Ic",
        "expanded_url" : "https:\/\/twitter.com\/cryptocoley\/status\/948331369662373888",
        "display_url" : "twitter.com\/cryptocoley\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948343099687714816",
    "text" : "This would make me so happy! https:\/\/t.co\/DN4VmZs3Ic",
    "id" : 948343099687714816,
    "created_at" : "2018-01-02 23:59:48 +0000",
    "user" : {
      "name" : "David Schwartz",
      "screen_name" : "JoelKatz",
      "protected" : false,
      "id_str" : "35749949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757519456545366016\/47RG1n2b_normal.jpg",
      "id" : 35749949,
      "verified" : false
    }
  },
  "id" : 948774584379166720,
  "created_at" : "2018-01-04 04:34:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP [DELETE COINMARKETCAP]",
      "screen_name" : "_Kevin_Pham",
      "indices" : [ 3, 15 ],
      "id_str" : "2395318063",
      "id" : 2395318063
    }, {
      "name" : "jratcliff63367",
      "screen_name" : "jratcliff",
      "indices" : [ 17, 27 ],
      "id_str" : "15842690",
      "id" : 15842690
    }, {
      "name" : "David Schwartz",
      "screen_name" : "JoelKatz",
      "indices" : [ 57, 66 ],
      "id_str" : "35749949",
      "id" : 35749949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948774532885700614",
  "text" : "RT @_Kevin_Pham: @jratcliff Ripple's Chief Cryptographer @JoelKatz even admits he doesn't understand this price action.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jratcliff63367",
        "screen_name" : "jratcliff",
        "indices" : [ 0, 10 ],
        "id_str" : "15842690",
        "id" : 15842690
      }, {
        "name" : "David Schwartz",
        "screen_name" : "JoelKatz",
        "indices" : [ 40, 49 ],
        "id_str" : "35749949",
        "id" : 35749949
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948707729375248384",
    "geo" : { },
    "id_str" : "948716976939008000",
    "in_reply_to_user_id" : 15842690,
    "text" : "@jratcliff Ripple's Chief Cryptographer @JoelKatz even admits he doesn't understand this price action.",
    "id" : 948716976939008000,
    "in_reply_to_status_id" : 948707729375248384,
    "created_at" : "2018-01-04 00:45:28 +0000",
    "in_reply_to_screen_name" : "jratcliff",
    "in_reply_to_user_id_str" : "15842690",
    "user" : {
      "name" : "KP [DELETE COINMARKETCAP]",
      "screen_name" : "_Kevin_Pham",
      "protected" : false,
      "id_str" : "2395318063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943269518318505984\/hB6TkL6P_normal.jpg",
      "id" : 2395318063,
      "verified" : false
    }
  },
  "id" : 948774532885700614,
  "created_at" : "2018-01-04 04:34:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Lynn",
      "screen_name" : "justinrwlynn",
      "indices" : [ 3, 16 ],
      "id_str" : "3312805083",
      "id" : 3312805083
    }, {
      "name" : "SeatsForEveryone.com",
      "screen_name" : "seatsforevery1",
      "indices" : [ 18, 33 ],
      "id_str" : "717347509190811648",
      "id" : 717347509190811648
    }, {
      "name" : "KP [DELETE COINMARKETCAP]",
      "screen_name" : "_Kevin_Pham",
      "indices" : [ 34, 46 ],
      "id_str" : "2395318063",
      "id" : 2395318063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948774511733821440",
  "text" : "RT @justinrwlynn: @seatsforevery1 @_Kevin_Pham Sure, and presumably you value that $XRP as much as the $BTC you just gave up and other peop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SeatsForEveryone.com",
        "screen_name" : "seatsforevery1",
        "indices" : [ 0, 15 ],
        "id_str" : "717347509190811648",
        "id" : 717347509190811648
      }, {
        "name" : "KP [DELETE COINMARKETCAP]",
        "screen_name" : "_Kevin_Pham",
        "indices" : [ 16, 28 ],
        "id_str" : "2395318063",
        "id" : 2395318063
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948641480679280640",
    "geo" : { },
    "id_str" : "948642197561200640",
    "in_reply_to_user_id" : 717347509190811648,
    "text" : "@seatsforevery1 @_Kevin_Pham Sure, and presumably you value that $XRP as much as the $BTC you just gave up and other people do as well... that's how trading prices get set in a global economy with multiple currency pairs.",
    "id" : 948642197561200640,
    "in_reply_to_status_id" : 948641480679280640,
    "created_at" : "2018-01-03 19:48:19 +0000",
    "in_reply_to_screen_name" : "seatsforevery1",
    "in_reply_to_user_id_str" : "717347509190811648",
    "user" : {
      "name" : "Justin Lynn",
      "screen_name" : "justinrwlynn",
      "protected" : false,
      "id_str" : "3312805083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607803643400626176\/1T_RM-xn_normal.jpg",
      "id" : 3312805083,
      "verified" : false
    }
  },
  "id" : 948774511733821440,
  "created_at" : "2018-01-04 04:34:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Lynn",
      "screen_name" : "justinrwlynn",
      "indices" : [ 3, 16 ],
      "id_str" : "3312805083",
      "id" : 3312805083
    }, {
      "name" : "KP [DELETE CONBASE]",
      "screen_name" : "_Kevin_Pham",
      "indices" : [ 18, 30 ],
      "id_str" : "2395318063",
      "id" : 2395318063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948774504322486272",
  "text" : "RT @justinrwlynn: @_Kevin_Pham Mate, $XRP isn't competing with $BTC ... it's addressing a different market. If anything it's helping people\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KP [DELETE CONBASE]",
        "screen_name" : "_Kevin_Pham",
        "indices" : [ 0, 12 ],
        "id_str" : "2395318063",
        "id" : 2395318063
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948627095403446273",
    "geo" : { },
    "id_str" : "948627773626568704",
    "in_reply_to_user_id" : 2395318063,
    "text" : "@_Kevin_Pham Mate, $XRP isn't competing with $BTC ... it's addressing a different market. If anything it's helping people become more comfortable with blockchain tech. $BTC will always have a place as a store of value -- it's digital gold. But the world needs more than that.",
    "id" : 948627773626568704,
    "in_reply_to_status_id" : 948627095403446273,
    "created_at" : "2018-01-03 18:51:00 +0000",
    "in_reply_to_screen_name" : "_Kevin_Pham",
    "in_reply_to_user_id_str" : "2395318063",
    "user" : {
      "name" : "Justin Lynn",
      "screen_name" : "justinrwlynn",
      "protected" : false,
      "id_str" : "3312805083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607803643400626176\/1T_RM-xn_normal.jpg",
      "id" : 3312805083,
      "verified" : false
    }
  },
  "id" : 948774504322486272,
  "created_at" : "2018-01-04 04:34:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Wire",
      "screen_name" : "realDailyWire",
      "indices" : [ 3, 17 ],
      "id_str" : "4081106480",
      "id" : 4081106480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948773956114411520",
  "text" : "RT @realDailyWire: The Facebook Comments On Oregon's Decision To Allow Motorists To Pump Their Own Gas Will Make Your Day https:\/\/t.co\/n9Xr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/n9XrnCXnRl",
        "expanded_url" : "http:\/\/bit.ly\/2lTy8yK",
        "display_url" : "bit.ly\/2lTy8yK"
      } ]
    },
    "geo" : { },
    "id_str" : "948773672378126336",
    "text" : "The Facebook Comments On Oregon's Decision To Allow Motorists To Pump Their Own Gas Will Make Your Day https:\/\/t.co\/n9XrnCXnRl",
    "id" : 948773672378126336,
    "created_at" : "2018-01-04 04:30:45 +0000",
    "user" : {
      "name" : "The Daily Wire",
      "screen_name" : "realDailyWire",
      "protected" : false,
      "id_str" : "4081106480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660488928240119808\/QqX7ED73_normal.png",
      "id" : 4081106480,
      "verified" : true
    }
  },
  "id" : 948773956114411520,
  "created_at" : "2018-01-04 04:31:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 112, 126 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oxygen",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "lithium",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/XCM7Vygs7e",
      "expanded_url" : "http:\/\/medx.cc\/434216551",
      "display_url" : "medx.cc\/434216551"
    } ]
  },
  "geo" : { },
  "id_str" : "948772581494198272",
  "text" : "RT @TechXplore_com: Battery leverages both iron and #oxygen to drive more #lithium ions https:\/\/t.co\/XCM7Vygs7e @northwesternu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Northwestern",
        "screen_name" : "NorthwesternU",
        "indices" : [ 92, 106 ],
        "id_str" : "33639255",
        "id" : 33639255
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oxygen",
        "indices" : [ 32, 39 ]
      }, {
        "text" : "lithium",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/XCM7Vygs7e",
        "expanded_url" : "http:\/\/medx.cc\/434216551",
        "display_url" : "medx.cc\/434216551"
      } ]
    },
    "geo" : { },
    "id_str" : "948655897521328128",
    "text" : "Battery leverages both iron and #oxygen to drive more #lithium ions https:\/\/t.co\/XCM7Vygs7e @northwesternu",
    "id" : 948655897521328128,
    "created_at" : "2018-01-03 20:42:45 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 948772581494198272,
  "created_at" : "2018-01-04 04:26:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948771692645617664",
  "text" : "RT @BONNIELYNN2015: My house will be an all of my family\u2018s name so when I\u2019m gone do they can share it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948770569603792896",
    "text" : "My house will be an all of my family\u2018s name so when I\u2019m gone do they can share it",
    "id" : 948770569603792896,
    "created_at" : "2018-01-04 04:18:25 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946587001930711040\/6K0BSqwc_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 948771692645617664,
  "created_at" : "2018-01-04 04:22:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moon",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/aMHr1YE63D",
      "expanded_url" : "http:\/\/phy.so\/434217733",
      "display_url" : "phy.so\/434217733"
    } ]
  },
  "geo" : { },
  "id_str" : "948771228952743937",
  "text" : "RT @physorg_com: The #moon is about to do something it hasn't done in more than 150 years https:\/\/t.co\/aMHr1YE63D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moon",
        "indices" : [ 4, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/aMHr1YE63D",
        "expanded_url" : "http:\/\/phy.so\/434217733",
        "display_url" : "phy.so\/434217733"
      } ]
    },
    "geo" : { },
    "id_str" : "948662830177378304",
    "text" : "The #moon is about to do something it hasn't done in more than 150 years https:\/\/t.co\/aMHr1YE63D",
    "id" : 948662830177378304,
    "created_at" : "2018-01-03 21:10:18 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 948771228952743937,
  "created_at" : "2018-01-04 04:21:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948770752513355777",
  "text" : "RT @lorenridinger: \"The first step towards getting somewhere is to decide that you are not going to stay where you are.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948766029727109120",
    "text" : "\"The first step towards getting somewhere is to decide that you are not going to stay where you are.\"",
    "id" : 948766029727109120,
    "created_at" : "2018-01-04 04:00:23 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948770752513355777,
  "created_at" : "2018-01-04 04:19:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948770463668256769",
  "geo" : { },
  "id_str" : "948770693524619270",
  "in_reply_to_user_id" : 210979938,
  "text" : "This analysis was done by a user\/Fan's request\/inquiry",
  "id" : 948770693524619270,
  "in_reply_to_status_id" : 948770463668256769,
  "created_at" : "2018-01-04 04:18:55 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/phjEc27oUn",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BCNBTC\/6RxRzRf2-BCNBTC-Long-Potential\/",
      "display_url" : "tradingview.com\/chart\/BCNBTC\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948770463668256769",
  "text" : "BCNBTC Long Potential - $BCNBTC chart https:\/\/t.co\/phjEc27oUn",
  "id" : 948770463668256769,
  "created_at" : "2018-01-04 04:18:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948759576760995841",
  "text" : "RT @Snapzu_Science: Daily Fact: Every year in the US, 625 people are struck by lightning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948759109221822465",
    "text" : "Daily Fact: Every year in the US, 625 people are struck by lightning.",
    "id" : 948759109221822465,
    "created_at" : "2018-01-04 03:32:53 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948759576760995841,
  "created_at" : "2018-01-04 03:34:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julieanne Kost",
      "screen_name" : "julieannekost",
      "indices" : [ 3, 17 ],
      "id_str" : "30042831",
      "id" : 30042831
    }, {
      "name" : "Behance",
      "screen_name" : "Behance",
      "indices" : [ 44, 52 ],
      "id_str" : "9313022",
      "id" : 9313022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/a5ycbScqTq",
      "expanded_url" : "http:\/\/be.net\/gallery\/59404657\/Tasmania",
      "display_url" : "be.net\/gallery\/594046\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948759517600407552",
  "text" : "RT @julieannekost: Check out new work on my @Behance portfolio: \"Tasmania\" https:\/\/t.co\/a5ycbScqTq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Behance",
        "screen_name" : "Behance",
        "indices" : [ 25, 33 ],
        "id_str" : "9313022",
        "id" : 9313022
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/a5ycbScqTq",
        "expanded_url" : "http:\/\/be.net\/gallery\/59404657\/Tasmania",
        "display_url" : "be.net\/gallery\/594046\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "938581667823869952",
    "text" : "Check out new work on my @Behance portfolio: \"Tasmania\" https:\/\/t.co\/a5ycbScqTq",
    "id" : 938581667823869952,
    "created_at" : "2017-12-07 01:31:22 +0000",
    "user" : {
      "name" : "Julieanne Kost",
      "screen_name" : "julieannekost",
      "protected" : false,
      "id_str" : "30042831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473533623144939520\/3nLyx23A_normal.jpeg",
      "id" : 30042831,
      "verified" : false
    }
  },
  "id" : 948759517600407552,
  "created_at" : "2018-01-04 03:34:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adobe Photoshop",
      "screen_name" : "Photoshop",
      "indices" : [ 3, 13 ],
      "id_str" : "65525881",
      "id" : 65525881
    }, {
      "name" : "Julieanne Kost",
      "screen_name" : "julieannekost",
      "indices" : [ 60, 74 ],
      "id_str" : "30042831",
      "id" : 30042831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Photoshop",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948759422700085249",
  "text" : "RT @Photoshop: For the latest 3, 2, 1...Photoshop tutorial, @julieannekost shares custom keyboard shortcuts for #Photoshop CC: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julieanne Kost",
        "screen_name" : "julieannekost",
        "indices" : [ 45, 59 ],
        "id_str" : "30042831",
        "id" : 30042831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Photoshop",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/1AsDLdqBkb",
        "expanded_url" : "http:\/\/bit.ly\/2lFOsDJ",
        "display_url" : "bit.ly\/2lFOsDJ"
      } ]
    },
    "geo" : { },
    "id_str" : "948240610976075776",
    "text" : "For the latest 3, 2, 1...Photoshop tutorial, @julieannekost shares custom keyboard shortcuts for #Photoshop CC: https:\/\/t.co\/1AsDLdqBkb",
    "id" : 948240610976075776,
    "created_at" : "2018-01-02 17:12:33 +0000",
    "user" : {
      "name" : "Adobe Photoshop",
      "screen_name" : "Photoshop",
      "protected" : false,
      "id_str" : "65525881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880097053816233984\/b64i8TOF_normal.jpg",
      "id" : 65525881,
      "verified" : true
    }
  },
  "id" : 948759422700085249,
  "created_at" : "2018-01-04 03:34:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948759344497283072",
  "text" : "RT @PhotographyTalk: It's a question every photographer considers at least a few times over the course of their lives\n\nhttps:\/\/t.co\/4rfEv78\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/4rfEv78OxC",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7597-what-lens-should-you-buy",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948219641712840704",
    "text" : "It's a question every photographer considers at least a few times over the course of their lives\n\nhttps:\/\/t.co\/4rfEv78OxC",
    "id" : 948219641712840704,
    "created_at" : "2018-01-02 15:49:14 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948759344497283072,
  "created_at" : "2018-01-04 03:33:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "indices" : [ 3, 16 ],
      "id_str" : "474231541",
      "id" : 474231541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948759071544496128",
  "text" : "RT @ImYoungChizz: Not washing your hands before you eat is nasty.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948758586917781504",
    "text" : "Not washing your hands before you eat is nasty.",
    "id" : 948758586917781504,
    "created_at" : "2018-01-04 03:30:48 +0000",
    "user" : {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "protected" : false,
      "id_str" : "474231541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915547694705324033\/shK07ykL_normal.jpg",
      "id" : 474231541,
      "verified" : true
    }
  },
  "id" : 948759071544496128,
  "created_at" : "2018-01-04 03:32:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torrey Gazette",
      "screen_name" : "TorreyGazette",
      "indices" : [ 0, 14 ],
      "id_str" : "2705601589",
      "id" : 2705601589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948756331300827136",
  "geo" : { },
  "id_str" : "948759032172630022",
  "in_reply_to_user_id" : 2705601589,
  "text" : "@TorreyGazette Definitely Oriental Orthodox theology, history of the church, the lives of the saints",
  "id" : 948759032172630022,
  "in_reply_to_status_id" : 948756331300827136,
  "created_at" : "2018-01-04 03:32:35 +0000",
  "in_reply_to_screen_name" : "TorreyGazette",
  "in_reply_to_user_id_str" : "2705601589",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torrey Gazette",
      "screen_name" : "TorreyGazette",
      "indices" : [ 3, 17 ],
      "id_str" : "2705601589",
      "id" : 2705601589
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948758824567140352",
  "text" : "RT @TorreyGazette: @gamer456148 We\u2019d love to hear from you about topics that interest you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948750124779491328",
    "geo" : { },
    "id_str" : "948756331300827136",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 We\u2019d love to hear from you about topics that interest you!",
    "id" : 948756331300827136,
    "in_reply_to_status_id" : 948750124779491328,
    "created_at" : "2018-01-04 03:21:51 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Torrey Gazette",
      "screen_name" : "TorreyGazette",
      "protected" : false,
      "id_str" : "2705601589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638825983143862272\/ORnjYVE7_normal.png",
      "id" : 2705601589,
      "verified" : false
    }
  },
  "id" : 948758824567140352,
  "created_at" : "2018-01-04 03:31:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948758567582158848\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Jpc1fsk35d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSqq4WBXkAAJ-2Z.jpg",
      "id_str" : "948758556475625472",
      "id" : 948758556475625472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSqq4WBXkAAJ-2Z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 919,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 919,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Jpc1fsk35d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948758567582158848",
  "text" : "My smile is trying to hard in this picture, but still look cool (kinda) https:\/\/t.co\/Jpc1fsk35d",
  "id" : 948758567582158848,
  "created_at" : "2018-01-04 03:30:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobsRepair",
      "screen_name" : "BobsRepair",
      "indices" : [ 3, 14 ],
      "id_str" : "901920700583129088",
      "id" : 901920700583129088
    }, {
      "name" : "BobsRepair",
      "screen_name" : "BobsRepair",
      "indices" : [ 16, 27 ],
      "id_str" : "901920700583129088",
      "id" : 901920700583129088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948750772937818114",
  "text" : "RT @BobsRepair: @BobsRepair is excited to announce Brandon Kite as our new CTO. He was previously the Lead Developer at Dragonchain and the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BobsRepair",
        "screen_name" : "BobsRepair",
        "indices" : [ 0, 11 ],
        "id_str" : "901920700583129088",
        "id" : 901920700583129088
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 241, 264 ],
        "url" : "https:\/\/t.co\/gxHMgvX5wW",
        "expanded_url" : "https:\/\/bobsrepair.com\/#news",
        "display_url" : "bobsrepair.com\/#news"
      } ]
    },
    "geo" : { },
    "id_str" : "948298685913288705",
    "in_reply_to_user_id" : 901920700583129088,
    "text" : "@BobsRepair is excited to announce Brandon Kite as our new CTO. He was previously the Lead Developer at Dragonchain and the Senior Software Engineer at The Walt Disney Company. He will be in charge of creating the BOB Application Ecosystem. https:\/\/t.co\/gxHMgvX5wW",
    "id" : 948298685913288705,
    "created_at" : "2018-01-02 21:03:19 +0000",
    "in_reply_to_screen_name" : "BobsRepair",
    "in_reply_to_user_id_str" : "901920700583129088",
    "user" : {
      "name" : "BobsRepair",
      "screen_name" : "BobsRepair",
      "protected" : false,
      "id_str" : "901920700583129088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920709720960221184\/L7JRGrTk_normal.jpg",
      "id" : 901920700583129088,
      "verified" : false
    }
  },
  "id" : 948750772937818114,
  "created_at" : "2018-01-04 02:59:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948750451775868928",
  "text" : "RT @lorenridinger: \"Change is the law of life and those who look only to the past or present are certain to miss the future.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948735884513464320",
    "text" : "\"Change is the law of life and those who look only to the past or present are certain to miss the future.\"",
    "id" : 948735884513464320,
    "created_at" : "2018-01-04 02:00:36 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948750451775868928,
  "created_at" : "2018-01-04 02:58:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/mFgyTysc20",
      "expanded_url" : "http:\/\/on.wsj.com\/2Crysj2",
      "display_url" : "on.wsj.com\/2Crysj2"
    } ]
  },
  "geo" : { },
  "id_str" : "948750398566825985",
  "text" : "RT @WSJ: PayPal founder Peter Thiel is all-in on bitcoin https:\/\/t.co\/mFgyTysc20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/mFgyTysc20",
        "expanded_url" : "http:\/\/on.wsj.com\/2Crysj2",
        "display_url" : "on.wsj.com\/2Crysj2"
      } ]
    },
    "geo" : { },
    "id_str" : "948285286815076353",
    "text" : "PayPal founder Peter Thiel is all-in on bitcoin https:\/\/t.co\/mFgyTysc20",
    "id" : 948285286815076353,
    "created_at" : "2018-01-02 20:10:05 +0000",
    "user" : {
      "name" : "The Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685113343204585473\/jV72Zljq_normal.jpg",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 948750398566825985,
  "created_at" : "2018-01-04 02:58:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948750296540467201",
  "text" : "RT @HelloRyanHolmes: Appointment at 2, then want to film. \nKinda have an idea but not really.\nMaybe a commentary video?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948618531863715840",
    "text" : "Appointment at 2, then want to film. \nKinda have an idea but not really.\nMaybe a commentary video?",
    "id" : 948618531863715840,
    "created_at" : "2018-01-03 18:14:17 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927420432151592960\/VbC3c51I_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 948750296540467201,
  "created_at" : "2018-01-04 02:57:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948750167167193088",
  "text" : "RT @jacksfilms: Try not to film any dead bodies today\n\nI know it's tempting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948592369477152769",
    "text" : "Try not to film any dead bodies today\n\nI know it's tempting",
    "id" : 948592369477152769,
    "created_at" : "2018-01-03 16:30:19 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947545819158401027\/f4tf_yQn_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 948750167167193088,
  "created_at" : "2018-01-04 02:57:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torrey Gazette",
      "screen_name" : "TorreyGazette",
      "indices" : [ 0, 14 ],
      "id_str" : "2705601589",
      "id" : 2705601589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948750124779491328",
  "in_reply_to_user_id" : 2705601589,
  "text" : "@TorreyGazette would love to contribute to your blog sometime",
  "id" : 948750124779491328,
  "created_at" : "2018-01-04 02:57:11 +0000",
  "in_reply_to_screen_name" : "TorreyGazette",
  "in_reply_to_user_id_str" : "2705601589",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ants",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948748187342397440",
  "text" : "RT @Snapzu_Earth: Did you know? #Ants never sleep. Also they don\u2019t have lungs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ants",
        "indices" : [ 14, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948741026331553792",
    "text" : "Did you know? #Ants never sleep. Also they don\u2019t have lungs.",
    "id" : 948741026331553792,
    "created_at" : "2018-01-04 02:21:02 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948748187342397440,
  "created_at" : "2018-01-04 02:49:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/iXwwhk1ycL",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/20-high-quality-twitter-bootstrap-templates\/",
      "display_url" : "webdesigndev.com\/20-high-qualit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948748129519718400",
  "text" : "RT @WebDesignDev: 20 High Quality Twitter Bootstrap Templates: https:\/\/t.co\/iXwwhk1ycL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/iXwwhk1ycL",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/20-high-quality-twitter-bootstrap-templates\/",
        "display_url" : "webdesigndev.com\/20-high-qualit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948745059972911106",
    "text" : "20 High Quality Twitter Bootstrap Templates: https:\/\/t.co\/iXwwhk1ycL",
    "id" : 948745059972911106,
    "created_at" : "2018-01-04 02:37:03 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948748129519718400,
  "created_at" : "2018-01-04 02:49:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Gokhshtein",
      "screen_name" : "davidgokhshtein",
      "indices" : [ 3, 19 ],
      "id_str" : "170049408",
      "id" : 170049408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948748102533566465",
  "text" : "RT @davidgokhshtein: Like I\u2019ve been saying; don\u2019t be surprised if $XRP hits 9-10 without coinbase.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948611914292170753",
    "text" : "Like I\u2019ve been saying; don\u2019t be surprised if $XRP hits 9-10 without coinbase.",
    "id" : 948611914292170753,
    "created_at" : "2018-01-03 17:47:59 +0000",
    "user" : {
      "name" : "David Gokhshtein",
      "screen_name" : "davidgokhshtein",
      "protected" : false,
      "id_str" : "170049408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948642029596237825\/yjM1ayvj_normal.jpg",
      "id" : 170049408,
      "verified" : false
    }
  },
  "id" : 948748102533566465,
  "created_at" : "2018-01-04 02:49:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Wetterlund III",
      "screen_name" : "TheINVIGOR8er",
      "indices" : [ 3, 17 ],
      "id_str" : "25454651",
      "id" : 25454651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948747183217610752",
  "text" : "RT @TheINVIGOR8er: Never be afraid to try something new. Remember, amateurs built the ark. Professionals built the Titanic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948737728664952832",
    "text" : "Never be afraid to try something new. Remember, amateurs built the ark. Professionals built the Titanic.",
    "id" : 948737728664952832,
    "created_at" : "2018-01-04 02:07:55 +0000",
    "user" : {
      "name" : "Ray Wetterlund III",
      "screen_name" : "TheINVIGOR8er",
      "protected" : false,
      "id_str" : "25454651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451910760\/wq2hwvn7ut1e1d127rlb_normal.jpeg",
      "id" : 25454651,
      "verified" : false
    }
  },
  "id" : 948747183217610752,
  "created_at" : "2018-01-04 02:45:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ripple",
      "screen_name" : "Ripple",
      "indices" : [ 3, 10 ],
      "id_str" : "1051053836",
      "id" : 1051053836
    }, {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 58, 66 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/AliCjDFh81",
      "expanded_url" : "https:\/\/twitter.com\/Reuters\/status\/948635115734884354",
      "display_url" : "twitter.com\/Reuters\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948747161436676097",
  "text" : "RT @Ripple: .$XRP was the best performing asset in 2017 - @Reuters has the numbers. https:\/\/t.co\/AliCjDFh81",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reuters Top News",
        "screen_name" : "Reuters",
        "indices" : [ 46, 54 ],
        "id_str" : "1652541",
        "id" : 1652541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/AliCjDFh81",
        "expanded_url" : "https:\/\/twitter.com\/Reuters\/status\/948635115734884354",
        "display_url" : "twitter.com\/Reuters\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948681582415671296",
    "text" : ".$XRP was the best performing asset in 2017 - @Reuters has the numbers. https:\/\/t.co\/AliCjDFh81",
    "id" : 948681582415671296,
    "created_at" : "2018-01-03 22:24:49 +0000",
    "user" : {
      "name" : "Ripple",
      "screen_name" : "Ripple",
      "protected" : false,
      "id_str" : "1051053836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879392946730094592\/IwNebNtK_normal.jpg",
      "id" : 1051053836,
      "verified" : true
    }
  },
  "id" : 948747161436676097,
  "created_at" : "2018-01-04 02:45:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Johnson",
      "screen_name" : "anthonyvlrg",
      "indices" : [ 3, 15 ],
      "id_str" : "128705279",
      "id" : 128705279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xrp",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "ripple",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948747122559606784",
  "text" : "RT @anthonyvlrg: Ripple might hit $4 this week! #xrp #ripple",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "xrp",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "ripple",
        "indices" : [ 36, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948739752416686080",
    "text" : "Ripple might hit $4 this week! #xrp #ripple",
    "id" : 948739752416686080,
    "created_at" : "2018-01-04 02:15:58 +0000",
    "user" : {
      "name" : "Anthony Johnson",
      "screen_name" : "anthonyvlrg",
      "protected" : false,
      "id_str" : "128705279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947280418176491522\/KRb7sCYQ_normal.jpg",
      "id" : 128705279,
      "verified" : false
    }
  },
  "id" : 948747122559606784,
  "created_at" : "2018-01-04 02:45:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bat",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948747077638656000",
  "text" : "RT @Snapzu_Science: Daily Fact: The leg bones of a #bat are so thin that no bat can walk.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bat",
        "indices" : [ 31, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948732154262970368",
    "text" : "Daily Fact: The leg bones of a #bat are so thin that no bat can walk.",
    "id" : 948732154262970368,
    "created_at" : "2018-01-04 01:45:46 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948747077638656000,
  "created_at" : "2018-01-04 02:45:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948746997942677505\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qEaO0PdEzG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSqgU-aXkAA42XE.jpg",
      "id_str" : "948746953726332928",
      "id" : 948746953726332928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSqgU-aXkAA42XE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/qEaO0PdEzG"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948746997942677505\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qEaO0PdEzG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSqgV29WsAAEs1_.jpg",
      "id_str" : "948746968905461760",
      "id" : 948746968905461760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSqgV29WsAAEs1_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 1664
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 1664
      }, {
        "h" : 1057,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/qEaO0PdEzG"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948746997942677505\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/qEaO0PdEzG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSqgWtIWkAAr8eR.jpg",
      "id_str" : "948746983447105536",
      "id" : 948746983447105536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSqgWtIWkAAr8eR.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/qEaO0PdEzG"
    } ],
    "hashtags" : [ {
      "text" : "puppy",
      "indices" : [ 42, 48 ]
    }, {
      "text" : "dogsoftwitter",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948746997942677505",
  "text" : "We must deal with this on a regular basis #puppy #dogsoftwitter https:\/\/t.co\/qEaO0PdEzG",
  "id" : 948746997942677505,
  "created_at" : "2018-01-04 02:44:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readymag",
      "screen_name" : "readymag",
      "indices" : [ 3, 12 ],
      "id_str" : "566196903",
      "id" : 566196903
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 79, 86 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948725726320189442",
  "text" : "RT @readymag: Just wanted to remind you about our first technical long-read on @Medium dedicated to Faster Vertical Viewer implementation.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/amplifr.com\" rel=\"nofollow\"\u003EAmplifr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 65, 72 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 164, 187 ],
        "url" : "https:\/\/t.co\/zFEVqfg9TX",
        "expanded_url" : "http:\/\/amp.gs\/noJq",
        "display_url" : "amp.gs\/noJq"
      } ]
    },
    "geo" : { },
    "id_str" : "944920696093802497",
    "text" : "Just wanted to remind you about our first technical long-read on @Medium dedicated to Faster Vertical Viewer implementation. We call it \u201CReadymag Under the Hood\u201D: \nhttps:\/\/t.co\/zFEVqfg9TX",
    "id" : 944920696093802497,
    "created_at" : "2017-12-24 13:20:24 +0000",
    "user" : {
      "name" : "Readymag",
      "screen_name" : "readymag",
      "protected" : false,
      "id_str" : "566196903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609780882396741632\/7far_K2I_normal.png",
      "id" : 566196903,
      "verified" : false
    }
  },
  "id" : 948725726320189442,
  "created_at" : "2018-01-04 01:20:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Narusson",
      "screen_name" : "MarkNarusson",
      "indices" : [ 3, 16 ],
      "id_str" : "156627074",
      "id" : 156627074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948725568652169221",
  "text" : "RT @MarkNarusson: He's about product design but the ideas translate to anyone involved in the creative industry - Dieter Rams: Ten Principl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Readymag",
        "screen_name" : "readymag",
        "indices" : [ 142, 151 ],
        "id_str" : "566196903",
        "id" : 566196903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 152, 175 ],
        "url" : "https:\/\/t.co\/dJnJHhVdVV",
        "expanded_url" : "http:\/\/bit.ly\/2lFq5Fy",
        "display_url" : "bit.ly\/2lFq5Fy"
      } ]
    },
    "geo" : { },
    "id_str" : "948177810987896832",
    "text" : "He's about product design but the ideas translate to anyone involved in the creative industry - Dieter Rams: Ten Principles For Good Design | @readymag https:\/\/t.co\/dJnJHhVdVV",
    "id" : 948177810987896832,
    "created_at" : "2018-01-02 13:03:01 +0000",
    "user" : {
      "name" : "Mark Narusson",
      "screen_name" : "MarkNarusson",
      "protected" : false,
      "id_str" : "156627074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/942684028590870528\/1Ez8cB6T_normal.jpg",
      "id" : 156627074,
      "verified" : false
    }
  },
  "id" : 948725568652169221,
  "created_at" : "2018-01-04 01:19:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ND8jOuf01W",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/after-effects-intros\/",
      "display_url" : "webdesigndev.com\/after-effects-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948724886113013761",
  "text" : "RT @WebDesignDev: 20 Amazing After Effects Intros for Designers: https:\/\/t.co\/ND8jOuf01W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/ND8jOuf01W",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/after-effects-intros\/",
        "display_url" : "webdesigndev.com\/after-effects-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948666574407430144",
    "text" : "20 Amazing After Effects Intros for Designers: https:\/\/t.co\/ND8jOuf01W",
    "id" : 948666574407430144,
    "created_at" : "2018-01-03 21:25:11 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948724886113013761,
  "created_at" : "2018-01-04 01:16:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TimeTravelTokyo",
      "screen_name" : "TimeTravelTokyo",
      "indices" : [ 3, 19 ],
      "id_str" : "706776844134162432",
      "id" : 706776844134162432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Earth",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "moon",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ch5lYrk1F0",
      "expanded_url" : "http:\/\/flip.it\/FCtFJp",
      "display_url" : "flip.it\/FCtFJp"
    } ]
  },
  "geo" : { },
  "id_str" : "948724716893868032",
  "text" : "RT @TimeTravelTokyo: How far is the #Earth from the #moon? Take a look yourself https:\/\/t.co\/Ch5lYrk1F0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Earth",
        "indices" : [ 15, 21 ]
      }, {
        "text" : "moon",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/Ch5lYrk1F0",
        "expanded_url" : "http:\/\/flip.it\/FCtFJp",
        "display_url" : "flip.it\/FCtFJp"
      } ]
    },
    "geo" : { },
    "id_str" : "948702183784099841",
    "text" : "How far is the #Earth from the #moon? Take a look yourself https:\/\/t.co\/Ch5lYrk1F0",
    "id" : 948702183784099841,
    "created_at" : "2018-01-03 23:46:41 +0000",
    "user" : {
      "name" : "TimeTravelTokyo",
      "screen_name" : "TimeTravelTokyo",
      "protected" : false,
      "id_str" : "706776844134162432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706785082116276224\/npA6QqJz_normal.jpg",
      "id" : 706776844134162432,
      "verified" : false
    }
  },
  "id" : 948724716893868032,
  "created_at" : "2018-01-04 01:16:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "indices" : [ 3, 16 ],
      "id_str" : "23150269",
      "id" : 23150269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948724575767941121",
  "text" : "RT @beardonabike: Most Christians would benefit from changing their vocabulary from \u201CGod\u2019s in control\u201D to \u201CGod is with me\u201D.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948717975951020032",
    "text" : "Most Christians would benefit from changing their vocabulary from \u201CGod\u2019s in control\u201D to \u201CGod is with me\u201D.",
    "id" : 948717975951020032,
    "created_at" : "2018-01-04 00:49:26 +0000",
    "user" : {
      "name" : "Shane Blackshear",
      "screen_name" : "beardonabike",
      "protected" : false,
      "id_str" : "23150269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817981907577278464\/wFZP9t8S_normal.jpg",
      "id" : 23150269,
      "verified" : false
    }
  },
  "id" : 948724575767941121,
  "created_at" : "2018-01-04 01:15:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Lori Greiner",
      "screen_name" : "LoriGreiner",
      "indices" : [ 108, 120 ],
      "id_str" : "31869934",
      "id" : 31869934
    }, {
      "name" : "Kevin O'Leary",
      "screen_name" : "kevinolearytv",
      "indices" : [ 121, 135 ],
      "id_str" : "32002507",
      "id" : 32002507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948724555073368064",
  "text" : "RT @TheSharkDaymond: #SharkTank fans you're going to enjoy this. Season 9 bloopers are here. Fun times with @LoriGreiner @kevinolearytv @Ba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori Greiner",
        "screen_name" : "LoriGreiner",
        "indices" : [ 87, 99 ],
        "id_str" : "31869934",
        "id" : 31869934
      }, {
        "name" : "Kevin O'Leary",
        "screen_name" : "kevinolearytv",
        "indices" : [ 100, 114 ],
        "id_str" : "32002507",
        "id" : 32002507
      }, {
        "name" : "Barbara Corcoran",
        "screen_name" : "BarbaraCorcoran",
        "indices" : [ 115, 131 ],
        "id_str" : "36728196",
        "id" : 36728196
      }, {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 132, 139 ],
        "id_str" : "16228398",
        "id" : 16228398
      }, {
        "name" : "Robert Herjavec",
        "screen_name" : "robertherjavec",
        "indices" : [ 144, 159 ],
        "id_str" : "39275966",
        "id" : 39275966
      }, {
        "name" : "Parade Magazine",
        "screen_name" : "ParadeMagazine",
        "indices" : [ 188, 203 ],
        "id_str" : "18682378",
        "id" : 18682378
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 160, 183 ],
        "url" : "https:\/\/t.co\/KHnxTuyxzU",
        "expanded_url" : "https:\/\/parade.com\/633505\/jerylbrunner\/parade-exclusive-video-bloopers-from-shark-tank-season-nine\/",
        "display_url" : "parade.com\/633505\/jerylbr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948653285703024640",
    "text" : "#SharkTank fans you're going to enjoy this. Season 9 bloopers are here. Fun times with @LoriGreiner @kevinolearytv @BarbaraCorcoran @mcuban and @robertherjavec https:\/\/t.co\/KHnxTuyxzU via @ParadeMagazine",
    "id" : 948653285703024640,
    "created_at" : "2018-01-03 20:32:23 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932689703391940615\/zAkwGMNj_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 948724555073368064,
  "created_at" : "2018-01-04 01:15:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marques Brownlee",
      "screen_name" : "MKBHD",
      "indices" : [ 3, 9 ],
      "id_str" : "29873662",
      "id" : 29873662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948724432176115712",
  "text" : "RT @MKBHD: Actual New Year's Resolution: More collaboration. So many talented YouTubers, creators, artists, musicians, etc that I'd love to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.samruston.co.uk\" rel=\"nofollow\"\u003EFlamingo for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948654996861661184",
    "text" : "Actual New Year's Resolution: More collaboration. So many talented YouTubers, creators, artists, musicians, etc that I'd love to work with to make dope stuff.",
    "id" : 948654996861661184,
    "created_at" : "2018-01-03 20:39:11 +0000",
    "user" : {
      "name" : "Marques Brownlee",
      "screen_name" : "MKBHD",
      "protected" : false,
      "id_str" : "29873662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946798631151112194\/0e0OgvFz_normal.jpg",
      "id" : 29873662,
      "verified" : true
    }
  },
  "id" : 948724432176115712,
  "created_at" : "2018-01-04 01:15:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarkik3D Ltd",
      "screen_name" : "Anarkik3D",
      "indices" : [ 3, 13 ],
      "id_str" : "56694984",
      "id" : 56694984
    }, {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 15, 20 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948724153837932544",
  "text" : "RT @Anarkik3D: @make Anarkik3D's CEO: extraordinary designer maker and doer - from jeweller to founder of haptic software development compa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Make:",
        "screen_name" : "make",
        "indices" : [ 0, 5 ],
        "id_str" : "1118451",
        "id" : 1118451
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948709965241376769",
    "geo" : { },
    "id_str" : "948713424783118336",
    "in_reply_to_user_id" : 1118451,
    "text" : "@make Anarkik3D's CEO: extraordinary designer maker and doer - from jeweller to founder of haptic software development company, main product: 3D haptic modelling package for designer-makers, giving those who struggle with CAD access to 3D printing technologies.",
    "id" : 948713424783118336,
    "in_reply_to_status_id" : 948709965241376769,
    "created_at" : "2018-01-04 00:31:21 +0000",
    "in_reply_to_screen_name" : "make",
    "in_reply_to_user_id_str" : "1118451",
    "user" : {
      "name" : "Anarkik3D Ltd",
      "screen_name" : "Anarkik3D",
      "protected" : false,
      "id_str" : "56694984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948708750445174784\/q1_pf0lG_normal.jpg",
      "id" : 56694984,
      "verified" : false
    }
  },
  "id" : 948724153837932544,
  "created_at" : "2018-01-04 01:13:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948724146258825223",
  "text" : "RT @make: Hep here - Thank you to everyone who has pitched or suggested someone to us. I am contacting people for this issue, as well as ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "diversemakers",
        "indices" : [ 261, 275 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948709965241376769",
    "text" : "Hep here - Thank you to everyone who has pitched or suggested someone to us. I am contacting people for this issue, as well as making a list for future issues, so if you don't hear back, don't worry, &amp; please keep the suggestions coming! hep@makermedia.com #diversemakers",
    "id" : 948709965241376769,
    "created_at" : "2018-01-04 00:17:36 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 948724146258825223,
  "created_at" : "2018-01-04 01:13:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "Samsung USA",
      "screen_name" : "SamsungUS",
      "indices" : [ 20, 30 ],
      "id_str" : "34356968",
      "id" : 34356968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/oO2GeyncOZ",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/samsung-cj791-qled-curved-monitor,36217.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/samsung-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948723982345392129",
  "text" : "RT @tomshardware: \u25B8 @SamsungUS Unveils Thunderbolt 3 QLED Curved Monitor https:\/\/t.co\/oO2GeyncOZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samsung USA",
        "screen_name" : "SamsungUS",
        "indices" : [ 2, 12 ],
        "id_str" : "34356968",
        "id" : 34356968
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/oO2GeyncOZ",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/samsung-cj791-qled-curved-monitor,36217.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/samsung-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948698877355474944",
    "text" : "\u25B8 @SamsungUS Unveils Thunderbolt 3 QLED Curved Monitor https:\/\/t.co\/oO2GeyncOZ",
    "id" : 948698877355474944,
    "created_at" : "2018-01-03 23:33:32 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948723982345392129,
  "created_at" : "2018-01-04 01:13:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948723972564226048",
  "text" : "RT @lorenridinger: \"In the waves of change we find our true direction.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948705728612663296",
    "text" : "\"In the waves of change we find our true direction.\"",
    "id" : 948705728612663296,
    "created_at" : "2018-01-04 00:00:46 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948723972564226048,
  "created_at" : "2018-01-04 01:13:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948723888242020352",
  "text" : "I actually had fun learning operations management today",
  "id" : 948723888242020352,
  "created_at" : "2018-01-04 01:12:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cierra",
      "screen_name" : "sustainablecgal",
      "indices" : [ 3, 19 ],
      "id_str" : "42500504",
      "id" : 42500504
    }, {
      "name" : "Array Digital",
      "screen_name" : "ThisIsArray",
      "indices" : [ 68, 80 ],
      "id_str" : "29975960",
      "id" : 29975960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ygdVgn5Vnd",
      "expanded_url" : "https:\/\/buff.ly\/2pH8a6E",
      "display_url" : "buff.ly\/2pH8a6E"
    } ]
  },
  "geo" : { },
  "id_str" : "948694894461292544",
  "text" : "RT @sustainablecgal: How long does it take to create a website? Via @thisisarray https:\/\/t.co\/ygdVgn5Vnd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Array Digital",
        "screen_name" : "ThisIsArray",
        "indices" : [ 47, 59 ],
        "id_str" : "29975960",
        "id" : 29975960
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/ygdVgn5Vnd",
        "expanded_url" : "https:\/\/buff.ly\/2pH8a6E",
        "display_url" : "buff.ly\/2pH8a6E"
      } ]
    },
    "geo" : { },
    "id_str" : "946102889075892224",
    "text" : "How long does it take to create a website? Via @thisisarray https:\/\/t.co\/ygdVgn5Vnd",
    "id" : 946102889075892224,
    "created_at" : "2017-12-27 19:38:01 +0000",
    "user" : {
      "name" : "Cierra",
      "screen_name" : "sustainablecgal",
      "protected" : false,
      "id_str" : "42500504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948627051619274752\/6JllNudm_normal.jpg",
      "id" : 42500504,
      "verified" : false
    }
  },
  "id" : 948694894461292544,
  "created_at" : "2018-01-03 23:17:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EnviroDrone",
      "screen_name" : "envirodrone",
      "indices" : [ 3, 15 ],
      "id_str" : "3315522284",
      "id" : 3315522284
    }, {
      "name" : "Tsubasa (faa)",
      "screen_name" : "faa",
      "indices" : [ 21, 25 ],
      "id_str" : "5822512",
      "id" : 5822512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "SFCO",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948694732758224896",
  "text" : "RT @envirodrone: The @FAA reported in a new study that #drones can cause more damage to an aircraft than a common bird strike. #SFCO #Inter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tsubasa (faa)",
        "screen_name" : "faa",
        "indices" : [ 4, 8 ],
        "id_str" : "5822512",
        "id" : 5822512
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 38, 45 ]
      }, {
        "text" : "SFCO",
        "indices" : [ 110, 115 ]
      }, {
        "text" : "InternationalCivilAviationDay",
        "indices" : [ 116, 146 ]
      }, {
        "text" : "CivilAviationDay",
        "indices" : [ 147, 164 ]
      }, {
        "text" : "CivilAviation",
        "indices" : [ 165, 179 ]
      }, {
        "text" : "ICAD",
        "indices" : [ 181, 186 ]
      }, {
        "text" : "UNDaysInternational",
        "indices" : [ 187, 207 ]
      } ],
      "urls" : [ {
        "indices" : [ 208, 231 ],
        "url" : "https:\/\/t.co\/0PqdarNM1z",
        "expanded_url" : "http:\/\/bit.ly\/2B9q0Eh",
        "display_url" : "bit.ly\/2B9q0Eh"
      } ]
    },
    "geo" : { },
    "id_str" : "938853819290718208",
    "text" : "The @FAA reported in a new study that #drones can cause more damage to an aircraft than a common bird strike. #SFCO #InternationalCivilAviationDay #CivilAviationDay #CivilAviation  #ICAD #UNDaysInternational https:\/\/t.co\/0PqdarNM1z",
    "id" : 938853819290718208,
    "created_at" : "2017-12-07 19:32:48 +0000",
    "user" : {
      "name" : "EnviroDrone",
      "screen_name" : "envirodrone",
      "protected" : false,
      "id_str" : "3315522284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938196328240287744\/9ZvPjNew_normal.jpg",
      "id" : 3315522284,
      "verified" : false
    }
  },
  "id" : 948694732758224896,
  "created_at" : "2018-01-03 23:17:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgia Power ET",
      "screen_name" : "georgiapowerET",
      "indices" : [ 3, 18 ],
      "id_str" : "2833196322",
      "id" : 2833196322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Atlanta",
      "indices" : [ 20, 28 ]
    }, {
      "text" : "ElectricVehicles",
      "indices" : [ 75, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948694620929699841",
  "text" : "RT @georgiapowerET: #Atlanta is one of the country's top cities to embrace #ElectricVehicles! Can you guess who else is on the list? Full @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TESLARATI",
        "screen_name" : "Teslarati",
        "indices" : [ 118, 128 ],
        "id_str" : "1308211178",
        "id" : 1308211178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Atlanta",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "ElectricVehicles",
        "indices" : [ 55, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/5RjfiyGQYH",
        "expanded_url" : "http:\/\/ht.ly\/jCn630hlPyA",
        "display_url" : "ht.ly\/jCn630hlPyA"
      } ]
    },
    "geo" : { },
    "id_str" : "946788249082658816",
    "text" : "#Atlanta is one of the country's top cities to embrace #ElectricVehicles! Can you guess who else is on the list? Full @Teslarati article here: https:\/\/t.co\/5RjfiyGQYH",
    "id" : 946788249082658816,
    "created_at" : "2017-12-29 17:01:23 +0000",
    "user" : {
      "name" : "Georgia Power ET",
      "screen_name" : "georgiapowerET",
      "protected" : false,
      "id_str" : "2833196322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786282298148806656\/uWrtrCsh_normal.jpg",
      "id" : 2833196322,
      "verified" : false
    }
  },
  "id" : 948694620929699841,
  "created_at" : "2018-01-03 23:16:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesla",
      "screen_name" : "Tesla",
      "indices" : [ 3, 9 ],
      "id_str" : "13298072",
      "id" : 13298072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/E2tgdxmjpU",
      "expanded_url" : "https:\/\/www.tesla.com\/careers\/gigafactory",
      "display_url" : "tesla.com\/careers\/gigafa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948694390880587778",
  "text" : "RT @Tesla: Join our Gigafactory team https:\/\/t.co\/E2tgdxmjpU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/E2tgdxmjpU",
        "expanded_url" : "https:\/\/www.tesla.com\/careers\/gigafactory",
        "display_url" : "tesla.com\/careers\/gigafa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948381391686742016",
    "text" : "Join our Gigafactory team https:\/\/t.co\/E2tgdxmjpU",
    "id" : 948381391686742016,
    "created_at" : "2018-01-03 02:31:58 +0000",
    "user" : {
      "name" : "Tesla",
      "screen_name" : "Tesla",
      "protected" : false,
      "id_str" : "13298072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489192650474414080\/4RxZxsud_normal.png",
      "id" : 13298072,
      "verified" : true
    }
  },
  "id" : 948694390880587778,
  "created_at" : "2018-01-03 23:15:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DXRacer",
      "screen_name" : "DXRacer",
      "indices" : [ 3, 11 ],
      "id_str" : "1955411096",
      "id" : 1955411096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948693450651832322",
  "text" : "RT @DXRacer: If you recline back in your DXRacer chair on December 31st at 11:58:00pm and stay there for at least three minutes, you will f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947625929165205504",
    "text" : "If you recline back in your DXRacer chair on December 31st at 11:58:00pm and stay there for at least three minutes, you will feel maximum ergonomic comfort at exactly midnight. \n\nEnter 2018 the right way.",
    "id" : 947625929165205504,
    "created_at" : "2018-01-01 00:30:02 +0000",
    "user" : {
      "name" : "DXRacer",
      "screen_name" : "DXRacer",
      "protected" : false,
      "id_str" : "1955411096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925705239071686656\/r3zATfr9_normal.jpg",
      "id" : 1955411096,
      "verified" : true
    }
  },
  "id" : 948693450651832322,
  "created_at" : "2018-01-03 23:11:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 3, 11 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948693073638383617",
  "text" : "RT @adwords: Hi everyone, we're currently making changes to our social support so that we can better assist you. During this time, please e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948692925487206401",
    "text" : "Hi everyone, we're currently making changes to our social support so that we can better assist you. During this time, please expect delays; however, we\u2019ll answer your questions as soon as possible.",
    "id" : 948692925487206401,
    "created_at" : "2018-01-03 23:09:53 +0000",
    "user" : {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "protected" : false,
      "id_str" : "91220126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618952064576585733\/0XNolOAa_normal.png",
      "id" : 91220126,
      "verified" : true
    }
  },
  "id" : 948693073638383617,
  "created_at" : "2018-01-03 23:10:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaspberryPi",
      "indices" : [ 67, 79 ]
    }, {
      "text" : "AndroidThings",
      "indices" : [ 84, 98 ]
    }, {
      "text" : "Android",
      "indices" : [ 124, 132 ]
    }, {
      "text" : "IoT",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/TdhLUoVuPG",
      "expanded_url" : "http:\/\/bit.ly\/2lpkiUb",
      "display_url" : "bit.ly\/2lpkiUb"
    } ]
  },
  "geo" : { },
  "id_str" : "948692559781597186",
  "text" : "RT @sparkfun: Build an internet-controlled MIDI controller using a #RaspberryPi and #AndroidThings. https:\/\/t.co\/TdhLUoVuPG #Android #IoT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaspberryPi",
        "indices" : [ 53, 65 ]
      }, {
        "text" : "AndroidThings",
        "indices" : [ 70, 84 ]
      }, {
        "text" : "Android",
        "indices" : [ 110, 118 ]
      }, {
        "text" : "IoT",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/TdhLUoVuPG",
        "expanded_url" : "http:\/\/bit.ly\/2lpkiUb",
        "display_url" : "bit.ly\/2lpkiUb"
      } ]
    },
    "geo" : { },
    "id_str" : "948253927367114752",
    "text" : "Build an internet-controlled MIDI controller using a #RaspberryPi and #AndroidThings. https:\/\/t.co\/TdhLUoVuPG #Android #IoT",
    "id" : 948253927367114752,
    "created_at" : "2018-01-02 18:05:28 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 948692559781597186,
  "created_at" : "2018-01-03 23:08:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arduino",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "Bluetooth",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "DIY",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/JVbv5X19Fk",
      "expanded_url" : "http:\/\/bit.ly\/2Cioygp",
      "display_url" : "bit.ly\/2Cioygp"
    } ]
  },
  "geo" : { },
  "id_str" : "948692537375645696",
  "text" : "RT @sparkfun: What's more fun than an RC car? An #Arduino #Bluetooth-controlled RC car. #DIY https:\/\/t.co\/JVbv5X19Fk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Arduino",
        "indices" : [ 35, 43 ]
      }, {
        "text" : "Bluetooth",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "DIY",
        "indices" : [ 74, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/JVbv5X19Fk",
        "expanded_url" : "http:\/\/bit.ly\/2Cioygp",
        "display_url" : "bit.ly\/2Cioygp"
      } ]
    },
    "geo" : { },
    "id_str" : "948662026884218881",
    "text" : "What's more fun than an RC car? An #Arduino #Bluetooth-controlled RC car. #DIY https:\/\/t.co\/JVbv5X19Fk",
    "id" : 948662026884218881,
    "created_at" : "2018-01-03 21:07:07 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 948692537375645696,
  "created_at" : "2018-01-03 23:08:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/qdRBmQZ4q2",
      "expanded_url" : "https:\/\/fstoppers.com\/originals\/how-stay-fresh-photographer-new-year-208563?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/originals\/how-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948692458380124160",
  "text" : "RT @JayHoque: How to Stay Fresh as a Photographer in the New Year: https:\/\/t.co\/qdRBmQZ4q2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/qdRBmQZ4q2",
        "expanded_url" : "https:\/\/fstoppers.com\/originals\/how-stay-fresh-photographer-new-year-208563?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/originals\/how-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948569988490780672",
    "text" : "How to Stay Fresh as a Photographer in the New Year: https:\/\/t.co\/qdRBmQZ4q2",
    "id" : 948569988490780672,
    "created_at" : "2018-01-03 15:01:23 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948692458380124160,
  "created_at" : "2018-01-03 23:08:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/HIAVD8y03u",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-wordpress-plugins-for-portfolios\/",
      "display_url" : "webdesigndev.com\/free-wordpress\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948692241945628672",
  "text" : "RT @WebDesignDev: 20 Best Free WordPress Plugins for Portfolios: https:\/\/t.co\/HIAVD8y03u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/HIAVD8y03u",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-wordpress-plugins-for-portfolios\/",
        "display_url" : "webdesigndev.com\/free-wordpress\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948679831138590721",
    "text" : "20 Best Free WordPress Plugins for Portfolios: https:\/\/t.co\/HIAVD8y03u",
    "id" : 948679831138590721,
    "created_at" : "2018-01-03 22:17:52 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948692241945628672,
  "created_at" : "2018-01-03 23:07:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948692155660406784",
  "text" : "What interests me is even if you lose stuff, I am still the one getting interviewed or the featured innovator sometimes. Never give up",
  "id" : 948692155660406784,
  "created_at" : "2018-01-03 23:06:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948692012475338753\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/m8hVQBB8Dm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSpuWfuXcAIwSp_.jpg",
      "id_str" : "948692004267061250",
      "id" : 948692004267061250,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSpuWfuXcAIwSp_.jpg",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 857
      } ],
      "display_url" : "pic.twitter.com\/m8hVQBB8Dm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948692012475338753",
  "text" : "I was bored before lectures, so .... https:\/\/t.co\/m8hVQBB8Dm",
  "id" : 948692012475338753,
  "created_at" : "2018-01-03 23:06:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948678204646150144\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/W4HadVs1bG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSphcb8VMAAV2u_.jpg",
      "id_str" : "948677812679946240",
      "id" : 948677812679946240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSphcb8VMAAV2u_.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/W4HadVs1bG"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948678204646150144\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/W4HadVs1bG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSphtybU0AAVjNY.jpg",
      "id_str" : "948678110773301248",
      "id" : 948678110773301248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSphtybU0AAVjNY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 1288
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 1288
      } ],
      "display_url" : "pic.twitter.com\/W4HadVs1bG"
    } ],
    "hashtags" : [ {
      "text" : "CrowdCoin",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "Wecrypto",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "cryptocurrency",
      "indices" : [ 46, 61 ]
    }, {
      "text" : "startups",
      "indices" : [ 62, 71 ]
    }, {
      "text" : "nodes",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948678204646150144",
  "text" : "Alexa is still going up! #CrowdCoin #Wecrypto #cryptocurrency #startups #nodes https:\/\/t.co\/W4HadVs1bG",
  "id" : 948678204646150144,
  "created_at" : "2018-01-03 22:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Td6VNjxf9k",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-html-css-goodies\/",
      "display_url" : "webdesigndev.com\/free-html-css-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948653664247386112",
  "text" : "RT @WebDesignDev: 20 Awesome Free HTML CSS Goodies for Designers: https:\/\/t.co\/Td6VNjxf9k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/Td6VNjxf9k",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-html-css-goodies\/",
        "display_url" : "webdesigndev.com\/free-html-css-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948653561046585345",
    "text" : "20 Awesome Free HTML CSS Goodies for Designers: https:\/\/t.co\/Td6VNjxf9k",
    "id" : 948653561046585345,
    "created_at" : "2018-01-03 20:33:28 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948653664247386112,
  "created_at" : "2018-01-03 20:33:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lizzy",
      "screen_name" : "fucxkenlizzy",
      "indices" : [ 3, 16 ],
      "id_str" : "127404941",
      "id" : 127404941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948653607376867328",
  "text" : "RT @fucxkenlizzy: Some stupid shit always has to happen to my car when I\u2019m out here \uD83D\uDE44",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948652331951951872",
    "text" : "Some stupid shit always has to happen to my car when I\u2019m out here \uD83D\uDE44",
    "id" : 948652331951951872,
    "created_at" : "2018-01-03 20:28:35 +0000",
    "user" : {
      "name" : "lizzy",
      "screen_name" : "fucxkenlizzy",
      "protected" : false,
      "id_str" : "127404941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915298935417192448\/40AQmTzh_normal.jpg",
      "id" : 127404941,
      "verified" : false
    }
  },
  "id" : 948653607376867328,
  "created_at" : "2018-01-03 20:33:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948653335204253696",
  "text" : "RT @PhotographyTalk: Short list of easy, yet highly impactful ways to breathe new life into your business in the new year.\n\nhttps:\/\/t.co\/9I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/9IplW9DLVJ",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/236-photography-business-tips\/8106-three-ways-to-build-a-more-successful-photography-business-in-the-new-year",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948559094243356672",
    "text" : "Short list of easy, yet highly impactful ways to breathe new life into your business in the new year.\n\nhttps:\/\/t.co\/9IplW9DLVJ",
    "id" : 948559094243356672,
    "created_at" : "2018-01-03 14:18:06 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948653335204253696,
  "created_at" : "2018-01-03 20:32:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/vt4dAUIezk",
      "expanded_url" : "http:\/\/depot.ly\/yEGy30hpIgc",
      "display_url" : "depot.ly\/yEGy30hpIgc"
    } ]
  },
  "geo" : { },
  "id_str" : "948653148750704641",
  "text" : "RT @DesignerDepot: 6 Ways Illustration Improves #UX https:\/\/t.co\/vt4dAUIezk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 29, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/vt4dAUIezk",
        "expanded_url" : "http:\/\/depot.ly\/yEGy30hpIgc",
        "display_url" : "depot.ly\/yEGy30hpIgc"
      } ]
    },
    "geo" : { },
    "id_str" : "944891673850589190",
    "text" : "6 Ways Illustration Improves #UX https:\/\/t.co\/vt4dAUIezk",
    "id" : 944891673850589190,
    "created_at" : "2017-12-24 11:25:04 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938857270888112128\/fueDq6et_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 948653148750704641,
  "created_at" : "2018-01-03 20:31:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Free",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/ea58xQcRQc",
      "expanded_url" : "http:\/\/depot.ly\/K5tM30hpImc",
      "display_url" : "depot.ly\/K5tM30hpImc"
    } ]
  },
  "geo" : { },
  "id_str" : "948653119407304704",
  "text" : "RT @DesignerDepot: 3 Best #Free CMS For Your Website https:\/\/t.co\/ea58xQcRQc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Free",
        "indices" : [ 7, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/ea58xQcRQc",
        "expanded_url" : "http:\/\/depot.ly\/K5tM30hpImc",
        "display_url" : "depot.ly\/K5tM30hpImc"
      } ]
    },
    "geo" : { },
    "id_str" : "945060283663503362",
    "text" : "3 Best #Free CMS For Your Website https:\/\/t.co\/ea58xQcRQc",
    "id" : 945060283663503362,
    "created_at" : "2017-12-24 22:35:04 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938857270888112128\/fueDq6et_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 948653119407304704,
  "created_at" : "2018-01-03 20:31:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 105, 110 ],
      "id_str" : "19709040",
      "id" : 19709040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PierreOmidyar",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948652431667269632",
  "text" : "RT @TheSharkDaymond: \"Whatever future you're building, don't try to program everything.\"  #PierreOmidyar @Ebay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "eBay",
        "screen_name" : "eBay",
        "indices" : [ 84, 89 ],
        "id_str" : "19709040",
        "id" : 19709040
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PierreOmidyar",
        "indices" : [ 69, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948613686842798080",
    "text" : "\"Whatever future you're building, don't try to program everything.\"  #PierreOmidyar @Ebay",
    "id" : 948613686842798080,
    "created_at" : "2018-01-03 17:55:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932689703391940615\/zAkwGMNj_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 948652431667269632,
  "created_at" : "2018-01-03 20:28:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Johnson",
      "screen_name" : "anthonyvlrg",
      "indices" : [ 3, 15 ],
      "id_str" : "128705279",
      "id" : 128705279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/RxFIekq0gi",
      "expanded_url" : "https:\/\/thenextweb.com\/hardfork\/2018\/01\/03\/ripple-xrp-coinbase-coinsquare\/",
      "display_url" : "thenextweb.com\/hardfork\/2018\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948652220270239744",
  "text" : "RT @anthonyvlrg: https:\/\/t.co\/RxFIekq0gi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/RxFIekq0gi",
        "expanded_url" : "https:\/\/thenextweb.com\/hardfork\/2018\/01\/03\/ripple-xrp-coinbase-coinsquare\/",
        "display_url" : "thenextweb.com\/hardfork\/2018\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948651625459212289",
    "text" : "https:\/\/t.co\/RxFIekq0gi",
    "id" : 948651625459212289,
    "created_at" : "2018-01-03 20:25:47 +0000",
    "user" : {
      "name" : "Anthony Johnson",
      "screen_name" : "anthonyvlrg",
      "protected" : false,
      "id_str" : "128705279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947280418176491522\/KRb7sCYQ_normal.jpg",
      "id" : 128705279,
      "verified" : false
    }
  },
  "id" : 948652220270239744,
  "created_at" : "2018-01-03 20:28:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TradingView",
      "screen_name" : "tradingview",
      "indices" : [ 32, 44 ],
      "id_str" : "373457750",
      "id" : 373457750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948651245627150336\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/LAwbRgaWDD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSpJQnGV4AA1zzc.jpg",
      "id_str" : "948651221237227520",
      "id" : 948651221237227520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSpJQnGV4AA1zzc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1377
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 571,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1377
      } ],
      "display_url" : "pic.twitter.com\/LAwbRgaWDD"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948651245627150336\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/LAwbRgaWDD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSpJRLPU8AAD8pt.jpg",
      "id_str" : "948651230938591232",
      "id" : 948651230938591232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSpJRLPU8AAD8pt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 180
      } ],
      "display_url" : "pic.twitter.com\/LAwbRgaWDD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948651245627150336",
  "text" : "Bitshares long potential??? via @tradingview https:\/\/t.co\/LAwbRgaWDD",
  "id" : 948651245627150336,
  "created_at" : "2018-01-03 20:24:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/ExisOOeTM8",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BTSBTC\/QKjPa1L3-BTSBTC-Long-Poloniex\/",
      "display_url" : "tradingview.com\/chart\/BTSBTC\/Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948650695313387520",
  "text" : "BTSBTC Long: Poloniex - $BTSBTC chart https:\/\/t.co\/ExisOOeTM8",
  "id" : 948650695313387520,
  "created_at" : "2018-01-03 20:22:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948639350455140352",
  "text" : "RT @BarbaraCorcoran: If you can\u2019t communicate well, you\u2019re never going to make a sale. And you\u2019re never going to build a business if you ca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948601179960946689",
    "text" : "If you can\u2019t communicate well, you\u2019re never going to make a sale. And you\u2019re never going to build a business if you can\u2019t make sales.",
    "id" : 948601179960946689,
    "created_at" : "2018-01-03 17:05:20 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948639350455140352,
  "created_at" : "2018-01-03 19:37:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LEGO",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948639212017942529",
  "text" : "RT @make: You're never too old to stop playing with #LEGO sets. Anyone use this past holiday to introduce a young family member to these ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LEGO",
        "indices" : [ 42, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 143, 166 ],
        "url" : "https:\/\/t.co\/PSqB2K49PW",
        "expanded_url" : "https:\/\/makezine.com\/2018\/01\/03\/automatic-lego-star-wars-x-wing\/",
        "display_url" : "makezine.com\/2018\/01\/03\/aut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948638888112939008",
    "text" : "You're never too old to stop playing with #LEGO sets. Anyone use this past holiday to introduce a young family member to these magical blocks? https:\/\/t.co\/PSqB2K49PW",
    "id" : 948638888112939008,
    "created_at" : "2018-01-03 19:35:10 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 948639212017942529,
  "created_at" : "2018-01-03 19:36:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "indices" : [ 3, 14 ],
      "id_str" : "18009781",
      "id" : 18009781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948614332400783360",
  "text" : "RT @joshgroban: So many pro-Swedish fish followers and I\u2019m delighted anyway have a great day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948614084752265216",
    "text" : "So many pro-Swedish fish followers and I\u2019m delighted anyway have a great day",
    "id" : 948614084752265216,
    "created_at" : "2018-01-03 17:56:36 +0000",
    "user" : {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "protected" : false,
      "id_str" : "18009781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/933455754706673664\/U2FwRVze_normal.jpg",
      "id" : 18009781,
      "verified" : true
    }
  },
  "id" : 948614332400783360,
  "created_at" : "2018-01-03 17:57:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948612212477841409",
  "text" : "RT @make: We would love to see some creators take this design and give their own spin to it. Maybe Glowstone blocks and a gold pickaxe? #Mi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Minecraft",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/nFRgYNSPXT",
        "expanded_url" : "https:\/\/makezine.com\/2018\/01\/03\/minecraft-computer-desk\/",
        "display_url" : "makezine.com\/2018\/01\/03\/min\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948603717934346240",
    "text" : "We would love to see some creators take this design and give their own spin to it. Maybe Glowstone blocks and a gold pickaxe? #Minecraft https:\/\/t.co\/nFRgYNSPXT",
    "id" : 948603717934346240,
    "created_at" : "2018-01-03 17:15:25 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 948612212477841409,
  "created_at" : "2018-01-03 17:49:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/o0BfOc9E3h",
      "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/03\/7-common-portrait-lighting-mistakes-avoid\/",
      "display_url" : "petapixel.com\/2018\/01\/03\/7-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948602242730520576",
  "text" : "RT @JayHoque: 7 Common Portrait Lighting Mistakes (And How to Avoid Them): https:\/\/t.co\/o0BfOc9E3h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/o0BfOc9E3h",
        "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/03\/7-common-portrait-lighting-mistakes-avoid\/",
        "display_url" : "petapixel.com\/2018\/01\/03\/7-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948598841707810816",
    "text" : "7 Common Portrait Lighting Mistakes (And How to Avoid Them): https:\/\/t.co\/o0BfOc9E3h",
    "id" : 948598841707810816,
    "created_at" : "2018-01-03 16:56:02 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948602242730520576,
  "created_at" : "2018-01-03 17:09:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948602198342201344",
  "text" : "RT @jacksfilms: Many parodies I've made over the years were born out of anger I felt over something.\n\nToday's parody is no exception. Still\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948598335799095297",
    "text" : "Many parodies I've made over the years were born out of anger I felt over something.\n\nToday's parody is no exception. Still angry.",
    "id" : 948598335799095297,
    "created_at" : "2018-01-03 16:54:02 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947545819158401027\/f4tf_yQn_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 948602198342201344,
  "created_at" : "2018-01-03 17:09:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Jerri",
      "screen_name" : "GeraldineKestn2",
      "indices" : [ 3, 19 ],
      "id_str" : "808143254390640640",
      "id" : 808143254390640640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Eb77glUmBv",
      "expanded_url" : "http:\/\/www.foxnews.com\/us\/2018\/01\/03\/arizona-family-found-dead-in-cabin-after-significant-failure-heating-system.html",
      "display_url" : "foxnews.com\/us\/2018\/01\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948602146236305409",
  "text" : "RT @GeraldineKestn2: Arizona family found dead in cabin after 'significant failure' of heating system https:\/\/t.co\/Eb77glUmBv via the @FoxN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 113, 121 ],
        "id_str" : "1367531",
        "id" : 1367531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Eb77glUmBv",
        "expanded_url" : "http:\/\/www.foxnews.com\/us\/2018\/01\/03\/arizona-family-found-dead-in-cabin-after-significant-failure-heating-system.html",
        "display_url" : "foxnews.com\/us\/2018\/01\/03\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948590771321503745",
    "text" : "Arizona family found dead in cabin after 'significant failure' of heating system https:\/\/t.co\/Eb77glUmBv via the @FoxNews Android app",
    "id" : 948590771321503745,
    "created_at" : "2018-01-03 16:23:58 +0000",
    "user" : {
      "name" : "Just Jerri",
      "screen_name" : "GeraldineKestn2",
      "protected" : false,
      "id_str" : "808143254390640640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945549398414573568\/dyAW8_DM_normal.jpg",
      "id" : 808143254390640640,
      "verified" : false
    }
  },
  "id" : 948602146236305409,
  "created_at" : "2018-01-03 17:09:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948602032176365570",
  "text" : "Selling some UKG, will buy again when lower maybe. Short bursts and market bursts can still be profitable manually",
  "id" : 948602032176365570,
  "created_at" : "2018-01-03 17:08:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Mahy \uD83C\uDF41",
      "screen_name" : "tmahy",
      "indices" : [ 3, 9 ],
      "id_str" : "180845526",
      "id" : 180845526
    }, {
      "name" : "Buffer",
      "screen_name" : "buffer",
      "indices" : [ 60, 67 ],
      "id_str" : "197962366",
      "id" : 197962366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BufferChat",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948601571843149824",
  "text" : "RT @tmahy: Jumping on #BufferChat today.  Whose joining me? @buffer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buffer",
        "screen_name" : "buffer",
        "indices" : [ 49, 56 ],
        "id_str" : "197962366",
        "id" : 197962366
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BufferChat",
        "indices" : [ 11, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948597914590437376",
    "text" : "Jumping on #BufferChat today.  Whose joining me? @buffer",
    "id" : 948597914590437376,
    "created_at" : "2018-01-03 16:52:21 +0000",
    "user" : {
      "name" : "Ted Mahy \uD83C\uDF41",
      "screen_name" : "tmahy",
      "protected" : false,
      "id_str" : "180845526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885347029097922560\/CiBiEDw-_normal.jpg",
      "id" : 180845526,
      "verified" : false
    }
  },
  "id" : 948601571843149824,
  "created_at" : "2018-01-03 17:06:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    }, {
      "name" : "Julianna Photopoulos",
      "screen_name" : "juliannaphos",
      "indices" : [ 116, 129 ],
      "id_str" : "169095973",
      "id" : 169095973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948601433728929793",
  "text" : "RT @ChemistryWorld: Arsenic has prevented uranium from leaching into waterways at the South Terras mine in the UK \u2013 @juliannaphos\n\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julianna Photopoulos",
        "screen_name" : "juliannaphos",
        "indices" : [ 96, 109 ],
        "id_str" : "169095973",
        "id" : 169095973
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/1znXWqY5bv",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/abandoned-cornish-mine-may-hold-clues-to-uranium-clean-up-\/3008478.article",
        "display_url" : "chemistryworld.com\/news\/abandoned\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948597480282906624",
    "text" : "Arsenic has prevented uranium from leaching into waterways at the South Terras mine in the UK \u2013 @juliannaphos\n\nhttps:\/\/t.co\/1znXWqY5bv",
    "id" : 948597480282906624,
    "created_at" : "2018-01-03 16:50:38 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 948601433728929793,
  "created_at" : "2018-01-03 17:06:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948601395502112768",
  "text" : "RT @StartupDailyANZ: Property platforms Landguide and House and Land aim to better the search experience for land buyers: https:\/\/t.co\/dP11\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/dP11gvviGP",
        "expanded_url" : "http:\/\/ow.ly\/QRlW30dCDkW",
        "display_url" : "ow.ly\/QRlW30dCDkW"
      } ]
    },
    "geo" : { },
    "id_str" : "948599852166012928",
    "text" : "Property platforms Landguide and House and Land aim to better the search experience for land buyers: https:\/\/t.co\/dP11gvviGP",
    "id" : 948599852166012928,
    "created_at" : "2018-01-03 17:00:03 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948601395502112768,
  "created_at" : "2018-01-03 17:06:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 20, 26 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/GcGb6kUvKV",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/intel-bug-performance-loss-windows,36208.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/intel-bug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948601297439219712",
  "text" : "RT @tomshardware: \u25B8 @Intel CPU Bug Performance Loss Reports Are Premature https:\/\/t.co\/GcGb6kUvKV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 2, 8 ],
        "id_str" : "2803191",
        "id" : 2803191
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/GcGb6kUvKV",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/intel-bug-performance-loss-windows,36208.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/intel-bug\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948599354058711040",
    "text" : "\u25B8 @Intel CPU Bug Performance Loss Reports Are Premature https:\/\/t.co\/GcGb6kUvKV",
    "id" : 948599354058711040,
    "created_at" : "2018-01-03 16:58:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948601297439219712,
  "created_at" : "2018-01-03 17:05:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948601273602932736",
  "text" : "I love going back and forth today with some BitBay",
  "id" : 948601273602932736,
  "created_at" : "2018-01-03 17:05:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Goats",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948595700262109184",
  "text" : "RT @Snapzu_Earth: Daily Fact: #Goats and sheep are seasonal breeders.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Goats",
        "indices" : [ 12, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948584453382615040",
    "text" : "Daily Fact: #Goats and sheep are seasonal breeders.",
    "id" : 948584453382615040,
    "created_at" : "2018-01-03 15:58:52 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948595700262109184,
  "created_at" : "2018-01-03 16:43:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/d0DLEvYnuF",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-handwriting-photoshop-brushes\/",
      "display_url" : "webdesigndev.com\/free-handwriti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948595624190074881",
  "text" : "RT @WebDesignDev: 350+ Free Handwriting Photoshop Brushes: https:\/\/t.co\/d0DLEvYnuF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/d0DLEvYnuF",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-handwriting-photoshop-brushes\/",
        "display_url" : "webdesigndev.com\/free-handwriti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948588132135563264",
    "text" : "350+ Free Handwriting Photoshop Brushes: https:\/\/t.co\/d0DLEvYnuF",
    "id" : 948588132135563264,
    "created_at" : "2018-01-03 16:13:29 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948595624190074881,
  "created_at" : "2018-01-03 16:43:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Simon PhD",
      "screen_name" : "simonandi",
      "indices" : [ 3, 13 ],
      "id_str" : "38572432",
      "id" : 38572432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948595606456557568",
  "text" : "RT @simonandi: Encouraging STEM paths for girls is important to ensure their perspective has an impact on future innovations! This is just\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 172, 177 ]
      } ],
      "urls" : [ {
        "indices" : [ 147, 170 ],
        "url" : "https:\/\/t.co\/w4LZPFrYUQ",
        "expanded_url" : "http:\/\/bit.ly\/2E0rJZO",
        "display_url" : "bit.ly\/2E0rJZO"
      } ]
    },
    "geo" : { },
    "id_str" : "948588272938307584",
    "text" : "Encouraging STEM paths for girls is important to ensure their perspective has an impact on future innovations! This is just one way to do that. \n\n https:\/\/t.co\/w4LZPFrYUQ\n\n#STEM",
    "id" : 948588272938307584,
    "created_at" : "2018-01-03 16:14:02 +0000",
    "user" : {
      "name" : "Andrea Simon PhD",
      "screen_name" : "simonandi",
      "protected" : false,
      "id_str" : "38572432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872102229527998465\/k5-qb_PL_normal.jpg",
      "id" : 38572432,
      "verified" : false
    }
  },
  "id" : 948595606456557568,
  "created_at" : "2018-01-03 16:43:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948595448373276672",
  "text" : "Couldn't go to the storage unit today. Much work and nasty weather. Wanted to but too cold and inconvenient in timing today. Will see what I can do.",
  "id" : 948595448373276672,
  "created_at" : "2018-01-03 16:42:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Sarah Perez",
      "screen_name" : "sarahintampa",
      "indices" : [ 88, 101 ],
      "id_str" : "683113",
      "id" : 683113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/QChWCt2wS5",
      "expanded_url" : "http:\/\/tcrn.ch\/2lOX9vM",
      "display_url" : "tcrn.ch\/2lOX9vM"
    } ]
  },
  "geo" : { },
  "id_str" : "948578575858495489",
  "text" : "RT @TechCrunch: E-commerce traffic spiked on New Year's, too https:\/\/t.co\/QChWCt2wS5 by @sarahintampa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Perez",
        "screen_name" : "sarahintampa",
        "indices" : [ 72, 85 ],
        "id_str" : "683113",
        "id" : 683113
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/QChWCt2wS5",
        "expanded_url" : "http:\/\/tcrn.ch\/2lOX9vM",
        "display_url" : "tcrn.ch\/2lOX9vM"
      } ]
    },
    "geo" : { },
    "id_str" : "948574095465213953",
    "text" : "E-commerce traffic spiked on New Year's, too https:\/\/t.co\/QChWCt2wS5 by @sarahintampa",
    "id" : 948574095465213953,
    "created_at" : "2018-01-03 15:17:42 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879359733936701440\/sitcq7wY_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 948578575858495489,
  "created_at" : "2018-01-03 15:35:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuySell",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948578553251221504",
  "text" : "RT @HamzeiAnalytics: BUY Programs detected at NYSE #BuySell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuySell",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948575396584243200",
    "text" : "BUY Programs detected at NYSE #BuySell",
    "id" : 948575396584243200,
    "created_at" : "2018-01-03 15:22:52 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 948578553251221504,
  "created_at" : "2018-01-03 15:35:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/1oGZ2KnILv",
      "expanded_url" : "http:\/\/ift.tt\/2AhCu7F",
      "display_url" : "ift.tt\/2AhCu7F"
    } ]
  },
  "geo" : { },
  "id_str" : "948578465762238465",
  "text" : "RT @dronepilots: Next Level: Ethernet\/IP Based Thermal Imaging Drone Payloads By TeAx | DronePilots - https:\/\/t.co\/1oGZ2KnILv #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/1oGZ2KnILv",
        "expanded_url" : "http:\/\/ift.tt\/2AhCu7F",
        "display_url" : "ift.tt\/2AhCu7F"
      } ]
    },
    "geo" : { },
    "id_str" : "948576008608894976",
    "text" : "Next Level: Ethernet\/IP Based Thermal Imaging Drone Payloads By TeAx | DronePilots - https:\/\/t.co\/1oGZ2KnILv #drones",
    "id" : 948576008608894976,
    "created_at" : "2018-01-03 15:25:18 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948578465762238465,
  "created_at" : "2018-01-03 15:35:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/pCK2sbWQIq",
      "expanded_url" : "http:\/\/engt.co\/2DZdDIk",
      "display_url" : "engt.co\/2DZdDIk"
    } ]
  },
  "geo" : { },
  "id_str" : "948578444929044482",
  "text" : "RT @engadget: eHarmony can't claim its matches are 'scientific' anymore https:\/\/t.co\/pCK2sbWQIq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/pCK2sbWQIq",
        "expanded_url" : "http:\/\/engt.co\/2DZdDIk",
        "display_url" : "engt.co\/2DZdDIk"
      } ]
    },
    "geo" : { },
    "id_str" : "948576322049191936",
    "text" : "eHarmony can't claim its matches are 'scientific' anymore https:\/\/t.co\/pCK2sbWQIq",
    "id" : 948576322049191936,
    "created_at" : "2018-01-03 15:26:33 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948578444929044482,
  "created_at" : "2018-01-03 15:34:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948578363786002432",
  "text" : "RT @copticworld: Witness recalls shock during gun attack on Coptic Church in Egypt: A man who was present during the latest church attack n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/copticworld\/status\/948576485853478913\/photo\/1",
        "indices" : [ 281, 304 ],
        "url" : "https:\/\/t.co\/MlQJTHQQV6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSoFSOuU8AAOiNo.jpg",
        "id_str" : "948576482263101440",
        "id" : 948576482263101440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSoFSOuU8AAOiNo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/MlQJTHQQV6"
      } ],
      "hashtags" : [ {
        "text" : "CopticWorld",
        "indices" : [ 260, 272 ]
      }, {
        "text" : "coptic",
        "indices" : [ 273, 280 ]
      } ],
      "urls" : [ {
        "indices" : [ 236, 259 ],
        "url" : "https:\/\/t.co\/f1Y9DiUL4l",
        "expanded_url" : "http:\/\/dlvr.it\/Q8jjJ4",
        "display_url" : "dlvr.it\/Q8jjJ4"
      } ]
    },
    "geo" : { },
    "id_str" : "948576485853478913",
    "text" : "Witness recalls shock during gun attack on Coptic Church in Egypt: A man who was present during the latest church attack near Cairo in Egypt recalled the shock he felt when he heard the sound of gunshots from a Christian-owned shop ... https:\/\/t.co\/f1Y9DiUL4l #CopticWorld #coptic https:\/\/t.co\/MlQJTHQQV6",
    "id" : 948576485853478913,
    "created_at" : "2018-01-03 15:27:12 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 948578363786002432,
  "created_at" : "2018-01-03 15:34:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/n5k1IraQcO",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/corporate-muse-website-templates\/",
      "display_url" : "webdesigndev.com\/corporate-muse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948578315195027456",
  "text" : "RT @WebDesignDev: 20 Professional Corporate Muse Website Templates: https:\/\/t.co\/n5k1IraQcO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/n5k1IraQcO",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/corporate-muse-website-templates\/",
        "display_url" : "webdesigndev.com\/corporate-muse\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948574993482383360",
    "text" : "20 Professional Corporate Muse Website Templates: https:\/\/t.co\/n5k1IraQcO",
    "id" : 948574993482383360,
    "created_at" : "2018-01-03 15:21:16 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948578315195027456,
  "created_at" : "2018-01-03 15:34:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trading",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "cryptocurrency",
      "indices" : [ 126, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948578273705058304",
  "text" : "Can't believe ADA broke the $1 record today. Also just sold Bitbay, it went down then bought it again in 5 minutes \uD83D\uDE06 #trading #cryptocurrency",
  "id" : 948578273705058304,
  "created_at" : "2018-01-03 15:34:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gaming",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/OTQ2N9Zd9E",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/game-streaming-encoding-coffee-lake-ryzen,5326.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/game-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948573401442078721",
  "text" : "RT @tomshardware: \u25B8 #Gaming And Streaming: Which CPU Is Best For Both? https:\/\/t.co\/OTQ2N9Zd9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gaming",
        "indices" : [ 2, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/OTQ2N9Zd9E",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/game-streaming-encoding-coffee-lake-ryzen,5326.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/game-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948555052653801474",
    "text" : "\u25B8 #Gaming And Streaming: Which CPU Is Best For Both? https:\/\/t.co\/OTQ2N9Zd9E",
    "id" : 948555052653801474,
    "created_at" : "2018-01-03 14:02:02 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948573401442078721,
  "created_at" : "2018-01-03 15:14:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/LpNBLy1xUY",
      "expanded_url" : "http:\/\/engt.co\/2CMLXXL",
      "display_url" : "engt.co\/2CMLXXL"
    } ]
  },
  "geo" : { },
  "id_str" : "948573023409405955",
  "text" : "RT @engadget: Watch this streamer accidentally break a 'Tetris' world record https:\/\/t.co\/LpNBLy1xUY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/LpNBLy1xUY",
        "expanded_url" : "http:\/\/engt.co\/2CMLXXL",
        "display_url" : "engt.co\/2CMLXXL"
      } ]
    },
    "geo" : { },
    "id_str" : "948571268613312512",
    "text" : "Watch this streamer accidentally break a 'Tetris' world record https:\/\/t.co\/LpNBLy1xUY",
    "id" : 948571268613312512,
    "created_at" : "2018-01-03 15:06:28 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948573023409405955,
  "created_at" : "2018-01-03 15:13:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948573008045756418",
  "text" : "RT @StartupDailyANZ: Working with the team behind L'Oreal's Makeup Genius app, Western Australian startup Speqs allows users to virtually t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 146, 169 ],
        "url" : "https:\/\/t.co\/abCdznHF5P",
        "expanded_url" : "http:\/\/ow.ly\/mB2n30hwz1B",
        "display_url" : "ow.ly\/mB2n30hwz1B"
      } ]
    },
    "geo" : { },
    "id_str" : "948569656750612481",
    "text" : "Working with the team behind L'Oreal's Makeup Genius app, Western Australian startup Speqs allows users to virtually try on glasses in real time: https:\/\/t.co\/abCdznHF5P",
    "id" : 948569656750612481,
    "created_at" : "2018-01-03 15:00:04 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948573008045756418,
  "created_at" : "2018-01-03 15:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/XITJ4uBaab",
      "expanded_url" : "http:\/\/engt.co\/2DVsC5N",
      "display_url" : "engt.co\/2DVsC5N"
    } ]
  },
  "geo" : { },
  "id_str" : "948572935425576961",
  "text" : "RT @engadget: Google brings its mysterious Fuchsia OS to the Pixelbook https:\/\/t.co\/XITJ4uBaab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/XITJ4uBaab",
        "expanded_url" : "http:\/\/engt.co\/2DVsC5N",
        "display_url" : "engt.co\/2DVsC5N"
      } ]
    },
    "geo" : { },
    "id_str" : "948492828757413888",
    "text" : "Google brings its mysterious Fuchsia OS to the Pixelbook https:\/\/t.co\/XITJ4uBaab",
    "id" : 948492828757413888,
    "created_at" : "2018-01-03 09:54:47 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948572935425576961,
  "created_at" : "2018-01-03 15:13:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Peters",
      "screen_name" : "StandardofTrust",
      "indices" : [ 3, 19 ],
      "id_str" : "15734989",
      "id" : 15734989
    }, {
      "name" : "AMD1\u2022ILLUMINATED",
      "screen_name" : "AMD1_CEO",
      "indices" : [ 49, 58 ],
      "id_str" : "80413939",
      "id" : 80413939
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 60, 72 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Jaganniwas Iyer",
      "screen_name" : "jaganniwas",
      "indices" : [ 74, 85 ],
      "id_str" : "1662033984",
      "id" : 1662033984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/t3aIuaQJIu",
      "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=004baa309cf42874982ae6a0",
      "display_url" : "sumall.com\/thankyou?utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948572845327683584",
  "text" : "RT @StandardofTrust: Our biggest fans this week: @AMD1_CEO, @gamer456148, @jaganniwas. Thank you! via https:\/\/t.co\/t3aIuaQJIu https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sumall.com\/\" rel=\"nofollow\"\u003ESumAll Authentication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMD1\u2022ILLUMINATED",
        "screen_name" : "AMD1_CEO",
        "indices" : [ 28, 37 ],
        "id_str" : "80413939",
        "id" : 80413939
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 39, 51 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Jaganniwas Iyer",
        "screen_name" : "jaganniwas",
        "indices" : [ 53, 64 ],
        "id_str" : "1662033984",
        "id" : 1662033984
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StandardofTrust\/status\/948569798174281729\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/pOpNIFvRbq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSn_M72WkAAbkHo.jpg",
        "id_str" : "948569794227376128",
        "id" : 948569794227376128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSn_M72WkAAbkHo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        } ],
        "display_url" : "pic.twitter.com\/pOpNIFvRbq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/t3aIuaQJIu",
        "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=004baa309cf42874982ae6a0",
        "display_url" : "sumall.com\/thankyou?utm_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948569798174281729",
    "text" : "Our biggest fans this week: @AMD1_CEO, @gamer456148, @jaganniwas. Thank you! via https:\/\/t.co\/t3aIuaQJIu https:\/\/t.co\/pOpNIFvRbq",
    "id" : 948569798174281729,
    "created_at" : "2018-01-03 15:00:38 +0000",
    "user" : {
      "name" : "Rob Peters",
      "screen_name" : "StandardofTrust",
      "protected" : false,
      "id_str" : "15734989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506409104865124352\/T7bUV46l_normal.jpeg",
      "id" : 15734989,
      "verified" : false
    }
  },
  "id" : 948572845327683584,
  "created_at" : "2018-01-03 15:12:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948569552002191360",
  "text" : "RT @BarbaraCorcoran: There\u2019s nothing more contagious than rubbing shoulders with someone who\u2019s dreaming + will jump over hurdles to make th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948557130394669056",
    "text" : "There\u2019s nothing more contagious than rubbing shoulders with someone who\u2019s dreaming + will jump over hurdles to make their dream come true.",
    "id" : 948557130394669056,
    "created_at" : "2018-01-03 14:10:17 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948569552002191360,
  "created_at" : "2018-01-03 14:59:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mammals",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948569496570212352",
  "text" : "RT @Snapzu_Earth: Did you know? Barn owls hunt mostly small #mammals such as the short-tailed vole.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mammals",
        "indices" : [ 42, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948554657227456513",
    "text" : "Did you know? Barn owls hunt mostly small #mammals such as the short-tailed vole.",
    "id" : 948554657227456513,
    "created_at" : "2018-01-03 14:00:28 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948569496570212352,
  "created_at" : "2018-01-03 14:59:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948569478278930432",
  "text" : "RT @elonmusk: Using a neural net to detect rain using cameras (no dedicated rain or sun sensors). Computers are very patient. \nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/YM0tQ6vLOV",
        "expanded_url" : "https:\/\/m.youtube.com\/watch?v=K7zKvHEbgS8",
        "display_url" : "m.youtube.com\/watch?v=K7zKvH\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948469610944241664",
    "text" : "Using a neural net to detect rain using cameras (no dedicated rain or sun sensors). Computers are very patient. \nhttps:\/\/t.co\/YM0tQ6vLOV",
    "id" : 948469610944241664,
    "created_at" : "2018-01-03 08:22:31 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 948569478278930432,
  "created_at" : "2018-01-03 14:59:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 43, 55 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Kent Lee Platte",
      "screen_name" : "MathBomb",
      "indices" : [ 57, 66 ],
      "id_str" : "306261708",
      "id" : 306261708
    }, {
      "name" : "Matthew Urben",
      "screen_name" : "MattUrben",
      "indices" : [ 68, 78 ],
      "id_str" : "199048161",
      "id" : 199048161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/KQSub7DMfE",
      "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=49d7a0aded1e25c4d2f3ac42",
      "display_url" : "sumall.com\/thankyou?utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948569354714730498",
  "text" : "RT @PFF_Brett: Our biggest fans this week: @gamer456148, @MathBomb, @MattUrben. Thank you! via https:\/\/t.co\/KQSub7DMfE https:\/\/t.co\/PcJ8zDn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sumall.com\/\" rel=\"nofollow\"\u003ESumAll Authentication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 28, 40 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Kent Lee Platte",
        "screen_name" : "MathBomb",
        "indices" : [ 42, 51 ],
        "id_str" : "306261708",
        "id" : 306261708
      }, {
        "name" : "Matthew Urben",
        "screen_name" : "MattUrben",
        "indices" : [ 53, 63 ],
        "id_str" : "199048161",
        "id" : 199048161
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PFF_Brett\/status\/948554569897906177\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/PcJ8zDnhsZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSnxWnGX0AEg5PS.jpg",
        "id_str" : "948554567293325313",
        "id" : 948554567293325313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSnxWnGX0AEg5PS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/PcJ8zDnhsZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/KQSub7DMfE",
        "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=49d7a0aded1e25c4d2f3ac42",
        "display_url" : "sumall.com\/thankyou?utm_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948554569897906177",
    "text" : "Our biggest fans this week: @gamer456148, @MathBomb, @MattUrben. Thank you! via https:\/\/t.co\/KQSub7DMfE https:\/\/t.co\/PcJ8zDnhsZ",
    "id" : 948554569897906177,
    "created_at" : "2018-01-03 14:00:07 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928241281834373121\/zuFGhra4_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 948569354714730498,
  "created_at" : "2018-01-03 14:58:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/eoAkdKTq78",
      "expanded_url" : "http:\/\/goo.gl\/zBS4gb",
      "display_url" : "goo.gl\/zBS4gb"
    } ]
  },
  "geo" : { },
  "id_str" : "948432484882149377",
  "text" : "RT @StartupDailyANZ: Get your dose of startup news right in your inbox with our daily newsletter: https:\/\/t.co\/eoAkdKTq78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/eoAkdKTq78",
        "expanded_url" : "http:\/\/goo.gl\/zBS4gb",
        "display_url" : "goo.gl\/zBS4gb"
      } ]
    },
    "geo" : { },
    "id_str" : "948426194462171136",
    "text" : "Get your dose of startup news right in your inbox with our daily newsletter: https:\/\/t.co\/eoAkdKTq78",
    "id" : 948426194462171136,
    "created_at" : "2018-01-03 05:30:00 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948432484882149377,
  "created_at" : "2018-01-03 05:55:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Briana",
      "screen_name" : "JustBriHonest_",
      "indices" : [ 3, 18 ],
      "id_str" : "349965740",
      "id" : 349965740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948432194162262016",
  "text" : "RT @JustBriHonest_: Up like I don\u2019t have to drive in the morning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948426852565180416",
    "text" : "Up like I don\u2019t have to drive in the morning.",
    "id" : 948426852565180416,
    "created_at" : "2018-01-03 05:32:37 +0000",
    "user" : {
      "name" : "Briana",
      "screen_name" : "JustBriHonest_",
      "protected" : false,
      "id_str" : "349965740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943674307452047360\/GNdRN2O2_normal.jpg",
      "id" : 349965740,
      "verified" : false
    }
  },
  "id" : 948432194162262016,
  "created_at" : "2018-01-03 05:53:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    }, {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 60, 69 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adafruit",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/0H2qnraK36",
      "expanded_url" : "https:\/\/learn.adafruit.com\/introducting-itsy-bitsy-32u4",
      "display_url" : "learn.adafruit.com\/introducting-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948432169248215040",
  "text" : "RT @adafruit: New Learn Guide: Introducting Itsy Bitsy 32u4 @adafruit #adafruit https:\/\/t.co\/0H2qnraK36",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/learn.adafruit.com\" rel=\"nofollow\"\u003Elearn.adafruit.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "adafruit industries",
        "screen_name" : "adafruit",
        "indices" : [ 46, 55 ],
        "id_str" : "20731304",
        "id" : 20731304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "adafruit",
        "indices" : [ 56, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/0H2qnraK36",
        "expanded_url" : "https:\/\/learn.adafruit.com\/introducting-itsy-bitsy-32u4",
        "display_url" : "learn.adafruit.com\/introducting-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948427391566794752",
    "text" : "New Learn Guide: Introducting Itsy Bitsy 32u4 @adafruit #adafruit https:\/\/t.co\/0H2qnraK36",
    "id" : 948427391566794752,
    "created_at" : "2018-01-03 05:34:45 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 948432169248215040,
  "created_at" : "2018-01-03 05:53:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948432130127867904",
  "text" : "RT @elonmusk: Come work at the biggest &amp; most advanced factory on Earth! Located by a river near the beautiful Sierra Nevada mountains with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 156, 179 ],
        "url" : "https:\/\/t.co\/Nimv3BvQXI",
        "expanded_url" : "https:\/\/twitter.com\/tesla\/status\/948381391686742016",
        "display_url" : "twitter.com\/tesla\/status\/9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948428274467618816",
    "text" : "Come work at the biggest &amp; most advanced factory on Earth! Located by a river near the beautiful Sierra Nevada mountains with wild horses roaming free. https:\/\/t.co\/Nimv3BvQXI",
    "id" : 948428274467618816,
    "created_at" : "2018-01-03 05:38:16 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 948432130127867904,
  "created_at" : "2018-01-03 05:53:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Ax5DeVDx1P",
      "expanded_url" : "http:\/\/engt.co\/2CGsIPx",
      "display_url" : "engt.co\/2CGsIPx"
    } ]
  },
  "geo" : { },
  "id_str" : "948432092832124928",
  "text" : "RT @engadget: Samsung's latest curved QLED monitor packs Thunderbolt 3 https:\/\/t.co\/Ax5DeVDx1P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/Ax5DeVDx1P",
        "expanded_url" : "http:\/\/engt.co\/2CGsIPx",
        "display_url" : "engt.co\/2CGsIPx"
      } ]
    },
    "geo" : { },
    "id_str" : "948429230215450624",
    "text" : "Samsung's latest curved QLED monitor packs Thunderbolt 3 https:\/\/t.co\/Ax5DeVDx1P",
    "id" : 948429230215450624,
    "created_at" : "2018-01-03 05:42:04 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948432092832124928,
  "created_at" : "2018-01-03 05:53:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "willwinter",
      "screen_name" : "willwinter",
      "indices" : [ 3, 14 ],
      "id_str" : "7851602",
      "id" : 7851602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Technology",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/rAwWojtRHU",
      "expanded_url" : "http:\/\/ift.tt\/2lJyRm1",
      "display_url" : "ift.tt\/2lJyRm1"
    } ]
  },
  "geo" : { },
  "id_str" : "948432002050609152",
  "text" : "RT @willwinter: Strong factory data, Wall St gains boost Asian share prices https:\/\/t.co\/rAwWojtRHU #Technology",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Technology",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/rAwWojtRHU",
        "expanded_url" : "http:\/\/ift.tt\/2lJyRm1",
        "display_url" : "ift.tt\/2lJyRm1"
      } ]
    },
    "geo" : { },
    "id_str" : "948430554772500482",
    "text" : "Strong factory data, Wall St gains boost Asian share prices https:\/\/t.co\/rAwWojtRHU #Technology",
    "id" : 948430554772500482,
    "created_at" : "2018-01-03 05:47:19 +0000",
    "user" : {
      "name" : "willwinter",
      "screen_name" : "willwinter",
      "protected" : false,
      "id_str" : "7851602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936067192524824576\/TmGg2W_N_normal.jpg",
      "id" : 7851602,
      "verified" : true
    }
  },
  "id" : 948432002050609152,
  "created_at" : "2018-01-03 05:53:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Ibrahim",
      "screen_name" : "ISpeakOrthodoxy",
      "indices" : [ 3, 19 ],
      "id_str" : "457790838",
      "id" : 457790838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948431978159919104",
  "text" : "RT @ISpeakOrthodoxy: \"Let us not be scandalised by the lack of faith around us, and by our own turmoils. The light of Christ is more powerf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lightofChrist",
        "indices" : [ 185, 199 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948428547021877248",
    "text" : "\"Let us not be scandalised by the lack of faith around us, and by our own turmoils. The light of Christ is more powerful than any doubt, than any evil or cruelty at work in the world.\" #lightofChrist",
    "id" : 948428547021877248,
    "created_at" : "2018-01-03 05:39:21 +0000",
    "user" : {
      "name" : "Michelle Ibrahim",
      "screen_name" : "ISpeakOrthodoxy",
      "protected" : false,
      "id_str" : "457790838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3614662548\/c0b968a1cb5ce645a726e09bbd62f695_normal.jpeg",
      "id" : 457790838,
      "verified" : false
    }
  },
  "id" : 948431978159919104,
  "created_at" : "2018-01-03 05:52:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/pdRfpERlP3",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-app-design-templates\/",
      "display_url" : "webdesigndev.com\/free-app-desig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948431804087881728",
  "text" : "RT @WebDesignDev: 35+ Gorgeous Free App Design Templates: https:\/\/t.co\/pdRfpERlP3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/pdRfpERlP3",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-app-design-templates\/",
        "display_url" : "webdesigndev.com\/free-app-desig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948431108101824512",
    "text" : "35+ Gorgeous Free App Design Templates: https:\/\/t.co\/pdRfpERlP3",
    "id" : 948431108101824512,
    "created_at" : "2018-01-03 05:49:31 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948431804087881728,
  "created_at" : "2018-01-03 05:52:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948431725482389504\/photo\/1",
      "indices" : [ 206, 229 ],
      "url" : "https:\/\/t.co\/RXQDeJxJmX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSmBnlXX4AEraLX.jpg",
      "id_str" : "948431713583226881",
      "id" : 948431713583226881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSmBnlXX4AEraLX.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/RXQDeJxJmX"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948431725482389504\/photo\/1",
      "indices" : [ 206, 229 ],
      "url" : "https:\/\/t.co\/RXQDeJxJmX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSmBoCmX0AA9F9g.jpg",
      "id_str" : "948431721430765568",
      "id" : 948431721430765568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSmBoCmX0AA9F9g.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/RXQDeJxJmX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948431725482389504",
  "text" : "I range from Staunch Conservative to Right Libertarian in lots of these tests. However, I just identity with a free market, moral, liberty-filled, deuntological philosophy that benefits society as a whole. https:\/\/t.co\/RXQDeJxJmX",
  "id" : 948431725482389504,
  "created_at" : "2018-01-03 05:51:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948415959714467841",
  "text" : "RT @Matthiasiam: When you turn off the internet for a quick minute, the world isn\u2019t such a terrible place. It\u2019s actually pretty awesome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948405798262136833",
    "text" : "When you turn off the internet for a quick minute, the world isn\u2019t such a terrible place. It\u2019s actually pretty awesome.",
    "id" : 948405798262136833,
    "created_at" : "2018-01-03 04:08:57 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929487527995510784\/Hzr8H3DU_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 948415959714467841,
  "created_at" : "2018-01-03 04:49:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/enocnFZLEZ",
      "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7551-5-camera-accessories-all-nikon-shooters-must-have",
      "display_url" : "photographytalk.com\/photography-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948402013041283072",
  "text" : "RT @PhotographyTalk: If you've got a Nikon camera, these five accessories are among the best you can buy.\n\nhttps:\/\/t.co\/enocnFZLEZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/enocnFZLEZ",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7551-5-camera-accessories-all-nikon-shooters-must-have",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948221887112499200",
    "text" : "If you've got a Nikon camera, these five accessories are among the best you can buy.\n\nhttps:\/\/t.co\/enocnFZLEZ",
    "id" : 948221887112499200,
    "created_at" : "2018-01-02 15:58:09 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948402013041283072,
  "created_at" : "2018-01-03 03:53:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 3, 10 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/UlYaJrSYpg",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/lizryan\/2016\/07\/02\/ten-things-a-good-manager-wont-ask-employees-to-do\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
      "display_url" : "forbes.com\/sites\/lizryan\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948401703858114560",
  "text" : "RT @Forbes: https:\/\/t.co\/UlYaJrSYpg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.forbes.com\" rel=\"nofollow\"\u003EMalorie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/UlYaJrSYpg",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/lizryan\/2016\/07\/02\/ten-things-a-good-manager-wont-ask-employees-to-do\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
        "display_url" : "forbes.com\/sites\/lizryan\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948328468839845888",
    "text" : "https:\/\/t.co\/UlYaJrSYpg",
    "id" : 948328468839845888,
    "created_at" : "2018-01-02 23:01:40 +0000",
    "user" : {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "protected" : false,
      "id_str" : "91478624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882603270484766720\/YFx4Lsh4_normal.jpg",
      "id" : 91478624,
      "verified" : true
    }
  },
  "id" : 948401703858114560,
  "created_at" : "2018-01-03 03:52:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/NpdwmOhG9t",
      "expanded_url" : "https:\/\/trib.al\/7A7feZi",
      "display_url" : "trib.al\/7A7feZi"
    } ]
  },
  "geo" : { },
  "id_str" : "948401008291581952",
  "text" : "RT @epicurious: It\u2019s tomatoes on toast, sure, but it\u2019s really much more than that.\nhttps:\/\/t.co\/NpdwmOhG9t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/NpdwmOhG9t",
        "expanded_url" : "https:\/\/trib.al\/7A7feZi",
        "display_url" : "trib.al\/7A7feZi"
      } ]
    },
    "geo" : { },
    "id_str" : "948378158121803776",
    "text" : "It\u2019s tomatoes on toast, sure, but it\u2019s really much more than that.\nhttps:\/\/t.co\/NpdwmOhG9t",
    "id" : 948378158121803776,
    "created_at" : "2018-01-03 02:19:07 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948401008291581952,
  "created_at" : "2018-01-03 03:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Physics Today",
      "screen_name" : "PhysicsToday",
      "indices" : [ 3, 16 ],
      "id_str" : "20608701",
      "id" : 20608701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/rmGmMAcs4U",
      "expanded_url" : "https:\/\/goo.gl\/fb\/v3LWUU",
      "display_url" : "goo.gl\/fb\/v3LWUU"
    } ]
  },
  "geo" : { },
  "id_str" : "948400875223048193",
  "text" : "RT @PhysicsToday: Bose\u2013Einstein condensation in the blink of an eye https:\/\/t.co\/rmGmMAcs4U #physics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "physics",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/rmGmMAcs4U",
        "expanded_url" : "https:\/\/goo.gl\/fb\/v3LWUU",
        "display_url" : "goo.gl\/fb\/v3LWUU"
      } ]
    },
    "geo" : { },
    "id_str" : "946476209768161280",
    "text" : "Bose\u2013Einstein condensation in the blink of an eye https:\/\/t.co\/rmGmMAcs4U #physics",
    "id" : 946476209768161280,
    "created_at" : "2017-12-28 20:21:27 +0000",
    "user" : {
      "name" : "Physics Today",
      "screen_name" : "PhysicsToday",
      "protected" : false,
      "id_str" : "20608701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948567046459142144\/DMpC9mcR_normal.jpg",
      "id" : 20608701,
      "verified" : true
    }
  },
  "id" : 948400875223048193,
  "created_at" : "2018-01-03 03:49:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "APS Physics",
      "screen_name" : "APSphysics",
      "indices" : [ 3, 14 ],
      "id_str" : "48463418",
      "id" : 48463418
    }, {
      "name" : "Phys Rev Materials",
      "screen_name" : "PhysRevMater",
      "indices" : [ 47, 60 ],
      "id_str" : "824994077192097796",
      "id" : 824994077192097796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apsPRMater",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/IpzFxqr5vO",
      "expanded_url" : "http:\/\/go.aps.org\/2Cckpgl",
      "display_url" : "go.aps.org\/2Cckpgl"
    } ]
  },
  "geo" : { },
  "id_str" : "948400690086449152",
  "text" : "RT @APSphysics: Latest research in materials - @PhysRevMater https:\/\/t.co\/IpzFxqr5vO #apsPRMater",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phys Rev Materials",
        "screen_name" : "PhysRevMater",
        "indices" : [ 31, 44 ],
        "id_str" : "824994077192097796",
        "id" : 824994077192097796
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apsPRMater",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/IpzFxqr5vO",
        "expanded_url" : "http:\/\/go.aps.org\/2Cckpgl",
        "display_url" : "go.aps.org\/2Cckpgl"
      } ]
    },
    "geo" : { },
    "id_str" : "946485949898387456",
    "text" : "Latest research in materials - @PhysRevMater https:\/\/t.co\/IpzFxqr5vO #apsPRMater",
    "id" : 946485949898387456,
    "created_at" : "2017-12-28 21:00:09 +0000",
    "user" : {
      "name" : "APS Physics",
      "screen_name" : "APSphysics",
      "protected" : false,
      "id_str" : "48463418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671419930269638656\/j5s9l3B9_normal.jpg",
      "id" : 48463418,
      "verified" : true
    }
  },
  "id" : 948400690086449152,
  "created_at" : "2018-01-03 03:48:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "APS Physics",
      "screen_name" : "APSphysics",
      "indices" : [ 3, 14 ],
      "id_str" : "48463418",
      "id" : 48463418
    }, {
      "name" : "Caltech",
      "screen_name" : "Caltech",
      "indices" : [ 53, 61 ],
      "id_str" : "16536844",
      "id" : 16536844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "histphys",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/5XIAauS2Wg",
      "expanded_url" : "http:\/\/go.aps.org\/VqU27U",
      "display_url" : "go.aps.org\/VqU27U"
    } ]
  },
  "geo" : { },
  "id_str" : "948400679961415680",
  "text" : "RT @APSphysics: December 29, 1959: Feynman's Classic @Caltech Lecture https:\/\/t.co\/5XIAauS2Wg #histphys",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caltech",
        "screen_name" : "Caltech",
        "indices" : [ 37, 45 ],
        "id_str" : "16536844",
        "id" : 16536844
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "histphys",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/5XIAauS2Wg",
        "expanded_url" : "http:\/\/go.aps.org\/VqU27U",
        "display_url" : "go.aps.org\/VqU27U"
      } ]
    },
    "geo" : { },
    "id_str" : "946757800918528000",
    "text" : "December 29, 1959: Feynman's Classic @Caltech Lecture https:\/\/t.co\/5XIAauS2Wg #histphys",
    "id" : 946757800918528000,
    "created_at" : "2017-12-29 15:00:24 +0000",
    "user" : {
      "name" : "APS Physics",
      "screen_name" : "APSphysics",
      "protected" : false,
      "id_str" : "48463418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671419930269638656\/j5s9l3B9_normal.jpg",
      "id" : 48463418,
      "verified" : true
    }
  },
  "id" : 948400679961415680,
  "created_at" : "2018-01-03 03:48:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0MFmvtIg5o",
      "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/teva-to-cut-14000-jobs\/3008472.article",
      "display_url" : "chemistryworld.com\/news\/teva-to-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948400576781570049",
  "text" : "RT @ChemistryWorld: Drug manufacturer Teva will lay off more than a quarter of its workforce over the next two years https:\/\/t.co\/0MFmvtIg5o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/0MFmvtIg5o",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/teva-to-cut-14000-jobs\/3008472.article",
        "display_url" : "chemistryworld.com\/news\/teva-to-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "944200602669772801",
    "text" : "Drug manufacturer Teva will lay off more than a quarter of its workforce over the next two years https:\/\/t.co\/0MFmvtIg5o",
    "id" : 944200602669772801,
    "created_at" : "2017-12-22 13:39:00 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 948400576781570049,
  "created_at" : "2018-01-03 03:48:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storj",
      "screen_name" : "storjproject",
      "indices" : [ 3, 16 ],
      "id_str" : "345738416",
      "id" : 345738416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400357805297664",
  "text" : "RT @storjproject: Building apps on a foundation that is private and secure by default is critical in the modern era. Read the latest articl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shawn Wilkinson",
        "screen_name" : "super3",
        "indices" : [ 126, 133 ],
        "id_str" : "18812868",
        "id" : 18812868
      }, {
        "name" : "Huffington.",
        "screen_name" : "Huffington",
        "indices" : [ 137, 148 ],
        "id_str" : "537443899",
        "id" : 537443899
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 205, 228 ],
        "url" : "https:\/\/t.co\/1qoct4sMXa",
        "expanded_url" : "https:\/\/www.huffingtonpost.com\/entry\/the-privacy-evolution-building-apps-on-a-foundation_us_5a43ee55e4b06cd2bd03ddb8",
        "display_url" : "huffingtonpost.com\/entry\/the-priv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948343969716449280",
    "text" : "Building apps on a foundation that is private and secure by default is critical in the modern era. Read the latest article by @super3 on @Huffington where he covers the evolution of privacy in the cloud.  https:\/\/t.co\/1qoct4sMXa",
    "id" : 948343969716449280,
    "created_at" : "2018-01-03 00:03:16 +0000",
    "user" : {
      "name" : "Storj",
      "screen_name" : "storjproject",
      "protected" : false,
      "id_str" : "345738416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835199495013019648\/cNeEcEDW_normal.jpg",
      "id" : 345738416,
      "verified" : false
    }
  },
  "id" : 948400357805297664,
  "created_at" : "2018-01-03 03:47:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sia Tech",
      "screen_name" : "SiaTechHQ",
      "indices" : [ 3, 13 ],
      "id_str" : "3351041295",
      "id" : 3351041295
    }, {
      "name" : "Bittrex",
      "screen_name" : "BittrexExchange",
      "indices" : [ 108, 124 ],
      "id_str" : "2309637680",
      "id" : 2309637680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400296589447169",
  "text" : "RT @SiaTechHQ: The Sia team is investigating issues with wallet performance, deposits, and withdrawals with @BittrexExchange. Resolution ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bittrex",
        "screen_name" : "BittrexExchange",
        "indices" : [ 93, 109 ],
        "id_str" : "2309637680",
        "id" : 2309637680
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948262577112584197",
    "text" : "The Sia team is investigating issues with wallet performance, deposits, and withdrawals with @BittrexExchange. Resolution may require a code fix, we\u2019ll update with more info as soon as we can.",
    "id" : 948262577112584197,
    "created_at" : "2018-01-02 18:39:50 +0000",
    "user" : {
      "name" : "Sia Tech",
      "screen_name" : "SiaTechHQ",
      "protected" : false,
      "id_str" : "3351041295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878236359726465024\/xWPF_AWk_normal.jpg",
      "id" : 3351041295,
      "verified" : false
    }
  },
  "id" : 948400296589447169,
  "created_at" : "2018-01-03 03:47:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "NIST",
      "screen_name" : "usnistgov",
      "indices" : [ 128, 138 ],
      "id_str" : "46648807",
      "id" : 46648807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ruII9PI7Zo",
      "expanded_url" : "http:\/\/phy.so\/434127775",
      "display_url" : "phy.so\/434127775"
    } ]
  },
  "geo" : { },
  "id_str" : "948400208911757312",
  "text" : "RT @physorg_com: 'Quantum radio' may aid communications and mapping indoors, underground and underwater https:\/\/t.co\/ruII9PI7Zo @usnistgov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIST",
        "screen_name" : "usnistgov",
        "indices" : [ 111, 121 ],
        "id_str" : "46648807",
        "id" : 46648807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ruII9PI7Zo",
        "expanded_url" : "http:\/\/phy.so\/434127775",
        "display_url" : "phy.so\/434127775"
      } ]
    },
    "geo" : { },
    "id_str" : "948283541422567425",
    "text" : "'Quantum radio' may aid communications and mapping indoors, underground and underwater https:\/\/t.co\/ruII9PI7Zo @usnistgov",
    "id" : 948283541422567425,
    "created_at" : "2018-01-02 20:03:09 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 948400208911757312,
  "created_at" : "2018-01-03 03:46:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 3, 11 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400087130169344",
  "text" : "RT @2EZ_HBM: I think psps failed because it was a head of its time. If they dropped the PSP in 2018 with PlayStation 4 games it would go cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/CSQKdCZPhh",
        "expanded_url" : "https:\/\/twitter.com\/lilhomiemikey\/status\/947622015363702784",
        "display_url" : "twitter.com\/lilhomiemikey\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948055760608653312",
    "text" : "I think psps failed because it was a head of its time. If they dropped the PSP in 2018 with PlayStation 4 games it would go crazy. https:\/\/t.co\/CSQKdCZPhh",
    "id" : 948055760608653312,
    "created_at" : "2018-01-02 04:58:02 +0000",
    "user" : {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "protected" : false,
      "id_str" : "1645859450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929138210239807489\/b0upFpeM_normal.jpg",
      "id" : 1645859450,
      "verified" : false
    }
  },
  "id" : 948400087130169344,
  "created_at" : "2018-01-03 03:46:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "indices" : [ 3, 16 ],
      "id_str" : "62046607",
      "id" : 62046607
    }, {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 18, 34 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 52, 60 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400073091829760",
  "text" : "RT @MrMarinKnows: @dyquanpatterson @JosephTheFlyGuy @2EZ_HBM Ok you\u2019re not getting what me or the original poster is saying. The PSP failed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\"D PESO\"",
        "screen_name" : "dyquanpatterson",
        "indices" : [ 0, 16 ],
        "id_str" : "3558172577",
        "id" : 3558172577
      }, {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 17, 33 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 34, 42 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948267992965697537",
    "geo" : { },
    "id_str" : "948270153606631424",
    "in_reply_to_user_id" : 3558172577,
    "text" : "@dyquanpatterson @JosephTheFlyGuy @2EZ_HBM Ok you\u2019re not getting what me or the original poster is saying. The PSP failed b\/c its numbers were low and it hit discount bins and eventually got discounted. That\u2019s a FACT.",
    "id" : 948270153606631424,
    "in_reply_to_status_id" : 948267992965697537,
    "created_at" : "2018-01-02 19:09:57 +0000",
    "in_reply_to_screen_name" : "dyquanpatterson",
    "in_reply_to_user_id_str" : "3558172577",
    "user" : {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "protected" : false,
      "id_str" : "62046607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941825756631654400\/J1e9HvOq_normal.jpg",
      "id" : 62046607,
      "verified" : false
    }
  },
  "id" : 948400073091829760,
  "created_at" : "2018-01-03 03:46:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 3, 19 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "indices" : [ 21, 34 ],
      "id_str" : "62046607",
      "id" : 62046607
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 52, 60 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400065906868224",
  "text" : "RT @dyquanpatterson: @MrMarinKnows @JosephTheFlyGuy @2EZ_HBM Bro the psp was a portable version of a PlayStation 2 for the time period. Gra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SIMPMODE SQUAD",
        "screen_name" : "MrMarinKnows",
        "indices" : [ 0, 13 ],
        "id_str" : "62046607",
        "id" : 62046607
      }, {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 14, 30 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 31, 39 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948267148165619712",
    "geo" : { },
    "id_str" : "948267992965697537",
    "in_reply_to_user_id" : 62046607,
    "text" : "@MrMarinKnows @JosephTheFlyGuy @2EZ_HBM Bro the psp was a portable version of a PlayStation 2 for the time period. Graphics and gameplay weren\u2019t as good as they are now, so a portable version of the ps2 was good for the time. It wasn\u2019t a failure actually it was genius",
    "id" : 948267992965697537,
    "in_reply_to_status_id" : 948267148165619712,
    "created_at" : "2018-01-02 19:01:22 +0000",
    "in_reply_to_screen_name" : "MrMarinKnows",
    "in_reply_to_user_id_str" : "62046607",
    "user" : {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "protected" : false,
      "id_str" : "3558172577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/942156649149751298\/J1WvLKzc_normal.jpg",
      "id" : 3558172577,
      "verified" : false
    }
  },
  "id" : 948400065906868224,
  "created_at" : "2018-01-03 03:46:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "indices" : [ 3, 16 ],
      "id_str" : "62046607",
      "id" : 62046607
    }, {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 18, 34 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 52, 60 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400056792645632",
  "text" : "RT @MrMarinKnows: @dyquanpatterson @JosephTheFlyGuy @2EZ_HBM The XB was upgraded. The PSP was completely wiped off of the market for years\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\"D PESO\"",
        "screen_name" : "dyquanpatterson",
        "indices" : [ 0, 16 ],
        "id_str" : "3558172577",
        "id" : 3558172577
      }, {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 17, 33 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 34, 42 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948264636297764865",
    "geo" : { },
    "id_str" : "948267148165619712",
    "in_reply_to_user_id" : 3558172577,
    "text" : "@dyquanpatterson @JosephTheFlyGuy @2EZ_HBM The XB was upgraded. The PSP was completely wiped off of the market for years for a reason... there\u2019s factual numbers and reports behind this lol",
    "id" : 948267148165619712,
    "in_reply_to_status_id" : 948264636297764865,
    "created_at" : "2018-01-02 18:58:00 +0000",
    "in_reply_to_screen_name" : "dyquanpatterson",
    "in_reply_to_user_id_str" : "3558172577",
    "user" : {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "protected" : false,
      "id_str" : "62046607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941825756631654400\/J1e9HvOq_normal.jpg",
      "id" : 62046607,
      "verified" : false
    }
  },
  "id" : 948400056792645632,
  "created_at" : "2018-01-03 03:46:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 3, 19 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "indices" : [ 21, 34 ],
      "id_str" : "62046607",
      "id" : 62046607
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 52, 60 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400050476081153",
  "text" : "RT @dyquanpatterson: @MrMarinKnows @JosephTheFlyGuy @2EZ_HBM They discontinued the Xbox 360. Did that fail?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SIMPMODE SQUAD",
        "screen_name" : "MrMarinKnows",
        "indices" : [ 0, 13 ],
        "id_str" : "62046607",
        "id" : 62046607
      }, {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 14, 30 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 31, 39 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948262026396164096",
    "geo" : { },
    "id_str" : "948264636297764865",
    "in_reply_to_user_id" : 62046607,
    "text" : "@MrMarinKnows @JosephTheFlyGuy @2EZ_HBM They discontinued the Xbox 360. Did that fail?",
    "id" : 948264636297764865,
    "in_reply_to_status_id" : 948262026396164096,
    "created_at" : "2018-01-02 18:48:01 +0000",
    "in_reply_to_screen_name" : "MrMarinKnows",
    "in_reply_to_user_id_str" : "62046607",
    "user" : {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "protected" : false,
      "id_str" : "3558172577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/942156649149751298\/J1WvLKzc_normal.jpg",
      "id" : 3558172577,
      "verified" : false
    }
  },
  "id" : 948400050476081153,
  "created_at" : "2018-01-03 03:46:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "indices" : [ 3, 16 ],
      "id_str" : "62046607",
      "id" : 62046607
    }, {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 18, 34 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 35, 51 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 52, 60 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400044683743232",
  "text" : "RT @MrMarinKnows: @dyquanpatterson @JosephTheFlyGuy @2EZ_HBM They discontinued them. Therefore it FAILED. Now, the times caught up with the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\"D PESO\"",
        "screen_name" : "dyquanpatterson",
        "indices" : [ 0, 16 ],
        "id_str" : "3558172577",
        "id" : 3558172577
      }, {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 17, 33 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 34, 42 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948227907733909505",
    "geo" : { },
    "id_str" : "948262026396164096",
    "in_reply_to_user_id" : 3558172577,
    "text" : "@dyquanpatterson @JosephTheFlyGuy @2EZ_HBM They discontinued them. Therefore it FAILED. Now, the times caught up with the PSP and its then ambitious concept... but it failed. Same with the Dreamcast and online gaming.",
    "id" : 948262026396164096,
    "in_reply_to_status_id" : 948227907733909505,
    "created_at" : "2018-01-02 18:37:39 +0000",
    "in_reply_to_screen_name" : "dyquanpatterson",
    "in_reply_to_user_id_str" : "3558172577",
    "user" : {
      "name" : "SIMPMODE SQUAD",
      "screen_name" : "MrMarinKnows",
      "protected" : false,
      "id_str" : "62046607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941825756631654400\/J1e9HvOq_normal.jpg",
      "id" : 62046607,
      "verified" : false
    }
  },
  "id" : 948400044683743232,
  "created_at" : "2018-01-03 03:46:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "indices" : [ 3, 19 ],
      "id_str" : "3558172577",
      "id" : 3558172577
    }, {
      "name" : "Im Not Famous",
      "screen_name" : "JosephTheFlyGuy",
      "indices" : [ 21, 37 ],
      "id_str" : "326919245",
      "id" : 326919245
    }, {
      "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
      "screen_name" : "2EZ_HBM",
      "indices" : [ 38, 46 ],
      "id_str" : "1645859450",
      "id" : 1645859450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948400040531451904",
  "text" : "RT @dyquanpatterson: @JosephTheFlyGuy @2EZ_HBM PSP didn\u2019t fail at all, It was good for it\u2019s time but now we have the Switch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Im Not Famous",
        "screen_name" : "JosephTheFlyGuy",
        "indices" : [ 0, 16 ],
        "id_str" : "326919245",
        "id" : 326919245
      }, {
        "name" : "\uD83E\uDD34\uD83C\uDFFEMark",
        "screen_name" : "2EZ_HBM",
        "indices" : [ 17, 25 ],
        "id_str" : "1645859450",
        "id" : 1645859450
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "948221511445266432",
    "geo" : { },
    "id_str" : "948227907733909505",
    "in_reply_to_user_id" : 326919245,
    "text" : "@JosephTheFlyGuy @2EZ_HBM PSP didn\u2019t fail at all, It was good for it\u2019s time but now we have the Switch",
    "id" : 948227907733909505,
    "in_reply_to_status_id" : 948221511445266432,
    "created_at" : "2018-01-02 16:22:05 +0000",
    "in_reply_to_screen_name" : "JosephTheFlyGuy",
    "in_reply_to_user_id_str" : "326919245",
    "user" : {
      "name" : "\"D PESO\"",
      "screen_name" : "dyquanpatterson",
      "protected" : false,
      "id_str" : "3558172577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/942156649149751298\/J1WvLKzc_normal.jpg",
      "id" : 3558172577,
      "verified" : false
    }
  },
  "id" : 948400040531451904,
  "created_at" : "2018-01-03 03:46:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/WaIqeI17B2",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/pixel-perfect-free-mockups\/",
      "display_url" : "webdesigndev.com\/pixel-perfect-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948399642810748930",
  "text" : "RT @WebDesignDev: 20 Pixel-Perfect Free Mockups for Designers: https:\/\/t.co\/WaIqeI17B2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/WaIqeI17B2",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/pixel-perfect-free-mockups\/",
        "display_url" : "webdesigndev.com\/pixel-perfect-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948391843204665345",
    "text" : "20 Pixel-Perfect Free Mockups for Designers: https:\/\/t.co\/WaIqeI17B2",
    "id" : 948391843204665345,
    "created_at" : "2018-01-03 03:13:30 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948399642810748930,
  "created_at" : "2018-01-03 03:44:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948389424055844864",
  "text" : "RT @Snapzu_Science: Fun Fact: In a full grown rye plant, the total length of roots may reach 380 miles (613 km).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948359885762183169",
    "text" : "Fun Fact: In a full grown rye plant, the total length of roots may reach 380 miles (613 km).",
    "id" : 948359885762183169,
    "created_at" : "2018-01-03 01:06:31 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948389424055844864,
  "created_at" : "2018-01-03 03:03:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948389350424891403",
  "text" : "RT @lorenridinger: \"Persistence. Perfection. Patience. Power. Prioritize your passion. It keeps you sane.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948373485591678977",
    "text" : "\"Persistence. Perfection. Patience. Power. Prioritize your passion. It keeps you sane.\u201D",
    "id" : 948373485591678977,
    "created_at" : "2018-01-03 02:00:33 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948389350424891403,
  "created_at" : "2018-01-03 03:03:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "indices" : [ 3, 11 ],
      "id_str" : "304857570",
      "id" : 304857570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pnyzFVEMnt",
      "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
      "display_url" : "ift.tt\/11IDdIl"
    } ]
  },
  "geo" : { },
  "id_str" : "948389307223629825",
  "text" : "RT @ChadUhl: Broncos: Trevor Siemian will undergo shoulder surgery; expected to need 2-3 months for recovery (ESPN) https:\/\/t.co\/pnyzFVEMnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/pnyzFVEMnt",
        "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
        "display_url" : "ift.tt\/11IDdIl"
      } ]
    },
    "geo" : { },
    "id_str" : "948386779182313472",
    "text" : "Broncos: Trevor Siemian will undergo shoulder surgery; expected to need 2-3 months for recovery (ESPN) https:\/\/t.co\/pnyzFVEMnt",
    "id" : 948386779182313472,
    "created_at" : "2018-01-03 02:53:22 +0000",
    "user" : {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "protected" : false,
      "id_str" : "304857570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688992808678506497\/rDcjGfuG_normal.jpg",
      "id" : 304857570,
      "verified" : false
    }
  },
  "id" : 948389307223629825,
  "created_at" : "2018-01-03 03:03:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poloniex Exchange",
      "screen_name" : "Poloniex",
      "indices" : [ 3, 12 ],
      "id_str" : "2288889440",
      "id" : 2288889440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948389250181095425",
  "text" : "RT @Poloniex: WARNING: There's an impostor Poloniex app in the Google Play Store. Do\nnot use this; it may be malicious. There is no officia\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "940243721827872769",
    "text" : "WARNING: There's an impostor Poloniex app in the Google Play Store. Do\nnot use this; it may be malicious. There is no official Poloniex app.",
    "id" : 940243721827872769,
    "created_at" : "2017-12-11 15:35:46 +0000",
    "user" : {
      "name" : "Poloniex Exchange",
      "screen_name" : "Poloniex",
      "protected" : false,
      "id_str" : "2288889440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879519440072826880\/8eQc8JrP_normal.jpg",
      "id" : 2288889440,
      "verified" : true
    }
  },
  "id" : 948389250181095425,
  "created_at" : "2018-01-03 03:03:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Rz7fZpH8ni",
      "expanded_url" : "https:\/\/trib.al\/CP6Lx81",
      "display_url" : "trib.al\/CP6Lx81"
    } ]
  },
  "geo" : { },
  "id_str" : "948357960929103873",
  "text" : "RT @epicurious: The holidays might be over, but buttered rum season is still going strong.\nhttps:\/\/t.co\/Rz7fZpH8ni",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Rz7fZpH8ni",
        "expanded_url" : "https:\/\/trib.al\/CP6Lx81",
        "display_url" : "trib.al\/CP6Lx81"
      } ]
    },
    "geo" : { },
    "id_str" : "948332084854181888",
    "text" : "The holidays might be over, but buttered rum season is still going strong.\nhttps:\/\/t.co\/Rz7fZpH8ni",
    "id" : 948332084854181888,
    "created_at" : "2018-01-02 23:16:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948357960929103873,
  "created_at" : "2018-01-03 00:58:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/SH6sYhp3Qp",
      "expanded_url" : "http:\/\/engt.co\/2CGzmoM",
      "display_url" : "engt.co\/2CGzmoM"
    } ]
  },
  "geo" : { },
  "id_str" : "948357718024257536",
  "text" : "RT @engadget: Judge sides with Airbnb in lawsuit from US apartment landlord https:\/\/t.co\/SH6sYhp3Qp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/SH6sYhp3Qp",
        "expanded_url" : "http:\/\/engt.co\/2CGzmoM",
        "display_url" : "engt.co\/2CGzmoM"
      } ]
    },
    "geo" : { },
    "id_str" : "948332781414699008",
    "text" : "Judge sides with Airbnb in lawsuit from US apartment landlord https:\/\/t.co\/SH6sYhp3Qp",
    "id" : 948332781414699008,
    "created_at" : "2018-01-02 23:18:48 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948357718024257536,
  "created_at" : "2018-01-03 00:57:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ShEQvKgUpd",
      "expanded_url" : "https:\/\/www.diyphotography.net\/7artisans-launches-12mm-f2-8-35mm-f1-2-aps-c-lenses-200\/",
      "display_url" : "diyphotography.net\/7artisans-laun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948357352306114560",
  "text" : "RT @JayHoque: 7Artisans launches 12mm F2.8 and 35mm F1.2 APS-C lenses, both under $200: https:\/\/t.co\/ShEQvKgUpd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ShEQvKgUpd",
        "expanded_url" : "https:\/\/www.diyphotography.net\/7artisans-launches-12mm-f2-8-35mm-f1-2-aps-c-lenses-200\/",
        "display_url" : "diyphotography.net\/7artisans-laun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948164798629531649",
    "text" : "7Artisans launches 12mm F2.8 and 35mm F1.2 APS-C lenses, both under $200: https:\/\/t.co\/ShEQvKgUpd",
    "id" : 948164798629531649,
    "created_at" : "2018-01-02 12:11:18 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948357352306114560,
  "created_at" : "2018-01-03 00:56:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/QhKCPk5per",
      "expanded_url" : "https:\/\/www.diyphotography.net\/video-shot-diy-8x10-large-format-video-camera\/",
      "display_url" : "diyphotography.net\/video-shot-diy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948357307590742017",
  "text" : "RT @JayHoque: This video was shot on a DIY 8\u00D710 large format video camera: https:\/\/t.co\/QhKCPk5per",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/QhKCPk5per",
        "expanded_url" : "https:\/\/www.diyphotography.net\/video-shot-diy-8x10-large-format-video-camera\/",
        "display_url" : "diyphotography.net\/video-shot-diy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948149674778746882",
    "text" : "This video was shot on a DIY 8\u00D710 large format video camera: https:\/\/t.co\/QhKCPk5per",
    "id" : 948149674778746882,
    "created_at" : "2018-01-02 11:11:12 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948357307590742017,
  "created_at" : "2018-01-03 00:56:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948357280575229958",
  "text" : "I got brackets from Home Depot and also bought some magnets for the other project on the side as well. Let us do this thing!",
  "id" : 948357280575229958,
  "created_at" : "2018-01-03 00:56:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Croatia",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948357169803661312",
  "text" : "RT @Snapzu_Earth: Daily Fact: In #Croatia, scientists discovered that lampposts were falling down because a chemical in the urine of male d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Croatia",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948172035372412929",
    "text" : "Daily Fact: In #Croatia, scientists discovered that lampposts were falling down because a chemical in the urine of male dogs was rotting the metal.",
    "id" : 948172035372412929,
    "created_at" : "2018-01-02 12:40:04 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948357169803661312,
  "created_at" : "2018-01-03 00:55:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/C0ktCWJNri",
      "expanded_url" : "https:\/\/www.slashgear.com\/first-blue-moon-eclipse-in-150-years-happens-in-january-02513316\/?source=Snapzu",
      "display_url" : "slashgear.com\/first-blue-moo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948354946763776000",
  "text" : "RT @Snapzu_Science: First Blue Moon eclipse in 150 years happens in January https:\/\/t.co\/C0ktCWJNri",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/C0ktCWJNri",
        "expanded_url" : "https:\/\/www.slashgear.com\/first-blue-moon-eclipse-in-150-years-happens-in-january-02513316\/?source=Snapzu",
        "display_url" : "slashgear.com\/first-blue-moo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948351484823068672",
    "text" : "First Blue Moon eclipse in 150 years happens in January https:\/\/t.co\/C0ktCWJNri",
    "id" : 948351484823068672,
    "created_at" : "2018-01-03 00:33:08 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948354946763776000,
  "created_at" : "2018-01-03 00:46:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mCXnL4Sm6Q",
      "expanded_url" : "https:\/\/buff.ly\/2DSbCgO",
      "display_url" : "buff.ly\/2DSbCgO"
    } ]
  },
  "geo" : { },
  "id_str" : "948354547856105477",
  "text" : "RT @analyticbridge: Character Analysis in Production and Sales https:\/\/t.co\/mCXnL4Sm6Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/mCXnL4Sm6Q",
        "expanded_url" : "https:\/\/buff.ly\/2DSbCgO",
        "display_url" : "buff.ly\/2DSbCgO"
      } ]
    },
    "geo" : { },
    "id_str" : "948329813017808898",
    "text" : "Character Analysis in Production and Sales https:\/\/t.co\/mCXnL4Sm6Q",
    "id" : 948329813017808898,
    "created_at" : "2018-01-02 23:07:01 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948354547856105477,
  "created_at" : "2018-01-03 00:45:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948354508110876672",
  "text" : "RT @Snapzu_Science: Did you know? 60 years ago: Otto Hahn discovered nuclear fission by splitting uranium, Teflon was invented.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948333123669905408",
    "text" : "Did you know? 60 years ago: Otto Hahn discovered nuclear fission by splitting uranium, Teflon was invented.",
    "id" : 948333123669905408,
    "created_at" : "2018-01-02 23:20:10 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948354508110876672,
  "created_at" : "2018-01-03 00:45:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948354433649463296",
  "text" : "RT @RandiAthenas: After a horrible Summer, Humpty Dumpty had a great Fall.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948343920341041152",
    "text" : "After a horrible Summer, Humpty Dumpty had a great Fall.",
    "id" : 948343920341041152,
    "created_at" : "2018-01-03 00:03:04 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 948354433649463296,
  "created_at" : "2018-01-03 00:44:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8eSXzF6dU2",
      "expanded_url" : "https:\/\/fstoppers.com\/pictures\/shooting-explosions-world-champion-stunt-rider-mike-jensen-210369?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/pictures\/shoot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948354410362654725",
  "text" : "RT @JayHoque: Shooting Explosions With World Champion Stunt Rider Mike Jensen: https:\/\/t.co\/8eSXzF6dU2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/8eSXzF6dU2",
        "expanded_url" : "https:\/\/fstoppers.com\/pictures\/shooting-explosions-world-champion-stunt-rider-mike-jensen-210369?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/pictures\/shoot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948353572390961154",
    "text" : "Shooting Explosions With World Champion Stunt Rider Mike Jensen: https:\/\/t.co\/8eSXzF6dU2",
    "id" : 948353572390961154,
    "created_at" : "2018-01-03 00:41:25 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948354410362654725,
  "created_at" : "2018-01-03 00:44:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 0, 5 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948336087377653760",
  "geo" : { },
  "id_str" : "948354362388164609",
  "in_reply_to_user_id" : 1118451,
  "text" : "@make I am a Coptic Egyptian minority who spoke at Maker Faire. I would love the opportunity to talk more about my work. Can we get in touch?",
  "id" : 948354362388164609,
  "in_reply_to_status_id" : 948336087377653760,
  "created_at" : "2018-01-03 00:44:34 +0000",
  "in_reply_to_screen_name" : "make",
  "in_reply_to_user_id_str" : "1118451",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948353988948381696",
  "text" : "RT @lorenridinger: \u201CCourage isn't having the strength to go on - it is going on when you don't have strength.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948343338998124544",
    "text" : "\u201CCourage isn't having the strength to go on - it is going on when you don't have strength.\u201D",
    "id" : 948343338998124544,
    "created_at" : "2018-01-03 00:00:46 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948353988948381696,
  "created_at" : "2018-01-03 00:43:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DroneSport",
      "screen_name" : "drone_sport",
      "indices" : [ 3, 15 ],
      "id_str" : "3064591599",
      "id" : 3064591599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948328801745948673",
  "text" : "RT @drone_sport: New Primary Insurance for Drone Pilots, with no Drone Limit, no Deductibles, and Worldwide Coverage | DroneSport - https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 139, 146 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/zJjO50xgSA",
        "expanded_url" : "http:\/\/ift.tt\/2Ctf2KU",
        "display_url" : "ift.tt\/2Ctf2KU"
      } ]
    },
    "geo" : { },
    "id_str" : "948217714266525697",
    "text" : "New Primary Insurance for Drone Pilots, with no Drone Limit, no Deductibles, and Worldwide Coverage | DroneSport - https:\/\/t.co\/zJjO50xgSA #drones",
    "id" : 948217714266525697,
    "created_at" : "2018-01-02 15:41:34 +0000",
    "user" : {
      "name" : "DroneSport",
      "screen_name" : "drone_sport",
      "protected" : false,
      "id_str" : "3064591599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594182328131276800\/vULo7m89_normal.png",
      "id" : 3064591599,
      "verified" : false
    }
  },
  "id" : 948328801745948673,
  "created_at" : "2018-01-02 23:03:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948328702223544323",
  "text" : "RT @lorenridinger: \u201CAnyone can hide. Facing up to things, working through them, that's what makes you strong.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948313146959323136",
    "text" : "\u201CAnyone can hide. Facing up to things, working through them, that's what makes you strong.\u201D",
    "id" : 948313146959323136,
    "created_at" : "2018-01-02 22:00:47 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948328702223544323,
  "created_at" : "2018-01-02 23:02:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948328671206625280",
  "text" : "Discord has a more intuitive UI than Slack, there I said it!!!",
  "id" : 948328671206625280,
  "created_at" : "2018-01-02 23:02:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dev",
      "indices" : [ 66, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948327506741989376",
  "text" : "Now using developer mode for chrome extensions and live debugging #dev",
  "id" : 948327506741989376,
  "created_at" : "2018-01-02 22:57:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ITV London",
      "screen_name" : "itvlondon",
      "indices" : [ 3, 13 ],
      "id_str" : "22919206",
      "id" : 22919206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/k5pCWzvJ2K",
      "expanded_url" : "http:\/\/www.itv.com\/news\/london\/2018-01-02\/man-dies-after-falling-50ft-at-canary-wharf-building-site\/",
      "display_url" : "itv.com\/news\/london\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948308831846715392",
  "text" : "RT @itvlondon: Man dies after falling 50ft at Canary Wharf building site https:\/\/t.co\/k5pCWzvJ2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/k5pCWzvJ2K",
        "expanded_url" : "http:\/\/www.itv.com\/news\/london\/2018-01-02\/man-dies-after-falling-50ft-at-canary-wharf-building-site\/",
        "display_url" : "itv.com\/news\/london\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948164078014533632",
    "text" : "Man dies after falling 50ft at Canary Wharf building site https:\/\/t.co\/k5pCWzvJ2K",
    "id" : 948164078014533632,
    "created_at" : "2018-01-02 12:08:26 +0000",
    "user" : {
      "name" : "ITV London",
      "screen_name" : "itvlondon",
      "protected" : false,
      "id_str" : "22919206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3105941050\/17bab587f151975ca4ae9f6a1cab7c56_normal.png",
      "id" : 22919206,
      "verified" : true
    }
  },
  "id" : 948308831846715392,
  "created_at" : "2018-01-02 21:43:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/JC97UEBsZ2",
      "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/02\/dji-drone-collided-us-army-black-hawk-chopper-dented-rotor\/",
      "display_url" : "petapixel.com\/2018\/01\/02\/dji\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948308584999346176",
  "text" : "RT @JayHoque: DJI Drone Collided with US Army Black Hawk Chopper and Dented Its Rotor: https:\/\/t.co\/JC97UEBsZ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/JC97UEBsZ2",
        "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/02\/dji-drone-collided-us-army-black-hawk-chopper-dented-rotor\/",
        "display_url" : "petapixel.com\/2018\/01\/02\/dji\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948306927922106368",
    "text" : "DJI Drone Collided with US Army Black Hawk Chopper and Dented Its Rotor: https:\/\/t.co\/JC97UEBsZ2",
    "id" : 948306927922106368,
    "created_at" : "2018-01-02 21:36:04 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948308584999346176,
  "created_at" : "2018-01-02 21:42:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWAS NHS Trust",
      "screen_name" : "NWAmbulance",
      "indices" : [ 3, 15 ],
      "id_str" : "348464547",
      "id" : 348464547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948308567500746753",
  "text" : "RT @NWAmbulance: We're experiencing very high numbers of 999 calls. Please only call if you have a serious \/life threatening condition. Uns\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948258710836727808",
    "text" : "We're experiencing very high numbers of 999 calls. Please only call if you have a serious \/life threatening condition. Unsure where else to go, call NHS 111 for advice.",
    "id" : 948258710836727808,
    "created_at" : "2018-01-02 18:24:29 +0000",
    "user" : {
      "name" : "NWAS NHS Trust",
      "screen_name" : "NWAmbulance",
      "protected" : false,
      "id_str" : "348464547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941612441607245825\/i4v9SopS_normal.jpg",
      "id" : 348464547,
      "verified" : true
    }
  },
  "id" : 948308567500746753,
  "created_at" : "2018-01-02 21:42:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Iy7ARFt4nY",
      "expanded_url" : "https:\/\/www.datasciencecentral.com\/profiles\/blogs\/learn-python-in-3-days-step-by-step-guide",
      "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948308513780092928",
  "text" : "RT @analyticbridge: Learn Python in 3 days : Step by Step Guide, https:\/\/t.co\/Iy7ARFt4nY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/Iy7ARFt4nY",
        "expanded_url" : "https:\/\/www.datasciencecentral.com\/profiles\/blogs\/learn-python-in-3-days-step-by-step-guide",
        "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948308169524219904",
    "text" : "Learn Python in 3 days : Step by Step Guide, https:\/\/t.co\/Iy7ARFt4nY",
    "id" : 948308169524219904,
    "created_at" : "2018-01-02 21:41:00 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948308513780092928,
  "created_at" : "2018-01-02 21:42:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948308351506460672",
  "geo" : { },
  "id_str" : "948308475746181124",
  "in_reply_to_user_id" : 210979938,
  "text" : "Yes, I expect that target",
  "id" : 948308475746181124,
  "in_reply_to_status_id" : 948308351506460672,
  "created_at" : "2018-01-02 21:42:13 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/T4TuADvAxA",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/PINKBTC\/nkk45ryd-Pinkcoin-Short-Target\/",
      "display_url" : "tradingview.com\/chart\/PINKBTC\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948308351506460672",
  "text" : "Pinkcoin Short Target - $PINKBTC chart https:\/\/t.co\/T4TuADvAxA",
  "id" : 948308351506460672,
  "created_at" : "2018-01-02 21:41:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Abramowicz",
      "screen_name" : "lisaabramowicz1",
      "indices" : [ 3, 19 ],
      "id_str" : "1327359720",
      "id" : 1327359720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948302299616763907",
  "text" : "RT @lisaabramowicz1: Automakers just saw their first annual US sales decline since 2009. Few analysts think this year will be any better fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/ErVVuOADhb",
        "expanded_url" : "https:\/\/www.bloomberg.com\/news\/articles\/2018-01-02\/fed-outlook-for-higher-rates-dims-u-s-auto-sales-view-for-2018",
        "display_url" : "bloomberg.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948174100199084033",
    "text" : "Automakers just saw their first annual US sales decline since 2009. Few analysts think this year will be any better for business. https:\/\/t.co\/ErVVuOADhb",
    "id" : 948174100199084033,
    "created_at" : "2018-01-02 12:48:16 +0000",
    "user" : {
      "name" : "Lisa Abramowicz",
      "screen_name" : "lisaabramowicz1",
      "protected" : false,
      "id_str" : "1327359720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666352316820271105\/_YfemtIK_normal.png",
      "id" : 1327359720,
      "verified" : true
    }
  },
  "id" : 948302299616763907,
  "created_at" : "2018-01-02 21:17:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNBC",
      "screen_name" : "CNBC",
      "indices" : [ 3, 8 ],
      "id_str" : "20402945",
      "id" : 20402945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/psIUDPiRzG",
      "expanded_url" : "http:\/\/cnb.cx\/2CHg42s",
      "display_url" : "cnb.cx\/2CHg42s"
    } ]
  },
  "geo" : { },
  "id_str" : "948302102853488641",
  "text" : "RT @CNBC: With one simple tweet, Elon Musk shows a masterful lesson in leadership https:\/\/t.co\/psIUDPiRzG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/psIUDPiRzG",
        "expanded_url" : "http:\/\/cnb.cx\/2CHg42s",
        "display_url" : "cnb.cx\/2CHg42s"
      } ]
    },
    "geo" : { },
    "id_str" : "948228117876871168",
    "text" : "With one simple tweet, Elon Musk shows a masterful lesson in leadership https:\/\/t.co\/psIUDPiRzG",
    "id" : 948228117876871168,
    "created_at" : "2018-01-02 16:22:55 +0000",
    "user" : {
      "name" : "CNBC",
      "screen_name" : "CNBC",
      "protected" : false,
      "id_str" : "20402945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875399584477962241\/CsazvyAF_normal.jpg",
      "id" : 20402945,
      "verified" : true
    }
  },
  "id" : 948302102853488641,
  "created_at" : "2018-01-02 21:16:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Robert Herjavec",
      "screen_name" : "robertherjavec",
      "indices" : [ 107, 122 ],
      "id_str" : "39275966",
      "id" : 39275966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948301924318760960",
  "text" : "RT @TheSharkDaymond: \"Don\u2019t start a business. Find a problem, Solve a problem, The business comes second.\" @robertherjavec",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Herjavec",
        "screen_name" : "robertherjavec",
        "indices" : [ 86, 101 ],
        "id_str" : "39275966",
        "id" : 39275966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "941732090764148737",
    "text" : "\"Don\u2019t start a business. Find a problem, Solve a problem, The business comes second.\" @robertherjavec",
    "id" : 941732090764148737,
    "created_at" : "2017-12-15 18:10:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932689703391940615\/zAkwGMNj_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 948301924318760960,
  "created_at" : "2018-01-02 21:16:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948301888272982016",
  "text" : "RT @BarbaraCorcoran: I want my entrepreneurs to have street smarts. Those are the ones who win in business!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "941760181872013312",
    "text" : "I want my entrepreneurs to have street smarts. Those are the ones who win in business!",
    "id" : 941760181872013312,
    "created_at" : "2017-12-15 20:01:39 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948301888272982016,
  "created_at" : "2018-01-02 21:16:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948301777941729281",
  "text" : "RT @CopticOrphans: Sad start to the new year. Praying for the victims families and for the safety of all those in Egypt. https:\/\/t.co\/sa4Xc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/sa4XcemCai",
        "expanded_url" : "https:\/\/buff.ly\/2DTjD50",
        "display_url" : "buff.ly\/2DTjD50"
      } ]
    },
    "geo" : { },
    "id_str" : "948297927205773312",
    "text" : "Sad start to the new year. Praying for the victims families and for the safety of all those in Egypt. https:\/\/t.co\/sa4XcemCai",
    "id" : 948297927205773312,
    "created_at" : "2018-01-02 21:00:19 +0000",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 948301777941729281,
  "created_at" : "2018-01-02 21:15:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948301712292483074",
  "text" : "RT @StartupDailyANZ: Got a new year's resolution to eat better at work? Sydney startup SnackProud designs nutritious snack boxes to keep wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "startupaus",
        "indices" : [ 160, 171 ]
      } ],
      "urls" : [ {
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/9IQ1MAnzyA",
        "expanded_url" : "http:\/\/ow.ly\/dNxP30gZai8",
        "display_url" : "ow.ly\/dNxP30gZai8"
      } ]
    },
    "geo" : { },
    "id_str" : "948297853453127681",
    "text" : "Got a new year's resolution to eat better at work? Sydney startup SnackProud designs nutritious snack boxes to keep workplaces healthy: https:\/\/t.co\/9IQ1MAnzyA #startupaus",
    "id" : 948297853453127681,
    "created_at" : "2018-01-02 21:00:01 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948301712292483074,
  "created_at" : "2018-01-02 21:15:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "indices" : [ 3, 11 ],
      "id_str" : "304857570",
      "id" : 304857570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/pnyzFVEMnt",
      "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
      "display_url" : "ift.tt\/11IDdIl"
    } ]
  },
  "geo" : { },
  "id_str" : "948301689597067264",
  "text" : "RT @ChadUhl: John Elway says Broncos have \"got to get better\" at QB position (ESPN) https:\/\/t.co\/pnyzFVEMnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/pnyzFVEMnt",
        "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
        "display_url" : "ift.tt\/11IDdIl"
      } ]
    },
    "geo" : { },
    "id_str" : "948298802527686656",
    "text" : "John Elway says Broncos have \"got to get better\" at QB position (ESPN) https:\/\/t.co\/pnyzFVEMnt",
    "id" : 948298802527686656,
    "created_at" : "2018-01-02 21:03:47 +0000",
    "user" : {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "protected" : false,
      "id_str" : "304857570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688992808678506497\/rDcjGfuG_normal.jpg",
      "id" : 304857570,
      "verified" : false
    }
  },
  "id" : 948301689597067264,
  "created_at" : "2018-01-02 21:15:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/0wXTfZoJYI",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/mobile-profile-user-interfaces\/",
      "display_url" : "webdesigndev.com\/mobile-profile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948301676846505984",
  "text" : "RT @WebDesignDev: 25 Unique Designs for Mobile Profile User Interfaces: https:\/\/t.co\/0wXTfZoJYI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/0wXTfZoJYI",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/mobile-profile-user-interfaces\/",
        "display_url" : "webdesigndev.com\/mobile-profile\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948300306558996480",
    "text" : "25 Unique Designs for Mobile Profile User Interfaces: https:\/\/t.co\/0wXTfZoJYI",
    "id" : 948300306558996480,
    "created_at" : "2018-01-02 21:09:46 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948301676846505984,
  "created_at" : "2018-01-02 21:15:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TradingView",
      "screen_name" : "tradingview",
      "indices" : [ 69, 81 ],
      "id_str" : "373457750",
      "id" : 373457750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948301564065845248\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SgdKLY2ujm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSkLOoKVMAAYq2k.jpg",
      "id_str" : "948301542465024000",
      "id" : 948301542465024000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSkLOoKVMAAYq2k.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1382
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1382
      } ],
      "display_url" : "pic.twitter.com\/SgdKLY2ujm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948301564065845248\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SgdKLY2ujm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSkLPSsVAAAayA0.jpg",
      "id_str" : "948301553881907200",
      "id" : 948301553881907200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSkLPSsVAAAayA0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 651,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/SgdKLY2ujm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/g3XPv6rBtJ",
      "expanded_url" : "http:\/\/bit.ly\/2EDx8Hf",
      "display_url" : "bit.ly\/2EDx8Hf"
    } ]
  },
  "geo" : { },
  "id_str" : "948301564065845248",
  "text" : "I am still calling another long position https:\/\/t.co\/g3XPv6rBtJ via @tradingview https:\/\/t.co\/SgdKLY2ujm",
  "id" : 948301564065845248,
  "created_at" : "2018-01-02 21:14:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/hUsWbAWdt7",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/SCBTC\/kOk0bR9W-SCBTC-Poloniex-Long\/",
      "display_url" : "tradingview.com\/chart\/SCBTC\/kO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948301098401460224",
  "text" : "SCBTC: Poloniex Long - $SCBTC chart https:\/\/t.co\/hUsWbAWdt7",
  "id" : 948301098401460224,
  "created_at" : "2018-01-02 21:12:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Abramowicz",
      "screen_name" : "lisaabramowicz1",
      "indices" : [ 3, 19 ],
      "id_str" : "1327359720",
      "id" : 1327359720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948291657266614277",
  "text" : "RT @lisaabramowicz1: PayPal's co-founder has amassed hundreds of millions of dollars of bitcoin through his venture capital firm. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/nNCetW202m",
        "expanded_url" : "https:\/\/www.wsj.com\/articles\/peter-thiels-founders-fund-makes-big-bet-on-bitcoin-1514917433",
        "display_url" : "wsj.com\/articles\/peter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948265767505743873",
    "text" : "PayPal's co-founder has amassed hundreds of millions of dollars of bitcoin through his venture capital firm. https:\/\/t.co\/nNCetW202m",
    "id" : 948265767505743873,
    "created_at" : "2018-01-02 18:52:31 +0000",
    "user" : {
      "name" : "Lisa Abramowicz",
      "screen_name" : "lisaabramowicz1",
      "protected" : false,
      "id_str" : "1327359720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666352316820271105\/_YfemtIK_normal.png",
      "id" : 1327359720,
      "verified" : true
    }
  },
  "id" : 948291657266614277,
  "created_at" : "2018-01-02 20:35:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FXStreet News",
      "screen_name" : "FXstreetNews",
      "indices" : [ 3, 16 ],
      "id_str" : "27652717",
      "id" : 27652717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Growth",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "Banks",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/dYjEDQPxez",
      "expanded_url" : "https:\/\/goo.gl\/GA2aRr",
      "display_url" : "goo.gl\/GA2aRr"
    } ]
  },
  "geo" : { },
  "id_str" : "948291434276442113",
  "text" : "RT @FXstreetNews: Global economy: Expansion to continue in 2018 and 2019 - Wells Fargo https:\/\/t.co\/dYjEDQPxez #Growth #Banks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.fxstreet.com\/\" rel=\"nofollow\"\u003EFXstreet.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Growth",
        "indices" : [ 93, 100 ]
      }, {
        "text" : "Banks",
        "indices" : [ 101, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/dYjEDQPxez",
        "expanded_url" : "https:\/\/goo.gl\/GA2aRr",
        "display_url" : "goo.gl\/GA2aRr"
      } ]
    },
    "geo" : { },
    "id_str" : "948282060246081536",
    "text" : "Global economy: Expansion to continue in 2018 and 2019 - Wells Fargo https:\/\/t.co\/dYjEDQPxez #Growth #Banks",
    "id" : 948282060246081536,
    "created_at" : "2018-01-02 19:57:16 +0000",
    "user" : {
      "name" : "FXStreet News",
      "screen_name" : "FXstreetNews",
      "protected" : false,
      "id_str" : "27652717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900669341171056640\/06pIS4h4_normal.jpg",
      "id" : 27652717,
      "verified" : false
    }
  },
  "id" : 948291434276442113,
  "created_at" : "2018-01-02 20:34:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/n3HAssFvY4",
      "expanded_url" : "https:\/\/twitter.com\/GreenGamerJD\/status\/948011779065569280",
      "display_url" : "twitter.com\/GreenGamerJD\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948291075558526978",
  "text" : "RT @Matthiasiam: Stockholm syndrome and desensitization. At least thats the only conclusion I can come to. https:\/\/t.co\/n3HAssFvY4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/n3HAssFvY4",
        "expanded_url" : "https:\/\/twitter.com\/GreenGamerJD\/status\/948011779065569280",
        "display_url" : "twitter.com\/GreenGamerJD\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948012191373860865",
    "text" : "Stockholm syndrome and desensitization. At least thats the only conclusion I can come to. https:\/\/t.co\/n3HAssFvY4",
    "id" : 948012191373860865,
    "created_at" : "2018-01-02 02:04:54 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929487527995510784\/Hzr8H3DU_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 948291075558526978,
  "created_at" : "2018-01-02 20:33:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 109, 116 ],
      "id_str" : "16228398",
      "id" : 16228398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288730065928193",
  "text" : "RT @TheSharkDaymond: \"Do the work. Out-work. Out-think. Out-sell your expectations. There are no shortcuts.\" @mcuban",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 88, 95 ],
        "id_str" : "16228398",
        "id" : 16228398
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948273000180342784",
    "text" : "\"Do the work. Out-work. Out-think. Out-sell your expectations. There are no shortcuts.\" @mcuban",
    "id" : 948273000180342784,
    "created_at" : "2018-01-02 19:21:15 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932689703391940615\/zAkwGMNj_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 948288730065928193,
  "created_at" : "2018-01-02 20:23:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288695186149376",
  "text" : "RT @BarbaraCorcoran: To be successful, you have to learn how to fail well. Fail often and fail well.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948190942573617152",
    "text" : "To be successful, you have to learn how to fail well. Fail often and fail well.",
    "id" : 948190942573617152,
    "created_at" : "2018-01-02 13:55:11 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948288695186149376,
  "created_at" : "2018-01-02 20:23:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288668682407937",
  "text" : "RT @BarbaraCorcoran: I can't work off of a to-do list that isn\u2019t on paper! The delete button will never give you the kicks that crossing of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948283007508664320",
    "text" : "I can't work off of a to-do list that isn\u2019t on paper! The delete button will never give you the kicks that crossing off tasks will give you.",
    "id" : 948283007508664320,
    "created_at" : "2018-01-02 20:01:01 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 948288668682407937,
  "created_at" : "2018-01-02 20:23:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288616916189185",
  "text" : "RT @BONNIELYNN2015: the little distraction is up ...sipping coffee......yum yum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948286109829578753",
    "text" : "the little distraction is up ...sipping coffee......yum yum",
    "id" : 948286109829578753,
    "created_at" : "2018-01-02 20:13:21 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946587001930711040\/6K0BSqwc_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 948288616916189185,
  "created_at" : "2018-01-02 20:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nansen Malin",
      "screen_name" : "nansen",
      "indices" : [ 3, 10 ],
      "id_str" : "14389132",
      "id" : 14389132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/F0pRnOM3xP",
      "expanded_url" : "http:\/\/komonews.com\/news\/local\/rail-investigator-says-train-derailment-was-caused-by-more-than-just-speed",
      "display_url" : "komonews.com\/news\/local\/rai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948288588067889152",
  "text" : "RT @nansen: Rail investigator says WA train derailment may have been caused by more than just speed  https:\/\/t.co\/F0pRnOM3xP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/F0pRnOM3xP",
        "expanded_url" : "http:\/\/komonews.com\/news\/local\/rail-investigator-says-train-derailment-was-caused-by-more-than-just-speed",
        "display_url" : "komonews.com\/news\/local\/rai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948286652316880896",
    "text" : "Rail investigator says WA train derailment may have been caused by more than just speed  https:\/\/t.co\/F0pRnOM3xP",
    "id" : 948286652316880896,
    "created_at" : "2018-01-02 20:15:30 +0000",
    "user" : {
      "name" : "Nansen Malin",
      "screen_name" : "nansen",
      "protected" : false,
      "id_str" : "14389132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797651345524199424\/hhYFpIXH_normal.jpg",
      "id" : 14389132,
      "verified" : false
    }
  },
  "id" : 948288588067889152,
  "created_at" : "2018-01-02 20:23:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "banksy",
      "screen_name" : "thereaIbanksy",
      "indices" : [ 3, 17 ],
      "id_str" : "1542533869",
      "id" : 1542533869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288516676554753",
  "text" : "RT @thereaIbanksy: Confidence is silent. Insecurities are loud.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948247534157357056",
    "text" : "Confidence is silent. Insecurities are loud.",
    "id" : 948247534157357056,
    "created_at" : "2018-01-02 17:40:04 +0000",
    "user" : {
      "name" : "banksy",
      "screen_name" : "thereaIbanksy",
      "protected" : false,
      "id_str" : "1542533869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000643505271\/80c2ea605ed52d7996f4146bf4c7481f_normal.jpeg",
      "id" : 1542533869,
      "verified" : false
    }
  },
  "id" : 948288516676554753,
  "created_at" : "2018-01-02 20:22:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FXStreet News",
      "screen_name" : "FXstreetNews",
      "indices" : [ 3, 16 ],
      "id_str" : "27652717",
      "id" : 27652717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Hup1m4a00R",
      "expanded_url" : "http:\/\/owl.li\/9H6d30hxxNu",
      "display_url" : "owl.li\/9H6d30hxxNu"
    } ]
  },
  "geo" : { },
  "id_str" : "948288483835162624",
  "text" : "RT @FXstreetNews: EUR\/USD: ready to reach fresh multi-year highs https:\/\/t.co\/Hup1m4a00R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/Hup1m4a00R",
        "expanded_url" : "http:\/\/owl.li\/9H6d30hxxNu",
        "display_url" : "owl.li\/9H6d30hxxNu"
      } ]
    },
    "geo" : { },
    "id_str" : "948287623495286784",
    "text" : "EUR\/USD: ready to reach fresh multi-year highs https:\/\/t.co\/Hup1m4a00R",
    "id" : 948287623495286784,
    "created_at" : "2018-01-02 20:19:22 +0000",
    "user" : {
      "name" : "FXStreet News",
      "screen_name" : "FXstreetNews",
      "protected" : false,
      "id_str" : "27652717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900669341171056640\/06pIS4h4_normal.jpg",
      "id" : 27652717,
      "verified" : false
    }
  },
  "id" : 948288483835162624,
  "created_at" : "2018-01-02 20:22:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948288448393342976",
  "text" : "Don't want to, but dealing with so many administrative stuff today",
  "id" : 948288448393342976,
  "created_at" : "2018-01-02 20:22:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948272776409964544",
  "text" : "RT @Snapzu_Earth: Fun Fact: Cat owners are 30% less likely to suffer a heart attack.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948258814389657600",
    "text" : "Fun Fact: Cat owners are 30% less likely to suffer a heart attack.",
    "id" : 948258814389657600,
    "created_at" : "2018-01-02 18:24:53 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948272776409964544,
  "created_at" : "2018-01-02 19:20:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/iGzoDOo1OU",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/simple-website-templates\/",
      "display_url" : "webdesigndev.com\/simple-website\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948272738975780865",
  "text" : "RT @WebDesignDev: 25 Free Simple Website Templates for Easy Websites: https:\/\/t.co\/iGzoDOo1OU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/iGzoDOo1OU",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/simple-website-templates\/",
        "display_url" : "webdesigndev.com\/simple-website\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948256246616018944",
    "text" : "25 Free Simple Website Templates for Easy Websites: https:\/\/t.co\/iGzoDOo1OU",
    "id" : 948256246616018944,
    "created_at" : "2018-01-02 18:14:41 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948272738975780865,
  "created_at" : "2018-01-02 19:20:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 91, 101 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "technology",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/MvFcq1T2A4",
      "expanded_url" : "http:\/\/medx.cc\/434120627",
      "display_url" : "medx.cc\/434120627"
    } ]
  },
  "geo" : { },
  "id_str" : "948272732835405825",
  "text" : "RT @TechXplore_com: A fossil fuel #technology that doesn't pollute https:\/\/t.co\/MvFcq1T2A4 @OhioState",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ohio State",
        "screen_name" : "OhioState",
        "indices" : [ 71, 81 ],
        "id_str" : "18846918",
        "id" : 18846918
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "technology",
        "indices" : [ 14, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/MvFcq1T2A4",
        "expanded_url" : "http:\/\/medx.cc\/434120627",
        "display_url" : "medx.cc\/434120627"
      } ]
    },
    "geo" : { },
    "id_str" : "948253548869021697",
    "text" : "A fossil fuel #technology that doesn't pollute https:\/\/t.co\/MvFcq1T2A4 @OhioState",
    "id" : 948253548869021697,
    "created_at" : "2018-01-02 18:03:58 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 948272732835405825,
  "created_at" : "2018-01-02 19:20:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startups",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "status",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948272632717332481",
  "text" : "Gonna be busy with what I am developing the entire day #startups #status",
  "id" : 948272632717332481,
  "created_at" : "2018-01-02 19:19:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LD6AukpuqO",
      "expanded_url" : "https:\/\/asc.ai\/",
      "display_url" : "asc.ai"
    } ]
  },
  "geo" : { },
  "id_str" : "948268003422015489",
  "text" : "We are a Planetary Network of Change Agents creating decentralized\/ethical alternatives to every product and service https:\/\/t.co\/LD6AukpuqO",
  "id" : 948268003422015489,
  "created_at" : "2018-01-02 19:01:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/pnRTzV5u6e",
      "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/02\/video-sony-a9-made\/",
      "display_url" : "petapixel.com\/2018\/01\/02\/vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948255216570388481",
  "text" : "RT @JayHoque: Video: How the Sony a9 is Made: https:\/\/t.co\/pnRTzV5u6e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/pnRTzV5u6e",
        "expanded_url" : "https:\/\/petapixel.com\/2018\/01\/02\/video-sony-a9-made\/",
        "display_url" : "petapixel.com\/2018\/01\/02\/vid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948254084095725569",
    "text" : "Video: How the Sony a9 is Made: https:\/\/t.co\/pnRTzV5u6e",
    "id" : 948254084095725569,
    "created_at" : "2018-01-02 18:06:06 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 948255216570388481,
  "created_at" : "2018-01-02 18:10:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArtTuesday",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/LP33sKAiGs",
      "expanded_url" : "https:\/\/adafru.it\/Apk",
      "display_url" : "adafru.it\/Apk"
    } ]
  },
  "geo" : { },
  "id_str" : "948255196555161601",
  "text" : "RT @adafruit: Graffiti Artist Spray-Paints Giant Animals onto Plastic Wrap in a Forest #ArtTuesday https:\/\/t.co\/LP33sKAiGs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArtTuesday",
        "indices" : [ 73, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/LP33sKAiGs",
        "expanded_url" : "https:\/\/adafru.it\/Apk",
        "display_url" : "adafru.it\/Apk"
      } ]
    },
    "geo" : { },
    "id_str" : "948252563320733698",
    "text" : "Graffiti Artist Spray-Paints Giant Animals onto Plastic Wrap in a Forest #ArtTuesday https:\/\/t.co\/LP33sKAiGs",
    "id" : 948252563320733698,
    "created_at" : "2018-01-02 18:00:03 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 948255196555161601,
  "created_at" : "2018-01-02 18:10:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/pKHFHXUXWj",
      "expanded_url" : "http:\/\/engt.co\/2DTLUZd",
      "display_url" : "engt.co\/2DTLUZd"
    } ]
  },
  "geo" : { },
  "id_str" : "948255165756387331",
  "text" : "RT @engadget: 'Need for Speed: Payback' to add online free roaming mode https:\/\/t.co\/pKHFHXUXWj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/pKHFHXUXWj",
        "expanded_url" : "http:\/\/engt.co\/2DTLUZd",
        "display_url" : "engt.co\/2DTLUZd"
      } ]
    },
    "geo" : { },
    "id_str" : "948247270901854210",
    "text" : "'Need for Speed: Payback' to add online free roaming mode https:\/\/t.co\/pKHFHXUXWj",
    "id" : 948247270901854210,
    "created_at" : "2018-01-02 17:39:01 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948255165756387331,
  "created_at" : "2018-01-02 18:10:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948255105538813952",
  "text" : "RT @Snapzu_Science: Daily Fact: A new born blue whale measures 20-26 feet (6.0 - 7.9 meters) long and weighs up to 6,614 pounds (3003 kg).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948249401771794432",
    "text" : "Daily Fact: A new born blue whale measures 20-26 feet (6.0 - 7.9 meters) long and weighs up to 6,614 pounds (3003 kg).",
    "id" : 948249401771794432,
    "created_at" : "2018-01-02 17:47:29 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 948255105538813952,
  "created_at" : "2018-01-02 18:10:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/zmFYOMwMTU",
      "expanded_url" : "http:\/\/ift.tt\/2lJDLzk",
      "display_url" : "ift.tt\/2lJDLzk"
    } ]
  },
  "geo" : { },
  "id_str" : "948255042230013952",
  "text" : "RT @dronepilots: Canada's drone racing king doubles as McGill PhD candidate | DronePilots - https:\/\/t.co\/zmFYOMwMTU #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/zmFYOMwMTU",
        "expanded_url" : "http:\/\/ift.tt\/2lJDLzk",
        "display_url" : "ift.tt\/2lJDLzk"
      } ]
    },
    "geo" : { },
    "id_str" : "948253604577759232",
    "text" : "Canada's drone racing king doubles as McGill PhD candidate | DronePilots - https:\/\/t.co\/zmFYOMwMTU #drones",
    "id" : 948253604577759232,
    "created_at" : "2018-01-02 18:04:11 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948255042230013952,
  "created_at" : "2018-01-02 18:09:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/VVErALiJlb",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/shopify-apps\/",
      "display_url" : "webdesigndev.com\/shopify-apps\/"
    } ]
  },
  "geo" : { },
  "id_str" : "948255007916339206",
  "text" : "RT @WebDesignDev: 20 Best Shopify Apps For Boosting Your Online Sales: https:\/\/t.co\/VVErALiJlb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/VVErALiJlb",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/shopify-apps\/",
        "display_url" : "webdesigndev.com\/shopify-apps\/"
      } ]
    },
    "geo" : { },
    "id_str" : "948247912999464961",
    "text" : "20 Best Shopify Apps For Boosting Your Online Sales: https:\/\/t.co\/VVErALiJlb",
    "id" : 948247912999464961,
    "created_at" : "2018-01-02 17:41:34 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948255007916339206,
  "created_at" : "2018-01-02 18:09:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "philosophy",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/ZlKMWmUWrI",
      "expanded_url" : "https:\/\/www.theodysseyonline.com\/dangerous",
      "display_url" : "theodysseyonline.com\/dangerous"
    } ]
  },
  "geo" : { },
  "id_str" : "948254930187575296",
  "text" : "How can we not censor intellectual diversity? #philosophy https:\/\/t.co\/ZlKMWmUWrI",
  "id" : 948254930187575296,
  "created_at" : "2018-01-02 18:09:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948246043283677184",
  "text" : "RT @Snapzu_Earth: Bloggers: Add unparalleled value to your blog with content created, shared &amp; curated by members of your community. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/r9Rm2nyyxC",
        "expanded_url" : "http:\/\/blogenhancement.com\/",
        "display_url" : "blogenhancement.com"
      } ]
    },
    "geo" : { },
    "id_str" : "948231985205362689",
    "text" : "Bloggers: Add unparalleled value to your blog with content created, shared &amp; curated by members of your community. https:\/\/t.co\/r9Rm2nyyxC",
    "id" : 948231985205362689,
    "created_at" : "2018-01-02 16:38:17 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948246043283677184,
  "created_at" : "2018-01-02 17:34:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/n7bOyi6VCT",
      "expanded_url" : "http:\/\/ift.tt\/2lIKCZP",
      "display_url" : "ift.tt\/2lIKCZP"
    } ]
  },
  "geo" : { },
  "id_str" : "948245998278729728",
  "text" : "RT @dronepilots: Watch the drone which interrupted League Two fixture between Yeovil and Crawley | DronePilots - https:\/\/t.co\/n7bOyi6VCT #d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/n7bOyi6VCT",
        "expanded_url" : "http:\/\/ift.tt\/2lIKCZP",
        "display_url" : "ift.tt\/2lIKCZP"
      } ]
    },
    "geo" : { },
    "id_str" : "948242253226696706",
    "text" : "Watch the drone which interrupted League Two fixture between Yeovil and Crawley | DronePilots - https:\/\/t.co\/n7bOyi6VCT #drones",
    "id" : 948242253226696706,
    "created_at" : "2018-01-02 17:19:05 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948245998278729728,
  "created_at" : "2018-01-02 17:33:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Bogart",
      "screen_name" : "CremeDeLaCrypto",
      "indices" : [ 3, 19 ],
      "id_str" : "4826176219",
      "id" : 4826176219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948245887704289281",
  "text" : "RT @CremeDeLaCrypto: Bitcoin's resiliency as #1 crypto makes sense once we understand that solving digital scarcity was 95%+ of the problem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948231356537962496",
    "text" : "Bitcoin's resiliency as #1 crypto makes sense once we understand that solving digital scarcity was 95%+ of the problem",
    "id" : 948231356537962496,
    "created_at" : "2018-01-02 16:35:47 +0000",
    "user" : {
      "name" : "Spencer Bogart",
      "screen_name" : "CremeDeLaCrypto",
      "protected" : false,
      "id_str" : "4826176219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/834130195967729664\/jGvfIE66_normal.jpg",
      "id" : 4826176219,
      "verified" : true
    }
  },
  "id" : 948245887704289281,
  "created_at" : "2018-01-02 17:33:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948245753176231937",
  "text" : "RT @make: We're back in the office after a rejuvenating holiday. How's everyone doing? Anyone work on anything cool over their holiday brea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948240308642504705",
    "text" : "We're back in the office after a rejuvenating holiday. How's everyone doing? Anyone work on anything cool over their holiday break?",
    "id" : 948240308642504705,
    "created_at" : "2018-01-02 17:11:21 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 948245753176231937,
  "created_at" : "2018-01-02 17:32:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 20, 26 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vega",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/R5sNvB1KCh",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/core-i7-8809g-vega-graphics-intel,36202.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/core-i7-8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948245739523715072",
  "text" : "RT @tomshardware: \u25B8 @Intel Lists Overclockable Core i7-8809G With #Vega Graphics https:\/\/t.co\/R5sNvB1KCh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 2, 8 ],
        "id_str" : "2803191",
        "id" : 2803191
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vega",
        "indices" : [ 48, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/R5sNvB1KCh",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/core-i7-8809g-vega-graphics-intel,36202.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/core-i7-8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948226660628774917",
    "text" : "\u25B8 @Intel Lists Overclockable Core i7-8809G With #Vega Graphics https:\/\/t.co\/R5sNvB1KCh",
    "id" : 948226660628774917,
    "created_at" : "2018-01-02 16:17:07 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948245739523715072,
  "created_at" : "2018-01-02 17:32:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948245718426320896\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8Cjvh4tUYC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSjYcUbXcAAHznN.jpg",
      "id_str" : "948245702592917504",
      "id" : 948245702592917504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSjYcUbXcAAHznN.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 952
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1625
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/8Cjvh4tUYC"
    } ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "DIY",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948245718426320896",
  "text" : "Screwed that part in, need to pick up some small brackets later. Not sure I will finish on time. #STEM #DIY https:\/\/t.co\/8Cjvh4tUYC",
  "id" : 948245718426320896,
  "created_at" : "2018-01-02 17:32:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948224454743687168",
  "text" : "RT @lorenridinger: \u201CCourage is the most important of all the virtues because without courage, you can't practice any other virtue consisten\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948223639928934400",
    "text" : "\u201CCourage is the most important of all the virtues because without courage, you can't practice any other virtue consistently.\u201D",
    "id" : 948223639928934400,
    "created_at" : "2018-01-02 16:05:07 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948224454743687168,
  "created_at" : "2018-01-02 16:08:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "AMD",
      "screen_name" : "AMD",
      "indices" : [ 20, 24 ],
      "id_str" : "14861876",
      "id" : 14861876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/2kU8zBX1iU",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/amd-adrenalin-issue-dx9-games,36203.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/amd-adren\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948224416047157249",
  "text" : "RT @tomshardware: \u25B8 @AMD Says It Won\u2019t Fix Driver Issue Breaking DX9 Games https:\/\/t.co\/2kU8zBX1iU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMD",
        "screen_name" : "AMD",
        "indices" : [ 2, 6 ],
        "id_str" : "14861876",
        "id" : 14861876
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2kU8zBX1iU",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/amd-adrenalin-issue-dx9-games,36203.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/amd-adren\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948223128886394880",
    "text" : "\u25B8 @AMD Says It Won\u2019t Fix Driver Issue Breaking DX9 Games https:\/\/t.co\/2kU8zBX1iU",
    "id" : 948223128886394880,
    "created_at" : "2018-01-02 16:03:05 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948224416047157249,
  "created_at" : "2018-01-02 16:08:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948220954236375040",
  "text" : "RT @PhotographyTalk: YouTube user Peter McKinnon took up the task of answering that very question in the video below.\nhttps:\/\/t.co\/o4CK6ebA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/o4CK6ebAhS",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7595-a-1-000-camera-vs-an-8-000-camera",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948220595094908928",
    "text" : "YouTube user Peter McKinnon took up the task of answering that very question in the video below.\nhttps:\/\/t.co\/o4CK6ebAhS",
    "id" : 948220595094908928,
    "created_at" : "2018-01-02 15:53:01 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948220954236375040,
  "created_at" : "2018-01-02 15:54:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/RSZMfag9DQ",
      "expanded_url" : "https:\/\/trib.al\/2T8ePcB",
      "display_url" : "trib.al\/2T8ePcB"
    } ]
  },
  "geo" : { },
  "id_str" : "948217183678685186",
  "text" : "RT @epicurious: Power up! https:\/\/t.co\/RSZMfag9DQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/RSZMfag9DQ",
        "expanded_url" : "https:\/\/trib.al\/2T8ePcB",
        "display_url" : "trib.al\/2T8ePcB"
      } ]
    },
    "geo" : { },
    "id_str" : "948168002419257344",
    "text" : "Power up! https:\/\/t.co\/RSZMfag9DQ",
    "id" : 948168002419257344,
    "created_at" : "2018-01-02 12:24:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948217183678685186,
  "created_at" : "2018-01-02 15:39:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "Plextor USA",
      "screen_name" : "PlextorUSA",
      "indices" : [ 20, 31 ],
      "id_str" : "41693638",
      "id" : 41693638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SSD",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/9s5cMXlPWI",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/plextor-m9pe-ssd-review,5408.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/plexto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948216923904532480",
  "text" : "RT @tomshardware: \u25B8 @PlextorUSA M9Pe #SSD Review https:\/\/t.co\/9s5cMXlPWI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Plextor USA",
        "screen_name" : "PlextorUSA",
        "indices" : [ 2, 13 ],
        "id_str" : "41693638",
        "id" : 41693638
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SSD",
        "indices" : [ 19, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/9s5cMXlPWI",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/plextor-m9pe-ssd-review,5408.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/plexto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948079425093898240",
    "text" : "\u25B8 @PlextorUSA M9Pe #SSD Review https:\/\/t.co\/9s5cMXlPWI",
    "id" : 948079425093898240,
    "created_at" : "2018-01-02 06:32:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 948216923904532480,
  "created_at" : "2018-01-02 15:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/x3F8sJW1Vh",
      "expanded_url" : "http:\/\/ift.tt\/2lDmloP",
      "display_url" : "ift.tt\/2lDmloP"
    } ]
  },
  "geo" : { },
  "id_str" : "948216639346167808",
  "text" : "RT @dronepilots: COPTRZ Launch Groundbreaking Drone Leasing Solution | DronePilots - https:\/\/t.co\/x3F8sJW1Vh #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/x3F8sJW1Vh",
        "expanded_url" : "http:\/\/ift.tt\/2lDmloP",
        "display_url" : "ift.tt\/2lDmloP"
      } ]
    },
    "geo" : { },
    "id_str" : "948213486403940353",
    "text" : "COPTRZ Launch Groundbreaking Drone Leasing Solution | DronePilots - https:\/\/t.co\/x3F8sJW1Vh #drones",
    "id" : 948213486403940353,
    "created_at" : "2018-01-02 15:24:46 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948216639346167808,
  "created_at" : "2018-01-02 15:37:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948216531728642051",
  "text" : "RT @dronepilots: Meet Evolve, the World\u2019s First Carbon Fiber Drone With Dual Screen Drone Controller | DronePilots - https:\/\/t.co\/lPJSFx3gK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/lPJSFx3gKf",
        "expanded_url" : "http:\/\/ift.tt\/2CEYAnK",
        "display_url" : "ift.tt\/2CEYAnK"
      } ]
    },
    "geo" : { },
    "id_str" : "948203421265485824",
    "text" : "Meet Evolve, the World\u2019s First Carbon Fiber Drone With Dual Screen Drone Controller | DronePilots - https:\/\/t.co\/lPJSFx3gKf #drones",
    "id" : 948203421265485824,
    "created_at" : "2018-01-02 14:44:47 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948216531728642051,
  "created_at" : "2018-01-02 15:36:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/fpCPmKH6uj",
      "expanded_url" : "http:\/\/engt.co\/2DQbxdu",
      "display_url" : "engt.co\/2DQbxdu"
    } ]
  },
  "geo" : { },
  "id_str" : "948216270121570305",
  "text" : "RT @engadget: Fans make 80 new levels for 'New Super Mario Bros.' https:\/\/t.co\/fpCPmKH6uj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/fpCPmKH6uj",
        "expanded_url" : "http:\/\/engt.co\/2DQbxdu",
        "display_url" : "engt.co\/2DQbxdu"
      } ]
    },
    "geo" : { },
    "id_str" : "948201146585436165",
    "text" : "Fans make 80 new levels for 'New Super Mario Bros.' https:\/\/t.co\/fpCPmKH6uj",
    "id" : 948201146585436165,
    "created_at" : "2018-01-02 14:35:44 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948216270121570305,
  "created_at" : "2018-01-02 15:35:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/HHxFg9UmZV",
      "expanded_url" : "https:\/\/buff.ly\/2kFr4px",
      "display_url" : "buff.ly\/2kFr4px"
    } ]
  },
  "geo" : { },
  "id_str" : "948216234264420352",
  "text" : "RT @analyticbridge: Making data science accessible \uFFFD Logistic Regression  https:\/\/t.co\/HHxFg9UmZV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/HHxFg9UmZV",
        "expanded_url" : "https:\/\/buff.ly\/2kFr4px",
        "display_url" : "buff.ly\/2kFr4px"
      } ]
    },
    "geo" : { },
    "id_str" : "948212795321053184",
    "text" : "Making data science accessible \uFFFD Logistic Regression  https:\/\/t.co\/HHxFg9UmZV",
    "id" : 948212795321053184,
    "created_at" : "2018-01-02 15:22:02 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948216234264420352,
  "created_at" : "2018-01-02 15:35:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/6RkCOnKize",
      "expanded_url" : "http:\/\/ow.ly\/DsfG30fjCl8",
      "display_url" : "ow.ly\/DsfG30fjCl8"
    } ]
  },
  "geo" : { },
  "id_str" : "948216171001729025",
  "text" : "RT @StartupDailyANZ: Melbourne startup Farmwall supplies vertical gardens to cafes and restaurants: https:\/\/t.co\/6RkCOnKize",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/6RkCOnKize",
        "expanded_url" : "http:\/\/ow.ly\/DsfG30fjCl8",
        "display_url" : "ow.ly\/DsfG30fjCl8"
      } ]
    },
    "geo" : { },
    "id_str" : "948207261268054023",
    "text" : "Melbourne startup Farmwall supplies vertical gardens to cafes and restaurants: https:\/\/t.co\/6RkCOnKize",
    "id" : 948207261268054023,
    "created_at" : "2018-01-02 15:00:02 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948216171001729025,
  "created_at" : "2018-01-02 15:35:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948216077288341504",
  "text" : "RT @copticworld: Christians killed in horrific New Year attack - Egypt on alert TWO CHRISTIANS were killed in a deadly attack today.: The t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/copticworld\/status\/948204757851676673\/photo\/1",
        "indices" : [ 276, 299 ],
        "url" : "https:\/\/t.co\/twXainxCDB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DSizM2QV4AEJpqK.jpg",
        "id_str" : "948204754865348609",
        "id" : 948204754865348609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSizM2QV4AEJpqK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/twXainxCDB"
      } ],
      "hashtags" : [ {
        "text" : "CopticWorld",
        "indices" : [ 255, 267 ]
      }, {
        "text" : "coptic",
        "indices" : [ 268, 275 ]
      } ],
      "urls" : [ {
        "indices" : [ 231, 254 ],
        "url" : "https:\/\/t.co\/0ytNuJA5Rh",
        "expanded_url" : "http:\/\/dlvr.it\/Q8YjnT",
        "display_url" : "dlvr.it\/Q8YjnT"
      } ]
    },
    "geo" : { },
    "id_str" : "948204757851676673",
    "text" : "Christians killed in horrific New Year attack - Egypt on alert TWO CHRISTIANS were killed in a deadly attack today.: The two men, who were brothers, were attacked by a masked gunman.\u00A0 The killer shot the men at their alcohol shop\u2026 https:\/\/t.co\/0ytNuJA5Rh #CopticWorld #coptic https:\/\/t.co\/twXainxCDB",
    "id" : 948204757851676673,
    "created_at" : "2018-01-02 14:50:05 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 948216077288341504,
  "created_at" : "2018-01-02 15:35:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/v7TITppPcL",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/vintage-typography-projects\/",
      "display_url" : "webdesigndev.com\/vintage-typogr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948193261323202565",
  "text" : "RT @WebDesignDev: 25 Vintage Typography Projects Worth Bookmarking: https:\/\/t.co\/v7TITppPcL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/v7TITppPcL",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/vintage-typography-projects\/",
        "display_url" : "webdesigndev.com\/vintage-typogr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948130140554387462",
    "text" : "25 Vintage Typography Projects Worth Bookmarking: https:\/\/t.co\/v7TITppPcL",
    "id" : 948130140554387462,
    "created_at" : "2018-01-02 09:53:35 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948193261323202565,
  "created_at" : "2018-01-02 14:04:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFacts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948126853507813376",
  "text" : "RT @OMGFacts: Alaska is simultaneously the most northern, the most western, and the most eastern state in the U.S.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947966415998504960",
    "text" : "Alaska is simultaneously the most northern, the most western, and the most eastern state in the U.S.",
    "id" : 947966415998504960,
    "created_at" : "2018-01-01 23:03:00 +0000",
    "user" : {
      "name" : "OMGFacts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 948126853507813376,
  "created_at" : "2018-01-02 09:40:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments_",
      "indices" : [ 3, 16 ],
      "id_str" : "1870241503",
      "id" : 1870241503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948126751921713152",
  "text" : "RT @Zen_Moments_: I'm not afraid of storms, for I'm learning how to sail my ship. ~ Louisa May Alcott",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.kucukbeyin.com\/\" rel=\"nofollow\"\u003Efldl\u00F6adlf\u00F6palsdfpasd\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947914128655618048",
    "text" : "I'm not afraid of storms, for I'm learning how to sail my ship. ~ Louisa May Alcott",
    "id" : 947914128655618048,
    "created_at" : "2018-01-01 19:35:14 +0000",
    "user" : {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments_",
      "protected" : false,
      "id_str" : "1870241503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475045128730468353\/6LkJbrmp_normal.png",
      "id" : 1870241503,
      "verified" : false
    }
  },
  "id" : 948126751921713152,
  "created_at" : "2018-01-02 09:40:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin J. Ryan",
      "screen_name" : "wheresKR",
      "indices" : [ 3, 12 ],
      "id_str" : "21989875",
      "id" : 21989875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948126160319401989",
  "text" : "RT @wheresKR: Yeah this game is amazing but if you didn\u2019t watch Jeopardy tonight you missed Trebek inform a contestant that his previous re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948010203869532160",
    "text" : "Yeah this game is amazing but if you didn\u2019t watch Jeopardy tonight you missed Trebek inform a contestant that his previous response of \u201CGangster\u2019s Paradise\u201D was incorrect and it should be pronounced \u201Cgangsta.\u201D",
    "id" : 948010203869532160,
    "created_at" : "2018-01-02 01:57:00 +0000",
    "user" : {
      "name" : "Kevin J. Ryan",
      "screen_name" : "wheresKR",
      "protected" : false,
      "id_str" : "21989875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505592535793041408\/8mdwK7Uv_normal.jpeg",
      "id" : 21989875,
      "verified" : true
    }
  },
  "id" : 948126160319401989,
  "created_at" : "2018-01-02 09:37:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "indices" : [ 3, 7 ],
      "id_str" : "16896485",
      "id" : 16896485
    }, {
      "name" : "Kevin J. Ryan",
      "screen_name" : "wheresKR",
      "indices" : [ 56, 65 ],
      "id_str" : "21989875",
      "id" : 21989875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/HBG8mI3jP5",
      "expanded_url" : "http:\/\/on.inc.com\/2zQF4Bj",
      "display_url" : "on.inc.com\/2zQF4Bj"
    } ]
  },
  "geo" : { },
  "id_str" : "948126085253701632",
  "text" : "RT @Inc: 15 Offices That Will Make You Insanely Jealous @wheresKR https:\/\/t.co\/HBG8mI3jP5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin J. Ryan",
        "screen_name" : "wheresKR",
        "indices" : [ 47, 56 ],
        "id_str" : "21989875",
        "id" : 21989875
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/HBG8mI3jP5",
        "expanded_url" : "http:\/\/on.inc.com\/2zQF4Bj",
        "display_url" : "on.inc.com\/2zQF4Bj"
      } ]
    },
    "geo" : { },
    "id_str" : "948100512007753728",
    "text" : "15 Offices That Will Make You Insanely Jealous @wheresKR https:\/\/t.co\/HBG8mI3jP5",
    "id" : 948100512007753728,
    "created_at" : "2018-01-02 07:55:51 +0000",
    "user" : {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "protected" : false,
      "id_str" : "16896485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794517026672967680\/M4bp9e6f_normal.jpg",
      "id" : 16896485,
      "verified" : true
    }
  },
  "id" : 948126085253701632,
  "created_at" : "2018-01-02 09:37:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/dojmDsEcsR",
      "expanded_url" : "http:\/\/ow.ly\/yV2G30hsGF0",
      "display_url" : "ow.ly\/yV2G30hsGF0"
    } ]
  },
  "geo" : { },
  "id_str" : "948125422566494208",
  "text" : "RT @analyticbridge: Free Book: SQL Essentials https:\/\/t.co\/dojmDsEcsR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/dojmDsEcsR",
        "expanded_url" : "http:\/\/ow.ly\/yV2G30hsGF0",
        "display_url" : "ow.ly\/yV2G30hsGF0"
      } ]
    },
    "geo" : { },
    "id_str" : "948116837061054464",
    "text" : "Free Book: SQL Essentials https:\/\/t.co\/dojmDsEcsR",
    "id" : 948116837061054464,
    "created_at" : "2018-01-02 09:00:43 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948125422566494208,
  "created_at" : "2018-01-02 09:34:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ultimaker",
      "screen_name" : "Ultimaker",
      "indices" : [ 3, 13 ],
      "id_str" : "181111601",
      "id" : 181111601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PLOljpgEmK",
      "expanded_url" : "http:\/\/ultim.kr\/2ATgwML",
      "display_url" : "ultim.kr\/2ATgwML"
    } ]
  },
  "geo" : { },
  "id_str" : "948125082177687552",
  "text" : "RT @Ultimaker: Last month, we released a new Breakaway support material and a 0.25 mm AA print core! Check them out: https:\/\/t.co\/PLOljpgEmK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/PLOljpgEmK",
        "expanded_url" : "http:\/\/ultim.kr\/2ATgwML",
        "display_url" : "ultim.kr\/2ATgwML"
      } ]
    },
    "geo" : { },
    "id_str" : "948117917434081280",
    "text" : "Last month, we released a new Breakaway support material and a 0.25 mm AA print core! Check them out: https:\/\/t.co\/PLOljpgEmK",
    "id" : 948117917434081280,
    "created_at" : "2018-01-02 09:05:01 +0000",
    "user" : {
      "name" : "Ultimaker",
      "screen_name" : "Ultimaker",
      "protected" : false,
      "id_str" : "181111601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785883430332534784\/09W2LPjg_normal.jpg",
      "id" : 181111601,
      "verified" : true
    }
  },
  "id" : 948125082177687552,
  "created_at" : "2018-01-02 09:33:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948124979979325440",
  "text" : "RT @lorenridinger: \u201CI think a role model is a mentor \u2013 someone you see on a daily basis, and you learn from them.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948116849153146880",
    "text" : "\u201CI think a role model is a mentor \u2013 someone you see on a daily basis, and you learn from them.\u201D",
    "id" : 948116849153146880,
    "created_at" : "2018-01-02 09:00:46 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 948124979979325440,
  "created_at" : "2018-01-02 09:33:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Z. Nardi",
      "screen_name" : "objthinker",
      "indices" : [ 3, 14 ],
      "id_str" : "725754026894184448",
      "id" : 725754026894184448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948124888241508352",
  "text" : "RT @objthinker: \"No man has a good enough memory to be a successful liar.\" -Abraham Lincoln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947901252742144000",
    "text" : "\"No man has a good enough memory to be a successful liar.\" -Abraham Lincoln",
    "id" : 947901252742144000,
    "created_at" : "2018-01-01 18:44:04 +0000",
    "user" : {
      "name" : "William Z. Nardi",
      "screen_name" : "objthinker",
      "protected" : false,
      "id_str" : "725754026894184448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947640121561624576\/Auwp96gr_normal.jpg",
      "id" : 725754026894184448,
      "verified" : false
    }
  },
  "id" : 948124888241508352,
  "created_at" : "2018-01-02 09:32:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948124796134490113",
  "text" : "Just wrote another Odyssey article, thinking about calling it a day. However, on the other hand ...",
  "id" : 948124796134490113,
  "created_at" : "2018-01-02 09:32:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "indices" : [ 3, 19 ],
      "id_str" : "406083970",
      "id" : 406083970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BiuWSvQzT8",
      "expanded_url" : "http:\/\/ow.ly\/MbPo30ezZlo",
      "display_url" : "ow.ly\/MbPo30ezZlo"
    } ]
  },
  "geo" : { },
  "id_str" : "948116927406313474",
  "text" : "RT @StartupDailyANZ: Creatively Squared matches businesses to creatives to develop custom visual content: https:\/\/t.co\/BiuWSvQzT8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/BiuWSvQzT8",
        "expanded_url" : "http:\/\/ow.ly\/MbPo30ezZlo",
        "display_url" : "ow.ly\/MbPo30ezZlo"
      } ]
    },
    "geo" : { },
    "id_str" : "948116655393079296",
    "text" : "Creatively Squared matches businesses to creatives to develop custom visual content: https:\/\/t.co\/BiuWSvQzT8",
    "id" : 948116655393079296,
    "created_at" : "2018-01-02 09:00:00 +0000",
    "user" : {
      "name" : "STARTUP DAILY",
      "screen_name" : "StartupDailyANZ",
      "protected" : false,
      "id_str" : "406083970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883201629700345856\/6oZN2qOm_normal.jpg",
      "id" : 406083970,
      "verified" : true
    }
  },
  "id" : 948116927406313474,
  "created_at" : "2018-01-02 09:01:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Lloyd George",
      "screen_name" : "AMLG23",
      "indices" : [ 3, 10 ],
      "id_str" : "111267377",
      "id" : 111267377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948116552469172224",
  "text" : "RT @AMLG23: Polling the internets - who are your favourite satirist writers or journalists of the last 100 years ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "946412762984603654",
    "text" : "Polling the internets - who are your favourite satirist writers or journalists of the last 100 years ?",
    "id" : 946412762984603654,
    "created_at" : "2017-12-28 16:09:20 +0000",
    "user" : {
      "name" : "Alice Lloyd George",
      "screen_name" : "AMLG23",
      "protected" : false,
      "id_str" : "111267377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874420194860576769\/CR_2BN8b_normal.jpg",
      "id" : 111267377,
      "verified" : false
    }
  },
  "id" : 948116552469172224,
  "created_at" : "2018-01-02 08:59:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/L6tppQe0DY",
      "expanded_url" : "http:\/\/tcrn.ch\/2CyHQOB",
      "display_url" : "tcrn.ch\/2CyHQOB"
    } ]
  },
  "geo" : { },
  "id_str" : "948116443081728000",
  "text" : "RT @TechCrunch: Hardware is hard https:\/\/t.co\/L6tppQe0DY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/L6tppQe0DY",
        "expanded_url" : "http:\/\/tcrn.ch\/2CyHQOB",
        "display_url" : "tcrn.ch\/2CyHQOB"
      } ]
    },
    "geo" : { },
    "id_str" : "947985055196045312",
    "text" : "Hardware is hard https:\/\/t.co\/L6tppQe0DY",
    "id" : 947985055196045312,
    "created_at" : "2018-01-02 00:17:04 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879359733936701440\/sitcq7wY_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 948116443081728000,
  "created_at" : "2018-01-02 08:59:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trees",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948116097546539008",
  "text" : "RT @Snapzu_Earth: Knowing #trees, I understand the meaning of patience. Knowing grass, I can appreciate persistence. - Hal Borland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trees",
        "indices" : [ 8, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948114757931769856",
    "text" : "Knowing #trees, I understand the meaning of patience. Knowing grass, I can appreciate persistence. - Hal Borland",
    "id" : 948114757931769856,
    "created_at" : "2018-01-02 08:52:28 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948116097546539008,
  "created_at" : "2018-01-02 08:57:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948115995817926656",
  "text" : "I used to admire Jim Cramer until his comments regarding cryptocurrency. There seems to be potential that he missed out on the biggest financial revolution of the past decade.",
  "id" : 948115995817926656,
  "created_at" : "2018-01-02 08:57:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948114279600881664",
  "text" : "RT @garyvee: 2018 is in trouble ... in the best way possible ... so excited",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947855085643681792",
    "text" : "2018 is in trouble ... in the best way possible ... so excited",
    "id" : 947855085643681792,
    "created_at" : "2018-01-01 15:40:37 +0000",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839672994159013894\/ndVV3x8D_normal.jpg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 948114279600881664,
  "created_at" : "2018-01-02 08:50:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "indices" : [ 3, 9 ],
      "id_str" : "3819701",
      "id" : 3819701
    }, {
      "name" : "Eileen Brown",
      "screen_name" : "eileenb",
      "indices" : [ 119, 127 ],
      "id_str" : "3348461",
      "id" : 3348461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/bjwtazH31p",
      "expanded_url" : "http:\/\/zd.net\/2eWfrXW",
      "display_url" : "zd.net\/2eWfrXW"
    } ]
  },
  "geo" : { },
  "id_str" : "948108772848881664",
  "text" : "RT @ZDNet: ReSpeaker releases its 4-microphone Raspberry Pi software for voice applications https:\/\/t.co\/bjwtazH31p by @eileenb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.zdnet.com\" rel=\"nofollow\"\u003Ezdnet API\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eileen Brown",
        "screen_name" : "eileenb",
        "indices" : [ 108, 116 ],
        "id_str" : "3348461",
        "id" : 3348461
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/bjwtazH31p",
        "expanded_url" : "http:\/\/zd.net\/2eWfrXW",
        "display_url" : "zd.net\/2eWfrXW"
      } ]
    },
    "geo" : { },
    "id_str" : "908067007542714368",
    "text" : "ReSpeaker releases its 4-microphone Raspberry Pi software for voice applications https:\/\/t.co\/bjwtazH31p by @eileenb",
    "id" : 908067007542714368,
    "created_at" : "2017-09-13 20:37:00 +0000",
    "user" : {
      "name" : "ZDNet",
      "screen_name" : "ZDNet",
      "protected" : false,
      "id_str" : "3819701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706961982545473536\/Ibj46-DX_normal.jpg",
      "id" : 3819701,
      "verified" : true
    }
  },
  "id" : 948108772848881664,
  "created_at" : "2018-01-02 08:28:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6oFIFFTeej",
      "expanded_url" : "http:\/\/depot.ly\/9ake30hpIkz",
      "display_url" : "depot.ly\/9ake30hpIkz"
    } ]
  },
  "geo" : { },
  "id_str" : "948108445416349696",
  "text" : "RT @DesignerDepot: Spilling accidents with happy endings imagined by Joe Suzuki https:\/\/t.co\/6oFIFFTeej",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/6oFIFFTeej",
        "expanded_url" : "http:\/\/depot.ly\/9ake30hpIkz",
        "display_url" : "depot.ly\/9ake30hpIkz"
      } ]
    },
    "geo" : { },
    "id_str" : "945028878896128002",
    "text" : "Spilling accidents with happy endings imagined by Joe Suzuki https:\/\/t.co\/6oFIFFTeej",
    "id" : 945028878896128002,
    "created_at" : "2017-12-24 20:30:17 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938857270888112128\/fueDq6et_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 948108445416349696,
  "created_at" : "2018-01-02 08:27:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xJmdslRUUa",
      "expanded_url" : "http:\/\/engt.co\/2DGJMnN",
      "display_url" : "engt.co\/2DGJMnN"
    } ]
  },
  "geo" : { },
  "id_str" : "948106236616216576",
  "text" : "RT @engadget: 'PUBG' is quietly changing video games with its 3D replay technology https:\/\/t.co\/xJmdslRUUa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/xJmdslRUUa",
        "expanded_url" : "http:\/\/engt.co\/2DGJMnN",
        "display_url" : "engt.co\/2DGJMnN"
      } ]
    },
    "geo" : { },
    "id_str" : "947868799319138304",
    "text" : "'PUBG' is quietly changing video games with its 3D replay technology https:\/\/t.co\/xJmdslRUUa",
    "id" : 947868799319138304,
    "created_at" : "2018-01-01 16:35:06 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948106236616216576,
  "created_at" : "2018-01-02 08:18:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/zEidiWooHO",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/image-hover-effects-made-with-css3\/",
      "display_url" : "webdesigndev.com\/image-hover-ef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948105622372999168",
  "text" : "RT @WebDesignDev: 36 Image Hover Effects Made with CSS3: https:\/\/t.co\/zEidiWooHO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/zEidiWooHO",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/image-hover-effects-made-with-css3\/",
        "display_url" : "webdesigndev.com\/image-hover-ef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948103969112576000",
    "text" : "36 Image Hover Effects Made with CSS3: https:\/\/t.co\/zEidiWooHO",
    "id" : 948103969112576000,
    "created_at" : "2018-01-02 08:09:35 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948105622372999168,
  "created_at" : "2018-01-02 08:16:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cardano Foundation",
      "screen_name" : "CardanoStiftung",
      "indices" : [ 3, 19 ],
      "id_str" : "4135644558",
      "id" : 4135644558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948105300812410880",
  "text" : "RT @CardanoStiftung: IOHK's weekly Cardano technical report has been released! Due to holiday season the report is shorter than normal. Che\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/ziIGxQiL8r",
        "expanded_url" : "https:\/\/www.cardanohub.org\/en\/weekly-technical-report\/#12-28-2017",
        "display_url" : "cardanohub.org\/en\/weekly-tech\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "946342212652105728",
    "text" : "IOHK's weekly Cardano technical report has been released! Due to holiday season the report is shorter than normal. Check it out here: https:\/\/t.co\/ziIGxQiL8r",
    "id" : 946342212652105728,
    "created_at" : "2017-12-28 11:29:00 +0000",
    "user" : {
      "name" : "Cardano Foundation",
      "screen_name" : "CardanoStiftung",
      "protected" : false,
      "id_str" : "4135644558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880103086735446016\/ZE8LxNBf_normal.jpg",
      "id" : 4135644558,
      "verified" : false
    }
  },
  "id" : 948105300812410880,
  "created_at" : "2018-01-02 08:14:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sia Tech",
      "screen_name" : "SiaTechHQ",
      "indices" : [ 3, 13 ],
      "id_str" : "3351041295",
      "id" : 3351041295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/1jkv6d167h",
      "expanded_url" : "https:\/\/blog.sia.tech\/sia-community-update-four-f274b99fca89",
      "display_url" : "blog.sia.tech\/sia-community-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948103886270844928",
  "text" : "RT @SiaTechHQ: Here's the final Community Update from 2017! It was an incredible year for Sia, and we owe it to you. https:\/\/t.co\/1jkv6d167h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/1jkv6d167h",
        "expanded_url" : "https:\/\/blog.sia.tech\/sia-community-update-four-f274b99fca89",
        "display_url" : "blog.sia.tech\/sia-community-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947929350363582468",
    "text" : "Here's the final Community Update from 2017! It was an incredible year for Sia, and we owe it to you. https:\/\/t.co\/1jkv6d167h",
    "id" : 947929350363582468,
    "created_at" : "2018-01-01 20:35:43 +0000",
    "user" : {
      "name" : "Sia Tech",
      "screen_name" : "SiaTechHQ",
      "protected" : false,
      "id_str" : "3351041295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878236359726465024\/xWPF_AWk_normal.jpg",
      "id" : 3351041295,
      "verified" : false
    }
  },
  "id" : 948103886270844928,
  "created_at" : "2018-01-02 08:09:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herts Fire Control",
      "screen_name" : "HertsFRSControl",
      "indices" : [ 3, 19 ],
      "id_str" : "574646646",
      "id" : 574646646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948103605994827776",
  "text" : "RT @HertsFRSControl: Good morning - Blue Watch are back on duty for our first shift of 2018. Happy New Year.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948102669599674369",
    "text" : "Good morning - Blue Watch are back on duty for our first shift of 2018. Happy New Year.",
    "id" : 948102669599674369,
    "created_at" : "2018-01-02 08:04:25 +0000",
    "user" : {
      "name" : "Herts Fire Control",
      "screen_name" : "HertsFRSControl",
      "protected" : false,
      "id_str" : "574646646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904681861384998912\/oRaphIVd_normal.jpg",
      "id" : 574646646,
      "verified" : true
    }
  },
  "id" : 948103605994827776,
  "created_at" : "2018-01-02 08:08:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sparkle Labs",
      "screen_name" : "sparklelabs",
      "indices" : [ 3, 15 ],
      "id_str" : "46385237",
      "id" : 46385237
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/FlIOWcKw5p",
      "expanded_url" : "https:\/\/vimeo.com\/224506974",
      "display_url" : "vimeo.com\/224506974"
    } ]
  },
  "geo" : { },
  "id_str" : "948103317057605637",
  "text" : "RT @sparklelabs: I just uploaded \u201CPapertronics Lunar Modules Tutorial\u201D to #Vimeo: https:\/\/t.co\/FlIOWcKw5p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/vimeo.com\" rel=\"nofollow\"\u003EVimeo\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vimeo",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/FlIOWcKw5p",
        "expanded_url" : "https:\/\/vimeo.com\/224506974",
        "display_url" : "vimeo.com\/224506974"
      } ]
    },
    "geo" : { },
    "id_str" : "883061572087709698",
    "text" : "I just uploaded \u201CPapertronics Lunar Modules Tutorial\u201D to #Vimeo: https:\/\/t.co\/FlIOWcKw5p",
    "id" : 883061572087709698,
    "created_at" : "2017-07-06 20:34:19 +0000",
    "user" : {
      "name" : "Sparkle Labs",
      "screen_name" : "sparklelabs",
      "protected" : false,
      "id_str" : "46385237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/280336100\/avatar_normal.gif",
      "id" : 46385237,
      "verified" : false
    }
  },
  "id" : 948103317057605637,
  "created_at" : "2018-01-02 08:07:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNP tutorials",
      "screen_name" : "PNPtutorials",
      "indices" : [ 3, 16 ],
      "id_str" : "724249140733968384",
      "id" : 724249140733968384
    }, {
      "name" : "Seeed",
      "screen_name" : "seeedstudio",
      "indices" : [ 71, 83 ],
      "id_str" : "28542415",
      "id" : 28542415
    }, {
      "name" : "\u674E\u9042\u5FD7 Molly",
      "screen_name" : "Mollyli1993",
      "indices" : [ 109, 121 ],
      "id_str" : "713246918042759168",
      "id" : 713246918042759168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/rWzsio1PzF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wrdUBSsiHVU",
      "display_url" : "youtube.com\/watch?v=wrdUBS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948103068146651136",
  "text" : "RT @PNPtutorials: Review and unboxing of Raspberry Pi zero W Kits from @seeedstudio \nhttps:\/\/t.co\/rWzsio1PzF @Mollyli1993",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seeed",
        "screen_name" : "seeedstudio",
        "indices" : [ 53, 65 ],
        "id_str" : "28542415",
        "id" : 28542415
      }, {
        "name" : "\u674E\u9042\u5FD7 Molly",
        "screen_name" : "Mollyli1993",
        "indices" : [ 91, 103 ],
        "id_str" : "713246918042759168",
        "id" : 713246918042759168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/rWzsio1PzF",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wrdUBSsiHVU",
        "display_url" : "youtube.com\/watch?v=wrdUBS\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "942378218480328705",
    "text" : "Review and unboxing of Raspberry Pi zero W Kits from @seeedstudio \nhttps:\/\/t.co\/rWzsio1PzF @Mollyli1993",
    "id" : 942378218480328705,
    "created_at" : "2017-12-17 12:57:30 +0000",
    "user" : {
      "name" : "PNP tutorials",
      "screen_name" : "PNPtutorials",
      "protected" : false,
      "id_str" : "724249140733968384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724250723311980545\/X6SHPYoa_normal.jpg",
      "id" : 724249140733968384,
      "verified" : false
    }
  },
  "id" : 948103068146651136,
  "created_at" : "2018-01-02 08:06:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESP32",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/dSe6bAp6QP",
      "expanded_url" : "http:\/\/bit.ly\/2leOG4x",
      "display_url" : "bit.ly\/2leOG4x"
    } ]
  },
  "geo" : { },
  "id_str" : "948103003952828416",
  "text" : "RT @sparkfun: How to watch video by turning an oscilloscope into a vector display with an #ESP32. https:\/\/t.co\/dSe6bAp6QP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESP32",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/dSe6bAp6QP",
        "expanded_url" : "http:\/\/bit.ly\/2leOG4x",
        "display_url" : "bit.ly\/2leOG4x"
      } ]
    },
    "geo" : { },
    "id_str" : "946804257168199680",
    "text" : "How to watch video by turning an oscilloscope into a vector display with an #ESP32. https:\/\/t.co\/dSe6bAp6QP",
    "id" : 946804257168199680,
    "created_at" : "2017-12-29 18:05:00 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 948103003952828416,
  "created_at" : "2018-01-02 08:05:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/EUdfk7fzFc",
      "expanded_url" : "https:\/\/adafru.it\/Ap5",
      "display_url" : "adafru.it\/Ap5"
    } ]
  },
  "geo" : { },
  "id_str" : "948102718878568448",
  "text" : "RT @adafruit: DotStar Clock https:\/\/t.co\/EUdfk7fzFc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/EUdfk7fzFc",
        "expanded_url" : "https:\/\/adafru.it\/Ap5",
        "display_url" : "adafru.it\/Ap5"
      } ]
    },
    "geo" : { },
    "id_str" : "948071574422392832",
    "text" : "DotStar Clock https:\/\/t.co\/EUdfk7fzFc",
    "id" : 948071574422392832,
    "created_at" : "2018-01-02 06:00:52 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 948102718878568448,
  "created_at" : "2018-01-02 08:04:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alejandro Odreman",
      "screen_name" : "aodremanm",
      "indices" : [ 3, 13 ],
      "id_str" : "21313695",
      "id" : 21313695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webdev",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "webdevelopment",
      "indices" : [ 41, 56 ]
    }, {
      "text" : "reactjs",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "javascript",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ymPH7JNYqc",
      "expanded_url" : "http:\/\/flip.it\/d4q4GY",
      "display_url" : "flip.it\/d4q4GY"
    } ]
  },
  "geo" : { },
  "id_str" : "948101953812353024",
  "text" : "RT @aodremanm: 11 React Examples #webdev #webdevelopment #reactjs #javascript https:\/\/t.co\/ymPH7JNYqc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webdev",
        "indices" : [ 18, 25 ]
      }, {
        "text" : "webdevelopment",
        "indices" : [ 26, 41 ]
      }, {
        "text" : "reactjs",
        "indices" : [ 42, 50 ]
      }, {
        "text" : "javascript",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/ymPH7JNYqc",
        "expanded_url" : "http:\/\/flip.it\/d4q4GY",
        "display_url" : "flip.it\/d4q4GY"
      } ]
    },
    "geo" : { },
    "id_str" : "947890487683440641",
    "text" : "11 React Examples #webdev #webdevelopment #reactjs #javascript https:\/\/t.co\/ymPH7JNYqc",
    "id" : 947890487683440641,
    "created_at" : "2018-01-01 18:01:17 +0000",
    "user" : {
      "name" : "Alejandro Odreman",
      "screen_name" : "aodremanm",
      "protected" : false,
      "id_str" : "21313695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712001828552974338\/X0FS6cza_normal.jpg",
      "id" : 21313695,
      "verified" : false
    }
  },
  "id" : 948101953812353024,
  "created_at" : "2018-01-02 08:01:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyJsPackages",
      "screen_name" : "dailyJsPackages",
      "indices" : [ 3, 19 ],
      "id_str" : "716875123895046146",
      "id" : 716875123895046146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "npm",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "javascript",
      "indices" : [ 121, 132 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/9llUBJS313",
      "expanded_url" : "http:\/\/dailyjspackages.com\/pkg\/redux-saga-websocket",
      "display_url" : "dailyjspackages.com\/pkg\/redux-saga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948101551381467136",
  "text" : "RT @dailyJsPackages: redux-saga-websocket - websocket for redux and redux-saga, which c... https:\/\/t.co\/9llUBJS313  #npm #javascript #nodejs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dailyjspackages.com\" rel=\"nofollow\"\u003EdailyJsPackages\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "npm",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "javascript",
        "indices" : [ 100, 111 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/9llUBJS313",
        "expanded_url" : "http:\/\/dailyjspackages.com\/pkg\/redux-saga-websocket",
        "display_url" : "dailyjspackages.com\/pkg\/redux-saga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948096438109687808",
    "text" : "redux-saga-websocket - websocket for redux and redux-saga, which c... https:\/\/t.co\/9llUBJS313  #npm #javascript #nodejs",
    "id" : 948096438109687808,
    "created_at" : "2018-01-02 07:39:40 +0000",
    "user" : {
      "name" : "dailyJsPackages",
      "screen_name" : "dailyJsPackages",
      "protected" : false,
      "id_str" : "716875123895046146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737459039865446402\/5_Lm25ol_normal.jpg",
      "id" : 716875123895046146,
      "verified" : false
    }
  },
  "id" : 948101551381467136,
  "created_at" : "2018-01-02 07:59:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilton Crover",
      "screen_name" : "HiltonCrover703",
      "indices" : [ 3, 19 ],
      "id_str" : "543520235",
      "id" : 543520235
    }, {
      "name" : "CNN International",
      "screen_name" : "cnni",
      "indices" : [ 67, 72 ],
      "id_str" : "2097571",
      "id" : 2097571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/m0vFmFkTFl",
      "expanded_url" : "http:\/\/cnn.it\/2Ckzeyg",
      "display_url" : "cnn.it\/2Ckzeyg"
    } ]
  },
  "geo" : { },
  "id_str" : "948101002577829889",
  "text" : "RT @HiltonCrover703: Two US families die in Costa Rica plane crash @CNNI https:\/\/t.co\/m0vFmFkTFl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN International",
        "screen_name" : "cnni",
        "indices" : [ 46, 51 ],
        "id_str" : "2097571",
        "id" : 2097571
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/m0vFmFkTFl",
        "expanded_url" : "http:\/\/cnn.it\/2Ckzeyg",
        "display_url" : "cnn.it\/2Ckzeyg"
      } ]
    },
    "geo" : { },
    "id_str" : "948100778346057728",
    "text" : "Two US families die in Costa Rica plane crash @CNNI https:\/\/t.co\/m0vFmFkTFl",
    "id" : 948100778346057728,
    "created_at" : "2018-01-02 07:56:55 +0000",
    "user" : {
      "name" : "Hilton Crover",
      "screen_name" : "HiltonCrover703",
      "protected" : false,
      "id_str" : "543520235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2019448968\/1172286523256_normal.jpg",
      "id" : 543520235,
      "verified" : false
    }
  },
  "id" : 948101002577829889,
  "created_at" : "2018-01-02 07:57:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/rgABzZTHsi",
      "expanded_url" : "https:\/\/trib.al\/gu1lKgj",
      "display_url" : "trib.al\/gu1lKgj"
    } ]
  },
  "geo" : { },
  "id_str" : "948100703368736769",
  "text" : "RT @epicurious: File under: cold-weather cooking. https:\/\/t.co\/rgABzZTHsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/rgABzZTHsi",
        "expanded_url" : "https:\/\/trib.al\/gu1lKgj",
        "display_url" : "trib.al\/gu1lKgj"
      } ]
    },
    "geo" : { },
    "id_str" : "947983813715603457",
    "text" : "File under: cold-weather cooking. https:\/\/t.co\/rgABzZTHsi",
    "id" : 947983813715603457,
    "created_at" : "2018-01-02 00:12:08 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948100703368736769,
  "created_at" : "2018-01-02 07:56:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/o5IAjpydhn",
      "expanded_url" : "https:\/\/trib.al\/m5SWTAb",
      "display_url" : "trib.al\/m5SWTAb"
    } ]
  },
  "geo" : { },
  "id_str" : "948100651422281728",
  "text" : "RT @epicurious: For those of you who are giving up meat for a while...https:\/\/t.co\/o5IAjpydhn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/o5IAjpydhn",
        "expanded_url" : "https:\/\/trib.al\/m5SWTAb",
        "display_url" : "trib.al\/m5SWTAb"
      } ]
    },
    "geo" : { },
    "id_str" : "948029851943997440",
    "text" : "For those of you who are giving up meat for a while...https:\/\/t.co\/o5IAjpydhn",
    "id" : 948029851943997440,
    "created_at" : "2018-01-02 03:15:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 948100651422281728,
  "created_at" : "2018-01-02 07:56:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TradingView",
      "screen_name" : "tradingview",
      "indices" : [ 57, 69 ],
      "id_str" : "373457750",
      "id" : 373457750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948100297779539968\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/s6R82scnyD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DShUMIYXUAAlU_G.jpg",
      "id_str" : "948100288946327552",
      "id" : 948100288946327552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DShUMIYXUAAlU_G.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1381
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1381
      } ],
      "display_url" : "pic.twitter.com\/s6R82scnyD"
    } ],
    "hashtags" : [ {
      "text" : "Forex",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/a4CMJhjEND",
      "expanded_url" : "http:\/\/bit.ly\/2DOfqzA",
      "display_url" : "bit.ly\/2DOfqzA"
    } ]
  },
  "geo" : { },
  "id_str" : "948100297779539968",
  "text" : "Putting things into perspective for this #Forex pair via @tradingview https:\/\/t.co\/a4CMJhjEND https:\/\/t.co\/s6R82scnyD",
  "id" : 948100297779539968,
  "created_at" : "2018-01-02 07:55:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/jJEryRkz7x",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/USDJPY\/BoimLJAD-USD-JPY-Trading-Potential\/",
      "display_url" : "tradingview.com\/chart\/USDJPY\/B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948099736493420544",
  "text" : "USD\/JPY Trading Potential - $USDJPY chart https:\/\/t.co\/jJEryRkz7x",
  "id" : 948099736493420544,
  "created_at" : "2018-01-02 07:52:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/1sh4Aigyur",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/dashboard-design\/",
      "display_url" : "webdesigndev.com\/dashboard-desi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948084592078188544",
  "text" : "RT @WebDesignDev: Dashboard Design | 20 Beautiful Examples of Dashboards: https:\/\/t.co\/1sh4Aigyur",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/1sh4Aigyur",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/dashboard-design\/",
        "display_url" : "webdesigndev.com\/dashboard-desi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947973073776644096",
    "text" : "Dashboard Design | 20 Beautiful Examples of Dashboards: https:\/\/t.co\/1sh4Aigyur",
    "id" : 947973073776644096,
    "created_at" : "2018-01-01 23:29:27 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948084592078188544,
  "created_at" : "2018-01-02 06:52:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Node.js",
      "screen_name" : "nodejs",
      "indices" : [ 3, 10 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "Node",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948084101575307264",
  "text" : "RT @nodejs: There are a lot of different ways to contribute to the #nodejs community, and our \"How I Got Into #Node\" series covers it all.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2728 rachel \u2728",
        "screen_name" : "ohhoe",
        "indices" : [ 133, 139 ],
        "id_str" : "2141321",
        "id" : 2141321
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodejs",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "Node",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 149, 156 ]
      } ],
      "urls" : [ {
        "indices" : [ 223, 246 ],
        "url" : "https:\/\/t.co\/ulx93oaRKL",
        "expanded_url" : "http:\/\/bit.ly\/2mS1QaN",
        "display_url" : "bit.ly\/2mS1QaN"
      } ]
    },
    "geo" : { },
    "id_str" : "946470848889749505",
    "text" : "There are a lot of different ways to contribute to the #nodejs community, and our \"How I Got Into #Node\" series covers it all. \uD83D\uDCD6 how @ohhoe got into #nodejs, why she contributes, and all the cool things she makes with Node https:\/\/t.co\/ulx93oaRKL",
    "id" : 946470848889749505,
    "created_at" : "2017-12-28 20:00:09 +0000",
    "user" : {
      "name" : "Node.js",
      "screen_name" : "nodejs",
      "protected" : false,
      "id_str" : "91985735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702185727262482432\/n1JRsFeB_normal.png",
      "id" : 91985735,
      "verified" : true
    }
  },
  "id" : 948084101575307264,
  "created_at" : "2018-01-02 06:50:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iridium Corporate",
      "screen_name" : "IridiumComm",
      "indices" : [ 3, 15 ],
      "id_str" : "150744336",
      "id" : 150744336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948083677652836352",
  "text" : "RT @IridiumComm: Read about the crazy lights in the sky last Friday? Still skeptical of what it \"really\" was? #FlashbackFriday to our favor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 93, 109 ]
      }, {
        "text" : "Iridium4",
        "indices" : [ 142, 151 ]
      }, {
        "text" : "IridiumNEXT",
        "indices" : [ 213, 225 ]
      }, {
        "text" : "NotaUFO",
        "indices" : [ 261, 269 ]
      }, {
        "text" : "SorryNotSorry",
        "indices" : [ 270, 284 ]
      } ],
      "urls" : [ {
        "indices" : [ 237, 260 ],
        "url" : "https:\/\/t.co\/V9lna4pEGr",
        "expanded_url" : "http:\/\/bit.ly\/2CloAXy",
        "display_url" : "bit.ly\/2CloAXy"
      } ]
    },
    "geo" : { },
    "id_str" : "946814835915919360",
    "text" : "Read about the crazy lights in the sky last Friday? Still skeptical of what it \"really\" was? #FlashbackFriday to our favorite day in Dec when #Iridium4 took flight &amp; mesmerized while on its way to drop off 10 #IridiumNEXT satellites https:\/\/t.co\/V9lna4pEGr #NotaUFO #SorryNotSorry",
    "id" : 946814835915919360,
    "created_at" : "2017-12-29 18:47:02 +0000",
    "user" : {
      "name" : "Iridium Corporate",
      "screen_name" : "IridiumComm",
      "protected" : false,
      "id_str" : "150744336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671741483150680064\/b9HlO8sj_normal.png",
      "id" : 150744336,
      "verified" : true
    }
  },
  "id" : 948083677652836352,
  "created_at" : "2018-01-02 06:48:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/NG2dwh29dV",
      "expanded_url" : "http:\/\/bit.ly\/2DreUYT",
      "display_url" : "bit.ly\/2DreUYT"
    } ]
  },
  "geo" : { },
  "id_str" : "948083261338734592",
  "text" : "RT @WIRED: Remember when refrigerators used to murder people? Not anymore, thanks to Albert Einstein. https:\/\/t.co\/NG2dwh29dV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/NG2dwh29dV",
        "expanded_url" : "http:\/\/bit.ly\/2DreUYT",
        "display_url" : "bit.ly\/2DreUYT"
      } ]
    },
    "geo" : { },
    "id_str" : "948075599129710592",
    "text" : "Remember when refrigerators used to murder people? Not anymore, thanks to Albert Einstein. https:\/\/t.co\/NG2dwh29dV",
    "id" : 948075599129710592,
    "created_at" : "2018-01-02 06:16:51 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 948083261338734592,
  "created_at" : "2018-01-02 06:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/kodL5WdVc9",
      "expanded_url" : "http:\/\/ift.tt\/2qb8wm2",
      "display_url" : "ift.tt\/2qb8wm2"
    } ]
  },
  "geo" : { },
  "id_str" : "948082723784183808",
  "text" : "RT @dronepilots: Kratos Subsidiary Gets $93M US Army Aerial Targets Contract | DronePilots - https:\/\/t.co\/kodL5WdVc9 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/kodL5WdVc9",
        "expanded_url" : "http:\/\/ift.tt\/2qb8wm2",
        "display_url" : "ift.tt\/2qb8wm2"
      } ]
    },
    "geo" : { },
    "id_str" : "948082488521478144",
    "text" : "Kratos Subsidiary Gets $93M US Army Aerial Targets Contract | DronePilots - https:\/\/t.co\/kodL5WdVc9 #drones",
    "id" : 948082488521478144,
    "created_at" : "2018-01-02 06:44:14 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948082723784183808,
  "created_at" : "2018-01-02 06:45:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SalesforceDevelopers",
      "screen_name" : "SalesforceDevs",
      "indices" : [ 3, 18 ],
      "id_str" : "7834512",
      "id" : 7834512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948082370892136448",
  "text" : "RT @SalesforceDevs: Catch our December webinar?\uD83C\uDF99 Our devs teach you how-to simplify your code with Salesforce DX and module development. \uD83D\uDCFA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/aSHDRMpht6",
        "expanded_url" : "http:\/\/sforce.co\/2lmqpZG",
        "display_url" : "sforce.co\/2lmqpZG"
      } ]
    },
    "geo" : { },
    "id_str" : "946440637481738240",
    "text" : "Catch our December webinar?\uD83C\uDF99 Our devs teach you how-to simplify your code with Salesforce DX and module development. \uD83D\uDCFA  Watch it on-demand here: https:\/\/t.co\/aSHDRMpht6",
    "id" : 946440637481738240,
    "created_at" : "2017-12-28 18:00:06 +0000",
    "user" : {
      "name" : "SalesforceDevelopers",
      "screen_name" : "SalesforceDevs",
      "protected" : false,
      "id_str" : "7834512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875809720266743808\/jX-q_THz_normal.jpg",
      "id" : 7834512,
      "verified" : true
    }
  },
  "id" : 948082370892136448,
  "created_at" : "2018-01-02 06:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Fawcett",
      "screen_name" : "andyinthecloud",
      "indices" : [ 3, 18 ],
      "id_str" : "81625756",
      "id" : 81625756
    }, {
      "name" : "Jesse Altman",
      "screen_name" : "jessealtman",
      "indices" : [ 47, 59 ],
      "id_str" : "1656515028",
      "id" : 1656515028
    }, {
      "name" : "FinancialForce",
      "screen_name" : "FinancialForce",
      "indices" : [ 60, 75 ],
      "id_str" : "18764818",
      "id" : 18764818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948082323777572864",
  "text" : "RT @andyinthecloud: Fun day brainstorming with @jessealtman @FinancialForce PSA Architect, topics such EDA via Platform Events! @FinancialF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Altman",
        "screen_name" : "jessealtman",
        "indices" : [ 27, 39 ],
        "id_str" : "1656515028",
        "id" : 1656515028
      }, {
        "name" : "FinancialForce",
        "screen_name" : "FinancialForce",
        "indices" : [ 40, 55 ],
        "id_str" : "18764818",
        "id" : 18764818
      }, {
        "name" : "FinancialForce",
        "screen_name" : "FinancialForce",
        "indices" : [ 108, 123 ],
        "id_str" : "18764818",
        "id" : 18764818
      }, {
        "name" : "SalesforceDevelopers",
        "screen_name" : "SalesforceDevs",
        "indices" : [ 124, 139 ],
        "id_str" : "7834512",
        "id" : 7834512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "922990728912936963",
    "text" : "Fun day brainstorming with @jessealtman @FinancialForce PSA Architect, topics such EDA via Platform Events! @FinancialForce @SalesforceDevs",
    "id" : 922990728912936963,
    "created_at" : "2017-10-25 00:58:32 +0000",
    "user" : {
      "name" : "Andrew Fawcett",
      "screen_name" : "andyinthecloud",
      "protected" : false,
      "id_str" : "81625756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000699734764\/b5f0ec906855430681cdf578cbccabb7_normal.jpeg",
      "id" : 81625756,
      "verified" : false
    }
  },
  "id" : 948082323777572864,
  "created_at" : "2018-01-02 06:43:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salesforce SE",
      "screen_name" : "StackSalesforce",
      "indices" : [ 3, 19 ],
      "id_str" : "735058458",
      "id" : 735058458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948082259059503104",
  "text" : "RT @StackSalesforce: Get Debug Logs with specified log levels for Execute Anonyous via APEX ToolingAPI, SoapAPI or anyhow https:\/\/t.co\/6qED\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.stackexchange.com\" rel=\"nofollow\"\u003EStack Exchange\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apex",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/6qED4yZs3B",
        "expanded_url" : "https:\/\/salesforce.stackexchange.com\/q\/41837?atw=1",
        "display_url" : "salesforce.stackexchange.com\/q\/41837?atw=1"
      } ]
    },
    "geo" : { },
    "id_str" : "948035938017562625",
    "text" : "Get Debug Logs with specified log levels for Execute Anonyous via APEX ToolingAPI, SoapAPI or anyhow https:\/\/t.co\/6qED4yZs3B #apex",
    "id" : 948035938017562625,
    "created_at" : "2018-01-02 03:39:15 +0000",
    "user" : {
      "name" : "Salesforce SE",
      "screen_name" : "StackSalesforce",
      "protected" : false,
      "id_str" : "735058458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700015326574948352\/SxCeO0-m_normal.png",
      "id" : 735058458,
      "verified" : false
    }
  },
  "id" : 948082259059503104,
  "created_at" : "2018-01-02 06:43:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/q3Z3eZ9N6f",
      "expanded_url" : "http:\/\/engt.co\/2CDEkmi",
      "display_url" : "engt.co\/2CDEkmi"
    } ]
  },
  "geo" : { },
  "id_str" : "948081546816344064",
  "text" : "RT @engadget: A rare Blue Moon lunar eclipse will happen this month https:\/\/t.co\/q3Z3eZ9N6f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/q3Z3eZ9N6f",
        "expanded_url" : "http:\/\/engt.co\/2CDEkmi",
        "display_url" : "engt.co\/2CDEkmi"
      } ]
    },
    "geo" : { },
    "id_str" : "948081145366958080",
    "text" : "A rare Blue Moon lunar eclipse will happen this month https:\/\/t.co\/q3Z3eZ9N6f",
    "id" : 948081145366958080,
    "created_at" : "2018-01-02 06:38:54 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948081546816344064,
  "created_at" : "2018-01-02 06:40:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948081337373773827\/photo\/1",
      "indices" : [ 277, 300 ],
      "url" : "https:\/\/t.co\/JaGBPUpbaO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DShC5QVXUAARLca.jpg",
      "id_str" : "948081272966041600",
      "id" : 948081272966041600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DShC5QVXUAARLca.jpg",
      "sizes" : [ {
        "h" : 503,
        "resize" : "fit",
        "w" : 966
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 966
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 966
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/JaGBPUpbaO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948081337373773827",
  "text" : "In the last 7 days, $XRP reached its highest point in its history at $2.44 a coin. Still looks like it will go up. Though it went slightly down, the high today was $2.08 showing a stable correlation past 3 days. I still stick with the potential of an imminent $3 price target. https:\/\/t.co\/JaGBPUpbaO",
  "id" : 948081337373773827,
  "created_at" : "2018-01-02 06:39:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/hNebZQHky4",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/premium-tumblr-themes-awesome-blogs\/",
      "display_url" : "webdesigndev.com\/premium-tumblr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948080581107179520",
  "text" : "RT @WebDesignDev: 20 New Premium Tumblr Themes for Awesome Blogs!: https:\/\/t.co\/hNebZQHky4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/hNebZQHky4",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/premium-tumblr-themes-awesome-blogs\/",
        "display_url" : "webdesigndev.com\/premium-tumblr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948077801034403840",
    "text" : "20 New Premium Tumblr Themes for Awesome Blogs!: https:\/\/t.co\/hNebZQHky4",
    "id" : 948077801034403840,
    "created_at" : "2018-01-02 06:25:36 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948080581107179520,
  "created_at" : "2018-01-02 06:36:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TradingView",
      "screen_name" : "tradingview",
      "indices" : [ 240, 252 ],
      "id_str" : "373457750",
      "id" : 373457750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948080490480840704\/photo\/1",
      "indices" : [ 253, 276 ],
      "url" : "https:\/\/t.co\/4lFFXpN61Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DShCKSbXcAIVHMH.jpg",
      "id_str" : "948080466074234882",
      "id" : 948080466074234882,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DShCKSbXcAIVHMH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 1383
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 1383
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 571,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4lFFXpN61Q"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948080490480840704\/photo\/1",
      "indices" : [ 253, 276 ],
      "url" : "https:\/\/t.co\/4lFFXpN61Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DShCK0fW4AAuidG.jpg",
      "id_str" : "948080475217780736",
      "id" : 948080475217780736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DShCK0fW4AAuidG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 364
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 364
      } ],
      "display_url" : "pic.twitter.com\/4lFFXpN61Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948080490480840704",
  "text" : "My parents could have almost doubled their money by now when I told them to get Alibaba few years back. I think a $180 price target should happen soon. Alibaba though in general seems to have a sustainable future still as a tech giant. via @tradingview https:\/\/t.co\/4lFFXpN61Q",
  "id" : 948080490480840704,
  "created_at" : "2018-01-02 06:36:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/AE8br3i1QI",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BABA\/e3kOph3J-Alibaba-180-Price-Target\/",
      "display_url" : "tradingview.com\/chart\/BABA\/e3k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948079856520069120",
  "text" : "Alibaba: $180 Price Target - $BABA chart https:\/\/t.co\/AE8br3i1QI",
  "id" : 948079856520069120,
  "created_at" : "2018-01-02 06:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 3, 9 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948075552937783298",
  "text" : "RT @intel: Meet the Intel Falcon 8+ commercial drone pilot who helped first responders after California\u2019s Sonoma County fires. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/nRfs1UBE4J",
        "expanded_url" : "http:\/\/intel.ly\/2iZls7Q",
        "display_url" : "intel.ly\/2iZls7Q"
      } ]
    },
    "geo" : { },
    "id_str" : "931250576893071361",
    "text" : "Meet the Intel Falcon 8+ commercial drone pilot who helped first responders after California\u2019s Sonoma County fires. https:\/\/t.co\/nRfs1UBE4J",
    "id" : 931250576893071361,
    "created_at" : "2017-11-16 20:00:13 +0000",
    "user" : {
      "name" : "Intel",
      "screen_name" : "intel",
      "protected" : false,
      "id_str" : "2803191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879390586385514496\/wQgljN6c_normal.jpg",
      "id" : 2803191,
      "verified" : true
    }
  },
  "id" : 948075552937783298,
  "created_at" : "2018-01-02 06:16:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Mike Varshavski",
      "screen_name" : "RealDoctorMike",
      "indices" : [ 3, 18 ],
      "id_str" : "1526321732",
      "id" : 1526321732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948075230395805696",
  "text" : "RT @RealDoctorMike: Hey Logan Paul, You want to be the first social media billionaire? By exploiting the death of a troubled youth? Take a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Logan Paul",
        "screen_name" : "LoganPaul",
        "indices" : [ 236, 246 ],
        "id_str" : "410409666",
        "id" : 410409666
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "beahumanfirst",
        "indices" : [ 247, 261 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948035327553351681",
    "text" : "Hey Logan Paul, You want to be the first social media billionaire? By exploiting the death of a troubled youth? Take a long hard look at what you are doing with your popularity young man. Find a mentor and perhaps log off for a moment. @LoganPaul #beahumanfirst",
    "id" : 948035327553351681,
    "created_at" : "2018-01-02 03:36:50 +0000",
    "user" : {
      "name" : "Dr. Mike Varshavski",
      "screen_name" : "RealDoctorMike",
      "protected" : false,
      "id_str" : "1526321732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660865091584307204\/x6BgTU3A_normal.jpg",
      "id" : 1526321732,
      "verified" : true
    }
  },
  "id" : 948075230395805696,
  "created_at" : "2018-01-02 06:15:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "Iridium Corporate",
      "screen_name" : "IridiumComm",
      "indices" : [ 58, 70 ],
      "id_str" : "150744336",
      "id" : 150744336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/gtC39uBC7z",
      "expanded_url" : "http:\/\/spacex.com\/webcast",
      "display_url" : "spacex.com\/webcast"
    } ]
  },
  "geo" : { },
  "id_str" : "948074622322397184",
  "text" : "RT @SpaceX: Back live for final burn and deployment of 10 @IridiumComm NEXT satellites \u2192 https:\/\/t.co\/gtC39uBC7z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Iridium Corporate",
        "screen_name" : "IridiumComm",
        "indices" : [ 46, 58 ],
        "id_str" : "150744336",
        "id" : 150744336
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/gtC39uBC7z",
        "expanded_url" : "http:\/\/spacex.com\/webcast",
        "display_url" : "spacex.com\/webcast"
      } ]
    },
    "geo" : { },
    "id_str" : "944391868846030848",
    "text" : "Back live for final burn and deployment of 10 @IridiumComm NEXT satellites \u2192 https:\/\/t.co\/gtC39uBC7z",
    "id" : 944391868846030848,
    "created_at" : "2017-12-23 02:19:02 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 948074622322397184,
  "created_at" : "2018-01-02 06:12:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948074568807276544",
  "text" : "RT @elonmusk: Wanted again to send a note of deep gratitude to Tesla owners WW for taking a chance on a new company that all experts said w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "945712432416137217",
    "text" : "Wanted again to send a note of deep gratitude to Tesla owners WW for taking a chance on a new company that all experts said would fail. \n\nSo much blood, sweat &amp; tears from the Tesla team went into creating cars that you\u2019d truly love. I hope you do.\n\nHow can we improve further?",
    "id" : 945712432416137217,
    "created_at" : "2017-12-26 17:46:29 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 948074568807276544,
  "created_at" : "2018-01-02 06:12:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Dyke",
      "screen_name" : "TheRobDyke",
      "indices" : [ 3, 14 ],
      "id_str" : "485377857",
      "id" : 485377857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948074028790616064",
  "text" : "RT @TheRobDyke: There are people getting ready right now to party tonight. They\u2019re gonna have some drinks and welcome the new year in style\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947540303682129921",
    "text" : "There are people getting ready right now to party tonight. They\u2019re gonna have some drinks and welcome the new year in style. They\u2019re putting on clothes, make-up, whatever it is right now. And some of those people, tonight, will die. And they have no idea. Don\u2019t drink and drive.",
    "id" : 947540303682129921,
    "created_at" : "2017-12-31 18:49:47 +0000",
    "user" : {
      "name" : "Rob Dyke",
      "screen_name" : "TheRobDyke",
      "protected" : false,
      "id_str" : "485377857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925762149573648389\/_RB0nv_7_normal.jpg",
      "id" : 485377857,
      "verified" : true
    }
  },
  "id" : 948074028790616064,
  "created_at" : "2018-01-02 06:10:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948073997211709440",
  "text" : "RT @Matthiasiam: If that\u2019s not cause for termination of a YouTube channel, then I\u2019m left baffled. So much disrespect. These brothers have l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948008073636888576",
    "text" : "If that\u2019s not cause for termination of a YouTube channel, then I\u2019m left baffled. So much disrespect. These brothers have lost their soul in the battle to one-up each other.",
    "id" : 948008073636888576,
    "created_at" : "2018-01-02 01:48:32 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929487527995510784\/Hzr8H3DU_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 948073997211709440,
  "created_at" : "2018-01-02 06:10:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/GnEJ6eJzuV",
      "expanded_url" : "https:\/\/buff.ly\/2D8ZKXu",
      "display_url" : "buff.ly\/2D8ZKXu"
    } ]
  },
  "geo" : { },
  "id_str" : "948073842584506368",
  "text" : "RT @analyticbridge: Market Mix Modeling (MMM) https:\/\/t.co\/GnEJ6eJzuV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/GnEJ6eJzuV",
        "expanded_url" : "https:\/\/buff.ly\/2D8ZKXu",
        "display_url" : "buff.ly\/2D8ZKXu"
      } ]
    },
    "geo" : { },
    "id_str" : "948061041438707712",
    "text" : "Market Mix Modeling (MMM) https:\/\/t.co\/GnEJ6eJzuV",
    "id" : 948061041438707712,
    "created_at" : "2018-01-02 05:19:01 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948073842584506368,
  "created_at" : "2018-01-02 06:09:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "History Lovers Club",
      "screen_name" : "historylvrsclub",
      "indices" : [ 3, 19 ],
      "id_str" : "3863605355",
      "id" : 3863605355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948073758635581440",
  "text" : "RT @historylvrsclub: \u201CI don't care that they stole my idea. I care that they don't have any of their own.\u201D - Nikola Tesla https:\/\/t.co\/37IV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/historylvrsclub\/status\/947780943842021376\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/37IVryU1qs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DScxsLAWkAAuc6y.jpg",
        "id_str" : "947780881523052544",
        "id" : 947780881523052544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DScxsLAWkAAuc6y.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 362
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 362
        } ],
        "display_url" : "pic.twitter.com\/37IVryU1qs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947780943842021376",
    "text" : "\u201CI don't care that they stole my idea. I care that they don't have any of their own.\u201D - Nikola Tesla https:\/\/t.co\/37IVryU1qs",
    "id" : 947780943842021376,
    "created_at" : "2018-01-01 10:46:00 +0000",
    "user" : {
      "name" : "History Lovers Club",
      "screen_name" : "historylvrsclub",
      "protected" : false,
      "id_str" : "3863605355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650726769058807808\/vWX4lILy_normal.jpg",
      "id" : 3863605355,
      "verified" : false
    }
  },
  "id" : 948073758635581440,
  "created_at" : "2018-01-02 06:09:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Primack",
      "screen_name" : "danprimack",
      "indices" : [ 3, 14 ],
      "id_str" : "16246929",
      "id" : 16246929
    }, {
      "name" : "Kia K.",
      "screen_name" : "imkialikethecar",
      "indices" : [ 27, 43 ],
      "id_str" : "245697392",
      "id" : 245697392
    }, {
      "name" : "Axios",
      "screen_name" : "axios",
      "indices" : [ 81, 87 ],
      "id_str" : "800707492346925056",
      "id" : 800707492346925056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/lRSc7zsCAu",
      "expanded_url" : "https:\/\/www.axios.com\/coinlist-spins-out-as-standalone-company-2498906975.html?utm_source=twitter&utm_medium=twsocialshare&utm_campaign=organic",
      "display_url" : "axios.com\/coinlist-spins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948072583597092864",
  "text" : "RT @danprimack: Scoop from @imkialikethecar: CoinList spins out of AngelList via @axios https:\/\/t.co\/lRSc7zsCAu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kia K.",
        "screen_name" : "imkialikethecar",
        "indices" : [ 11, 27 ],
        "id_str" : "245697392",
        "id" : 245697392
      }, {
        "name" : "Axios",
        "screen_name" : "axios",
        "indices" : [ 65, 71 ],
        "id_str" : "800707492346925056",
        "id" : 800707492346925056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/lRSc7zsCAu",
        "expanded_url" : "https:\/\/www.axios.com\/coinlist-spins-out-as-standalone-company-2498906975.html?utm_source=twitter&utm_medium=twsocialshare&utm_campaign=organic",
        "display_url" : "axios.com\/coinlist-spins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "921370697850609664",
    "text" : "Scoop from @imkialikethecar: CoinList spins out of AngelList via @axios https:\/\/t.co\/lRSc7zsCAu",
    "id" : 921370697850609664,
    "created_at" : "2017-10-20 13:41:07 +0000",
    "user" : {
      "name" : "Dan Primack",
      "screen_name" : "danprimack",
      "protected" : false,
      "id_str" : "16246929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980037366\/danprimack_normal.jpg",
      "id" : 16246929,
      "verified" : true
    }
  },
  "id" : 948072583597092864,
  "created_at" : "2018-01-02 06:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoinList",
      "screen_name" : "coinlist",
      "indices" : [ 3, 12 ],
      "id_str" : "866047997456658434",
      "id" : 866047997456658434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/idEy0GheeB",
      "expanded_url" : "http:\/\/blockstack.one",
      "display_url" : "blockstack.one"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/uhtpPLX339",
      "expanded_url" : "https:\/\/blockstack.com",
      "display_url" : "blockstack.com"
    } ]
  },
  "geo" : { },
  "id_str" : "948072543142981632",
  "text" : "RT @coinlist: ICYMI https:\/\/t.co\/idEy0GheeB is a scam. The only places to buy blockstack tokens are https:\/\/t.co\/uhtpPLX339 and https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/idEy0GheeB",
        "expanded_url" : "http:\/\/blockstack.one",
        "display_url" : "blockstack.one"
      }, {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/uhtpPLX339",
        "expanded_url" : "https:\/\/blockstack.com",
        "display_url" : "blockstack.com"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/83UbV0cX1x",
        "expanded_url" : "https:\/\/coinlist.co",
        "display_url" : "coinlist.co"
      } ]
    },
    "geo" : { },
    "id_str" : "931403386489942016",
    "text" : "ICYMI https:\/\/t.co\/idEy0GheeB is a scam. The only places to buy blockstack tokens are https:\/\/t.co\/uhtpPLX339 and https:\/\/t.co\/83UbV0cX1x.",
    "id" : 931403386489942016,
    "created_at" : "2017-11-17 06:07:26 +0000",
    "user" : {
      "name" : "CoinList",
      "screen_name" : "coinlist",
      "protected" : false,
      "id_str" : "866047997456658434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922628815033057280\/SzqlRfLI_normal.jpg",
      "id" : 866047997456658434,
      "verified" : false
    }
  },
  "id" : 948072543142981632,
  "created_at" : "2018-01-02 06:04:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1rINrLy2vB",
      "expanded_url" : "http:\/\/ift.tt\/2CMOSOE",
      "display_url" : "ift.tt\/2CMOSOE"
    } ]
  },
  "geo" : { },
  "id_str" : "948071795936120832",
  "text" : "RT @dronepilots: Boeing unveils MQ-25 drone that it claims will be \"changing future air power\" | DronePilots - https:\/\/t.co\/1rINrLy2vB #dro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/1rINrLy2vB",
        "expanded_url" : "http:\/\/ift.tt\/2CMOSOE",
        "display_url" : "ift.tt\/2CMOSOE"
      } ]
    },
    "geo" : { },
    "id_str" : "947857280971702273",
    "text" : "Boeing unveils MQ-25 drone that it claims will be \"changing future air power\" | DronePilots - https:\/\/t.co\/1rINrLy2vB #drones",
    "id" : 947857280971702273,
    "created_at" : "2018-01-01 15:49:20 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948071795936120832,
  "created_at" : "2018-01-02 06:01:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/KgJY7OLiao",
      "expanded_url" : "http:\/\/ift.tt\/2DI6Z8Y",
      "display_url" : "ift.tt\/2DI6Z8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "948071748762849281",
  "text" : "RT @dronepilots: This amazing drone footage reminds us how stunning Cambridge is | DronePilots - https:\/\/t.co\/KgJY7OLiao #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/KgJY7OLiao",
        "expanded_url" : "http:\/\/ift.tt\/2DI6Z8Y",
        "display_url" : "ift.tt\/2DI6Z8Y"
      } ]
    },
    "geo" : { },
    "id_str" : "947864862344048640",
    "text" : "This amazing drone footage reminds us how stunning Cambridge is | DronePilots - https:\/\/t.co\/KgJY7OLiao #drones",
    "id" : 947864862344048640,
    "created_at" : "2018-01-01 16:19:28 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948071748762849281,
  "created_at" : "2018-01-02 06:01:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "indices" : [ 3, 13 ],
      "id_str" : "403614288",
      "id" : 403614288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948071673886117894",
  "text" : "RT @LinusTech: Happy birthday Linus Media Group. I can't believe the incredible journey I've been on for the last 5 years. Love you all - LS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947739483226570752",
    "text" : "Happy birthday Linus Media Group. I can't believe the incredible journey I've been on for the last 5 years. Love you all - LS",
    "id" : 947739483226570752,
    "created_at" : "2018-01-01 08:01:15 +0000",
    "user" : {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "protected" : false,
      "id_str" : "403614288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748214451740958720\/A5FPJ1ad_normal.jpg",
      "id" : 403614288,
      "verified" : true
    }
  },
  "id" : 948071673886117894,
  "created_at" : "2018-01-02 06:01:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "indices" : [ 3, 13 ],
      "id_str" : "403614288",
      "id" : 403614288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/5vhQxF477u",
      "expanded_url" : "https:\/\/youtu.be\/R_h63IsmvSQ",
      "display_url" : "youtu.be\/R_h63IsmvSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "948071650268008448",
  "text" : "RT @LinusTech: NEW VIDEO: The Ultimate Compact Sleeper PC Build\nOh.. and happy new year! \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF8A\uD83C\uDF8A\uD83C\uDF8A\nhttps:\/\/t.co\/5vhQxF477u https:\/\/t.co\/h6Vhb5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LinusTech\/status\/947740623812956160\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/h6Vhb5EQB2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DScNEBoVoAE0toH.jpg",
        "id_str" : "947740609393041409",
        "id" : 947740609393041409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DScNEBoVoAE0toH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/h6Vhb5EQB2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/5vhQxF477u",
        "expanded_url" : "https:\/\/youtu.be\/R_h63IsmvSQ",
        "display_url" : "youtu.be\/R_h63IsmvSQ"
      } ]
    },
    "geo" : { },
    "id_str" : "947740623812956160",
    "text" : "NEW VIDEO: The Ultimate Compact Sleeper PC Build\nOh.. and happy new year! \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89\uD83C\uDF8A\uD83C\uDF8A\uD83C\uDF8A\nhttps:\/\/t.co\/5vhQxF477u https:\/\/t.co\/h6Vhb5EQB2",
    "id" : 947740623812956160,
    "created_at" : "2018-01-01 08:05:47 +0000",
    "user" : {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "protected" : false,
      "id_str" : "403614288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748214451740958720\/A5FPJ1ad_normal.jpg",
      "id" : 403614288,
      "verified" : true
    }
  },
  "id" : 948071650268008448,
  "created_at" : "2018-01-02 06:01:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948071129922629632",
  "text" : "I may start using Reddit some more :&gt;)",
  "id" : 948071129922629632,
  "created_at" : "2018-01-02 05:59:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/7rYqprz5Pa",
      "expanded_url" : "http:\/\/bit.ly\/2C8SV8g",
      "display_url" : "bit.ly\/2C8SV8g"
    } ]
  },
  "geo" : { },
  "id_str" : "948071067326828544",
  "text" : "https:\/\/t.co\/7rYqprz5Pa",
  "id" : 948071067326828544,
  "created_at" : "2018-01-02 05:58:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Rogers",
      "screen_name" : "Justin_Rogers",
      "indices" : [ 3, 17 ],
      "id_str" : "17542705",
      "id" : 17542705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948061373191409664",
  "text" : "RT @Justin_Rogers: According to reports, Lions have expressed interest in talking to Patricia, Wilks and Vrabel. No surprises.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947842093124333568",
    "text" : "According to reports, Lions have expressed interest in talking to Patricia, Wilks and Vrabel. No surprises.",
    "id" : 947842093124333568,
    "created_at" : "2018-01-01 14:48:59 +0000",
    "user" : {
      "name" : "Justin Rogers",
      "screen_name" : "Justin_Rogers",
      "protected" : false,
      "id_str" : "17542705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2567721988\/g7mmvpypsw2lbwvw7of3_normal.png",
      "id" : 17542705,
      "verified" : false
    }
  },
  "id" : 948061373191409664,
  "created_at" : "2018-01-02 05:20:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zerohedge",
      "screen_name" : "zerohedge",
      "indices" : [ 3, 13 ],
      "id_str" : "18856867",
      "id" : 18856867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948059528305704960",
  "text" : "RT @zerohedge: Krugman 1997: \"The Internet\u2019s impact on the economy has been no greater than the fax machine\u2019s\u2026.ten years from now, the phra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947995952597622786",
    "text" : "Krugman 1997: \"The Internet\u2019s impact on the economy has been no greater than the fax machine\u2019s\u2026.ten years from now, the phrase \u201Cinformation economy\u201D will sound silly.\"\nKrugman 2018: \"Bitcoin is nonsense\"",
    "id" : 947995952597622786,
    "created_at" : "2018-01-02 01:00:22 +0000",
    "user" : {
      "name" : "zerohedge",
      "screen_name" : "zerohedge",
      "protected" : false,
      "id_str" : "18856867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/72647502\/tyler_normal.jpg",
      "id" : 18856867,
      "verified" : false
    }
  },
  "id" : 948059528305704960,
  "created_at" : "2018-01-02 05:13:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Armstrong",
      "screen_name" : "brian_armstrong",
      "indices" : [ 3, 19 ],
      "id_str" : "14379660",
      "id" : 14379660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Rogp0PIrww",
      "expanded_url" : "https:\/\/medium.com\/p\/toshi-a-dapp-browser-for-the-ethereum-network-5a64bde25757",
      "display_url" : "medium.com\/p\/toshi-a-dapp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948052123601833984",
  "text" : "RT @brian_armstrong: I just published \u201CToshi: A Dapp Browser for the Ethereum Network\u201D https:\/\/t.co\/Rogp0PIrww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Rogp0PIrww",
        "expanded_url" : "https:\/\/medium.com\/p\/toshi-a-dapp-browser-for-the-ethereum-network-5a64bde25757",
        "display_url" : "medium.com\/p\/toshi-a-dapp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947661921645449216",
    "text" : "I just published \u201CToshi: A Dapp Browser for the Ethereum Network\u201D https:\/\/t.co\/Rogp0PIrww",
    "id" : 947661921645449216,
    "created_at" : "2018-01-01 02:53:03 +0000",
    "user" : {
      "name" : "Brian Armstrong",
      "screen_name" : "brian_armstrong",
      "protected" : false,
      "id_str" : "14379660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822200953919205377\/AwhBAj8K_normal.jpg",
      "id" : 14379660,
      "verified" : false
    }
  },
  "id" : 948052123601833984,
  "created_at" : "2018-01-02 04:43:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey India",
      "screen_name" : "LindseyIndia",
      "indices" : [ 3, 16 ],
      "id_str" : "117381909",
      "id" : 117381909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948051913358106624",
  "text" : "RT @LindseyIndia: If I\u2019m expressing my genuine feelings of anxiety or concern, don\u2019t ever \u201Clol\u201D me while contesting my thoughts. It will pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948051133976711168",
    "text" : "If I\u2019m expressing my genuine feelings of anxiety or concern, don\u2019t ever \u201Clol\u201D me while contesting my thoughts. It will probably be the last conversation you have with me.",
    "id" : 948051133976711168,
    "created_at" : "2018-01-02 04:39:38 +0000",
    "user" : {
      "name" : "Lindsey India",
      "screen_name" : "LindseyIndia",
      "protected" : false,
      "id_str" : "117381909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948011727156842496\/cfKezdjp_normal.jpg",
      "id" : 117381909,
      "verified" : false
    }
  },
  "id" : 948051913358106624,
  "created_at" : "2018-01-02 04:42:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/yw4U1hb5RV",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-material-design-backgrounds\/",
      "display_url" : "webdesigndev.com\/free-material-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948051869489881094",
  "text" : "RT @WebDesignDev: 250+ Free Material Design Backgrounds You Should Download: https:\/\/t.co\/yw4U1hb5RV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/yw4U1hb5RV",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-material-design-backgrounds\/",
        "display_url" : "webdesigndev.com\/free-material-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948051615491162112",
    "text" : "250+ Free Material Design Backgrounds You Should Download: https:\/\/t.co\/yw4U1hb5RV",
    "id" : 948051615491162112,
    "created_at" : "2018-01-02 04:41:33 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948051869489881094,
  "created_at" : "2018-01-02 04:42:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KDnuggets",
      "screen_name" : "kdnuggets",
      "indices" : [ 3, 13 ],
      "id_str" : "20167623",
      "id" : 20167623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KDN",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/lai3qcUB1k",
      "expanded_url" : "http:\/\/ow.ly\/THBs30gZ6oK",
      "display_url" : "ow.ly\/THBs30gZ6oK"
    } ]
  },
  "geo" : { },
  "id_str" : "948051397798395904",
  "text" : "RT @kdnuggets: Anomaly Detection in Predictive Maintenance with Time Series Analysis #KDN https:\/\/t.co\/lai3qcUB1k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KDN",
        "indices" : [ 70, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/lai3qcUB1k",
        "expanded_url" : "http:\/\/ow.ly\/THBs30gZ6oK",
        "display_url" : "ow.ly\/THBs30gZ6oK"
      } ]
    },
    "geo" : { },
    "id_str" : "947935551516266497",
    "text" : "Anomaly Detection in Predictive Maintenance with Time Series Analysis #KDN https:\/\/t.co\/lai3qcUB1k",
    "id" : 947935551516266497,
    "created_at" : "2018-01-01 21:00:21 +0000",
    "user" : {
      "name" : "KDnuggets",
      "screen_name" : "kdnuggets",
      "protected" : false,
      "id_str" : "20167623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795788806008041473\/0nTPcRja_normal.jpg",
      "id" : 20167623,
      "verified" : false
    }
  },
  "id" : 948051397798395904,
  "created_at" : "2018-01-02 04:40:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis Hilsenteger",
      "screen_name" : "UnboxTherapy",
      "indices" : [ 3, 16 ],
      "id_str" : "239672340",
      "id" : 239672340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948051337274691584",
  "text" : "RT @UnboxTherapy: The customer \u201Coutrage\u201D is not about battery tech it\u2019s about subverting one\u2019s ability to diagnose their smartphone's issue\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "946789401945919488",
    "text" : "The customer \u201Coutrage\u201D is not about battery tech it\u2019s about subverting one\u2019s ability to diagnose their smartphone's issue. If your car needed new tires you\u2019d be experiencing traction issues not a transmission that refuses to shift gears.",
    "id" : 946789401945919488,
    "created_at" : "2017-12-29 17:05:58 +0000",
    "user" : {
      "name" : "Lewis Hilsenteger",
      "screen_name" : "UnboxTherapy",
      "protected" : false,
      "id_str" : "239672340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948769241443942401\/tL1_qwMz_normal.jpg",
      "id" : 239672340,
      "verified" : true
    }
  },
  "id" : 948051337274691584,
  "created_at" : "2018-01-02 04:40:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marques Brownlee",
      "screen_name" : "MKBHD",
      "indices" : [ 3, 9 ],
      "id_str" : "29873662",
      "id" : 29873662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948051160782594048",
  "text" : "RT @MKBHD: 9 years ago today, January 1st 2009: Uploaded my first video to YouTube. No regrets. Just getting started. Let's go 2018.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.samruston.co.uk\" rel=\"nofollow\"\u003EFlamingo for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947693940257492992",
    "text" : "9 years ago today, January 1st 2009: Uploaded my first video to YouTube. No regrets. Just getting started. Let's go 2018.",
    "id" : 947693940257492992,
    "created_at" : "2018-01-01 05:00:17 +0000",
    "user" : {
      "name" : "Marques Brownlee",
      "screen_name" : "MKBHD",
      "protected" : false,
      "id_str" : "29873662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946798631151112194\/0e0OgvFz_normal.jpg",
      "id" : 29873662,
      "verified" : true
    }
  },
  "id" : 948051160782594048,
  "created_at" : "2018-01-02 04:39:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "indices" : [ 3, 15 ],
      "id_str" : "717313",
      "id" : 717313
    }, {
      "name" : "Timothy B. Lee",
      "screen_name" : "binarybits",
      "indices" : [ 113, 124 ],
      "id_str" : "14165170",
      "id" : 14165170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HtzRfFgH9A",
      "expanded_url" : "http:\/\/arstechnica.com\/cars\/2018\/01\/driving-around-without-a-driver-lidar-technology-explained\/",
      "display_url" : "arstechnica.com\/cars\/2018\/01\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948050713732698112",
  "text" : "RT @arstechnica: Why experts believe cheaper, better lidar is right around the corner https:\/\/t.co\/HtzRfFgH9A by @binarybits",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/arstechnica.com\" rel=\"nofollow\"\u003EArs tweetbot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Timothy B. Lee",
        "screen_name" : "binarybits",
        "indices" : [ 96, 107 ],
        "id_str" : "14165170",
        "id" : 14165170
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/HtzRfFgH9A",
        "expanded_url" : "http:\/\/arstechnica.com\/cars\/2018\/01\/driving-around-without-a-driver-lidar-technology-explained\/",
        "display_url" : "arstechnica.com\/cars\/2018\/01\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947824990807838720",
    "text" : "Why experts believe cheaper, better lidar is right around the corner https:\/\/t.co\/HtzRfFgH9A by @binarybits",
    "id" : 947824990807838720,
    "created_at" : "2018-01-01 13:41:02 +0000",
    "user" : {
      "name" : "Ars Technica",
      "screen_name" : "arstechnica",
      "protected" : false,
      "id_str" : "717313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2215576731\/ars-logo_normal.png",
      "id" : 717313,
      "verified" : true
    }
  },
  "id" : 948050713732698112,
  "created_at" : "2018-01-02 04:37:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2B Magazine",
      "screen_name" : "2BMagazine",
      "indices" : [ 3, 14 ],
      "id_str" : "800409601",
      "id" : 800409601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Jc7jSk9l5d",
      "expanded_url" : "http:\/\/ift.tt\/2C37kCY",
      "display_url" : "ift.tt\/2C37kCY"
    } ]
  },
  "geo" : { },
  "id_str" : "948050201985601536",
  "text" : "RT @2BMagazine: Beer as a renewable fuel: Vehicles could run on it 2022, without having to be altered https:\/\/t.co\/Jc7jSk9l5d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Jc7jSk9l5d",
        "expanded_url" : "http:\/\/ift.tt\/2C37kCY",
        "display_url" : "ift.tt\/2C37kCY"
      } ]
    },
    "geo" : { },
    "id_str" : "947647647329980416",
    "text" : "Beer as a renewable fuel: Vehicles could run on it 2022, without having to be altered https:\/\/t.co\/Jc7jSk9l5d",
    "id" : 947647647329980416,
    "created_at" : "2018-01-01 01:56:20 +0000",
    "user" : {
      "name" : "2B Magazine",
      "screen_name" : "2BMagazine",
      "protected" : false,
      "id_str" : "800409601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495899599723180032\/jk3CFBgX_normal.png",
      "id" : 800409601,
      "verified" : false
    }
  },
  "id" : 948050201985601536,
  "created_at" : "2018-01-02 04:35:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948050117831077888",
  "text" : "RT @ausecure: Streaming #Gold $1307.2 +$1.9\/0.15% #Silver $17.01 -$0.06\/0.35% #Platinum $934.7 +$0.9\/0.1% #Palladium $1069.8 +$4.1\/0.38%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948041245141733377",
    "text" : "Streaming #Gold $1307.2 +$1.9\/0.15% #Silver $17.01 -$0.06\/0.35% #Platinum $934.7 +$0.9\/0.1% #Palladium $1069.8 +$4.1\/0.38%",
    "id" : 948041245141733377,
    "created_at" : "2018-01-02 04:00:21 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 948050117831077888,
  "created_at" : "2018-01-02 04:35:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maulinus Modo",
      "screen_name" : "panzennakute",
      "indices" : [ 3, 16 ],
      "id_str" : "151238042",
      "id" : 151238042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/p9MIMDWezx",
      "expanded_url" : "https:\/\/www.mnn.com\/green-tech\/research-innovations\/stories\/graphene-material-turns-diamond-armor-when-shot-bullet",
      "display_url" : "mnn.com\/green-tech\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948049953527664640",
  "text" : "RT @panzennakute: Graphene material turns into diamond-like armor when shot with a bullet https:\/\/t.co\/p9MIMDWezx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.aeonmall.com\/\" rel=\"nofollow\"\u003Epanzennakute\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/p9MIMDWezx",
        "expanded_url" : "https:\/\/www.mnn.com\/green-tech\/research-innovations\/stories\/graphene-material-turns-diamond-armor-when-shot-bullet",
        "display_url" : "mnn.com\/green-tech\/res\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947709306056663040",
    "text" : "Graphene material turns into diamond-like armor when shot with a bullet https:\/\/t.co\/p9MIMDWezx",
    "id" : 947709306056663040,
    "created_at" : "2018-01-01 06:01:20 +0000",
    "user" : {
      "name" : "Maulinus Modo",
      "screen_name" : "panzennakute",
      "protected" : false,
      "id_str" : "151238042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836435023880458241\/7JyA2sBy_normal.jpg",
      "id" : 151238042,
      "verified" : false
    }
  },
  "id" : 948049953527664640,
  "created_at" : "2018-01-02 04:34:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TradingView",
      "screen_name" : "tradingview",
      "indices" : [ 40, 52 ],
      "id_str" : "373457750",
      "id" : 373457750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948049711646281728\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JChAXTJhIn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSgmJX-W0AA2R1k.jpg",
      "id_str" : "948049664057724928",
      "id" : 948049664057724928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSgmJX-W0AA2R1k.jpg",
      "sizes" : [ {
        "h" : 649,
        "resize" : "fit",
        "w" : 1370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 1370
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JChAXTJhIn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948049711646281728\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JChAXTJhIn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSgmKHnW4AAc0y9.jpg",
      "id_str" : "948049676846161920",
      "id" : 948049676846161920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSgmKHnW4AAc0y9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 586
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 586
      } ],
      "display_url" : "pic.twitter.com\/JChAXTJhIn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/948049711646281728\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JChAXTJhIn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSgmLCrWkAEWWmU.jpg",
      "id_str" : "948049692700610561",
      "id" : 948049692700610561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSgmLCrWkAEWWmU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 448
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 448
      } ],
      "display_url" : "pic.twitter.com\/JChAXTJhIn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/PHnTxAEFRC",
      "expanded_url" : "http:\/\/bit.ly\/2CBFb71",
      "display_url" : "bit.ly\/2CBFb71"
    } ]
  },
  "geo" : { },
  "id_str" : "948049711646281728",
  "text" : "What would you suggest for Pinkcoin via @tradingview https:\/\/t.co\/PHnTxAEFRC https:\/\/t.co\/JChAXTJhIn",
  "id" : 948049711646281728,
  "created_at" : "2018-01-02 04:33:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ZCxYLvhcxN",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/PINKBTC\/qudlORxR-Poloniex-Pinkcoin-Long\/",
      "display_url" : "tradingview.com\/chart\/PINKBTC\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948049296535953408",
  "text" : "Poloniex: Pinkcoin Long - $PINKBTC chart https:\/\/t.co\/ZCxYLvhcxN",
  "id" : 948049296535953408,
  "created_at" : "2018-01-02 04:32:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/jfmyieRHi3",
      "expanded_url" : "http:\/\/engt.co\/2DLHOma",
      "display_url" : "engt.co\/2DLHOma"
    } ]
  },
  "geo" : { },
  "id_str" : "948038900173430784",
  "text" : "RT @engadget: Samsung preps Chrome OS tablet with a high-end camera https:\/\/t.co\/jfmyieRHi3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/jfmyieRHi3",
        "expanded_url" : "http:\/\/engt.co\/2DLHOma",
        "display_url" : "engt.co\/2DLHOma"
      } ]
    },
    "geo" : { },
    "id_str" : "948035905603895296",
    "text" : "Samsung preps Chrome OS tablet with a high-end camera https:\/\/t.co\/jfmyieRHi3",
    "id" : 948035905603895296,
    "created_at" : "2018-01-02 03:39:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948038900173430784,
  "created_at" : "2018-01-02 03:51:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948038863586545664",
  "text" : "RT @BONNIELYNN2015: If you take a toddler age 2 or three to a campground you don\u2019t take your eyes off of them because they will wander off\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948036527296102400",
    "text" : "If you take a toddler age 2 or three to a campground you don\u2019t take your eyes off of them because they will wander off   Geeezzzz people",
    "id" : 948036527296102400,
    "created_at" : "2018-01-02 03:41:36 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946587001930711040\/6K0BSqwc_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 948038863586545664,
  "created_at" : "2018-01-02 03:50:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/MeiwPD7s1L",
      "expanded_url" : "https:\/\/buff.ly\/2CZiqJ0",
      "display_url" : "buff.ly\/2CZiqJ0"
    } ]
  },
  "geo" : { },
  "id_str" : "948036634586636289",
  "text" : "RT @analyticbridge: Every Data Science Interview Boiled Down To Five Basic Questions  https:\/\/t.co\/MeiwPD7s1L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/MeiwPD7s1L",
        "expanded_url" : "https:\/\/buff.ly\/2CZiqJ0",
        "display_url" : "buff.ly\/2CZiqJ0"
      } ]
    },
    "geo" : { },
    "id_str" : "948033884729610240",
    "text" : "Every Data Science Interview Boiled Down To Five Basic Questions  https:\/\/t.co\/MeiwPD7s1L",
    "id" : 948033884729610240,
    "created_at" : "2018-01-02 03:31:06 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 948036634586636289,
  "created_at" : "2018-01-02 03:42:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948036264854458373",
  "text" : "RT @jacksfilms: shoutout to people who aren't terrible",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948035704336146432",
    "text" : "shoutout to people who aren't terrible",
    "id" : 948035704336146432,
    "created_at" : "2018-01-02 03:38:20 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/947545819158401027\/f4tf_yQn_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 948036264854458373,
  "created_at" : "2018-01-02 03:40:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IClLphoLRj",
      "expanded_url" : "http:\/\/ift.tt\/2zZ1IHV",
      "display_url" : "ift.tt\/2zZ1IHV"
    } ]
  },
  "geo" : { },
  "id_str" : "948036212526338049",
  "text" : "RT @dronepilots: New Solar-Cell Wing Will Boost AeroVironment's Puma Drone | DronePilots - https:\/\/t.co\/IClLphoLRj #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/IClLphoLRj",
        "expanded_url" : "http:\/\/ift.tt\/2zZ1IHV",
        "display_url" : "ift.tt\/2zZ1IHV"
      } ]
    },
    "geo" : { },
    "id_str" : "948029645676564480",
    "text" : "New Solar-Cell Wing Will Boost AeroVironment's Puma Drone | DronePilots - https:\/\/t.co\/IClLphoLRj #drones",
    "id" : 948029645676564480,
    "created_at" : "2018-01-02 03:14:15 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948036212526338049,
  "created_at" : "2018-01-02 03:40:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948036184441278464",
  "text" : "Wonder who has a good experience using Poloniex or 1Broker with autoview? Can you point to some good documentation for 1Broker's integration? Especially, given it is one of the more popular ones to use with it?",
  "id" : 948036184441278464,
  "created_at" : "2018-01-02 03:40:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/6yrNXPfI8x",
      "expanded_url" : "http:\/\/engt.co\/2DJLXHc",
      "display_url" : "engt.co\/2DJLXHc"
    } ]
  },
  "geo" : { },
  "id_str" : "948028132182851584",
  "text" : "RT @engadget: Adventurous OnePlus 5T owners can try Android Oreo https:\/\/t.co\/6yrNXPfI8x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/6yrNXPfI8x",
        "expanded_url" : "http:\/\/engt.co\/2DJLXHc",
        "display_url" : "engt.co\/2DJLXHc"
      } ]
    },
    "geo" : { },
    "id_str" : "947982502139920392",
    "text" : "Adventurous OnePlus 5T owners can try Android Oreo https:\/\/t.co\/6yrNXPfI8x",
    "id" : 947982502139920392,
    "created_at" : "2018-01-02 00:06:55 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 948028132182851584,
  "created_at" : "2018-01-02 03:08:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027914888589312",
  "text" : "RT @PhotographyTalk: There are plenty of great lenses out there that will get you good results without busting your budget.\n\nhttps:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/BGVtQLSmdS",
        "expanded_url" : "https:\/\/www.photographytalk.com\/beginner-photography-tips\/8160-need-a-lens-try-these-excellent-budget-options",
        "display_url" : "photographytalk.com\/beginner-photo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947853650185072642",
    "text" : "There are plenty of great lenses out there that will get you good results without busting your budget.\n\nhttps:\/\/t.co\/BGVtQLSmdS",
    "id" : 947853650185072642,
    "created_at" : "2018-01-01 15:34:55 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 948027914888589312,
  "created_at" : "2018-01-02 03:07:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027549745139712",
  "text" : "RT @neiltyson: Not that anybody\u2019s asked, but New Years Day on the Gregorian Calendar is a cosmically arbitrary event, carrying no Astronomi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947961917901066240",
    "text" : "Not that anybody\u2019s asked, but New Years Day on the Gregorian Calendar is a cosmically arbitrary event, carrying no Astronomical significance at all.",
    "id" : 947961917901066240,
    "created_at" : "2018-01-01 22:45:08 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 948027549745139712,
  "created_at" : "2018-01-02 03:05:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peyton Finch#\u20E31\u20E31\u20E3",
      "screen_name" : "ItsMeWesP_11",
      "indices" : [ 3, 16 ],
      "id_str" : "359492713",
      "id" : 359492713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027418358550531",
  "text" : "RT @ItsMeWesP_11: Why does it always feel like Jalen and Calvin Ridley don't practice together? They never on the same page",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "948025367280963584",
    "text" : "Why does it always feel like Jalen and Calvin Ridley don't practice together? They never on the same page",
    "id" : 948025367280963584,
    "created_at" : "2018-01-02 02:57:15 +0000",
    "user" : {
      "name" : "Peyton Finch#\u20E31\u20E31\u20E3",
      "screen_name" : "ItsMeWesP_11",
      "protected" : false,
      "id_str" : "359492713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808921478041370624\/9kxI4HFp_normal.jpg",
      "id" : 359492713,
      "verified" : false
    }
  },
  "id" : 948027418358550531,
  "created_at" : "2018-01-02 03:05:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027395357003777",
  "text" : "RT @dronepilots: Yeovil Town's game with Crawley Town stopped because of drone flying above Huish Park | DronePilots - https:\/\/t.co\/jTolppF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/jTolppF99W",
        "expanded_url" : "http:\/\/ift.tt\/2Cz79QE",
        "display_url" : "ift.tt\/2Cz79QE"
      } ]
    },
    "geo" : { },
    "id_str" : "947880031619084288",
    "text" : "Yeovil Town's game with Crawley Town stopped because of drone flying above Huish Park | DronePilots - https:\/\/t.co\/jTolppF99W #drones",
    "id" : 947880031619084288,
    "created_at" : "2018-01-01 17:19:44 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 948027395357003777,
  "created_at" : "2018-01-02 03:05:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027357348225025",
  "text" : "RT @Snapzu_Earth: \"Come forth into the light of things, let #nature be your teacher.\" - William Wordsworth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947905172373692418",
    "text" : "\"Come forth into the light of things, let #nature be your teacher.\" - William Wordsworth",
    "id" : 947905172373692418,
    "created_at" : "2018-01-01 18:59:38 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 948027357348225025,
  "created_at" : "2018-01-02 03:05:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948027287693414400",
  "text" : "I got to start getting my projects in order and life together. It is 2018 and I got so much improvement and stuff to catch up with. This week, I got to be grinding and trying hard. Like they say, it is the eye of the tiger and can't lose focus.",
  "id" : 948027287693414400,
  "created_at" : "2018-01-02 03:04:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/SyCQuUXtlW",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/top-20-sports-website-templates-and-wordpress-themes\/",
      "display_url" : "webdesigndev.com\/top-20-sports-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948026921203486721",
  "text" : "RT @WebDesignDev: Top 20 Sports Website Templates and WordPress Themes: https:\/\/t.co\/SyCQuUXtlW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/SyCQuUXtlW",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/top-20-sports-website-templates-and-wordpress-themes\/",
        "display_url" : "webdesigndev.com\/top-20-sports-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "948025313568665601",
    "text" : "Top 20 Sports Website Templates and WordPress Themes: https:\/\/t.co\/SyCQuUXtlW",
    "id" : 948025313568665601,
    "created_at" : "2018-01-02 02:57:02 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 948026921203486721,
  "created_at" : "2018-01-02 03:03:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "948026830426202112",
  "geo" : { },
  "id_str" : "948026887032406017",
  "in_reply_to_user_id" : 210979938,
  "text" : "He seemed nice at least ;)",
  "id" : 948026887032406017,
  "in_reply_to_status_id" : 948026830426202112,
  "created_at" : "2018-01-02 03:03:18 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "948026830426202112",
  "text" : "I got pulled over because I had snow on my licence plate and it \"wasn't legible\" on a snow day. He let me go with a verbal warning. Since, I was pulled over in the past, I think it is time to shave my beard, lol",
  "id" : 948026830426202112,
  "created_at" : "2018-01-02 03:03:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albert Breer",
      "screen_name" : "AlbertBreer",
      "indices" : [ 3, 15 ],
      "id_str" : "61830970",
      "id" : 61830970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947968736086122496",
  "text" : "RT @AlbertBreer: The Colts have been granted permission to interview Texans defensive coordinator Mike Vrabel, per source.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947942893989367808",
    "text" : "The Colts have been granted permission to interview Texans defensive coordinator Mike Vrabel, per source.",
    "id" : 947942893989367808,
    "created_at" : "2018-01-01 21:29:32 +0000",
    "user" : {
      "name" : "Albert Breer",
      "screen_name" : "AlbertBreer",
      "protected" : false,
      "id_str" : "61830970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790876378497421312\/s7gjQA45_normal.jpg",
      "id" : 61830970,
      "verified" : true
    }
  },
  "id" : 947968736086122496,
  "created_at" : "2018-01-01 23:12:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wick",
      "screen_name" : "ChrisWick_",
      "indices" : [ 3, 14 ],
      "id_str" : "3286790660",
      "id" : 3286790660
    }, {
      "name" : "Mohit Whabi",
      "screen_name" : "mohitwhabi",
      "indices" : [ 16, 27 ],
      "id_str" : "142056303",
      "id" : 142056303
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 28, 40 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Mike Thorp",
      "screen_name" : "MThorpXXi",
      "indices" : [ 41, 51 ],
      "id_str" : "36099075",
      "id" : 36099075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947968660819374084",
  "text" : "RT @ChrisWick_: @mohitwhabi @gamer456148 @MThorpXXi Happy New Year \uD83C\uDF89\uD83C\uDF8A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mohit Whabi",
        "screen_name" : "mohitwhabi",
        "indices" : [ 0, 11 ],
        "id_str" : "142056303",
        "id" : 142056303
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 12, 24 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Mike Thorp",
        "screen_name" : "MThorpXXi",
        "indices" : [ 25, 35 ],
        "id_str" : "36099075",
        "id" : 36099075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "947830044352811009",
    "geo" : { },
    "id_str" : "947918894408323072",
    "in_reply_to_user_id" : 142056303,
    "text" : "@mohitwhabi @gamer456148 @MThorpXXi Happy New Year \uD83C\uDF89\uD83C\uDF8A",
    "id" : 947918894408323072,
    "in_reply_to_status_id" : 947830044352811009,
    "created_at" : "2018-01-01 19:54:10 +0000",
    "in_reply_to_screen_name" : "mohitwhabi",
    "in_reply_to_user_id_str" : "142056303",
    "user" : {
      "name" : "Chris Wick",
      "screen_name" : "ChrisWick_",
      "protected" : false,
      "id_str" : "3286790660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920126430469488640\/OWmx4dNf_normal.jpg",
      "id" : 3286790660,
      "verified" : false
    }
  },
  "id" : 947968660819374084,
  "created_at" : "2018-01-01 23:11:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947968633568972800",
  "text" : "Need good autoview &amp; pinescript tutorials? Any suggestions? Made 10 alerts but none of them connects in the liveview?",
  "id" : 947968633568972800,
  "created_at" : "2018-01-01 23:11:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/zdSJQ9hyU0",
      "expanded_url" : "https:\/\/www.diyphotography.net\/take-peek-inside-sony-factory-see-make-alpha-a9\/",
      "display_url" : "diyphotography.net\/take-peek-insi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947968298674728960",
  "text" : "RT @JayHoque: Take a peek inside the Sony factory to see how they make the Alpha A9: https:\/\/t.co\/zdSJQ9hyU0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/zdSJQ9hyU0",
        "expanded_url" : "https:\/\/www.diyphotography.net\/take-peek-inside-sony-factory-see-make-alpha-a9\/",
        "display_url" : "diyphotography.net\/take-peek-insi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947789781345406978",
    "text" : "Take a peek inside the Sony factory to see how they make the Alpha A9: https:\/\/t.co\/zdSJQ9hyU0",
    "id" : 947789781345406978,
    "created_at" : "2018-01-01 11:21:07 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 947968298674728960,
  "created_at" : "2018-01-01 23:10:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kudzai",
      "screen_name" : "KudzaiMak",
      "indices" : [ 3, 13 ],
      "id_str" : "3121659333",
      "id" : 3121659333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947968283063578625",
  "text" : "RT @KudzaiMak: Hidden Figures is a brilliant film that will hopefully help to inspire more women into #STEM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947942094928318464",
    "text" : "Hidden Figures is a brilliant film that will hopefully help to inspire more women into #STEM",
    "id" : 947942094928318464,
    "created_at" : "2018-01-01 21:26:22 +0000",
    "user" : {
      "name" : "Kudzai",
      "screen_name" : "KudzaiMak",
      "protected" : false,
      "id_str" : "3121659333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745958081813745664\/xR5BglrO_normal.jpg",
      "id" : 3121659333,
      "verified" : false
    }
  },
  "id" : 947968283063578625,
  "created_at" : "2018-01-01 23:10:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/iW0g3SJbnA",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/XRPBTC\/QLCl5Jks-XRP-Alert-System-Trial\/",
      "display_url" : "tradingview.com\/chart\/XRPBTC\/Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947968017140367361",
  "text" : "XRP Alert System Trial - $XRPBTC chart https:\/\/t.co\/iW0g3SJbnA",
  "id" : 947968017140367361,
  "created_at" : "2018-01-01 23:09:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Merkle",
      "screen_name" : "themerklenews",
      "indices" : [ 3, 17 ],
      "id_str" : "2509810398",
      "id" : 2509810398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/XX34bFE8j8",
      "expanded_url" : "http:\/\/ift.tt\/2C5vTiF",
      "display_url" : "ift.tt\/2C5vTiF"
    } ]
  },
  "geo" : { },
  "id_str" : "947942620411715585",
  "text" : "RT @themerklenews: Bitcoin, Why You Should Own a Bit https:\/\/t.co\/XX34bFE8j8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/XX34bFE8j8",
        "expanded_url" : "http:\/\/ift.tt\/2C5vTiF",
        "display_url" : "ift.tt\/2C5vTiF"
      } ]
    },
    "geo" : { },
    "id_str" : "947855046997348353",
    "text" : "Bitcoin, Why You Should Own a Bit https:\/\/t.co\/XX34bFE8j8",
    "id" : 947855046997348353,
    "created_at" : "2018-01-01 15:40:28 +0000",
    "user" : {
      "name" : "The Merkle",
      "screen_name" : "themerklenews",
      "protected" : false,
      "id_str" : "2509810398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698794480435003392\/YDNq9nxJ_normal.png",
      "id" : 2509810398,
      "verified" : false
    }
  },
  "id" : 947942620411715585,
  "created_at" : "2018-01-01 21:28:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engr Sanni",
      "screen_name" : "K_tobiloba",
      "indices" : [ 3, 14 ],
      "id_str" : "608071569",
      "id" : 608071569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947942484482633730",
  "text" : "RT @K_tobiloba: I expected to work on my project this holiday. What's the title sef?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947933699059994624",
    "text" : "I expected to work on my project this holiday. What's the title sef?",
    "id" : 947933699059994624,
    "created_at" : "2018-01-01 20:53:00 +0000",
    "user" : {
      "name" : "Engr Sanni",
      "screen_name" : "K_tobiloba",
      "protected" : false,
      "id_str" : "608071569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/937274013755301888\/Y2bupyqH_normal.jpg",
      "id" : 608071569,
      "verified" : false
    }
  },
  "id" : 947942484482633730,
  "created_at" : "2018-01-01 21:27:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/9CwJf97chp",
      "expanded_url" : "http:\/\/engt.co\/2Czkc4G",
      "display_url" : "engt.co\/2Czkc4G"
    } ]
  },
  "geo" : { },
  "id_str" : "947942268564135936",
  "text" : "RT @engadget: Making your own waves in the 'Vortices' art installation https:\/\/t.co\/9CwJf97chp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/9CwJf97chp",
        "expanded_url" : "http:\/\/engt.co\/2Czkc4G",
        "display_url" : "engt.co\/2Czkc4G"
      } ]
    },
    "geo" : { },
    "id_str" : "947936710138134531",
    "text" : "Making your own waves in the 'Vortices' art installation https:\/\/t.co\/9CwJf97chp",
    "id" : 947936710138134531,
    "created_at" : "2018-01-01 21:04:58 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 947942268564135936,
  "created_at" : "2018-01-01 21:27:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fuNuiYNYX5",
      "expanded_url" : "https:\/\/fstoppers.com\/education\/practical-guide-processing-milky-way-landscape-photos-210130?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/education\/prac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947942239480745984",
  "text" : "RT @JayHoque: A Practical Guide to Processing the Milky Way in Landscape Photos: https:\/\/t.co\/fuNuiYNYX5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/fuNuiYNYX5",
        "expanded_url" : "https:\/\/fstoppers.com\/education\/practical-guide-processing-milky-way-landscape-photos-210130?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/education\/prac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947929482140233730",
    "text" : "A Practical Guide to Processing the Milky Way in Landscape Photos: https:\/\/t.co\/fuNuiYNYX5",
    "id" : 947929482140233730,
    "created_at" : "2018-01-01 20:36:14 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 947942239480745984,
  "created_at" : "2018-01-01 21:26:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KP [DELETE CONBASE]",
      "screen_name" : "_Kevin_Pham",
      "indices" : [ 3, 15 ],
      "id_str" : "2395318063",
      "id" : 2395318063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947942206266073089",
  "text" : "RT @_Kevin_Pham: My 2018 resolution is to move from \"hodling BTC\" to \"earning BTC.\" Starting with helping ethical and responsible Bitcoin b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947926476996755456",
    "text" : "My 2018 resolution is to move from \"hodling BTC\" to \"earning BTC.\" Starting with helping ethical and responsible Bitcoin businesses be successful.\n\nIf you're an ethical Bitcoin business and need my help telling you story, DMs are open.",
    "id" : 947926476996755456,
    "created_at" : "2018-01-01 20:24:18 +0000",
    "user" : {
      "name" : "KP [DELETE COINMARKETCAP]",
      "screen_name" : "_Kevin_Pham",
      "protected" : false,
      "id_str" : "2395318063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943269518318505984\/hB6TkL6P_normal.jpg",
      "id" : 2395318063,
      "verified" : false
    }
  },
  "id" : 947942206266073089,
  "created_at" : "2018-01-01 21:26:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947942139035516928",
  "text" : "RT @Snapzu_Earth: Did you know? The placement of the eyes of a donkey enables them to see all four of their legs at all times.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947929471306231808",
    "text" : "Did you know? The placement of the eyes of a donkey enables them to see all four of their legs at all times.",
    "id" : 947929471306231808,
    "created_at" : "2018-01-01 20:36:12 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 947942139035516928,
  "created_at" : "2018-01-01 21:26:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/sMtrvr38FB",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/15-brand-new-small-business-pre-built-websites\/",
      "display_url" : "webdesigndev.com\/15-brand-new-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947942118076665856",
  "text" : "RT @WebDesignDev: 15 Brand New Small Business Pre-Built Websites: https:\/\/t.co\/sMtrvr38FB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/sMtrvr38FB",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/15-brand-new-small-business-pre-built-websites\/",
        "display_url" : "webdesigndev.com\/15-brand-new-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947933870976126976",
    "text" : "15 Brand New Small Business Pre-Built Websites: https:\/\/t.co\/sMtrvr38FB",
    "id" : 947933870976126976,
    "created_at" : "2018-01-01 20:53:41 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 947942118076665856,
  "created_at" : "2018-01-01 21:26:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/947942100389302272\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/PDx47c2Sy5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DSfETJpVQAAiQVg.jpg",
      "id_str" : "947942079870615552",
      "id" : 947942079870615552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DSfETJpVQAAiQVg.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1572,
        "resize" : "fit",
        "w" : 2096
      } ],
      "display_url" : "pic.twitter.com\/PDx47c2Sy5"
    } ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947942100389302272",
  "text" : "This Tandoori Chicken pizza was smokin #foodie https:\/\/t.co\/PDx47c2Sy5",
  "id" : 947942100389302272,
  "created_at" : "2018-01-01 21:26:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herts Fire Control",
      "screen_name" : "HertsFRSControl",
      "indices" : [ 3, 19 ],
      "id_str" : "574646646",
      "id" : 574646646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947916533333884928",
  "text" : "RT @HertsFRSControl: Green Watch are preparing to hand over to Red Watch for the night shift. We will be back again at 8pm tomorrow night.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947914973858226176",
    "text" : "Green Watch are preparing to hand over to Red Watch for the night shift. We will be back again at 8pm tomorrow night. Enjoy your evening :-)",
    "id" : 947914973858226176,
    "created_at" : "2018-01-01 19:38:35 +0000",
    "user" : {
      "name" : "Herts Fire Control",
      "screen_name" : "HertsFRSControl",
      "protected" : false,
      "id_str" : "574646646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904681861384998912\/oRaphIVd_normal.jpg",
      "id" : 574646646,
      "verified" : true
    }
  },
  "id" : 947916533333884928,
  "created_at" : "2018-01-01 19:44:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947916482268291074",
  "text" : "RT @analyticbridge: Difference Between Data Scientists, Data Engineers, and Software Engineers - According To LinkedIn  https:\/\/t.co\/iAeP0P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/iAeP0P2ceI",
        "expanded_url" : "https:\/\/buff.ly\/2kFnbkm",
        "display_url" : "buff.ly\/2kFnbkm"
      } ]
    },
    "geo" : { },
    "id_str" : "947898980083687424",
    "text" : "Difference Between Data Scientists, Data Engineers, and Software Engineers - According To LinkedIn  https:\/\/t.co\/iAeP0P2ceI",
    "id" : 947898980083687424,
    "created_at" : "2018-01-01 18:35:02 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 947916482268291074,
  "created_at" : "2018-01-01 19:44:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947916425066352642",
  "text" : "RT @dronepilots: Yeovil vs Crawley clash stopped for 11 minutes after drone is spotted flying above Huish Park | DronePilots - https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 134, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/3iL90PdmLV",
        "expanded_url" : "http:\/\/ift.tt\/2CAyXUW",
        "display_url" : "ift.tt\/2CAyXUW"
      } ]
    },
    "geo" : { },
    "id_str" : "947907589895008257",
    "text" : "Yeovil vs Crawley clash stopped for 11 minutes after drone is spotted flying above Huish Park | DronePilots - https:\/\/t.co\/3iL90PdmLV #drones",
    "id" : 947907589895008257,
    "created_at" : "2018-01-01 19:09:15 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 947916425066352642,
  "created_at" : "2018-01-01 19:44:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/WiuRyuUtLC",
      "expanded_url" : "https:\/\/fstoppers.com\/originals\/build-rapport-your-photography-shoot-language-music-209984?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/originals\/buil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947916396440309760",
  "text" : "RT @JayHoque: Build Rapport on Your Photography Shoot With the Language of Music: https:\/\/t.co\/WiuRyuUtLC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/WiuRyuUtLC",
        "expanded_url" : "https:\/\/fstoppers.com\/originals\/build-rapport-your-photography-shoot-language-music-209984?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/originals\/buil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947915635274780672",
    "text" : "Build Rapport on Your Photography Shoot With the Language of Music: https:\/\/t.co\/WiuRyuUtLC",
    "id" : 947915635274780672,
    "created_at" : "2018-01-01 19:41:13 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 947916396440309760,
  "created_at" : "2018-01-01 19:44:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/igTKlgU7BY",
      "expanded_url" : "http:\/\/ift.tt\/2q9aDXN",
      "display_url" : "ift.tt\/2q9aDXN"
    } ]
  },
  "geo" : { },
  "id_str" : "947916381441454080",
  "text" : "RT @dronepilots: Got a drone? Not so fast flying it around Northwest Florida | DronePilots - https:\/\/t.co\/igTKlgU7BY #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/igTKlgU7BY",
        "expanded_url" : "http:\/\/ift.tt\/2q9aDXN",
        "display_url" : "ift.tt\/2q9aDXN"
      } ]
    },
    "geo" : { },
    "id_str" : "947911373870297088",
    "text" : "Got a drone? Not so fast flying it around Northwest Florida | DronePilots - https:\/\/t.co\/igTKlgU7BY #drones",
    "id" : 947911373870297088,
    "created_at" : "2018-01-01 19:24:17 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 947916381441454080,
  "created_at" : "2018-01-01 19:44:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "updates",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "DIY",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "STEM",
      "indices" : [ 140, 145 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947916280555810816",
  "text" : "Missed a day off going to the storage unit to work on my project, left me drill at home. Gotta go to work now, must try later #updates #DIY #STEM",
  "id" : 947916280555810816,
  "created_at" : "2018-01-01 19:43:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enterprise Learning",
      "screen_name" : "EnterpriseLearn",
      "indices" : [ 3, 19 ],
      "id_str" : "331722126",
      "id" : 331722126
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947898714835779586",
  "text" : "RT @EnterpriseLearn: Happy New Year 2018! What\u2019re your #STEM initiatives goals this year? We are so excited to create more innovations and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "STEM",
        "indices" : [ 139, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947890169990074368",
    "text" : "Happy New Year 2018! What\u2019re your #STEM initiatives goals this year? We are so excited to create more innovations and contributions to the #STEM world this year!",
    "id" : 947890169990074368,
    "created_at" : "2018-01-01 18:00:02 +0000",
    "user" : {
      "name" : "Enterprise Learning",
      "screen_name" : "EnterpriseLearn",
      "protected" : false,
      "id_str" : "331722126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418881931120353280\/3ImXHUm1_normal.jpeg",
      "id" : 331722126,
      "verified" : false
    }
  },
  "id" : 947898714835779586,
  "created_at" : "2018-01-01 18:33:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DG Quotes",
      "screen_name" : "DGquoter",
      "indices" : [ 3, 12 ],
      "id_str" : "840509398321631232",
      "id" : 840509398321631232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trust",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947898623702044674",
  "text" : "RT @DGquoter: Not everyone can be trusted. I think we all have to be very selective about the people we trust. #trust",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trust",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947724634375540739",
    "text" : "Not everyone can be trusted. I think we all have to be very selective about the people we trust. #trust",
    "id" : 947724634375540739,
    "created_at" : "2018-01-01 07:02:15 +0000",
    "user" : {
      "name" : "DG Quotes",
      "screen_name" : "DGquoter",
      "protected" : false,
      "id_str" : "840509398321631232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895933142229327872\/kBHult8D_normal.jpg",
      "id" : 840509398321631232,
      "verified" : false
    }
  },
  "id" : 947898623702044674,
  "created_at" : "2018-01-01 18:33:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "indices" : [ 3, 18 ],
      "id_str" : "2544598020",
      "id" : 2544598020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947898568802791424",
  "text" : "RT @Snapzu_Science: Daily Fact: J.B Dunlop was first to put air into tires.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947892793845755904",
    "text" : "Daily Fact: J.B Dunlop was first to put air into tires.",
    "id" : 947892793845755904,
    "created_at" : "2018-01-01 18:10:27 +0000",
    "user" : {
      "name" : "Snapzu Science",
      "screen_name" : "Snapzu_Science",
      "protected" : false,
      "id_str" : "2544598020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473969610463518720\/GqdLl9VN_normal.png",
      "id" : 2544598020,
      "verified" : false
    }
  },
  "id" : 947898568802791424,
  "created_at" : "2018-01-01 18:33:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Swift",
      "screen_name" : "JSwiftTWS",
      "indices" : [ 3, 13 ],
      "id_str" : "15146659",
      "id" : 15146659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "make2018amazing",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947898537358036992",
  "text" : "RT @JSwiftTWS: Unfollow that one account you've resisted because the person takes follows too seriously. #make2018amazing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "make2018amazing",
        "indices" : [ 90, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "947685889324527617",
    "text" : "Unfollow that one account you've resisted because the person takes follows too seriously. #make2018amazing",
    "id" : 947685889324527617,
    "created_at" : "2018-01-01 04:28:17 +0000",
    "user" : {
      "name" : "Jim Swift",
      "screen_name" : "JSwiftTWS",
      "protected" : false,
      "id_str" : "15146659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945999983936974848\/TIoUYbp2_normal.jpg",
      "id" : 15146659,
      "verified" : true
    }
  },
  "id" : 947898537358036992,
  "created_at" : "2018-01-01 18:33:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ALXIpDxhs4",
      "expanded_url" : "http:\/\/ift.tt\/2CzGtj2",
      "display_url" : "ift.tt\/2CzGtj2"
    } ]
  },
  "geo" : { },
  "id_str" : "947898476691689472",
  "text" : "RT @dronepilots: Got a drone? Not so fast flying it around Northwest Florida | DronePilots - https:\/\/t.co\/ALXIpDxhs4 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/ALXIpDxhs4",
        "expanded_url" : "http:\/\/ift.tt\/2CzGtj2",
        "display_url" : "ift.tt\/2CzGtj2"
      } ]
    },
    "geo" : { },
    "id_str" : "947895089732444164",
    "text" : "Got a drone? Not so fast flying it around Northwest Florida | DronePilots - https:\/\/t.co\/ALXIpDxhs4 #drones",
    "id" : 947895089732444164,
    "created_at" : "2018-01-01 18:19:35 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 947898476691689472,
  "created_at" : "2018-01-01 18:33:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/F4mRf58Zti",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/silverstone-sx500-g-psu,5278.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/silver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947898433804951553",
  "text" : "RT @tomshardware: \u25B8 SilverStone SX500-G PSU Review https:\/\/t.co\/F4mRf58Zti",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/F4mRf58Zti",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/silverstone-sx500-g-psu,5278.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/silver\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947832670913904640",
    "text" : "\u25B8 SilverStone SX500-G PSU Review https:\/\/t.co\/F4mRf58Zti",
    "id" : 947832670913904640,
    "created_at" : "2018-01-01 14:11:33 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 947898433804951553,
  "created_at" : "2018-01-01 18:32:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2tC8X2UrhK",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/20-awesome-templates-for-accessories-and-jewelry-shops\/",
      "display_url" : "webdesigndev.com\/20-awesome-tem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947898416155299845",
  "text" : "RT @WebDesignDev: 20+ Accessories Website Templates And WordPress Themes: https:\/\/t.co\/2tC8X2UrhK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/2tC8X2UrhK",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/20-awesome-templates-for-accessories-and-jewelry-shops\/",
        "display_url" : "webdesigndev.com\/20-awesome-tem\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947894580611084289",
    "text" : "20+ Accessories Website Templates And WordPress Themes: https:\/\/t.co\/2tC8X2UrhK",
    "id" : 947894580611084289,
    "created_at" : "2018-01-01 18:17:33 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 947898416155299845,
  "created_at" : "2018-01-01 18:32:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "947898315617849345",
  "geo" : { },
  "id_str" : "947898364124950533",
  "in_reply_to_user_id" : 210979938,
  "text" : "Lol, so spoiled",
  "id" : 947898364124950533,
  "in_reply_to_status_id" : 947898315617849345,
  "created_at" : "2018-01-01 18:32:35 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/947898315617849345\/video\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/gQwB9jRCM5",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/947898118489673728\/pu\/img\/XXEadgi2lfjhqpCy.jpg",
      "id_str" : "947898118489673728",
      "id" : 947898118489673728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/947898118489673728\/pu\/img\/XXEadgi2lfjhqpCy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/gQwB9jRCM5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947898315617849345",
  "text" : "She doesn't even thank you, just goes to the corner, eating her bone https:\/\/t.co\/gQwB9jRCM5",
  "id" : 947898315617849345,
  "created_at" : "2018-01-01 18:32:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/QOqUj3Rebi",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/10-minimalist-portfolio-websites\/",
      "display_url" : "webdesigndev.com\/10-minimalist-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947885613843435520",
  "text" : "RT @WebDesignDev: 10 Minimalist Portfolio Websites: https:\/\/t.co\/QOqUj3Rebi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/QOqUj3Rebi",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/10-minimalist-portfolio-websites\/",
        "display_url" : "webdesigndev.com\/10-minimalist-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947881523566571520",
    "text" : "10 Minimalist Portfolio Websites: https:\/\/t.co\/QOqUj3Rebi",
    "id" : 947881523566571520,
    "created_at" : "2018-01-01 17:25:40 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 947885613843435520,
  "created_at" : "2018-01-01 17:41:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Z2T635C1mk",
      "expanded_url" : "https:\/\/fstoppers.com\/originals\/real-world-nikon-d850-camera-review-ireland-210039?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/originals\/real\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "947885572592463878",
  "text" : "RT @JayHoque: The Real World Nikon D850 Camera Review in Ireland: https:\/\/t.co\/Z2T635C1mk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Z2T635C1mk",
        "expanded_url" : "https:\/\/fstoppers.com\/originals\/real-world-nikon-d850-camera-review-ireland-210039?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/originals\/real\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "947883013517529088",
    "text" : "The Real World Nikon D850 Camera Review in Ireland: https:\/\/t.co\/Z2T635C1mk",
    "id" : 947883013517529088,
    "created_at" : "2018-01-01 17:31:35 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 947885572592463878,
  "created_at" : "2018-01-01 17:41:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "indices" : [ 3, 11 ],
      "id_str" : "304857570",
      "id" : 304857570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pnyzFVEMnt",
      "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
      "display_url" : "ift.tt\/11IDdIl"
    } ]
  },
  "geo" : { },
  "id_str" : "947885462999519234",
  "text" : "RT @ChadUhl: NFL: Broncos inform head coach Vance Joseph he will return after 5-11 record in first season (ESPN) https:\/\/t.co\/pnyzFVEMnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/pnyzFVEMnt",
        "expanded_url" : "http:\/\/ift.tt\/11IDdIl",
        "display_url" : "ift.tt\/11IDdIl"
      } ]
    },
    "geo" : { },
    "id_str" : "947884345259413504",
    "text" : "NFL: Broncos inform head coach Vance Joseph he will return after 5-11 record in first season (ESPN) https:\/\/t.co\/pnyzFVEMnt",
    "id" : 947884345259413504,
    "created_at" : "2018-01-01 17:36:53 +0000",
    "user" : {
      "name" : "Chad",
      "screen_name" : "ChadUhl",
      "protected" : false,
      "id_str" : "304857570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688992808678506497\/rDcjGfuG_normal.jpg",
      "id" : 304857570,
      "verified" : false
    }
  },
  "id" : 947885462999519234,
  "created_at" : "2018-01-01 17:41:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "947885404472139776",
  "text" : "12 hours pass, already fails some New Year's resolutions...",
  "id" : 947885404472139776,
  "created_at" : "2018-01-01 17:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]