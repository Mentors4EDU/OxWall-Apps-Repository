Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418233514744504320",
  "text" : "Watched the encounter 3.7\/5 stars",
  "id" : 418233514744504320,
  "created_at" : "2014-01-01 04:13:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418151333938462720",
  "text" : "Had the burger now for some snacks, and GC, lol",
  "id" : 418151333938462720,
  "created_at" : "2013-12-31 22:47:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOOK OF WISDOM",
      "screen_name" : "bookofwisdom",
      "indices" : [ 3, 16 ],
      "id_str" : "103913301",
      "id" : 103913301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qeU71lpWlX",
      "expanded_url" : "http:\/\/bit.ly\/wgKPan",
      "display_url" : "bit.ly\/wgKPan"
    } ]
  },
  "geo" : { },
  "id_str" : "417833870419980289",
  "text" : "RT @bookofwisdom: \"Where there is matter, there is geometry.\" Johannes Kepler\nhttp:\/\/t.co\/qeU71lpWlX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/qeU71lpWlX",
        "expanded_url" : "http:\/\/bit.ly\/wgKPan",
        "display_url" : "bit.ly\/wgKPan"
      } ]
    },
    "geo" : { },
    "id_str" : "417577621338066944",
    "text" : "\"Where there is matter, there is geometry.\" Johannes Kepler\nhttp:\/\/t.co\/qeU71lpWlX",
    "id" : 417577621338066944,
    "created_at" : "2013-12-30 08:47:17 +0000",
    "user" : {
      "name" : "BOOK OF WISDOM",
      "screen_name" : "bookofwisdom",
      "protected" : false,
      "id_str" : "103913301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1960877334\/All-9-c_normal.jpg",
      "id" : 103913301,
      "verified" : false
    }
  },
  "id" : 417833870419980289,
  "created_at" : "2013-12-31 01:45:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheRealYokasB",
      "screen_name" : "TheRealYokasB",
      "indices" : [ 3, 17 ],
      "id_str" : "2757949046",
      "id" : 2757949046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417833749783396353",
  "text" : "RT @TheRealYokasB: The pain will not go away by ignoring it, you need to understand it, you need not cling to it, but be free of it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417833438268649472",
    "text" : "The pain will not go away by ignoring it, you need to understand it, you need not cling to it, but be free of it.",
    "id" : 417833438268649472,
    "created_at" : "2013-12-31 01:43:49 +0000",
    "user" : {
      "name" : "Yokas Boslarelli",
      "screen_name" : "YokasBoslarelli",
      "protected" : false,
      "id_str" : "242637589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877956420498591745\/IjNA_EQG_normal.jpg",
      "id" : 242637589,
      "verified" : false
    }
  },
  "id" : 417833749783396353,
  "created_at" : "2013-12-31 01:45:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417833575556186112",
  "text" : "Had melted goat cheese and bread, the burger joint is closed now :(",
  "id" : 417833575556186112,
  "created_at" : "2013-12-31 01:44:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417826249050836992",
  "text" : "Going to have a poorboy burger with onion rings and BBQ sauce, honestly 5\/5 burger",
  "id" : 417826249050836992,
  "created_at" : "2013-12-31 01:15:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417680841720881152",
  "text" : "Had melty goat cheese on garlic bread",
  "id" : 417680841720881152,
  "created_at" : "2013-12-30 15:37:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417442332339089408",
  "text" : "Had much food today Lol",
  "id" : 417442332339089408,
  "created_at" : "2013-12-29 23:49:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417105700314435584",
  "text" : "\"@ItsDonteiFrass: I don't have any energy for:\n\n\u25CF Meaningless friendships\n\u25CF Forced interactions\n\u25CF Unnecessary conversations.\" I'm antisocial",
  "id" : 417105700314435584,
  "created_at" : "2013-12-29 01:32:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheRealYokasB",
      "screen_name" : "TheRealYokasB",
      "indices" : [ 1, 15 ],
      "id_str" : "2757949046",
      "id" : 2757949046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417103990925852672",
  "text" : "\"@TheRealYokasB: I am not of the world, I just live in it.\" I hear you bro, lol",
  "id" : 417103990925852672,
  "created_at" : "2013-12-29 01:25:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "indices" : [ 3, 12 ],
      "id_str" : "14244304",
      "id" : 14244304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/UoHBy7MgmW",
      "expanded_url" : "http:\/\/bit.ly\/1gXRzQ3",
      "display_url" : "bit.ly\/1gXRzQ3"
    } ]
  },
  "geo" : { },
  "id_str" : "417103963348287488",
  "text" : "RT @evanderv: Want To Buy A Movie Ready Iron Man 3 Suit Of Armor? Not So Fast\u2026 http:\/\/t.co\/UoHBy7MgmW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ericvanderveer.com\" rel=\"nofollow\"\u003EEvandervTweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/UoHBy7MgmW",
        "expanded_url" : "http:\/\/bit.ly\/1gXRzQ3",
        "display_url" : "bit.ly\/1gXRzQ3"
      } ]
    },
    "geo" : { },
    "id_str" : "416014270368063488",
    "text" : "Want To Buy A Movie Ready Iron Man 3 Suit Of Armor? Not So Fast\u2026 http:\/\/t.co\/UoHBy7MgmW",
    "id" : 416014270368063488,
    "created_at" : "2013-12-26 01:15:05 +0000",
    "user" : {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "protected" : false,
      "id_str" : "14244304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1799520845\/eric_normal.jpg",
      "id" : 14244304,
      "verified" : false
    }
  },
  "id" : 417103963348287488,
  "created_at" : "2013-12-29 01:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417103963356663808",
  "text" : "RT @BestGamezUp: These Forsworn don\uFFFDt even have the decency to dress properly.\uFFFD - Marcurio (ES: Skyrim)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416014826323058688",
    "text" : "These Forsworn don\uFFFDt even have the decency to dress properly.\uFFFD - Marcurio (ES: Skyrim)",
    "id" : 416014826323058688,
    "created_at" : "2013-12-26 01:17:18 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 417103963356663808,
  "created_at" : "2013-12-29 01:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417103954468954112",
  "text" : "Had the tour of Italy at olive garden 3.42\/5",
  "id" : 417103954468954112,
  "created_at" : "2013-12-29 01:25:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416675131679719424",
  "text" : "Shaved",
  "id" : 416675131679719424,
  "created_at" : "2013-12-27 21:01:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416017044404834304",
  "text" : "Had a fun family reunion especially with the kids, lol",
  "id" : 416017044404834304,
  "created_at" : "2013-12-26 01:26:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415236927021785088",
  "text" : "I like food, lol",
  "id" : 415236927021785088,
  "created_at" : "2013-12-23 21:46:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414903569272156160",
  "text" : "Had such a nice day",
  "id" : 414903569272156160,
  "created_at" : "2013-12-22 23:41:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414863894746648576",
  "text" : "Greek yogurt doesn't taste better then regular yogurt, in my opinion.",
  "id" : 414863894746648576,
  "created_at" : "2013-12-22 21:03:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414861943216693248",
  "text" : "Went to the Coptic church today",
  "id" : 414861943216693248,
  "created_at" : "2013-12-22 20:56:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414450966566432768",
  "text" : "Had a double decker Reuben and hash browns at demitris 4.5\/5 stars, lol",
  "id" : 414450966566432768,
  "created_at" : "2013-12-21 17:43:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414227394073853952",
  "text" : "Had so much food this week, lol",
  "id" : 414227394073853952,
  "created_at" : "2013-12-21 02:54:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "full",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413935787655196673",
  "text" : "Had so much food #full",
  "id" : 413935787655196673,
  "created_at" : "2013-12-20 07:35:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/412082102864056320\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/PNiaPb9dbA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbgCfTeCYAA-j09.jpg",
      "id_str" : "412082102729859072",
      "id" : 412082102729859072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbgCfTeCYAA-j09.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/PNiaPb9dbA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412082102864056320",
  "text" : "Got a haircut at 5pm today, lol http:\/\/t.co\/PNiaPb9dbA",
  "id" : 412082102864056320,
  "created_at" : "2013-12-15 04:50:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411995527652208640",
  "text" : "Had an everything spicy subway. Lol",
  "id" : 411995527652208640,
  "created_at" : "2013-12-14 23:06:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410991647464624128",
  "text" : "I ate so much cheesy foods today, lol, including some melted goat cheese and hot pockets, it was delicious.",
  "id" : 410991647464624128,
  "created_at" : "2013-12-12 04:36:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409805136744026113",
  "text" : "Stress gets to you",
  "id" : 409805136744026113,
  "created_at" : "2013-12-08 22:02:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409523195981889536",
  "text" : "My first tweet on my new phone",
  "id" : 409523195981889536,
  "created_at" : "2013-12-08 03:21:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408701573465112576",
  "text" : "Frustrated :(",
  "id" : 408701573465112576,
  "created_at" : "2013-12-05 20:57:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408698058822537216",
  "text" : "Canned jelly taste nice!!!",
  "id" : 408698058822537216,
  "created_at" : "2013-12-05 20:43:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408690769839783937",
  "text" : ":) :D",
  "id" : 408690769839783937,
  "created_at" : "2013-12-05 20:14:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408690682447265795",
  "text" : "Food taste nice, lol",
  "id" : 408690682447265795,
  "created_at" : "2013-12-05 20:13:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408690606601674752",
  "text" : "If I had mustard and coleslaw the slap would have been a masterpiece, add ghost pepper extract make it a real slap, lol",
  "id" : 408690606601674752,
  "created_at" : "2013-12-05 20:13:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/nlhUHt5mUe",
      "expanded_url" : "http:\/\/sdrv.ms\/1kcC6sr",
      "display_url" : "sdrv.ms\/1kcC6sr"
    } ]
  },
  "geo" : { },
  "id_str" : "408402820333707264",
  "text" : "The southwest slap http:\/\/t.co\/nlhUHt5mUe",
  "id" : 408402820333707264,
  "created_at" : "2013-12-05 01:09:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408067099500609536",
  "text" : "I like food, you like food, we all like food, lol",
  "id" : 408067099500609536,
  "created_at" : "2013-12-04 02:55:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/407785547818479617\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hVoZ5bKKz8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bai-y5LCMAAP-SH.jpg",
      "id_str" : "407785547826868224",
      "id" : 407785547826868224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bai-y5LCMAAP-SH.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hVoZ5bKKz8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407785547818479617",
  "text" : "It is a shame our talk show got such low IMDB votes, guess there aren't many Coptic Christian believers in this world http:\/\/t.co\/hVoZ5bKKz8",
  "id" : 407785547818479617,
  "created_at" : "2013-12-03 08:17:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407625535133454336",
  "text" : "My phone was supposed to come today, instead I got a redelivery slip with bad handwriting",
  "id" : 407625535133454336,
  "created_at" : "2013-12-02 21:41:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407300934578864130",
  "text" : "When something gets two big it turns to something worse, ugh, parents",
  "id" : 407300934578864130,
  "created_at" : "2013-12-02 00:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]