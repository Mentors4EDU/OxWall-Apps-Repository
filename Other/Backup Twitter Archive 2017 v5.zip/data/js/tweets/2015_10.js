Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659570642770112512",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump Is right on the utter insanity of Gun Control and Gun-Free zones #GOPDebate",
  "id" : 659570642770112512,
  "created_at" : "2015-10-29 03:21:10 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/659007917111320576\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/wyS4MGdYhH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVENMBWEAAt9-7.jpg",
      "id_str" : "659007913835499520",
      "id" : 659007913835499520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVENMBWEAAt9-7.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 555,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wyS4MGdYhH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/lCUXnbP272",
      "expanded_url" : "http:\/\/engt.co\/1MpnOII",
      "display_url" : "engt.co\/1MpnOII"
    } ]
  },
  "geo" : { },
  "id_str" : "659013312991133696",
  "text" : "RT @engadget: 'Uncharted' borrows from cinema to sidestep clunky game design https:\/\/t.co\/lCUXnbP272 https:\/\/t.co\/wyS4MGdYhH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.aol.com\" rel=\"nofollow\"\u003EAOL Blogsmith\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/659007917111320576\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/wyS4MGdYhH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVENMBWEAAt9-7.jpg",
        "id_str" : "659007913835499520",
        "id" : 659007913835499520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVENMBWEAAt9-7.jpg",
        "sizes" : [ {
          "h" : 650,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 555,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wyS4MGdYhH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/lCUXnbP272",
        "expanded_url" : "http:\/\/engt.co\/1MpnOII",
        "display_url" : "engt.co\/1MpnOII"
      } ]
    },
    "geo" : { },
    "id_str" : "659007917111320576",
    "text" : "'Uncharted' borrows from cinema to sidestep clunky game design https:\/\/t.co\/lCUXnbP272 https:\/\/t.co\/wyS4MGdYhH",
    "id" : 659007917111320576,
    "created_at" : "2015-10-27 14:05:05 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 659013312991133696,
  "created_at" : "2015-10-27 14:26:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland U Student",
      "screen_name" : "An_OU_Student",
      "indices" : [ 3, 17 ],
      "id_str" : "2900716968",
      "id" : 2900716968
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659012828809007105",
  "text" : "RT @An_OU_Student: @gamer456148 yes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "658835364786868224",
    "geo" : { },
    "id_str" : "659012034084909056",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 yes.",
    "id" : 659012034084909056,
    "in_reply_to_status_id" : 658835364786868224,
    "created_at" : "2015-10-27 14:21:27 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Oakland U Student",
      "screen_name" : "An_OU_Student",
      "protected" : false,
      "id_str" : "2900716968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819996902766874624\/GI1fJvEF_normal.jpg",
      "id" : 2900716968,
      "verified" : false
    }
  },
  "id" : 659012828809007105,
  "created_at" : "2015-10-27 14:24:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "indices" : [ 0, 15 ],
      "id_str" : "1523963450",
      "id" : 1523963450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644904580631920640",
  "geo" : { },
  "id_str" : "659012780960436224",
  "in_reply_to_user_id" : 1523963450,
  "text" : "@danielleakrawi They are called Storm Troopers.",
  "id" : 659012780960436224,
  "in_reply_to_status_id" : 644904580631920640,
  "created_at" : "2015-10-27 14:24:25 +0000",
  "in_reply_to_screen_name" : "danielleakrawi",
  "in_reply_to_user_id_str" : "1523963450",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessi\uD83D\uDC51",
      "screen_name" : "heyy_jessay22",
      "indices" : [ 0, 14 ],
      "id_str" : "1349097163",
      "id" : 1349097163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658841605231742976",
  "geo" : { },
  "id_str" : "659011496698073088",
  "in_reply_to_user_id" : 1349097163,
  "text" : "@heyy_jessay22 I feel so bad for you :(",
  "id" : 659011496698073088,
  "in_reply_to_status_id" : 658841605231742976,
  "created_at" : "2015-10-27 14:19:19 +0000",
  "in_reply_to_screen_name" : "heyy_jessay22",
  "in_reply_to_user_id_str" : "1349097163",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland U Student",
      "screen_name" : "An_OU_Student",
      "indices" : [ 0, 14 ],
      "id_str" : "2900716968",
      "id" : 2900716968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655914487535550464",
  "geo" : { },
  "id_str" : "658835364786868224",
  "in_reply_to_user_id" : 2900716968,
  "text" : "@An_OU_Student So that's why the police where there??? \uD83D\uDE27",
  "id" : 658835364786868224,
  "in_reply_to_status_id" : 655914487535550464,
  "created_at" : "2015-10-27 02:39:26 +0000",
  "in_reply_to_screen_name" : "An_OU_Student",
  "in_reply_to_user_id_str" : "2900716968",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658833802937135104",
  "text" : "RT @HelloRyanHolmes: Confidence is key",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653681870144606208",
    "text" : "Confidence is key",
    "id" : 653681870144606208,
    "created_at" : "2015-10-12 21:21:17 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854042008058462208\/qK3tEZDX_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 658833802937135104,
  "created_at" : "2015-10-27 02:33:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658833082976501762",
  "text" : "RT @HelloRyanHolmes: Need to organize my social medias.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655986852688596992",
    "text" : "Need to organize my social medias.",
    "id" : 655986852688596992,
    "created_at" : "2015-10-19 06:00:27 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854042008058462208\/qK3tEZDX_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 658833082976501762,
  "created_at" : "2015-10-27 02:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "indices" : [ 3, 18 ],
      "id_str" : "1523963450",
      "id" : 1523963450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658831766640308224",
  "text" : "RT @danielleakrawi: Was really nice to just have breakfast by myself, read the Bible, and drink coffee \uD83D\uDE0C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658285845330403328",
    "text" : "Was really nice to just have breakfast by myself, read the Bible, and drink coffee \uD83D\uDE0C",
    "id" : 658285845330403328,
    "created_at" : "2015-10-25 14:15:50 +0000",
    "user" : {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "protected" : false,
      "id_str" : "1523963450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836570803886047233\/CK7FyMaP_normal.jpg",
      "id" : 1523963450,
      "verified" : false
    }
  },
  "id" : 658831766640308224,
  "created_at" : "2015-10-27 02:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "indices" : [ 3, 18 ],
      "id_str" : "1523963450",
      "id" : 1523963450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658831564256780288",
  "text" : "RT @danielleakrawi: Have people really changed the end of their wedding vows from \"...till death do us part\" to \"...as long as our love sha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658316585782935552",
    "text" : "Have people really changed the end of their wedding vows from \"...till death do us part\" to \"...as long as our love shall last\"? Ridiculous.",
    "id" : 658316585782935552,
    "created_at" : "2015-10-25 16:17:59 +0000",
    "user" : {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "protected" : false,
      "id_str" : "1523963450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836570803886047233\/CK7FyMaP_normal.jpg",
      "id" : 1523963450,
      "verified" : false
    }
  },
  "id" : 658831564256780288,
  "created_at" : "2015-10-27 02:24:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Soverign Monarch",
      "screen_name" : "mills_mayor",
      "indices" : [ 3, 15 ],
      "id_str" : "2620461124",
      "id" : 2620461124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658831148378902528",
  "text" : "RT @mills_mayor: Making small talk about how bad parking is on campus #ThisIsOU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThisIsOU",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644997428366704640",
    "text" : "Making small talk about how bad parking is on campus #ThisIsOU",
    "id" : 644997428366704640,
    "created_at" : "2015-09-18 22:12:25 +0000",
    "user" : {
      "name" : "The Soverign Monarch",
      "screen_name" : "mills_mayor",
      "protected" : false,
      "id_str" : "2620461124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479300631925370881\/3m7R1H_1_normal.jpeg",
      "id" : 2620461124,
      "verified" : false
    }
  },
  "id" : 658831148378902528,
  "created_at" : "2015-10-27 02:22:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658825665521799168",
  "text" : "RT @Fact: An ugly personality can easily destroy a pretty face.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658742483602509824",
    "text" : "An ugly personality can easily destroy a pretty face.",
    "id" : 658742483602509824,
    "created_at" : "2015-10-26 20:30:21 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 658825665521799168,
  "created_at" : "2015-10-27 02:00:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658748481864114176",
  "geo" : { },
  "id_str" : "658825561129750528",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact True",
  "id" : 658825561129750528,
  "in_reply_to_status_id" : 658748481864114176,
  "created_at" : "2015-10-27 02:00:28 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658751495328964608",
  "geo" : { },
  "id_str" : "658825493786021888",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact Why humanity? Why? Just why?",
  "id" : 658825493786021888,
  "in_reply_to_status_id" : 658751495328964608,
  "created_at" : "2015-10-27 02:00:12 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658814384697946112",
  "geo" : { },
  "id_str" : "658824656598736896",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact This one I would agree on",
  "id" : 658824656598736896,
  "in_reply_to_status_id" : 658814384697946112,
  "created_at" : "2015-10-27 01:56:53 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658822438789054464",
  "geo" : { },
  "id_str" : "658824463715344384",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact Arrogance is never good for mental health. Never focus on the self.",
  "id" : 658824463715344384,
  "in_reply_to_status_id" : 658822438789054464,
  "created_at" : "2015-10-27 01:56:07 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/658824250321731585\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/nFR4kLdRCp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSSdKRMU8AASGrc.jpg",
      "id_str" : "658824245242294272",
      "id" : 658824245242294272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSSdKRMU8AASGrc.jpg",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 632
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 632
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nFR4kLdRCp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658824250321731585",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Hey Ryan I think you might have made a small marginal spelling error in your title. \uD83D\uDE02 https:\/\/t.co\/nFR4kLdRCp",
  "id" : 658824250321731585,
  "created_at" : "2015-10-27 01:55:16 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/658751415792242688\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/ixQ21oE81B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRa6qDUYAA1KfS.jpg",
      "id_str" : "658751409270054912",
      "id" : 658751409270054912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRa6qDUYAA1KfS.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ixQ21oE81B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658751415792242688",
  "text" : "My new car https:\/\/t.co\/ixQ21oE81B",
  "id" : 658751415792242688,
  "created_at" : "2015-10-26 21:05:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 16, 25 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658345574328983552",
  "geo" : { },
  "id_str" : "658345920761753600",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @mashable I liked it more when Mashable was covering just Tech",
  "id" : 658345920761753600,
  "in_reply_to_status_id" : 658345574328983552,
  "created_at" : "2015-10-25 18:14:33 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirb \uD83C\uDF0E",
      "screen_name" : "KirbyPuckettJr_",
      "indices" : [ 3, 19 ],
      "id_str" : "532839886",
      "id" : 532839886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658345586781917184",
  "text" : "RT @KirbyPuckettJr_: RIP Flip Saunders",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658345448827056128",
    "text" : "RIP Flip Saunders",
    "id" : 658345448827056128,
    "created_at" : "2015-10-25 18:12:41 +0000",
    "user" : {
      "name" : "Kirb \uD83C\uDF0E",
      "screen_name" : "KirbyPuckettJr_",
      "protected" : false,
      "id_str" : "532839886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625402797593223168\/QLFzhmd-_normal.jpg",
      "id" : 532839886,
      "verified" : false
    }
  },
  "id" : 658345586781917184,
  "created_at" : "2015-10-25 18:13:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 0, 11 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658345292471914497",
  "geo" : { },
  "id_str" : "658345433694007296",
  "in_reply_to_user_id" : 305791165,
  "text" : "@WWEXStream That's the stuff",
  "id" : 658345433694007296,
  "in_reply_to_status_id" : 658345292471914497,
  "created_at" : "2015-10-25 18:12:37 +0000",
  "in_reply_to_screen_name" : "WWEXStream",
  "in_reply_to_user_id_str" : "305791165",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658337578190512128",
  "text" : "RT @copticworld: Pope Tawadros II Baptizes 3 Babies at St Mary &amp; St John Church in Pleasanton, California: Pope Tawadros\u2026 https:\/\/t.co\/4hZc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HHPT2inUSA",
        "indices" : [ 133, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/4hZcAEOO9l",
        "expanded_url" : "http:\/\/dlvr.it\/CY7fKX",
        "display_url" : "dlvr.it\/CY7fKX"
      } ]
    },
    "geo" : { },
    "id_str" : "658336739170254848",
    "text" : "Pope Tawadros II Baptizes 3 Babies at St Mary &amp; St John Church in Pleasanton, California: Pope Tawadros\u2026 https:\/\/t.co\/4hZcAEOO9l #HHPT2inUSA",
    "id" : 658336739170254848,
    "created_at" : "2015-10-25 17:38:04 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 658337578190512128,
  "created_at" : "2015-10-25 17:41:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658306068003627009",
  "geo" : { },
  "id_str" : "658337215941095425",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact Ironic you say that. I prefer twitter's interface more but Facebook more for marketing analytics.",
  "id" : 658337215941095425,
  "in_reply_to_status_id" : 658306068003627009,
  "created_at" : "2015-10-25 17:39:58 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658309118609006594",
  "geo" : { },
  "id_str" : "658336906871222272",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact That reminds me of the brilliance of Edison or the ingenuity of Tesla",
  "id" : 658336906871222272,
  "in_reply_to_status_id" : 658309118609006594,
  "created_at" : "2015-10-25 17:38:44 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658324192295788544",
  "geo" : { },
  "id_str" : "658336514426957824",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact I guess that is a standard definition on human nature. Utter pride an arrogance.",
  "id" : 658336514426957824,
  "in_reply_to_status_id" : 658324192295788544,
  "created_at" : "2015-10-25 17:37:10 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658336393035448320",
  "text" : "RT @Fact: The number one predictor that you will find meaning in your job is the belief that what you do positively impacts others, a study\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658325407318433792",
    "text" : "The number one predictor that you will find meaning in your job is the belief that what you do positively impacts others, a study finds.",
    "id" : 658325407318433792,
    "created_at" : "2015-10-25 16:53:02 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 658336393035448320,
  "created_at" : "2015-10-25 17:36:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658336308721524736",
  "text" : "RT @Fact: When you're alone, you think. When you think, you remember. When you remember, you feel pain. - Psychological Fact",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658328688166064128",
    "text" : "When you're alone, you think. When you think, you remember. When you remember, you feel pain. - Psychological Fact",
    "id" : 658328688166064128,
    "created_at" : "2015-10-25 17:06:05 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 658336308721524736,
  "created_at" : "2015-10-25 17:36:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 0, 5 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658303007545806848",
  "geo" : { },
  "id_str" : "658336158775156737",
  "in_reply_to_user_id" : 2425231,
  "text" : "@Fact Probably some interesting precautions.",
  "id" : 658336158775156737,
  "in_reply_to_status_id" : 658303007545806848,
  "created_at" : "2015-10-25 17:35:46 +0000",
  "in_reply_to_screen_name" : "Fact",
  "in_reply_to_user_id_str" : "2425231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Diggs",
      "screen_name" : "CTDGRAPHICMAN",
      "indices" : [ 0, 14 ],
      "id_str" : "88804144",
      "id" : 88804144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IT",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658335494816665600",
  "geo" : { },
  "id_str" : "658335938435747840",
  "in_reply_to_user_id" : 88804144,
  "text" : "@CTDGRAPHICMAN Not that bad of a design, needs to be more user friendly though. For screen caps though, I recommend using Bandicam #IT",
  "id" : 658335938435747840,
  "in_reply_to_status_id" : 658335494816665600,
  "created_at" : "2015-10-25 17:34:53 +0000",
  "in_reply_to_screen_name" : "CTDGRAPHICMAN",
  "in_reply_to_user_id_str" : "88804144",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658111677716672513",
  "geo" : { },
  "id_str" : "658112637516062720",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Wait what???",
  "id" : 658112637516062720,
  "in_reply_to_status_id" : 658111677716672513,
  "created_at" : "2015-10-25 02:47:34 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/658111663829295105\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/t6fYyn62V4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CSIVEiCWwAAgO5X.png",
      "id_str" : "658111663149858816",
      "id" : 658111663149858816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CSIVEiCWwAAgO5X.png",
      "sizes" : [ {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t6fYyn62V4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658112564916801536",
  "text" : "RT @rockindigo: 88 miles per hour! https:\/\/t.co\/t6fYyn62V4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/658111663829295105\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/t6fYyn62V4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CSIVEiCWwAAgO5X.png",
        "id_str" : "658111663149858816",
        "id" : 658111663149858816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CSIVEiCWwAAgO5X.png",
        "sizes" : [ {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/t6fYyn62V4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658111663829295105",
    "text" : "88 miles per hour! https:\/\/t.co\/t6fYyn62V4",
    "id" : 658111663829295105,
    "created_at" : "2015-10-25 02:43:42 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 658112564916801536,
  "created_at" : "2015-10-25 02:47:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 16, 30 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658071217933565952",
  "geo" : { },
  "id_str" : "658110986184994816",
  "in_reply_to_user_id" : 2727090457,
  "text" : "@Sexxandbottles @SexxAndBlunts Your tweets make me loose sight on humanity, you should be ASHAMED",
  "id" : 658110986184994816,
  "in_reply_to_status_id" : 658071217933565952,
  "created_at" : "2015-10-25 02:41:00 +0000",
  "in_reply_to_screen_name" : "Iustfuck",
  "in_reply_to_user_id_str" : "2727090457",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zakaria Ahmed",
      "screen_name" : "DaRealZAK",
      "indices" : [ 0, 10 ],
      "id_str" : "237353027",
      "id" : 237353027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658107729685254144",
  "geo" : { },
  "id_str" : "658110638770814976",
  "in_reply_to_user_id" : 237353027,
  "text" : "@DaRealZAK That reference was absolutely disgusting and degrading to woman",
  "id" : 658110638770814976,
  "in_reply_to_status_id" : 658107729685254144,
  "created_at" : "2015-10-25 02:39:38 +0000",
  "in_reply_to_screen_name" : "DaRealZAK",
  "in_reply_to_user_id_str" : "237353027",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duane Patterson",
      "screen_name" : "Radioblogger",
      "indices" : [ 3, 16 ],
      "id_str" : "17850012",
      "id" : 17850012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658109329615245313",
  "text" : "RT @Radioblogger: HRC: Sid's credibility wasn't as important to me. He wasn't advising me. Reality: Keep it coming, Sid. He's a close frien\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657241884230729728",
    "text" : "HRC: Sid's credibility wasn't as important to me. He wasn't advising me. Reality: Keep it coming, Sid. He's a close friend.",
    "id" : 657241884230729728,
    "created_at" : "2015-10-22 17:07:30 +0000",
    "user" : {
      "name" : "Duane Patterson",
      "screen_name" : "Radioblogger",
      "protected" : false,
      "id_str" : "17850012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668337092552843265\/dYkkp7qJ_normal.jpg",
      "id" : 17850012,
      "verified" : true
    }
  },
  "id" : 658109329615245313,
  "created_at" : "2015-10-25 02:34:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "indices" : [ 3, 19 ],
      "id_str" : "290594346",
      "id" : 290594346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658108793226702848",
  "text" : "RT @Karynne_Summars: Procrastination is a fear of failure or success.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657240417440808961",
    "text" : "Procrastination is a fear of failure or success.",
    "id" : 657240417440808961,
    "created_at" : "2015-10-22 17:01:41 +0000",
    "user" : {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "protected" : false,
      "id_str" : "290594346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702662666960023552\/qIla4_S8_normal.jpg",
      "id" : 290594346,
      "verified" : false
    }
  },
  "id" : 658108793226702848,
  "created_at" : "2015-10-25 02:32:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 43, 55 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Startup",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/hokBKR4YP3",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/ch8OJ",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658108730693808128",
  "text" : "RT @CouponTrump: #Startup Hackathon 101 by @gamer456148 Just $9 https:\/\/t.co\/hokBKR4YP3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 26, 38 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Startup",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/hokBKR4YP3",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/ch8OJ",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657327021903757312",
    "text" : "#Startup Hackathon 101 by @gamer456148 Just $9 https:\/\/t.co\/hokBKR4YP3",
    "id" : 657327021903757312,
    "created_at" : "2015-10-22 22:45:49 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 658108730693808128,
  "created_at" : "2015-10-25 02:32:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657242415309430784",
  "text" : "Learned something new #ThisIsOU",
  "id" : 657242415309430784,
  "created_at" : "2015-10-22 17:09:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 41, 53 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/e5prThyUnh",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/Wh1SF",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657242231477248000",
  "text" : "RT @CouponTrump: Intro to Construct 2 by @gamer456148 Just $9 https:\/\/t.co\/e5prThyUnh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 24, 36 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/e5prThyUnh",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/Wh1SF",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657125623014498304",
    "text" : "Intro to Construct 2 by @gamer456148 Just $9 https:\/\/t.co\/e5prThyUnh",
    "id" : 657125623014498304,
    "created_at" : "2015-10-22 09:25:31 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 657242231477248000,
  "created_at" : "2015-10-22 17:08:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 51, 63 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/GVLw69aI0m",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/AVMsB",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656869898950455296",
  "text" : "RT @CouponTrump: Common Core Math Concepts: K-8 by @gamer456148 Just $9 https:\/\/t.co\/GVLw69aI0m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 34, 46 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/GVLw69aI0m",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/AVMsB",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656845111406497792",
    "text" : "Common Core Math Concepts: K-8 by @gamer456148 Just $9 https:\/\/t.co\/GVLw69aI0m",
    "id" : 656845111406497792,
    "created_at" : "2015-10-21 14:50:52 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 656869898950455296,
  "created_at" : "2015-10-21 16:29:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656869731920670720",
  "text" : "It's back to the future day!!!!",
  "id" : 656869731920670720,
  "created_at" : "2015-10-21 16:28:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chau Tu",
      "screen_name" : "chaubtu",
      "indices" : [ 3, 11 ],
      "id_str" : "449501607",
      "id" : 449501607
    }, {
      "name" : "The Takeaway\uD83C\uDF99",
      "screen_name" : "TheTakeaway",
      "indices" : [ 13, 25 ],
      "id_str" : "14552720",
      "id" : 14552720
    }, {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 26, 33 ],
      "id_str" : "16817883",
      "id" : 16817883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/mERrL3j586",
      "expanded_url" : "http:\/\/qz.com\/529806\/nike-has-made-the-self-lacing-sneakers-from-back-to-the-future-part-ii\/",
      "display_url" : "qz.com\/529806\/nike-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656869604673912832",
  "text" : "RT @chaubtu: @TheTakeaway @scifri !! https:\/\/t.co\/mERrL3j586",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Takeaway\uD83C\uDF99",
        "screen_name" : "TheTakeaway",
        "indices" : [ 0, 12 ],
        "id_str" : "14552720",
        "id" : 14552720
      }, {
        "name" : "Science Friday",
        "screen_name" : "scifri",
        "indices" : [ 13, 20 ],
        "id_str" : "16817883",
        "id" : 16817883
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/mERrL3j586",
        "expanded_url" : "http:\/\/qz.com\/529806\/nike-has-made-the-self-lacing-sneakers-from-back-to-the-future-part-ii\/",
        "display_url" : "qz.com\/529806\/nike-ha\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "656856259484897280",
    "geo" : { },
    "id_str" : "656866387869245440",
    "in_reply_to_user_id" : 14552720,
    "text" : "@TheTakeaway @scifri !! https:\/\/t.co\/mERrL3j586",
    "id" : 656866387869245440,
    "in_reply_to_status_id" : 656856259484897280,
    "created_at" : "2015-10-21 16:15:25 +0000",
    "in_reply_to_screen_name" : "TheTakeaway",
    "in_reply_to_user_id_str" : "14552720",
    "user" : {
      "name" : "Chau Tu",
      "screen_name" : "chaubtu",
      "protected" : false,
      "id_str" : "449501607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599266264666746880\/483hHWmM_normal.jpg",
      "id" : 449501607,
      "verified" : true
    }
  },
  "id" : 656869604673912832,
  "created_at" : "2015-10-21 16:28:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Cooke",
      "screen_name" : "dannycooke",
      "indices" : [ 3, 14 ],
      "id_str" : "194032271",
      "id" : 194032271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/XUxCbMm7gc",
      "expanded_url" : "https:\/\/youtu.be\/xFyY7_hc-14",
      "display_url" : "youtu.be\/xFyY7_hc-14"
    } ]
  },
  "geo" : { },
  "id_str" : "656869535560146944",
  "text" : "RT @dannycooke: Fueled by the Future | Back to the Future | Presented by Toyota Mirai https:\/\/t.co\/XUxCbMm7gc via YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/XUxCbMm7gc",
        "expanded_url" : "https:\/\/youtu.be\/xFyY7_hc-14",
        "display_url" : "youtu.be\/xFyY7_hc-14"
      } ]
    },
    "geo" : { },
    "id_str" : "656868917865029632",
    "text" : "Fueled by the Future | Back to the Future | Presented by Toyota Mirai https:\/\/t.co\/XUxCbMm7gc via YouTube",
    "id" : 656868917865029632,
    "created_at" : "2015-10-21 16:25:28 +0000",
    "user" : {
      "name" : "Danny Cooke",
      "screen_name" : "dannycooke",
      "protected" : false,
      "id_str" : "194032271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837332154610774016\/kQckkexO_normal.jpg",
      "id" : 194032271,
      "verified" : false
    }
  },
  "id" : 656869535560146944,
  "created_at" : "2015-10-21 16:27:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/656868662582857729\/photo\/1",
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/v2M2h5bTmy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR2qjfvUYAAcZBc.jpg",
      "id_str" : "656868647458070528",
      "id" : 656868647458070528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR2qjfvUYAAcZBc.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v2M2h5bTmy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656868662582857729",
  "text" : "Cake!!!! https:\/\/t.co\/v2M2h5bTmy",
  "id" : 656868662582857729,
  "created_at" : "2015-10-21 16:24:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Smores",
      "indices" : [ 8, 15 ]
    }, {
      "text" : "OU",
      "indices" : [ 41, 44 ]
    }, {
      "text" : "ThisIsOU",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656823705818021888",
  "text" : "I had a #Smores Rice Crispy treat at the #OU bake sale today for the biomedical society #ThisIsOU",
  "id" : 656823705818021888,
  "created_at" : "2015-10-21 13:25:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 0, 11 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656792590034083840",
  "geo" : { },
  "id_str" : "656793084802527232",
  "in_reply_to_user_id" : 305791165,
  "text" : "@WWEXStream But what is he doing?",
  "id" : 656793084802527232,
  "in_reply_to_status_id" : 656792590034083840,
  "created_at" : "2015-10-21 11:24:08 +0000",
  "in_reply_to_screen_name" : "WWEXStream",
  "in_reply_to_user_id_str" : "305791165",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 3, 14 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/kXQUl32qAH",
      "expanded_url" : "http:\/\/vine.co\/v\/blVpO39FPTd",
      "display_url" : "vine.co\/v\/blVpO39FPTd"
    } ]
  },
  "geo" : { },
  "id_str" : "656793026547830784",
  "text" : "RT @WWEXStream: Amazing Trick Shot: https:\/\/t.co\/kXQUl32qAH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/kXQUl32qAH",
        "expanded_url" : "http:\/\/vine.co\/v\/blVpO39FPTd",
        "display_url" : "vine.co\/v\/blVpO39FPTd"
      } ]
    },
    "geo" : { },
    "id_str" : "656792590034083840",
    "text" : "Amazing Trick Shot: https:\/\/t.co\/kXQUl32qAH",
    "id" : 656792590034083840,
    "created_at" : "2015-10-21 11:22:10 +0000",
    "user" : {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "protected" : false,
      "id_str" : "305791165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465976113496223744\/iEGR6Kkr_normal.jpeg",
      "id" : 305791165,
      "verified" : false
    }
  },
  "id" : 656793026547830784,
  "created_at" : "2015-10-21 11:23:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 0, 14 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotCool",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656792198713839616",
  "in_reply_to_user_id" : 200751709,
  "text" : "@SexxAndBlunts Why your tweets gotta be so inappropriate? #NotCool",
  "id" : 656792198713839616,
  "created_at" : "2015-10-21 11:20:37 +0000",
  "in_reply_to_screen_name" : "sexxandblunts",
  "in_reply_to_user_id_str" : "200751709",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656648864582258688",
  "geo" : { },
  "id_str" : "656791907264253952",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Seriously?",
  "id" : 656791907264253952,
  "in_reply_to_status_id" : 656648864582258688,
  "created_at" : "2015-10-21 11:19:27 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 0, 9 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656790978339057664",
  "geo" : { },
  "id_str" : "656791368338165760",
  "in_reply_to_user_id" : 10971502,
  "text" : "@FXStefan I never understood Forex fairly well",
  "id" : 656791368338165760,
  "in_reply_to_status_id" : 656790978339057664,
  "created_at" : "2015-10-21 11:17:19 +0000",
  "in_reply_to_screen_name" : "FXStefan",
  "in_reply_to_user_id_str" : "10971502",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 0, 10 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656790945720049665",
  "geo" : { },
  "id_str" : "656791198485585920",
  "in_reply_to_user_id" : 17093617,
  "text" : "@hootsuite Strategies #1 Overuse hashtags #ThisIsOU",
  "id" : 656791198485585920,
  "in_reply_to_status_id" : 656790945720049665,
  "created_at" : "2015-10-21 11:16:38 +0000",
  "in_reply_to_screen_name" : "hootsuite",
  "in_reply_to_user_id_str" : "17093617",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Mobile",
      "screen_name" : "1Mobile",
      "indices" : [ 0, 8 ],
      "id_str" : "221999170",
      "id" : 221999170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656791054407045120",
  "in_reply_to_user_id" : 221999170,
  "text" : "@1Mobile Why would you change your whole developer program, it was so good already \uD83D\uDE24\uD83D\uDC4E\uD83C\uDFFC",
  "id" : 656791054407045120,
  "created_at" : "2015-10-21 11:16:04 +0000",
  "in_reply_to_screen_name" : "1Mobile",
  "in_reply_to_user_id_str" : "221999170",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PayPal",
      "screen_name" : "PayPal",
      "indices" : [ 0, 7 ],
      "id_str" : "30018058",
      "id" : 30018058
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 24, 33 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656790826039775232",
  "in_reply_to_user_id" : 30018058,
  "text" : "@PayPal @PayPalSecurity @facebook I called in and didn't get the support I needed. Both PayPal and FB let me down.",
  "id" : 656790826039775232,
  "created_at" : "2015-10-21 11:15:10 +0000",
  "in_reply_to_screen_name" : "PayPal",
  "in_reply_to_user_id_str" : "30018058",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656555689561739264",
  "text" : "RT @HelloRyanHolmes: Time keeps on slipping slipping slipping into the future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656555286254063616",
    "text" : "Time keeps on slipping slipping slipping into the future.",
    "id" : 656555286254063616,
    "created_at" : "2015-10-20 19:39:13 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854042008058462208\/qK3tEZDX_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 656555689561739264,
  "created_at" : "2015-10-20 19:40:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J-S",
      "screen_name" : "Wakooz_RSS",
      "indices" : [ 3, 14 ],
      "id_str" : "19022242",
      "id" : 19022242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/8uRvuhnTQI",
      "expanded_url" : "http:\/\/dlvr.it\/CVBjfR",
      "display_url" : "dlvr.it\/CVBjfR"
    } ]
  },
  "geo" : { },
  "id_str" : "656246125033336832",
  "text" : "RT @Wakooz_RSS: Donald Trump takes a big risk in attacking Jeb Bush on 9\/11 https:\/\/t.co\/8uRvuhnTQI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/8uRvuhnTQI",
        "expanded_url" : "http:\/\/dlvr.it\/CVBjfR",
        "display_url" : "dlvr.it\/CVBjfR"
      } ]
    },
    "geo" : { },
    "id_str" : "656245207118168064",
    "text" : "Donald Trump takes a big risk in attacking Jeb Bush on 9\/11 https:\/\/t.co\/8uRvuhnTQI",
    "id" : 656245207118168064,
    "created_at" : "2015-10-19 23:07:04 +0000",
    "user" : {
      "name" : "J-S",
      "screen_name" : "Wakooz_RSS",
      "protected" : false,
      "id_str" : "19022242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000041986620\/fc5090c77dfc50d4d79b3f7b7af57ea5_normal.jpeg",
      "id" : 19022242,
      "verified" : false
    }
  },
  "id" : 656246125033336832,
  "created_at" : "2015-10-19 23:10:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656245259274293248",
  "geo" : { },
  "id_str" : "656245805846650880",
  "in_reply_to_user_id" : 144078841,
  "text" : "@God_Instagram Praying does help \uD83D\uDE03",
  "id" : 656245805846650880,
  "in_reply_to_status_id" : 656245259274293248,
  "created_at" : "2015-10-19 23:09:27 +0000",
  "in_reply_to_screen_name" : "101BibleVerses",
  "in_reply_to_user_id_str" : "144078841",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655971600710242304",
  "geo" : { },
  "id_str" : "656245647880753153",
  "in_reply_to_user_id" : 3943427414,
  "text" : "@saadgalcece What type of quote is that?",
  "id" : 656245647880753153,
  "in_reply_to_status_id" : 655971600710242304,
  "created_at" : "2015-10-19 23:08:49 +0000",
  "in_reply_to_screen_name" : "BADGALKC",
  "in_reply_to_user_id_str" : "3943427414",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656218485656309761",
  "geo" : { },
  "id_str" : "656218888837926912",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki It is cool but AI creeps me out",
  "id" : 656218888837926912,
  "in_reply_to_status_id" : 656218485656309761,
  "created_at" : "2015-10-19 21:22:29 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iseunife The First",
      "screen_name" : "Shawnife_",
      "indices" : [ 0, 10 ],
      "id_str" : "2932585115",
      "id" : 2932585115
    }, {
      "name" : "when a real nigga",
      "screen_name" : "HilMarHustler",
      "indices" : [ 11, 25 ],
      "id_str" : "121330617",
      "id" : 121330617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotSorry",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616378207013617664",
  "geo" : { },
  "id_str" : "656218506317438976",
  "in_reply_to_user_id" : 2932585115,
  "text" : "@Shawnife_ @HilMarHustler How about none? #NotSorry",
  "id" : 656218506317438976,
  "in_reply_to_status_id" : 616378207013617664,
  "created_at" : "2015-10-19 21:20:58 +0000",
  "in_reply_to_screen_name" : "Shawnife_",
  "in_reply_to_user_id_str" : "2932585115",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brock Murley",
      "screen_name" : "thebrockmurley",
      "indices" : [ 0, 15 ],
      "id_str" : "372842787",
      "id" : 372842787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656218129496997888",
  "geo" : { },
  "id_str" : "656218361756520450",
  "in_reply_to_user_id" : 372842787,
  "text" : "@thebrockmurley Probably better where I am right now or heading ;)",
  "id" : 656218361756520450,
  "in_reply_to_status_id" : 656218129496997888,
  "created_at" : "2015-10-19 21:20:24 +0000",
  "in_reply_to_screen_name" : "thebrockmurley",
  "in_reply_to_user_id_str" : "372842787",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Oli\u064En\u0650vard",
      "screen_name" : "Olinvard",
      "indices" : [ 0, 9 ],
      "id_str" : "357687570",
      "id" : 357687570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656217953373954048",
  "geo" : { },
  "id_str" : "656218191333564417",
  "in_reply_to_user_id" : 357687570,
  "text" : "@Olinvard That sounds like an arrogant and prideful quote in itself",
  "id" : 656218191333564417,
  "in_reply_to_status_id" : 656217953373954048,
  "created_at" : "2015-10-19 21:19:43 +0000",
  "in_reply_to_screen_name" : "Olinvard",
  "in_reply_to_user_id_str" : "357687570",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Entrepreneur",
      "screen_name" : "digentre",
      "indices" : [ 3, 12 ],
      "id_str" : "244035744",
      "id" : 244035744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656217896666996738",
  "text" : "RT @digentre: Email Marketing is so emotional",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653605731170680832",
    "text" : "Email Marketing is so emotional",
    "id" : 653605731170680832,
    "created_at" : "2015-10-12 16:18:44 +0000",
    "user" : {
      "name" : "Digital Entrepreneur",
      "screen_name" : "digentre",
      "protected" : false,
      "id_str" : "244035744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785425170437705728\/422BufOw_normal.jpg",
      "id" : 244035744,
      "verified" : false
    }
  },
  "id" : 656217896666996738,
  "created_at" : "2015-10-19 21:18:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656217763539763200",
  "text" : "I am sweet they say ;^)",
  "id" : 656217763539763200,
  "created_at" : "2015-10-19 21:18:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656166165241307136",
  "text" : "Gave cakes to veterans today, God bless America!!!",
  "id" : 656166165241307136,
  "created_at" : "2015-10-19 17:52:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655925273985159168",
  "geo" : { },
  "id_str" : "656163219845881856",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp Amazon is making a controller? Wait what?",
  "id" : 656163219845881856,
  "in_reply_to_status_id" : 655925273985159168,
  "created_at" : "2015-10-19 17:41:17 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOVE LIFE \u2665",
      "screen_name" : "ltsLOVELIFE",
      "indices" : [ 3, 15 ],
      "id_str" : "312620091",
      "id" : 312620091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656162967134801920",
  "text" : "RT @ltsLOVELIFE: Life is tough, but God is tougher.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641253121839235072",
    "text" : "Life is tough, but God is tougher.",
    "id" : 641253121839235072,
    "created_at" : "2015-09-08 14:13:52 +0000",
    "user" : {
      "name" : "LOVE LIFE \u2665",
      "screen_name" : "ltsLOVELIFE",
      "protected" : false,
      "id_str" : "312620091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420006291688259584\/Tx6dH8U1_normal.jpeg",
      "id" : 312620091,
      "verified" : false
    }
  },
  "id" : 656162967134801920,
  "created_at" : "2015-10-19 17:40:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOVE LIFE \u2665",
      "screen_name" : "ltsLOVELIFE",
      "indices" : [ 3, 15 ],
      "id_str" : "312620091",
      "id" : 312620091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656162954199638016",
  "text" : "RT @ltsLOVELIFE: Sometimes you have to test someone. Not because you don't trust them, but to see how much they're willing to prove they lo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641270352551784449",
    "text" : "Sometimes you have to test someone. Not because you don't trust them, but to see how much they're willing to prove they love you.",
    "id" : 641270352551784449,
    "created_at" : "2015-09-08 15:22:20 +0000",
    "user" : {
      "name" : "LOVE LIFE \u2665",
      "screen_name" : "ltsLOVELIFE",
      "protected" : false,
      "id_str" : "312620091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420006291688259584\/Tx6dH8U1_normal.jpeg",
      "id" : 312620091,
      "verified" : false
    }
  },
  "id" : 656162954199638016,
  "created_at" : "2015-10-19 17:40:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "AboveTopSecret",
      "screen_name" : "AboveTopSecret",
      "indices" : [ 33, 48 ],
      "id_str" : "14210021",
      "id" : 14210021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656162779813031936",
  "text" : "RT @chknfriedsteak: @gamer456148 @AboveTopSecret I read that headline.... Smh.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "AboveTopSecret",
        "screen_name" : "AboveTopSecret",
        "indices" : [ 13, 28 ],
        "id_str" : "14210021",
        "id" : 14210021
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "655908297233604608",
    "geo" : { },
    "id_str" : "656117900109987840",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @AboveTopSecret I read that headline.... Smh.",
    "id" : 656117900109987840,
    "in_reply_to_status_id" : 655908297233604608,
    "created_at" : "2015-10-19 14:41:12 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 656162779813031936,
  "created_at" : "2015-10-19 17:39:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656162635034050560",
  "text" : "Patience is a wise virtue we all need to learn",
  "id" : 656162635034050560,
  "created_at" : "2015-10-19 17:38:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AboveTopSecret",
      "screen_name" : "AboveTopSecret",
      "indices" : [ 0, 15 ],
      "id_str" : "14210021",
      "id" : 14210021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655875607318929412",
  "geo" : { },
  "id_str" : "655908297233604608",
  "in_reply_to_user_id" : 14210021,
  "text" : "@AboveTopSecret Wait what?",
  "id" : 655908297233604608,
  "in_reply_to_status_id" : 655875607318929412,
  "created_at" : "2015-10-19 00:48:18 +0000",
  "in_reply_to_screen_name" : "AboveTopSecret",
  "in_reply_to_user_id_str" : "14210021",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655908088562761728",
  "text" : "Twitter, a wall of opinions and sometimes interesting, sometimes utterly pointless, sometimes boring, and sometimes inspiring posts",
  "id" : 655908088562761728,
  "created_at" : "2015-10-19 00:47:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "indices" : [ 3, 14 ],
      "id_str" : "222482865",
      "id" : 222482865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/4AHFJsU6V1",
      "expanded_url" : "http:\/\/tvista.in\/1Vu73jy",
      "display_url" : "tvista.in\/1Vu73jy"
    } ]
  },
  "geo" : { },
  "id_str" : "655907725180850180",
  "text" : "RT @amitava235: Simple Greenhouses May Be The Way To Grow Food On Mars\nRead on: http:\/\/t.co\/4AHFJsU6V1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/4AHFJsU6V1",
        "expanded_url" : "http:\/\/tvista.in\/1Vu73jy",
        "display_url" : "tvista.in\/1Vu73jy"
      } ]
    },
    "geo" : { },
    "id_str" : "655907577902014464",
    "text" : "Simple Greenhouses May Be The Way To Grow Food On Mars\nRead on: http:\/\/t.co\/4AHFJsU6V1",
    "id" : 655907577902014464,
    "created_at" : "2015-10-19 00:45:27 +0000",
    "user" : {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "protected" : false,
      "id_str" : "222482865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556878626906722304\/R-U_SUZW_normal.jpeg",
      "id" : 222482865,
      "verified" : false
    }
  },
  "id" : 655907725180850180,
  "created_at" : "2015-10-19 00:46:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655907604288413696",
  "text" : "RT @ijustine: Worst part of being sick is I can't play rock band because my entire body hurts. The band needs me and I'm letting them down \uD83D\uDE2D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655870355001577472",
    "text" : "Worst part of being sick is I can't play rock band because my entire body hurts. The band needs me and I'm letting them down \uD83D\uDE2D",
    "id" : 655870355001577472,
    "created_at" : "2015-10-18 22:17:32 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989703573573632\/ndieod1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 655907604288413696,
  "created_at" : "2015-10-19 00:45:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Henry Maneuver",
      "screen_name" : "THenryManeuver",
      "indices" : [ 3, 18 ],
      "id_str" : "34798452",
      "id" : 34798452
    }, {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 20, 35 ],
      "id_str" : "248135355",
      "id" : 248135355
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 36, 48 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655802347101143040",
  "text" : "RT @THenryManeuver: @BONNIELYNN2015 @gamer456148 think about it in the context of a nightmare, and maybe the joke will make more sense haha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Last Pirate in LA",
        "screen_name" : "BONNIELYNN2015",
        "indices" : [ 0, 15 ],
        "id_str" : "248135355",
        "id" : 248135355
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 16, 28 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "655595064031363072",
    "geo" : { },
    "id_str" : "655772407018315776",
    "in_reply_to_user_id" : 210979938,
    "text" : "@BONNIELYNN2015 @gamer456148 think about it in the context of a nightmare, and maybe the joke will make more sense haha",
    "id" : 655772407018315776,
    "in_reply_to_status_id" : 655595064031363072,
    "created_at" : "2015-10-18 15:48:20 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "The Henry Maneuver",
      "screen_name" : "THenryManeuver",
      "protected" : false,
      "id_str" : "34798452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3224569411\/9fb288ccff7dad1e1ebdd9a096d69b26_normal.jpeg",
      "id" : 34798452,
      "verified" : false
    }
  },
  "id" : 655802347101143040,
  "created_at" : "2015-10-18 17:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/655802235784294401\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/CJLooIV846",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRngpufWUAADkbD.jpg",
      "id_str" : "655802228217892864",
      "id" : 655802228217892864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRngpufWUAADkbD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CJLooIV846"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655802235784294401",
  "text" : "Both my grandmas and my aunts are good cooks :) http:\/\/t.co\/CJLooIV846",
  "id" : 655802235784294401,
  "created_at" : "2015-10-18 17:46:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655751506646474752",
  "text" : "RT @BONNIELYNN2015: Lol lol lol it is funny and so that makes it relevant  people need to laugh i am sorry if you do not see the value \uD83D\uDE09 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rTnPmTRyGv",
        "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/655595064031363072",
        "display_url" : "twitter.com\/gamer456148\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655599781192994816",
    "text" : "Lol lol lol it is funny and so that makes it relevant  people need to laugh i am sorry if you do not see the value \uD83D\uDE09 https:\/\/t.co\/rTnPmTRyGv",
    "id" : 655599781192994816,
    "created_at" : "2015-10-18 04:22:22 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854854678865076224\/wyfm4hc3_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 655751506646474752,
  "created_at" : "2015-10-18 14:25:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/FMrCHqiUZA",
      "expanded_url" : "https:\/\/twitter.com\/bestgamezup\/status\/655751030173540352",
      "display_url" : "twitter.com\/bestgamezup\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655751371606618112",
  "text" : "Too expensive, at least he isn't Super Man, but those are just fictional characters https:\/\/t.co\/FMrCHqiUZA",
  "id" : 655751371606618112,
  "created_at" : "2015-10-18 14:24:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655751083642527744",
  "text" : "Children are so wonderful :)",
  "id" : 655751083642527744,
  "created_at" : "2015-10-18 14:23:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/X79JH7goAI",
      "expanded_url" : "https:\/\/twitter.com\/wwexstream\/status\/655594870288064512",
      "display_url" : "twitter.com\/wwexstream\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655595222110502912",
  "text" : "Meanwhile in Australia... https:\/\/t.co\/X79JH7goAI",
  "id" : 655595222110502912,
  "created_at" : "2015-10-18 04:04:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Henry Maneuver",
      "screen_name" : "THenryManeuver",
      "indices" : [ 0, 15 ],
      "id_str" : "34798452",
      "id" : 34798452
    }, {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 16, 31 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655593735284068352",
  "geo" : { },
  "id_str" : "655595064031363072",
  "in_reply_to_user_id" : 34798452,
  "text" : "@THenryManeuver @BONNIELYNN2015 Don't see how that is relevant to the public",
  "id" : 655595064031363072,
  "in_reply_to_status_id" : 655593735284068352,
  "created_at" : "2015-10-18 04:03:38 +0000",
  "in_reply_to_screen_name" : "THenryManeuver",
  "in_reply_to_user_id_str" : "34798452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594779087122432",
  "text" : "Food makes my belly happy",
  "id" : 655594779087122432,
  "created_at" : "2015-10-18 04:02:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 0, 12 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594466552750080",
  "in_reply_to_user_id" : 2833631352,
  "text" : "@FoodPornAww You are making me hungry",
  "id" : 655594466552750080,
  "created_at" : "2015-10-18 04:01:15 +0000",
  "in_reply_to_screen_name" : "FoodPornAww",
  "in_reply_to_user_id_str" : "2833631352",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655574132864786432\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/iHFsFjcBWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkRM0JWcAApehs.png",
      "id_str" : "655574132613083136",
      "id" : 655574132613083136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkRM0JWcAApehs.png",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iHFsFjcBWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594374022189056",
  "text" : "RT @FoodPornAww: Cookies and Cream Milkshake http:\/\/t.co\/iHFsFjcBWF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655574132864786432\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/iHFsFjcBWF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkRM0JWcAApehs.png",
        "id_str" : "655574132613083136",
        "id" : 655574132613083136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkRM0JWcAApehs.png",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iHFsFjcBWF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655574132864786432",
    "text" : "Cookies and Cream Milkshake http:\/\/t.co\/iHFsFjcBWF",
    "id" : 655574132864786432,
    "created_at" : "2015-10-18 02:40:27 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594374022189056,
  "created_at" : "2015-10-18 04:00:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655576612214349824\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/99d8UTQfi9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkTdJGWcAAmmOk.jpg",
      "id_str" : "655576612138807296",
      "id" : 655576612138807296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkTdJGWcAAmmOk.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/99d8UTQfi9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594359899992064",
  "text" : "RT @FoodPornAww: Cheesesteak and Fries http:\/\/t.co\/99d8UTQfi9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655576612214349824\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/99d8UTQfi9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkTdJGWcAAmmOk.jpg",
        "id_str" : "655576612138807296",
        "id" : 655576612138807296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkTdJGWcAAmmOk.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/99d8UTQfi9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655576612214349824",
    "text" : "Cheesesteak and Fries http:\/\/t.co\/99d8UTQfi9",
    "id" : 655576612214349824,
    "created_at" : "2015-10-18 02:50:19 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594359899992064,
  "created_at" : "2015-10-18 04:00:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655579474109558784\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/YteRR5BEUY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkWDuWWcAAElV7.jpg",
      "id_str" : "655579473996312576",
      "id" : 655579473996312576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkWDuWWcAAElV7.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/YteRR5BEUY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594331324203008",
  "text" : "RT @FoodPornAww: Cinnamon Sugar Pull Apart Muffin http:\/\/t.co\/YteRR5BEUY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655579474109558784\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/YteRR5BEUY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkWDuWWcAAElV7.jpg",
        "id_str" : "655579473996312576",
        "id" : 655579473996312576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkWDuWWcAAElV7.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/YteRR5BEUY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655579474109558784",
    "text" : "Cinnamon Sugar Pull Apart Muffin http:\/\/t.co\/YteRR5BEUY",
    "id" : 655579474109558784,
    "created_at" : "2015-10-18 03:01:41 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594331324203008,
  "created_at" : "2015-10-18 04:00:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655582540976246784\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/8bapNoFXJW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkY2PUWIAADzVw.jpg",
      "id_str" : "655582540862988288",
      "id" : 655582540862988288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkY2PUWIAADzVw.jpg",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/8bapNoFXJW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594306535845888",
  "text" : "RT @FoodPornAww: Chocolate Chip, Oreo, and M&amp;M Cookies http:\/\/t.co\/8bapNoFXJW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655582540976246784\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/8bapNoFXJW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkY2PUWIAADzVw.jpg",
        "id_str" : "655582540862988288",
        "id" : 655582540862988288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkY2PUWIAADzVw.jpg",
        "sizes" : [ {
          "h" : 696,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/8bapNoFXJW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655582540976246784",
    "text" : "Chocolate Chip, Oreo, and M&amp;M Cookies http:\/\/t.co\/8bapNoFXJW",
    "id" : 655582540976246784,
    "created_at" : "2015-10-18 03:13:52 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594306535845888,
  "created_at" : "2015-10-18 04:00:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655586759514943488\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/cjW1pZ1z5d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkcrymWEAAw5XF.jpg",
      "id_str" : "655586759401672704",
      "id" : 655586759401672704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkcrymWEAAw5XF.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/cjW1pZ1z5d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594282074644481",
  "text" : "RT @FoodPornAww: M&amp;M Chocolate Fudge http:\/\/t.co\/cjW1pZ1z5d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655586759514943488\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/cjW1pZ1z5d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRkcrymWEAAw5XF.jpg",
        "id_str" : "655586759401672704",
        "id" : 655586759401672704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRkcrymWEAAw5XF.jpg",
        "sizes" : [ {
          "h" : 397,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/cjW1pZ1z5d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655586759514943488",
    "text" : "M&amp;M Chocolate Fudge http:\/\/t.co\/cjW1pZ1z5d",
    "id" : 655586759514943488,
    "created_at" : "2015-10-18 03:30:38 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594282074644481,
  "created_at" : "2015-10-18 04:00:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "indices" : [ 3, 15 ],
      "id_str" : "2833631352",
      "id" : 2833631352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655536384627769344\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/nfDyXYOsNv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRju3lgVEAAcMrQ.jpg",
      "id_str" : "655536384510332928",
      "id" : 655536384510332928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRju3lgVEAAcMrQ.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 466
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nfDyXYOsNv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594224738574336",
  "text" : "RT @FoodPornAww: Lasagna. http:\/\/t.co\/nfDyXYOsNv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodPornAww\/status\/655536384627769344\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/nfDyXYOsNv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRju3lgVEAAcMrQ.jpg",
        "id_str" : "655536384510332928",
        "id" : 655536384510332928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRju3lgVEAAcMrQ.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 466
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nfDyXYOsNv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655536384627769344",
    "text" : "Lasagna. http:\/\/t.co\/nfDyXYOsNv",
    "id" : 655536384627769344,
    "created_at" : "2015-10-18 00:10:28 +0000",
    "user" : {
      "name" : "Food Porn",
      "screen_name" : "FoodPornAww",
      "protected" : false,
      "id_str" : "2833631352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524298855991369731\/3yV9sSvw_normal.jpeg",
      "id" : 2833631352,
      "verified" : false
    }
  },
  "id" : 655594224738574336,
  "created_at" : "2015-10-18 04:00:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.S. Morin",
      "screen_name" : "authorjsmorin",
      "indices" : [ 3, 17 ],
      "id_str" : "604772054",
      "id" : 604772054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655594070614626308",
  "text" : "RT @authorjsmorin: The first person to discover a creature is either a scientist or an explorer; the second is invariably a cook.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655508928373985280",
    "text" : "The first person to discover a creature is either a scientist or an explorer; the second is invariably a cook.",
    "id" : 655508928373985280,
    "created_at" : "2015-10-17 22:21:21 +0000",
    "user" : {
      "name" : "J.S. Morin",
      "screen_name" : "authorjsmorin",
      "protected" : false,
      "id_str" : "604772054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655385964164968448\/uRcwbKdS_normal.jpg",
      "id" : 604772054,
      "verified" : false
    }
  },
  "id" : 655594070614626308,
  "created_at" : "2015-10-18 03:59:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655551286063058944",
  "text" : "Equilibrium price; Price at which supply=demand, not to be confused with the break even point where cost=total revenue #MathTips",
  "id" : 655551286063058944,
  "created_at" : "2015-10-18 01:09:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 0, 12 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655547824931782656",
  "geo" : { },
  "id_str" : "655550037213212672",
  "in_reply_to_user_id" : 35773039,
  "text" : "@TheAtlantic Leave it to a lib. to call Ben Carson intellectually gifted, but than irrational for believing in God or being a conservative",
  "id" : 655550037213212672,
  "in_reply_to_status_id" : 655547824931782656,
  "created_at" : "2015-10-18 01:04:43 +0000",
  "in_reply_to_screen_name" : "TheAtlantic",
  "in_reply_to_user_id_str" : "35773039",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655548518845804544",
  "text" : "((Cost-Salvage value)\/Useful Life))*-1=m; x=# of years; b=cost; y=mx+b; Linear depreciation using the straight line method #MathTips",
  "id" : 655548518845804544,
  "created_at" : "2015-10-18 00:58:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    }, {
      "name" : "mirko",
      "screen_name" : "Mirko_Draganic",
      "indices" : [ 15, 30 ],
      "id_str" : "1678529467",
      "id" : 1678529467
    }, {
      "name" : "sarah.",
      "screen_name" : "jzzsarah",
      "indices" : [ 31, 40 ],
      "id_str" : "4280996593",
      "id" : 4280996593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655160569461239809",
  "text" : "@josef_lokmani @Mirko_Draganic @jzzsarah Dang it English, I know but you can't edit tweets \uD83D\uDE06",
  "id" : 655160569461239809,
  "created_at" : "2015-10-16 23:17:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eskimojo",
      "screen_name" : "eskimojo100",
      "indices" : [ 0, 12 ],
      "id_str" : "2757557355",
      "id" : 2757557355
    }, {
      "name" : "Tess O' Reilly",
      "screen_name" : "TESSOREILLYreal",
      "indices" : [ 13, 29 ],
      "id_str" : "117428568",
      "id" : 117428568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655087391808598016",
  "geo" : { },
  "id_str" : "655091430591893505",
  "in_reply_to_user_id" : 2757557355,
  "text" : "@eskimojo100 @TESSOREILLYreal Nah, I am too cool to celebrate \uD83D\uDE0E",
  "id" : 655091430591893505,
  "in_reply_to_status_id" : 655087391808598016,
  "created_at" : "2015-10-16 18:42:22 +0000",
  "in_reply_to_screen_name" : "eskimojo100",
  "in_reply_to_user_id_str" : "2757557355",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 0, 14 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655088929172008960",
  "geo" : { },
  "id_str" : "655091279370436608",
  "in_reply_to_user_id" : 200751709,
  "text" : "@SexxAndBlunts What is this again?",
  "id" : 655091279370436608,
  "in_reply_to_status_id" : 655088929172008960,
  "created_at" : "2015-10-16 18:41:46 +0000",
  "in_reply_to_screen_name" : "sexxandblunts",
  "in_reply_to_user_id_str" : "200751709",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah.",
      "screen_name" : "jzzsarah",
      "indices" : [ 0, 9 ],
      "id_str" : "4280996593",
      "id" : 4280996593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655091106594492416",
  "text" : "@jzzsarah I am just here for no reason at all, don't worry, okay bye",
  "id" : 655091106594492416,
  "created_at" : "2015-10-16 18:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/z4wFrEwJkP",
      "expanded_url" : "https:\/\/twitter.com\/mirko_draganic\/status\/655089082549202944",
      "display_url" : "twitter.com\/mirko_draganic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655090906521976832",
  "text" : "How many dollars than? Huh https:\/\/t.co\/z4wFrEwJkP",
  "id" : 655090906521976832,
  "created_at" : "2015-10-16 18:40:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JB",
      "indices" : [ 38, 41 ]
    }, {
      "text" : "OU",
      "indices" : [ 42, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655090437456183296",
  "text" : "The moments you miss someone you love #JB #OU",
  "id" : 655090437456183296,
  "created_at" : "2015-10-16 18:38:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655088173954002944",
  "text" : "@josef_lokmani Search Peter Singer",
  "id" : 655088173954002944,
  "created_at" : "2015-10-16 18:29:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655072856460537856",
  "text" : "Sometimes I am funny, sometimes I am intimidating, but overall I am human",
  "id" : 655072856460537856,
  "created_at" : "2015-10-16 17:28:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 0, 15 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655072681813872641",
  "in_reply_to_user_id" : 1339835893,
  "text" : "@HillaryClinton I said it once, and I will say it again: If you can't control your own husband, how can you take control of this country?",
  "id" : 655072681813872641,
  "created_at" : "2015-10-16 17:27:52 +0000",
  "in_reply_to_screen_name" : "HillaryClinton",
  "in_reply_to_user_id_str" : "1339835893",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u270C\u2654 Tmoney\u270C\u2654",
      "screen_name" : "cash__me_out",
      "indices" : [ 3, 16 ],
      "id_str" : "322780853",
      "id" : 322780853
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655072203755548672",
  "text" : "RT @cash__me_out: @gamer456148 thanks\uD83D\uDE15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "654771780616220672",
    "geo" : { },
    "id_str" : "654775937389584385",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 thanks\uD83D\uDE15",
    "id" : 654775937389584385,
    "in_reply_to_status_id" : 654771780616220672,
    "created_at" : "2015-10-15 21:48:43 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "\u270C\u2654 Tmoney\u270C\u2654",
      "screen_name" : "cash__me_out",
      "protected" : false,
      "id_str" : "322780853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802411083906457600\/LDVNSpMw_normal.jpg",
      "id" : 322780853,
      "verified" : false
    }
  },
  "id" : 655072203755548672,
  "created_at" : "2015-10-16 17:25:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654772881646219264",
  "text" : "RT @God_Instagram: God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654772668273573888",
    "text" : "God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
    "id" : 654772668273573888,
    "created_at" : "2015-10-15 21:35:43 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 654772881646219264,
  "created_at" : "2015-10-15 21:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Davis \uD83D\uDCF9",
      "screen_name" : "Joel_Davis_",
      "indices" : [ 15, 27 ],
      "id_str" : "460641674",
      "id" : 460641674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654425484642664448",
  "geo" : { },
  "id_str" : "654772818870046722",
  "in_reply_to_user_id" : 2467058131,
  "text" : "@thenebulapics @Joel_Davis_ The universe is a marvelous creation of natural wonders",
  "id" : 654772818870046722,
  "in_reply_to_status_id" : 654425484642664448,
  "created_at" : "2015-10-15 21:36:19 +0000",
  "in_reply_to_screen_name" : "TurntAyyLmao",
  "in_reply_to_user_id_str" : "2467058131",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thenebulapics\/status\/654425484642664448\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/QCGm6bL0TD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRT8gsbW8AE_D8y.jpg",
      "id_str" : "654425484487487489",
      "id" : 654425484487487489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRT8gsbW8AE_D8y.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QCGm6bL0TD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654772715660840960",
  "text" : "RT @thenebulapics: A Sagittarius Triplet http:\/\/t.co\/QCGm6bL0TD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thenebulapics\/status\/654425484642664448\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/QCGm6bL0TD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRT8gsbW8AE_D8y.jpg",
        "id_str" : "654425484487487489",
        "id" : 654425484487487489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRT8gsbW8AE_D8y.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QCGm6bL0TD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654425484642664448",
    "text" : "A Sagittarius Triplet http:\/\/t.co\/QCGm6bL0TD",
    "id" : 654425484642664448,
    "created_at" : "2015-10-14 22:36:08 +0000",
    "user" : {
      "name" : "Turnt Alien",
      "screen_name" : "TurntAyyLmao",
      "protected" : false,
      "id_str" : "2467058131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714607588751630336\/iXNvCLWx_normal.jpg",
      "id" : 2467058131,
      "verified" : false
    }
  },
  "id" : 654772715660840960,
  "created_at" : "2015-10-15 21:35:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Spliffton",
      "screen_name" : "charliethebee",
      "indices" : [ 0, 14 ],
      "id_str" : "59060200",
      "id" : 59060200
    }, {
      "name" : "Snapchat: Lo.monroee",
      "screen_name" : "kvngshxtnigga__",
      "indices" : [ 15, 31 ],
      "id_str" : "425245948",
      "id" : 425245948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654703396813844480",
  "geo" : { },
  "id_str" : "654772613290397696",
  "in_reply_to_user_id" : 59060200,
  "text" : "@charliethebee @kvngshxtnigga__ Come on this is way too personal for Twitter, why would you tweet that for him???",
  "id" : 654772613290397696,
  "in_reply_to_status_id" : 654703396813844480,
  "created_at" : "2015-10-15 21:35:30 +0000",
  "in_reply_to_screen_name" : "charliethebee",
  "in_reply_to_user_id_str" : "59060200",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6BD2 \u8D29 \u5B50",
      "screen_name" : "freshhcutz",
      "indices" : [ 0, 11 ],
      "id_str" : "837900703926468609",
      "id" : 837900703926468609
    }, {
      "name" : "Snapchat: Lo.monroee",
      "screen_name" : "kvngshxtnigga__",
      "indices" : [ 12, 28 ],
      "id_str" : "425245948",
      "id" : 425245948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636343330268409856",
  "geo" : { },
  "id_str" : "654772370545049600",
  "in_reply_to_user_id" : 287784378,
  "text" : "@Freshhcutz @kvngshxtnigga__ Some man need to learn self respect and human dignity, same the other way around as well",
  "id" : 654772370545049600,
  "in_reply_to_status_id" : 636343330268409856,
  "created_at" : "2015-10-15 21:34:32 +0000",
  "in_reply_to_screen_name" : "zctv114",
  "in_reply_to_user_id_str" : "287784378",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lil Loaf",
      "screen_name" : "DeJLoaf",
      "indices" : [ 3, 11 ],
      "id_str" : "125777025",
      "id" : 125777025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654772168945852416",
  "text" : "RT @DeJLoaf: They'll be so quick to say you've changed, when it's really them who aren't growing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653785378638442496",
    "text" : "They'll be so quick to say you've changed, when it's really them who aren't growing.",
    "id" : 653785378638442496,
    "created_at" : "2015-10-13 04:12:35 +0000",
    "user" : {
      "name" : "Lil Loaf",
      "screen_name" : "DeJLoaf",
      "protected" : false,
      "id_str" : "125777025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821526093454856193\/kwP94RF9_normal.jpg",
      "id" : 125777025,
      "verified" : true
    }
  },
  "id" : 654772168945852416,
  "created_at" : "2015-10-15 21:33:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tuhaf Ama Sahici",
      "screen_name" : "tuhafamasahici",
      "indices" : [ 0, 15 ],
      "id_str" : "1014141614",
      "id" : 1014141614
    }, {
      "name" : "K\u0131rm\u0131z\u0131l\u0131 KIZ",
      "screen_name" : "Aybukeyalcindag",
      "indices" : [ 16, 32 ],
      "id_str" : "623832162",
      "id" : 623832162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654664090065879040",
  "geo" : { },
  "id_str" : "654772107667111938",
  "in_reply_to_user_id" : 1014141614,
  "text" : "@tuhafamasahici @Aybukeyalcindag Candy!!!",
  "id" : 654772107667111938,
  "in_reply_to_status_id" : 654664090065879040,
  "created_at" : "2015-10-15 21:33:30 +0000",
  "in_reply_to_screen_name" : "tuhafamasahici",
  "in_reply_to_user_id_str" : "1014141614",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 0, 14 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654771647627456513",
  "geo" : { },
  "id_str" : "654771943447531520",
  "in_reply_to_user_id" : 200751709,
  "text" : "@SexxAndBlunts Why post things like these, you can provide a much better impact on humanity",
  "id" : 654771943447531520,
  "in_reply_to_status_id" : 654771647627456513,
  "created_at" : "2015-10-15 21:32:51 +0000",
  "in_reply_to_screen_name" : "sexxandblunts",
  "in_reply_to_user_id_str" : "200751709",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u270C\u2654 Tmoney\u270C\u2654",
      "screen_name" : "cash__me_out",
      "indices" : [ 0, 13 ],
      "id_str" : "322780853",
      "id" : 322780853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654771511438409728",
  "geo" : { },
  "id_str" : "654771780616220672",
  "in_reply_to_user_id" : 322780853,
  "text" : "@cash__me_out May God help you and bless you. May the Lord have mercy on you \uD83D\uDE4F\uD83C\uDFFD",
  "id" : 654771780616220672,
  "in_reply_to_status_id" : 654771511438409728,
  "created_at" : "2015-10-15 21:32:12 +0000",
  "in_reply_to_screen_name" : "cash__me_out",
  "in_reply_to_user_id_str" : "322780853",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654771381410795524",
  "text" : "God never wanted a world of hate, that is why heaven is filled with love. The devil comes to burn and destroy.",
  "id" : 654771381410795524,
  "created_at" : "2015-10-15 21:30:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654771181640220672",
  "text" : "The world is filled with utilitarians, socialist, oppression, and those who dehumanize others",
  "id" : 654771181640220672,
  "created_at" : "2015-10-15 21:29:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654770859496751105",
  "text" : "Don't inflict harm on others when thinking deontologically",
  "id" : 654770859496751105,
  "created_at" : "2015-10-15 21:28:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654770678646726656",
  "text" : "Turn the other cheek in times of pain; greater are those who follow the cross",
  "id" : 654770678646726656,
  "created_at" : "2015-10-15 21:27:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OT",
      "indices" : [ 94, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654770514372661248",
  "text" : "War isn't politically correct, but self defense is necessary rather than having a nation fall #OT",
  "id" : 654770514372661248,
  "created_at" : "2015-10-15 21:27:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654770264824090624",
  "text" : "Blessed is the poor, humble, and those who rejoice in times of trouble. Blessed is the wealthy who act like job. Blessed are God's servants",
  "id" : 654770264824090624,
  "created_at" : "2015-10-15 21:26:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654770005964255233",
  "text" : "What good is it if you don't love one another, why call for peace if you don't know how to care?",
  "id" : 654770005964255233,
  "created_at" : "2015-10-15 21:25:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654769868613353472",
  "text" : "Unfortunately the world is a dark place, filled with evil",
  "id" : 654769868613353472,
  "created_at" : "2015-10-15 21:24:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654769582259859456",
  "text" : "People need to have moral integrity, deep honesty, and mutual respect for one another.",
  "id" : 654769582259859456,
  "created_at" : "2015-10-15 21:23:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654769342584766464",
  "text" : "Why does the world have to have liars, scammers, and thiefs but others seem to do little to step in?",
  "id" : 654769342584766464,
  "created_at" : "2015-10-15 21:22:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654172924702670849",
  "geo" : { },
  "id_str" : "654768861380612097",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes You can follow your own heart, wow !!! \uD83D\uDE02",
  "id" : 654768861380612097,
  "in_reply_to_status_id" : 654172924702670849,
  "created_at" : "2015-10-15 21:20:36 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654768732837801985",
  "text" : "RT @HelloRyanHolmes: Follow your heart, but listen to your brain.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654172924702670849",
    "text" : "Follow your heart, but listen to your brain.",
    "id" : 654172924702670849,
    "created_at" : "2015-10-14 05:52:33 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854042008058462208\/qK3tEZDX_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 654768732837801985,
  "created_at" : "2015-10-15 21:20:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemDebate",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/hQW8bFyexD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=3Y8B93r2gKg",
      "display_url" : "youtube.com\/watch?v=3Y8B93\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654704504609202176",
  "text" : "RT @Lukewearechange: No Snowden couldn't go through the proper channels Hillary here's why    https:\/\/t.co\/hQW8bFyexD #DemDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemDebate",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/hQW8bFyexD",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=3Y8B93r2gKg",
        "display_url" : "youtube.com\/watch?v=3Y8B93\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654120729701552128",
    "text" : "No Snowden couldn't go through the proper channels Hillary here's why    https:\/\/t.co\/hQW8bFyexD #DemDebate",
    "id" : 654120729701552128,
    "created_at" : "2015-10-14 02:25:09 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 654704504609202176,
  "created_at" : "2015-10-15 17:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 116, 124 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/SZlHF5ioWA",
      "expanded_url" : "http:\/\/youtu.be\/LEPV4M3o8cg?a",
      "display_url" : "youtu.be\/LEPV4M3o8cg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "654704417359331328",
  "text" : "RT @Lukewearechange: Hillary Clinton Controversy Addressed By Congresswomen In Campaign: http:\/\/t.co\/SZlHF5ioWA via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 95, 103 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/SZlHF5ioWA",
        "expanded_url" : "http:\/\/youtu.be\/LEPV4M3o8cg?a",
        "display_url" : "youtu.be\/LEPV4M3o8cg?a"
      } ]
    },
    "geo" : { },
    "id_str" : "654613209945612288",
    "text" : "Hillary Clinton Controversy Addressed By Congresswomen In Campaign: http:\/\/t.co\/SZlHF5ioWA via @YouTube",
    "id" : 654613209945612288,
    "created_at" : "2015-10-15 11:02:06 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 654704417359331328,
  "created_at" : "2015-10-15 17:04:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caelus",
      "screen_name" : "caemck",
      "indices" : [ 0, 7 ],
      "id_str" : "3452993655",
      "id" : 3452993655
    }, {
      "name" : "daria",
      "screen_name" : "dariatbh",
      "indices" : [ 8, 17 ],
      "id_str" : "842905494",
      "id" : 842905494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651177899647610882",
  "geo" : { },
  "id_str" : "654703786821218304",
  "in_reply_to_user_id" : 3452993655,
  "text" : "@caemck @dariatbh What the hell is the gossip app? Sounds dumb",
  "id" : 654703786821218304,
  "in_reply_to_status_id" : 651177899647610882,
  "created_at" : "2015-10-15 17:02:01 +0000",
  "in_reply_to_screen_name" : "caemck",
  "in_reply_to_user_id_str" : "3452993655",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VirtualWingMan",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654702963345125376",
  "geo" : { },
  "id_str" : "654703345337131008",
  "in_reply_to_user_id" : 210979938,
  "text" : "@HelloRyanHolmes But overall be sweet and just be yourself (This one is real advice this time). #VirtualWingMan",
  "id" : 654703345337131008,
  "in_reply_to_status_id" : 654702963345125376,
  "created_at" : "2015-10-15 17:00:15 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654702963345125376",
  "geo" : { },
  "id_str" : "654703183957090304",
  "in_reply_to_user_id" : 210979938,
  "text" : "@HelloRyanHolmes It works 1% of the time, don't forget to tell her the sparkle in her eyes lightens up your day, girls like cheesy quotes",
  "id" : 654703183957090304,
  "in_reply_to_status_id" : 654702963345125376,
  "created_at" : "2015-10-15 16:59:37 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654702963345125376",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes The best dating advice, go up to a lady, ask her if she has a boyfriend, if she says no, say \"You do now\"",
  "id" : 654702963345125376,
  "created_at" : "2015-10-15 16:58:44 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 0, 9 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654670232938672128",
  "in_reply_to_user_id" : 2425151,
  "text" : "@Facebook Where do we go for help? Help pages doesn't work, phone number in Alto is just an automated machine, this is unfair for me :(",
  "id" : 654670232938672128,
  "created_at" : "2015-10-15 14:48:41 +0000",
  "in_reply_to_screen_name" : "facebook",
  "in_reply_to_user_id_str" : "2425151",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654336096969588736",
  "geo" : { },
  "id_str" : "654336377409159168",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki try mine \uD83D\uDE06",
  "id" : 654336377409159168,
  "in_reply_to_status_id" : 654336096969588736,
  "created_at" : "2015-10-14 16:42:04 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/654335972893659137\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/FhaZLxfDRE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRSrGIvWcAIT_5L.jpg",
      "id_str" : "654335967789215746",
      "id" : 654335967789215746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRSrGIvWcAIT_5L.jpg",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FhaZLxfDRE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654335972893659137",
  "text" : "Had some brownies from Frankie's Cafe @ Kringe http:\/\/t.co\/FhaZLxfDRE",
  "id" : 654335972893659137,
  "created_at" : "2015-10-14 16:40:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654333138722783233",
  "text" : "I am Andrew, the gentle giant #ThisIsOU",
  "id" : 654333138722783233,
  "created_at" : "2015-10-14 16:29:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654323602838454272",
  "text" : "Went to the OU bake sale today, caramel apple cookies are better than they sound \u270B\uD83C\uDFFC",
  "id" : 654323602838454272,
  "created_at" : "2015-10-14 15:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Walking Dead AMC",
      "screen_name" : "WalkingDead_AMC",
      "indices" : [ 0, 16 ],
      "id_str" : "65184105",
      "id" : 65184105
    }, {
      "name" : "Angel Eduardo Jr.",
      "screen_name" : "AngelEduJr",
      "indices" : [ 17, 28 ],
      "id_str" : "238329380",
      "id" : 238329380
    }, {
      "name" : "Louise",
      "screen_name" : "_xlou_x",
      "indices" : [ 29, 37 ],
      "id_str" : "3420871282",
      "id" : 3420871282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654288432915738625",
  "geo" : { },
  "id_str" : "654290281886523392",
  "in_reply_to_user_id" : 65184105,
  "text" : "@WalkingDead_AMC @AngelEduJr @_xlou_x Not really",
  "id" : 654290281886523392,
  "in_reply_to_status_id" : 654288432915738625,
  "created_at" : "2015-10-14 13:38:53 +0000",
  "in_reply_to_screen_name" : "WalkingDead_AMC",
  "in_reply_to_user_id_str" : "65184105",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 35, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654289848543674368",
  "text" : "Wow people can be insanely rude :( #OU",
  "id" : 654289848543674368,
  "created_at" : "2015-10-14 13:37:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653962013643816960",
  "text" : "I am super nice #OU",
  "id" : 653962013643816960,
  "created_at" : "2015-10-13 15:54:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 45, 57 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6zknUURpB2",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/p9l4q",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653935901765181440",
  "text" : "RT @CouponTrump: Intro to Unreal Engine 4 by @gamer456148 Just $9 http:\/\/t.co\/6zknUURpB2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 28, 40 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/6zknUURpB2",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/p9l4q",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653822671025766400",
    "text" : "Intro to Unreal Engine 4 by @gamer456148 Just $9 http:\/\/t.co\/6zknUURpB2",
    "id" : 653822671025766400,
    "created_at" : "2015-10-13 06:40:46 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 653935901765181440,
  "created_at" : "2015-10-13 14:10:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Math",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "ThisIsOU",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653935815517671424",
  "text" : "Showed my work in the wrong section \uD83D\uDE21 #Math #ThisIsOU",
  "id" : 653935815517671424,
  "created_at" : "2015-10-13 14:10:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653694711513903104",
  "text" : "RT @copticworld: Pope Tawadros II Arrives to Corpus Christi, Texas: Pope Tawadros II Arrives to Corpus Christi, Texas http:\/\/t.co\/widEpSOcp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HHPT2inUSA",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/widEpSOcp6",
        "expanded_url" : "http:\/\/dlvr.it\/CQjx4b",
        "display_url" : "dlvr.it\/CQjx4b"
      } ]
    },
    "geo" : { },
    "id_str" : "653692383045914624",
    "text" : "Pope Tawadros II Arrives to Corpus Christi, Texas: Pope Tawadros II Arrives to Corpus Christi, Texas http:\/\/t.co\/widEpSOcp6 #HHPT2inUSA",
    "id" : 653692383045914624,
    "created_at" : "2015-10-12 22:03:03 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 653694711513903104,
  "created_at" : "2015-10-12 22:12:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Olsen",
      "screen_name" : "PeteOlsen",
      "indices" : [ 0, 10 ],
      "id_str" : "18183592",
      "id" : 18183592
    }, {
      "name" : "Pitchfix",
      "screen_name" : "PitchfixUSA",
      "indices" : [ 11, 23 ],
      "id_str" : "2786992973",
      "id" : 2786992973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653692093055954944",
  "geo" : { },
  "id_str" : "653694551853563904",
  "in_reply_to_user_id" : 18183592,
  "text" : "@PeteOlsen @PitchfixUSA Nicely designed",
  "id" : 653694551853563904,
  "in_reply_to_status_id" : 653692093055954944,
  "created_at" : "2015-10-12 22:11:40 +0000",
  "in_reply_to_screen_name" : "PeteOlsen",
  "in_reply_to_user_id_str" : "18183592",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/GcWQBD12RF",
      "expanded_url" : "https:\/\/twitter.com\/thenewgabriel\/status\/653687842741293057",
      "display_url" : "twitter.com\/thenewgabriel\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653694240598401024",
  "text" : "I wish that were true with me https:\/\/t.co\/GcWQBD12RF",
  "id" : 653694240598401024,
  "created_at" : "2015-10-12 22:10:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 0, 11 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653574422075437056",
  "geo" : { },
  "id_str" : "653574700405260288",
  "in_reply_to_user_id" : 74998076,
  "text" : "@Eniolasays Without music, unless it is gospel",
  "id" : 653574700405260288,
  "in_reply_to_status_id" : 653574422075437056,
  "created_at" : "2015-10-12 14:15:26 +0000",
  "in_reply_to_screen_name" : "Eniolasays",
  "in_reply_to_user_id_str" : "74998076",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/4ZEVEB5RLF",
      "expanded_url" : "http:\/\/fb.me\/6S9AMatZx",
      "display_url" : "fb.me\/6S9AMatZx"
    } ]
  },
  "geo" : { },
  "id_str" : "653574573712142336",
  "text" : "RT @EmperorDarroux: Pepsi (yes, the soda company) is making its own Android phone http:\/\/t.co\/4ZEVEB5RLF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/4ZEVEB5RLF",
        "expanded_url" : "http:\/\/fb.me\/6S9AMatZx",
        "display_url" : "fb.me\/6S9AMatZx"
      } ]
    },
    "geo" : { },
    "id_str" : "653574308254511104",
    "text" : "Pepsi (yes, the soda company) is making its own Android phone http:\/\/t.co\/4ZEVEB5RLF",
    "id" : 653574308254511104,
    "created_at" : "2015-10-12 14:13:52 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 653574573712142336,
  "created_at" : "2015-10-12 14:14:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jme",
      "screen_name" : "JmeBBK",
      "indices" : [ 0, 7 ],
      "id_str" : "14689295",
      "id" : 14689295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653500635590074368",
  "geo" : { },
  "id_str" : "653574168664010752",
  "in_reply_to_user_id" : 14689295,
  "text" : "@JmeBBK No need for evidence, we believe you",
  "id" : 653574168664010752,
  "in_reply_to_status_id" : 653500635590074368,
  "created_at" : "2015-10-12 14:13:19 +0000",
  "in_reply_to_screen_name" : "JmeBBK",
  "in_reply_to_user_id_str" : "14689295",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653573883904327683",
  "text" : "Meeting and greeting random people, than had a cookie bar at this bake sale #ThisIsOU",
  "id" : 653573883904327683,
  "created_at" : "2015-10-12 14:12:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653322805510053888",
  "text" : "I beat my dad at Fusball, than my little sis whom I always win against, beat me 3 times, was tired, geez \uD83D\uDE21\uD83D\uDE2D\uD83D\uDE24",
  "id" : 653322805510053888,
  "created_at" : "2015-10-11 21:34:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daria",
      "screen_name" : "dariatbh",
      "indices" : [ 3, 12 ],
      "id_str" : "842905494",
      "id" : 842905494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653257028874452992",
  "text" : "RT @dariatbh: College goes 0-100 real quick. You'll go from chilling for four weeks to having 3 tests 5 quizzes 4 speeches and 7 papers due\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648292558603313152",
    "text" : "College goes 0-100 real quick. You'll go from chilling for four weeks to having 3 tests 5 quizzes 4 speeches and 7 papers due in 2 days",
    "id" : 648292558603313152,
    "created_at" : "2015-09-28 00:26:05 +0000",
    "user" : {
      "name" : "daria",
      "screen_name" : "dariatbh",
      "protected" : false,
      "id_str" : "842905494",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430220186717663232\/slUj1_7n_normal.jpeg",
      "id" : 842905494,
      "verified" : false
    }
  },
  "id" : 653257028874452992,
  "created_at" : "2015-10-11 17:13:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/653256625789239296\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/u9cLlTGzR2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRDVbtRUkAA0ETu.jpg",
      "id_str" : "653256617954152448",
      "id" : 653256617954152448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRDVbtRUkAA0ETu.jpg",
      "sizes" : [ {
        "h" : 890,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u9cLlTGzR2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653256625789239296",
  "text" : "Arabic gum has a unique flavor I always liked http:\/\/t.co\/u9cLlTGzR2",
  "id" : 653256625789239296,
  "created_at" : "2015-10-11 17:11:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Vines",
      "screen_name" : "TheAnimalVines",
      "indices" : [ 0, 15 ],
      "id_str" : "2357600840",
      "id" : 2357600840
    }, {
      "name" : "lauren",
      "screen_name" : "selenasrevival",
      "indices" : [ 16, 31 ],
      "id_str" : "1553775140",
      "id" : 1553775140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639484254775177216",
  "geo" : { },
  "id_str" : "652651563115130880",
  "in_reply_to_user_id" : 2357600840,
  "text" : "@TheAnimalVines @selenasrevival Then go to the animal shelter, you might find better luck there then on Twitter",
  "id" : 652651563115130880,
  "in_reply_to_status_id" : 639484254775177216,
  "created_at" : "2015-10-10 01:07:12 +0000",
  "in_reply_to_screen_name" : "TheAnimalVines",
  "in_reply_to_user_id_str" : "2357600840",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652650817510510592",
  "text" : "RT @HelloRyanHolmes: Worked 8 hours today!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652248309432586240",
    "text" : "Worked 8 hours today!",
    "id" : 652248309432586240,
    "created_at" : "2015-10-08 22:24:49 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/854042008058462208\/qK3tEZDX_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 652650817510510592,
  "created_at" : "2015-10-10 01:04:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652650049827155968",
  "geo" : { },
  "id_str" : "652650528330018816",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp That is horrible",
  "id" : 652650528330018816,
  "in_reply_to_status_id" : 652650049827155968,
  "created_at" : "2015-10-10 01:03:06 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Vines",
      "screen_name" : "TheAnimalVines",
      "indices" : [ 3, 18 ],
      "id_str" : "2357600840",
      "id" : 2357600840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mPRlBqoIN6",
      "expanded_url" : "https:\/\/vine.co\/v\/ew96z5bH2YQ",
      "display_url" : "vine.co\/v\/ew96z5bH2YQ"
    } ]
  },
  "geo" : { },
  "id_str" : "652650381424529409",
  "text" : "RT @TheAnimalVines: When someone tries to wake you up before ur alarm goes off  https:\/\/t.co\/mPRlBqoIN6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/mPRlBqoIN6",
        "expanded_url" : "https:\/\/vine.co\/v\/ew96z5bH2YQ",
        "display_url" : "vine.co\/v\/ew96z5bH2YQ"
      } ]
    },
    "geo" : { },
    "id_str" : "642451468713242624",
    "text" : "When someone tries to wake you up before ur alarm goes off  https:\/\/t.co\/mPRlBqoIN6",
    "id" : 642451468713242624,
    "created_at" : "2015-09-11 21:35:40 +0000",
    "user" : {
      "name" : "Animal Vines",
      "screen_name" : "TheAnimalVines",
      "protected" : false,
      "id_str" : "2357600840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750824565048090624\/lHP8bzAB_normal.jpg",
      "id" : 2357600840,
      "verified" : false
    }
  },
  "id" : 652650381424529409,
  "created_at" : "2015-10-10 01:02:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652558238748135424",
  "geo" : { },
  "id_str" : "652649967719309312",
  "in_reply_to_user_id" : 376229331,
  "text" : "@nyctphiliaa Why would you tell strangers you don't know to chat with you? Do something productive, your potential can be better than this",
  "id" : 652649967719309312,
  "in_reply_to_status_id" : 652558238748135424,
  "created_at" : "2015-10-10 01:00:52 +0000",
  "in_reply_to_screen_name" : "busedemirbileek",
  "in_reply_to_user_id_str" : "376229331",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/w3C1q2fFsP",
      "expanded_url" : "https:\/\/twitter.com\/emperordarroux\/status\/652558138281865220",
      "display_url" : "twitter.com\/emperordarroux\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652649283112431617",
  "text" : "Wait what? https:\/\/t.co\/w3C1q2fFsP",
  "id" : 652649283112431617,
  "created_at" : "2015-10-10 00:58:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Copt",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652648913627779072",
  "text" : "Can't believe the BOC separated from the COC #Copt",
  "id" : 652648913627779072,
  "created_at" : "2015-10-10 00:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Hoft",
      "screen_name" : "gatewaypundit",
      "indices" : [ 3, 17 ],
      "id_str" : "19211550",
      "id" : 19211550
    }, {
      "name" : "Jim Hoft",
      "screen_name" : "gatewaypundit",
      "indices" : [ 118, 132 ],
      "id_str" : "19211550",
      "id" : 19211550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/6KpwxyGwU1",
      "expanded_url" : "https:\/\/shar.es\/1ub5wc",
      "display_url" : "shar.es\/1ub5wc"
    } ]
  },
  "geo" : { },
  "id_str" : "652642267044446208",
  "text" : "RT @gatewaypundit: HUNDREDS TURN OUT to Protest Barack Obama in Oregon \u201CGo Golf!\u201D (VIDEO) https:\/\/t.co\/6KpwxyGwU1 via @gatewaypundit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Hoft",
        "screen_name" : "gatewaypundit",
        "indices" : [ 99, 113 ],
        "id_str" : "19211550",
        "id" : 19211550
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/6KpwxyGwU1",
        "expanded_url" : "https:\/\/shar.es\/1ub5wc",
        "display_url" : "shar.es\/1ub5wc"
      } ]
    },
    "geo" : { },
    "id_str" : "652552367762640896",
    "text" : "HUNDREDS TURN OUT to Protest Barack Obama in Oregon \u201CGo Golf!\u201D (VIDEO) https:\/\/t.co\/6KpwxyGwU1 via @gatewaypundit",
    "id" : 652552367762640896,
    "created_at" : "2015-10-09 18:33:02 +0000",
    "user" : {
      "name" : "Jim Hoft",
      "screen_name" : "gatewaypundit",
      "protected" : false,
      "id_str" : "19211550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2333537481\/cunytcjxusinsxkh9vex_normal.jpeg",
      "id" : 19211550,
      "verified" : false
    }
  },
  "id" : 652642267044446208,
  "created_at" : "2015-10-10 00:30:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Campo",
      "screen_name" : "CampoRetro",
      "indices" : [ 0, 11 ],
      "id_str" : "1498194906",
      "id" : 1498194906
    }, {
      "name" : "Abraham",
      "screen_name" : "Abzdeman20",
      "indices" : [ 12, 23 ],
      "id_str" : "280201001",
      "id" : 280201001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652490003440926720",
  "geo" : { },
  "id_str" : "652557133624573952",
  "in_reply_to_user_id" : 1498194906,
  "text" : "@CampoRetro @Abzdeman20 That was epic :P",
  "id" : 652557133624573952,
  "in_reply_to_status_id" : 652490003440926720,
  "created_at" : "2015-10-09 18:51:59 +0000",
  "in_reply_to_screen_name" : "CampoRetro",
  "in_reply_to_user_id_str" : "1498194906",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "indices" : [ 3, 14 ],
      "id_str" : "222482865",
      "id" : 222482865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amitava235\/status\/652295222660059136\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/04fknVpDcp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1rDGxVAAA6peP.jpg",
      "id_str" : "652295222139879424",
      "id" : 652295222139879424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1rDGxVAAA6peP.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/04fknVpDcp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/wIYknyCRdk",
      "expanded_url" : "http:\/\/tvista.in\/1Ljbfw4",
      "display_url" : "tvista.in\/1Ljbfw4"
    } ]
  },
  "geo" : { },
  "id_str" : "652295683437920256",
  "text" : "RT @amitava235: \u201CBlack\u201D holes turn the universe around them into \u201Cbright\u201D spots\nRead on: http:\/\/t.co\/wIYknyCRdk http:\/\/t.co\/04fknVpDcp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amitava235\/status\/652295222660059136\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/04fknVpDcp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1rDGxVAAA6peP.jpg",
        "id_str" : "652295222139879424",
        "id" : 652295222139879424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1rDGxVAAA6peP.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/04fknVpDcp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/wIYknyCRdk",
        "expanded_url" : "http:\/\/tvista.in\/1Ljbfw4",
        "display_url" : "tvista.in\/1Ljbfw4"
      } ]
    },
    "geo" : { },
    "id_str" : "652295222660059136",
    "text" : "\u201CBlack\u201D holes turn the universe around them into \u201Cbright\u201D spots\nRead on: http:\/\/t.co\/wIYknyCRdk http:\/\/t.co\/04fknVpDcp",
    "id" : 652295222660059136,
    "created_at" : "2015-10-09 01:31:14 +0000",
    "user" : {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "protected" : false,
      "id_str" : "222482865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556878626906722304\/R-U_SUZW_normal.jpeg",
      "id" : 222482865,
      "verified" : false
    }
  },
  "id" : 652295683437920256,
  "created_at" : "2015-10-09 01:33:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "indices" : [ 0, 11 ],
      "id_str" : "222482865",
      "id" : 222482865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Epic",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652295222660059136",
  "geo" : { },
  "id_str" : "652295418425004033",
  "in_reply_to_user_id" : 222482865,
  "text" : "@amitava235 Wait what? #Epic",
  "id" : 652295418425004033,
  "in_reply_to_status_id" : 652295222660059136,
  "created_at" : "2015-10-09 01:32:01 +0000",
  "in_reply_to_screen_name" : "amitava235",
  "in_reply_to_user_id_str" : "222482865",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Pavlich",
      "screen_name" : "KatiePavlich",
      "indices" : [ 0, 13 ],
      "id_str" : "48459553",
      "id" : 48459553
    }, {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 14, 26 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "NRA",
      "screen_name" : "NRA",
      "indices" : [ 27, 31 ],
      "id_str" : "21829541",
      "id" : 21829541
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 32, 47 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652283592064823296",
  "geo" : { },
  "id_str" : "652295172714287104",
  "in_reply_to_user_id" : 48459553,
  "text" : "@KatiePavlich @seanhannity @NRA @HillaryClinton No common sense on Hillary's side",
  "id" : 652295172714287104,
  "in_reply_to_status_id" : 652283592064823296,
  "created_at" : "2015-10-09 01:31:02 +0000",
  "in_reply_to_screen_name" : "KatiePavlich",
  "in_reply_to_user_id_str" : "48459553",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Pavlich",
      "screen_name" : "KatiePavlich",
      "indices" : [ 3, 16 ],
      "id_str" : "48459553",
      "id" : 48459553
    }, {
      "name" : "NRA",
      "screen_name" : "NRA",
      "indices" : [ 39, 43 ],
      "id_str" : "21829541",
      "id" : 21829541
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 51, 66 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652295073439346689",
  "text" : "RT @KatiePavlich: Do you belong to the @nra? If so @HillaryClinton thinks you're the equivalent of an Iranian terrorist. I discuss w\/ @sean\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NRA",
        "screen_name" : "NRA",
        "indices" : [ 21, 25 ],
        "id_str" : "21829541",
        "id" : 21829541
      }, {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 33, 48 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      }, {
        "name" : "Sean Hannity",
        "screen_name" : "seanhannity",
        "indices" : [ 116, 128 ],
        "id_str" : "41634520",
        "id" : 41634520
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2A",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652283592064823296",
    "text" : "Do you belong to the @nra? If so @HillaryClinton thinks you're the equivalent of an Iranian terrorist. I discuss w\/ @seanhannity tonight #2A",
    "id" : 652283592064823296,
    "created_at" : "2015-10-09 00:45:01 +0000",
    "user" : {
      "name" : "Katie Pavlich",
      "screen_name" : "KatiePavlich",
      "protected" : false,
      "id_str" : "48459553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847903652450902021\/2OAKIJxp_normal.jpg",
      "id" : 48459553,
      "verified" : true
    }
  },
  "id" : 652295073439346689,
  "created_at" : "2015-10-09 01:30:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sour Patch Kids",
      "screen_name" : "SourPatchKids",
      "indices" : [ 23, 37 ],
      "id_str" : "122480273",
      "id" : 122480273
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/652294602263785472\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/BhjQ4K4PAY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1qetlUYAAWIMw.jpg",
      "id_str" : "652294596903329792",
      "id" : 652294596903329792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1qetlUYAAWIMw.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BhjQ4K4PAY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652294602263785472",
  "text" : "This gum is amazing!!! @SourPatchKids http:\/\/t.co\/BhjQ4K4PAY",
  "id" : 652294602263785472,
  "created_at" : "2015-10-09 01:28:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/652206189229568000\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/MaQ2gvRMCx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ0aArmUcAA1v9d.jpg",
      "id_str" : "652206120044359680",
      "id" : 652206120044359680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ0aArmUcAA1v9d.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MaQ2gvRMCx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652206189229568000",
  "text" : "Exposing the evil behind Oakland University's vending machines. Stupid candy http:\/\/t.co\/MaQ2gvRMCx",
  "id" : 652206189229568000,
  "created_at" : "2015-10-08 19:37:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651969660645052417",
  "text" : "RT @tedcruz: I am excited to have the support of such an accomplished group of courageous conservatives in Michigan: https:\/\/t.co\/HTOpUCHzd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CruzCrew",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/HTOpUCHzd5",
        "expanded_url" : "https:\/\/www.tedcruz.org\/news\/cruz-for-president-announces-michigan-grassroots-leadership-team\/",
        "display_url" : "tedcruz.org\/news\/cruz-for-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651864979365212160",
    "text" : "I am excited to have the support of such an accomplished group of courageous conservatives in Michigan: https:\/\/t.co\/HTOpUCHzd5 #CruzCrew",
    "id" : 651864979365212160,
    "created_at" : "2015-10-07 21:01:36 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 651969660645052417,
  "created_at" : "2015-10-08 03:57:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crysta Mobbs",
      "screen_name" : "mobbs_crysta",
      "indices" : [ 0, 13 ],
      "id_str" : "1447950116",
      "id" : 1447950116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651071661177982976",
  "geo" : { },
  "id_str" : "651969109052133381",
  "in_reply_to_user_id" : 1447950116,
  "text" : "@mobbs_crysta Why would someone touch your legs, that is harassment, unless it is your family, it is just weird.",
  "id" : 651969109052133381,
  "in_reply_to_status_id" : 651071661177982976,
  "created_at" : "2015-10-08 03:55:23 +0000",
  "in_reply_to_screen_name" : "mobbs_crysta",
  "in_reply_to_user_id_str" : "1447950116",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651958613037072384",
  "text" : "Just why????????",
  "id" : 651958613037072384,
  "created_at" : "2015-10-08 03:13:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "indices" : [ 3, 16 ],
      "id_str" : "26257166",
      "id" : 26257166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651958453401862144",
  "text" : "RT @SportsCenter: GO CUBS GO! Chicago Cubs win their first postseason game since 2003, advance to face the Cardinals in the NLDS. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SportsCenter\/status\/651954213459730432\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/093u9CMT9M",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CQw05wpXAAA88v1.png",
        "id_str" : "651954212977442816",
        "id" : 651954212977442816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CQw05wpXAAA88v1.png",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/093u9CMT9M"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651954213459730432",
    "text" : "GO CUBS GO! Chicago Cubs win their first postseason game since 2003, advance to face the Cardinals in the NLDS. http:\/\/t.co\/093u9CMT9M",
    "id" : 651954213459730432,
    "created_at" : "2015-10-08 02:56:11 +0000",
    "user" : {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "protected" : false,
      "id_str" : "26257166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841791006978768897\/wZXGsOZc_normal.jpg",
      "id" : 26257166,
      "verified" : true
    }
  },
  "id" : 651958453401862144,
  "created_at" : "2015-10-08 03:13:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651958316168404996",
  "text" : "RT @seanhannity: Question of the Day: Do you think President Obama should address the violence in inner cities instead of going to Oregon? \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651954696509231104",
    "text" : "Question of the Day: Do you think President Obama should address the violence in inner cities instead of going to Oregon? #Hannity",
    "id" : 651954696509231104,
    "created_at" : "2015-10-08 02:58:07 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 651958316168404996,
  "created_at" : "2015-10-08 03:12:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 3, 8 ],
      "id_str" : "2557521",
      "id" : 2557521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651958239353933824",
  "text" : "RT @espn: Go wild, Windy City!\n\nFor the first time in 12 years, the Cubs have won a playoff game, beating the Pirates 4-0. http:\/\/t.co\/TJ4T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/espn\/status\/651954283764695040\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/TJ4Tmut226",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQwx98nWgAAOjtI.jpg",
        "id_str" : "651950986374840320",
        "id" : 651950986374840320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQwx98nWgAAOjtI.jpg",
        "sizes" : [ {
          "h" : 466,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 715
        } ],
        "display_url" : "pic.twitter.com\/TJ4Tmut226"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651954283764695040",
    "text" : "Go wild, Windy City!\n\nFor the first time in 12 years, the Cubs have won a playoff game, beating the Pirates 4-0. http:\/\/t.co\/TJ4Tmut226",
    "id" : 651954283764695040,
    "created_at" : "2015-10-08 02:56:28 +0000",
    "user" : {
      "name" : "ESPN",
      "screen_name" : "espn",
      "protected" : false,
      "id_str" : "2557521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841837141000896513\/Ou_VuHAq_normal.jpg",
      "id" : 2557521,
      "verified" : true
    }
  },
  "id" : 651958239353933824,
  "created_at" : "2015-10-08 03:12:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grant schwomeyer",
      "screen_name" : "gschwo",
      "indices" : [ 3, 10 ],
      "id_str" : "126357484",
      "id" : 126357484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651958177718669313",
  "text" : "RT @gschwo: Cubs win!! First postseason win in 12 years let's go!  \uD83D\uDC3B\uD83D\uDD25",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651954416505982977",
    "text" : "Cubs win!! First postseason win in 12 years let's go!  \uD83D\uDC3B\uD83D\uDD25",
    "id" : 651954416505982977,
    "created_at" : "2015-10-08 02:57:00 +0000",
    "user" : {
      "name" : "grant schwomeyer",
      "screen_name" : "gschwo",
      "protected" : false,
      "id_str" : "126357484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696822448038268929\/-yEhKerh_normal.jpg",
      "id" : 126357484,
      "verified" : false
    }
  },
  "id" : 651958177718669313,
  "created_at" : "2015-10-08 03:11:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651930364840136704",
  "text" : "Whatever challenges I face, whatever pain I grieve, Glory be to God, that's all I have to say",
  "id" : 651930364840136704,
  "created_at" : "2015-10-08 01:21:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651860584737210368",
  "geo" : { },
  "id_str" : "651861217670205440",
  "in_reply_to_user_id" : 153832325,
  "text" : "@supagirlx sorry for your loss",
  "id" : 651861217670205440,
  "in_reply_to_status_id" : 651860584737210368,
  "created_at" : "2015-10-07 20:46:39 +0000",
  "in_reply_to_screen_name" : "ecmorrison_",
  "in_reply_to_user_id_str" : "153832325",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/suySwa0UWB",
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/651860818972307457",
      "display_url" : "twitter.com\/engadget\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651861044781056000",
  "text" : "Whoa https:\/\/t.co\/suySwa0UWB",
  "id" : 651861044781056000,
  "created_at" : "2015-10-07 20:45:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/534142760052207619\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/eaA1yy2DGJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2moAkxCQAA013V.png",
      "id_str" : "534142758642925568",
      "id" : 534142758642925568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2moAkxCQAA013V.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 1017
      } ],
      "display_url" : "pic.twitter.com\/eaA1yy2DGJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KnwOFIChoI",
      "expanded_url" : "http:\/\/goo.gl\/X6gS0J",
      "display_url" : "goo.gl\/X6gS0J"
    } ]
  },
  "geo" : { },
  "id_str" : "651860915973947393",
  "text" : "RT @BestGamezUp: The craziest rumored PlayStation 4 designs http:\/\/t.co\/KnwOFIChoI http:\/\/t.co\/eaA1yy2DGJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/534142760052207619\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/eaA1yy2DGJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2moAkxCQAA013V.png",
        "id_str" : "534142758642925568",
        "id" : 534142758642925568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2moAkxCQAA013V.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1017
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1017
        } ],
        "display_url" : "pic.twitter.com\/eaA1yy2DGJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/KnwOFIChoI",
        "expanded_url" : "http:\/\/goo.gl\/X6gS0J",
        "display_url" : "goo.gl\/X6gS0J"
      } ]
    },
    "geo" : { },
    "id_str" : "651860452335616001",
    "text" : "The craziest rumored PlayStation 4 designs http:\/\/t.co\/KnwOFIChoI http:\/\/t.co\/eaA1yy2DGJ",
    "id" : 651860452335616001,
    "created_at" : "2015-10-07 20:43:37 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 651860915973947393,
  "created_at" : "2015-10-07 20:45:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 0, 13 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651421849780396032",
  "geo" : { },
  "id_str" : "651422074414702592",
  "in_reply_to_user_id" : 18433619,
  "text" : "@buysellshort Stock trades, awesome, gotta analyze them well in a global economy",
  "id" : 651422074414702592,
  "in_reply_to_status_id" : 651421849780396032,
  "created_at" : "2015-10-06 15:41:40 +0000",
  "in_reply_to_screen_name" : "buysellshort",
  "in_reply_to_user_id_str" : "18433619",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/WDcKtJ8FmO",
      "expanded_url" : "http:\/\/fb.me\/3nNGy8vVN",
      "display_url" : "fb.me\/3nNGy8vVN"
    } ]
  },
  "geo" : { },
  "id_str" : "651421737981202433",
  "text" : "RT @EmperorDarroux: Microsoft announces Surface Pro 4 http:\/\/t.co\/WDcKtJ8FmO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/WDcKtJ8FmO",
        "expanded_url" : "http:\/\/fb.me\/3nNGy8vVN",
        "display_url" : "fb.me\/3nNGy8vVN"
      } ]
    },
    "geo" : { },
    "id_str" : "651421393993621504",
    "text" : "Microsoft announces Surface Pro 4 http:\/\/t.co\/WDcKtJ8FmO",
    "id" : 651421393993621504,
    "created_at" : "2015-10-06 15:38:57 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 651421737981202433,
  "created_at" : "2015-10-06 15:40:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 0, 13 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651420931160719360",
  "geo" : { },
  "id_str" : "651421646440501248",
  "in_reply_to_user_id" : 18433619,
  "text" : "@buysellshort Wait what???",
  "id" : 651421646440501248,
  "in_reply_to_status_id" : 651420931160719360,
  "created_at" : "2015-10-06 15:39:57 +0000",
  "in_reply_to_screen_name" : "buysellshort",
  "in_reply_to_user_id_str" : "18433619",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 49, 56 ],
      "id_str" : "24206345",
      "id" : 24206345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeedPhone",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/muaLoe1ADH",
      "expanded_url" : "https:\/\/twitter.com\/emperordarroux\/status\/651421209280688128",
      "display_url" : "twitter.com\/emperordarroux\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651421512310870016",
  "text" : "I seen an inventor make something similar before @Quirky #SeedPhone https:\/\/t.co\/muaLoe1ADH",
  "id" : 651421512310870016,
  "created_at" : "2015-10-06 15:39:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/651421065781112832\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/gBc9O6pi8I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQpP_9cUEAEHPKQ.jpg",
      "id_str" : "651421056352129025",
      "id" : 651421056352129025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQpP_9cUEAEHPKQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gBc9O6pi8I"
    } ],
    "hashtags" : [ {
      "text" : "HelloUniverse",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651421065781112832",
  "text" : "Day#1 of diet and it is already broken, but gonna be active to make up for it, #HelloUniverse http:\/\/t.co\/gBc9O6pi8I",
  "id" : 651421065781112832,
  "created_at" : "2015-10-06 15:37:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Sky 1",
      "screen_name" : "sky1",
      "indices" : [ 13, 18 ],
      "id_str" : "36909344",
      "id" : 36909344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648200240663789568",
  "geo" : { },
  "id_str" : "651205101768409090",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze @sky1 LOL \uD83D\uDE03\uD83D\uDE02\uD83D\uDE00\uD83D\uDE27\uD83D\uDE2E\uD83D\uDC72\uD83C\uDFFC\uD83D\uDC7D\uD83D\uDCAA\uD83C\uDFFD",
  "id" : 651205101768409090,
  "in_reply_to_status_id" : 648200240663789568,
  "created_at" : "2015-10-06 01:19:29 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Luc",
      "screen_name" : "JetVapour",
      "indices" : [ 17, 27 ],
      "id_str" : "23901547",
      "id" : 23901547
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651204689036337152",
  "text" : "RT @colin_furze: @JetVapour few weeks time. You've got assassins creed gadgets between.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luc",
        "screen_name" : "JetVapour",
        "indices" : [ 0, 10 ],
        "id_str" : "23901547",
        "id" : 23901547
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "650802840391122944",
    "geo" : { },
    "id_str" : "650933798507577344",
    "in_reply_to_user_id" : 23901547,
    "text" : "@JetVapour few weeks time. You've got assassins creed gadgets between.",
    "id" : 650933798507577344,
    "in_reply_to_status_id" : 650802840391122944,
    "created_at" : "2015-10-05 07:21:25 +0000",
    "in_reply_to_screen_name" : "JetVapour",
    "in_reply_to_user_id_str" : "23901547",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 651204689036337152,
  "created_at" : "2015-10-06 01:17:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ApocalypseSky1",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/p2MXoT5JfG",
      "expanded_url" : "http:\/\/bit.ly\/1GauKRP",
      "display_url" : "bit.ly\/1GauKRP"
    } ]
  },
  "geo" : { },
  "id_str" : "651204664684253184",
  "text" : "RT @colin_furze: Bunker progressing, ep4 a few weeks away but check out the series so for here http:\/\/t.co\/p2MXoT5JfG #ApocalypseSky1 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/651079116201066501\/video\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Fn1ybup2nP",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/651078754169700352\/pu\/img\/Xbiq9tlnUtXPhXwW.jpg",
        "id_str" : "651078754169700352",
        "id" : 651078754169700352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/651078754169700352\/pu\/img\/Xbiq9tlnUtXPhXwW.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 854
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Fn1ybup2nP"
      } ],
      "hashtags" : [ {
        "text" : "ApocalypseSky1",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/p2MXoT5JfG",
        "expanded_url" : "http:\/\/bit.ly\/1GauKRP",
        "display_url" : "bit.ly\/1GauKRP"
      } ]
    },
    "geo" : { },
    "id_str" : "651079116201066501",
    "text" : "Bunker progressing, ep4 a few weeks away but check out the series so for here http:\/\/t.co\/p2MXoT5JfG #ApocalypseSky1 http:\/\/t.co\/Fn1ybup2nP",
    "id" : 651079116201066501,
    "created_at" : "2015-10-05 16:58:52 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 651204664684253184,
  "created_at" : "2015-10-06 01:17:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple iOS",
      "screen_name" : "appleios",
      "indices" : [ 0, 9 ],
      "id_str" : "130942339",
      "id" : 130942339
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 10, 16 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/651204326740787200\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/wJnbwv8rEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQmK4Z9U8AEp0Ye.jpg",
      "id_str" : "651204322777165825",
      "id" : 651204322777165825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQmK4Z9U8AEp0Ye.jpg",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/wJnbwv8rEx"
    } ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651204326740787200",
  "in_reply_to_user_id" : 130942339,
  "text" : "@appleios @Gmail What is up with these random gmail loading errors on iPhone 5c? #fail http:\/\/t.co\/wJnbwv8rEx",
  "id" : 651204326740787200,
  "created_at" : "2015-10-06 01:16:24 +0000",
  "in_reply_to_screen_name" : "appleios",
  "in_reply_to_user_id_str" : "130942339",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "josef_lokmani",
      "indices" : [ 0, 14 ],
      "id_str" : "817767898987069441",
      "id" : 817767898987069441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651106149769437184",
  "text" : "@josef_lokmani Thanks, I needed that :) Maybe I should start dieting",
  "id" : 651106149769437184,
  "created_at" : "2015-10-05 18:46:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651025969009020928",
  "text" : "When people don't want to talk to you or are one ended in a conversation, you can tell #OU",
  "id" : 651025969009020928,
  "created_at" : "2015-10-05 13:27:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/651021682212257792\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/w7uh5ki6PZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQjkxANUwAAVP-f.jpg",
      "id_str" : "651021676675645440",
      "id" : 651021676675645440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQjkxANUwAAVP-f.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w7uh5ki6PZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651021682212257792",
  "text" : "Having this for lunch ;) http:\/\/t.co\/w7uh5ki6PZ",
  "id" : 651021682212257792,
  "created_at" : "2015-10-05 13:10:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 18, 28 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/651013870165852160\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/LfjtgbhOyW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQjdqNvWcAA2A9p.jpg",
      "id_str" : "651013863467544576",
      "id" : 651013863467544576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQjdqNvWcAA2A9p.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LfjtgbhOyW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651013870165852160",
  "text" : "I tried a chilled @Starbucks Pumpkin Spice Latte (chilled), don't get what the big deal was, not the best ;) http:\/\/t.co\/LfjtgbhOyW",
  "id" : 651013870165852160,
  "created_at" : "2015-10-05 12:39:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/sMbUrwrbgQ",
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/650645392724492288",
      "display_url" : "twitter.com\/colin_furze\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650713402113982464",
  "text" : "Wait what\uD83D\uDE2F https:\/\/t.co\/sMbUrwrbgQ",
  "id" : 650713402113982464,
  "created_at" : "2015-10-04 16:45:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/650713144218775553\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/1hCvt6BPtx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQfMIKtWEAASsTL.jpg",
      "id_str" : "650713111863889920",
      "id" : 650713111863889920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQfMIKtWEAASsTL.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1hCvt6BPtx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650713144218775553",
  "text" : "This was probably overkill http:\/\/t.co\/1hCvt6BPtx",
  "id" : 650713144218775553,
  "created_at" : "2015-10-04 16:44:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/650332283719716864\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/yKpCa0qa1Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQZxwt3U8AAzuo5.jpg",
      "id_str" : "650332277960929280",
      "id" : 650332277960929280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQZxwt3U8AAzuo5.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yKpCa0qa1Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650332283719716864",
  "text" : "I like candy, don't judge me :&lt;) http:\/\/t.co\/yKpCa0qa1Y",
  "id" : 650332283719716864,
  "created_at" : "2015-10-03 15:31:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649955416571518976",
  "text" : "Went to the OU bake-sale today, would have took a picture but I was very hungry #ThisIsOU",
  "id" : 649955416571518976,
  "created_at" : "2015-10-02 14:33:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]