Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/5ibc550WQG",
      "expanded_url" : "http:\/\/youtu.be\/ntvBa6u9ldY",
      "display_url" : "youtu.be\/ntvBa6u9ldY"
    } ]
  },
  "geo" : { },
  "id_str" : "560981813053509632",
  "text" : "RT @colin_furze: Furze's Invention show - JETWIPE: http:\/\/t.co\/5ibc550WQG via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 61, 69 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/5ibc550WQG",
        "expanded_url" : "http:\/\/youtu.be\/ntvBa6u9ldY",
        "display_url" : "youtu.be\/ntvBa6u9ldY"
      } ]
    },
    "geo" : { },
    "id_str" : "560897390937640960",
    "text" : "Furze's Invention show - JETWIPE: http:\/\/t.co\/5ibc550WQG via @YouTube",
    "id" : 560897390937640960,
    "created_at" : "2015-01-29 20:28:53 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 560981813053509632,
  "created_at" : "2015-01-30 02:04:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/560975061314584576\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/KC3CeLXFF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8j72G5CEAAO-pZ.jpg",
      "id_str" : "560975060588957696",
      "id" : 560975060588957696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8j72G5CEAAO-pZ.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/KC3CeLXFF0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560975061314584576",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice I was shocked to see this at my college, very anti-American, the comment itself is disturbing http:\/\/t.co\/KC3CeLXFF0",
  "id" : 560975061314584576,
  "created_at" : "2015-01-30 01:37:31 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MR",
      "indices" : [ 24, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560963406513971200",
  "text" : "It was a Gyro day today #MR.PITA",
  "id" : 560963406513971200,
  "created_at" : "2015-01-30 00:51:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558387127377854464",
  "text" : "Ask Colin Furze about his latest Karaoke clean, lol",
  "id" : 558387127377854464,
  "created_at" : "2015-01-22 22:14:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556703106977632256",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Did you set your feet on fire?",
  "id" : 556703106977632256,
  "created_at" : "2015-01-18 06:42:18 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556649420859506688",
  "text" : "Today was a nice day.",
  "id" : 556649420859506688,
  "created_at" : "2015-01-18 03:08:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hMidRccnx4",
      "expanded_url" : "http:\/\/youtu.be\/Zm6Dk4glS2k?a",
      "display_url" : "youtu.be\/Zm6Dk4glS2k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "556649347564044289",
  "text" : "RT @VigilantChrist: PUT THE REMOTE CONTROL DOWN &amp; GO OUTSIDE !!!  http:\/\/t.co\/hMidRccnx4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/hMidRccnx4",
        "expanded_url" : "http:\/\/youtu.be\/Zm6Dk4glS2k?a",
        "display_url" : "youtu.be\/Zm6Dk4glS2k?a"
      } ]
    },
    "geo" : { },
    "id_str" : "556587412193689600",
    "text" : "PUT THE REMOTE CONTROL DOWN &amp; GO OUTSIDE !!!  http:\/\/t.co\/hMidRccnx4",
    "id" : 556587412193689600,
    "created_at" : "2015-01-17 23:02:34 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 556649347564044289,
  "created_at" : "2015-01-18 03:08:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/AfTg3vahAK",
      "expanded_url" : "http:\/\/youtu.be\/Uw7FWYBqTC4?a",
      "display_url" : "youtu.be\/Uw7FWYBqTC4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "556649334083555328",
  "text" : "RT @VigilantChrist: POPE ATTACKS FREE SPEECH SAYING IT HAS LIMITATIONS !!!  http:\/\/t.co\/AfTg3vahAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/AfTg3vahAK",
        "expanded_url" : "http:\/\/youtu.be\/Uw7FWYBqTC4?a",
        "display_url" : "youtu.be\/Uw7FWYBqTC4?a"
      } ]
    },
    "geo" : { },
    "id_str" : "556482048173424640",
    "text" : "POPE ATTACKS FREE SPEECH SAYING IT HAS LIMITATIONS !!!  http:\/\/t.co\/AfTg3vahAK",
    "id" : 556482048173424640,
    "created_at" : "2015-01-17 16:03:53 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 556649334083555328,
  "created_at" : "2015-01-18 03:08:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/556649039635021824\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/FNPq7zL5N5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7mdWegCEAAuKiz.jpg",
      "id_str" : "556649038427066368",
      "id" : 556649038427066368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7mdWegCEAAuKiz.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FNPq7zL5N5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556649039635021824",
  "text" : "Food selfie, lol \uD83D\uDE06 http:\/\/t.co\/FNPq7zL5N5",
  "id" : 556649039635021824,
  "created_at" : "2015-01-18 03:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/HGmyL5NJSp",
      "expanded_url" : "http:\/\/youtu.be\/n9INTt_3yNo?a",
      "display_url" : "youtu.be\/n9INTt_3yNo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "555045480707538944",
  "text" : "RT @VigilantChrist: PROOF INTERNET TROLLS ARE MENTALLY ILL !!! Troll Psychology EXPOSED !!! http:\/\/t.co\/HGmyL5NJSp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/HGmyL5NJSp",
        "expanded_url" : "http:\/\/youtu.be\/n9INTt_3yNo?a",
        "display_url" : "youtu.be\/n9INTt_3yNo?a"
      } ]
    },
    "geo" : { },
    "id_str" : "554670197215227904",
    "text" : "PROOF INTERNET TROLLS ARE MENTALLY ILL !!! Troll Psychology EXPOSED !!! http:\/\/t.co\/HGmyL5NJSp",
    "id" : 554670197215227904,
    "created_at" : "2015-01-12 16:04:14 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 555045480707538944,
  "created_at" : "2015-01-13 16:55:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Cauguiran",
      "screen_name" : "kidguru",
      "indices" : [ 3, 11 ],
      "id_str" : "11828962",
      "id" : 11828962
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BiTk26CyFK",
      "expanded_url" : "http:\/\/screencapp.com",
      "display_url" : "screencapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "555045277577400320",
  "text" : "RT @kidguru: @gamer456148 Hey Andrew! We recently just introduce android based reviews exclusively for http:\/\/t.co\/BiTk26CyFK clients",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/BiTk26CyFK",
        "expanded_url" : "http:\/\/screencapp.com",
        "display_url" : "screencapp.com"
      } ]
    },
    "in_reply_to_status_id_str" : "489932123239755776",
    "geo" : { },
    "id_str" : "489952538930606080",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Hey Andrew! We recently just introduce android based reviews exclusively for http:\/\/t.co\/BiTk26CyFK clients",
    "id" : 489952538930606080,
    "in_reply_to_status_id" : 489932123239755776,
    "created_at" : "2014-07-18 01:59:22 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Adrian Cauguiran",
      "screen_name" : "kidguru",
      "protected" : false,
      "id_str" : "11828962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796589722189500416\/q_rp0qNZ_normal.jpg",
      "id" : 11828962,
      "verified" : false
    }
  },
  "id" : 555045277577400320,
  "created_at" : "2015-01-13 16:54:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "indices" : [ 3, 16 ],
      "id_str" : "43532936",
      "id" : 43532936
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/u9RVjUAmuO",
      "expanded_url" : "http:\/\/gu.com\/p\/44kzj\/stw",
      "display_url" : "gu.com\/p\/44kzj\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "555045088842108928",
  "text" : "RT @cohasset_kid: @gamer456148 interesting \u2192 \"Egyptian president attends Coptic Christmas Eve mass in Cairo\" http:\/\/t.co\/u9RVjUAmuO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.yoono.com\" rel=\"nofollow\"\u003Eyoono\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/u9RVjUAmuO",
        "expanded_url" : "http:\/\/gu.com\/p\/44kzj\/stw",
        "display_url" : "gu.com\/p\/44kzj\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "552934686083649536",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 interesting \u2192 \"Egyptian president attends Coptic Christmas Eve mass in Cairo\" http:\/\/t.co\/u9RVjUAmuO",
    "id" : 552934686083649536,
    "created_at" : "2015-01-07 21:07:56 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "protected" : false,
      "id_str" : "43532936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592433281850716160\/JPeYcsA7_normal.jpg",
      "id" : 43532936,
      "verified" : false
    }
  },
  "id" : 555045088842108928,
  "created_at" : "2015-01-13 16:53:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 14, 26 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555044998257717249",
  "text" : "RT @MarkDice: @gamer456148 I'm done with the conspiracy kooks.  Lost souls.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "555017209030774785",
    "geo" : { },
    "id_str" : "555031870925066241",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I'm done with the conspiracy kooks.  Lost souls.",
    "id" : 555031870925066241,
    "in_reply_to_status_id" : 555017209030774785,
    "created_at" : "2015-01-13 16:01:24 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 555044998257717249,
  "created_at" : "2015-01-13 16:53:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555018228708020224",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice You can thank all those trolls for the adsense. Since they are pathetically hating on you.",
  "id" : 555018228708020224,
  "created_at" : "2015-01-13 15:07:12 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554849613543256064",
  "geo" : { },
  "id_str" : "555017209030774785",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice It is like the fake snow crap all over again. People need to research things.",
  "id" : 555017209030774785,
  "in_reply_to_status_id" : 554849613543256064,
  "created_at" : "2015-01-13 15:03:09 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 14, 26 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555016343917830145",
  "text" : "RT @MarkDice: @gamer456148 that's what I said in the video.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "554817755694653440",
    "geo" : { },
    "id_str" : "554849613543256064",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 that's what I said in the video.",
    "id" : 554849613543256064,
    "in_reply_to_status_id" : 554817755694653440,
    "created_at" : "2015-01-13 03:57:11 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 555016343917830145,
  "created_at" : "2015-01-13 14:59:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554818132762558464",
  "text" : "I love the Coptic community!!",
  "id" : 554818132762558464,
  "created_at" : "2015-01-13 01:52:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554818057042812928",
  "text" : "Had Cottage inn today, wish it was that Halal pizza place in Dearborn.",
  "id" : 554818057042812928,
  "created_at" : "2015-01-13 01:51:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 83, 92 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554817755694653440",
  "text" : "Les Illumines means fanatics or crazy people. Don't think it means something else. @markdice",
  "id" : 554817755694653440,
  "created_at" : "2015-01-13 01:50:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554408547912413184",
  "text" : "I had a great but tiring week.",
  "id" : 554408547912413184,
  "created_at" : "2015-01-11 22:44:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552932687539736576",
  "text" : "Happy Christmas to my Coptic peeps.",
  "id" : 552932687539736576,
  "created_at" : "2015-01-07 21:00:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    }, {
      "name" : "DCCC",
      "screen_name" : "dccc",
      "indices" : [ 23, 28 ],
      "id_str" : "14676022",
      "id" : 14676022
    }, {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 40, 53 ],
      "id_str" : "342887079",
      "id" : 342887079
    }, {
      "name" : "POLITICO",
      "screen_name" : "politico",
      "indices" : [ 58, 67 ],
      "id_str" : "9300262",
      "id" : 9300262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/2iAx7yYUpE",
      "expanded_url" : "http:\/\/politi.co\/1o3TK48",
      "display_url" : "politi.co\/1o3TK48"
    } ]
  },
  "geo" : { },
  "id_str" : "552932581079920641",
  "text" : "RT @rushlimbaugh: The .@DCCC lie about .@RushLimbaugh in .@politico: http:\/\/t.co\/2iAx7yYUpE. Don\u2019t let them raise funds this way. Spread th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DCCC",
        "screen_name" : "dccc",
        "indices" : [ 5, 10 ],
        "id_str" : "14676022",
        "id" : 14676022
      }, {
        "name" : "Rush Limbaugh",
        "screen_name" : "rushlimbaugh",
        "indices" : [ 22, 35 ],
        "id_str" : "342887079",
        "id" : 342887079
      }, {
        "name" : "POLITICO",
        "screen_name" : "politico",
        "indices" : [ 40, 49 ],
        "id_str" : "9300262",
        "id" : 9300262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/2iAx7yYUpE",
        "expanded_url" : "http:\/\/politi.co\/1o3TK48",
        "display_url" : "politi.co\/1o3TK48"
      } ]
    },
    "geo" : { },
    "id_str" : "512336974514892800",
    "text" : "The .@DCCC lie about .@RushLimbaugh in .@politico: http:\/\/t.co\/2iAx7yYUpE. Don\u2019t let them raise funds this way. Spread the word.",
    "id" : 512336974514892800,
    "created_at" : "2014-09-17 20:27:08 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 552932581079920641,
  "created_at" : "2015-01-07 20:59:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552932175876603904",
  "text" : "RT @SenTedCruz: Thoughts and prayers are with those impacted by the shooting at the El Paso VA and the first responders who acted heroicall\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "552638065484005377",
    "text" : "Thoughts and prayers are with those impacted by the shooting at the El Paso VA and the first responders who acted heroically this evening.",
    "id" : 552638065484005377,
    "created_at" : "2015-01-07 01:29:16 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 552932175876603904,
  "created_at" : "2015-01-07 20:57:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Network",
      "screen_name" : "FoodNetwork",
      "indices" : [ 3, 15 ],
      "id_str" : "20710809",
      "id" : 20710809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoodNetwork\/status\/552657133217382401\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/tQFWqHj2FI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6tuvAQCYAAKP3l.jpg",
      "id_str" : "552657133083189248",
      "id" : 552657133083189248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6tuvAQCYAAKP3l.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tQFWqHj2FI"
    } ],
    "hashtags" : [ {
      "text" : "Chopped",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552931771650568192",
  "text" : "RT @FoodNetwork: See these chefs cook with ingredients chosen by fans on tonight's new #Chopped at 10|9c! http:\/\/t.co\/tQFWqHj2FI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scrippsnetworksinteractive.com\/\" rel=\"nofollow\"\u003EScripps Networks\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoodNetwork\/status\/552657133217382401\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/tQFWqHj2FI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6tuvAQCYAAKP3l.jpg",
        "id_str" : "552657133083189248",
        "id" : 552657133083189248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6tuvAQCYAAKP3l.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tQFWqHj2FI"
      } ],
      "hashtags" : [ {
        "text" : "Chopped",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "552657133217382401",
    "text" : "See these chefs cook with ingredients chosen by fans on tonight's new #Chopped at 10|9c! http:\/\/t.co\/tQFWqHj2FI",
    "id" : 552657133217382401,
    "created_at" : "2015-01-07 02:45:03 +0000",
    "user" : {
      "name" : "Food Network",
      "screen_name" : "FoodNetwork",
      "protected" : false,
      "id_str" : "20710809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776883129600602113\/gKHSt5W6_normal.jpg",
      "id" : 20710809,
      "verified" : true
    }
  },
  "id" : 552931771650568192,
  "created_at" : "2015-01-07 20:56:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552816417150885888",
  "geo" : { },
  "id_str" : "552931383287377920",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze How are you so cool? Lol",
  "id" : 552931383287377920,
  "in_reply_to_status_id" : 552816417150885888,
  "created_at" : "2015-01-07 20:54:49 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pewdiepie",
      "screen_name" : "pewdiepie",
      "indices" : [ 0, 10 ],
      "id_str" : "39538010",
      "id" : 39538010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552545793769750528",
  "geo" : { },
  "id_str" : "552931094668910593",
  "in_reply_to_user_id" : 39538010,
  "text" : "@pewdiepie I know you are an illuminati puppet. Your secrets are out. #2015",
  "id" : 552931094668910593,
  "in_reply_to_status_id" : 552545793769750528,
  "created_at" : "2015-01-07 20:53:40 +0000",
  "in_reply_to_screen_name" : "pewdiepie",
  "in_reply_to_user_id_str" : "39538010",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Upton",
      "screen_name" : "KateUpton",
      "indices" : [ 0, 10 ],
      "id_str" : "205915163",
      "id" : 205915163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550799782374309889",
  "geo" : { },
  "id_str" : "552930143698550784",
  "in_reply_to_user_id" : 205915163,
  "text" : "@KateUpton I wore cloth today and dressed modestly. Accomplished more then you already :)",
  "id" : 552930143698550784,
  "in_reply_to_status_id" : 550799782374309889,
  "created_at" : "2015-01-07 20:49:53 +0000",
  "in_reply_to_screen_name" : "KateUpton",
  "in_reply_to_user_id_str" : "205915163",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HTC Canada",
      "screen_name" : "HTCCanada",
      "indices" : [ 3, 13 ],
      "id_str" : "374199410",
      "id" : 374199410
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 47, 59 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HTCOneM8",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552281254956371969",
  "text" : "RT @HTCCanada: We are go for launch! Check out @Colin_Furze sending the #HTCOneM8 to the edge of space for an epic light show! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 32, 44 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HTCOneM8",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/FOVBVpkMUf",
        "expanded_url" : "http:\/\/s.htc.com\/1y4EZqY",
        "display_url" : "s.htc.com\/1y4EZqY"
      } ]
    },
    "geo" : { },
    "id_str" : "550705513886154752",
    "text" : "We are go for launch! Check out @Colin_Furze sending the #HTCOneM8 to the edge of space for an epic light show! http:\/\/t.co\/FOVBVpkMUf",
    "id" : 550705513886154752,
    "created_at" : "2015-01-01 17:30:00 +0000",
    "user" : {
      "name" : "HTC Canada",
      "screen_name" : "HTCCanada",
      "protected" : false,
      "id_str" : "374199410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3278376721\/171e382ee7b9e0ad6534c083991fae8b_normal.png",
      "id" : 374199410,
      "verified" : true
    }
  },
  "id" : 552281254956371969,
  "created_at" : "2015-01-06 01:51:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552280671591604225",
  "text" : "The Baghdad restaurant in 15 Mile Road Michigan is a good place for ordering take out",
  "id" : 552280671591604225,
  "created_at" : "2015-01-06 01:49:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550675623643869184",
  "text" : "My mom got me Jaguar Classic colonge'. She has a nice taste.",
  "id" : 550675623643869184,
  "created_at" : "2015-01-01 15:31:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]