Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProTip",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "business",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747232363852234752",
  "text" : "RT @BarbaraCorcoran: #ProTip: When your #business is young, only spend money on the things that directly lead to sales.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ProTip",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "business",
        "indices" : [ 19, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747054375525318656",
    "text" : "#ProTip: When your #business is young, only spend money on the things that directly lead to sales.",
    "id" : 747054375525318656,
    "created_at" : "2016-06-26 13:10:17 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 747232363852234752,
  "created_at" : "2016-06-27 00:57:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747232232495013888",
  "text" : "RT @tedcruz: We need conservative fighters like @SenMikeCrane in Congress: https:\/\/t.co\/17dB8nRI4y Join me in supporting him: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/17dB8nRI4y",
        "expanded_url" : "https:\/\/youtu.be\/SlgEi2nUMAs",
        "display_url" : "youtu.be\/SlgEi2nUMAs"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/SE2ezKLd3Y",
        "expanded_url" : "https:\/\/mikecraneforcongress.com",
        "display_url" : "mikecraneforcongress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "747193837676748800",
    "text" : "We need conservative fighters like @SenMikeCrane in Congress: https:\/\/t.co\/17dB8nRI4y Join me in supporting him: https:\/\/t.co\/SE2ezKLd3Y",
    "id" : 747193837676748800,
    "created_at" : "2016-06-26 22:24:27 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 747232232495013888,
  "created_at" : "2016-06-27 00:57:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747151063497773056\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/HWD3hNVEhU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl5p7khWQAAu6WE.jpg",
      "id_str" : "747151060326825984",
      "id" : 747151060326825984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl5p7khWQAAu6WE.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/HWD3hNVEhU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qKtyuZCw9Z",
      "expanded_url" : "http:\/\/engt.co\/28UAzZ7",
      "display_url" : "engt.co\/28UAzZ7"
    } ]
  },
  "geo" : { },
  "id_str" : "747232128354627586",
  "text" : "RT @engadget: South Korea hopes traffic signs will cut phone distractions https:\/\/t.co\/qKtyuZCw9Z https:\/\/t.co\/HWD3hNVEhU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747151063497773056\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/HWD3hNVEhU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl5p7khWQAAu6WE.jpg",
        "id_str" : "747151060326825984",
        "id" : 747151060326825984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl5p7khWQAAu6WE.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/HWD3hNVEhU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/qKtyuZCw9Z",
        "expanded_url" : "http:\/\/engt.co\/28UAzZ7",
        "display_url" : "engt.co\/28UAzZ7"
      } ]
    },
    "geo" : { },
    "id_str" : "747151063497773056",
    "text" : "South Korea hopes traffic signs will cut phone distractions https:\/\/t.co\/qKtyuZCw9Z https:\/\/t.co\/HWD3hNVEhU",
    "id" : 747151063497773056,
    "created_at" : "2016-06-26 19:34:29 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747232128354627586,
  "created_at" : "2016-06-27 00:56:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/747074570528690176\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/fmAqwjIkhC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4kXG1WEAAvUC9.jpg",
      "id_str" : "747074567580028928",
      "id" : 747074567580028928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4kXG1WEAAvUC9.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/fmAqwjIkhC"
    } ],
    "hashtags" : [ {
      "text" : "gradle",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747232079952416768",
  "text" : "RT @slidenerdtech: The best joke you will ever hear about the Gradle build system...#gradle https:\/\/t.co\/fmAqwjIkhC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/747074570528690176\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/fmAqwjIkhC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4kXG1WEAAvUC9.jpg",
        "id_str" : "747074567580028928",
        "id" : 747074567580028928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4kXG1WEAAvUC9.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/fmAqwjIkhC"
      } ],
      "hashtags" : [ {
        "text" : "gradle",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747074570528690176",
    "text" : "The best joke you will ever hear about the Gradle build system...#gradle https:\/\/t.co\/fmAqwjIkhC",
    "id" : 747074570528690176,
    "created_at" : "2016-06-26 14:30:32 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3626569194\/9efac426d5465cf43ae94b41838e0a51_normal.jpeg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 747232079952416768,
  "created_at" : "2016-06-27 00:56:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747071911331500033\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/4NFRA3qqWa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4h8VKWQAAEeuC.jpg",
      "id_str" : "747071908546494464",
      "id" : 747071908546494464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4h8VKWQAAEeuC.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/4NFRA3qqWa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/4oEYE3kfl8",
      "expanded_url" : "http:\/\/engt.co\/28TeWti",
      "display_url" : "engt.co\/28TeWti"
    } ]
  },
  "geo" : { },
  "id_str" : "747232015301349380",
  "text" : "RT @engadget: Google is offering a Udacity course for Android development newcomers https:\/\/t.co\/4oEYE3kfl8 https:\/\/t.co\/4NFRA3qqWa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747071911331500033\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/4NFRA3qqWa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4h8VKWQAAEeuC.jpg",
        "id_str" : "747071908546494464",
        "id" : 747071908546494464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4h8VKWQAAEeuC.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4NFRA3qqWa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/4oEYE3kfl8",
        "expanded_url" : "http:\/\/engt.co\/28TeWti",
        "display_url" : "engt.co\/28TeWti"
      } ]
    },
    "geo" : { },
    "id_str" : "747071911331500033",
    "text" : "Google is offering a Udacity course for Android development newcomers https:\/\/t.co\/4oEYE3kfl8 https:\/\/t.co\/4NFRA3qqWa",
    "id" : 747071911331500033,
    "created_at" : "2016-06-26 14:19:58 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747232015301349380,
  "created_at" : "2016-06-27 00:56:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/tAuplGQfSq",
      "expanded_url" : "http:\/\/engt.co\/28UrINb",
      "display_url" : "engt.co\/28UrINb"
    } ]
  },
  "geo" : { },
  "id_str" : "747231873894617088",
  "text" : "RT @engadget: Want to run Linux on your PS4? For now, you'll have to resort to some actual hacking https:\/\/t.co\/tAuplGQfSq https:\/\/t.co\/bQ9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746845748222918656\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/bQ9BIKObhz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl1UP8pXIAAVLQz.jpg",
        "id_str" : "746845746167750656",
        "id" : 746845746167750656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl1UP8pXIAAVLQz.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/bQ9BIKObhz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/tAuplGQfSq",
        "expanded_url" : "http:\/\/engt.co\/28UrINb",
        "display_url" : "engt.co\/28UrINb"
      } ]
    },
    "geo" : { },
    "id_str" : "746845748222918656",
    "text" : "Want to run Linux on your PS4? For now, you'll have to resort to some actual hacking https:\/\/t.co\/tAuplGQfSq https:\/\/t.co\/bQ9BIKObhz",
    "id" : 746845748222918656,
    "created_at" : "2016-06-25 23:21:16 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231873894617088,
  "created_at" : "2016-06-27 00:55:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/h2blLvkWFl",
      "expanded_url" : "http:\/\/engt.co\/28SKQZg",
      "display_url" : "engt.co\/28SKQZg"
    } ]
  },
  "geo" : { },
  "id_str" : "747231649700651008",
  "text" : "RT @engadget: NASA can send data to other spacecraft (or back to Earth) faster than ever before https:\/\/t.co\/h2blLvkWFl https:\/\/t.co\/YL45eG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746518266466664448\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/YL45eG3lJs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwqZ_eWIAAldjx.jpg",
        "id_str" : "746518264260468736",
        "id" : 746518264260468736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwqZ_eWIAAldjx.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/YL45eG3lJs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/h2blLvkWFl",
        "expanded_url" : "http:\/\/engt.co\/28SKQZg",
        "display_url" : "engt.co\/28SKQZg"
      } ]
    },
    "geo" : { },
    "id_str" : "746518266466664448",
    "text" : "NASA can send data to other spacecraft (or back to Earth) faster than ever before https:\/\/t.co\/h2blLvkWFl https:\/\/t.co\/YL45eG3lJs",
    "id" : 746518266466664448,
    "created_at" : "2016-06-25 01:39:59 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231649700651008,
  "created_at" : "2016-06-27 00:54:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746514121152143362\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/d0PN14a0dM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwmorhWIAAVmnf.jpg",
      "id_str" : "746514118555869184",
      "id" : 746514118555869184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwmorhWIAAVmnf.jpg",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/d0PN14a0dM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/AweHYtoDt0",
      "expanded_url" : "http:\/\/engt.co\/28Stzfk",
      "display_url" : "engt.co\/28Stzfk"
    } ]
  },
  "geo" : { },
  "id_str" : "747231615336779776",
  "text" : "RT @engadget: Nevada gives its first license to a daily fantasy sports game https:\/\/t.co\/AweHYtoDt0 https:\/\/t.co\/d0PN14a0dM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746514121152143362\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/d0PN14a0dM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClwmorhWIAAVmnf.jpg",
        "id_str" : "746514118555869184",
        "id" : 746514118555869184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClwmorhWIAAVmnf.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/d0PN14a0dM"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/AweHYtoDt0",
        "expanded_url" : "http:\/\/engt.co\/28Stzfk",
        "display_url" : "engt.co\/28Stzfk"
      } ]
    },
    "geo" : { },
    "id_str" : "746514121152143362",
    "text" : "Nevada gives its first license to a daily fantasy sports game https:\/\/t.co\/AweHYtoDt0 https:\/\/t.co\/d0PN14a0dM",
    "id" : 746514121152143362,
    "created_at" : "2016-06-25 01:23:30 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231615336779776,
  "created_at" : "2016-06-27 00:54:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747231570545762304",
  "text" : "RT @lorenridinger: \"Repeat after me: I am stronger than this challenge. And this challenge is making me even stronger.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746463038354636804",
    "text" : "\"Repeat after me: I am stronger than this challenge. And this challenge is making me even stronger.\"",
    "id" : 746463038354636804,
    "created_at" : "2016-06-24 22:00:31 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 747231570545762304,
  "created_at" : "2016-06-27 00:54:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746453574398402561\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Wa0JvKjwsF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClvvkbbWIAAD8vP.jpg",
      "id_str" : "746453572376731648",
      "id" : 746453572376731648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClvvkbbWIAAD8vP.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Wa0JvKjwsF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/pkKdmj9O1r",
      "expanded_url" : "http:\/\/engt.co\/28Sd7fa",
      "display_url" : "engt.co\/28Sd7fa"
    } ]
  },
  "geo" : { },
  "id_str" : "747231523213029376",
  "text" : "RT @engadget: The Mill's shapeshifting Blackbird can mimic any car https:\/\/t.co\/pkKdmj9O1r https:\/\/t.co\/Wa0JvKjwsF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746453574398402561\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Wa0JvKjwsF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClvvkbbWIAAD8vP.jpg",
        "id_str" : "746453572376731648",
        "id" : 746453572376731648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClvvkbbWIAAD8vP.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/Wa0JvKjwsF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/pkKdmj9O1r",
        "expanded_url" : "http:\/\/engt.co\/28Sd7fa",
        "display_url" : "engt.co\/28Sd7fa"
      } ]
    },
    "geo" : { },
    "id_str" : "746453574398402561",
    "text" : "The Mill's shapeshifting Blackbird can mimic any car https:\/\/t.co\/pkKdmj9O1r https:\/\/t.co\/Wa0JvKjwsF",
    "id" : 746453574398402561,
    "created_at" : "2016-06-24 21:22:55 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231523213029376,
  "created_at" : "2016-06-27 00:54:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746433614024421376\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/WPxkkriA6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clvdab-WAAETX85.jpg",
      "id_str" : "746433609515532289",
      "id" : 746433609515532289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clvdab-WAAETX85.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/WPxkkriA6K"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/fxk7ojZW2o",
      "expanded_url" : "http:\/\/engt.co\/28WF4Ig",
      "display_url" : "engt.co\/28WF4Ig"
    } ]
  },
  "geo" : { },
  "id_str" : "747231426920222720",
  "text" : "RT @engadget: NASA tasks the Hubble Telescope with five more years of service https:\/\/t.co\/fxk7ojZW2o https:\/\/t.co\/WPxkkriA6K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/746433614024421376\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/WPxkkriA6K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clvdab-WAAETX85.jpg",
        "id_str" : "746433609515532289",
        "id" : 746433609515532289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clvdab-WAAETX85.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/WPxkkriA6K"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fxk7ojZW2o",
        "expanded_url" : "http:\/\/engt.co\/28WF4Ig",
        "display_url" : "engt.co\/28WF4Ig"
      } ]
    },
    "geo" : { },
    "id_str" : "746433614024421376",
    "text" : "NASA tasks the Hubble Telescope with five more years of service https:\/\/t.co\/fxk7ojZW2o https:\/\/t.co\/WPxkkriA6K",
    "id" : 746433614024421376,
    "created_at" : "2016-06-24 20:03:36 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231426920222720,
  "created_at" : "2016-06-27 00:53:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "attitude",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747231318522667008",
  "text" : "RT @BarbaraCorcoran: Hiring for the right #attitude always delivers much more than hiring for experience - always!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "attitude",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746373693367029761",
    "text" : "Hiring for the right #attitude always delivers much more than hiring for experience - always!",
    "id" : 746373693367029761,
    "created_at" : "2016-06-24 16:05:30 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 747231318522667008,
  "created_at" : "2016-06-27 00:53:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747142693868953600\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/RvESpnQZlp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl5iUbLWgAAydbT.jpg",
      "id_str" : "747142691222355968",
      "id" : 747142691222355968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl5iUbLWgAAydbT.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/RvESpnQZlp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/anSLqKu2Kl",
      "expanded_url" : "http:\/\/engt.co\/28X3LEF",
      "display_url" : "engt.co\/28X3LEF"
    } ]
  },
  "geo" : { },
  "id_str" : "747231158447013888",
  "text" : "RT @engadget: Hands-on with Hasselblad's X1D medium-format mirrorless camera https:\/\/t.co\/anSLqKu2Kl https:\/\/t.co\/RvESpnQZlp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747142693868953600\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/RvESpnQZlp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl5iUbLWgAAydbT.jpg",
        "id_str" : "747142691222355968",
        "id" : 747142691222355968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl5iUbLWgAAydbT.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 788,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 788,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RvESpnQZlp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/anSLqKu2Kl",
        "expanded_url" : "http:\/\/engt.co\/28X3LEF",
        "display_url" : "engt.co\/28X3LEF"
      } ]
    },
    "geo" : { },
    "id_str" : "747142693868953600",
    "text" : "Hands-on with Hasselblad's X1D medium-format mirrorless camera https:\/\/t.co\/anSLqKu2Kl https:\/\/t.co\/RvESpnQZlp",
    "id" : 747142693868953600,
    "created_at" : "2016-06-26 19:01:14 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231158447013888,
  "created_at" : "2016-06-27 00:52:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747132188043395073\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Yfo6ucGQNT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl5Yw1YWkAEmZ9J.jpg",
      "id_str" : "747132184176267265",
      "id" : 747132184176267265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl5Yw1YWkAEmZ9J.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 394
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 394
      } ],
      "display_url" : "pic.twitter.com\/Yfo6ucGQNT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ytgDgIauc9",
      "expanded_url" : "http:\/\/engt.co\/28RcPHo",
      "display_url" : "engt.co\/28RcPHo"
    } ]
  },
  "geo" : { },
  "id_str" : "747231110577397760",
  "text" : "RT @engadget: This robot dog (from Boston Dynamics) can do your dishes https:\/\/t.co\/ytgDgIauc9 https:\/\/t.co\/Yfo6ucGQNT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747132188043395073\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Yfo6ucGQNT",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl5Yw1YWkAEmZ9J.jpg",
        "id_str" : "747132184176267265",
        "id" : 747132184176267265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cl5Yw1YWkAEmZ9J.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 394
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 394
        } ],
        "display_url" : "pic.twitter.com\/Yfo6ucGQNT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ytgDgIauc9",
        "expanded_url" : "http:\/\/engt.co\/28RcPHo",
        "display_url" : "engt.co\/28RcPHo"
      } ]
    },
    "geo" : { },
    "id_str" : "747132188043395073",
    "text" : "This robot dog (from Boston Dynamics) can do your dishes https:\/\/t.co\/ytgDgIauc9 https:\/\/t.co\/Yfo6ucGQNT",
    "id" : 747132188043395073,
    "created_at" : "2016-06-26 18:19:29 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231110577397760,
  "created_at" : "2016-06-27 00:52:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747067769406033920\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/FdG5sgYnvZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4eLL0WMAAuz-d.jpg",
      "id_str" : "747067765689823232",
      "id" : 747067765689823232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4eLL0WMAAuz-d.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/FdG5sgYnvZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Aub8kc0ioT",
      "expanded_url" : "http:\/\/engt.co\/28ZVqiY",
      "display_url" : "engt.co\/28ZVqiY"
    } ]
  },
  "geo" : { },
  "id_str" : "747231035721678848",
  "text" : "RT @engadget: Inhabitat's Week in Green: Solar Impulse's record flight and more! https:\/\/t.co\/Aub8kc0ioT https:\/\/t.co\/FdG5sgYnvZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/747067769406033920\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/FdG5sgYnvZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl4eLL0WMAAuz-d.jpg",
        "id_str" : "747067765689823232",
        "id" : 747067765689823232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl4eLL0WMAAuz-d.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/FdG5sgYnvZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Aub8kc0ioT",
        "expanded_url" : "http:\/\/engt.co\/28ZVqiY",
        "display_url" : "engt.co\/28ZVqiY"
      } ]
    },
    "geo" : { },
    "id_str" : "747067769406033920",
    "text" : "Inhabitat's Week in Green: Solar Impulse's record flight and more! https:\/\/t.co\/Aub8kc0ioT https:\/\/t.co\/FdG5sgYnvZ",
    "id" : 747067769406033920,
    "created_at" : "2016-06-26 14:03:30 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 747231035721678848,
  "created_at" : "2016-06-27 00:52:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/zE4kJ3znab",
      "expanded_url" : "https:\/\/vine.co\/v\/heiFwUqpVju",
      "display_url" : "vine.co\/v\/heiFwUqpVju"
    } ]
  },
  "geo" : { },
  "id_str" : "747230883757891585",
  "text" : "RT @BestGamezUp: this dog is satan https:\/\/t.co\/zE4kJ3znab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/zE4kJ3znab",
        "expanded_url" : "https:\/\/vine.co\/v\/heiFwUqpVju",
        "display_url" : "vine.co\/v\/heiFwUqpVju"
      } ]
    },
    "geo" : { },
    "id_str" : "746045303619522561",
    "text" : "this dog is satan https:\/\/t.co\/zE4kJ3znab",
    "id" : 746045303619522561,
    "created_at" : "2016-06-23 18:20:35 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 747230883757891585,
  "created_at" : "2016-06-27 00:51:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/747230738345496576\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/HCRkYahO2S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl6yY7tWIAAolRD.jpg",
      "id_str" : "747230729604571136",
      "id" : 747230729604571136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl6yY7tWIAAolRD.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HCRkYahO2S"
    } ],
    "hashtags" : [ {
      "text" : "DigestiveRegrets",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747230738345496576",
  "text" : "I got problems #DigestiveRegrets https:\/\/t.co\/HCRkYahO2S",
  "id" : 747230738345496576,
  "created_at" : "2016-06-27 00:51:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Cohen",
      "screen_name" : "MichaelCohen212",
      "indices" : [ 3, 19 ],
      "id_str" : "52136185",
      "id" : 52136185
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 22, 29 ],
      "id_str" : "16228398",
      "id" : 16228398
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 30, 46 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746045623712026625",
  "text" : "RT @MichaelCohen212: .@mcuban @realDonaldTrump just in case people didn't know what jealousy looks like...it looks like Mark Cuban.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 1, 8 ],
        "id_str" : "16228398",
        "id" : 16228398
      }, {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 9, 25 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "745281687714619392",
    "geo" : { },
    "id_str" : "745376939314151424",
    "in_reply_to_user_id" : 16228398,
    "text" : ".@mcuban @realDonaldTrump just in case people didn't know what jealousy looks like...it looks like Mark Cuban.",
    "id" : 745376939314151424,
    "in_reply_to_status_id" : 745281687714619392,
    "created_at" : "2016-06-21 22:04:45 +0000",
    "in_reply_to_screen_name" : "mcuban",
    "in_reply_to_user_id_str" : "16228398",
    "user" : {
      "name" : "Michael Cohen",
      "screen_name" : "MichaelCohen212",
      "protected" : false,
      "id_str" : "52136185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642687696473882624\/jHvVFZYt_normal.jpg",
      "id" : 52136185,
      "verified" : true
    }
  },
  "id" : 746045623712026625,
  "created_at" : "2016-06-23 18:21:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneur",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746045178612420608",
  "text" : "RT @BarbaraCorcoran: Book smarts are overrated. Street smarts and thinking fast on your feet make a great #entrepreneur!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneur",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746012480112103424",
    "text" : "Book smarts are overrated. Street smarts and thinking fast on your feet make a great #entrepreneur!",
    "id" : 746012480112103424,
    "created_at" : "2016-06-23 16:10:10 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 746045178612420608,
  "created_at" : "2016-06-23 18:20:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/AK84vBiVsj",
      "expanded_url" : "http:\/\/bit.ly\/28Lnaqk",
      "display_url" : "bit.ly\/28Lnaqk"
    } ]
  },
  "geo" : { },
  "id_str" : "746044859346223104",
  "text" : "RT @Tearieeror: Oppo A37 Dirilis, Ini Spesifikasinya https:\/\/t.co\/AK84vBiVsj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/AK84vBiVsj",
        "expanded_url" : "http:\/\/bit.ly\/28Lnaqk",
        "display_url" : "bit.ly\/28Lnaqk"
      } ]
    },
    "geo" : { },
    "id_str" : "745044960542494720",
    "text" : "Oppo A37 Dirilis, Ini Spesifikasinya https:\/\/t.co\/AK84vBiVsj",
    "id" : 745044960542494720,
    "created_at" : "2016-06-21 00:05:35 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 746044859346223104,
  "created_at" : "2016-06-23 18:18:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/745041244724748288\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/Xs7VZAGuar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbrD-dVYAAOLAk.jpg",
      "id_str" : "745041241914564608",
      "id" : 745041241914564608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbrD-dVYAAOLAk.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Xs7VZAGuar"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746044554562904065",
  "text" : "RT @rockindigo: But how? https:\/\/t.co\/Xs7VZAGuar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/745041244724748288\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/Xs7VZAGuar",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbrD-dVYAAOLAk.jpg",
        "id_str" : "745041241914564608",
        "id" : 745041241914564608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbrD-dVYAAOLAk.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/Xs7VZAGuar"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745041244724748288",
    "text" : "But how? https:\/\/t.co\/Xs7VZAGuar",
    "id" : 745041244724748288,
    "created_at" : "2016-06-20 23:50:49 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 746044554562904065,
  "created_at" : "2016-06-23 18:17:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/746044431128739840\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/xVSgKLw4i4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clp7cghWEAQpAPV.jpg",
      "id_str" : "746044417979584516",
      "id" : 746044417979584516,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clp7cghWEAQpAPV.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/xVSgKLw4i4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746044431128739840",
  "text" : "Look at my creation, still went to the gym right after https:\/\/t.co\/xVSgKLw4i4",
  "id" : 746044431128739840,
  "created_at" : "2016-06-23 18:17:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745035530472034306",
  "text" : "RT @lorenridinger: \u201CA Clear Vision, Backed By Definite Plans, Gives You A Tremendous Feeling Of Confidence And Personal Power.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744998451440672769",
    "text" : "\u201CA Clear Vision, Backed By Definite Plans, Gives You A Tremendous Feeling Of Confidence And Personal Power.\u201D",
    "id" : 744998451440672769,
    "created_at" : "2016-06-20 21:00:46 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 745035530472034306,
  "created_at" : "2016-06-20 23:28:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Abbott",
      "screen_name" : "GregAbbott_TX",
      "indices" : [ 3, 17 ],
      "id_str" : "90651198",
      "id" : 90651198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "txlege",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/OXIOBg72zt",
      "expanded_url" : "http:\/\/m.mysanantonio.com\/business\/article\/These-are-the-Fortune-500-companies-that-call-8311936.php",
      "display_url" : "m.mysanantonio.com\/business\/artic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745035494782730240",
  "text" : "RT @GregAbbott_TX: Texas ranks 2nd in number of Fortune 500 companies.  Now we're aiming to be #1.  #txlege  https:\/\/t.co\/OXIOBg72zt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "txlege",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/OXIOBg72zt",
        "expanded_url" : "http:\/\/m.mysanantonio.com\/business\/article\/These-are-the-Fortune-500-companies-that-call-8311936.php",
        "display_url" : "m.mysanantonio.com\/business\/artic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745000459870470144",
    "text" : "Texas ranks 2nd in number of Fortune 500 companies.  Now we're aiming to be #1.  #txlege  https:\/\/t.co\/OXIOBg72zt",
    "id" : 745000459870470144,
    "created_at" : "2016-06-20 21:08:45 +0000",
    "user" : {
      "name" : "Greg Abbott",
      "screen_name" : "GregAbbott_TX",
      "protected" : false,
      "id_str" : "90651198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744436907036139521\/onguTE-A_normal.jpg",
      "id" : 90651198,
      "verified" : true
    }
  },
  "id" : 745035494782730240,
  "created_at" : "2016-06-20 23:27:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/745001932851294209\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/FviNcUdU7X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbHN2FUYAAYusF.jpg",
      "id_str" : "745001829046444032",
      "id" : 745001829046444032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbHN2FUYAAYusF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1103
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1103
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1103
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/FviNcUdU7X"
    } ],
    "hashtags" : [ {
      "text" : "2A",
      "indices" : [ 94, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/aDfBtQyK6m",
      "expanded_url" : "https:\/\/www.tedcruz.org\/l\/2a\/",
      "display_url" : "tedcruz.org\/l\/2a\/"
    } ]
  },
  "geo" : { },
  "id_str" : "745035181921177600",
  "text" : "RT @tedcruz: Protect our right to keep and bear arms \u2014 add your name: https:\/\/t.co\/aDfBtQyK6m #2A https:\/\/t.co\/FviNcUdU7X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/745001932851294209\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/FviNcUdU7X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbHN2FUYAAYusF.jpg",
        "id_str" : "745001829046444032",
        "id" : 745001829046444032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbHN2FUYAAYusF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1103
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1103
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1103
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/FviNcUdU7X"
      } ],
      "hashtags" : [ {
        "text" : "2A",
        "indices" : [ 81, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/aDfBtQyK6m",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/2a\/",
        "display_url" : "tedcruz.org\/l\/2a\/"
      } ]
    },
    "geo" : { },
    "id_str" : "745001932851294209",
    "text" : "Protect our right to keep and bear arms \u2014 add your name: https:\/\/t.co\/aDfBtQyK6m #2A https:\/\/t.co\/FviNcUdU7X",
    "id" : 745001932851294209,
    "created_at" : "2016-06-20 21:14:36 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 745035181921177600,
  "created_at" : "2016-06-20 23:26:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745035154188435456",
  "text" : "RT @BarbaraCorcoran: Patents are only worth something if you have the money to defend it and most entrepreneurs do not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744968727725215744",
    "text" : "Patents are only worth something if you have the money to defend it and most entrepreneurs do not.",
    "id" : 744968727725215744,
    "created_at" : "2016-06-20 19:02:40 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 745035154188435456,
  "created_at" : "2016-06-20 23:26:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/PLblTW2oUE",
      "expanded_url" : "http:\/\/www.cnn.com\/2016\/06\/20\/politics\/senate-gun-votes-congress\/index.html",
      "display_url" : "cnn.com\/2016\/06\/20\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745035015516368896",
  "text" : "RT @HamzeiAnalytics: https:\/\/t.co\/PLblTW2oUE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/PLblTW2oUE",
        "expanded_url" : "http:\/\/www.cnn.com\/2016\/06\/20\/politics\/senate-gun-votes-congress\/index.html",
        "display_url" : "cnn.com\/2016\/06\/20\/pol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745034066735603712",
    "text" : "https:\/\/t.co\/PLblTW2oUE",
    "id" : 745034066735603712,
    "created_at" : "2016-06-20 23:22:18 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 745035015516368896,
  "created_at" : "2016-06-20 23:26:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/IkoSuL7cSs",
      "expanded_url" : "http:\/\/mashable.com\/2016\/06\/20\/leonardo-dicaprio-wolf-wall-street-lawsuit\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/06\/20\/leo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745034968091398146",
  "text" : "RT @EmperorDarroux: Judge orders Leonardo DiCaprio to testify in 'Wolf of Wall Street' lawsuit https:\/\/t.co\/IkoSuL7cSs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/IkoSuL7cSs",
        "expanded_url" : "http:\/\/mashable.com\/2016\/06\/20\/leonardo-dicaprio-wolf-wall-street-lawsuit\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/06\/20\/leo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745034116337270786",
    "text" : "Judge orders Leonardo DiCaprio to testify in 'Wolf of Wall Street' lawsuit https:\/\/t.co\/IkoSuL7cSs",
    "id" : 745034116337270786,
    "created_at" : "2016-06-20 23:22:30 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 745034968091398146,
  "created_at" : "2016-06-20 23:25:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 0, 14 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745034316812541952",
  "geo" : { },
  "id_str" : "745034915247333376",
  "in_reply_to_user_id" : 200751709,
  "text" : "@sexxandblunts That's not how it works, retweeting anything doesn't help you find money",
  "id" : 745034915247333376,
  "in_reply_to_status_id" : 745034316812541952,
  "created_at" : "2016-06-20 23:25:40 +0000",
  "in_reply_to_screen_name" : "sexxandblunts",
  "in_reply_to_user_id_str" : "200751709",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745005531975278592",
  "geo" : { },
  "id_str" : "745033268194467840",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani Dieting starting tomorrow \uD83D\uDE02",
  "id" : 745033268194467840,
  "in_reply_to_status_id" : 745005531975278592,
  "created_at" : "2016-06-20 23:19:07 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 3, 16 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745033170668531712",
  "text" : "RT @JosefLokmani: @gamer456148 nice going.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "744878488931360768",
    "geo" : { },
    "id_str" : "745005531975278592",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 nice going.",
    "id" : 745005531975278592,
    "in_reply_to_status_id" : 744878488931360768,
    "created_at" : "2016-06-20 21:28:55 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "protected" : false,
      "id_str" : "703541068462235648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836658752577290241\/4sTW-DBF_normal.jpg",
      "id" : 703541068462235648,
      "verified" : false
    }
  },
  "id" : 745033170668531712,
  "created_at" : "2016-06-20 23:18:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744918906163257344\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/A8q7lMQeHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZ7y3wWEAAQe5C.jpg",
      "id_str" : "744918902266793984",
      "id" : 744918902266793984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZ7y3wWEAAQe5C.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/A8q7lMQeHy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/F93TPC8nie",
      "expanded_url" : "http:\/\/engt.co\/28JxUWB",
      "display_url" : "engt.co\/28JxUWB"
    } ]
  },
  "geo" : { },
  "id_str" : "744928648487010304",
  "text" : "RT @engadget: Add-on brings Game Boy cartridges to your Android phone https:\/\/t.co\/F93TPC8nie https:\/\/t.co\/A8q7lMQeHy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744918906163257344\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/A8q7lMQeHy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZ7y3wWEAAQe5C.jpg",
        "id_str" : "744918902266793984",
        "id" : 744918902266793984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZ7y3wWEAAQe5C.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/A8q7lMQeHy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/F93TPC8nie",
        "expanded_url" : "http:\/\/engt.co\/28JxUWB",
        "display_url" : "engt.co\/28JxUWB"
      } ]
    },
    "geo" : { },
    "id_str" : "744918906163257344",
    "text" : "Add-on brings Game Boy cartridges to your Android phone https:\/\/t.co\/F93TPC8nie https:\/\/t.co\/A8q7lMQeHy",
    "id" : 744918906163257344,
    "created_at" : "2016-06-20 15:44:41 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 744928648487010304,
  "created_at" : "2016-06-20 16:23:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744915051350466560\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OA0SNM8uZo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZ4SiaWQAE5mbV.jpg",
      "id_str" : "744915048246689793",
      "id" : 744915048246689793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZ4SiaWQAE5mbV.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/OA0SNM8uZo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/p9lWLrcN5B",
      "expanded_url" : "http:\/\/engt.co\/28JC5Sk",
      "display_url" : "engt.co\/28JC5Sk"
    } ]
  },
  "geo" : { },
  "id_str" : "744928593466122240",
  "text" : "RT @engadget: Microsoft trashes Chrome's battery life https:\/\/t.co\/p9lWLrcN5B https:\/\/t.co\/OA0SNM8uZo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744915051350466560\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/OA0SNM8uZo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZ4SiaWQAE5mbV.jpg",
        "id_str" : "744915048246689793",
        "id" : 744915048246689793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZ4SiaWQAE5mbV.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/OA0SNM8uZo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/p9lWLrcN5B",
        "expanded_url" : "http:\/\/engt.co\/28JC5Sk",
        "display_url" : "engt.co\/28JC5Sk"
      } ]
    },
    "geo" : { },
    "id_str" : "744915051350466560",
    "text" : "Microsoft trashes Chrome's battery life https:\/\/t.co\/p9lWLrcN5B https:\/\/t.co\/OA0SNM8uZo",
    "id" : 744915051350466560,
    "created_at" : "2016-06-20 15:29:22 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 744928593466122240,
  "created_at" : "2016-06-20 16:23:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744926671334162432",
  "geo" : { },
  "id_str" : "744928243166285824",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki This is fake though",
  "id" : 744928243166285824,
  "in_reply_to_status_id" : 744926671334162432,
  "created_at" : "2016-06-20 16:21:47 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744927589500739585",
  "text" : "RT @robynthe5th: Education is \uD83D\uDD11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744926205128880128",
    "text" : "Education is \uD83D\uDD11",
    "id" : 744926205128880128,
    "created_at" : "2016-06-20 16:13:42 +0000",
    "user" : {
      "name" : "Robyn \uD83C\uDD74",
      "screen_name" : "itxrobyn",
      "protected" : false,
      "id_str" : "156843968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875106004958105604\/V-CL8FGo_normal.jpg",
      "id" : 156843968,
      "verified" : false
    }
  },
  "id" : 744927589500739585,
  "created_at" : "2016-06-20 16:19:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/N0wNWgOMQ4",
      "expanded_url" : "http:\/\/bit.ly\/28KVuk7",
      "display_url" : "bit.ly\/28KVuk7"
    } ]
  },
  "geo" : { },
  "id_str" : "744927554146959361",
  "text" : "RT @pluralsight: ICYMI: Apple says all apps must use its ATS security protocol by end of 2016. Details: https:\/\/t.co\/N0wNWgOMQ4 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pluralsight\/status\/744926047536287744\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/0v1EyEfKE3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaCSjfWMAQ3665.jpg",
        "id_str" : "744926043652370436",
        "id" : 744926043652370436,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaCSjfWMAQ3665.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 812,
          "resize" : "fit",
          "w" : 1592
        }, {
          "h" : 812,
          "resize" : "fit",
          "w" : 1592
        } ],
        "display_url" : "pic.twitter.com\/0v1EyEfKE3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/N0wNWgOMQ4",
        "expanded_url" : "http:\/\/bit.ly\/28KVuk7",
        "display_url" : "bit.ly\/28KVuk7"
      } ]
    },
    "geo" : { },
    "id_str" : "744926047536287744",
    "text" : "ICYMI: Apple says all apps must use its ATS security protocol by end of 2016. Details: https:\/\/t.co\/N0wNWgOMQ4 https:\/\/t.co\/0v1EyEfKE3",
    "id" : 744926047536287744,
    "created_at" : "2016-06-20 16:13:04 +0000",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659469901178933248\/zdC50ICY_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 744927554146959361,
  "created_at" : "2016-06-20 16:19:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744927201598988289",
  "text" : "RT @buysellshort: $BLIN gettin the algo vol, has news and chart and float for one of those big moves once it clears $1.40 again",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744924667035561984",
    "text" : "$BLIN gettin the algo vol, has news and chart and float for one of those big moves once it clears $1.40 again",
    "id" : 744924667035561984,
    "created_at" : "2016-06-20 16:07:35 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : false,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 744927201598988289,
  "created_at" : "2016-06-20 16:17:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/744927124608319488\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/w2216zPYcw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaDRDoUsAAoxNU.jpg",
      "id_str" : "744927117431844864",
      "id" : 744927117431844864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaDRDoUsAAoxNU.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w2216zPYcw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744927124608319488",
  "text" : "I still miss these! https:\/\/t.co\/w2216zPYcw",
  "id" : 744927124608319488,
  "created_at" : "2016-06-20 16:17:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/744878488931360768\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/nXZuN0fsnk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZXBv5WkAA1dCa.jpg",
      "id_str" : "744878475924901888",
      "id" : 744878475924901888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZXBv5WkAA1dCa.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/nXZuN0fsnk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744878488931360768",
  "text" : "Starting my morning off right, with donuts https:\/\/t.co\/nXZuN0fsnk",
  "id" : 744878488931360768,
  "created_at" : "2016-06-20 13:04:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Mahoney",
      "screen_name" : "mahoneyylo",
      "indices" : [ 3, 14 ],
      "id_str" : "831773563",
      "id" : 831773563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744697993513811969",
  "text" : "RT @mahoneyylo: I'm not threatened by what isn't real &amp; genuine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744360962573107200",
    "text" : "I'm not threatened by what isn't real &amp; genuine",
    "id" : 744360962573107200,
    "created_at" : "2016-06-19 02:47:37 +0000",
    "user" : {
      "name" : "Lauren Mahoney",
      "screen_name" : "mahoneyylo",
      "protected" : false,
      "id_str" : "831773563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880568903717531653\/wUzPhgOx_normal.jpg",
      "id" : 831773563,
      "verified" : false
    }
  },
  "id" : 744697993513811969,
  "created_at" : "2016-06-20 01:06:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Scott",
      "screen_name" : "slasher20412",
      "indices" : [ 3, 16 ],
      "id_str" : "30028728",
      "id" : 30028728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/7EafE8ip3Q",
      "expanded_url" : "http:\/\/fb.me\/31nriovkU",
      "display_url" : "fb.me\/31nriovkU"
    } ]
  },
  "geo" : { },
  "id_str" : "744697736205836290",
  "text" : "RT @slasher20412: Lynyrd Skynyrd -- Sweet Home Alabama [[ Official Live Video ]] HD https:\/\/t.co\/7EafE8ip3Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/7EafE8ip3Q",
        "expanded_url" : "http:\/\/fb.me\/31nriovkU",
        "display_url" : "fb.me\/31nriovkU"
      } ]
    },
    "geo" : { },
    "id_str" : "744692264417402880",
    "text" : "Lynyrd Skynyrd -- Sweet Home Alabama [[ Official Live Video ]] HD https:\/\/t.co\/7EafE8ip3Q",
    "id" : 744692264417402880,
    "created_at" : "2016-06-20 00:44:06 +0000",
    "user" : {
      "name" : "Linda Scott",
      "screen_name" : "slasher20412",
      "protected" : false,
      "id_str" : "30028728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470894360561995776\/x3aZCOYn_normal.jpeg",
      "id" : 30028728,
      "verified" : false
    }
  },
  "id" : 744697736205836290,
  "created_at" : "2016-06-20 01:05:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Le Chrisp, J.D.",
      "screen_name" : "chrispyxchreme",
      "indices" : [ 0, 15 ],
      "id_str" : "57940983",
      "id" : 57940983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/744697342465613828\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/vd8xEpUa3v",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ClWyR1qWQAA8guy.jpg",
      "id_str" : "744697332931903488",
      "id" : 744697332931903488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ClWyR1qWQAA8guy.jpg",
      "sizes" : [ {
        "h" : 146,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 146,
        "resize" : "crop",
        "w" : 146
      } ],
      "display_url" : "pic.twitter.com\/vd8xEpUa3v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744693892113633281",
  "geo" : { },
  "id_str" : "744697342465613828",
  "in_reply_to_user_id" : 57940983,
  "text" : "@chrispyxchreme https:\/\/t.co\/vd8xEpUa3v",
  "id" : 744697342465613828,
  "in_reply_to_status_id" : 744693892113633281,
  "created_at" : "2016-06-20 01:04:16 +0000",
  "in_reply_to_screen_name" : "chrispyxchreme",
  "in_reply_to_user_id_str" : "57940983",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sid wag",
      "screen_name" : "Sidneyy_Brooke",
      "indices" : [ 0, 15 ],
      "id_str" : "3016051875",
      "id" : 3016051875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744694199317049345",
  "geo" : { },
  "id_str" : "744697093848178692",
  "in_reply_to_user_id" : 3016051875,
  "text" : "@Sidneyy_Brooke Alabama's the best!",
  "id" : 744697093848178692,
  "in_reply_to_status_id" : 744694199317049345,
  "created_at" : "2016-06-20 01:03:17 +0000",
  "in_reply_to_screen_name" : "Sidneyy_Brooke",
  "in_reply_to_user_id_str" : "3016051875",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1000 Rockhits",
      "screen_name" : "1000Rockhits",
      "indices" : [ 3, 16 ],
      "id_str" : "4905558773",
      "id" : 4905558773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/G8kZTWHULR",
      "expanded_url" : "http:\/\/1000webradios.de\/streams\/1000rockhits.m3u",
      "display_url" : "1000webradios.de\/streams\/1000ro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744696962629406724",
  "text" : "RT @1000Rockhits: Sweet Home Alabama von Lynyrd Skynyrd.  https:\/\/t.co\/G8kZTWHULR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/1000rockhits.de\" rel=\"nofollow\"\u003E1000 Rock Hits Title Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/G8kZTWHULR",
        "expanded_url" : "http:\/\/1000webradios.de\/streams\/1000rockhits.m3u",
        "display_url" : "1000webradios.de\/streams\/1000ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744695025808838657",
    "text" : "Sweet Home Alabama von Lynyrd Skynyrd.  https:\/\/t.co\/G8kZTWHULR",
    "id" : 744695025808838657,
    "created_at" : "2016-06-20 00:55:04 +0000",
    "user" : {
      "name" : "1000 Rockhits",
      "screen_name" : "1000Rockhits",
      "protected" : false,
      "id_str" : "4905558773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698572102270590982\/lc0Mndcg_normal.jpg",
      "id" : 4905558773,
      "verified" : false
    }
  },
  "id" : 744696962629406724,
  "created_at" : "2016-06-20 01:02:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1000 Webradios",
      "screen_name" : "1000webradios",
      "indices" : [ 3, 17 ],
      "id_str" : "3318851181",
      "id" : 3318851181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/yJSs7x2s6G",
      "expanded_url" : "http:\/\/1000webradios.de\/streams\/1000rockhits.m3u",
      "display_url" : "1000webradios.de\/streams\/1000ro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744696950600114180",
  "text" : "RT @1000webradios: Sweet Home Alabama \/ Lynyrd Skynyrd.  https:\/\/t.co\/yJSs7x2s6G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/1000oldies.de\" rel=\"nofollow\"\u003ETweet all stations\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/yJSs7x2s6G",
        "expanded_url" : "http:\/\/1000webradios.de\/streams\/1000rockhits.m3u",
        "display_url" : "1000webradios.de\/streams\/1000ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744695026874257413",
    "text" : "Sweet Home Alabama \/ Lynyrd Skynyrd.  https:\/\/t.co\/yJSs7x2s6G",
    "id" : 744695026874257413,
    "created_at" : "2016-06-20 00:55:04 +0000",
    "user" : {
      "name" : "1000 Webradios",
      "screen_name" : "1000webradios",
      "protected" : false,
      "id_str" : "3318851181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609112309986902017\/bk0kbxKq_normal.jpg",
      "id" : 3318851181,
      "verified" : false
    }
  },
  "id" : 744696950600114180,
  "created_at" : "2016-06-20 01:02:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eileen Hallmark",
      "screen_name" : "eileenhallmark",
      "indices" : [ 3, 18 ],
      "id_str" : "55442979",
      "id" : 55442979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visionary",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "wholesaler",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "alabama",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "millerhighlife",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744696922305339393",
  "text" : "RT @eileenhallmark: Memories of beloved father. We had a cool pool that was the symbol #visionary #wholesaler #alabama #millerhighlife http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/eileenhallmark\/status\/744695530345881601\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/CbEJHUMj94",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWwoEwWkAA-Ozc.jpg",
        "id_str" : "744695515917488128",
        "id" : 744695515917488128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWwoEwWkAA-Ozc.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/CbEJHUMj94"
      } ],
      "hashtags" : [ {
        "text" : "visionary",
        "indices" : [ 67, 77 ]
      }, {
        "text" : "wholesaler",
        "indices" : [ 78, 89 ]
      }, {
        "text" : "alabama",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "millerhighlife",
        "indices" : [ 99, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744695530345881601",
    "text" : "Memories of beloved father. We had a cool pool that was the symbol #visionary #wholesaler #alabama #millerhighlife https:\/\/t.co\/CbEJHUMj94",
    "id" : 744695530345881601,
    "created_at" : "2016-06-20 00:57:04 +0000",
    "user" : {
      "name" : "Eileen Hallmark",
      "screen_name" : "eileenhallmark",
      "protected" : false,
      "id_str" : "55442979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1380188657\/NEH2_normal.jpg",
      "id" : 55442979,
      "verified" : false
    }
  },
  "id" : 744696922305339393,
  "created_at" : "2016-06-20 01:02:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disney's ALAN ALDA",
      "screen_name" : "keisertroll",
      "indices" : [ 3, 15 ],
      "id_str" : "141436861",
      "id" : 141436861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744696661784596484",
  "text" : "RT @keisertroll: Cleveland tied with Alabama football near the end of the half.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744696220636053508",
    "text" : "Cleveland tied with Alabama football near the end of the half.",
    "id" : 744696220636053508,
    "created_at" : "2016-06-20 00:59:49 +0000",
    "user" : {
      "name" : "Disney's ALAN ALDA",
      "screen_name" : "keisertroll",
      "protected" : false,
      "id_str" : "141436861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/868285551979487232\/jgFUXEkL_normal.jpg",
      "id" : 141436861,
      "verified" : false
    }
  },
  "id" : 744696661784596484,
  "created_at" : "2016-06-20 01:01:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barrett Jones",
      "screen_name" : "BarrettJonesFan",
      "indices" : [ 111, 127 ],
      "id_str" : "613287029",
      "id" : 613287029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744696573674819586",
  "text" : "RT @TDAlabama: Game 7 is tonight, but it's 75 days until Alabama football! Barrett Jones looks ready. Are you? @BarrettJonesFan https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barrett Jones",
        "screen_name" : "BarrettJonesFan",
        "indices" : [ 96, 112 ],
        "id_str" : "613287029",
        "id" : 613287029
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TDAlabama\/status\/744650454135676928\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ttGbyIO7Ip",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWHkAXWEAAVLqm.jpg",
        "id_str" : "744650366042640384",
        "id" : 744650366042640384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWHkAXWEAAVLqm.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 4147,
          "resize" : "fit",
          "w" : 2764
        } ],
        "display_url" : "pic.twitter.com\/ttGbyIO7Ip"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744650454135676928",
    "text" : "Game 7 is tonight, but it's 75 days until Alabama football! Barrett Jones looks ready. Are you? @BarrettJonesFan https:\/\/t.co\/ttGbyIO7Ip",
    "id" : 744650454135676928,
    "created_at" : "2016-06-19 21:57:57 +0000",
    "user" : {
      "name" : "Touchdown Alabama",
      "screen_name" : "TDAlabamaMag",
      "protected" : false,
      "id_str" : "26400298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804901758246027264\/3lvHE5JW_normal.jpg",
      "id" : 26400298,
      "verified" : false
    }
  },
  "id" : 744696573674819586,
  "created_at" : "2016-06-20 01:01:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iowa DNR",
      "screen_name" : "iowadnr",
      "indices" : [ 3, 11 ],
      "id_str" : "19911224",
      "id" : 19911224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iowadnr\/status\/743504168724238336\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DO8ZpBx3Gz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClF1Ga_UsAAiMXF.jpg",
      "id_str" : "743504166677426176",
      "id" : 743504166677426176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClF1Ga_UsAAiMXF.jpg",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 355,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/DO8ZpBx3Gz"
    } ],
    "hashtags" : [ {
      "text" : "upcycled",
      "indices" : [ 27, 36 ]
    }, {
      "text" : "camping",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "outdoorliving",
      "indices" : [ 50, 64 ]
    }, {
      "text" : "upcycling",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/QRMxjlSmx1",
      "expanded_url" : "http:\/\/bit.ly\/1Sir6im",
      "display_url" : "bit.ly\/1Sir6im"
    } ]
  },
  "geo" : { },
  "id_str" : "744696349162090496",
  "text" : "RT @iowadnr: Make your own #upcycled #camping and #outdoorliving gear! 12 ideas: https:\/\/t.co\/QRMxjlSmx1 #upcycling https:\/\/t.co\/DO8ZpBx3Gz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iowadnr\/status\/743504168724238336\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/DO8ZpBx3Gz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClF1Ga_UsAAiMXF.jpg",
        "id_str" : "743504166677426176",
        "id" : 743504166677426176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClF1Ga_UsAAiMXF.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/DO8ZpBx3Gz"
      } ],
      "hashtags" : [ {
        "text" : "upcycled",
        "indices" : [ 14, 23 ]
      }, {
        "text" : "camping",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "outdoorliving",
        "indices" : [ 37, 51 ]
      }, {
        "text" : "upcycling",
        "indices" : [ 92, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/QRMxjlSmx1",
        "expanded_url" : "http:\/\/bit.ly\/1Sir6im",
        "display_url" : "bit.ly\/1Sir6im"
      } ]
    },
    "geo" : { },
    "id_str" : "743504168724238336",
    "text" : "Make your own #upcycled #camping and #outdoorliving gear! 12 ideas: https:\/\/t.co\/QRMxjlSmx1 #upcycling https:\/\/t.co\/DO8ZpBx3Gz",
    "id" : 743504168724238336,
    "created_at" : "2016-06-16 18:03:02 +0000",
    "user" : {
      "name" : "Iowa DNR",
      "screen_name" : "iowadnr",
      "protected" : false,
      "id_str" : "19911224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458715865072939008\/TnIahUq3_normal.jpeg",
      "id" : 19911224,
      "verified" : true
    }
  },
  "id" : 744696349162090496,
  "created_at" : "2016-06-20 01:00:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Outside Magazine",
      "screen_name" : "outsidemagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "17810254",
      "id" : 17810254
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/outsidemagazine\/status\/743506991570685952\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/PWPAzVshnE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClF3quAWQAAgK2R.jpg",
      "id_str" : "743506989280542720",
      "id" : 743506989280542720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClF3quAWQAAgK2R.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/PWPAzVshnE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/blQwFF1Dip",
      "expanded_url" : "http:\/\/bit.ly\/1XZasUq",
      "display_url" : "bit.ly\/1XZasUq"
    } ]
  },
  "geo" : { },
  "id_str" : "744696315477692417",
  "text" : "RT @outsidemagazine: 8 repair tools that belong in your pack: https:\/\/t.co\/blQwFF1Dip https:\/\/t.co\/PWPAzVshnE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/outsidemagazine\/status\/743506991570685952\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/PWPAzVshnE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClF3quAWQAAgK2R.jpg",
        "id_str" : "743506989280542720",
        "id" : 743506989280542720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClF3quAWQAAgK2R.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/PWPAzVshnE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/blQwFF1Dip",
        "expanded_url" : "http:\/\/bit.ly\/1XZasUq",
        "display_url" : "bit.ly\/1XZasUq"
      } ]
    },
    "geo" : { },
    "id_str" : "743506991570685952",
    "text" : "8 repair tools that belong in your pack: https:\/\/t.co\/blQwFF1Dip https:\/\/t.co\/PWPAzVshnE",
    "id" : 743506991570685952,
    "created_at" : "2016-06-16 18:14:15 +0000",
    "user" : {
      "name" : "Outside Magazine",
      "screen_name" : "outsidemagazine",
      "protected" : false,
      "id_str" : "17810254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876871363918561280\/g3DOgN_B_normal.jpg",
      "id" : 17810254,
      "verified" : true
    }
  },
  "id" : 744696315477692417,
  "created_at" : "2016-06-20 01:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 21, 29 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744696142357733376",
  "text" : "RT @DarrylGlenn2016: @TedCruz will be in Colorado on Monday 6\/20 to personally endorse Darryl Glenn! Please come out and support! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 0, 8 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COsen",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/3qJPlshTSg",
        "expanded_url" : "https:\/\/goo.gl\/7oMVDa",
        "display_url" : "goo.gl\/7oMVDa"
      } ]
    },
    "geo" : { },
    "id_str" : "744242523326013441",
    "in_reply_to_user_id" : 23022687,
    "text" : "@TedCruz will be in Colorado on Monday 6\/20 to personally endorse Darryl Glenn! Please come out and support! https:\/\/t.co\/3qJPlshTSg #COsen",
    "id" : 744242523326013441,
    "created_at" : "2016-06-18 18:56:59 +0000",
    "in_reply_to_screen_name" : "tedcruz",
    "in_reply_to_user_id_str" : "23022687",
    "user" : {
      "name" : "Darryl Glenn",
      "screen_name" : "DarrylLGlenn",
      "protected" : false,
      "id_str" : "2957516001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817892633737465856\/ST5rIb3e_normal.jpg",
      "id" : 2957516001,
      "verified" : false
    }
  },
  "id" : 744696142357733376,
  "created_at" : "2016-06-20 00:59:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Braek Haven",
      "screen_name" : "BraekHaven_",
      "indices" : [ 0, 12 ],
      "id_str" : "238396997",
      "id" : 238396997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744695090703011840",
  "geo" : { },
  "id_str" : "744695705663639556",
  "in_reply_to_user_id" : 238396997,
  "text" : "@BraekHaven_ Well....",
  "id" : 744695705663639556,
  "in_reply_to_status_id" : 744695090703011840,
  "created_at" : "2016-06-20 00:57:46 +0000",
  "in_reply_to_screen_name" : "BraekHaven_",
  "in_reply_to_user_id_str" : "238396997",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/3GCBAHH3qi",
      "expanded_url" : "http:\/\/bit.ly\/1WXyUc1",
      "display_url" : "bit.ly\/1WXyUc1"
    } ]
  },
  "geo" : { },
  "id_str" : "744695618086572032",
  "text" : "RT @Tearieeror: PREVIEW ISC A 2016: Madura United FC - Bali United FC https:\/\/t.co\/3GCBAHH3qi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/3GCBAHH3qi",
        "expanded_url" : "http:\/\/bit.ly\/1WXyUc1",
        "display_url" : "bit.ly\/1WXyUc1"
      } ]
    },
    "geo" : { },
    "id_str" : "744695426771615744",
    "text" : "PREVIEW ISC A 2016: Madura United FC - Bali United FC https:\/\/t.co\/3GCBAHH3qi",
    "id" : 744695426771615744,
    "created_at" : "2016-06-20 00:56:40 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 744695618086572032,
  "created_at" : "2016-06-20 00:57:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "indices" : [ 3, 19 ],
      "id_str" : "226690054",
      "id" : 226690054
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SincerelyTumblr\/status\/744643761372807168\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/jr2F2bHyGD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWBjZ2WMAENe74.jpg",
      "id_str" : "744643758633922561",
      "id" : 744643758633922561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWBjZ2WMAENe74.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/jr2F2bHyGD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744694554096459776",
  "text" : "RT @SincerelyTumblr: https:\/\/t.co\/jr2F2bHyGD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SincerelyTumblr\/status\/744643761372807168\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/jr2F2bHyGD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWBjZ2WMAENe74.jpg",
        "id_str" : "744643758633922561",
        "id" : 744643758633922561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWBjZ2WMAENe74.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/jr2F2bHyGD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744643761372807168",
    "text" : "https:\/\/t.co\/jr2F2bHyGD",
    "id" : 744643761372807168,
    "created_at" : "2016-06-19 21:31:22 +0000",
    "user" : {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "protected" : false,
      "id_str" : "226690054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726467869031030784\/fR83Tu2w_normal.jpg",
      "id" : 226690054,
      "verified" : false
    }
  },
  "id" : 744694554096459776,
  "created_at" : "2016-06-20 00:53:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "indices" : [ 3, 19 ],
      "id_str" : "226690054",
      "id" : 226690054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744694524329484288",
  "text" : "RT @SincerelyTumblr: I put the \"i\" in \"single\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744647706640060416",
    "text" : "I put the \"i\" in \"single\".",
    "id" : 744647706640060416,
    "created_at" : "2016-06-19 21:47:02 +0000",
    "user" : {
      "name" : "Sincerely Tumblr",
      "screen_name" : "SincerelyTumblr",
      "protected" : false,
      "id_str" : "226690054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726467869031030784\/fR83Tu2w_normal.jpg",
      "id" : 226690054,
      "verified" : false
    }
  },
  "id" : 744694524329484288,
  "created_at" : "2016-06-20 00:53:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dory",
      "screen_name" : "Dory",
      "indices" : [ 3, 8 ],
      "id_str" : "1187647735",
      "id" : 1187647735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Dory\/status\/744579527184158720\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/dMRisHUAfc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVHIfMWIAEryB3.jpg",
      "id_str" : "744579524537491457",
      "id" : 744579524537491457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVHIfMWIAEryB3.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/dMRisHUAfc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744694144627544064",
  "text" : "RT @Dory: Still can't find it https:\/\/t.co\/dMRisHUAfc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dory\/status\/744579527184158720\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/dMRisHUAfc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVHIfMWIAEryB3.jpg",
        "id_str" : "744579524537491457",
        "id" : 744579524537491457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVHIfMWIAEryB3.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/dMRisHUAfc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744579527184158720",
    "text" : "Still can't find it https:\/\/t.co\/dMRisHUAfc",
    "id" : 744579527184158720,
    "created_at" : "2016-06-19 17:16:07 +0000",
    "user" : {
      "name" : "Dory",
      "screen_name" : "Dory",
      "protected" : false,
      "id_str" : "1187647735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681579053338394624\/8UZsho0J_normal.jpg",
      "id" : 1187647735,
      "verified" : false
    }
  },
  "id" : 744694144627544064,
  "created_at" : "2016-06-20 00:51:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744693884937248768",
  "text" : "RT @martincallan: Switzerland 0-0 France: Switzerland and France play out a Euro 2016 goalless draw which takes the Swiss into ... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/kh1yWKWpwd",
        "expanded_url" : "http:\/\/bbc.in\/1W7NZqG",
        "display_url" : "bbc.in\/1W7NZqG"
      } ]
    },
    "geo" : { },
    "id_str" : "744655768385789952",
    "text" : "Switzerland 0-0 France: Switzerland and France play out a Euro 2016 goalless draw which takes the Swiss into ... https:\/\/t.co\/kh1yWKWpwd",
    "id" : 744655768385789952,
    "created_at" : "2016-06-19 22:19:04 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 744693884937248768,
  "created_at" : "2016-06-20 00:50:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/luCd8N3G5f",
      "expanded_url" : "http:\/\/vine.co\/v\/hvlpVQdXrKh",
      "display_url" : "vine.co\/v\/hvlpVQdXrKh"
    } ]
  },
  "geo" : { },
  "id_str" : "744693835167567872",
  "text" : "RT @BestGamezUp: Um.. https:\/\/t.co\/luCd8N3G5f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 28 ],
        "url" : "https:\/\/t.co\/luCd8N3G5f",
        "expanded_url" : "http:\/\/vine.co\/v\/hvlpVQdXrKh",
        "display_url" : "vine.co\/v\/hvlpVQdXrKh"
      } ]
    },
    "geo" : { },
    "id_str" : "744656027988148225",
    "text" : "Um.. https:\/\/t.co\/luCd8N3G5f",
    "id" : 744656027988148225,
    "created_at" : "2016-06-19 22:20:06 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 744693835167567872,
  "created_at" : "2016-06-20 00:50:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744659805445455872",
  "geo" : { },
  "id_str" : "744693374003855360",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp Just why?",
  "id" : 744693374003855360,
  "in_reply_to_status_id" : 744659805445455872,
  "created_at" : "2016-06-20 00:48:30 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744595167785656320\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/VsTJMWbMtj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVVW2DWYAANMyh.jpg",
      "id_str" : "744595164354732032",
      "id" : 744595164354732032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVVW2DWYAANMyh.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/VsTJMWbMtj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/AgVgx3s08c",
      "expanded_url" : "http:\/\/engt.co\/1UQZgc8",
      "display_url" : "engt.co\/1UQZgc8"
    } ]
  },
  "geo" : { },
  "id_str" : "744693188573691904",
  "text" : "RT @engadget: Newly discovered asteroid is Earth's cosmic buddy https:\/\/t.co\/AgVgx3s08c https:\/\/t.co\/VsTJMWbMtj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/744595167785656320\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VsTJMWbMtj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVVW2DWYAANMyh.jpg",
        "id_str" : "744595164354732032",
        "id" : 744595164354732032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVVW2DWYAANMyh.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/VsTJMWbMtj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/AgVgx3s08c",
        "expanded_url" : "http:\/\/engt.co\/1UQZgc8",
        "display_url" : "engt.co\/1UQZgc8"
      } ]
    },
    "geo" : { },
    "id_str" : "744595167785656320",
    "text" : "Newly discovered asteroid is Earth's cosmic buddy https:\/\/t.co\/AgVgx3s08c https:\/\/t.co\/VsTJMWbMtj",
    "id" : 744595167785656320,
    "created_at" : "2016-06-19 18:18:16 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 744693188573691904,
  "created_at" : "2016-06-20 00:47:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadInspirationalQuotes",
      "indices" : [ 76, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744692944322592768",
  "text" : "Life is confusing and always awkward sometimes so make the best of whatever #BadInspirationalQuotes",
  "id" : 744692944322592768,
  "created_at" : "2016-06-20 00:46:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ole (oh-lay)",
      "screen_name" : "olemajorlyindie",
      "indices" : [ 3, 19 ],
      "id_str" : "474477472",
      "id" : 474477472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744690840287719424",
  "text" : "RT @olemajorlyindie: Happy Fathers Day from all of us at ole!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744671788328685568",
    "text" : "Happy Fathers Day from all of us at ole!",
    "id" : 744671788328685568,
    "created_at" : "2016-06-19 23:22:44 +0000",
    "user" : {
      "name" : "ole (oh-lay)",
      "screen_name" : "olemajorlyindie",
      "protected" : false,
      "id_str" : "474477472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624987444593561600\/1dbk8RuE_normal.png",
      "id" : 474477472,
      "verified" : true
    }
  },
  "id" : 744690840287719424,
  "created_at" : "2016-06-20 00:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "indices" : [ 3, 10 ],
      "id_str" : "263814100",
      "id" : 263814100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UPTIME",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744690645743316993",
  "text" : "RT @uptime: #UPTIME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UPTIME",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744675258528055296",
    "text" : "#UPTIME",
    "id" : 744675258528055296,
    "created_at" : "2016-06-19 23:36:31 +0000",
    "user" : {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "protected" : false,
      "id_str" : "263814100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504330138230616065\/sKW4KfgD_normal.png",
      "id" : 263814100,
      "verified" : false
    }
  },
  "id" : 744690645743316993,
  "created_at" : "2016-06-20 00:37:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/kBakcg0S43",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNFX6jShTW-TGveRMF_D7mE0qI1aDA&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779135211787&ei=EDNnV7CKIcT6wQHsu4KwAQ&url=http%3A%2F%2Fwww.freep.com%2Fstory%2Fsports%2Fcollege%2Funiversity-michigan%2Fwolverines%2F2016%2F06%2F19%2Fformer-michigan-wolverines-help-at-camp%2F86120204%2F&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744690611719184384",
  "text" : "RT @andikhm01: Former Michigan football players happy to help at camp - Detroit Free Press https:\/\/t.co\/kBakcg0S43",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/kBakcg0S43",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNFX6jShTW-TGveRMF_D7mE0qI1aDA&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779135211787&ei=EDNnV7CKIcT6wQHsu4KwAQ&url=http%3A%2F%2Fwww.freep.com%2Fstory%2Fsports%2Fcollege%2Funiversity-michigan%2Fwolverines%2F2016%2F06%2F19%2Fformer-michigan-wolverines-help-at-camp%2F86120204%2F&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744682459791429632",
    "text" : "Former Michigan football players happy to help at camp - Detroit Free Press https:\/\/t.co\/kBakcg0S43",
    "id" : 744682459791429632,
    "created_at" : "2016-06-20 00:05:08 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 744690611719184384,
  "created_at" : "2016-06-20 00:37:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "indices" : [ 3, 10 ],
      "id_str" : "263814100",
      "id" : 263814100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UPTIME",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "business",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "history",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "commerce",
      "indices" : [ 116, 125 ]
    }, {
      "text" : "energy",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/MfOOkWYcMO",
      "expanded_url" : "http:\/\/uptime.energy",
      "display_url" : "uptime.energy"
    } ]
  },
  "geo" : { },
  "id_str" : "744690511454289921",
  "text" : "RT @uptime: Did you know that #UPTIME has been around for OVER 30 YEARS? https:\/\/t.co\/MfOOkWYcMO #business #history #commerce #energy #perf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UPTIME",
        "indices" : [ 18, 25 ]
      }, {
        "text" : "business",
        "indices" : [ 85, 94 ]
      }, {
        "text" : "history",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "commerce",
        "indices" : [ 104, 113 ]
      }, {
        "text" : "energy",
        "indices" : [ 114, 121 ]
      }, {
        "text" : "performance",
        "indices" : [ 122, 134 ]
      }, {
        "text" : "time",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/MfOOkWYcMO",
        "expanded_url" : "http:\/\/uptime.energy",
        "display_url" : "uptime.energy"
      } ]
    },
    "geo" : { },
    "id_str" : "744687883475423233",
    "text" : "Did you know that #UPTIME has been around for OVER 30 YEARS? https:\/\/t.co\/MfOOkWYcMO #business #history #commerce #energy #performance #time",
    "id" : 744687883475423233,
    "created_at" : "2016-06-20 00:26:41 +0000",
    "user" : {
      "name" : "UPTIME Energy",
      "screen_name" : "uptime",
      "protected" : false,
      "id_str" : "263814100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504330138230616065\/sKW4KfgD_normal.png",
      "id" : 263814100,
      "verified" : false
    }
  },
  "id" : 744690511454289921,
  "created_at" : "2016-06-20 00:37:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mavey \uD83C\uDF80",
      "screen_name" : "Mavicdayrit",
      "indices" : [ 0, 12 ],
      "id_str" : "347561794",
      "id" : 347561794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744561093838704640",
  "geo" : { },
  "id_str" : "744690248119107585",
  "in_reply_to_user_id" : 347561794,
  "text" : "@Mavicdayrit Gotta love Space",
  "id" : 744690248119107585,
  "in_reply_to_status_id" : 744561093838704640,
  "created_at" : "2016-06-20 00:36:05 +0000",
  "in_reply_to_screen_name" : "Mavicdayrit",
  "in_reply_to_user_id_str" : "347561794",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "indices" : [ 3, 19 ],
      "id_str" : "290594346",
      "id" : 290594346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744690037166604288",
  "text" : "RT @Karynne_Summars: Life is like an elevator, sometimes on the way up you have to stop to let some people off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744689084698890241",
    "text" : "Life is like an elevator, sometimes on the way up you have to stop to let some people off.",
    "id" : 744689084698890241,
    "created_at" : "2016-06-20 00:31:28 +0000",
    "user" : {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "protected" : false,
      "id_str" : "290594346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702662666960023552\/qIla4_S8_normal.jpg",
      "id" : 290594346,
      "verified" : false
    }
  },
  "id" : 744690037166604288,
  "created_at" : "2016-06-20 00:35:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Devindra Hardawar",
      "screen_name" : "Devindra",
      "indices" : [ 10, 19 ],
      "id_str" : "13171062",
      "id" : 13171062
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 20, 27 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744669870579539969",
  "geo" : { },
  "id_str" : "744689835122790400",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget @Devindra @amazon gone a long way from being an online book store to a tech giant",
  "id" : 744689835122790400,
  "in_reply_to_status_id" : 744669870579539969,
  "created_at" : "2016-06-20 00:34:27 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/744660689952772096\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/60ZcNqFPDM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWQ8ajVYAA4qwJ.jpg",
      "id_str" : "744660680993759232",
      "id" : 744660680993759232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWQ8ajVYAA4qwJ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/60ZcNqFPDM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744660689952772096",
  "text" : "I had some amazing food this past week! https:\/\/t.co\/60ZcNqFPDM",
  "id" : 744660689952772096,
  "created_at" : "2016-06-19 22:38:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Kellyanne Conway",
      "screen_name" : "KellyannePolls",
      "indices" : [ 18, 33 ],
      "id_str" : "471672239",
      "id" : 471672239
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 36, 51 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743801082539876353",
  "text" : "RT @seanhannity: .@KellyannePolls: \u201C@HillaryClinton referred to pro-life Republicans as terrorists, but...she has a hard time\u2026calling terro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kellyanne Conway",
        "screen_name" : "KellyannePolls",
        "indices" : [ 1, 16 ],
        "id_str" : "471672239",
        "id" : 471672239
      }, {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 19, 34 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743638326704410626",
    "text" : ".@KellyannePolls: \u201C@HillaryClinton referred to pro-life Republicans as terrorists, but...she has a hard time\u2026calling terrorists-terrorists.\u201D",
    "id" : 743638326704410626,
    "created_at" : "2016-06-17 02:56:07 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 743801082539876353,
  "created_at" : "2016-06-17 13:42:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743202026453110784",
  "text" : "RT @lorenridinger: \"Wisdom is knowing what to do next; virtue is doing it.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743201597090562048",
    "text" : "\"Wisdom is knowing what to do next; virtue is doing it.\"",
    "id" : 743201597090562048,
    "created_at" : "2016-06-15 22:00:43 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 743202026453110784,
  "created_at" : "2016-06-15 22:02:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201883418943490",
  "text" : "RT @slidenerdtech: I am recording a new java series from today and I would like to hear from you about which IDE you want me to use https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/bjPmM0PUgO",
        "expanded_url" : "http:\/\/buff.ly\/1UtVw1E",
        "display_url" : "buff.ly\/1UtVw1E"
      } ]
    },
    "geo" : { },
    "id_str" : "743060994470076416",
    "text" : "I am recording a new java series from today and I would like to hear from you about which IDE you want me to use https:\/\/t.co\/bjPmM0PUgO....",
    "id" : 743060994470076416,
    "created_at" : "2016-06-15 12:42:01 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3626569194\/9efac426d5465cf43ae94b41838e0a51_normal.jpeg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 743201883418943490,
  "created_at" : "2016-06-15 22:01:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201524961189893",
  "text" : "RT @seanhannity: .@realDonaldTrump on Clinton: \"Here's a woman that takes all of this money from [oppressive countries] &amp; then she says she\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742908899049803778",
    "text" : ".@realDonaldTrump on Clinton: \"Here's a woman that takes all of this money from [oppressive countries] &amp; then she says she loves women...\"",
    "id" : 742908899049803778,
    "created_at" : "2016-06-15 02:37:38 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 743201524961189893,
  "created_at" : "2016-06-15 22:00:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneur",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201489645101056",
  "text" : "RT @BarbaraCorcoran: I look for 3 traits in every #entrepreneur I choose to work with: good character, lots of enthusiasm and a genuine sen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneur",
        "indices" : [ 29, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743109697201426432",
    "text" : "I look for 3 traits in every #entrepreneur I choose to work with: good character, lots of enthusiasm and a genuine sense of thankfulness.",
    "id" : 743109697201426432,
    "created_at" : "2016-06-15 15:55:32 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 743201489645101056,
  "created_at" : "2016-06-15 22:00:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201455822241792",
  "text" : "RT @seanhannity: Bombshell: Whistleblower Claims DHS Scrubbed Records That Might Have Prevented Orlando And San Bernardino Attacks https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Muv6O7Za9y",
        "expanded_url" : "http:\/\/www.hannity.com\/articles\/war-on-terror-487284\/bombshell-whistleblower-claims-dhs-scrubbed-records-14816541\/",
        "display_url" : "hannity.com\/articles\/war-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743089193367277568",
    "text" : "Bombshell: Whistleblower Claims DHS Scrubbed Records That Might Have Prevented Orlando And San Bernardino Attacks https:\/\/t.co\/Muv6O7Za9y",
    "id" : 743089193367277568,
    "created_at" : "2016-06-15 14:34:04 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 743201455822241792,
  "created_at" : "2016-06-15 22:00:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201423194742784",
  "text" : "RT @seanhannity: Steve Harrigan: \"Fox News can confirm [Noor Salman] did know her husband was planning to carry out a brutal attack.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742902487150145536",
    "text" : "Steve Harrigan: \"Fox News can confirm [Noor Salman] did know her husband was planning to carry out a brutal attack.\"",
    "id" : 742902487150145536,
    "created_at" : "2016-06-15 02:12:10 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 743201423194742784,
  "created_at" : "2016-06-15 22:00:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "recycle_it",
      "screen_name" : "Recycle___it",
      "indices" : [ 3, 16 ],
      "id_str" : "379820199",
      "id" : 379820199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743201294656151552",
  "text" : "RT @Recycle___it: More gravitational waves detected: Scientists announce the detection at Earth of another burst of gravitation... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/djwP2f2fig",
        "expanded_url" : "http:\/\/bbc.in\/1UUYZlM",
        "display_url" : "bbc.in\/1UUYZlM"
      } ]
    },
    "geo" : { },
    "id_str" : "743200819843997696",
    "text" : "More gravitational waves detected: Scientists announce the detection at Earth of another burst of gravitation... https:\/\/t.co\/djwP2f2fig",
    "id" : 743200819843997696,
    "created_at" : "2016-06-15 21:57:38 +0000",
    "user" : {
      "name" : "recycle_it",
      "screen_name" : "Recycle___it",
      "protected" : false,
      "id_str" : "379820199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1559405270\/recycleitlogo2_normal.jpg",
      "id" : 379820199,
      "verified" : false
    }
  },
  "id" : 743201294656151552,
  "created_at" : "2016-06-15 21:59:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Premium",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "DeadSeaUSA",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/JLWnQUhcfB",
      "expanded_url" : "https:\/\/hdtk.co\/RQKLA",
      "display_url" : "hdtk.co\/RQKLA"
    } ]
  },
  "geo" : { },
  "id_str" : "743110834612736001",
  "text" : "Get the best #Premium organic skin scrubs at low cost #DeadSeaUSA https:\/\/t.co\/JLWnQUhcfB",
  "id" : 743110834612736001,
  "created_at" : "2016-06-15 16:00:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 35, 42 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742742209997492224",
  "text" : "RT @tedcruz: Happy birthday to the @USArmy. Thank you for 241 years of fighting for freedom at home and across the globe! https:\/\/t.co\/z8sH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 22, 29 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/z8sHjB8V6R",
        "expanded_url" : "https:\/\/twitter.com\/usarmy\/status\/742693078482309121",
        "display_url" : "twitter.com\/usarmy\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742698554330775556",
    "text" : "Happy birthday to the @USArmy. Thank you for 241 years of fighting for freedom at home and across the globe! https:\/\/t.co\/z8sHjB8V6R",
    "id" : 742698554330775556,
    "created_at" : "2016-06-14 12:41:48 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 742742209997492224,
  "created_at" : "2016-06-14 15:35:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ioS0ai4hU4",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGXIVGDPWF_a0eNGOc0JxOCvFy4Gg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779132446744&ei=YIFeV5BO6MDBAZb0iPAC&url=https%3A%2F%2Fwww.theguardian.com%2Ffootball%2F2016%2Fjun%2F13%2Ffootball-transfer-rumours-psgs-marco-verratti-to-manchester-united&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742453010148663297",
  "text" : "RT @andikhm01: Football transfer rumours: PSG's Marco Verratti to Manchester United? - The Guardian https:\/\/t.co\/ioS0ai4hU4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/ioS0ai4hU4",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGXIVGDPWF_a0eNGOc0JxOCvFy4Gg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779132446744&ei=YIFeV5BO6MDBAZb0iPAC&url=https%3A%2F%2Fwww.theguardian.com%2Ffootball%2F2016%2Fjun%2F13%2Ffootball-transfer-rumours-psgs-marco-verratti-to-manchester-united&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742292728889761792",
    "text" : "Football transfer rumours: PSG's Marco Verratti to Manchester United? - The Guardian https:\/\/t.co\/ioS0ai4hU4",
    "id" : 742292728889761792,
    "created_at" : "2016-06-13 09:49:12 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 742453010148663297,
  "created_at" : "2016-06-13 20:26:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Rogers",
      "screen_name" : "TheRealSJR",
      "indices" : [ 3, 14 ],
      "id_str" : "101524268",
      "id" : 101524268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742452962060951552",
  "text" : "RT @TheRealSJR: Red Wings Video: Gordie Howe once taught Keith Olbermann about hockey respect in a classic \\\"This is SportsCenter\\\" (ESPN) \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742263258195841025",
    "text" : "Red Wings Video: Gordie Howe once taught Keith Olbermann about hockey respect in a classic \\\"This is SportsCenter\\\" (ESPN) \u2026",
    "id" : 742263258195841025,
    "created_at" : "2016-06-13 07:52:05 +0000",
    "user" : {
      "name" : "Stewart Rogers",
      "screen_name" : "TheRealSJR",
      "protected" : false,
      "id_str" : "101524268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841920665133436929\/19rV_PTN_normal.jpg",
      "id" : 101524268,
      "verified" : true
    }
  },
  "id" : 742452962060951552,
  "created_at" : "2016-06-13 20:25:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "indices" : [ 3, 16 ],
      "id_str" : "26257166",
      "id" : 26257166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742452917282603010",
  "text" : "RT @SportsCenter: Ecuador advances to Copa America quarterfinals, defeat Haiti, 4-0.\n\nUSMNT will face Ecuador in the next round. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SportsCenter\/status\/742153229962711041\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/8GDQcl7xsX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkyobWLWEAEoJXp.jpg",
        "id_str" : "742153226372386817",
        "id" : 742153226372386817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkyobWLWEAEoJXp.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/8GDQcl7xsX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742153229962711041",
    "text" : "Ecuador advances to Copa America quarterfinals, defeat Haiti, 4-0.\n\nUSMNT will face Ecuador in the next round. https:\/\/t.co\/8GDQcl7xsX",
    "id" : 742153229962711041,
    "created_at" : "2016-06-13 00:34:53 +0000",
    "user" : {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "protected" : false,
      "id_str" : "26257166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875363787867652096\/JVsTbdmb_normal.jpg",
      "id" : 26257166,
      "verified" : true
    }
  },
  "id" : 742452917282603010,
  "created_at" : "2016-06-13 20:25:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742452692442701825",
  "text" : "Microsoft is acquiring LinkedIn, all I can say is thank God Facebook didn't acquire it. Hope not too many changes to the striving platform",
  "id" : 742452692442701825,
  "created_at" : "2016-06-13 20:24:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "APM",
      "screen_name" : "APMutharika",
      "indices" : [ 96, 108 ],
      "id_str" : "2858673641",
      "id" : 2858673641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4rghWJ7wYW",
      "expanded_url" : "https:\/\/hdtk.co\/6mhRO",
      "display_url" : "hdtk.co\/6mhRO"
    } ]
  },
  "geo" : { },
  "id_str" : "742287977963982848",
  "text" : "Take action! Stop the ritual murders and discrimination against people with albinism in Malawi! @APMutharika https:\/\/t.co\/4rghWJ7wYW",
  "id" : 742287977963982848,
  "created_at" : "2016-06-13 09:30:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742040468305895424",
  "text" : "RT @BarbaraCorcoran: The difference between successful people and everyone else is how long they spend feeling sorry for themselves!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741975909427744768",
    "text" : "The difference between successful people and everyone else is how long they spend feeling sorry for themselves!",
    "id" : 741975909427744768,
    "created_at" : "2016-06-12 12:50:16 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 742040468305895424,
  "created_at" : "2016-06-12 17:06:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janice_TexasBlessed",
      "screen_name" : "JaniceTXBlessed",
      "indices" : [ 3, 19 ],
      "id_str" : "2495686176",
      "id" : 2495686176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrayForAmerica",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742040394121220096",
  "text" : "RT @JaniceTXBlessed: A powerful team, really? A Socialist &amp; a criminal. Dear God, help us if that happens! #PrayForAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrayForAmerica",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737711123013599235",
    "text" : "A powerful team, really? A Socialist &amp; a criminal. Dear God, help us if that happens! #PrayForAmerica",
    "id" : 737711123013599235,
    "created_at" : "2016-05-31 18:23:32 +0000",
    "user" : {
      "name" : "Janice_TexasBlessed",
      "screen_name" : "JaniceTXBlessed",
      "protected" : false,
      "id_str" : "2495686176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883058999628845056\/pqR73qeW_normal.jpg",
      "id" : 2495686176,
      "verified" : false
    }
  },
  "id" : 742040394121220096,
  "created_at" : "2016-06-12 17:06:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crosby Melendi",
      "screen_name" : "CrosbyMelendi",
      "indices" : [ 0, 14 ],
      "id_str" : "726447301",
      "id" : 726447301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742036126169501697",
  "geo" : { },
  "id_str" : "742040156111261696",
  "in_reply_to_user_id" : 726447301,
  "text" : "@CrosbyMelendi Automatic assault riffles and military style machine guns are illegal to own and not sold in gun shows",
  "id" : 742040156111261696,
  "in_reply_to_status_id" : 742036126169501697,
  "created_at" : "2016-06-12 17:05:34 +0000",
  "in_reply_to_screen_name" : "CrosbyMelendi",
  "in_reply_to_user_id_str" : "726447301",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heel Athletics",
      "screen_name" : "HeelAthletics",
      "indices" : [ 3, 17 ],
      "id_str" : "1067126203",
      "id" : 1067126203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742039694926614528",
  "text" : "RT @HeelAthletics: Praying for those injured and the families of those killed in Orlando. Humanity has to do better than this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742039147611848705",
    "text" : "Praying for those injured and the families of those killed in Orlando. Humanity has to do better than this.",
    "id" : 742039147611848705,
    "created_at" : "2016-06-12 17:01:33 +0000",
    "user" : {
      "name" : "Heel Athletics",
      "screen_name" : "HeelAthletics",
      "protected" : false,
      "id_str" : "1067126203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866451413970411520\/TLh6oka9_normal.jpg",
      "id" : 1067126203,
      "verified" : false
    }
  },
  "id" : 742039694926614528,
  "created_at" : "2016-06-12 17:03:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeAndre Benbow",
      "screen_name" : "DeandreBB",
      "indices" : [ 3, 13 ],
      "id_str" : "180961910",
      "id" : 180961910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742039666484989953",
  "text" : "RT @DeandreBB: I pray for the people of the incident last night but we cant live our lifes in fear.  Orlando has to be strong or the terror\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742039157455900672",
    "text" : "I pray for the people of the incident last night but we cant live our lifes in fear.  Orlando has to be strong or the terrorist has won.",
    "id" : 742039157455900672,
    "created_at" : "2016-06-12 17:01:36 +0000",
    "user" : {
      "name" : "DeAndre Benbow",
      "screen_name" : "DeandreBB",
      "protected" : false,
      "id_str" : "180961910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870363274667229184\/A7wQld0a_normal.jpg",
      "id" : 180961910,
      "verified" : false
    }
  },
  "id" : 742039666484989953,
  "created_at" : "2016-06-12 17:03:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 3, 8 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopTheHate",
      "indices" : [ 98, 110 ]
    }, {
      "text" : "PrayForOrlando",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742039612370112512",
  "text" : "RT @Cubs: We prepare for today's game with heavy hearts following the tragic violence in Orlando. #StopTheHate #PrayForOrlando",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopTheHate",
        "indices" : [ 88, 100 ]
      }, {
        "text" : "PrayForOrlando",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742039166309961729",
    "text" : "We prepare for today's game with heavy hearts following the tragic violence in Orlando. #StopTheHate #PrayForOrlando",
    "id" : 742039166309961729,
    "created_at" : "2016-06-12 17:01:38 +0000",
    "user" : {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "protected" : false,
      "id_str" : "41144996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883052969499009025\/IvcndP01_normal.jpg",
      "id" : 41144996,
      "verified" : true
    }
  },
  "id" : 742039612370112512,
  "created_at" : "2016-06-12 17:03:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/740800783164313601\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZiQ8DvPkK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkfaYpJWgAArJFo.jpg",
      "id_str" : "740800780622528512",
      "id" : 740800780622528512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkfaYpJWgAArJFo.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 818
      } ],
      "display_url" : "pic.twitter.com\/ZiQ8DvPkK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741822242510671873",
  "text" : "RT @saatchi_gallery: Pawel Nolbert perplexes the senses with his fictional filters &amp; reconstructed realities. https:\/\/t.co\/ZiQ8DvPkK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/740800783164313601\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/ZiQ8DvPkK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkfaYpJWgAArJFo.jpg",
        "id_str" : "740800780622528512",
        "id" : 740800780622528512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkfaYpJWgAArJFo.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 818
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 818
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 818
        } ],
        "display_url" : "pic.twitter.com\/ZiQ8DvPkK1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740800783164313601",
    "text" : "Pawel Nolbert perplexes the senses with his fictional filters &amp; reconstructed realities. https:\/\/t.co\/ZiQ8DvPkK1",
    "id" : 740800783164313601,
    "created_at" : "2016-06-09 07:00:44 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 741822242510671873,
  "created_at" : "2016-06-12 02:39:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741821914369253376",
  "text" : "RT @tedcruz: We must act to protect the internet and the amazing engine for economic growth and opportunity it has become! https:\/\/t.co\/EB9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/EB9JVyZ02N",
        "expanded_url" : "http:\/\/www.washingtontimes.com\/news\/2016\/jun\/8\/cruz-proposes-bill-keep-us-giving-internet-governa\/",
        "display_url" : "washingtontimes.com\/news\/2016\/jun\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740610531732529153",
    "text" : "We must act to protect the internet and the amazing engine for economic growth and opportunity it has become! https:\/\/t.co\/EB9JVyZ02N",
    "id" : 740610531732529153,
    "created_at" : "2016-06-08 18:24:45 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 741821914369253376,
  "created_at" : "2016-06-12 02:38:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald Trump Jr.",
      "screen_name" : "DonaldJTrumpJr",
      "indices" : [ 18, 33 ],
      "id_str" : "39344374",
      "id" : 39344374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741821814100262912",
  "text" : "RT @seanhannity: .@DonaldJTrumpJr: \"People have been disenfranchised by D.C. They\u2019re disgusted by what the politicians are doing across the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald Trump Jr.",
        "screen_name" : "DonaldJTrumpJr",
        "indices" : [ 1, 16 ],
        "id_str" : "39344374",
        "id" : 39344374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740729642940653568",
    "text" : ".@DonaldJTrumpJr: \"People have been disenfranchised by D.C. They\u2019re disgusted by what the politicians are doing across the board.\u201D #Hannity",
    "id" : 740729642940653568,
    "created_at" : "2016-06-09 02:18:03 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 741821814100262912,
  "created_at" : "2016-06-12 02:37:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741821770018127872",
  "text" : "RIP Christina Grimmie, now in heaven's arms",
  "id" : 741821770018127872,
  "created_at" : "2016-06-12 02:37:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502553239420928",
  "text" : "RT @tedcruz: Please join Heidi &amp; me in praying for those lost yesterday, their families &amp; the communities of Pensacola &amp; Ft Hood https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/2afO0iJBXj",
        "expanded_url" : "https:\/\/www.facebook.com\/tedcruzpage\/posts\/10154174585532464",
        "display_url" : "facebook.com\/tedcruzpage\/po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738825419294547968",
    "text" : "Please join Heidi &amp; me in praying for those lost yesterday, their families &amp; the communities of Pensacola &amp; Ft Hood https:\/\/t.co\/2afO0iJBXj",
    "id" : 738825419294547968,
    "created_at" : "2016-06-03 20:11:21 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 739502553239420928,
  "created_at" : "2016-06-05 17:02:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Review",
      "screen_name" : "NRO",
      "indices" : [ 3, 7 ],
      "id_str" : "19417492",
      "id" : 19417492
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 10, 18 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/WeGw8NA5XJ",
      "expanded_url" : "http:\/\/natl.re\/lc8tW4",
      "display_url" : "natl.re\/lc8tW4"
    } ]
  },
  "geo" : { },
  "id_str" : "739502465792368641",
  "text" : "RT @NRO: .@tedcruz: Obama vetoing bill to show solidarity w\/ the Chinese people on Tiananmen Square?\nhttps:\/\/t.co\/WeGw8NA5XJ https:\/\/t.co\/J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 1, 9 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NRO\/status\/738708083828871168\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/JU2oPXCrX9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkBdd6BVAAAnzdF.jpg",
        "id_str" : "738693107261177856",
        "id" : 738693107261177856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkBdd6BVAAAnzdF.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 613
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 613
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 613
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 613
        } ],
        "display_url" : "pic.twitter.com\/JU2oPXCrX9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/WeGw8NA5XJ",
        "expanded_url" : "http:\/\/natl.re\/lc8tW4",
        "display_url" : "natl.re\/lc8tW4"
      } ]
    },
    "geo" : { },
    "id_str" : "738708083828871168",
    "text" : ".@tedcruz: Obama vetoing bill to show solidarity w\/ the Chinese people on Tiananmen Square?\nhttps:\/\/t.co\/WeGw8NA5XJ https:\/\/t.co\/JU2oPXCrX9",
    "id" : 738708083828871168,
    "created_at" : "2016-06-03 12:25:06 +0000",
    "user" : {
      "name" : "National Review",
      "screen_name" : "NRO",
      "protected" : false,
      "id_str" : "19417492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471722478822100992\/slV_OilN_normal.jpeg",
      "id" : 19417492,
      "verified" : true
    }
  },
  "id" : 739502465792368641,
  "created_at" : "2016-06-05 17:01:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502421198528513",
  "text" : "RT @lorenridinger: \"Everybody has their own strengths &amp; weaknesses, and it is only when you accept everything you are- &amp; aren\u2019t- that you w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738777509718855681",
    "text" : "\"Everybody has their own strengths &amp; weaknesses, and it is only when you accept everything you are- &amp; aren\u2019t- that you will truly succeed.\"",
    "id" : 738777509718855681,
    "created_at" : "2016-06-03 17:00:58 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 739502421198528513,
  "created_at" : "2016-06-05 17:01:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502387325325312",
  "text" : "RT @lorenridinger: \"Be confident. Too many days are wasted comparing ourselves to others and wishing to be something we aren\u2019t.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738762417451245568",
    "text" : "\"Be confident. Too many days are wasted comparing ourselves to others and wishing to be something we aren\u2019t.\"",
    "id" : 738762417451245568,
    "created_at" : "2016-06-03 16:01:00 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 739502387325325312,
  "created_at" : "2016-06-05 17:01:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/738722431414734848\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/pHhxI64yxk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkB4IoeW0AIL02-.jpg",
      "id_str" : "738722428587790338",
      "id" : 738722428587790338,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkB4IoeW0AIL02-.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/pHhxI64yxk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/uFN2hz3HXj",
      "expanded_url" : "http:\/\/engt.co\/1Xol3Mo",
      "display_url" : "engt.co\/1Xol3Mo"
    } ]
  },
  "geo" : { },
  "id_str" : "739502311995674624",
  "text" : "RT @engadget: Hubble shows the universe is expanding faster than we thought https:\/\/t.co\/uFN2hz3HXj https:\/\/t.co\/pHhxI64yxk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/738722431414734848\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/pHhxI64yxk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkB4IoeW0AIL02-.jpg",
        "id_str" : "738722428587790338",
        "id" : 738722428587790338,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkB4IoeW0AIL02-.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/pHhxI64yxk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/uFN2hz3HXj",
        "expanded_url" : "http:\/\/engt.co\/1Xol3Mo",
        "display_url" : "engt.co\/1Xol3Mo"
      } ]
    },
    "geo" : { },
    "id_str" : "738722431414734848",
    "text" : "Hubble shows the universe is expanding faster than we thought https:\/\/t.co\/uFN2hz3HXj https:\/\/t.co\/pHhxI64yxk",
    "id" : 738722431414734848,
    "created_at" : "2016-06-03 13:22:07 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 739502311995674624,
  "created_at" : "2016-06-05 17:01:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502250058342400",
  "text" : "RT @BarbaraCorcoran: You can't be successful in business unless your whole heart is in it. And that makes the endless hours you'll need to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738718280517574656",
    "text" : "You can't be successful in business unless your whole heart is in it. And that makes the endless hours you'll need to put in worth it.",
    "id" : 738718280517574656,
    "created_at" : "2016-06-03 13:05:37 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 739502250058342400,
  "created_at" : "2016-06-05 17:00:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Lockhart",
      "screen_name" : "wlockhart",
      "indices" : [ 3, 13 ],
      "id_str" : "14891331",
      "id" : 14891331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502213488201732",
  "text" : "RT @wlockhart: Google's new user-friendly tool should make it easier for small businesses to see how their sites rank in terms... https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/E0Kxo9ULum",
        "expanded_url" : "http:\/\/fb.me\/7Yf84BUWG",
        "display_url" : "fb.me\/7Yf84BUWG"
      } ]
    },
    "geo" : { },
    "id_str" : "738705805696991232",
    "text" : "Google's new user-friendly tool should make it easier for small businesses to see how their sites rank in terms... https:\/\/t.co\/E0Kxo9ULum",
    "id" : 738705805696991232,
    "created_at" : "2016-06-03 12:16:03 +0000",
    "user" : {
      "name" : "William Lockhart",
      "screen_name" : "wlockhart",
      "protected" : false,
      "id_str" : "14891331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446658275782565888\/wV11izgw_normal.jpeg",
      "id" : 14891331,
      "verified" : false
    }
  },
  "id" : 739502213488201732,
  "created_at" : "2016-06-05 17:00:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Lisa Boothe",
      "screen_name" : "LisaMarieBoothe",
      "indices" : [ 14, 30 ],
      "id_str" : "121574367",
      "id" : 121574367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502137340633089",
  "text" : "RT @FoxNews: .@LisaMarieBoothe: \"We can't even trust [Clinton] w\/ her emails \u2013 how can we trust her w\/ that kind of power?\" https:\/\/t.co\/qp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Boothe",
        "screen_name" : "LisaMarieBoothe",
        "indices" : [ 1, 17 ],
        "id_str" : "121574367",
        "id" : 121574367
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/738562601274089472\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/qpBTBm3q0E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj_mxRtUYAAYwLv.jpg",
        "id_str" : "738562598153510912",
        "id" : 738562598153510912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj_mxRtUYAAYwLv.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/qpBTBm3q0E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738562601274089472",
    "text" : ".@LisaMarieBoothe: \"We can't even trust [Clinton] w\/ her emails \u2013 how can we trust her w\/ that kind of power?\" https:\/\/t.co\/qpBTBm3q0E",
    "id" : 738562601274089472,
    "created_at" : "2016-06-03 02:47:00 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794654746342662144\/hHnFe4Sx_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 739502137340633089,
  "created_at" : "2016-06-05 17:00:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502084257521664",
  "text" : "RT @seanhannity: Dolly Kyle who had decades-long affair w\/Bill Clinton on radio to discuss secrets &amp; scandals of the Clinton machine https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/qIbSrSzmNF",
        "expanded_url" : "http:\/\/amzn.to\/1PoeSFf",
        "display_url" : "amzn.to\/1PoeSFf"
      } ]
    },
    "geo" : { },
    "id_str" : "738469020312051717",
    "text" : "Dolly Kyle who had decades-long affair w\/Bill Clinton on radio to discuss secrets &amp; scandals of the Clinton machine https:\/\/t.co\/qIbSrSzmNF",
    "id" : 738469020312051717,
    "created_at" : "2016-06-02 20:35:09 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 739502084257521664,
  "created_at" : "2016-06-05 17:00:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/739501938803277824\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/yf8blHwgJw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkM9FYmWUAAnhrN.jpg",
      "id_str" : "739501926530830336",
      "id" : 739501926530830336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkM9FYmWUAAnhrN.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 1888,
        "resize" : "fit",
        "w" : 1485
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1888,
        "resize" : "fit",
        "w" : 1485
      } ],
      "display_url" : "pic.twitter.com\/yf8blHwgJw"
    } ],
    "hashtags" : [ {
      "text" : "FutureMillionaire",
      "indices" : [ 11, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739501938803277824",
  "text" : "Suiting up #FutureMillionaire https:\/\/t.co\/yf8blHwgJw",
  "id" : 739501938803277824,
  "created_at" : "2016-06-05 16:59:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/endWP4zQBz",
      "expanded_url" : "https:\/\/hdtk.co\/VH8xM",
      "display_url" : "hdtk.co\/VH8xM"
    } ]
  },
  "geo" : { },
  "id_str" : "738052548117049344",
  "text" : "Help this mom get to sons Navy PIR Graduation From Bootcamp https:\/\/t.co\/endWP4zQBz",
  "id" : 738052548117049344,
  "created_at" : "2016-06-01 17:00:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]