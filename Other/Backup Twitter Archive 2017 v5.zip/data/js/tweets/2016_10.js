Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GypsyDanger \uD83D\uDC51",
      "screen_name" : "GypsyDanger1013",
      "indices" : [ 3, 19 ],
      "id_str" : "3732994399",
      "id" : 3732994399
    }, {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 21, 36 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793227716707233792",
  "text" : "RT @GypsyDanger1013: @AvalloneHunter welcome back mon amie, glad that creepy avi is finally gone lol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hunter Avallone",
        "screen_name" : "AvalloneHunter",
        "indices" : [ 0, 15 ],
        "id_str" : "2575373509",
        "id" : 2575373509
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790269559009718272",
    "in_reply_to_user_id" : 2575373509,
    "text" : "@AvalloneHunter welcome back mon amie, glad that creepy avi is finally gone lol",
    "id" : 790269559009718272,
    "created_at" : "2016-10-23 19:12:00 +0000",
    "in_reply_to_screen_name" : "AvalloneHunter",
    "in_reply_to_user_id_str" : "2575373509",
    "user" : {
      "name" : "GypsyDanger \uD83D\uDC51",
      "screen_name" : "GypsyDanger1013",
      "protected" : false,
      "id_str" : "3732994399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858008717127798784\/0W1OqYvT_normal.jpg",
      "id" : 3732994399,
      "verified" : false
    }
  },
  "id" : 793227716707233792,
  "created_at" : "2016-10-31 23:06:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meninist",
      "screen_name" : "MeninistTweet",
      "indices" : [ 3, 17 ],
      "id_str" : "2870078111",
      "id" : 2870078111
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MeninistTweet\/status\/792072975054929921\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/fpR9sp57UQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4B1_fWAAASH8F.jpg",
      "id_str" : "792072611551379456",
      "id" : 792072611551379456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4B1_fWAAASH8F.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/fpR9sp57UQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793227031362146304",
  "text" : "RT @MeninistTweet: goals this, goals that. even sitting on a rock is goals for you females. https:\/\/t.co\/fpR9sp57UQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MeninistTweet\/status\/792072975054929921\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/fpR9sp57UQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4B1_fWAAASH8F.jpg",
        "id_str" : "792072611551379456",
        "id" : 792072611551379456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4B1_fWAAASH8F.jpg",
        "sizes" : [ {
          "h" : 446,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/fpR9sp57UQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792072975054929921",
    "text" : "goals this, goals that. even sitting on a rock is goals for you females. https:\/\/t.co\/fpR9sp57UQ",
    "id" : 792072975054929921,
    "created_at" : "2016-10-28 18:38:07 +0000",
    "user" : {
      "name" : "Meninist",
      "screen_name" : "MeninistTweet",
      "protected" : false,
      "id_str" : "2870078111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877724409871466497\/WlFBTg1K_normal.jpg",
      "id" : 2870078111,
      "verified" : false
    }
  },
  "id" : 793227031362146304,
  "created_at" : "2016-10-31 23:03:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foreign Policy",
      "screen_name" : "ForeignPolicy",
      "indices" : [ 3, 17 ],
      "id_str" : "26792275",
      "id" : 26792275
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 113, 127 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793226314392100864",
  "text" : "RT @ForeignPolicy: \"I\u2019m the only presidential candidate with a plan\" to bring an end to the Syria crisis, writes @Evan_McMullin https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 94, 108 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ForeignPolicy\/status\/793205170767294464\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/bksFBWUhkc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwIH5fuWgAAjQaJ.jpg",
        "id_str" : "793205168720478208",
        "id" : 793205168720478208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwIH5fuWgAAjQaJ.jpg",
        "sizes" : [ {
          "h" : 562,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 958
        } ],
        "display_url" : "pic.twitter.com\/bksFBWUhkc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/92AHNEDE1h",
        "expanded_url" : "http:\/\/atfp.co\/2f2dUkD",
        "display_url" : "atfp.co\/2f2dUkD"
      } ]
    },
    "geo" : { },
    "id_str" : "793205170767294464",
    "text" : "\"I\u2019m the only presidential candidate with a plan\" to bring an end to the Syria crisis, writes @Evan_McMullin https:\/\/t.co\/92AHNEDE1h https:\/\/t.co\/bksFBWUhkc",
    "id" : 793205170767294464,
    "created_at" : "2016-10-31 21:37:04 +0000",
    "user" : {
      "name" : "Foreign Policy",
      "screen_name" : "ForeignPolicy",
      "protected" : false,
      "id_str" : "26792275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560557786350637057\/GXv25iue_normal.png",
      "id" : 26792275,
      "verified" : true
    }
  },
  "id" : 793226314392100864,
  "created_at" : "2016-10-31 23:01:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TNCannuck",
      "screen_name" : "TNCannuck",
      "indices" : [ 3, 13 ],
      "id_str" : "425339751",
      "id" : 425339751
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 15, 24 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793226242363236352",
  "text" : "RT @TNCannuck: @scrowder Now that you're a professor, daily LwC is just around the corner, right?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "793208587824820225",
    "geo" : { },
    "id_str" : "793211239761637376",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder Now that you're a professor, daily LwC is just around the corner, right?",
    "id" : 793211239761637376,
    "in_reply_to_status_id" : 793208587824820225,
    "created_at" : "2016-10-31 22:01:11 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "TNCannuck",
      "screen_name" : "TNCannuck",
      "protected" : false,
      "id_str" : "425339751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450724202224439296\/Flb4wjhb_normal.jpeg",
      "id" : 425339751,
      "verified" : false
    }
  },
  "id" : 793226242363236352,
  "created_at" : "2016-10-31 23:00:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jurasskick",
      "screen_name" : "jurasskick",
      "indices" : [ 3, 14 ],
      "id_str" : "471470510",
      "id" : 471470510
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 16, 25 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793226221081407488",
  "text" : "RT @jurasskick: @scrowder Well done!  Tyranny of the majority sure won't make Socialism any more successful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "793208587824820225",
    "geo" : { },
    "id_str" : "793210365840502784",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder Well done!  Tyranny of the majority sure won't make Socialism any more successful.",
    "id" : 793210365840502784,
    "in_reply_to_status_id" : 793208587824820225,
    "created_at" : "2016-10-31 21:57:43 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Jurasskick",
      "screen_name" : "jurasskick",
      "protected" : false,
      "id_str" : "471470510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2535949581\/05r969bgzbyoixjv5vft_normal.png",
      "id" : 471470510,
      "verified" : false
    }
  },
  "id" : 793226221081407488,
  "created_at" : "2016-10-31 23:00:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/793221822531661824\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/e7c3MKxZsu",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CwIXCquWYAEjIJn.jpg",
      "id_str" : "793221818966499329",
      "id" : 793221818966499329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CwIXCquWYAEjIJn.jpg",
      "sizes" : [ {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/e7c3MKxZsu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QFEZHadpUJ",
      "expanded_url" : "http:\/\/engt.co\/2fxYBB6",
      "display_url" : "engt.co\/2fxYBB6"
    } ]
  },
  "geo" : { },
  "id_str" : "793225794851971072",
  "text" : "RT @engadget: Lithium battery failure wipes out DARPA robot at NASA https:\/\/t.co\/QFEZHadpUJ https:\/\/t.co\/e7c3MKxZsu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/793221822531661824\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/e7c3MKxZsu",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CwIXCquWYAEjIJn.jpg",
        "id_str" : "793221818966499329",
        "id" : 793221818966499329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CwIXCquWYAEjIJn.jpg",
        "sizes" : [ {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/e7c3MKxZsu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/QFEZHadpUJ",
        "expanded_url" : "http:\/\/engt.co\/2fxYBB6",
        "display_url" : "engt.co\/2fxYBB6"
      } ]
    },
    "geo" : { },
    "id_str" : "793221822531661824",
    "text" : "Lithium battery failure wipes out DARPA robot at NASA https:\/\/t.co\/QFEZHadpUJ https:\/\/t.co\/e7c3MKxZsu",
    "id" : 793221822531661824,
    "created_at" : "2016-10-31 22:43:14 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 793225794851971072,
  "created_at" : "2016-10-31 22:59:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eve",
      "screen_name" : "eveknill",
      "indices" : [ 3, 12 ],
      "id_str" : "529534367",
      "id" : 529534367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793225375291625472",
  "text" : "RT @eveknill: Whenever I fancy a laugh I look at my bank balance X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785749966929195008",
    "text" : "Whenever I fancy a laugh I look at my bank balance X",
    "id" : 785749966929195008,
    "created_at" : "2016-10-11 07:52:45 +0000",
    "user" : {
      "name" : "eve",
      "screen_name" : "eveknill",
      "protected" : false,
      "id_str" : "529534367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874293790793707521\/9wr3od6V_normal.jpg",
      "id" : 529534367,
      "verified" : false
    }
  },
  "id" : 793225375291625472,
  "created_at" : "2016-10-31 22:57:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monica",
      "screen_name" : "Phattychicky",
      "indices" : [ 0, 13 ],
      "id_str" : "3225945317",
      "id" : 3225945317
    }, {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 14, 28 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "793204410214182916",
  "geo" : { },
  "id_str" : "793224316150087685",
  "in_reply_to_user_id" : 3225945317,
  "text" : "@Phattychicky @sexxandblunts PS4 got released by Sony years ago",
  "id" : 793224316150087685,
  "in_reply_to_status_id" : 793204410214182916,
  "created_at" : "2016-10-31 22:53:09 +0000",
  "in_reply_to_screen_name" : "Phattychicky",
  "in_reply_to_user_id_str" : "3225945317",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Look@MyPinnedTweet",
      "screen_name" : "MichaelRello",
      "indices" : [ 3, 16 ],
      "id_str" : "77080603",
      "id" : 77080603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793224180644745216",
  "text" : "RT @MichaelRello: Call your family and tell them you love them",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "793223893930549248",
    "text" : "Call your family and tell them you love them",
    "id" : 793223893930549248,
    "created_at" : "2016-10-31 22:51:28 +0000",
    "user" : {
      "name" : "Look@MyPinnedTweet",
      "screen_name" : "MichaelRello",
      "protected" : false,
      "id_str" : "77080603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879952434227032068\/HjzwjxNg_normal.jpg",
      "id" : 77080603,
      "verified" : false
    }
  },
  "id" : 793224180644745216,
  "created_at" : "2016-10-31 22:52:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "793224156431036417",
  "text" : "Times are tough but God will intervene, it will get better, no matter how much at times the world is trying to confuse and push you",
  "id" : 793224156431036417,
  "created_at" : "2016-10-31 22:52:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saved By The Max",
      "screen_name" : "SavedByTheMax",
      "indices" : [ 3, 17 ],
      "id_str" : "4890583990",
      "id" : 4890583990
    }, {
      "name" : "Nerdist",
      "screen_name" : "nerdist",
      "indices" : [ 42, 50 ],
      "id_str" : "394216985",
      "id" : 394216985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/J5wFUs9a3j",
      "expanded_url" : "http:\/\/nerdist.com\/chicagos-saved-by-the-bell-diner-is-a-time-machine-back-to-the-90s\/",
      "display_url" : "nerdist.com\/chicagos-saved\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792552903181492224",
  "text" : "RT @SavedByTheMax: Thanks for stopping by @nerdist! https:\/\/t.co\/J5wFUs9a3j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nerdist",
        "screen_name" : "nerdist",
        "indices" : [ 23, 31 ],
        "id_str" : "394216985",
        "id" : 394216985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/J5wFUs9a3j",
        "expanded_url" : "http:\/\/nerdist.com\/chicagos-saved-by-the-bell-diner-is-a-time-machine-back-to-the-90s\/",
        "display_url" : "nerdist.com\/chicagos-saved\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788418192603426816",
    "text" : "Thanks for stopping by @nerdist! https:\/\/t.co\/J5wFUs9a3j",
    "id" : 788418192603426816,
    "created_at" : "2016-10-18 16:35:19 +0000",
    "user" : {
      "name" : "Saved By The Max",
      "screen_name" : "SavedByTheMax",
      "protected" : false,
      "id_str" : "4890583990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724225436721487875\/nHX-ovHm_normal.jpg",
      "id" : 4890583990,
      "verified" : false
    }
  },
  "id" : 792552903181492224,
  "created_at" : "2016-10-30 02:25:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/fhnZtPGYzt",
      "expanded_url" : "http:\/\/ow.ly\/kKTP305E3wM",
      "display_url" : "ow.ly\/kKTP305E3wM"
    } ]
  },
  "geo" : { },
  "id_str" : "792552762382905344",
  "text" : "RT @hootsuite: You'll want to bookmark these! \uD83D\uDCD6 https:\/\/t.co\/fhnZtPGYzt 20 free stock photo sites for social media images https:\/\/t.co\/Hoe7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/792550379674304513\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Hoe7oO21Uf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-0Xm1W8AAmEAE.jpg",
        "id_str" : "792550377094836224",
        "id" : 792550377094836224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-0Xm1W8AAmEAE.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Hoe7oO21Uf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/fhnZtPGYzt",
        "expanded_url" : "http:\/\/ow.ly\/kKTP305E3wM",
        "display_url" : "ow.ly\/kKTP305E3wM"
      } ]
    },
    "geo" : { },
    "id_str" : "792550379674304513",
    "text" : "You'll want to bookmark these! \uD83D\uDCD6 https:\/\/t.co\/fhnZtPGYzt 20 free stock photo sites for social media images https:\/\/t.co\/Hoe7oO21Uf",
    "id" : 792550379674304513,
    "created_at" : "2016-10-30 02:15:10 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 792552762382905344,
  "created_at" : "2016-10-30 02:24:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Jenna Ezarik",
      "screen_name" : "jennaezarik",
      "indices" : [ 48, 60 ],
      "id_str" : "6015992",
      "id" : 6015992
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/792550612307091456\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/k44InEPM30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-0dTlUEAAAsNn.jpg",
      "id_str" : "792550475006480384",
      "id" : 792550475006480384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-0dTlUEAAAsNn.jpg",
      "sizes" : [ {
        "h" : 955,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 955,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 955,
        "resize" : "fit",
        "w" : 955
      } ],
      "display_url" : "pic.twitter.com\/k44InEPM30"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792552707424980993",
  "text" : "RT @ijustine: Me and sis peanut butter sandwich @jennaezarik \u263A\uFE0F https:\/\/t.co\/k44InEPM30",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jenna Ezarik",
        "screen_name" : "jennaezarik",
        "indices" : [ 34, 46 ],
        "id_str" : "6015992",
        "id" : 6015992
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/792550612307091456\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/k44InEPM30",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-0dTlUEAAAsNn.jpg",
        "id_str" : "792550475006480384",
        "id" : 792550475006480384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-0dTlUEAAAsNn.jpg",
        "sizes" : [ {
          "h" : 955,
          "resize" : "fit",
          "w" : 955
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 955,
          "resize" : "fit",
          "w" : 955
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 955,
          "resize" : "fit",
          "w" : 955
        } ],
        "display_url" : "pic.twitter.com\/k44InEPM30"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792550612307091456",
    "text" : "Me and sis peanut butter sandwich @jennaezarik \u263A\uFE0F https:\/\/t.co\/k44InEPM30",
    "id" : 792550612307091456,
    "created_at" : "2016-10-30 02:16:05 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873056728606097408\/KmXQNIx6_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 792552707424980993,
  "created_at" : "2016-10-30 02:24:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike",
      "screen_name" : "MikeBeaudreault",
      "indices" : [ 3, 19 ],
      "id_str" : "58234317",
      "id" : 58234317
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MikeBeaudreault\/status\/792424818972954624\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/lZcAVt3P8r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9CKfWWgAAghN2.jpg",
      "id_str" : "792424807421870080",
      "id" : 792424807421870080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9CKfWWgAAghN2.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lZcAVt3P8r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792552698549862400",
  "text" : "RT @MikeBeaudreault: My culture is not a costume. https:\/\/t.co\/lZcAVt3P8r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MikeBeaudreault\/status\/792424818972954624\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/lZcAVt3P8r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9CKfWWgAAghN2.jpg",
        "id_str" : "792424807421870080",
        "id" : 792424807421870080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9CKfWWgAAghN2.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lZcAVt3P8r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792424818972954624",
    "text" : "My culture is not a costume. https:\/\/t.co\/lZcAVt3P8r",
    "id" : 792424818972954624,
    "created_at" : "2016-10-29 17:56:14 +0000",
    "user" : {
      "name" : "Mike",
      "screen_name" : "MikeBeaudreault",
      "protected" : false,
      "id_str" : "58234317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884425803097927681\/8tpG4CZr_normal.jpg",
      "id" : 58234317,
      "verified" : false
    }
  },
  "id" : 792552698549862400,
  "created_at" : "2016-10-30 02:24:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "indices" : [ 3, 16 ],
      "id_str" : "474231541",
      "id" : 474231541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792552251130798080",
  "text" : "RT @ImYoungChizz: I had 2 rough weeks back to back. I like to take moments like this to reflect on positive things. Too many blessings to c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792323170401419264",
    "text" : "I had 2 rough weeks back to back. I like to take moments like this to reflect on positive things. Too many blessings to count",
    "id" : 792323170401419264,
    "created_at" : "2016-10-29 11:12:19 +0000",
    "user" : {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "protected" : false,
      "id_str" : "474231541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755204135268384768\/cg8TeT-h_normal.jpg",
      "id" : 474231541,
      "verified" : true
    }
  },
  "id" : 792552251130798080,
  "created_at" : "2016-10-30 02:22:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792552159011373056",
  "text" : "RT @elonmusk: Solar glass tiles can also incorporate heating elements, like rear defroster on a car, to clear roof of snow and keep generat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792218248917811204",
    "text" : "Solar glass tiles can also incorporate heating elements, like rear defroster on a car, to clear roof of snow and keep generating energy",
    "id" : 792218248917811204,
    "created_at" : "2016-10-29 04:15:23 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 792552159011373056,
  "created_at" : "2016-10-30 02:22:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/qP7REQA5fL",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNH76lK1GtUEn2bDnT0vRHvUWQX8Bg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779257318539&ei=B08VWLD7JcO2uAKd36vAAQ&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Fdarts%2F37812152&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792552108847468544",
  "text" : "RT @andikhm01: Dave Lanning: Darts &amp; speedway broadcaster dies at 78 - BBC News https:\/\/t.co\/qP7REQA5fL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/qP7REQA5fL",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNH76lK1GtUEn2bDnT0vRHvUWQX8Bg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779257318539&ei=B08VWLD7JcO2uAKd36vAAQ&url=http%3A%2F%2Fwww.bbc.co.uk%2Fsport%2Fdarts%2F37812152&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792541291577876480",
    "text" : "Dave Lanning: Darts &amp; speedway broadcaster dies at 78 - BBC News https:\/\/t.co\/qP7REQA5fL",
    "id" : 792541291577876480,
    "created_at" : "2016-10-30 01:39:03 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 792552108847468544,
  "created_at" : "2016-10-30 02:22:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/427978136278818816\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/9ZEYrkTB1M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfB72OhIYAAqFgn.jpg",
      "id_str" : "427978136140406784",
      "id" : 427978136140406784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfB72OhIYAAqFgn.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1428
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9ZEYrkTB1M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792551834573561856",
  "text" : "RT @BestGamezUp: one of the best controllers https:\/\/t.co\/9ZEYrkTB1M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/427978136278818816\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/9ZEYrkTB1M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfB72OhIYAAqFgn.jpg",
        "id_str" : "427978136140406784",
        "id" : 427978136140406784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfB72OhIYAAqFgn.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1428
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 861,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9ZEYrkTB1M"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792544081155153920",
    "text" : "one of the best controllers https:\/\/t.co\/9ZEYrkTB1M",
    "id" : 792544081155153920,
    "created_at" : "2016-10-30 01:50:08 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 792551834573561856,
  "created_at" : "2016-10-30 02:20:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/a5xsKiAk97",
      "expanded_url" : "http:\/\/fb.me\/87HKNEDBe",
      "display_url" : "fb.me\/87HKNEDBe"
    } ]
  },
  "geo" : { },
  "id_str" : "792551783453392896",
  "text" : "RT @EmperorDarroux: Scientists find the first known dinosaur brain tissue fossil https:\/\/t.co\/a5xsKiAk97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/a5xsKiAk97",
        "expanded_url" : "http:\/\/fb.me\/87HKNEDBe",
        "display_url" : "fb.me\/87HKNEDBe"
      } ]
    },
    "geo" : { },
    "id_str" : "792544256208633856",
    "text" : "Scientists find the first known dinosaur brain tissue fossil https:\/\/t.co\/a5xsKiAk97",
    "id" : 792544256208633856,
    "created_at" : "2016-10-30 01:50:50 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 792551783453392896,
  "created_at" : "2016-10-30 02:20:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/OAne8T3aec",
      "expanded_url" : "http:\/\/ow.ly\/rlsz305uEKt",
      "display_url" : "ow.ly\/rlsz305uEKt"
    } ]
  },
  "geo" : { },
  "id_str" : "792551233269760000",
  "text" : "RT @analyticbridge: Top Mistakes Developers Make When Using Python for Big Data Analytics https:\/\/t.co\/OAne8T3aec",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/OAne8T3aec",
        "expanded_url" : "http:\/\/ow.ly\/rlsz305uEKt",
        "display_url" : "ow.ly\/rlsz305uEKt"
      } ]
    },
    "geo" : { },
    "id_str" : "792546810334150657",
    "text" : "Top Mistakes Developers Make When Using Python for Big Data Analytics https:\/\/t.co\/OAne8T3aec",
    "id" : 792546810334150657,
    "created_at" : "2016-10-30 02:00:59 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 792551233269760000,
  "created_at" : "2016-10-30 02:18:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    }, {
      "name" : "Jane Merrick",
      "screen_name" : "janemerrick23",
      "indices" : [ 81, 95 ],
      "id_str" : "59471660",
      "id" : 59471660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halloween",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "isis",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/7lcWj6VQw3",
      "expanded_url" : "http:\/\/paper.li\/martincallan\/1311862121?edition_id=d3ce6630-9e45-11e6-b65b-0cc47a0d1609",
      "display_url" : "paper.li\/martincallan\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792550912304746496",
  "text" : "RT @martincallan: The latest The Daily Callan! https:\/\/t.co\/7lcWj6VQw3 Thanks to @janemerrick23 #halloween #isis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Merrick",
        "screen_name" : "janemerrick23",
        "indices" : [ 63, 77 ],
        "id_str" : "59471660",
        "id" : 59471660
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "halloween",
        "indices" : [ 78, 88 ]
      }, {
        "text" : "isis",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/7lcWj6VQw3",
        "expanded_url" : "http:\/\/paper.li\/martincallan\/1311862121?edition_id=d3ce6630-9e45-11e6-b65b-0cc47a0d1609",
        "display_url" : "paper.li\/martincallan\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792548849277698048",
    "text" : "The latest The Daily Callan! https:\/\/t.co\/7lcWj6VQw3 Thanks to @janemerrick23 #halloween #isis",
    "id" : 792548849277698048,
    "created_at" : "2016-10-30 02:09:05 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 792550912304746496,
  "created_at" : "2016-10-30 02:17:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renato Mazariegos",
      "screen_name" : "RPMSports18",
      "indices" : [ 3, 15 ],
      "id_str" : "166860265",
      "id" : 166860265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MICHvsMSU",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792550827525283840",
  "text" : "RT @RPMSports18: This Michigan fan stuck in the Michigan State student section hates his life so much right now. #MICHvsMSU https:\/\/t.co\/Fz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RPMSports18\/status\/792399549927075840\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/FzXVTcl8lu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv8rL_tUAAA4vxf.jpg",
        "id_str" : "792399544520540160",
        "id" : 792399544520540160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv8rL_tUAAA4vxf.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/FzXVTcl8lu"
      } ],
      "hashtags" : [ {
        "text" : "MICHvsMSU",
        "indices" : [ 96, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792399549927075840",
    "text" : "This Michigan fan stuck in the Michigan State student section hates his life so much right now. #MICHvsMSU https:\/\/t.co\/FzXVTcl8lu",
    "id" : 792399549927075840,
    "created_at" : "2016-10-29 16:15:49 +0000",
    "user" : {
      "name" : "Renato Mazariegos",
      "screen_name" : "RPMSports18",
      "protected" : false,
      "id_str" : "166860265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882284258546659328\/ydyZM-Ri_normal.jpg",
      "id" : 166860265,
      "verified" : false
    }
  },
  "id" : 792550827525283840,
  "created_at" : "2016-10-30 02:16:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdist",
      "screen_name" : "nerdist",
      "indices" : [ 3, 11 ],
      "id_str" : "394216985",
      "id" : 394216985
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 14, 26 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fireworks",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/CllsMs3KZp",
      "expanded_url" : "http:\/\/nerdi.st\/2dj67Ko",
      "display_url" : "nerdi.st\/2dj67Ko"
    } ]
  },
  "geo" : { },
  "id_str" : "792550284354519040",
  "text" : "RT @nerdist: .@colin_furze response to fans worried about his safety? Set off #fireworks in a van! https:\/\/t.co\/CllsMs3KZp https:\/\/t.co\/KPm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/nerdist.com\/\" rel=\"nofollow\"\u003Enerdist_nextscripts\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 1, 13 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nerdist\/status\/787322438824566784\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/KPmKlQeihy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu0hlZUUsAAYksZ.jpg",
        "id_str" : "787322436194709504",
        "id" : 787322436194709504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu0hlZUUsAAYksZ.jpg",
        "sizes" : [ {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 970
        } ],
        "display_url" : "pic.twitter.com\/KPmKlQeihy"
      } ],
      "hashtags" : [ {
        "text" : "fireworks",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/CllsMs3KZp",
        "expanded_url" : "http:\/\/nerdi.st\/2dj67Ko",
        "display_url" : "nerdi.st\/2dj67Ko"
      } ]
    },
    "geo" : { },
    "id_str" : "787322438824566784",
    "text" : ".@colin_furze response to fans worried about his safety? Set off #fireworks in a van! https:\/\/t.co\/CllsMs3KZp https:\/\/t.co\/KPmKlQeihy",
    "id" : 787322438824566784,
    "created_at" : "2016-10-15 16:01:11 +0000",
    "user" : {
      "name" : "Nerdist",
      "screen_name" : "nerdist",
      "protected" : false,
      "id_str" : "394216985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658730129066102784\/qH6cpyVx_normal.png",
      "id" : 394216985,
      "verified" : true
    }
  },
  "id" : 792550284354519040,
  "created_at" : "2016-10-30 02:14:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greenpower",
      "screen_name" : "Greenpowertrust",
      "indices" : [ 3, 19 ],
      "id_str" : "23665898",
      "id" : 23665898
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 38, 50 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GPFinal",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/QNoOzP0NDE",
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/787678740952276992",
      "display_url" : "twitter.com\/colin_furze\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792550219464445952",
  "text" : "RT @Greenpowertrust: Fantastic to see @colin_furze and his son attended the #GPFinal! Thanks for coming, Colin! https:\/\/t.co\/QNoOzP0NDE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 17, 29 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GPFinal",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/QNoOzP0NDE",
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/787678740952276992",
        "display_url" : "twitter.com\/colin_furze\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "788330421994000384",
    "text" : "Fantastic to see @colin_furze and his son attended the #GPFinal! Thanks for coming, Colin! https:\/\/t.co\/QNoOzP0NDE",
    "id" : 788330421994000384,
    "created_at" : "2016-10-18 10:46:33 +0000",
    "user" : {
      "name" : "Greenpower",
      "screen_name" : "Greenpowertrust",
      "protected" : false,
      "id_str" : "23665898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2796882337\/5709be844fa36f9580a9aa86e1659dff_normal.png",
      "id" : 23665898,
      "verified" : false
    }
  },
  "id" : 792550219464445952,
  "created_at" : "2016-10-30 02:14:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "furzeday",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792550170395283456",
  "text" : "RT @colin_furze: Really odd invention for you all at 4pm today #furzeday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "furzeday",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789050605306347520",
    "text" : "Really odd invention for you all at 4pm today #furzeday",
    "id" : 789050605306347520,
    "created_at" : "2016-10-20 10:28:18 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 792550170395283456,
  "created_at" : "2016-10-30 02:14:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792550133649006593",
  "text" : "RT @colin_furze: Never mind Red dead 2 or Logan what about the stomp o matic lol ......the other 2 things do look good  https:\/\/t.co\/VVJjXm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/789198938171596800\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/pGM3stm1bJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPMLboUIAAHZpZ.jpg",
        "id_str" : "789198856487444480",
        "id" : 789198856487444480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPMLboUIAAHZpZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/pGM3stm1bJ"
      } ],
      "hashtags" : [ {
        "text" : "furzeday",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/VVJjXmS6Vo",
        "expanded_url" : "https:\/\/youtu.be\/ysr9yOY53bk",
        "display_url" : "youtu.be\/ysr9yOY53bk"
      } ]
    },
    "geo" : { },
    "id_str" : "789198938171596800",
    "text" : "Never mind Red dead 2 or Logan what about the stomp o matic lol ......the other 2 things do look good  https:\/\/t.co\/VVJjXmS6Vo #furzeday https:\/\/t.co\/pGM3stm1bJ",
    "id" : 789198938171596800,
    "created_at" : "2016-10-20 20:17:44 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 792550133649006593,
  "created_at" : "2016-10-30 02:14:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/792093424593858560\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/tLjxkkQU6h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4UtYkXYAAE4MT.jpg",
      "id_str" : "792093354385432576",
      "id" : 792093354385432576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4UtYkXYAAE4MT.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/tLjxkkQU6h"
    } ],
    "hashtags" : [ {
      "text" : "furze",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/gmVMw2jyiO",
      "expanded_url" : "https:\/\/youtu.be\/vuRV-uXGy1w",
      "display_url" : "youtu.be\/vuRV-uXGy1w"
    } ]
  },
  "geo" : { },
  "id_str" : "792549943974191104",
  "text" : "RT @colin_furze: Build THIS with little skill and tools #furze https:\/\/t.co\/gmVMw2jyiO https:\/\/t.co\/tLjxkkQU6h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/792093424593858560\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/tLjxkkQU6h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4UtYkXYAAE4MT.jpg",
        "id_str" : "792093354385432576",
        "id" : 792093354385432576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4UtYkXYAAE4MT.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/tLjxkkQU6h"
      } ],
      "hashtags" : [ {
        "text" : "furze",
        "indices" : [ 39, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/gmVMw2jyiO",
        "expanded_url" : "https:\/\/youtu.be\/vuRV-uXGy1w",
        "display_url" : "youtu.be\/vuRV-uXGy1w"
      } ]
    },
    "geo" : { },
    "id_str" : "792093424593858560",
    "text" : "Build THIS with little skill and tools #furze https:\/\/t.co\/gmVMw2jyiO https:\/\/t.co\/tLjxkkQU6h",
    "id" : 792093424593858560,
    "created_at" : "2016-10-28 19:59:23 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 792549943974191104,
  "created_at" : "2016-10-30 02:13:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hoodie",
      "screen_name" : "HoodiePanda",
      "indices" : [ 3, 15 ],
      "id_str" : "375442181",
      "id" : 375442181
    }, {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 17, 29 ],
      "id_str" : "44184316",
      "id" : 44184316
    }, {
      "name" : "Amanda Faye",
      "screen_name" : "heyamandafaye",
      "indices" : [ 30, 44 ],
      "id_str" : "120666850",
      "id" : 120666850
    }, {
      "name" : "Hi5 Studios",
      "screen_name" : "Hi5Studios",
      "indices" : [ 45, 56 ],
      "id_str" : "773540541371940864",
      "id" : 773540541371940864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549847236771840",
  "text" : "RT @HoodiePanda: @Matthiasiam @heyamandafaye @Hi5Studios Because they \"hope\" you find it funny after 100x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias",
        "screen_name" : "Matthiasiam",
        "indices" : [ 0, 12 ],
        "id_str" : "44184316",
        "id" : 44184316
      }, {
        "name" : "Amanda Faye",
        "screen_name" : "heyamandafaye",
        "indices" : [ 13, 27 ],
        "id_str" : "120666850",
        "id" : 120666850
      }, {
        "name" : "Hi5 Studios",
        "screen_name" : "Hi5Studios",
        "indices" : [ 28, 39 ],
        "id_str" : "773540541371940864",
        "id" : 773540541371940864
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792462586226683904",
    "geo" : { },
    "id_str" : "792465200679047168",
    "in_reply_to_user_id" : 44184316,
    "text" : "@Matthiasiam @heyamandafaye @Hi5Studios Because they \"hope\" you find it funny after 100x",
    "id" : 792465200679047168,
    "in_reply_to_status_id" : 792462586226683904,
    "created_at" : "2016-10-29 20:36:41 +0000",
    "in_reply_to_screen_name" : "Matthiasiam",
    "in_reply_to_user_id_str" : "44184316",
    "user" : {
      "name" : "Hoodie",
      "screen_name" : "HoodiePanda",
      "protected" : false,
      "id_str" : "375442181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877200744419647488\/4RQy68oE_normal.jpg",
      "id" : 375442181,
      "verified" : false
    }
  },
  "id" : 792549847236771840,
  "created_at" : "2016-10-30 02:13:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    }, {
      "name" : "Amanda Faye",
      "screen_name" : "heyamandafaye",
      "indices" : [ 25, 39 ],
      "id_str" : "120666850",
      "id" : 120666850
    }, {
      "name" : "Hi5 Studios",
      "screen_name" : "Hi5Studios",
      "indices" : [ 52, 63 ],
      "id_str" : "773540541371940864",
      "id" : 773540541371940864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549298596634628",
  "text" : "RT @Matthiasiam: I think @heyamandafaye thinks that @Hi5Studios is a dangerous work environment because I keep coming hope with massive bru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Faye",
        "screen_name" : "heyamandafaye",
        "indices" : [ 8, 22 ],
        "id_str" : "120666850",
        "id" : 120666850
      }, {
        "name" : "Hi5 Studios",
        "screen_name" : "Hi5Studios",
        "indices" : [ 35, 46 ],
        "id_str" : "773540541371940864",
        "id" : 773540541371940864
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792461650162950144",
    "text" : "I think @heyamandafaye thinks that @Hi5Studios is a dangerous work environment because I keep coming hope with massive bruises.",
    "id" : 792461650162950144,
    "created_at" : "2016-10-29 20:22:35 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878063216936366080\/MYU8BMti_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 792549298596634628,
  "created_at" : "2016-10-30 02:10:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Reed Galen",
      "screen_name" : "reedgalen",
      "indices" : [ 39, 49 ],
      "id_str" : "63507170",
      "id" : 63507170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/JmvmreEJrM",
      "expanded_url" : "https:\/\/medium.com\/the-american-singularity\/todays-gop-burned-bridges-broken-promises-8eea574528ea#.aelh4cila",
      "display_url" : "medium.com\/the-american-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792549251821793280",
  "text" : "RT @Evan_McMullin: Insightful piece by @reedgalen on the GOP, the conservative movement, and their future. https:\/\/t.co\/JmvmreEJrM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reed Galen",
        "screen_name" : "reedgalen",
        "indices" : [ 20, 30 ],
        "id_str" : "63507170",
        "id" : 63507170
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/JmvmreEJrM",
        "expanded_url" : "https:\/\/medium.com\/the-american-singularity\/todays-gop-burned-bridges-broken-promises-8eea574528ea#.aelh4cila",
        "display_url" : "medium.com\/the-american-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792435050486829056",
    "text" : "Insightful piece by @reedgalen on the GOP, the conservative movement, and their future. https:\/\/t.co\/JmvmreEJrM",
    "id" : 792435050486829056,
    "created_at" : "2016-10-29 18:36:53 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 792549251821793280,
  "created_at" : "2016-10-30 02:10:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 99, 113 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trumptanic",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549221694046208",
  "text" : "RT @TeamMcMullin: Dear Americans: you don't have to go down with the #Trumptanic. Learn more about @Evan_McMullin here: https:\/\/t.co\/Pay7hS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 81, 95 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/792499467370962944\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/sismPdNP6Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-FdzQUkAEnOSr.jpg",
        "id_str" : "792498806461861889",
        "id" : 792498806461861889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-FdzQUkAEnOSr.jpg",
        "sizes" : [ {
          "h" : 717,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/sismPdNP6Z"
      } ],
      "hashtags" : [ {
        "text" : "Trumptanic",
        "indices" : [ 51, 62 ]
      }, {
        "text" : "McMullinFinn",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/Pay7hS7gax",
        "expanded_url" : "https:\/\/www.evanmcmullin.com",
        "display_url" : "evanmcmullin.com"
      } ]
    },
    "geo" : { },
    "id_str" : "792499467370962944",
    "text" : "Dear Americans: you don't have to go down with the #Trumptanic. Learn more about @Evan_McMullin here: https:\/\/t.co\/Pay7hS7gax #McMullinFinn https:\/\/t.co\/sismPdNP6Z",
    "id" : 792499467370962944,
    "created_at" : "2016-10-29 22:52:51 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 792549221694046208,
  "created_at" : "2016-10-30 02:10:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549180019474432",
  "text" : "RT @scrowder: Goes to Democrat site. Commenters are SURE Hillary will win. Go to conservative website. Commenters are SURE Trump wins. Midg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792462238594375680",
    "text" : "Goes to Democrat site. Commenters are SURE Hillary will win. Go to conservative website. Commenters are SURE Trump wins. Midget with tequila",
    "id" : 792462238594375680,
    "created_at" : "2016-10-29 20:24:55 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 792549180019474432,
  "created_at" : "2016-10-30 02:10:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 14, 28 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549137506009088",
  "text" : "RT @FoxNews: .@Evan_McMullin: \"We've got two major party candidates who are big government liberals... We've got to try to block them both.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 1, 15 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/792379003826937856\/photo\/1",
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/W3BIYik0rx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv8YbnbUMAAVzt4.jpg",
        "id_str" : "792378922159583232",
        "id" : 792378922159583232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv8YbnbUMAAVzt4.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/W3BIYik0rx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792379003826937856",
    "text" : ".@Evan_McMullin: \"We've got two major party candidates who are big government liberals... We've got to try to block them both.\" https:\/\/t.co\/W3BIYik0rx",
    "id" : 792379003826937856,
    "created_at" : "2016-10-29 14:54:10 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794654746342662144\/hHnFe4Sx_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 792549137506009088,
  "created_at" : "2016-10-30 02:10:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg",
      "screen_name" : "Gafster290",
      "indices" : [ 3, 14 ],
      "id_str" : "555349088",
      "id" : 555349088
    }, {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 16, 29 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792549025350385664",
  "text" : "RT @Gafster290: @PrisonPlanet Lol.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Joseph Watson",
        "screen_name" : "PrisonPlanet",
        "indices" : [ 0, 13 ],
        "id_str" : "18643437",
        "id" : 18643437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792129435034128384",
    "geo" : { },
    "id_str" : "792416555749433344",
    "in_reply_to_user_id" : 18643437,
    "text" : "@PrisonPlanet Lol.",
    "id" : 792416555749433344,
    "in_reply_to_status_id" : 792129435034128384,
    "created_at" : "2016-10-29 17:23:23 +0000",
    "in_reply_to_screen_name" : "PrisonPlanet",
    "in_reply_to_user_id_str" : "18643437",
    "user" : {
      "name" : "Greg",
      "screen_name" : "Gafster290",
      "protected" : false,
      "id_str" : "555349088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446803848070303744\/EuLSCyGl_normal.png",
      "id" : 555349088,
      "verified" : false
    }
  },
  "id" : 792549025350385664,
  "created_at" : "2016-10-30 02:09:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The_Real_Fly",
      "screen_name" : "The_Real_Fly",
      "indices" : [ 3, 16 ],
      "id_str" : "15079601",
      "id" : 15079601
    }, {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 18, 31 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548939656470528",
  "text" : "RT @The_Real_Fly: @PrisonPlanet weiner's great grandfather was Russian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Joseph Watson",
        "screen_name" : "PrisonPlanet",
        "indices" : [ 0, 13 ],
        "id_str" : "18643437",
        "id" : 18643437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792129435034128384",
    "geo" : { },
    "id_str" : "792276787568992256",
    "in_reply_to_user_id" : 18643437,
    "text" : "@PrisonPlanet weiner's great grandfather was Russian",
    "id" : 792276787568992256,
    "in_reply_to_status_id" : 792129435034128384,
    "created_at" : "2016-10-29 08:08:00 +0000",
    "in_reply_to_screen_name" : "PrisonPlanet",
    "in_reply_to_user_id_str" : "18643437",
    "user" : {
      "name" : "The_Real_Fly",
      "screen_name" : "The_Real_Fly",
      "protected" : false,
      "id_str" : "15079601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541335998769012737\/KFZv3A-a_normal.jpeg",
      "id" : 15079601,
      "verified" : false
    }
  },
  "id" : 792548939656470528,
  "created_at" : "2016-10-30 02:09:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 3, 16 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548754586996737",
  "text" : "RT @PrisonPlanet: Weiner is reportedly in Clinton-controlled solitary confinement. Hillary doesn't want him anywhere near a reporter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792269382365896704",
    "text" : "Weiner is reportedly in Clinton-controlled solitary confinement. Hillary doesn't want him anywhere near a reporter.",
    "id" : 792269382365896704,
    "created_at" : "2016-10-29 07:38:35 +0000",
    "user" : {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "protected" : false,
      "id_str" : "18643437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862654391739961345\/0qvW1agL_normal.jpg",
      "id" : 18643437,
      "verified" : true
    }
  },
  "id" : 792548754586996737,
  "created_at" : "2016-10-30 02:08:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 3, 16 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548673116839936",
  "text" : "RT @PrisonPlanet: Petition calls for amplified Muslim call for prayer to be allowed for UK towns that have over 50% Muslim population. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3iHZANx37I",
        "expanded_url" : "http:\/\/www.express.co.uk\/news\/uk\/725909\/Petition-UK-mosques-loud-call-prayer-THREE-TIMES-day",
        "display_url" : "express.co.uk\/news\/uk\/725909\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792333422870073344",
    "text" : "Petition calls for amplified Muslim call for prayer to be allowed for UK towns that have over 50% Muslim population. https:\/\/t.co\/3iHZANx37I",
    "id" : 792333422870073344,
    "created_at" : "2016-10-29 11:53:03 +0000",
    "user" : {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "protected" : false,
      "id_str" : "18643437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862654391739961345\/0qvW1agL_normal.jpg",
      "id" : 18643437,
      "verified" : true
    }
  },
  "id" : 792548673116839936,
  "created_at" : "2016-10-30 02:08:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOLLOW IF U HATE CNN",
      "screen_name" : "cnnwriter69",
      "indices" : [ 3, 15 ],
      "id_str" : "773622069091336193",
      "id" : 773622069091336193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hillarysemail",
      "indices" : [ 93, 107 ]
    }, {
      "text" : "podestaemails22",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548497274830848",
  "text" : "RT @cnnwriter69: John Podesta compares himself to a mobster for his collusion with Politico. #hillarysemail #podestaemails22 https:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cnnwriter69\/status\/792343760650792960\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/acBN8n7CRS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv74cpzWcAE3xf2.jpg",
        "id_str" : "792343755605045249",
        "id" : 792343755605045249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv74cpzWcAE3xf2.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/acBN8n7CRS"
      } ],
      "hashtags" : [ {
        "text" : "hillarysemail",
        "indices" : [ 76, 90 ]
      }, {
        "text" : "podestaemails22",
        "indices" : [ 91, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792343760650792960",
    "text" : "John Podesta compares himself to a mobster for his collusion with Politico. #hillarysemail #podestaemails22 https:\/\/t.co\/acBN8n7CRS",
    "id" : 792343760650792960,
    "created_at" : "2016-10-29 12:34:08 +0000",
    "user" : {
      "name" : "FOLLOW IF U HATE CNN",
      "screen_name" : "cnnwriter69",
      "protected" : false,
      "id_str" : "773622069091336193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800499595201515520\/9WTdzepR_normal.jpg",
      "id" : 773622069091336193,
      "verified" : false
    }
  },
  "id" : 792548497274830848,
  "created_at" : "2016-10-30 02:07:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 3, 16 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/7VYLCqRVRC",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-3885618\/Knifeman-run-stabbing-four-people-Frankfurt-train-station.html",
      "display_url" : "dailymail.co.uk\/news\/article-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792548416656113664",
  "text" : "RT @PrisonPlanet: Nothing to do with Islam. https:\/\/t.co\/7VYLCqRVRC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/7VYLCqRVRC",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-3885618\/Knifeman-run-stabbing-four-people-Frankfurt-train-station.html",
        "display_url" : "dailymail.co.uk\/news\/article-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792446170341773312",
    "text" : "Nothing to do with Islam. https:\/\/t.co\/7VYLCqRVRC",
    "id" : 792446170341773312,
    "created_at" : "2016-10-29 19:21:04 +0000",
    "user" : {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "protected" : false,
      "id_str" : "18643437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862654391739961345\/0qvW1agL_normal.jpg",
      "id" : 18643437,
      "verified" : true
    }
  },
  "id" : 792548416656113664,
  "created_at" : "2016-10-30 02:07:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/AY4OU3QQqZ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=cJV41gS2c8M",
      "display_url" : "youtube.com\/watch?v=cJV41g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792548388810153984",
  "text" : "RT @CheezusCripes: Hillary supporters act like thugs to minorities with different opinions\nhttps:\/\/t.co\/AY4OU3QQqZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/AY4OU3QQqZ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=cJV41gS2c8M",
        "display_url" : "youtube.com\/watch?v=cJV41g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792433171677769728",
    "text" : "Hillary supporters act like thugs to minorities with different opinions\nhttps:\/\/t.co\/AY4OU3QQqZ",
    "id" : 792433171677769728,
    "created_at" : "2016-10-29 18:29:25 +0000",
    "user" : {
      "name" : "Vincent Quimby\u2122",
      "screen_name" : "Vincent_Quimby",
      "protected" : false,
      "id_str" : "4460706432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866821682585096193\/8ehNVgUa_normal.jpg",
      "id" : 4460706432,
      "verified" : false
    }
  },
  "id" : 792548388810153984,
  "created_at" : "2016-10-30 02:07:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548301392535552",
  "text" : "RT @KassyDillon: Every republican's reaction after hearing that the FBI has restarted the investigation because of Anthony Weiner #DrainThe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Townhall.com",
        "screen_name" : "townhallcom",
        "indices" : [ 128, 140 ],
        "id_str" : "28614262",
        "id" : 28614262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792473792446623744\/video\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/NAWtNVrVsZ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/792473427307356160\/pu\/img\/WkjJVdGan8kwaB7n.jpg",
        "id_str" : "792473427307356160",
        "id" : 792473427307356160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/792473427307356160\/pu\/img\/WkjJVdGan8kwaB7n.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NAWtNVrVsZ"
      } ],
      "hashtags" : [ {
        "text" : "DrainTheSwamp",
        "indices" : [ 113, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792473792446623744",
    "text" : "Every republican's reaction after hearing that the FBI has restarted the investigation because of Anthony Weiner #DrainTheSwamp @townhallcom https:\/\/t.co\/NAWtNVrVsZ",
    "id" : 792473792446623744,
    "created_at" : "2016-10-29 21:10:50 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 792548301392535552,
  "created_at" : "2016-10-30 02:06:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/zJZ7fP4S5A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueW8AIOzjW.jpg",
      "id_str" : "792496451536482306",
      "id" : 792496451536482306,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueW8AIOzjW.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/zJZ7fP4S5A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueW8AAfQgv.jpg",
      "id_str" : "792496451536482304",
      "id" : 792496451536482304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueW8AAfQgv.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/zJZ7fP4S5A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueWAAEat1k.jpg",
      "id_str" : "792496451536420865",
      "id" : 792496451536420865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueWAAEat1k.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548175370391552",
  "text" : "RT @KassyDillon: Gary Johnson gets more views than Hillary... https:\/\/t.co\/zJZ7fP4S5A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/zJZ7fP4S5A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueW8AIOzjW.jpg",
        "id_str" : "792496451536482306",
        "id" : 792496451536482306,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueW8AIOzjW.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/zJZ7fP4S5A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueW8AAfQgv.jpg",
        "id_str" : "792496451536482304",
        "id" : 792496451536482304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueW8AAfQgv.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/792496457530089472\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/zJZ7fP4S5A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-DUueWAAEat1k.jpg",
        "id_str" : "792496451536420865",
        "id" : 792496451536420865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-DUueWAAEat1k.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/zJZ7fP4S5A"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792496457530089472",
    "text" : "Gary Johnson gets more views than Hillary... https:\/\/t.co\/zJZ7fP4S5A",
    "id" : 792496457530089472,
    "created_at" : "2016-10-29 22:40:54 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 792548175370391552,
  "created_at" : "2016-10-30 02:06:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "indices" : [ 3, 19 ],
      "id_str" : "1356030014",
      "id" : 1356030014
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LibertarianBlue\/status\/791399882582032384\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/QA9lBVhZYY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvud-i4WYAAz354.jpg",
      "id_str" : "791399857374257152",
      "id" : 791399857374257152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvud-i4WYAAz354.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/QA9lBVhZYY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548067035799552",
  "text" : "RT @LibertarianBlue: Yeah. That's right. What are YOU doing with your evening? https:\/\/t.co\/QA9lBVhZYY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LibertarianBlue\/status\/791399882582032384\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/QA9lBVhZYY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvud-i4WYAAz354.jpg",
        "id_str" : "791399857374257152",
        "id" : 791399857374257152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvud-i4WYAAz354.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/QA9lBVhZYY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791399882582032384",
    "text" : "Yeah. That's right. What are YOU doing with your evening? https:\/\/t.co\/QA9lBVhZYY",
    "id" : 791399882582032384,
    "created_at" : "2016-10-26 22:03:30 +0000",
    "user" : {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "protected" : false,
      "id_str" : "1356030014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821028721670967298\/j0XhnwCa_normal.jpg",
      "id" : 1356030014,
      "verified" : true
    }
  },
  "id" : 792548067035799552,
  "created_at" : "2016-10-30 02:05:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayaan Hirsi Ali",
      "screen_name" : "Ayaan",
      "indices" : [ 3, 9 ],
      "id_str" : "15912890",
      "id" : 15912890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792548023377203200",
  "text" : "RT @Ayaan: Obama says: \"terrorists want to make this war about Islam\"\nSeriously, where was he all this time?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742879727061438465",
    "text" : "Obama says: \"terrorists want to make this war about Islam\"\nSeriously, where was he all this time?",
    "id" : 742879727061438465,
    "created_at" : "2016-06-15 00:41:43 +0000",
    "user" : {
      "name" : "Ayaan Hirsi Ali",
      "screen_name" : "Ayaan",
      "protected" : false,
      "id_str" : "15912890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508945272\/ayaan_normal.jpg",
      "id" : 15912890,
      "verified" : true
    }
  },
  "id" : 792548023377203200,
  "created_at" : "2016-10-30 02:05:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayaan Hirsi Ali",
      "screen_name" : "Ayaan",
      "indices" : [ 3, 9 ],
      "id_str" : "15912890",
      "id" : 15912890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/CMT0yLGFNJ",
      "expanded_url" : "https:\/\/youtu.be\/wJkFQohIKNI",
      "display_url" : "youtu.be\/wJkFQohIKNI"
    } ]
  },
  "geo" : { },
  "id_str" : "792547899112562688",
  "text" : "RT @Ayaan: Why Don't Feminists Fight for Muslim Women? https:\/\/t.co\/CMT0yLGFNJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/CMT0yLGFNJ",
        "expanded_url" : "https:\/\/youtu.be\/wJkFQohIKNI",
        "display_url" : "youtu.be\/wJkFQohIKNI"
      } ]
    },
    "geo" : { },
    "id_str" : "748589214799921155",
    "text" : "Why Don't Feminists Fight for Muslim Women? https:\/\/t.co\/CMT0yLGFNJ",
    "id" : 748589214799921155,
    "created_at" : "2016-06-30 18:49:11 +0000",
    "user" : {
      "name" : "Ayaan Hirsi Ali",
      "screen_name" : "Ayaan",
      "protected" : false,
      "id_str" : "15912890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508945272\/ayaan_normal.jpg",
      "id" : 15912890,
      "verified" : true
    }
  },
  "id" : 792547899112562688,
  "created_at" : "2016-10-30 02:05:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 3, 16 ],
      "id_str" : "116994659",
      "id" : 116994659
    }, {
      "name" : "Ayaan Hirsi Ali",
      "screen_name" : "Ayaan",
      "indices" : [ 57, 63 ],
      "id_str" : "15912890",
      "id" : 15912890
    }, {
      "name" : "Maajid",
      "screen_name" : "MaajidNawaz",
      "indices" : [ 68, 80 ],
      "id_str" : "46078438",
      "id" : 46078438
    }, {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "indices" : [ 121, 131 ],
      "id_str" : "65698096",
      "id" : 65698096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792547830871261184",
  "text" : "RT @SamHarrisOrg: The Southern Poverty Law Center labels @Ayaan and @MaajidNawaz \"anti-Muslim extremists.\" Unbelievable! @splcenter\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ayaan Hirsi Ali",
        "screen_name" : "Ayaan",
        "indices" : [ 39, 45 ],
        "id_str" : "15912890",
        "id" : 15912890
      }, {
        "name" : "Maajid",
        "screen_name" : "MaajidNawaz",
        "indices" : [ 50, 62 ],
        "id_str" : "46078438",
        "id" : 46078438
      }, {
        "name" : "SPLC",
        "screen_name" : "splcenter",
        "indices" : [ 103, 113 ],
        "id_str" : "65698096",
        "id" : 65698096
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/rQz3ide3BZ",
        "expanded_url" : "http:\/\/bit.ly\/2dYMU4v",
        "display_url" : "bit.ly\/2dYMU4v"
      } ]
    },
    "geo" : { },
    "id_str" : "791486713579249664",
    "text" : "The Southern Poverty Law Center labels @Ayaan and @MaajidNawaz \"anti-Muslim extremists.\" Unbelievable! @splcenter\nhttps:\/\/t.co\/rQz3ide3BZ",
    "id" : 791486713579249664,
    "created_at" : "2016-10-27 03:48:32 +0000",
    "user" : {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "protected" : false,
      "id_str" : "116994659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715180693\/Headshot2_normal.jpg",
      "id" : 116994659,
      "verified" : true
    }
  },
  "id" : 792547830871261184,
  "created_at" : "2016-10-30 02:05:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ashcraft",
      "screen_name" : "Brian_Ashcraft",
      "indices" : [ 3, 18 ],
      "id_str" : "18762284",
      "id" : 18762284
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brian_Ashcraft\/status\/791132389938458625\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Qs2BVNGLR2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvqqoJ8WgAILJag.jpg",
      "id_str" : "791132291397484546",
      "id" : 791132291397484546,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvqqoJ8WgAILJag.jpg",
      "sizes" : [ {
        "h" : 138,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/Qs2BVNGLR2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792547716597444608",
  "text" : "RT @Brian_Ashcraft: It begins. https:\/\/t.co\/Qs2BVNGLR2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brian_Ashcraft\/status\/791132389938458625\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/Qs2BVNGLR2",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CvqqoJ8WgAILJag.jpg",
        "id_str" : "791132291397484546",
        "id" : 791132291397484546,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CvqqoJ8WgAILJag.jpg",
        "sizes" : [ {
          "h" : 138,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/Qs2BVNGLR2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791132389938458625",
    "text" : "It begins. https:\/\/t.co\/Qs2BVNGLR2",
    "id" : 791132389938458625,
    "created_at" : "2016-10-26 04:20:34 +0000",
    "user" : {
      "name" : "Brian Ashcraft",
      "screen_name" : "Brian_Ashcraft",
      "protected" : false,
      "id_str" : "18762284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701215844844441600\/hsmxitQn_normal.jpg",
      "id" : 18762284,
      "verified" : true
    }
  },
  "id" : 792547716597444608,
  "created_at" : "2016-10-30 02:04:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "indices" : [ 3, 19 ],
      "id_str" : "1356030014",
      "id" : 1356030014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/CrIrrwDSb6",
      "expanded_url" : "http:\/\/www.cnn.com\/2016\/10\/28\/politics\/fbi-reviewing-new-emails-in-clinton-probe-director-tells-senate-judiciary-committee\/",
      "display_url" : "cnn.com\/2016\/10\/28\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792547325440888832",
  "text" : "RT @LibertarianBlue: Those FBI bros keep oppressing Hillary smdh\nhttps:\/\/t.co\/CrIrrwDSb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/CrIrrwDSb6",
        "expanded_url" : "http:\/\/www.cnn.com\/2016\/10\/28\/politics\/fbi-reviewing-new-emails-in-clinton-probe-director-tells-senate-judiciary-committee\/",
        "display_url" : "cnn.com\/2016\/10\/28\/pol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792097346246979584",
    "text" : "Those FBI bros keep oppressing Hillary smdh\nhttps:\/\/t.co\/CrIrrwDSb6",
    "id" : 792097346246979584,
    "created_at" : "2016-10-28 20:14:58 +0000",
    "user" : {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "protected" : false,
      "id_str" : "1356030014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821028721670967298\/j0XhnwCa_normal.jpg",
      "id" : 1356030014,
      "verified" : true
    }
  },
  "id" : 792547325440888832,
  "created_at" : "2016-10-30 02:03:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Judd",
      "screen_name" : "juddzeez",
      "indices" : [ 3, 12 ],
      "id_str" : "251983774",
      "id" : 251983774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792547298102444032",
  "text" : "RT @juddzeez: Here's Trump on August 29th, speculating Weiner could be a security risk for Clinton's handling of classified information: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juddzeez\/status\/792085754210025472\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/jCMJ9zsT2z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv4NykNWIAAp7KF.jpg",
        "id_str" : "792085746828058624",
        "id" : 792085746828058624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv4NykNWIAAp7KF.jpg",
        "sizes" : [ {
          "h" : 287,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com\/jCMJ9zsT2z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792085754210025472",
    "text" : "Here's Trump on August 29th, speculating Weiner could be a security risk for Clinton's handling of classified information: https:\/\/t.co\/jCMJ9zsT2z",
    "id" : 792085754210025472,
    "created_at" : "2016-10-28 19:28:54 +0000",
    "user" : {
      "name" : "DJ Judd",
      "screen_name" : "juddzeez",
      "protected" : false,
      "id_str" : "251983774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871778912346492928\/rJ_y5xPG_normal.jpg",
      "id" : 251983774,
      "verified" : true
    }
  },
  "id" : 792547298102444032,
  "created_at" : "2016-10-30 02:02:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "indices" : [ 3, 19 ],
      "id_str" : "1356030014",
      "id" : 1356030014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792547103461474304",
  "text" : "RT @LibertarianBlue: Can you write on a chalk board with cheetos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792388877268971520",
    "geo" : { },
    "id_str" : "792391836442689537",
    "in_reply_to_user_id" : 1356030014,
    "text" : "Can you write on a chalk board with cheetos",
    "id" : 792391836442689537,
    "in_reply_to_status_id" : 792388877268971520,
    "created_at" : "2016-10-29 15:45:10 +0000",
    "in_reply_to_screen_name" : "LibertarianBlue",
    "in_reply_to_user_id_str" : "1356030014",
    "user" : {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "protected" : false,
      "id_str" : "1356030014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821028721670967298\/j0XhnwCa_normal.jpg",
      "id" : 1356030014,
      "verified" : true
    }
  },
  "id" : 792547103461474304,
  "created_at" : "2016-10-30 02:02:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "indices" : [ 3, 16 ],
      "id_str" : "26257166",
      "id" : 26257166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792546932967215108",
  "text" : "RT @SportsCenter: Jabrill Peppers scored his 4th TD of the season vs Michigan State.\n\nThat's as many as Charles Woodson had in his 1997 Hei\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SportsCenter\/status\/792469688794116096\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/VhujGR2gK3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9q-xuWcAAiK4d.jpg",
        "id_str" : "792469686172676096",
        "id" : 792469686172676096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9q-xuWcAAiK4d.jpg",
        "sizes" : [ {
          "h" : 1872,
          "resize" : "fit",
          "w" : 1872
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1872,
          "resize" : "fit",
          "w" : 1872
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/VhujGR2gK3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792469688794116096",
    "text" : "Jabrill Peppers scored his 4th TD of the season vs Michigan State.\n\nThat's as many as Charles Woodson had in his 1997 Heisman season. https:\/\/t.co\/VhujGR2gK3",
    "id" : 792469688794116096,
    "created_at" : "2016-10-29 20:54:31 +0000",
    "user" : {
      "name" : "SportsCenter",
      "screen_name" : "SportsCenter",
      "protected" : false,
      "id_str" : "26257166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875363787867652096\/JVsTbdmb_normal.jpg",
      "id" : 26257166,
      "verified" : true
    }
  },
  "id" : 792546932967215108,
  "created_at" : "2016-10-30 02:01:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2655beryl\u2655",
      "screen_name" : "ilysbhood",
      "indices" : [ 3, 13 ],
      "id_str" : "1165154540",
      "id" : 1165154540
    }, {
      "name" : "22 days",
      "screen_name" : "jacksfilms",
      "indices" : [ 15, 26 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792546839077806080",
  "text" : "RT @ilysbhood: @jacksfilms what's so big about the jackask",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "22 days",
        "screen_name" : "jacksfilms",
        "indices" : [ 0, 11 ],
        "id_str" : "9989862",
        "id" : 9989862
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792460145653452800",
    "geo" : { },
    "id_str" : "792460237215182849",
    "in_reply_to_user_id" : 9989862,
    "text" : "@jacksfilms what's so big about the jackask",
    "id" : 792460237215182849,
    "in_reply_to_status_id" : 792460145653452800,
    "created_at" : "2016-10-29 20:16:58 +0000",
    "in_reply_to_screen_name" : "jacksfilms",
    "in_reply_to_user_id_str" : "9989862",
    "user" : {
      "name" : "\u2655beryl\u2655",
      "screen_name" : "ilysbhood",
      "protected" : false,
      "id_str" : "1165154540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884505395737182208\/8d1Z4_pf_normal.jpg",
      "id" : 1165154540,
      "verified" : false
    }
  },
  "id" : 792546839077806080,
  "created_at" : "2016-10-30 02:01:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792546395005808640",
  "text" : "RT @scrowder: I think Trump has a better shot at WI than PA. MI? Not at all. People underestimate the thuggery and money of AFL-CIO. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/IDiKC15T8a",
        "expanded_url" : "https:\/\/twitter.com\/awt14_\/status\/792366641669562368",
        "display_url" : "twitter.com\/awt14_\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792366876923928576",
    "text" : "I think Trump has a better shot at WI than PA. MI? Not at all. People underestimate the thuggery and money of AFL-CIO. https:\/\/t.co\/IDiKC15T8a",
    "id" : 792366876923928576,
    "created_at" : "2016-10-29 14:05:59 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 792546395005808640,
  "created_at" : "2016-10-30 01:59:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khaledalnouss",
      "screen_name" : "khaledalnouss1",
      "indices" : [ 3, 18 ],
      "id_str" : "749367024623779841",
      "id" : 749367024623779841
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/khaledalnouss1\/status\/792167700231557121\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mk907pAYPw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5YUOEWYAAj2cO.jpg",
      "id_str" : "792167688860753920",
      "id" : 792167688860753920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5YUOEWYAAj2cO.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mk907pAYPw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/khaledalnouss1\/status\/792167700231557121\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mk907pAYPw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5YUOBXYAUEM4B.jpg",
      "id_str" : "792167688848236549",
      "id" : 792167688848236549,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5YUOBXYAUEM4B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 797,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/mk907pAYPw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792546313313419264",
  "text" : "RT @khaledalnouss1: Happy birthday to former Juventus goalkeeper Edwin Van Der Sar, who turns 46 today. [88 Games] https:\/\/t.co\/mk907pAYPw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/khaledalnouss1\/status\/792167700231557121\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/mk907pAYPw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5YUOEWYAAj2cO.jpg",
        "id_str" : "792167688860753920",
        "id" : 792167688860753920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5YUOEWYAAj2cO.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mk907pAYPw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/khaledalnouss1\/status\/792167700231557121\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/mk907pAYPw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5YUOBXYAUEM4B.jpg",
        "id_str" : "792167688848236549",
        "id" : 792167688848236549,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5YUOBXYAUEM4B.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/mk907pAYPw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792167700231557121",
    "text" : "Happy birthday to former Juventus goalkeeper Edwin Van Der Sar, who turns 46 today. [88 Games] https:\/\/t.co\/mk907pAYPw",
    "id" : 792167700231557121,
    "created_at" : "2016-10-29 00:54:32 +0000",
    "user" : {
      "name" : "Khaledalnouss",
      "screen_name" : "khaledalnouss1",
      "protected" : false,
      "id_str" : "749367024623779841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873950297944543232\/AlGKXMkk_normal.jpg",
      "id" : 749367024623779841,
      "verified" : false
    }
  },
  "id" : 792546313313419264,
  "created_at" : "2016-10-30 01:59:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792334580615409664",
  "geo" : { },
  "id_str" : "792546235014152192",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Just why???",
  "id" : 792546235014152192,
  "in_reply_to_status_id" : 792334580615409664,
  "created_at" : "2016-10-30 01:58:41 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792545913101312000",
  "text" : "RT @saatchi_gallery: Klaus Pichler's gorgeous photographs of rotting groceries are meant to churn stomachs over gross amounts of global foo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/792323349716361216\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/Ttec9Dk3qC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv7l4vkWYAA_VP6.jpg",
        "id_str" : "792323347468148736",
        "id" : 792323347468148736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv7l4vkWYAA_VP6.jpg",
        "sizes" : [ {
          "h" : 959,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 959,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 959,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Ttec9Dk3qC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792323349716361216",
    "text" : "Klaus Pichler's gorgeous photographs of rotting groceries are meant to churn stomachs over gross amounts of global food waste. https:\/\/t.co\/Ttec9Dk3qC",
    "id" : 792323349716361216,
    "created_at" : "2016-10-29 11:13:01 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 792545913101312000,
  "created_at" : "2016-10-30 01:57:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792545831635259392",
  "text" : "RT @ijustine: Rumor has it eating pumpkin spice Oreos before bed will give you sweet dreams.. \n\nI'll report back in the AM \uD83C\uDF83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792281438494134272",
    "text" : "Rumor has it eating pumpkin spice Oreos before bed will give you sweet dreams.. \n\nI'll report back in the AM \uD83C\uDF83",
    "id" : 792281438494134272,
    "created_at" : "2016-10-29 08:26:29 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873056728606097408\/KmXQNIx6_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 792545831635259392,
  "created_at" : "2016-10-30 01:57:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792545793890783232",
  "text" : "RT @lorenridinger: \"So many aspire for greatness; so few are willing to walk unfastened along the tightrope above the bordering lands of ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792275033477484544",
    "text" : "\"So many aspire for greatness; so few are willing to walk unfastened along the tightrope above the bordering lands of madness and genius.\"",
    "id" : 792275033477484544,
    "created_at" : "2016-10-29 08:01:02 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 792545793890783232,
  "created_at" : "2016-10-30 01:56:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/792257734884335620\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/xlmB4aqac2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv6qNcrWYAAIC5-.jpg",
      "id_str" : "792257732476821504",
      "id" : 792257732476821504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv6qNcrWYAAIC5-.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/xlmB4aqac2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792545773074391041",
  "text" : "RT @rockindigo: How can you club these things ;-; https:\/\/t.co\/xlmB4aqac2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/792257734884335620\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/xlmB4aqac2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv6qNcrWYAAIC5-.jpg",
        "id_str" : "792257732476821504",
        "id" : 792257732476821504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv6qNcrWYAAIC5-.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/xlmB4aqac2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792257734884335620",
    "text" : "How can you club these things ;-; https:\/\/t.co\/xlmB4aqac2",
    "id" : 792257734884335620,
    "created_at" : "2016-10-29 06:52:18 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 792545773074391041,
  "created_at" : "2016-10-30 01:56:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792545632108048384",
  "text" : "RT @HelloRyanHolmes: Dude. They ditched my phone and someone found it. They called the number flashing on the screen and I think i'm gettin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792196110815232004",
    "text" : "Dude. They ditched my phone and someone found it. They called the number flashing on the screen and I think i'm getting it back tomorrow...",
    "id" : 792196110815232004,
    "created_at" : "2016-10-29 02:47:25 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880486625746223106\/uqol0phE_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 792545632108048384,
  "created_at" : "2016-10-30 01:56:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ltKzpIHq6d",
      "expanded_url" : "http:\/\/ow.ly\/8Gj0305uEJB",
      "display_url" : "ow.ly\/8Gj0305uEJB"
    } ]
  },
  "geo" : { },
  "id_str" : "792545516018073600",
  "text" : "RT @analyticbridge: Job interview question: what is wrong with this picture? https:\/\/t.co\/ltKzpIHq6d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ltKzpIHq6d",
        "expanded_url" : "http:\/\/ow.ly\/8Gj0305uEJB",
        "display_url" : "ow.ly\/8Gj0305uEJB"
      } ]
    },
    "geo" : { },
    "id_str" : "792161687709310976",
    "text" : "Job interview question: what is wrong with this picture? https:\/\/t.co\/ltKzpIHq6d",
    "id" : 792161687709310976,
    "created_at" : "2016-10-29 00:30:38 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 792545516018073600,
  "created_at" : "2016-10-30 01:55:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luxe Zoie",
      "screen_name" : "zoieburgher",
      "indices" : [ 0, 12 ],
      "id_str" : "2258893508",
      "id" : 2258893508
    }, {
      "name" : "RiceGum",
      "screen_name" : "RiceGum",
      "indices" : [ 20, 28 ],
      "id_str" : "910874659",
      "id" : 910874659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792156882118901761",
  "geo" : { },
  "id_str" : "792545492441980928",
  "in_reply_to_user_id" : 2258893508,
  "text" : "@zoieburgher @_Odyn @RiceGum I have an expectation of females being good role models to a younger audience. I don't wanna see this \uD83D\uDE21",
  "id" : 792545492441980928,
  "in_reply_to_status_id" : 792156882118901761,
  "created_at" : "2016-10-30 01:55:44 +0000",
  "in_reply_to_screen_name" : "zoieburgher",
  "in_reply_to_user_id_str" : "2258893508",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOX Business",
      "screen_name" : "FoxBusiness",
      "indices" : [ 3, 15 ],
      "id_str" : "56413858",
      "id" : 56413858
    }, {
      "name" : "StubHub",
      "screen_name" : "StubHub",
      "indices" : [ 75, 83 ],
      "id_str" : "14419089",
      "id" : 14419089
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoxBusiness\/status\/792013053302759428\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/zCoQEbRJh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv3IfJiUsAAYdn3.jpg",
      "id_str" : "792009546948456448",
      "id" : 792009546948456448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv3IfJiUsAAYdn3.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/zCoQEbRJh8"
    } ],
    "hashtags" : [ {
      "text" : "WorldSeries",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792544573360832512",
  "text" : "RT @FoxBusiness: Prices for Game 3 of the #WorldSeries at Wrigley Field on @StubHub. https:\/\/t.co\/zCoQEbRJh8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StubHub",
        "screen_name" : "StubHub",
        "indices" : [ 58, 66 ],
        "id_str" : "14419089",
        "id" : 14419089
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxBusiness\/status\/792013053302759428\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/zCoQEbRJh8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv3IfJiUsAAYdn3.jpg",
        "id_str" : "792009546948456448",
        "id" : 792009546948456448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv3IfJiUsAAYdn3.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/zCoQEbRJh8"
      } ],
      "hashtags" : [ {
        "text" : "WorldSeries",
        "indices" : [ 25, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792013053302759428",
    "text" : "Prices for Game 3 of the #WorldSeries at Wrigley Field on @StubHub. https:\/\/t.co\/zCoQEbRJh8",
    "id" : 792013053302759428,
    "created_at" : "2016-10-28 14:40:01 +0000",
    "user" : {
      "name" : "FOX Business",
      "screen_name" : "FoxBusiness",
      "protected" : false,
      "id_str" : "56413858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875384861736841217\/j4vwsisS_normal.jpg",
      "id" : 56413858,
      "verified" : true
    }
  },
  "id" : 792544573360832512,
  "created_at" : "2016-10-30 01:52:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/792157503169687556\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ADBBkdx2Mn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5PDNEWAAAaaf-.jpg",
      "id_str" : "792157500929867776",
      "id" : 792157500929867776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5PDNEWAAAaaf-.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ADBBkdx2Mn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/JwNTSiJg7w",
      "expanded_url" : "http:\/\/engt.co\/2eWusbF",
      "display_url" : "engt.co\/2eWusbF"
    } ]
  },
  "geo" : { },
  "id_str" : "792543917778534401",
  "text" : "RT @engadget: Hey Twitter, hiding usernames won't help you https:\/\/t.co\/JwNTSiJg7w https:\/\/t.co\/ADBBkdx2Mn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/792157503169687556\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/ADBBkdx2Mn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5PDNEWAAAaaf-.jpg",
        "id_str" : "792157500929867776",
        "id" : 792157500929867776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5PDNEWAAAaaf-.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/ADBBkdx2Mn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/JwNTSiJg7w",
        "expanded_url" : "http:\/\/engt.co\/2eWusbF",
        "display_url" : "engt.co\/2eWusbF"
      } ]
    },
    "geo" : { },
    "id_str" : "792157503169687556",
    "text" : "Hey Twitter, hiding usernames won't help you https:\/\/t.co\/JwNTSiJg7w https:\/\/t.co\/ADBBkdx2Mn",
    "id" : 792157503169687556,
    "created_at" : "2016-10-29 00:14:00 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 792543917778534401,
  "created_at" : "2016-10-30 01:49:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/DexF59q3li",
      "expanded_url" : "https:\/\/www.conservativereview.com\/commentary\/2016\/10\/cruz-will-the-fbi-hold-hillary-clinton-accountable-this-time",
      "display_url" : "conservativereview.com\/commentary\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "792543886619078656",
  "text" : "RT @tedcruz: The rule of law matters, and it should apply equally and fairly to us all. https:\/\/t.co\/DexF59q3li",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/DexF59q3li",
        "expanded_url" : "https:\/\/www.conservativereview.com\/commentary\/2016\/10\/cruz-will-the-fbi-hold-hillary-clinton-accountable-this-time",
        "display_url" : "conservativereview.com\/commentary\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792164186994438146",
    "text" : "The rule of law matters, and it should apply equally and fairly to us all. https:\/\/t.co\/DexF59q3li",
    "id" : 792164186994438146,
    "created_at" : "2016-10-29 00:40:34 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 792543886619078656,
  "created_at" : "2016-10-30 01:49:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PetraMaier",
      "screen_name" : "PetraSuMaier",
      "indices" : [ 3, 16 ],
      "id_str" : "3245730508",
      "id" : 3245730508
    }, {
      "name" : "Vet o'Valentine Wars",
      "screen_name" : "VetForumWars",
      "indices" : [ 18, 31 ],
      "id_str" : "366259953",
      "id" : 366259953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792543259830673408",
  "text" : "RT @PetraSuMaier: @VetForumWars It seems all parties elected the perfect caricatures of themselves. I want Ron Paul back.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vet o'Valentine Wars",
        "screen_name" : "VetForumWars",
        "indices" : [ 0, 13 ],
        "id_str" : "366259953",
        "id" : 366259953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "792026744970743808",
    "geo" : { },
    "id_str" : "792028633837830148",
    "in_reply_to_user_id" : 366259953,
    "text" : "@VetForumWars It seems all parties elected the perfect caricatures of themselves. I want Ron Paul back.",
    "id" : 792028633837830148,
    "in_reply_to_status_id" : 792026744970743808,
    "created_at" : "2016-10-28 15:41:56 +0000",
    "in_reply_to_screen_name" : "VetForumWars",
    "in_reply_to_user_id_str" : "366259953",
    "user" : {
      "name" : "PetraMaier",
      "screen_name" : "PetraSuMaier",
      "protected" : false,
      "id_str" : "3245730508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682953981061120000\/WPuYZTq4_normal.jpg",
      "id" : 3245730508,
      "verified" : false
    }
  },
  "id" : 792543259830673408,
  "created_at" : "2016-10-30 01:46:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayne720",
      "screen_name" : "Jayne720",
      "indices" : [ 3, 12 ],
      "id_str" : "20889358",
      "id" : 20889358
    }, {
      "name" : "althusser respecter",
      "screen_name" : "areyousurebruv",
      "indices" : [ 14, 29 ],
      "id_str" : "224223937",
      "id" : 224223937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792543225814843394",
  "text" : "RT @Jayne720: @areyousurebruv Must be in withdrawal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "althusser respecter",
        "screen_name" : "areyousurebruv",
        "indices" : [ 0, 15 ],
        "id_str" : "224223937",
        "id" : 224223937
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791858718967107584",
    "geo" : { },
    "id_str" : "791938619103514624",
    "in_reply_to_user_id" : 224223937,
    "text" : "@areyousurebruv Must be in withdrawal.",
    "id" : 791938619103514624,
    "in_reply_to_status_id" : 791858718967107584,
    "created_at" : "2016-10-28 09:44:14 +0000",
    "in_reply_to_screen_name" : "areyousurebruv",
    "in_reply_to_user_id_str" : "224223937",
    "user" : {
      "name" : "Jayne720",
      "screen_name" : "Jayne720",
      "protected" : false,
      "id_str" : "20889358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847975151350280192\/4C_eKnRi_normal.jpg",
      "id" : 20889358,
      "verified" : false
    }
  },
  "id" : 792543225814843394,
  "created_at" : "2016-10-30 01:46:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INTERNETFRIEND \uD83C\uDF10",
      "screen_name" : "INTERNETFRIEND",
      "indices" : [ 3, 18 ],
      "id_str" : "277057336",
      "id" : 277057336
    }, {
      "name" : "althusser respecter",
      "screen_name" : "areyousurebruv",
      "indices" : [ 20, 35 ],
      "id_str" : "224223937",
      "id" : 224223937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792543071988772864",
  "text" : "RT @INTERNETFRIEND: @areyousurebruv what a disaster of a man at this point",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "althusser respecter",
        "screen_name" : "areyousurebruv",
        "indices" : [ 0, 15 ],
        "id_str" : "224223937",
        "id" : 224223937
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791858718967107584",
    "geo" : { },
    "id_str" : "791859239992131584",
    "in_reply_to_user_id" : 224223937,
    "text" : "@areyousurebruv what a disaster of a man at this point",
    "id" : 791859239992131584,
    "in_reply_to_status_id" : 791858718967107584,
    "created_at" : "2016-10-28 04:28:49 +0000",
    "in_reply_to_screen_name" : "areyousurebruv",
    "in_reply_to_user_id_str" : "224223937",
    "user" : {
      "name" : "INTERNETFRIEND \uD83C\uDF10",
      "screen_name" : "INTERNETFRIEND",
      "protected" : false,
      "id_str" : "277057336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882196791654875136\/lKlXJtew_normal.jpg",
      "id" : 277057336,
      "verified" : false
    }
  },
  "id" : 792543071988772864,
  "created_at" : "2016-10-30 01:46:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SignsAtTheGatesOfHell",
      "indices" : [ 14, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792542346634207232",
  "text" : "RT @MarkDice: #SignsAtTheGatesOfHell  \"Birthplace of Hillary Clinton\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SignsAtTheGatesOfHell",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792449167968784384",
    "text" : "#SignsAtTheGatesOfHell  \"Birthplace of Hillary Clinton\"",
    "id" : 792449167968784384,
    "created_at" : "2016-10-29 19:32:59 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 792542346634207232,
  "created_at" : "2016-10-30 01:43:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillarysEmail",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/FMG8iMNTD4",
      "expanded_url" : "https:\/\/youtu.be\/3teYvgMsNXk",
      "display_url" : "youtu.be\/3teYvgMsNXk"
    } ]
  },
  "geo" : { },
  "id_str" : "792542196587200512",
  "text" : "RT @MarkDice: Rachel Maddow Almost Cries Over FBI Investigating #HillarysEmail  https:\/\/t.co\/FMG8iMNTD4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillarysEmail",
        "indices" : [ 50, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/FMG8iMNTD4",
        "expanded_url" : "https:\/\/youtu.be\/3teYvgMsNXk",
        "display_url" : "youtu.be\/3teYvgMsNXk"
      } ]
    },
    "geo" : { },
    "id_str" : "792399552393252865",
    "text" : "Rachel Maddow Almost Cries Over FBI Investigating #HillarysEmail  https:\/\/t.co\/FMG8iMNTD4",
    "id" : 792399552393252865,
    "created_at" : "2016-10-29 16:15:50 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 792542196587200512,
  "created_at" : "2016-10-30 01:42:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    }, {
      "name" : "Kenneth Lipp",
      "screen_name" : "kennethlipp",
      "indices" : [ 13, 25 ],
      "id_str" : "35062969",
      "id" : 35062969
    }, {
      "name" : "matt blaze",
      "screen_name" : "mattblaze",
      "indices" : [ 26, 36 ],
      "id_str" : "26567591",
      "id" : 26567591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541942928269312",
  "text" : "RT @Snowden: @kennethlipp @mattblaze To save time: after Bush's warrantless wiretapping program came to light, AT&amp;T demanded an immunity la\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kenneth Lipp",
        "screen_name" : "kennethlipp",
        "indices" : [ 0, 12 ],
        "id_str" : "35062969",
        "id" : 35062969
      }, {
        "name" : "matt blaze",
        "screen_name" : "mattblaze",
        "indices" : [ 13, 23 ],
        "id_str" : "26567591",
        "id" : 26567591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791056665323905025",
    "geo" : { },
    "id_str" : "791057341223473153",
    "in_reply_to_user_id" : 2916305152,
    "text" : "@kennethlipp @mattblaze To save time: after Bush's warrantless wiretapping program came to light, AT&amp;T demanded an immunity law to continue.",
    "id" : 791057341223473153,
    "in_reply_to_status_id" : 791056665323905025,
    "created_at" : "2016-10-25 23:22:21 +0000",
    "in_reply_to_screen_name" : "Snowden",
    "in_reply_to_user_id_str" : "2916305152",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 792541942928269312,
  "created_at" : "2016-10-30 01:41:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The WikiLeaks Party",
      "screen_name" : "WikiLeaksParty",
      "indices" : [ 3, 18 ],
      "id_str" : "1208410202",
      "id" : 1208410202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541839723270144",
  "text" : "RT @WikiLeaksParty: (Washington, DC) \u2013 Judicial Watch announced today that it filed a Freedom of Information (FOIA) lawsuit to obtain... ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qLPhDOYi7h",
        "expanded_url" : "http:\/\/fb.me\/Y6DZ3RwY",
        "display_url" : "fb.me\/Y6DZ3RwY"
      } ]
    },
    "geo" : { },
    "id_str" : "792443120159862784",
    "text" : "(Washington, DC) \u2013 Judicial Watch announced today that it filed a Freedom of Information (FOIA) lawsuit to obtain... https:\/\/t.co\/qLPhDOYi7h",
    "id" : 792443120159862784,
    "created_at" : "2016-10-29 19:08:57 +0000",
    "user" : {
      "name" : "The WikiLeaks Party",
      "screen_name" : "WikiLeaksParty",
      "protected" : false,
      "id_str" : "1208410202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000164590650\/16c69926f9a148236dfc7b58deeff018_normal.png",
      "id" : 1208410202,
      "verified" : true
    }
  },
  "id" : 792541839723270144,
  "created_at" : "2016-10-30 01:41:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541770655596544",
  "text" : "RT @wikileaks: 2006 audio emerges of Clinton proposing election rigging in Palestine; censored by Israeli press for past 10 years https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/LsMYcUzJR4",
        "expanded_url" : "http:\/\/observer.com\/2016\/10\/2006-audio-emerges-of-hillary-clinton-proposing-rigging-palestine-election\/#.WBOP6mO8ojs.twitter",
        "display_url" : "observer.com\/2016\/10\/2006-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "792147717938089984",
    "text" : "2006 audio emerges of Clinton proposing election rigging in Palestine; censored by Israeli press for past 10 years https:\/\/t.co\/LsMYcUzJR4",
    "id" : 792147717938089984,
    "created_at" : "2016-10-28 23:35:08 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 792541770655596544,
  "created_at" : "2016-10-30 01:40:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541610408116224",
  "text" : "RT @wikileaks: Clinton's most emailed aid in the US State Department, Jake Sullivan, used personal email to talk with Clinton about bringin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wikileaks\/status\/792443303824334849\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/dgYu6DONGL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9SMmrXgAAcmhg.jpg",
        "id_str" : "792442435934846976",
        "id" : 792442435934846976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9SMmrXgAAcmhg.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 917
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 917
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 917
        } ],
        "display_url" : "pic.twitter.com\/dgYu6DONGL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792443303824334849",
    "text" : "Clinton's most emailed aid in the US State Department, Jake Sullivan, used personal email to talk with Clinton about bringing down Libya. https:\/\/t.co\/dgYu6DONGL",
    "id" : 792443303824334849,
    "created_at" : "2016-10-29 19:09:41 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 792541610408116224,
  "created_at" : "2016-10-30 01:40:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Examiner",
      "screen_name" : "dcexaminer",
      "indices" : [ 3, 14 ],
      "id_str" : "18956073",
      "id" : 18956073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541569337401344",
  "text" : "RT @dcexaminer: WikiLeaks reveals Hillary Clinton hid the \"depth\" of her email scandal from her own campaign manager and staff https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dcexaminer\/status\/792458540812238848\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/tuTdsDCesK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9g12MWEAAAwvK.jpg",
        "id_str" : "792458537637122048",
        "id" : 792458537637122048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9g12MWEAAAwvK.jpg",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/tuTdsDCesK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/OSv41n7azS",
        "expanded_url" : "http:\/\/washex.am\/2dYniBv",
        "display_url" : "washex.am\/2dYniBv"
      } ]
    },
    "geo" : { },
    "id_str" : "792458540812238848",
    "text" : "WikiLeaks reveals Hillary Clinton hid the \"depth\" of her email scandal from her own campaign manager and staff https:\/\/t.co\/OSv41n7azS https:\/\/t.co\/tuTdsDCesK",
    "id" : 792458540812238848,
    "created_at" : "2016-10-29 20:10:13 +0000",
    "user" : {
      "name" : "Washington Examiner",
      "screen_name" : "dcexaminer",
      "protected" : false,
      "id_str" : "18956073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727863966567903232\/inm00S9s_normal.jpg",
      "id" : 18956073,
      "verified" : true
    }
  },
  "id" : 792541569337401344,
  "created_at" : "2016-10-30 01:40:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg Politics",
      "screen_name" : "bpolitics",
      "indices" : [ 3, 13 ],
      "id_str" : "564111558",
      "id" : 564111558
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bpolitics\/status\/792469070436270080\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/yNMmSGBVcG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9qazJWEAAZYjT.jpg",
      "id_str" : "792469068079042560",
      "id" : 792469068079042560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9qazJWEAAZYjT.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/yNMmSGBVcG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/83j5ZimXWp",
      "expanded_url" : "http:\/\/bloom.bg\/2e9diZr",
      "display_url" : "bloom.bg\/2e9diZr"
    } ]
  },
  "geo" : { },
  "id_str" : "792541549016018944",
  "text" : "RT @bpolitics: WikiLeaks documents shine light on Clinton aide Doug Band https:\/\/t.co\/83j5ZimXWp https:\/\/t.co\/yNMmSGBVcG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bpolitics\/status\/792469070436270080\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/yNMmSGBVcG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv9qazJWEAAZYjT.jpg",
        "id_str" : "792469068079042560",
        "id" : 792469068079042560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv9qazJWEAAZYjT.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 844,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/yNMmSGBVcG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/83j5ZimXWp",
        "expanded_url" : "http:\/\/bloom.bg\/2e9diZr",
        "display_url" : "bloom.bg\/2e9diZr"
      } ]
    },
    "geo" : { },
    "id_str" : "792469070436270080",
    "text" : "WikiLeaks documents shine light on Clinton aide Doug Band https:\/\/t.co\/83j5ZimXWp https:\/\/t.co\/yNMmSGBVcG",
    "id" : 792469070436270080,
    "created_at" : "2016-10-29 20:52:04 +0000",
    "user" : {
      "name" : "Bloomberg Politics",
      "screen_name" : "bpolitics",
      "protected" : false,
      "id_str" : "564111558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714804098890133504\/cUO4gD1A_normal.jpg",
      "id" : 564111558,
      "verified" : true
    }
  },
  "id" : 792541549016018944,
  "created_at" : "2016-10-30 01:40:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541434008178688",
  "text" : "Will the Feds finally indict Hillary after one of the directors of wikileaks died and her emails been reopened",
  "id" : 792541434008178688,
  "created_at" : "2016-10-30 01:39:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792541171146973185",
  "text" : "For the record what Anthony was doing with underage girls isn't abnormal w\/ Bill from the Clinton crime family",
  "id" : 792541171146973185,
  "created_at" : "2016-10-30 01:38:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792540832805089280",
  "text" : "Hillary Clinton shouldn't have trusted a weenier, didn't she learn from Bill Clinton!",
  "id" : 792540832805089280,
  "created_at" : "2016-10-30 01:37:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Help",
      "screen_name" : "AmazonHelp",
      "indices" : [ 0, 11 ],
      "id_str" : "85741735",
      "id" : 85741735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792185799458562048",
  "geo" : { },
  "id_str" : "792540546044661761",
  "in_reply_to_user_id" : 85741735,
  "text" : "@AmazonHelp will try doing over the weekday, thanks :)",
  "id" : 792540546044661761,
  "in_reply_to_status_id" : 792185799458562048,
  "created_at" : "2016-10-30 01:36:05 +0000",
  "in_reply_to_screen_name" : "AmazonHelp",
  "in_reply_to_user_id_str" : "85741735",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792323418519724032",
  "geo" : { },
  "id_str" : "792540483604082688",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp it has been fixed!!!",
  "id" : 792540483604082688,
  "in_reply_to_status_id" : 792323418519724032,
  "created_at" : "2016-10-30 01:35:50 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792154120148938756",
  "text" : "RT @scrowder: Anthony Weiner just can't stop screwing people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792124863980986368",
    "text" : "Anthony Weiner just can't stop screwing people.",
    "id" : 792124863980986368,
    "created_at" : "2016-10-28 22:04:19 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 792154120148938756,
  "created_at" : "2016-10-29 00:00:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Help",
      "screen_name" : "AmazonHelp",
      "indices" : [ 0, 11 ],
      "id_str" : "85741735",
      "id" : 85741735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792153834806272001",
  "in_reply_to_user_id" : 85741735,
  "text" : "@AmazonHelp Hi I am using an affiliate plugin 4 Wordpress by a third party &amp; it shows numerous clicks that don't show on my Amazon dashboard",
  "id" : 792153834806272001,
  "created_at" : "2016-10-28 23:59:26 +0000",
  "in_reply_to_screen_name" : "AmazonHelp",
  "in_reply_to_user_id_str" : "85741735",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/792153324611133445\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/cZDaEXJoYT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv5LP1SWgAAq2t3.jpg",
      "id_str" : "792153319837958144",
      "id" : 792153319837958144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv5LP1SWgAAq2t3.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 617
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/cZDaEXJoYT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792153324611133445",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp is LinkedIn having some server issues, I need to login and email my boss and some distributors? https:\/\/t.co\/cZDaEXJoYT",
  "id" : 792153324611133445,
  "created_at" : "2016-10-28 23:57:24 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/5QBsq1ttHw",
      "expanded_url" : "http:\/\/fb.me\/4UiayjK53",
      "display_url" : "fb.me\/4UiayjK53"
    } ]
  },
  "geo" : { },
  "id_str" : "792121378296168448",
  "text" : "RT @EmperorDarroux: Zip around Taiwan on the faster Gogoro S electric scooter https:\/\/t.co\/5QBsq1ttHw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/5QBsq1ttHw",
        "expanded_url" : "http:\/\/fb.me\/4UiayjK53",
        "display_url" : "fb.me\/4UiayjK53"
      } ]
    },
    "geo" : { },
    "id_str" : "792121000079028225",
    "text" : "Zip around Taiwan on the faster Gogoro S electric scooter https:\/\/t.co\/5QBsq1ttHw",
    "id" : 792121000079028225,
    "created_at" : "2016-10-28 21:48:57 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 792121378296168448,
  "created_at" : "2016-10-28 21:50:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792121279524503552",
  "text" : "Sometimes I crave gas station pizza and an Arnold Palmer than I realize I should really work out",
  "id" : 792121279524503552,
  "created_at" : "2016-10-28 21:50:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Verstappen",
      "screen_name" : "Max33Verstappen",
      "indices" : [ 3, 19 ],
      "id_str" : "556260847",
      "id" : 556260847
    }, {
      "name" : "Red Bull Racing",
      "screen_name" : "redbullracing",
      "indices" : [ 25, 39 ],
      "id_str" : "226087776",
      "id" : 226087776
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lessonlearned",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "MexicoGP",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792015000462303232",
  "text" : "RT @Max33Verstappen: The @redbullracing team is teaching me how to do my own pitstops, just in case... #lessonlearned #MexicoGP https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Bull Racing",
        "screen_name" : "redbullracing",
        "indices" : [ 4, 18 ],
        "id_str" : "226087776",
        "id" : 226087776
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Max33Verstappen\/status\/792000369568219136\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/LN29daL1oZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv2xPr-WYAAgECg.jpg",
        "id_str" : "791983992547467264",
        "id" : 791983992547467264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv2xPr-WYAAgECg.jpg",
        "sizes" : [ {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/LN29daL1oZ"
      } ],
      "hashtags" : [ {
        "text" : "lessonlearned",
        "indices" : [ 82, 96 ]
      }, {
        "text" : "MexicoGP",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792000369568219136",
    "text" : "The @redbullracing team is teaching me how to do my own pitstops, just in case... #lessonlearned #MexicoGP https:\/\/t.co\/LN29daL1oZ",
    "id" : 792000369568219136,
    "created_at" : "2016-10-28 13:49:37 +0000",
    "user" : {
      "name" : "Max Verstappen",
      "screen_name" : "Max33Verstappen",
      "protected" : false,
      "id_str" : "556260847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856876528231219202\/RWxtKdXN_normal.jpg",
      "id" : 556260847,
      "verified" : true
    }
  },
  "id" : 792015000462303232,
  "created_at" : "2016-10-28 14:47:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chick-fil-A, Inc.",
      "screen_name" : "ChickfilA",
      "indices" : [ 24, 34 ],
      "id_str" : "16043308",
      "id" : 16043308
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/792014820635705344\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/o3Padneauq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv3NRm8WcAAbxDY.jpg",
      "id_str" : "792014811882221568",
      "id" : 792014811882221568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv3NRm8WcAAbxDY.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/o3Padneauq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792014820635705344",
  "text" : "Grilled sandwiches from @ChickfilA are so good https:\/\/t.co\/o3Padneauq",
  "id" : 792014820635705344,
  "created_at" : "2016-10-28 14:47:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA.com",
      "screen_name" : "NBAcom",
      "indices" : [ 3, 10 ],
      "id_str" : "1373313666",
      "id" : 1373313666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NBAcom\/status\/791958471767830528\/video\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/tRmwPsyUeo",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791958210294853632\/pu\/img\/Do9DOCoznySDQU3a.jpg",
      "id_str" : "791958210294853632",
      "id" : 791958210294853632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791958210294853632\/pu\/img\/Do9DOCoznySDQU3a.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tRmwPsyUeo"
    } ],
    "hashtags" : [ {
      "text" : "FastBreak",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791998905701597184",
  "text" : "RT @NBAcom: Miss a game last night? Catch up on 'em all in the #FastBreak! https:\/\/t.co\/tRmwPsyUeo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NBAcom\/status\/791958471767830528\/video\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/tRmwPsyUeo",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791958210294853632\/pu\/img\/Do9DOCoznySDQU3a.jpg",
        "id_str" : "791958210294853632",
        "id" : 791958210294853632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791958210294853632\/pu\/img\/Do9DOCoznySDQU3a.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tRmwPsyUeo"
      } ],
      "hashtags" : [ {
        "text" : "FastBreak",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791958471767830528",
    "text" : "Miss a game last night? Catch up on 'em all in the #FastBreak! https:\/\/t.co\/tRmwPsyUeo",
    "id" : 791958471767830528,
    "created_at" : "2016-10-28 11:03:08 +0000",
    "user" : {
      "name" : "NBA.com",
      "screen_name" : "NBAcom",
      "protected" : false,
      "id_str" : "1373313666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884040400163545089\/xOm7mdMW_normal.jpg",
      "id" : 1373313666,
      "verified" : true
    }
  },
  "id" : 791998905701597184,
  "created_at" : "2016-10-28 13:43:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/vYdWIVPRSY",
      "expanded_url" : "http:\/\/fb.me\/3Gugev2DT",
      "display_url" : "fb.me\/3Gugev2DT"
    } ]
  },
  "geo" : { },
  "id_str" : "791998435410845697",
  "text" : "RT @EmperorDarroux: ICYMI: Microsoft throws everything into mixed reality https:\/\/t.co\/vYdWIVPRSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/vYdWIVPRSY",
        "expanded_url" : "http:\/\/fb.me\/3Gugev2DT",
        "display_url" : "fb.me\/3Gugev2DT"
      } ]
    },
    "geo" : { },
    "id_str" : "791996767332106241",
    "text" : "ICYMI: Microsoft throws everything into mixed reality https:\/\/t.co\/vYdWIVPRSY",
    "id" : 791996767332106241,
    "created_at" : "2016-10-28 13:35:18 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 791998435410845697,
  "created_at" : "2016-10-28 13:41:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SI_F",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791998283426238465",
  "text" : "RT @HamzeiAnalytics: BLOCK TRADE detected in #SI_F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SI_F",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791996489400619008",
    "text" : "BLOCK TRADE detected in #SI_F",
    "id" : 791996489400619008,
    "created_at" : "2016-10-28 13:34:12 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 791998283426238465,
  "created_at" : "2016-10-28 13:41:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Westbrook",
      "screen_name" : "Cam_Westbrook",
      "indices" : [ 3, 17 ],
      "id_str" : "1054209961",
      "id" : 1054209961
    }, {
      "name" : "ceneblock",
      "screen_name" : "ceneblock",
      "indices" : [ 19, 29 ],
      "id_str" : "721802143275941888",
      "id" : 721802143275941888
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 30, 42 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791996853135011840",
  "text" : "RT @Cam_Westbrook: @ceneblock @KassyDillon yeah I was thinking the same thing. But no, someone less perfect seems to have filmed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ceneblock",
        "screen_name" : "ceneblock",
        "indices" : [ 0, 10 ],
        "id_str" : "721802143275941888",
        "id" : 721802143275941888
      }, {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 11, 23 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791121708640067584",
    "geo" : { },
    "id_str" : "791282833981661185",
    "in_reply_to_user_id" : 721802143275941888,
    "text" : "@ceneblock @KassyDillon yeah I was thinking the same thing. But no, someone less perfect seems to have filmed.",
    "id" : 791282833981661185,
    "in_reply_to_status_id" : 791121708640067584,
    "created_at" : "2016-10-26 14:18:23 +0000",
    "in_reply_to_screen_name" : "ceneblock",
    "in_reply_to_user_id_str" : "721802143275941888",
    "user" : {
      "name" : "Cameron Westbrook",
      "screen_name" : "Cam_Westbrook",
      "protected" : false,
      "id_str" : "1054209961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879837689679368193\/MFPaxqoS_normal.jpg",
      "id" : 1054209961,
      "verified" : false
    }
  },
  "id" : 791996853135011840,
  "created_at" : "2016-10-28 13:35:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charlie mackesy",
      "screen_name" : "charliemackesy",
      "indices" : [ 3, 18 ],
      "id_str" : "402363096",
      "id" : 402363096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791996401911734272",
  "text" : "RT @charliemackesy: Avoid negatively comparing yourself with those who look like they have it all together .There's a lot of frantic paddli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791358221315432448",
    "text" : "Avoid negatively comparing yourself with those who look like they have it all together .There's a lot of frantic paddling under those swans.",
    "id" : 791358221315432448,
    "created_at" : "2016-10-26 19:17:57 +0000",
    "user" : {
      "name" : "charlie mackesy",
      "screen_name" : "charliemackesy",
      "protected" : false,
      "id_str" : "402363096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870954578237378560\/r1Jq-S5A_normal.jpg",
      "id" : 402363096,
      "verified" : false
    }
  },
  "id" : 791996401911734272,
  "created_at" : "2016-10-28 13:33:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 41, 45 ],
      "id_str" : "759251",
      "id" : 759251
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 47, 61 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 66, 76 ],
      "id_str" : "4248211",
      "id" : 4248211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791996337160069120",
  "text" : "RT @TeamMcMullin: Coming up next LIVE on @CNN: @Evan_McMullin and @mindyfinn!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 23, 27 ],
        "id_str" : "759251",
        "id" : 759251
      }, {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 29, 43 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      }, {
        "name" : "Mindy Finn",
        "screen_name" : "mindyfinn",
        "indices" : [ 48, 58 ],
        "id_str" : "4248211",
        "id" : 4248211
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791658653094772737",
    "text" : "Coming up next LIVE on @CNN: @Evan_McMullin and @mindyfinn!",
    "id" : 791658653094772737,
    "created_at" : "2016-10-27 15:11:45 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 791996337160069120,
  "created_at" : "2016-10-28 13:33:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791996244918996992",
  "text" : "RT @BONNIELYNN2015: Apple??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791994996232630276",
    "text" : "Apple??",
    "id" : 791994996232630276,
    "created_at" : "2016-10-28 13:28:16 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883931234337816576\/xJntU2gN_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 791996244918996992,
  "created_at" : "2016-10-28 13:33:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Style Details",
      "screen_name" : "StyleDetails",
      "indices" : [ 0, 13 ],
      "id_str" : "582753822",
      "id" : 582753822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791995191523741696",
  "geo" : { },
  "id_str" : "791995941834395648",
  "in_reply_to_user_id" : 582753822,
  "text" : "@StyleDetails Anastasiya Kvitko is much prettier",
  "id" : 791995941834395648,
  "in_reply_to_status_id" : 791995191523741696,
  "created_at" : "2016-10-28 13:32:01 +0000",
  "in_reply_to_screen_name" : "StyleDetails",
  "in_reply_to_user_id_str" : "582753822",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/tFEIifyzzR",
      "expanded_url" : "http:\/\/ow.ly\/YV9k305uEJg",
      "display_url" : "ow.ly\/YV9k305uEJg"
    } ]
  },
  "geo" : { },
  "id_str" : "791995730223325188",
  "text" : "RT @analyticbridge: Answers to dozens of data science job interview questions https:\/\/t.co\/tFEIifyzzR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/tFEIifyzzR",
        "expanded_url" : "http:\/\/ow.ly\/YV9k305uEJg",
        "display_url" : "ow.ly\/YV9k305uEJg"
      } ]
    },
    "geo" : { },
    "id_str" : "791995660455251968",
    "text" : "Answers to dozens of data science job interview questions https:\/\/t.co\/tFEIifyzzR",
    "id" : 791995660455251968,
    "created_at" : "2016-10-28 13:30:54 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 791995730223325188,
  "created_at" : "2016-10-28 13:31:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mb7e3D5npc",
      "expanded_url" : "http:\/\/es.pn\/2e4ku8W",
      "display_url" : "es.pn\/2e4ku8W"
    } ]
  },
  "geo" : { },
  "id_str" : "791995697436454913",
  "text" : "RT @FXStefan: Jerome Boger's flag-happy crew to call Eagles-Cowboys in Week 8: Jerome Boger's flag-happy crew t... https:\/\/t.co\/mb7e3D5npc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 125, 131 ]
      }, {
        "text" : "nfl",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/mb7e3D5npc",
        "expanded_url" : "http:\/\/es.pn\/2e4ku8W",
        "display_url" : "es.pn\/2e4ku8W"
      } ]
    },
    "geo" : { },
    "id_str" : "791995274658930689",
    "text" : "Jerome Boger's flag-happy crew to call Eagles-Cowboys in Week 8: Jerome Boger's flag-happy crew t... https:\/\/t.co\/mb7e3D5npc #sport #nfl",
    "id" : 791995274658930689,
    "created_at" : "2016-10-28 13:29:22 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 791995697436454913,
  "created_at" : "2016-10-28 13:31:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791923067190648832",
  "geo" : { },
  "id_str" : "791995540045266944",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo this is awesome!!!",
  "id" : 791995540045266944,
  "in_reply_to_status_id" : 791923067190648832,
  "created_at" : "2016-10-28 13:30:25 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    }, {
      "name" : "remi stevens",
      "screen_name" : "remistevens",
      "indices" : [ 81, 93 ],
      "id_str" : "20575931",
      "id" : 20575931
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 94, 106 ]
    }, {
      "text" : "facman",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Cn2ySQ8wA5",
      "expanded_url" : "http:\/\/paper.li\/GuyKawasaki?edition_id=5cb7f270-9d12-11e6-b65b-0cc47a0d1609",
      "display_url" : "paper.li\/GuyKawasaki?ed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791995404376301568",
  "text" : "RT @GuyKawasaki: The latest Guy\u2019s Daily Paper! https:\/\/t.co\/Cn2ySQ8wA5 Thanks to @remistevens #socialmedia #facman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "remi stevens",
        "screen_name" : "remistevens",
        "indices" : [ 64, 76 ],
        "id_str" : "20575931",
        "id" : 20575931
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialmedia",
        "indices" : [ 77, 89 ]
      }, {
        "text" : "facman",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/Cn2ySQ8wA5",
        "expanded_url" : "http:\/\/paper.li\/GuyKawasaki?edition_id=5cb7f270-9d12-11e6-b65b-0cc47a0d1609",
        "display_url" : "paper.li\/GuyKawasaki?ed\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791994963634642944",
    "text" : "The latest Guy\u2019s Daily Paper! https:\/\/t.co\/Cn2ySQ8wA5 Thanks to @remistevens #socialmedia #facman",
    "id" : 791994963634642944,
    "created_at" : "2016-10-28 13:28:08 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 791995404376301568,
  "created_at" : "2016-10-28 13:29:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791995236553789441",
  "text" : "Not sure what is worse having a deeply sad conversation or doing bad at a test.",
  "id" : 791995236553789441,
  "created_at" : "2016-10-28 13:29:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791995013764882432",
  "text" : "Some people use conference rooms for private work, others use it to watch Bollywood movies \uD83D\uDE21\uD83D\uDE21\uD83D\uDE21",
  "id" : 791995013764882432,
  "created_at" : "2016-10-28 13:28:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791994800006455302",
  "text" : "Someone gave me a free butterfinger, I made someone laugh and got a gig on Fiverr, so far a nice start to the day",
  "id" : 791994800006455302,
  "created_at" : "2016-10-28 13:27:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/dsEwzp4b0F",
      "expanded_url" : "http:\/\/fb.me\/53JcH6Em2",
      "display_url" : "fb.me\/53JcH6Em2"
    } ]
  },
  "geo" : { },
  "id_str" : "791358226130407424",
  "text" : "RT @EmperorDarroux: Why SK Gaming is favored to win the ESL Pro League Finals https:\/\/t.co\/dsEwzp4b0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/dsEwzp4b0F",
        "expanded_url" : "http:\/\/fb.me\/53JcH6Em2",
        "display_url" : "fb.me\/53JcH6Em2"
      } ]
    },
    "geo" : { },
    "id_str" : "791357484145385472",
    "text" : "Why SK Gaming is favored to win the ESL Pro League Finals https:\/\/t.co\/dsEwzp4b0F",
    "id" : 791357484145385472,
    "created_at" : "2016-10-26 19:15:01 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 791358226130407424,
  "created_at" : "2016-10-26 19:17:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "indices" : [ 3, 11 ],
      "id_str" : "18930003",
      "id" : 18930003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791358189627473920",
  "text" : "RT @UgoUche: You are not your mistakes, but your mistakes are yours.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791357624419627008",
    "text" : "You are not your mistakes, but your mistakes are yours.",
    "id" : 791357624419627008,
    "created_at" : "2016-10-26 19:15:35 +0000",
    "user" : {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "protected" : false,
      "id_str" : "18930003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2161257485\/img_0008__427x640___214x320___120x180__normal.jpg",
      "id" : 18930003,
      "verified" : false
    }
  },
  "id" : 791358189627473920,
  "created_at" : "2016-10-26 19:17:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Squire",
      "screen_name" : "travelsquire",
      "indices" : [ 3, 16 ],
      "id_str" : "25354439",
      "id" : 25354439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "travelbucketlist",
      "indices" : [ 33, 50 ]
    }, {
      "text" : "TRAVEX",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791358145553657856",
  "text" : "RT @travelsquire: What's on your #travelbucketlist Tell us tonight on #TRAVEX at 5PM EST.  Join us in a couple of hours.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "travelbucketlist",
        "indices" : [ 15, 32 ]
      }, {
        "text" : "TRAVEX",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791357708003934208",
    "text" : "What's on your #travelbucketlist Tell us tonight on #TRAVEX at 5PM EST.  Join us in a couple of hours.",
    "id" : 791357708003934208,
    "created_at" : "2016-10-26 19:15:54 +0000",
    "user" : {
      "name" : "Travel Squire",
      "screen_name" : "travelsquire",
      "protected" : false,
      "id_str" : "25354439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1676507896\/NewTravelSquiresmall_2_normal.jpg",
      "id" : 25354439,
      "verified" : false
    }
  },
  "id" : 791358145553657856,
  "created_at" : "2016-10-26 19:17:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791357966066876420",
  "text" : "When life gives you lemons, eat them and plant their seeds",
  "id" : 791357966066876420,
  "created_at" : "2016-10-26 19:16:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791357748797669376",
  "text" : "The challenges you face in life get worse if you pity yourself.",
  "id" : 791357748797669376,
  "created_at" : "2016-10-26 19:16:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/gMdEfafgu1",
      "expanded_url" : "http:\/\/fb.me\/srvIyldt",
      "display_url" : "fb.me\/srvIyldt"
    } ]
  },
  "geo" : { },
  "id_str" : "791352724759650304",
  "text" : "RT @EmperorDarroux: This is the baby photo of three stars forming 750 light-years from Earth https:\/\/t.co\/gMdEfafgu1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/gMdEfafgu1",
        "expanded_url" : "http:\/\/fb.me\/srvIyldt",
        "display_url" : "fb.me\/srvIyldt"
      } ]
    },
    "geo" : { },
    "id_str" : "791350356735209473",
    "text" : "This is the baby photo of three stars forming 750 light-years from Earth https:\/\/t.co\/gMdEfafgu1",
    "id" : 791350356735209473,
    "created_at" : "2016-10-26 18:46:42 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 791352724759650304,
  "created_at" : "2016-10-26 18:56:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mrs. Fitz",
      "screen_name" : "PFitzpa",
      "indices" : [ 3, 11 ],
      "id_str" : "1292849216",
      "id" : 1292849216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791338580002111488",
  "text" : "RT @PFitzpa: I reject all mongering unless it involves cheese.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788942199270445056",
    "text" : "I reject all mongering unless it involves cheese.",
    "id" : 788942199270445056,
    "created_at" : "2016-10-20 03:17:32 +0000",
    "user" : {
      "name" : "Mrs. Fitz",
      "screen_name" : "PFitzpa",
      "protected" : false,
      "id_str" : "1292849216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/834610615327010816\/vzFkaoSE_normal.jpg",
      "id" : 1292849216,
      "verified" : false
    }
  },
  "id" : 791338580002111488,
  "created_at" : "2016-10-26 17:59:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/791338529699852289\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/spoPeaX11U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvtmMTSWIAAgNdc.jpg",
      "id_str" : "791338521055338496",
      "id" : 791338521055338496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvtmMTSWIAAgNdc.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/spoPeaX11U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791338529699852289",
  "text" : "Had a cinnamon pretzel w\/ cheese before this https:\/\/t.co\/spoPeaX11U",
  "id" : 791338529699852289,
  "created_at" : "2016-10-26 17:59:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "htng",
      "screen_name" : "htng",
      "indices" : [ 3, 8 ],
      "id_str" : "28227547",
      "id" : 28227547
    }, {
      "name" : "Jonathan MacDonald",
      "screen_name" : "jmacdonald",
      "indices" : [ 80, 91 ],
      "id_str" : "12427412",
      "id" : 12427412
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/htng\/status\/791186523731402752\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/1NBcLU5Hyq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvrb8NKWgAADo29.jpg",
      "id_str" : "791186511928655872",
      "id" : 791186511928655872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvrb8NKWgAADo29.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/1NBcLU5Hyq"
    } ],
    "hashtags" : [ {
      "text" : "HTNG2016",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791316339965169665",
  "text" : "RT @htng: How to drive game-changing innovation in an age of perpetual change - @jmacdonald #HTNG2016 https:\/\/t.co\/1NBcLU5Hyq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan MacDonald",
        "screen_name" : "jmacdonald",
        "indices" : [ 70, 81 ],
        "id_str" : "12427412",
        "id" : 12427412
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/htng\/status\/791186523731402752\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/1NBcLU5Hyq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvrb8NKWgAADo29.jpg",
        "id_str" : "791186511928655872",
        "id" : 791186511928655872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvrb8NKWgAADo29.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/1NBcLU5Hyq"
      } ],
      "hashtags" : [ {
        "text" : "HTNG2016",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791186523731402752",
    "text" : "How to drive game-changing innovation in an age of perpetual change - @jmacdonald #HTNG2016 https:\/\/t.co\/1NBcLU5Hyq",
    "id" : 791186523731402752,
    "created_at" : "2016-10-26 07:55:41 +0000",
    "user" : {
      "name" : "htng",
      "screen_name" : "htng",
      "protected" : false,
      "id_str" : "28227547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877943514096685057\/40XA1cGi_normal.jpg",
      "id" : 28227547,
      "verified" : false
    }
  },
  "id" : 791316339965169665,
  "created_at" : "2016-10-26 16:31:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "indices" : [ 3, 15 ],
      "id_str" : "491350825",
      "id" : 491350825
    }, {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 45, 55 ],
      "id_str" : "4248211",
      "id" : 4248211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VP",
      "indices" : [ 68, 71 ]
    }, {
      "text" : "policyMAKERS",
      "indices" : [ 97, 110 ]
    }, {
      "text" : "Election2016",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/cVzJFt1yS1",
      "expanded_url" : "http:\/\/aol.it\/2dJMLVd",
      "display_url" : "aol.it\/2dJMLVd"
    } ]
  },
  "geo" : { },
  "id_str" : "791316257568153600",
  "text" : "RT @MAKERSwomen: Have you heard? 35 year old @mindyfinn wants to be #VP: https:\/\/t.co\/cVzJFt1yS1 #policyMAKERS #Election2016 https:\/\/t.co\/e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mindy Finn",
        "screen_name" : "mindyfinn",
        "indices" : [ 28, 38 ],
        "id_str" : "4248211",
        "id" : 4248211
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MAKERSwomen\/status\/790732117298733056\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/eetUOU7nLY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvk-qvoUIAItfQM.jpg",
        "id_str" : "790732113641218050",
        "id" : 790732113641218050,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvk-qvoUIAItfQM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eetUOU7nLY"
      } ],
      "hashtags" : [ {
        "text" : "VP",
        "indices" : [ 51, 54 ]
      }, {
        "text" : "policyMAKERS",
        "indices" : [ 80, 93 ]
      }, {
        "text" : "Election2016",
        "indices" : [ 94, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/cVzJFt1yS1",
        "expanded_url" : "http:\/\/aol.it\/2dJMLVd",
        "display_url" : "aol.it\/2dJMLVd"
      } ]
    },
    "geo" : { },
    "id_str" : "790732117298733056",
    "text" : "Have you heard? 35 year old @mindyfinn wants to be #VP: https:\/\/t.co\/cVzJFt1yS1 #policyMAKERS #Election2016 https:\/\/t.co\/eetUOU7nLY",
    "id" : 790732117298733056,
    "created_at" : "2016-10-25 01:50:02 +0000",
    "user" : {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "protected" : false,
      "id_str" : "491350825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880873229467897856\/d-_nHVcA_normal.jpg",
      "id" : 491350825,
      "verified" : true
    }
  },
  "id" : 791316257568153600,
  "created_at" : "2016-10-26 16:31:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "ragdus",
      "indices" : [ 3, 10 ],
      "id_str" : "375289223",
      "id" : 375289223
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 12, 26 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315673112870913",
  "text" : "RT @ragdus: @Evan_McMullin True enough but what do you do when one party's electorate doesn't want honest &amp; wise? They're picking the leade\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 0, 14 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791105688961376256",
    "geo" : { },
    "id_str" : "791110574985900032",
    "in_reply_to_user_id" : 1051396218,
    "text" : "@Evan_McMullin True enough but what do you do when one party's electorate doesn't want honest &amp; wise? They're picking the leaders they want.",
    "id" : 791110574985900032,
    "in_reply_to_status_id" : 791105688961376256,
    "created_at" : "2016-10-26 02:53:53 +0000",
    "in_reply_to_screen_name" : "Evan_McMullin",
    "in_reply_to_user_id_str" : "1051396218",
    "user" : {
      "name" : "Eric",
      "screen_name" : "ragdus",
      "protected" : false,
      "id_str" : "375289223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840213757641052160\/pTWBOoAt_normal.jpg",
      "id" : 375289223,
      "verified" : false
    }
  },
  "id" : 791315673112870913,
  "created_at" : "2016-10-26 16:28:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Monica Crowley",
      "screen_name" : "MonicaCrowley",
      "indices" : [ 18, 32 ],
      "id_str" : "166990746",
      "id" : 166990746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315531706097664",
  "text" : "RT @seanhannity: .@MonicaCrowley: \"The system is rigged...you don't have a fair, independent, impartial press which is interested in above\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Crowley",
        "screen_name" : "MonicaCrowley",
        "indices" : [ 1, 15 ],
        "id_str" : "166990746",
        "id" : 166990746
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791104815896166404",
    "text" : ".@MonicaCrowley: \"The system is rigged...you don't have a fair, independent, impartial press which is interested in above all, the truth.\"",
    "id" : 791104815896166404,
    "created_at" : "2016-10-26 02:31:00 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 791315531706097664,
  "created_at" : "2016-10-26 16:28:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chow",
      "screen_name" : "JohnChow",
      "indices" : [ 3, 12 ],
      "id_str" : "14290180",
      "id" : 14290180
    }, {
      "name" : "John Chow",
      "screen_name" : "JohnChow",
      "indices" : [ 107, 116 ],
      "id_str" : "14290180",
      "id" : 14290180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZDspySI9lu",
      "expanded_url" : "http:\/\/www.johnchow.com\/adcombo-offers-a-fresh-take-on-cpa-marketing\/",
      "display_url" : "johnchow.com\/adcombo-offers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791315457118732288",
  "text" : "RT @JohnChow: AdCombo Offers a Fresh Take on CPA Marketing | John Chow dot Com https:\/\/t.co\/ZDspySI9lu via @johnchow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Chow",
        "screen_name" : "JohnChow",
        "indices" : [ 93, 102 ],
        "id_str" : "14290180",
        "id" : 14290180
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/ZDspySI9lu",
        "expanded_url" : "http:\/\/www.johnchow.com\/adcombo-offers-a-fresh-take-on-cpa-marketing\/",
        "display_url" : "johnchow.com\/adcombo-offers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791313828705210368",
    "text" : "AdCombo Offers a Fresh Take on CPA Marketing | John Chow dot Com https:\/\/t.co\/ZDspySI9lu via @johnchow",
    "id" : 791313828705210368,
    "created_at" : "2016-10-26 16:21:33 +0000",
    "user" : {
      "name" : "John Chow",
      "screen_name" : "JohnChow",
      "protected" : false,
      "id_str" : "14290180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541735628\/johnchow-headshot_normal.jpg",
      "id" : 14290180,
      "verified" : false
    }
  },
  "id" : 791315457118732288,
  "created_at" : "2016-10-26 16:28:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315413217017857",
  "text" : "RT @scrowder: \"FREEDOM OF CHOICE\" now actually means \"freedom to steal your tax dollars to fund my abortion\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791073278433558529",
    "text" : "\"FREEDOM OF CHOICE\" now actually means \"freedom to steal your tax dollars to fund my abortion\"",
    "id" : 791073278433558529,
    "created_at" : "2016-10-26 00:25:41 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 791315413217017857,
  "created_at" : "2016-10-26 16:27:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315388017602560",
  "text" : "RT @KassyDillon: \"Free speech exists for ideas we hate. You don't need it for speech people like.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791072581365460992",
    "text" : "\"Free speech exists for ideas we hate. You don't need it for speech people like.\"",
    "id" : 791072581365460992,
    "created_at" : "2016-10-26 00:22:55 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 791315388017602560,
  "created_at" : "2016-10-26 16:27:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhuigi Villasenor",
      "screen_name" : "Rhuigi",
      "indices" : [ 3, 10 ],
      "id_str" : "184777871",
      "id" : 184777871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315347743895552",
  "text" : "RT @Rhuigi: Everlasting flow of ideas, I can't be moved.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791074194641543168",
    "text" : "Everlasting flow of ideas, I can't be moved.",
    "id" : 791074194641543168,
    "created_at" : "2016-10-26 00:29:20 +0000",
    "user" : {
      "name" : "Rhuigi Villasenor",
      "screen_name" : "Rhuigi",
      "protected" : false,
      "id_str" : "184777871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803444431923933185\/Eia20ygx_normal.jpg",
      "id" : 184777871,
      "verified" : false
    }
  },
  "id" : 791315347743895552,
  "created_at" : "2016-10-26 16:27:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/lj8lfb5gCt",
      "expanded_url" : "http:\/\/ow.ly\/DZQJ305nxdi",
      "display_url" : "ow.ly\/DZQJ305nxdi"
    } ]
  },
  "geo" : { },
  "id_str" : "791315319033847808",
  "text" : "RT @analyticbridge: What People REALLY Do with the Internet of Things and Big Data https:\/\/t.co\/lj8lfb5gCt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/lj8lfb5gCt",
        "expanded_url" : "http:\/\/ow.ly\/DZQJ305nxdi",
        "display_url" : "ow.ly\/DZQJ305nxdi"
      } ]
    },
    "geo" : { },
    "id_str" : "791078228693745664",
    "text" : "What People REALLY Do with the Internet of Things and Big Data https:\/\/t.co\/lj8lfb5gCt",
    "id" : 791078228693745664,
    "created_at" : "2016-10-26 00:45:21 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 791315319033847808,
  "created_at" : "2016-10-26 16:27:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/791077414017335296\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bMGHyveMxx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp4ttsWEAAuBFF.jpg",
      "id_str" : "791077411311980544",
      "id" : 791077411311980544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp4ttsWEAAuBFF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/bMGHyveMxx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315294354563072",
  "text" : "RT @rockindigo: 80's and 90's kids will understand... https:\/\/t.co\/bMGHyveMxx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/791077414017335296\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/bMGHyveMxx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp4ttsWEAAuBFF.jpg",
        "id_str" : "791077411311980544",
        "id" : 791077411311980544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp4ttsWEAAuBFF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/bMGHyveMxx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791077414017335296",
    "text" : "80's and 90's kids will understand... https:\/\/t.co\/bMGHyveMxx",
    "id" : 791077414017335296,
    "created_at" : "2016-10-26 00:42:07 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 791315294354563072,
  "created_at" : "2016-10-26 16:27:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LWC",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/d7tD5Dyuzo",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=dhtphabTpIs",
      "display_url" : "youtube.com\/watch?v=dhtpha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791315245214171136",
  "text" : "RT @scrowder: Rebutting Samantha Bee's abortions lies with stats.. and facts.. and principles. #LWC &gt;&gt; https:\/\/t.co\/d7tD5Dyuzo https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/791075681132249088\/video\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/RiLIuvXffP",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791075624639225857\/pu\/img\/5p0jbDEhchiV71f9.jpg",
        "id_str" : "791075624639225857",
        "id" : 791075624639225857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/791075624639225857\/pu\/img\/5p0jbDEhchiV71f9.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RiLIuvXffP"
      } ],
      "hashtags" : [ {
        "text" : "LWC",
        "indices" : [ 81, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/d7tD5Dyuzo",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=dhtphabTpIs",
        "display_url" : "youtube.com\/watch?v=dhtpha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791075681132249088",
    "text" : "Rebutting Samantha Bee's abortions lies with stats.. and facts.. and principles. #LWC &gt;&gt; https:\/\/t.co\/d7tD5Dyuzo https:\/\/t.co\/RiLIuvXffP",
    "id" : 791075681132249088,
    "created_at" : "2016-10-26 00:35:14 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 791315245214171136,
  "created_at" : "2016-10-26 16:27:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/hpgTKjXp4g",
      "expanded_url" : "http:\/\/ow.ly\/YZHz305uEHd",
      "display_url" : "ow.ly\/YZHz305uEHd"
    } ]
  },
  "geo" : { },
  "id_str" : "791315218060218368",
  "text" : "RT @analyticbridge: R in your browser https:\/\/t.co\/hpgTKjXp4g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/hpgTKjXp4g",
        "expanded_url" : "http:\/\/ow.ly\/YZHz305uEHd",
        "display_url" : "ow.ly\/YZHz305uEHd"
      } ]
    },
    "geo" : { },
    "id_str" : "791074543951642624",
    "text" : "R in your browser https:\/\/t.co\/hpgTKjXp4g",
    "id" : 791074543951642624,
    "created_at" : "2016-10-26 00:30:43 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 791315218060218368,
  "created_at" : "2016-10-26 16:27:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/791072677532360704\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/rrl2wfF3JA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp0ZrzUAAA4eYM.jpg",
      "id_str" : "791072669160439808",
      "id" : 791072669160439808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp0ZrzUAAA4eYM.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/rrl2wfF3JA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315146358591488",
  "text" : "RT @ijustine: IM HAPPY https:\/\/t.co\/rrl2wfF3JA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/791072677532360704\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/rrl2wfF3JA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp0ZrzUAAA4eYM.jpg",
        "id_str" : "791072669160439808",
        "id" : 791072669160439808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp0ZrzUAAA4eYM.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/rrl2wfF3JA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "791072677532360704",
    "text" : "IM HAPPY https:\/\/t.co\/rrl2wfF3JA",
    "id" : 791072677532360704,
    "created_at" : "2016-10-26 00:23:18 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873056728606097408\/KmXQNIx6_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 791315146358591488,
  "created_at" : "2016-10-26 16:26:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin",
      "screen_name" : "addictwithaptx",
      "indices" : [ 3, 18 ],
      "id_str" : "1928561970",
      "id" : 1928561970
    }, {
      "name" : "22 days",
      "screen_name" : "jacksfilms",
      "indices" : [ 20, 31 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791315046139854852",
  "text" : "RT @addictwithaptx: @jacksfilms too soon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "22 days",
        "screen_name" : "jacksfilms",
        "indices" : [ 0, 11 ],
        "id_str" : "9989862",
        "id" : 9989862
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "791071492087750656",
    "geo" : { },
    "id_str" : "791071607682924544",
    "in_reply_to_user_id" : 9989862,
    "text" : "@jacksfilms too soon",
    "id" : 791071607682924544,
    "in_reply_to_status_id" : 791071492087750656,
    "created_at" : "2016-10-26 00:19:03 +0000",
    "in_reply_to_screen_name" : "jacksfilms",
    "in_reply_to_user_id_str" : "9989862",
    "user" : {
      "name" : "erin",
      "screen_name" : "addictwithaptx",
      "protected" : false,
      "id_str" : "1928561970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879494603631710208\/e2l6qzhZ_normal.jpg",
      "id" : 1928561970,
      "verified" : false
    }
  },
  "id" : 791315046139854852,
  "created_at" : "2016-10-26 16:26:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate \uD83E\uDD84",
      "screen_name" : "AlwaysJLover",
      "indices" : [ 0, 13 ],
      "id_str" : "962141971",
      "id" : 962141971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791071284541198352",
  "geo" : { },
  "id_str" : "791314891365842944",
  "in_reply_to_user_id" : 150060272,
  "text" : "@AlwaysJLover Never back down, things get better",
  "id" : 791314891365842944,
  "in_reply_to_status_id" : 791071284541198352,
  "created_at" : "2016-10-26 16:25:46 +0000",
  "in_reply_to_screen_name" : "forbexana",
  "in_reply_to_user_id_str" : "150060272",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/791080886905167872\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/TBoPepzlwn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp7328UEAAUqA0.jpg",
      "id_str" : "791080884128452608",
      "id" : 791080884128452608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp7328UEAAUqA0.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TBoPepzlwn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/7W0E8yDojK",
      "expanded_url" : "http:\/\/holykaw.alltop.com\/18-fresh-fall-recipes-sweet-potatoes?gk3",
      "display_url" : "holykaw.alltop.com\/18-fresh-fall-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "791314713544126466",
  "text" : "RT @GuyKawasaki: 18 fresh fall recipes for sweet potatoes https:\/\/t.co\/7W0E8yDojK https:\/\/t.co\/TBoPepzlwn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/alltop.com\/\" rel=\"nofollow\"\u003EAlltop Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/791080886905167872\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/TBoPepzlwn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cvp7328UEAAUqA0.jpg",
        "id_str" : "791080884128452608",
        "id" : 791080884128452608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cvp7328UEAAUqA0.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TBoPepzlwn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/7W0E8yDojK",
        "expanded_url" : "http:\/\/holykaw.alltop.com\/18-fresh-fall-recipes-sweet-potatoes?gk3",
        "display_url" : "holykaw.alltop.com\/18-fresh-fall-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791080886905167872",
    "text" : "18 fresh fall recipes for sweet potatoes https:\/\/t.co\/7W0E8yDojK https:\/\/t.co\/TBoPepzlwn",
    "id" : 791080886905167872,
    "created_at" : "2016-10-26 00:55:55 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 791314713544126466,
  "created_at" : "2016-10-26 16:25:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/osXn7i4TCY",
      "expanded_url" : "http:\/\/fb.me\/4rQurwvnk",
      "display_url" : "fb.me\/4rQurwvnk"
    } ]
  },
  "geo" : { },
  "id_str" : "791314664529465344",
  "text" : "RT @EmperorDarroux: Josh Norman's concussion perfectly embodies two of the NFL's biggest flaws https:\/\/t.co\/osXn7i4TCY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/osXn7i4TCY",
        "expanded_url" : "http:\/\/fb.me\/4rQurwvnk",
        "display_url" : "fb.me\/4rQurwvnk"
      } ]
    },
    "geo" : { },
    "id_str" : "791080823084707841",
    "text" : "Josh Norman's concussion perfectly embodies two of the NFL's biggest flaws https:\/\/t.co\/osXn7i4TCY",
    "id" : 791080823084707841,
    "created_at" : "2016-10-26 00:55:40 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 791314664529465344,
  "created_at" : "2016-10-26 16:24:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "indices" : [ 3, 19 ],
      "id_str" : "18992010",
      "id" : 18992010
    }, {
      "name" : "Goucher College",
      "screen_name" : "gouchercollege",
      "indices" : [ 122, 137 ],
      "id_str" : "25119699",
      "id" : 25119699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791314437785411584",
  "text" : "RT @victorricciardi: I\u2019m honored to be accepted to the NFEC\u2019s Personal Finance Speakers Association as a Featured Speaker @gouchercollege h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Goucher College",
        "screen_name" : "gouchercollege",
        "indices" : [ 101, 116 ],
        "id_str" : "25119699",
        "id" : 25119699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ti3meWcrGH",
        "expanded_url" : "http:\/\/www.financialeducatorscouncil.org\/Victor-Ricciardi",
        "display_url" : "financialeducatorscouncil.org\/Victor-Ricciar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "791079579964276736",
    "text" : "I\u2019m honored to be accepted to the NFEC\u2019s Personal Finance Speakers Association as a Featured Speaker @gouchercollege https:\/\/t.co\/Ti3meWcrGH",
    "id" : 791079579964276736,
    "created_at" : "2016-10-26 00:50:44 +0000",
    "user" : {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "protected" : false,
      "id_str" : "18992010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566693508296085504\/-v5kzmcw_normal.jpeg",
      "id" : 18992010,
      "verified" : false
    }
  },
  "id" : 791314437785411584,
  "created_at" : "2016-10-26 16:23:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791314306751168512",
  "text" : "The real world purposely sometimes just strikes you hard, but many times I always get back up",
  "id" : 791314306751168512,
  "created_at" : "2016-10-26 16:23:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Wentz",
      "screen_name" : "LarryWentz",
      "indices" : [ 3, 14 ],
      "id_str" : "21836409",
      "id" : 21836409
    }, {
      "name" : "DocSend",
      "screen_name" : "DocSend",
      "indices" : [ 84, 92 ],
      "id_str" : "1450095528",
      "id" : 1450095528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "B2B",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/ntYuUbEfLT",
      "expanded_url" : "https:\/\/blog.docsend.com\/best-b2b-case-study-examples\/",
      "display_url" : "blog.docsend.com\/best-b2b-case-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790965629331378180",
  "text" : "RT @LarryWentz: 150 of the Best B2B Case Study Examples https:\/\/t.co\/ntYuUbEfLT via @DocSend #B2B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DocSend",
        "screen_name" : "DocSend",
        "indices" : [ 68, 76 ],
        "id_str" : "1450095528",
        "id" : 1450095528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "B2B",
        "indices" : [ 77, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/ntYuUbEfLT",
        "expanded_url" : "https:\/\/blog.docsend.com\/best-b2b-case-study-examples\/",
        "display_url" : "blog.docsend.com\/best-b2b-case-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790965082717032456",
    "text" : "150 of the Best B2B Case Study Examples https:\/\/t.co\/ntYuUbEfLT via @DocSend #B2B",
    "id" : 790965082717032456,
    "created_at" : "2016-10-25 17:15:45 +0000",
    "user" : {
      "name" : "Larry Wentz",
      "screen_name" : "LarryWentz",
      "protected" : false,
      "id_str" : "21836409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466445256028717056\/2tIK9N6Z_normal.jpeg",
      "id" : 21836409,
      "verified" : false
    }
  },
  "id" : 790965629331378180,
  "created_at" : "2016-10-25 17:17:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "indices" : [ 3, 14 ],
      "id_str" : "242435607",
      "id" : 242435607
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/hQ2Uug5vPc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSpqSVYAAEbdD.jpg",
      "id_str" : "790965191492067328",
      "id" : 790965191492067328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSpqSVYAAEbdD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 761
      } ],
      "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/hQ2Uug5vPc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSp2gUsAAVEJC.jpg",
      "id_str" : "790965194771968000",
      "id" : 790965194771968000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSp2gUsAAVEJC.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/hQ2Uug5vPc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSp2hUkAA8aCM.jpg",
      "id_str" : "790965194776154112",
      "id" : 790965194776154112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSp2hUkAA8aCM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790965492743798784",
  "text" : "RT @Anba_Ermia: \u062F\u064A\u0631 \u0627\u0644\u0634\u0647\u064A\u062F \u0627\u0644\u0639\u0638\u064A\u0645 \u0645\u0627\u0631 \u0645\u064A\u0646\u0627 \u0628\u0645\u0631\u064A\u0648\u0637-\u0661 https:\/\/t.co\/hQ2Uug5vPc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/hQ2Uug5vPc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSpqSVYAAEbdD.jpg",
        "id_str" : "790965191492067328",
        "id" : 790965191492067328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSpqSVYAAEbdD.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 761
        } ],
        "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/hQ2Uug5vPc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSp2gUsAAVEJC.jpg",
        "id_str" : "790965194771968000",
        "id" : 790965194771968000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSp2gUsAAVEJC.jpg",
        "sizes" : [ {
          "h" : 397,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/790965203173117952\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/hQ2Uug5vPc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvoSp2hUkAA8aCM.jpg",
        "id_str" : "790965194776154112",
        "id" : 790965194776154112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvoSp2hUkAA8aCM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/hQ2Uug5vPc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790965203173117952",
    "text" : "\u062F\u064A\u0631 \u0627\u0644\u0634\u0647\u064A\u062F \u0627\u0644\u0639\u0638\u064A\u0645 \u0645\u0627\u0631 \u0645\u064A\u0646\u0627 \u0628\u0645\u0631\u064A\u0648\u0637-\u0661 https:\/\/t.co\/hQ2Uug5vPc",
    "id" : 790965203173117952,
    "created_at" : "2016-10-25 17:16:14 +0000",
    "user" : {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "protected" : false,
      "id_str" : "242435607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580148862\/4cf7cba83bbd8d24e3a9a21f82ebc51e_normal.jpeg",
      "id" : 242435607,
      "verified" : false
    }
  },
  "id" : 790965492743798784,
  "created_at" : "2016-10-25 17:17:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790965363504738308",
  "text" : "RT @TeamMcMullin: \"...there is a yearning for something different, an earnest belief in working to make the country better.\" https:\/\/t.co\/E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/EOoW4rNiJI",
        "expanded_url" : "https:\/\/www.bloomberg.com\/view\/articles\/2016-10-25\/i-saw-the-future-of-politics-at-an-evan-mcmullin-rally",
        "display_url" : "bloomberg.com\/view\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790922917395570688",
    "text" : "\"...there is a yearning for something different, an earnest belief in working to make the country better.\" https:\/\/t.co\/EOoW4rNiJI",
    "id" : 790922917395570688,
    "created_at" : "2016-10-25 14:28:12 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 790965363504738308,
  "created_at" : "2016-10-25 17:16:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790965263801917440",
  "text" : "Some people remember me after years of not seeing me then they don't wanna hang out",
  "id" : 790965263801917440,
  "created_at" : "2016-10-25 17:16:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790599688126918656",
  "text" : "Life can kick you hard some times",
  "id" : 790599688126918656,
  "created_at" : "2016-10-24 17:03:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 3, 13 ],
      "id_str" : "17454769",
      "id" : 17454769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/T0YaU5GAff",
      "expanded_url" : "http:\/\/ow.ly\/YuLz305s4HV",
      "display_url" : "ow.ly\/YuLz305s4HV"
    } ]
  },
  "geo" : { },
  "id_str" : "790338776748875777",
  "text" : "RT @glennbeck: Miracle Baby Was Born Twice: Removed From the Womb to Correct Tumor Then Returned https:\/\/t.co\/T0YaU5GAff https:\/\/t.co\/nhNsl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/glennbeck\/status\/790324447827881984\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/nhNslQEkN4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfL5VsWEAUV37S.jpg",
        "id_str" : "790324445562933253",
        "id" : 790324445562933253,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfL5VsWEAUV37S.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/nhNslQEkN4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/T0YaU5GAff",
        "expanded_url" : "http:\/\/ow.ly\/YuLz305s4HV",
        "display_url" : "ow.ly\/YuLz305s4HV"
      } ]
    },
    "geo" : { },
    "id_str" : "790324447827881984",
    "text" : "Miracle Baby Was Born Twice: Removed From the Womb to Correct Tumor Then Returned https:\/\/t.co\/T0YaU5GAff https:\/\/t.co\/nhNslQEkN4",
    "id" : 790324447827881984,
    "created_at" : "2016-10-23 22:50:06 +0000",
    "user" : {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "protected" : false,
      "id_str" : "17454769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535418462491791361\/NZmf8ftP_normal.jpeg",
      "id" : 17454769,
      "verified" : true
    }
  },
  "id" : 790338776748875777,
  "created_at" : "2016-10-23 23:47:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kee Yaw",
      "screen_name" : "emaly_suire",
      "indices" : [ 3, 15 ],
      "id_str" : "2170842290",
      "id" : 2170842290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790338443985379333",
  "text" : "RT @emaly_suire: This fog is thicker than a snicker",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788716216529457152",
    "text" : "This fog is thicker than a snicker",
    "id" : 788716216529457152,
    "created_at" : "2016-10-19 12:19:34 +0000",
    "user" : {
      "name" : "Kee Yaw",
      "screen_name" : "emaly_suire",
      "protected" : false,
      "id_str" : "2170842290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878752770576326656\/lhOvbbUd_normal.jpg",
      "id" : 2170842290,
      "verified" : false
    }
  },
  "id" : 790338443985379333,
  "created_at" : "2016-10-23 23:45:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790337781495017472",
  "text" : "RT @HelloRyanHolmes: Fall is here!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789965951114489856",
    "text" : "Fall is here!",
    "id" : 789965951114489856,
    "created_at" : "2016-10-22 23:05:34 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880486625746223106\/uqol0phE_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 790337781495017472,
  "created_at" : "2016-10-23 23:43:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/790320984402325504\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/gZweX9wiOF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfIvusWAAAXf2U.jpg",
      "id_str" : "790320981940240384",
      "id" : 790320981940240384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfIvusWAAAXf2U.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/gZweX9wiOF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/kcEjz6Yr9I",
      "expanded_url" : "http:\/\/engt.co\/2eHUqhD",
      "display_url" : "engt.co\/2eHUqhD"
    } ]
  },
  "geo" : { },
  "id_str" : "790337264014417920",
  "text" : "RT @engadget: iPod marks its 15th birthday in a changed world https:\/\/t.co\/kcEjz6Yr9I https:\/\/t.co\/gZweX9wiOF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/790320984402325504\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/gZweX9wiOF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfIvusWAAAXf2U.jpg",
        "id_str" : "790320981940240384",
        "id" : 790320981940240384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfIvusWAAAXf2U.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/gZweX9wiOF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/kcEjz6Yr9I",
        "expanded_url" : "http:\/\/engt.co\/2eHUqhD",
        "display_url" : "engt.co\/2eHUqhD"
      } ]
    },
    "geo" : { },
    "id_str" : "790320984402325504",
    "text" : "iPod marks its 15th birthday in a changed world https:\/\/t.co\/kcEjz6Yr9I https:\/\/t.co\/gZweX9wiOF",
    "id" : 790320984402325504,
    "created_at" : "2016-10-23 22:36:20 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 790337264014417920,
  "created_at" : "2016-10-23 23:41:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Winsoar",
      "screen_name" : "winsoar",
      "indices" : [ 3, 11 ],
      "id_str" : "15406575",
      "id" : 15406575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790337222109073408",
  "text" : "RT @winsoar: Life is about making an impact, not making an income. \u2013Kevin Kruse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790327287384276992",
    "text" : "Life is about making an impact, not making an income. \u2013Kevin Kruse",
    "id" : 790327287384276992,
    "created_at" : "2016-10-23 23:01:23 +0000",
    "user" : {
      "name" : "James Winsoar",
      "screen_name" : "winsoar",
      "protected" : false,
      "id_str" : "15406575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879992259554541568\/6DjAyBq5_normal.jpg",
      "id" : 15406575,
      "verified" : false
    }
  },
  "id" : 790337222109073408,
  "created_at" : "2016-10-23 23:40:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/KIpsm1Vk0J",
      "expanded_url" : "http:\/\/ow.ly\/Xp27305jkpQ",
      "display_url" : "ow.ly\/Xp27305jkpQ"
    } ]
  },
  "geo" : { },
  "id_str" : "790337195810750464",
  "text" : "RT @analyticbridge: A New Breed of Mathematics: Topology https:\/\/t.co\/KIpsm1Vk0J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/KIpsm1Vk0J",
        "expanded_url" : "http:\/\/ow.ly\/Xp27305jkpQ",
        "display_url" : "ow.ly\/Xp27305jkpQ"
      } ]
    },
    "geo" : { },
    "id_str" : "790327250616979457",
    "text" : "A New Breed of Mathematics: Topology https:\/\/t.co\/KIpsm1Vk0J",
    "id" : 790327250616979457,
    "created_at" : "2016-10-23 23:01:14 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 790337195810750464,
  "created_at" : "2016-10-23 23:40:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/xAp1KFnhrh",
      "expanded_url" : "http:\/\/ow.ly\/DKDQ305jkpR",
      "display_url" : "ow.ly\/DKDQ305jkpR"
    } ]
  },
  "geo" : { },
  "id_str" : "790337162042494976",
  "text" : "RT @analyticbridge: Time Series with Monte Carlo Simulation https:\/\/t.co\/xAp1KFnhrh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/xAp1KFnhrh",
        "expanded_url" : "http:\/\/ow.ly\/DKDQ305jkpR",
        "display_url" : "ow.ly\/DKDQ305jkpR"
      } ]
    },
    "geo" : { },
    "id_str" : "790334667220250628",
    "text" : "Time Series with Monte Carlo Simulation https:\/\/t.co\/xAp1KFnhrh",
    "id" : 790334667220250628,
    "created_at" : "2016-10-23 23:30:43 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 790337162042494976,
  "created_at" : "2016-10-23 23:40:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tala Raassi",
      "screen_name" : "TalaRaassi",
      "indices" : [ 0, 11 ],
      "id_str" : "29903342",
      "id" : 29903342
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 12, 27 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788925367339941892",
  "geo" : { },
  "id_str" : "790336946987950080",
  "in_reply_to_user_id" : 29903342,
  "text" : "@TalaRaassi @HillaryClinton Please don't be :(",
  "id" : 790336946987950080,
  "in_reply_to_status_id" : 788925367339941892,
  "created_at" : "2016-10-23 23:39:46 +0000",
  "in_reply_to_screen_name" : "TalaRaassi",
  "in_reply_to_user_id_str" : "29903342",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tala Raassi",
      "screen_name" : "TalaRaassi",
      "indices" : [ 3, 14 ],
      "id_str" : "29903342",
      "id" : 29903342
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quoteoftheday",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790336792792752128",
  "text" : "RT @TalaRaassi: Do not get upset with people or situations, both are powerless without your reaction \uD83D\uDCAA\uD83C\uDFFC#quoteoftheday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quoteoftheday",
        "indices" : [ 87, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790196779165810689",
    "text" : "Do not get upset with people or situations, both are powerless without your reaction \uD83D\uDCAA\uD83C\uDFFC#quoteoftheday",
    "id" : 790196779165810689,
    "created_at" : "2016-10-23 14:22:47 +0000",
    "user" : {
      "name" : "Tala Raassi",
      "screen_name" : "TalaRaassi",
      "protected" : false,
      "id_str" : "29903342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730515518558486529\/P-59iKwp_normal.jpg",
      "id" : 29903342,
      "verified" : false
    }
  },
  "id" : 790336792792752128,
  "created_at" : "2016-10-23 23:39:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "indices" : [ 3, 12 ],
      "id_str" : "40369362",
      "id" : 40369362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motorcycle",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "MOTORESS",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/swfbA7ORRb",
      "expanded_url" : "http:\/\/ow.ly\/4Rbt305kTUe",
      "display_url" : "ow.ly\/4Rbt305kTUe"
    } ]
  },
  "geo" : { },
  "id_str" : "790336629164564480",
  "text" : "RT @MOTORESS: Ever wonder what your #motorcycle tire sidewall is saying to you?\nHere's the translation https:\/\/t.co\/swfbA7ORRb #MOTORESS ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MOTORESS\/status\/790314424619982848\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/GSr8SJ4gVS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfCx5_WEAAl_QN.jpg",
        "id_str" : "790314422262697984",
        "id" : 790314422262697984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfCx5_WEAAl_QN.jpg",
        "sizes" : [ {
          "h" : 349,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/GSr8SJ4gVS"
      } ],
      "hashtags" : [ {
        "text" : "motorcycle",
        "indices" : [ 22, 33 ]
      }, {
        "text" : "MOTORESS",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/swfbA7ORRb",
        "expanded_url" : "http:\/\/ow.ly\/4Rbt305kTUe",
        "display_url" : "ow.ly\/4Rbt305kTUe"
      } ]
    },
    "geo" : { },
    "id_str" : "790314424619982848",
    "text" : "Ever wonder what your #motorcycle tire sidewall is saying to you?\nHere's the translation https:\/\/t.co\/swfbA7ORRb #MOTORESS https:\/\/t.co\/GSr8SJ4gVS",
    "id" : 790314424619982848,
    "created_at" : "2016-10-23 22:10:16 +0000",
    "user" : {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "protected" : false,
      "id_str" : "40369362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408819496521729\/vGa13GuH_normal.jpg",
      "id" : 40369362,
      "verified" : false
    }
  },
  "id" : 790336629164564480,
  "created_at" : "2016-10-23 23:38:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zj0jkSN8eX",
      "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=96&edit=0&userid=1",
      "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "790336461098721280",
  "text" : "RT @BestGamezUp: 10 Consoles That Failed Too Hard For Anyone to Even Notice Them https:\/\/t.co\/zj0jkSN8eX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/zj0jkSN8eX",
        "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=96&edit=0&userid=1",
        "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "790313108271144960",
    "text" : "10 Consoles That Failed Too Hard For Anyone to Even Notice Them https:\/\/t.co\/zj0jkSN8eX",
    "id" : 790313108271144960,
    "created_at" : "2016-10-23 22:05:02 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 790336461098721280,
  "created_at" : "2016-10-23 23:37:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/gPXeABlTsi",
      "expanded_url" : "http:\/\/ow.ly\/Z8At305jkpO",
      "display_url" : "ow.ly\/Z8At305jkpO"
    } ]
  },
  "geo" : { },
  "id_str" : "790336287618109441",
  "text" : "RT @analyticbridge: Unlocking Personal Data https:\/\/t.co\/gPXeABlTsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/gPXeABlTsi",
        "expanded_url" : "http:\/\/ow.ly\/Z8At305jkpO",
        "display_url" : "ow.ly\/Z8At305jkpO"
      } ]
    },
    "geo" : { },
    "id_str" : "790312135008067585",
    "text" : "Unlocking Personal Data https:\/\/t.co\/gPXeABlTsi",
    "id" : 790312135008067585,
    "created_at" : "2016-10-23 22:01:10 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 790336287618109441,
  "created_at" : "2016-10-23 23:37:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790336173671522305",
  "text" : "RT @lorenridinger: \u201CYou make mistakes, mistakes don't make you\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790311951196909573",
    "text" : "\u201CYou make mistakes, mistakes don't make you\u201D",
    "id" : 790311951196909573,
    "created_at" : "2016-10-23 22:00:27 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 790336173671522305,
  "created_at" : "2016-10-23 23:36:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarketWatch",
      "screen_name" : "MarketWatch",
      "indices" : [ 3, 15 ],
      "id_str" : "624413",
      "id" : 624413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/94wSvVBhX0",
      "expanded_url" : "http:\/\/on.mktw.net\/2eHUv4M",
      "display_url" : "on.mktw.net\/2eHUv4M"
    } ]
  },
  "geo" : { },
  "id_str" : "790336075034046464",
  "text" : "RT @MarketWatch: Friday\u2019s internet attack method evolved from disgruntled gamers https:\/\/t.co\/94wSvVBhX0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/94wSvVBhX0",
        "expanded_url" : "http:\/\/on.mktw.net\/2eHUv4M",
        "display_url" : "on.mktw.net\/2eHUv4M"
      } ]
    },
    "geo" : { },
    "id_str" : "790310191283724288",
    "text" : "Friday\u2019s internet attack method evolved from disgruntled gamers https:\/\/t.co\/94wSvVBhX0",
    "id" : 790310191283724288,
    "created_at" : "2016-10-23 21:53:27 +0000",
    "user" : {
      "name" : "MarketWatch",
      "screen_name" : "MarketWatch",
      "protected" : false,
      "id_str" : "624413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705601245596090368\/Z6xUOnRg_normal.jpg",
      "id" : 624413,
      "verified" : true
    }
  },
  "id" : 790336075034046464,
  "created_at" : "2016-10-23 23:36:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/790308235299295232\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/E33E6wJk8u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cve9JcPUsAAVZtY.jpg",
      "id_str" : "790308229523746816",
      "id" : 790308229523746816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cve9JcPUsAAVZtY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/E33E6wJk8u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790335986567827456",
  "text" : "RT @FoxNews: 296 refugees have been diagnosed with active TB in Minnesota. https:\/\/t.co\/E33E6wJk8u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/790308235299295232\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/E33E6wJk8u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cve9JcPUsAAVZtY.jpg",
        "id_str" : "790308229523746816",
        "id" : 790308229523746816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cve9JcPUsAAVZtY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/E33E6wJk8u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790308235299295232",
    "text" : "296 refugees have been diagnosed with active TB in Minnesota. https:\/\/t.co\/E33E6wJk8u",
    "id" : 790308235299295232,
    "created_at" : "2016-10-23 21:45:41 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794654746342662144\/hHnFe4Sx_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 790335986567827456,
  "created_at" : "2016-10-23 23:35:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Idaho Steelheads",
      "screen_name" : "Steelheads",
      "indices" : [ 52, 63 ],
      "id_str" : "18055123",
      "id" : 18055123
    }, {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 77, 87 ],
      "id_str" : "4248211",
      "id" : 4248211
    }, {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 92, 105 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Evan_McMullin\/status\/790023187660615680\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WjXG6OYm0I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cva55YKVIAAoWgv.jpg",
      "id_str" : "790023180039561216",
      "id" : 790023180039561216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cva55YKVIAAoWgv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/WjXG6OYm0I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790335924789927936",
  "text" : "RT @Evan_McMullin: Had a great time cheering on the @Steelheads tonight with @mindyfinn and @TeamMcMullin in Boise. https:\/\/t.co\/WjXG6OYm0I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Idaho Steelheads",
        "screen_name" : "Steelheads",
        "indices" : [ 33, 44 ],
        "id_str" : "18055123",
        "id" : 18055123
      }, {
        "name" : "Mindy Finn",
        "screen_name" : "mindyfinn",
        "indices" : [ 58, 68 ],
        "id_str" : "4248211",
        "id" : 4248211
      }, {
        "name" : "Team McMullin",
        "screen_name" : "TeamMcMullin",
        "indices" : [ 73, 86 ],
        "id_str" : "762792021492895749",
        "id" : 762792021492895749
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Evan_McMullin\/status\/790023187660615680\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/WjXG6OYm0I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cva55YKVIAAoWgv.jpg",
        "id_str" : "790023180039561216",
        "id" : 790023180039561216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cva55YKVIAAoWgv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/WjXG6OYm0I"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790023187660615680",
    "text" : "Had a great time cheering on the @Steelheads tonight with @mindyfinn and @TeamMcMullin in Boise. https:\/\/t.co\/WjXG6OYm0I",
    "id" : 790023187660615680,
    "created_at" : "2016-10-23 02:53:00 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 790335924789927936,
  "created_at" : "2016-10-23 23:35:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KTVB Morgan Boydston",
      "screen_name" : "KTVBMorgan",
      "indices" : [ 3, 14 ],
      "id_str" : "3253144939",
      "id" : 3253144939
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 86, 100 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790335882683310080",
  "text" : "RT @KTVBMorgan: It was a pleasure to sit down with independent presidential candidate @Evan_McMullin tonight. Hear what he stands for at 10\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 70, 84 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      }, {
        "name" : "KTVB.COM",
        "screen_name" : "KTVB",
        "indices" : [ 127, 132 ],
        "id_str" : "14859642",
        "id" : 14859642
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KTVBMorgan\/status\/789992616100147200\/photo\/1",
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/RqVmQ8IRAG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvaeFmOVUAQuGYN.jpg",
        "id_str" : "789992603647299588",
        "id" : 789992603647299588,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvaeFmOVUAQuGYN.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RqVmQ8IRAG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789992616100147200",
    "text" : "It was a pleasure to sit down with independent presidential candidate @Evan_McMullin tonight. Hear what he stands for at 10 on @KTVB https:\/\/t.co\/RqVmQ8IRAG",
    "id" : 789992616100147200,
    "created_at" : "2016-10-23 00:51:31 +0000",
    "user" : {
      "name" : "KTVB Morgan Boydston",
      "screen_name" : "KTVBMorgan",
      "protected" : false,
      "id_str" : "3253144939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669721540565405697\/bOe0_Qhq_normal.jpg",
      "id" : 3253144939,
      "verified" : true
    }
  },
  "id" : 790335882683310080,
  "created_at" : "2016-10-23 23:35:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790335774768009216",
  "text" : "RT @NASA: The GOES-R weather satellite will be able to deliver a full globe scan in only 5 minutes, currently it takes 25 minutes for the s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/790309440431984640\/video\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/ixT5vqrsTr",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/790309323520049153\/img\/171Fb6Rn-2lqlWY0.jpg",
        "id_str" : "790309323520049153",
        "id" : 790309323520049153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/790309323520049153\/img\/171Fb6Rn-2lqlWY0.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ixT5vqrsTr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "790309440431984640",
    "text" : "The GOES-R weather satellite will be able to deliver a full globe scan in only 5 minutes, currently it takes 25 minutes for the same task: https:\/\/t.co\/ixT5vqrsTr",
    "id" : 790309440431984640,
    "created_at" : "2016-10-23 21:50:28 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 790335774768009216,
  "created_at" : "2016-10-23 23:35:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/790335537852747776\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/wG2Hlj1h2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfV-n2UkAA5IQ1.jpg",
      "id_str" : "790335531452239872",
      "id" : 790335531452239872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfV-n2UkAA5IQ1.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/wG2Hlj1h2q"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/790335537852747776\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/wG2Hlj1h2q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvfV-oAVUAIvW0w.jpg",
      "id_str" : "790335531494232066",
      "id" : 790335531494232066,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvfV-oAVUAIvW0w.jpg",
      "sizes" : [ {
        "h" : 89,
        "resize" : "crop",
        "w" : 89
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 89
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 89
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 89
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 89
      } ],
      "display_url" : "pic.twitter.com\/wG2Hlj1h2q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790335537852747776",
  "text" : "Best sodas ever, \uD83D\uDE0E https:\/\/t.co\/wG2Hlj1h2q",
  "id" : 790335537852747776,
  "created_at" : "2016-10-23 23:34:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Evan_McMullin\/status\/789259870411235328\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/9x6bQEtYjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvQDqkrVUAAiCun.jpg",
      "id_str" : "789259864631496704",
      "id" : 789259864631496704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvQDqkrVUAAiCun.jpg",
      "sizes" : [ {
        "h" : 414,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/9x6bQEtYjg"
    } ],
    "hashtags" : [ {
      "text" : "McMullinFinn",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790309651900354560",
  "text" : "RT @Evan_McMullin: This does not bode well for the future of the GOP. There's a better way. #McMullinFinn https:\/\/t.co\/9x6bQEtYjg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Evan_McMullin\/status\/789259870411235328\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/9x6bQEtYjg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvQDqkrVUAAiCun.jpg",
        "id_str" : "789259864631496704",
        "id" : 789259864631496704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvQDqkrVUAAiCun.jpg",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/9x6bQEtYjg"
      } ],
      "hashtags" : [ {
        "text" : "McMullinFinn",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789259870411235328",
    "text" : "This does not bode well for the future of the GOP. There's a better way. #McMullinFinn https:\/\/t.co\/9x6bQEtYjg",
    "id" : 789259870411235328,
    "created_at" : "2016-10-21 00:19:51 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 790309651900354560,
  "created_at" : "2016-10-23 21:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790309583977713664",
  "text" : "Went to Chipotle &amp; got a chorizo burrito w\/ s.cream, beans &amp; guacamole. Also had grapefruit soda &amp; had a lit time w\/ the church group &amp; Hana",
  "id" : 790309583977713664,
  "created_at" : "2016-10-23 21:51:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789470113871327233",
  "text" : "RT @Matthiasiam: If you are trying to convince me of something in a YT comment or a tweet, include your source. Don't spread misinformation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789303809499467776",
    "text" : "If you are trying to convince me of something in a YT comment or a tweet, include your source. Don't spread misinformation.",
    "id" : 789303809499467776,
    "created_at" : "2016-10-21 03:14:27 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878063216936366080\/MYU8BMti_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 789470113871327233,
  "created_at" : "2016-10-21 14:15:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789470045722247168",
  "text" : "Trust me, I am cool, you just all started a long day",
  "id" : 789470045722247168,
  "created_at" : "2016-10-21 14:15:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/789197220968960000\/video\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/JcqTViMnzI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPKrxkVMAED8-L.jpg",
      "id_str" : "789196903141388288",
      "id" : 789196903141388288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPKrxkVMAED8-L.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JcqTViMnzI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ClPeiRo0vu",
      "expanded_url" : "http:\/\/engt.co\/2et6SkZ",
      "display_url" : "engt.co\/2et6SkZ"
    } ]
  },
  "geo" : { },
  "id_str" : "789230109609881600",
  "text" : "RT @engadget: LeEco jumps into the US market with TVs, phones, car and bike https:\/\/t.co\/ClPeiRo0vu https:\/\/t.co\/JcqTViMnzI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/789197220968960000\/video\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/JcqTViMnzI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvPKrxkVMAED8-L.jpg",
        "id_str" : "789196903141388288",
        "id" : 789196903141388288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvPKrxkVMAED8-L.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/JcqTViMnzI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/ClPeiRo0vu",
        "expanded_url" : "http:\/\/engt.co\/2et6SkZ",
        "display_url" : "engt.co\/2et6SkZ"
      } ]
    },
    "geo" : { },
    "id_str" : "789197220968960000",
    "text" : "LeEco jumps into the US market with TVs, phones, car and bike https:\/\/t.co\/ClPeiRo0vu https:\/\/t.co\/JcqTViMnzI",
    "id" : 789197220968960000,
    "created_at" : "2016-10-20 20:10:54 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 789230109609881600,
  "created_at" : "2016-10-20 22:21:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Anthony",
      "screen_name" : "MarcAnthony",
      "indices" : [ 3, 15 ],
      "id_str" : "254274083",
      "id" : 254274083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Houston",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "MarcAnthonyLive",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789229699029405696",
  "text" : "RT @MarcAnthony: #Houston, what a night! Thank you for coming out and sharing so much love. God bless you always! #MarcAnthonyLive #Tour201\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/gainapp.com\" rel=\"nofollow\"\u003EGain App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarcAnthony\/status\/787384952375676928\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/zWDJiX6LoJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu1acCOWgAABPwc.jpg",
        "id_str" : "787384947539607552",
        "id" : 787384947539607552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu1acCOWgAABPwc.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/zWDJiX6LoJ"
      } ],
      "hashtags" : [ {
        "text" : "Houston",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "MarcAnthonyLive",
        "indices" : [ 97, 113 ]
      }, {
        "text" : "Tour2016",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787384952375676928",
    "text" : "#Houston, what a night! Thank you for coming out and sharing so much love. God bless you always! #MarcAnthonyLive #Tour2016 https:\/\/t.co\/zWDJiX6LoJ",
    "id" : 787384952375676928,
    "created_at" : "2016-10-15 20:09:36 +0000",
    "user" : {
      "name" : "Marc Anthony",
      "screen_name" : "MarcAnthony",
      "protected" : false,
      "id_str" : "254274083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683822265599918080\/TNXeJgPl_normal.jpg",
      "id" : 254274083,
      "verified" : true
    }
  },
  "id" : 789229699029405696,
  "created_at" : "2016-10-20 22:19:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789229454627405824",
  "text" : "Why can't we just all unite???",
  "id" : 789229454627405824,
  "created_at" : "2016-10-20 22:18:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nurse Barb",
      "screen_name" : "NurseBarbDehn",
      "indices" : [ 3, 17 ],
      "id_str" : "14297643",
      "id" : 14297643
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NurseBarbDehn\/status\/789144723726270464\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/4Z2DXfr4Md",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOa8XRUEAA-cRF.jpg",
      "id_str" : "789144721549430784",
      "id" : 789144721549430784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOa8XRUEAA-cRF.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/4Z2DXfr4Md"
    } ],
    "hashtags" : [ {
      "text" : "Gentle",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "Tanzania",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789165647389339648",
  "text" : "RT @NurseBarbDehn: Good Morning from a #Gentle Giant in #Tanzania. https:\/\/t.co\/4Z2DXfr4Md",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NurseBarbDehn\/status\/789144723726270464\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/4Z2DXfr4Md",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvOa8XRUEAA-cRF.jpg",
        "id_str" : "789144721549430784",
        "id" : 789144721549430784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvOa8XRUEAA-cRF.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/4Z2DXfr4Md"
      } ],
      "hashtags" : [ {
        "text" : "Gentle",
        "indices" : [ 20, 27 ]
      }, {
        "text" : "Tanzania",
        "indices" : [ 37, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "789144723726270464",
    "text" : "Good Morning from a #Gentle Giant in #Tanzania. https:\/\/t.co\/4Z2DXfr4Md",
    "id" : 789144723726270464,
    "created_at" : "2016-10-20 16:42:18 +0000",
    "user" : {
      "name" : "Nurse Barb",
      "screen_name" : "NurseBarbDehn",
      "protected" : false,
      "id_str" : "14297643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1926399777\/NB_Twitter3_normal.jpg",
      "id" : 14297643,
      "verified" : false
    }
  },
  "id" : 789165647389339648,
  "created_at" : "2016-10-20 18:05:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/IIHpdF1Kk4",
      "expanded_url" : "http:\/\/ow.ly\/pxrD305jkna",
      "display_url" : "ow.ly\/pxrD305jkna"
    } ]
  },
  "geo" : { },
  "id_str" : "789165426131410944",
  "text" : "RT @analyticbridge: More than 100 data science, analytics, big data, visualization books https:\/\/t.co\/IIHpdF1Kk4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/IIHpdF1Kk4",
        "expanded_url" : "http:\/\/ow.ly\/pxrD305jkna",
        "display_url" : "ow.ly\/pxrD305jkna"
      } ]
    },
    "geo" : { },
    "id_str" : "789119550268796929",
    "text" : "More than 100 data science, analytics, big data, visualization books https:\/\/t.co\/IIHpdF1Kk4",
    "id" : 789119550268796929,
    "created_at" : "2016-10-20 15:02:16 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 789165426131410944,
  "created_at" : "2016-10-20 18:04:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789165339225366528",
  "text" : "I'm so funny, just everybody around me has no sense of humor, \uD83D\uDE02",
  "id" : 789165339225366528,
  "created_at" : "2016-10-20 18:04:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789096718302195712",
  "text" : "RT @Evan_McMullin: Being serious about the national debt means having the courage to reform entitlements. Both of these candidates fail tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788930210871713792",
    "text" : "Being serious about the national debt means having the courage to reform entitlements. Both of these candidates fail that test. #debates",
    "id" : 788930210871713792,
    "created_at" : "2016-10-20 02:29:54 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 789096718302195712,
  "created_at" : "2016-10-20 13:31:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 21, 33 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789096536365867008",
  "text" : "RT @HelloRyanHolmes: @gamer456148 DUDE RIGHT!?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "788488975321268225",
    "geo" : { },
    "id_str" : "788635797515821058",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 DUDE RIGHT!?",
    "id" : 788635797515821058,
    "in_reply_to_status_id" : 788488975321268225,
    "created_at" : "2016-10-19 07:00:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880486625746223106\/uqol0phE_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 789096536365867008,
  "created_at" : "2016-10-20 13:30:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Matthiasiam\/status\/788446484488269824\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/xwRr6lQUU0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEf3rTUIAAbtwR.jpg",
      "id_str" : "788446451143548928",
      "id" : 788446451143548928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEf3rTUIAAbtwR.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xwRr6lQUU0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788489128107249664",
  "text" : "RT @Matthiasiam: Look out for todays video where I roast your sorry butts https:\/\/t.co\/xwRr6lQUU0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Matthiasiam\/status\/788446484488269824\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/xwRr6lQUU0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvEf3rTUIAAbtwR.jpg",
        "id_str" : "788446451143548928",
        "id" : 788446451143548928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvEf3rTUIAAbtwR.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/xwRr6lQUU0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788446484488269824",
    "text" : "Look out for todays video where I roast your sorry butts https:\/\/t.co\/xwRr6lQUU0",
    "id" : 788446484488269824,
    "created_at" : "2016-10-18 18:27:45 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878063216936366080\/MYU8BMti_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 788489128107249664,
  "created_at" : "2016-10-18 21:17:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788053061625184257",
  "geo" : { },
  "id_str" : "788488975321268225",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Now has over 104 million views, if it got that many views than you deserve 800 million views, lol",
  "id" : 788488975321268225,
  "in_reply_to_status_id" : 788053061625184257,
  "created_at" : "2016-10-18 21:16:35 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "indices" : [ 3, 14 ],
      "id_str" : "15131310",
      "id" : 15131310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fall",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "SlowCooker",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788426297286488064",
  "text" : "RT @WholeFoods: Check out our 10 most popular #fall recipes... Determined by you! Fall in love with this #SlowCooker Soup: https:\/\/t.co\/xqw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WholeFoods\/status\/788425932218466305\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/OnxReWSocv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvENNH_W8AAVSyg.jpg",
        "id_str" : "788425928900800512",
        "id" : 788425928900800512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvENNH_W8AAVSyg.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1151,
          "resize" : "fit",
          "w" : 2046
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1151,
          "resize" : "fit",
          "w" : 2046
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/OnxReWSocv"
      } ],
      "hashtags" : [ {
        "text" : "fall",
        "indices" : [ 30, 35 ]
      }, {
        "text" : "SlowCooker",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/xqw4Hgrma9",
        "expanded_url" : "http:\/\/bit.ly\/2eexMR6",
        "display_url" : "bit.ly\/2eexMR6"
      } ]
    },
    "geo" : { },
    "id_str" : "788425932218466305",
    "text" : "Check out our 10 most popular #fall recipes... Determined by you! Fall in love with this #SlowCooker Soup: https:\/\/t.co\/xqw4Hgrma9. https:\/\/t.co\/OnxReWSocv",
    "id" : 788425932218466305,
    "created_at" : "2016-10-18 17:06:05 +0000",
    "user" : {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "protected" : false,
      "id_str" : "15131310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804367481041080320\/ljq1T2Qx_normal.jpg",
      "id" : 15131310,
      "verified" : true
    }
  },
  "id" : 788426297286488064,
  "created_at" : "2016-10-18 17:07:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 0, 9 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788396978522755073",
  "geo" : { },
  "id_str" : "788426141736562689",
  "in_reply_to_user_id" : 33522196,
  "text" : "@Gillette Way too many times",
  "id" : 788426141736562689,
  "in_reply_to_status_id" : 788396978522755073,
  "created_at" : "2016-10-18 17:06:55 +0000",
  "in_reply_to_screen_name" : "Gillette",
  "in_reply_to_user_id_str" : "33522196",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/788394243769397248\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/QJfUPoX6an",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvDwYowWIAA-jbX.jpg",
      "id_str" : "788394240837558272",
      "id" : 788394240837558272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvDwYowWIAA-jbX.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/QJfUPoX6an"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/XHzfFschjc",
      "expanded_url" : "http:\/\/engt.co\/2dkD3qL",
      "display_url" : "engt.co\/2dkD3qL"
    } ]
  },
  "geo" : { },
  "id_str" : "788426056621588481",
  "text" : "RT @engadget: Audi's all-electric vehicle line will be called the 'E-Tron' https:\/\/t.co\/XHzfFschjc https:\/\/t.co\/QJfUPoX6an",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/788394243769397248\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/QJfUPoX6an",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CvDwYowWIAA-jbX.jpg",
        "id_str" : "788394240837558272",
        "id" : 788394240837558272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvDwYowWIAA-jbX.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/QJfUPoX6an"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/XHzfFschjc",
        "expanded_url" : "http:\/\/engt.co\/2dkD3qL",
        "display_url" : "engt.co\/2dkD3qL"
      } ]
    },
    "geo" : { },
    "id_str" : "788394243769397248",
    "text" : "Audi's all-electric vehicle line will be called the 'E-Tron' https:\/\/t.co\/XHzfFschjc https:\/\/t.co\/QJfUPoX6an",
    "id" : 788394243769397248,
    "created_at" : "2016-10-18 15:00:10 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 788426056621588481,
  "created_at" : "2016-10-18 17:06:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 16, 25 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 26, 39 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "788425539455488000",
  "geo" : { },
  "id_str" : "788426034219716608",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @engadget @Joseflokmani yours will be better",
  "id" : 788426034219716608,
  "in_reply_to_status_id" : 788425539455488000,
  "created_at" : "2016-10-18 17:06:29 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/rYYpceFbBq",
      "expanded_url" : "http:\/\/ow.ly\/Zhmf3057dHl",
      "display_url" : "ow.ly\/Zhmf3057dHl"
    } ]
  },
  "geo" : { },
  "id_str" : "788425822210260992",
  "text" : "RT @analyticbridge: 3 Game Changing Big Data Use Cases in Telecom https:\/\/t.co\/rYYpceFbBq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/rYYpceFbBq",
        "expanded_url" : "http:\/\/ow.ly\/Zhmf3057dHl",
        "display_url" : "ow.ly\/Zhmf3057dHl"
      } ]
    },
    "geo" : { },
    "id_str" : "788425235116748801",
    "text" : "3 Game Changing Big Data Use Cases in Telecom https:\/\/t.co\/rYYpceFbBq",
    "id" : 788425235116748801,
    "created_at" : "2016-10-18 17:03:18 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 788425822210260992,
  "created_at" : "2016-10-18 17:05:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788425796104978433",
  "text" : "If only I was smooth like Elvis",
  "id" : 788425796104978433,
  "created_at" : "2016-10-18 17:05:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/fS6YawsuRT",
      "expanded_url" : "http:\/\/ow.ly\/Qb6Q3057dGQ",
      "display_url" : "ow.ly\/Qb6Q3057dGQ"
    } ]
  },
  "geo" : { },
  "id_str" : "788393773239721984",
  "text" : "RT @analyticbridge: Managed Analytics \u0096 A Shortcut to Success https:\/\/t.co\/fS6YawsuRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/fS6YawsuRT",
        "expanded_url" : "http:\/\/ow.ly\/Qb6Q3057dGQ",
        "display_url" : "ow.ly\/Qb6Q3057dGQ"
      } ]
    },
    "geo" : { },
    "id_str" : "788190563455668224",
    "text" : "Managed Analytics \u0096 A Shortcut to Success https:\/\/t.co\/fS6YawsuRT",
    "id" : 788190563455668224,
    "created_at" : "2016-10-18 01:30:48 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 788393773239721984,
  "created_at" : "2016-10-18 14:58:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/788393708467068928\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/qQqarZC1Zt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvDv22GVMAACxp5.jpg",
      "id_str" : "788393660303880192",
      "id" : 788393660303880192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvDv22GVMAACxp5.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qQqarZC1Zt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788393708467068928",
  "text" : "Had Jersey Mike's sub, the giant version, it was way too heavy and greasy :( but did taste good https:\/\/t.co\/qQqarZC1Zt",
  "id" : 788393708467068928,
  "created_at" : "2016-10-18 14:58:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "indices" : [ 3, 12 ],
      "id_str" : "14244304",
      "id" : 14244304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/evanderv\/status\/788026330474541056\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/evZsKYmT7O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-hw1AWAAA-eHH.jpg",
      "id_str" : "788026320047439872",
      "id" : 788026320047439872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-hw1AWAAA-eHH.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/evZsKYmT7O"
    } ],
    "hashtags" : [ {
      "text" : "MICyberSummit",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788041730935455745",
  "text" : "RT @evanderv: Employee cyber security awareness is ultimately one we need to focus on.  #MICyberSummit https:\/\/t.co\/evZsKYmT7O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/evanderv\/status\/788026330474541056\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/evZsKYmT7O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-hw1AWAAA-eHH.jpg",
        "id_str" : "788026320047439872",
        "id" : 788026320047439872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-hw1AWAAA-eHH.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/evZsKYmT7O"
      } ],
      "hashtags" : [ {
        "text" : "MICyberSummit",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788026330474541056",
    "text" : "Employee cyber security awareness is ultimately one we need to focus on.  #MICyberSummit https:\/\/t.co\/evZsKYmT7O",
    "id" : 788026330474541056,
    "created_at" : "2016-10-17 14:38:12 +0000",
    "user" : {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "protected" : false,
      "id_str" : "14244304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1799520845\/eric_normal.jpg",
      "id" : 14244304,
      "verified" : false
    }
  },
  "id" : 788041730935455745,
  "created_at" : "2016-10-17 15:39:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters U.S. News",
      "screen_name" : "ReutersUS",
      "indices" : [ 3, 13 ],
      "id_str" : "15108530",
      "id" : 15108530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788041631010283521",
  "text" : "RT @ReutersUS: BREAKING: Undersecretary of State Kennedy asked FBI to make 'classified' Clinton email 'unclassified' for a 'quid pro quo' -\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788024242071830528",
    "text" : "BREAKING: Undersecretary of State Kennedy asked FBI to make 'classified' Clinton email 'unclassified' for a 'quid pro quo' - FBI documents",
    "id" : 788024242071830528,
    "created_at" : "2016-10-17 14:29:54 +0000",
    "user" : {
      "name" : "Reuters U.S. News",
      "screen_name" : "ReutersUS",
      "protected" : false,
      "id_str" : "15108530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877263299439493121\/4Otn8oxB_normal.jpg",
      "id" : 15108530,
      "verified" : true
    }
  },
  "id" : 788041631010283521,
  "created_at" : "2016-10-17 15:39:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "indices" : [ 3, 12 ],
      "id_str" : "14244304",
      "id" : 14244304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MICyberSecurity",
      "indices" : [ 81, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788041587955728384",
  "text" : "RT @evanderv: Gov. Rick Snyder, we need to help each other with Cyber Security.  #MICyberSecurity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MICyberSecurity",
        "indices" : [ 67, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "788000051050127361",
    "text" : "Gov. Rick Snyder, we need to help each other with Cyber Security.  #MICyberSecurity",
    "id" : 788000051050127361,
    "created_at" : "2016-10-17 12:53:47 +0000",
    "user" : {
      "name" : "Eric Vanderveer",
      "screen_name" : "evanderv",
      "protected" : false,
      "id_str" : "14244304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1799520845\/eric_normal.jpg",
      "id" : 14244304,
      "verified" : false
    }
  },
  "id" : 788041587955728384,
  "created_at" : "2016-10-17 15:38:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788041464530034689",
  "text" : "RT @KassyDillon: I just want the election season to be over. It's so draining. I can't wait to focus on activism and the issues regardless\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787780395894988802",
    "text" : "I just want the election season to be over. It's so draining. I can't wait to focus on activism and the issues regardless of who wins.",
    "id" : 787780395894988802,
    "created_at" : "2016-10-16 22:20:57 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 788041464530034689,
  "created_at" : "2016-10-17 15:38:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/788041040779509761\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/qPtbLvevqG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-vJg6WEAEHJ1Q.jpg",
      "id_str" : "788041037801459713",
      "id" : 788041037801459713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-vJg6WEAEHJ1Q.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/qPtbLvevqG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/egerZS9YDp",
      "expanded_url" : "http:\/\/engt.co\/2em37Of",
      "display_url" : "engt.co\/2em37Of"
    } ]
  },
  "geo" : { },
  "id_str" : "788041355788509184",
  "text" : "RT @engadget: Video game voice actors will strike on October 21st https:\/\/t.co\/egerZS9YDp https:\/\/t.co\/qPtbLvevqG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/788041040779509761\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/qPtbLvevqG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu-vJg6WEAEHJ1Q.jpg",
        "id_str" : "788041037801459713",
        "id" : 788041037801459713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu-vJg6WEAEHJ1Q.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/qPtbLvevqG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/egerZS9YDp",
        "expanded_url" : "http:\/\/engt.co\/2em37Of",
        "display_url" : "engt.co\/2em37Of"
      } ]
    },
    "geo" : { },
    "id_str" : "788041040779509761",
    "text" : "Video game voice actors will strike on October 21st https:\/\/t.co\/egerZS9YDp https:\/\/t.co\/qPtbLvevqG",
    "id" : 788041040779509761,
    "created_at" : "2016-10-17 15:36:39 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 788041355788509184,
  "created_at" : "2016-10-17 15:37:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "788041276096647168",
  "text" : "Women love to confuse men, that's why it is so hard to understand them. It is like an art of war.",
  "id" : 788041276096647168,
  "created_at" : "2016-10-17 15:37:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Alibaba Group",
      "screen_name" : "AlibabaGroup",
      "indices" : [ 38, 51 ],
      "id_str" : "2694564780",
      "id" : 2694564780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787819852186517504",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani I might get addicted to @AlibabaGroup",
  "id" : 787819852186517504,
  "created_at" : "2016-10-17 00:57:44 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 3, 16 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787819744892039168",
  "text" : "RT @JosefLokmani: @gamer456148 eat sallad and healthy. Buy yourself vitamins also, and buy omega 3 and such",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "745033268194467840",
    "geo" : { },
    "id_str" : "745036465734836224",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 eat sallad and healthy. Buy yourself vitamins also, and buy omega 3 and such",
    "id" : 745036465734836224,
    "in_reply_to_status_id" : 745033268194467840,
    "created_at" : "2016-06-20 23:31:50 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "protected" : false,
      "id_str" : "703541068462235648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836658752577290241\/4sTW-DBF_normal.jpg",
      "id" : 703541068462235648,
      "verified" : false
    }
  },
  "id" : 787819744892039168,
  "created_at" : "2016-10-17 00:57:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/De6ldTbdcb",
      "expanded_url" : "http:\/\/ow.ly\/VDC43057dG0",
      "display_url" : "ow.ly\/VDC43057dG0"
    } ]
  },
  "geo" : { },
  "id_str" : "787819185288065024",
  "text" : "RT @analyticbridge: Data Science with Python &amp;amp; R: Dimensionality Reduction and Clustering https:\/\/t.co\/De6ldTbdcb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/De6ldTbdcb",
        "expanded_url" : "http:\/\/ow.ly\/VDC43057dG0",
        "display_url" : "ow.ly\/VDC43057dG0"
      } ]
    },
    "geo" : { },
    "id_str" : "787805624063197184",
    "text" : "Data Science with Python &amp;amp; R: Dimensionality Reduction and Clustering https:\/\/t.co\/De6ldTbdcb",
    "id" : 787805624063197184,
    "created_at" : "2016-10-17 00:01:12 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 787819185288065024,
  "created_at" : "2016-10-17 00:55:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/toRvkpNFba",
      "expanded_url" : "http:\/\/ow.ly\/5jS23057dG1",
      "display_url" : "ow.ly\/5jS23057dG1"
    } ]
  },
  "geo" : { },
  "id_str" : "787818956920807424",
  "text" : "RT @analyticbridge: 20 Excel spreadsheet secrets https:\/\/t.co\/toRvkpNFba",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/toRvkpNFba",
        "expanded_url" : "http:\/\/ow.ly\/5jS23057dG1",
        "display_url" : "ow.ly\/5jS23057dG1"
      } ]
    },
    "geo" : { },
    "id_str" : "787813031199801344",
    "text" : "20 Excel spreadsheet secrets https:\/\/t.co\/toRvkpNFba",
    "id" : 787813031199801344,
    "created_at" : "2016-10-17 00:30:38 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 787818956920807424,
  "created_at" : "2016-10-17 00:54:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aaleem",
      "screen_name" : "garamsamosay",
      "indices" : [ 3, 16 ],
      "id_str" : "341135765",
      "id" : 341135765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787818926314885121",
  "text" : "RT @garamsamosay: Im starting to love my job, all we do is blast rap music and fix computers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787811860632461312",
    "text" : "Im starting to love my job, all we do is blast rap music and fix computers",
    "id" : 787811860632461312,
    "created_at" : "2016-10-17 00:25:59 +0000",
    "user" : {
      "name" : "aaleem",
      "screen_name" : "garamsamosay",
      "protected" : false,
      "id_str" : "341135765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884302280715104256\/B6kW9e7m_normal.jpg",
      "id" : 341135765,
      "verified" : false
    }
  },
  "id" : 787818926314885121,
  "created_at" : "2016-10-17 00:54:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "indices" : [ 3, 12 ],
      "id_str" : "13213122",
      "id" : 13213122
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Deadspin\/status\/787809141633015808\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/z113KMqw56",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7cPPZWIAABady.jpg",
      "id_str" : "787809139225403392",
      "id" : 787809139225403392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7cPPZWIAABady.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/z113KMqw56"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/WF9SVM0RP5",
      "expanded_url" : "http:\/\/deadsp.in\/ZsTQX1t",
      "display_url" : "deadsp.in\/ZsTQX1t"
    } ]
  },
  "geo" : { },
  "id_str" : "787818910628261888",
  "text" : "RT @Deadspin: Falcons lose chance to win on missed pass interference call: https:\/\/t.co\/WF9SVM0RP5 https:\/\/t.co\/z113KMqw56",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deadspin\/status\/787809141633015808\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/z113KMqw56",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7cPPZWIAABady.jpg",
        "id_str" : "787809139225403392",
        "id" : 787809139225403392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7cPPZWIAABady.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/z113KMqw56"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/WF9SVM0RP5",
        "expanded_url" : "http:\/\/deadsp.in\/ZsTQX1t",
        "display_url" : "deadsp.in\/ZsTQX1t"
      } ]
    },
    "geo" : { },
    "id_str" : "787809141633015808",
    "text" : "Falcons lose chance to win on missed pass interference call: https:\/\/t.co\/WF9SVM0RP5 https:\/\/t.co\/z113KMqw56",
    "id" : 787809141633015808,
    "created_at" : "2016-10-17 00:15:10 +0000",
    "user" : {
      "name" : "Deadspin",
      "screen_name" : "Deadspin",
      "protected" : false,
      "id_str" : "13213122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590240306353811456\/Ee89NSpb_normal.png",
      "id" : 13213122,
      "verified" : true
    }
  },
  "id" : 787818910628261888,
  "created_at" : "2016-10-17 00:53:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ksmfrq0Oy3",
      "expanded_url" : "https:\/\/twitter.com\/mofoq\/status\/787809060879937536",
      "display_url" : "twitter.com\/mofoq\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787818613013000192",
  "text" : "RT @KassyDillon: Yes. I need another puppy. My sister hogs Tucker. https:\/\/t.co\/ksmfrq0Oy3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/ksmfrq0Oy3",
        "expanded_url" : "https:\/\/twitter.com\/mofoq\/status\/787809060879937536",
        "display_url" : "twitter.com\/mofoq\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787809619569680384",
    "text" : "Yes. I need another puppy. My sister hogs Tucker. https:\/\/t.co\/ksmfrq0Oy3",
    "id" : 787809619569680384,
    "created_at" : "2016-10-17 00:17:04 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 787818613013000192,
  "created_at" : "2016-10-17 00:52:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/SPMuZyOhmQ",
      "expanded_url" : "http:\/\/ow.ly\/Aoii304LYaa",
      "display_url" : "ow.ly\/Aoii304LYaa"
    } ]
  },
  "geo" : { },
  "id_str" : "787818271907065856",
  "text" : "RT @analyticbridge: Making the Most of Survey Research Data https:\/\/t.co\/SPMuZyOhmQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/SPMuZyOhmQ",
        "expanded_url" : "http:\/\/ow.ly\/Aoii304LYaa",
        "display_url" : "ow.ly\/Aoii304LYaa"
      } ]
    },
    "geo" : { },
    "id_str" : "787816725211389952",
    "text" : "Making the Most of Survey Research Data https:\/\/t.co\/SPMuZyOhmQ",
    "id" : 787816725211389952,
    "created_at" : "2016-10-17 00:45:18 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 787818271907065856,
  "created_at" : "2016-10-17 00:51:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/goC94eUEpX",
      "expanded_url" : "http:\/\/fb.me\/5ewLgYUNt",
      "display_url" : "fb.me\/5ewLgYUNt"
    } ]
  },
  "geo" : { },
  "id_str" : "787818024262733824",
  "text" : "RT @EmperorDarroux: Robin Williams' unique bicycle collection goes on auction block for charity https:\/\/t.co\/goC94eUEpX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/goC94eUEpX",
        "expanded_url" : "http:\/\/fb.me\/5ewLgYUNt",
        "display_url" : "fb.me\/5ewLgYUNt"
      } ]
    },
    "geo" : { },
    "id_str" : "787814338560200704",
    "text" : "Robin Williams' unique bicycle collection goes on auction block for charity https:\/\/t.co\/goC94eUEpX",
    "id" : 787814338560200704,
    "created_at" : "2016-10-17 00:35:49 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 787818024262733824,
  "created_at" : "2016-10-17 00:50:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/787805453166059520\/video\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/HRIS8qDg0J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7Y4LyVIAI-acp.jpg",
      "id_str" : "787805355229089792",
      "id" : 787805355229089792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7Y4LyVIAI-acp.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/HRIS8qDg0J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ftVWN5hmoZ",
      "expanded_url" : "http:\/\/engt.co\/2ebjjHp",
      "display_url" : "engt.co\/2ebjjHp"
    } ]
  },
  "geo" : { },
  "id_str" : "787817884751831040",
  "text" : "RT @engadget: Panasonic's new prototype TV can hide in plain sight https:\/\/t.co\/ftVWN5hmoZ https:\/\/t.co\/HRIS8qDg0J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/787805453166059520\/video\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/HRIS8qDg0J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7Y4LyVIAI-acp.jpg",
        "id_str" : "787805355229089792",
        "id" : 787805355229089792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7Y4LyVIAI-acp.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/HRIS8qDg0J"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/ftVWN5hmoZ",
        "expanded_url" : "http:\/\/engt.co\/2ebjjHp",
        "display_url" : "engt.co\/2ebjjHp"
      } ]
    },
    "geo" : { },
    "id_str" : "787805453166059520",
    "text" : "Panasonic's new prototype TV can hide in plain sight https:\/\/t.co\/ftVWN5hmoZ https:\/\/t.co\/HRIS8qDg0J",
    "id" : 787805453166059520,
    "created_at" : "2016-10-17 00:00:31 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 787817884751831040,
  "created_at" : "2016-10-17 00:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Special Report Team",
      "screen_name" : "SpecialReport",
      "indices" : [ 40, 54 ],
      "id_str" : "122207745",
      "id" : 122207745
    }, {
      "name" : "Bret Baier",
      "screen_name" : "BretBaier",
      "indices" : [ 70, 80 ],
      "id_str" : "18646108",
      "id" : 18646108
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 84, 92 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787817861922250752",
  "text" : "RT @Evan_McMullin: I'll be appearing on @SpecialReport this hour with @BretBaier on @FoxNews - hope you can join us!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Special Report Team",
        "screen_name" : "SpecialReport",
        "indices" : [ 21, 35 ],
        "id_str" : "122207745",
        "id" : 122207745
      }, {
        "name" : "Bret Baier",
        "screen_name" : "BretBaier",
        "indices" : [ 51, 61 ],
        "id_str" : "18646108",
        "id" : 18646108
      }, {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 65, 73 ],
        "id_str" : "1367531",
        "id" : 1367531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787805574226325508",
    "text" : "I'll be appearing on @SpecialReport this hour with @BretBaier on @FoxNews - hope you can join us!",
    "id" : 787805574226325508,
    "created_at" : "2016-10-17 00:01:00 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 787817861922250752,
  "created_at" : "2016-10-17 00:49:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787817839402979329\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/jKO8Ht6KOE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7kJD4WEAAqLkA.jpg",
      "id_str" : "787817829148004352",
      "id" : 787817829148004352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7kJD4WEAAqLkA.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/jKO8Ht6KOE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787817839402979329\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/jKO8Ht6KOE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7kJD5WAAAmNNb.jpg",
      "id_str" : "787817829152194560",
      "id" : 787817829152194560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7kJD5WAAAmNNb.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 521
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/jKO8Ht6KOE"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787817839402979329\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/jKO8Ht6KOE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu7kJD5WAAICsHy.jpg",
      "id_str" : "787817829152194562",
      "id" : 787817829152194562,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu7kJD5WAAICsHy.jpg",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/jKO8Ht6KOE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787817839402979329",
  "text" : "These memes I found online are so cringe worthy https:\/\/t.co\/jKO8Ht6KOE",
  "id" : 787817839402979329,
  "created_at" : "2016-10-17 00:49:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787738935426416640",
  "text" : "Be always a person of character",
  "id" : 787738935426416640,
  "created_at" : "2016-10-16 19:36:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breyden Moore",
      "screen_name" : "BreyMoore",
      "indices" : [ 3, 13 ],
      "id_str" : "35158451",
      "id" : 35158451
    }, {
      "name" : "Alyssa Moore",
      "screen_name" : "alyssamooream",
      "indices" : [ 15, 29 ],
      "id_str" : "46056636",
      "id" : 46056636
    }, {
      "name" : "Alana Mastrangelo",
      "screen_name" : "ARmastrangelo",
      "indices" : [ 30, 44 ],
      "id_str" : "26520948",
      "id" : 26520948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737881708199936",
  "text" : "RT @BreyMoore: @alyssamooream @ARmastrangelo makes sense. All a game",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alyssa Moore",
        "screen_name" : "alyssamooream",
        "indices" : [ 0, 14 ],
        "id_str" : "46056636",
        "id" : 46056636
      }, {
        "name" : "Alana Mastrangelo",
        "screen_name" : "ARmastrangelo",
        "indices" : [ 15, 29 ],
        "id_str" : "26520948",
        "id" : 26520948
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "787683672488980482",
    "geo" : { },
    "id_str" : "787683811525996544",
    "in_reply_to_user_id" : 46056636,
    "text" : "@alyssamooream @ARmastrangelo makes sense. All a game",
    "id" : 787683811525996544,
    "in_reply_to_status_id" : 787683672488980482,
    "created_at" : "2016-10-16 15:57:09 +0000",
    "in_reply_to_screen_name" : "alyssamooream",
    "in_reply_to_user_id_str" : "46056636",
    "user" : {
      "name" : "Breyden Moore",
      "screen_name" : "BreyMoore",
      "protected" : false,
      "id_str" : "35158451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823042674668113920\/YTPSY1L9_normal.jpg",
      "id" : 35158451,
      "verified" : false
    }
  },
  "id" : 787737881708199936,
  "created_at" : "2016-10-16 19:32:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Jennings",
      "screen_name" : "willjennings60",
      "indices" : [ 3, 18 ],
      "id_str" : "337113210",
      "id" : 337113210
    }, {
      "name" : "Alana Mastrangelo",
      "screen_name" : "ARmastrangelo",
      "indices" : [ 20, 34 ],
      "id_str" : "26520948",
      "id" : 26520948
    }, {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 35, 48 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737866352922624",
  "text" : "RT @willjennings60: @ARmastrangelo @PrisonPlanet - Typical liberal response, isn't it? Don't advance a new plan\/policy to help blacks; just\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alana Mastrangelo",
        "screen_name" : "ARmastrangelo",
        "indices" : [ 0, 14 ],
        "id_str" : "26520948",
        "id" : 26520948
      }, {
        "name" : "Paul Joseph Watson",
        "screen_name" : "PrisonPlanet",
        "indices" : [ 15, 28 ],
        "id_str" : "18643437",
        "id" : 18643437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "787637826019926021",
    "geo" : { },
    "id_str" : "787657356444184576",
    "in_reply_to_user_id" : 26520948,
    "text" : "@ARmastrangelo @PrisonPlanet - Typical liberal response, isn't it? Don't advance a new plan\/policy to help blacks; just hire a token.",
    "id" : 787657356444184576,
    "in_reply_to_status_id" : 787637826019926021,
    "created_at" : "2016-10-16 14:12:02 +0000",
    "in_reply_to_screen_name" : "ARmastrangelo",
    "in_reply_to_user_id_str" : "26520948",
    "user" : {
      "name" : "William Jennings",
      "screen_name" : "willjennings60",
      "protected" : false,
      "id_str" : "337113210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869914399942746112\/XK7gbSHu_normal.jpg",
      "id" : 337113210,
      "verified" : false
    }
  },
  "id" : 787737866352922624,
  "created_at" : "2016-10-16 19:31:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fifa Ultimate Goals",
      "screen_name" : "Eliastrip",
      "indices" : [ 0, 10 ],
      "id_str" : "176737476",
      "id" : 176737476
    }, {
      "name" : "David Wolfe",
      "screen_name" : "DavidWolfe",
      "indices" : [ 11, 22 ],
      "id_str" : "15328881",
      "id" : 15328881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787587905283887104",
  "geo" : { },
  "id_str" : "787737525054017538",
  "in_reply_to_user_id" : 176737476,
  "text" : "@Eliastrip @DavidWolfe I think I may have seen a super moon yesterday!!!",
  "id" : 787737525054017538,
  "in_reply_to_status_id" : 787587905283887104,
  "created_at" : "2016-10-16 19:30:36 +0000",
  "in_reply_to_screen_name" : "Eliastrip",
  "in_reply_to_user_id_str" : "176737476",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quotes",
      "screen_name" : "quotes",
      "indices" : [ 3, 10 ],
      "id_str" : "646353",
      "id" : 646353
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/quotes\/status\/787518551733272576\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/vauocJpLV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu3T8r1WIAA2TAg.jpg",
      "id_str" : "787518549371789312",
      "id" : 787518549371789312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu3T8r1WIAA2TAg.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/vauocJpLV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737342069137408",
  "text" : "RT @quotes: \"Good people are like candles; they burn themselves up to give others light.\" - Turkish Proverb https:\/\/t.co\/vauocJpLV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/quotes\/status\/787518551733272576\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/vauocJpLV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu3T8r1WIAA2TAg.jpg",
        "id_str" : "787518549371789312",
        "id" : 787518549371789312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu3T8r1WIAA2TAg.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/vauocJpLV4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787518551733272576",
    "text" : "\"Good people are like candles; they burn themselves up to give others light.\" - Turkish Proverb https:\/\/t.co\/vauocJpLV4",
    "id" : 787518551733272576,
    "created_at" : "2016-10-16 05:00:28 +0000",
    "user" : {
      "name" : "Quotes",
      "screen_name" : "quotes",
      "protected" : false,
      "id_str" : "646353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467381374886744064\/oo4UffQ1_normal.png",
      "id" : 646353,
      "verified" : false
    }
  },
  "id" : 787737342069137408,
  "created_at" : "2016-10-16 19:29:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737289606701056",
  "text" : "RT @Evan_McMullin: I told Congressional Republicans: You've got to put the interests of the country 1st, &amp; never mind your reelection. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/rRSOg5J9Sw",
        "expanded_url" : "https:\/\/www.facebook.com\/mcmullinforpresident\/videos\/vb.1604371783193820\/1634214183542913\/?type=2&theater&notif_t=live_video_explicit&notif_id=1476547545989128",
        "display_url" : "facebook.com\/mcmullinforpre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787470023103164416",
    "text" : "I told Congressional Republicans: You've got to put the interests of the country 1st, &amp; never mind your reelection. https:\/\/t.co\/rRSOg5J9Sw",
    "id" : 787470023103164416,
    "created_at" : "2016-10-16 01:47:38 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 787737289606701056,
  "created_at" : "2016-10-16 19:29:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 19, 33 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Utah",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737256530509824",
  "text" : "RT @TeamMcMullin: .@Evan_McMullin is LIVE NOW from St. George, #Utah, in front of another packed house. Watch online here: https:\/\/t.co\/zEw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 1, 15 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/787467841096122369\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/EkBhpb8L7B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu2l0NvUAAA74SS.jpg",
        "id_str" : "787467826319589376",
        "id" : 787467826319589376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu2l0NvUAAA74SS.jpg",
        "sizes" : [ {
          "h" : 503,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/EkBhpb8L7B"
      } ],
      "hashtags" : [ {
        "text" : "Utah",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/zEwtuttqm5",
        "expanded_url" : "https:\/\/www.facebook.com\/mcmullinforpresident\/videos\/vb.1604371783193820\/1634214183542913\/?type=2&theater&notif_t=live_video_explicit&notif_id=1476547545989128",
        "display_url" : "facebook.com\/mcmullinforpre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787467841096122369",
    "text" : ".@Evan_McMullin is LIVE NOW from St. George, #Utah, in front of another packed house. Watch online here: https:\/\/t.co\/zEwtuttqm5 https:\/\/t.co\/EkBhpb8L7B",
    "id" : 787467841096122369,
    "created_at" : "2016-10-16 01:38:58 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 787737256530509824,
  "created_at" : "2016-10-16 19:29:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick",
      "screen_name" : "nickpar12",
      "indices" : [ 3, 13 ],
      "id_str" : "3249449702",
      "id" : 3249449702
    }, {
      "name" : "BLACK PPL TWEET",
      "screen_name" : "BlackPplTweet",
      "indices" : [ 15, 29 ],
      "id_str" : "1138569926",
      "id" : 1138569926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787737214910431232",
  "text" : "RT @nickpar12: @BlackPplTweet @vine @blakeparnham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BLACK PPL TWEET",
        "screen_name" : "BlackPplTweet",
        "indices" : [ 0, 14 ],
        "id_str" : "1138569926",
        "id" : 1138569926
      }, {
        "name" : "Blake Parnham",
        "screen_name" : "blakeparnham",
        "indices" : [ 21, 34 ],
        "id_str" : "275173888",
        "id" : 275173888
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "787703723279736832",
    "geo" : { },
    "id_str" : "787708107405324288",
    "in_reply_to_user_id" : 1138569926,
    "text" : "@BlackPplTweet @vine @blakeparnham",
    "id" : 787708107405324288,
    "in_reply_to_status_id" : 787703723279736832,
    "created_at" : "2016-10-16 17:33:42 +0000",
    "in_reply_to_screen_name" : "BlackPplTweet",
    "in_reply_to_user_id_str" : "1138569926",
    "user" : {
      "name" : "Nick",
      "screen_name" : "nickpar12",
      "protected" : false,
      "id_str" : "3249449702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736724349260992513\/E5tSCzEb_normal.jpg",
      "id" : 3249449702,
      "verified" : false
    }
  },
  "id" : 787737214910431232,
  "created_at" : "2016-10-16 19:29:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ExYcIdQ8Z1",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNHX4kvzuCh82g2b6XyMsw0oSuF7dQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779243798656&ei=rdMDWJDNKpCAuQLh1YHgBA&url=http%3A%2F%2Fwww.freep.com%2Fstory%2Fsports%2Fcollege%2Funiversity-michigan%2Fwolverines%2F2016%2F10%2F16%2Fmichigan-football-top-25-polls%2F92194796%2F&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787737052620132352",
  "text" : "RT @andikhm01: In the polls: Michigan football stays 4th in coaches, up to 3rd in AP - Detroit Free Press https:\/\/t.co\/ExYcIdQ8Z1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ExYcIdQ8Z1",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNHX4kvzuCh82g2b6XyMsw0oSuF7dQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779243798656&ei=rdMDWJDNKpCAuQLh1YHgBA&url=http%3A%2F%2Fwww.freep.com%2Fstory%2Fsports%2Fcollege%2Funiversity-michigan%2Fwolverines%2F2016%2F10%2F16%2Fmichigan-football-top-25-polls%2F92194796%2F&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787735763894939648",
    "text" : "In the polls: Michigan football stays 4th in coaches, up to 3rd in AP - Detroit Free Press https:\/\/t.co\/ExYcIdQ8Z1",
    "id" : 787735763894939648,
    "created_at" : "2016-10-16 19:23:36 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 787737052620132352,
  "created_at" : "2016-10-16 19:28:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "indices" : [ 3, 12 ],
      "id_str" : "40369362",
      "id" : 40369362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motoress",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "riders",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/wj2F4wfm5U",
      "expanded_url" : "http:\/\/paper.li\/MOTORESS\/1388351969?edition_id=9c015fd0-933e-11e6-b525-0cc47a0d164b",
      "display_url" : "paper.li\/MOTORESS\/13883\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787737017241174017",
  "text" : "RT @MOTORESS: The MOTORESS Daily is out! https:\/\/t.co\/wj2F4wfm5U #motoress #riders",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "motoress",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "riders",
        "indices" : [ 61, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/wj2F4wfm5U",
        "expanded_url" : "http:\/\/paper.li\/MOTORESS\/1388351969?edition_id=9c015fd0-933e-11e6-b525-0cc47a0d164b",
        "display_url" : "paper.li\/MOTORESS\/13883\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787462983421231104",
    "text" : "The MOTORESS Daily is out! https:\/\/t.co\/wj2F4wfm5U #motoress #riders",
    "id" : 787462983421231104,
    "created_at" : "2016-10-16 01:19:40 +0000",
    "user" : {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "protected" : false,
      "id_str" : "40369362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408819496521729\/vGa13GuH_normal.jpg",
      "id" : 40369362,
      "verified" : false
    }
  },
  "id" : 787737017241174017,
  "created_at" : "2016-10-16 19:28:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "Catrocky22",
      "indices" : [ 3, 14 ],
      "id_str" : "49519644",
      "id" : 49519644
    }, {
      "name" : "Lizzy",
      "screen_name" : "MissLizzyNJ",
      "indices" : [ 16, 28 ],
      "id_str" : "3138440693",
      "id" : 3138440693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787736871761739776",
  "text" : "RT @Catrocky22: @MissLizzyNJ but we're you at target or just the target",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzy",
        "screen_name" : "MissLizzyNJ",
        "indices" : [ 0, 12 ],
        "id_str" : "3138440693",
        "id" : 3138440693
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "787542336419102720",
    "geo" : { },
    "id_str" : "787671726050070530",
    "in_reply_to_user_id" : 718561802787930113,
    "text" : "@MissLizzyNJ but we're you at target or just the target",
    "id" : 787671726050070530,
    "in_reply_to_status_id" : 787542336419102720,
    "created_at" : "2016-10-16 15:09:08 +0000",
    "in_reply_to_screen_name" : "BasedElizabeth",
    "in_reply_to_user_id_str" : "718561802787930113",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "Catrocky22",
      "protected" : false,
      "id_str" : "49519644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774642205923299328\/cvDy-mC8_normal.jpg",
      "id" : 49519644,
      "verified" : false
    }
  },
  "id" : 787736871761739776,
  "created_at" : "2016-10-16 19:28:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald",
      "screen_name" : "1CanAm",
      "indices" : [ 3, 10 ],
      "id_str" : "71987785",
      "id" : 71987785
    }, {
      "name" : "Brett Mac",
      "screen_name" : "TweetBrettMac",
      "indices" : [ 12, 26 ],
      "id_str" : "305211380",
      "id" : 305211380
    }, {
      "name" : "\u2606 Prissy Holly \u2606",
      "screen_name" : "PrissyHolly",
      "indices" : [ 27, 39 ],
      "id_str" : "2712845118",
      "id" : 2712845118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787736242175807488",
  "text" : "RT @1CanAm: @TweetBrettMac @PrissyHolly OMG that's terrible Prissy. Call Gloria Allred immediately. I can see a HUGE settlement. Damn you H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brett Mac",
        "screen_name" : "TweetBrettMac",
        "indices" : [ 0, 14 ],
        "id_str" : "305211380",
        "id" : 305211380
      }, {
        "name" : "\u2606 Prissy Holly \u2606",
        "screen_name" : "PrissyHolly",
        "indices" : [ 15, 27 ],
        "id_str" : "2712845118",
        "id" : 2712845118
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "787459586512912384",
    "geo" : { },
    "id_str" : "787477159988170752",
    "in_reply_to_user_id" : 305211380,
    "text" : "@TweetBrettMac @PrissyHolly OMG that's terrible Prissy. Call Gloria Allred immediately. I can see a HUGE settlement. Damn you Hillary.",
    "id" : 787477159988170752,
    "in_reply_to_status_id" : 787459586512912384,
    "created_at" : "2016-10-16 02:16:00 +0000",
    "in_reply_to_screen_name" : "TweetBrettMac",
    "in_reply_to_user_id_str" : "305211380",
    "user" : {
      "name" : "Donald",
      "screen_name" : "1CanAm",
      "protected" : false,
      "id_str" : "71987785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453357712189820929\/xNk56YnC_normal.jpeg",
      "id" : 71987785,
      "verified" : false
    }
  },
  "id" : 787736242175807488,
  "created_at" : "2016-10-16 19:25:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kalasia Richer",
      "screen_name" : "KalasiaRicher",
      "indices" : [ 3, 17 ],
      "id_str" : "780221365202944004",
      "id" : 780221365202944004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillaryBecause",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787463006045270017",
  "text" : "RT @KalasiaRicher: YES I am a member of the black community and NO I am not with #HillaryBecause she referred to black males as predators.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillaryBecause",
        "indices" : [ 62, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787317276735336448",
    "text" : "YES I am a member of the black community and NO I am not with #HillaryBecause she referred to black males as predators.",
    "id" : 787317276735336448,
    "created_at" : "2016-10-15 15:40:41 +0000",
    "user" : {
      "name" : "Kalasia Richer",
      "screen_name" : "KalasiaRicher",
      "protected" : false,
      "id_str" : "780221365202944004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839131934232047616\/jMIIxhw4_normal.jpg",
      "id" : 780221365202944004,
      "verified" : false
    }
  },
  "id" : 787463006045270017,
  "created_at" : "2016-10-16 01:19:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillaryBecause",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462845499867136",
  "text" : "RT @scrowder: #HillaryBecause the complete silence from media on Wikileaks tells you that all you need is money and a (D) next to your name.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillaryBecause",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787418573224480768",
    "text" : "#HillaryBecause the complete silence from media on Wikileaks tells you that all you need is money and a (D) next to your name.",
    "id" : 787418573224480768,
    "created_at" : "2016-10-15 22:23:12 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 787462845499867136,
  "created_at" : "2016-10-16 01:19:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory George, MS",
      "screen_name" : "IamCoryGeorge",
      "indices" : [ 3, 17 ],
      "id_str" : "77620039",
      "id" : 77620039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462805788262400",
  "text" : "RT @IamCoryGeorge: Every door that's open isn't worth walking through and every door that's closed isn't safe enough to open.\u00A0 Plan your jo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787422419174694912",
    "text" : "Every door that's open isn't worth walking through and every door that's closed isn't safe enough to open.\u00A0 Plan your journey carefully.  CG",
    "id" : 787422419174694912,
    "created_at" : "2016-10-15 22:38:28 +0000",
    "user" : {
      "name" : "Cory George, MS",
      "screen_name" : "IamCoryGeorge",
      "protected" : false,
      "id_str" : "77620039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838749859817664512\/1zYcZqtS_normal.jpg",
      "id" : 77620039,
      "verified" : false
    }
  },
  "id" : 787462805788262400,
  "created_at" : "2016-10-16 01:18:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/787345498755727360\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Yg56PoPTX3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu02jYbXEAApetd.jpg",
      "id_str" : "787345491340234752",
      "id" : 787345491340234752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu02jYbXEAApetd.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1075
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1834
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1834
      } ],
      "display_url" : "pic.twitter.com\/Yg56PoPTX3"
    } ],
    "hashtags" : [ {
      "text" : "HillaryBecause",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462682823757824",
  "text" : "RT @KassyDillon: #HillaryBecause I wanted to scare the neighborhood children. https:\/\/t.co\/Yg56PoPTX3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/787345498755727360\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/Yg56PoPTX3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu02jYbXEAApetd.jpg",
        "id_str" : "787345491340234752",
        "id" : 787345491340234752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu02jYbXEAApetd.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1075
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1834
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1834
        } ],
        "display_url" : "pic.twitter.com\/Yg56PoPTX3"
      } ],
      "hashtags" : [ {
        "text" : "HillaryBecause",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787345498755727360",
    "text" : "#HillaryBecause I wanted to scare the neighborhood children. https:\/\/t.co\/Yg56PoPTX3",
    "id" : 787345498755727360,
    "created_at" : "2016-10-15 17:32:49 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 787462682823757824,
  "created_at" : "2016-10-16 01:18:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/oJ61Y5wxY6",
      "expanded_url" : "https:\/\/twitter.com\/freebeacon\/status\/787069224292261888",
      "display_url" : "twitter.com\/freebeacon\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787462598480498688",
  "text" : "RT @tedcruz: \"The federal government ran a deficit of $587 billion despite the record revenue.\" https:\/\/t.co\/oJ61Y5wxY6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/oJ61Y5wxY6",
        "expanded_url" : "https:\/\/twitter.com\/freebeacon\/status\/787069224292261888",
        "display_url" : "twitter.com\/freebeacon\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787370647529791488",
    "text" : "\"The federal government ran a deficit of $587 billion despite the record revenue.\" https:\/\/t.co\/oJ61Y5wxY6",
    "id" : 787370647529791488,
    "created_at" : "2016-10-15 19:12:45 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 787462598480498688,
  "created_at" : "2016-10-16 01:18:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462507564765184",
  "text" : "RT @Evan_McMullin: The civilians who al-Assad's slaughtering are our brothers &amp; sisters. We should be a leader among nations against tyrann\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787334079062478849",
    "text" : "The civilians who al-Assad's slaughtering are our brothers &amp; sisters. We should be a leader among nations against tyranny anywhere it exists",
    "id" : 787334079062478849,
    "created_at" : "2016-10-15 16:47:27 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 787462507564765184,
  "created_at" : "2016-10-16 01:17:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 32, 46 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Idaho",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kp0a1iXe2e",
      "expanded_url" : "https:\/\/www.facebook.com\/mcmullinforpresident\/videos\/1633650733599258\/",
      "display_url" : "facebook.com\/mcmullinforpre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787462426719551488",
  "text" : "RT @TeamMcMullin: If you missed @Evan_McMullin's event tonight in #Idaho, the video is up now on his Facebook page: https:\/\/t.co\/kp0a1iXe2e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 14, 28 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Idaho",
        "indices" : [ 48, 54 ]
      }, {
        "text" : "McMullinFinn",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/kp0a1iXe2e",
        "expanded_url" : "https:\/\/www.facebook.com\/mcmullinforpresident\/videos\/1633650733599258\/",
        "display_url" : "facebook.com\/mcmullinforpre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787114271440109569",
    "text" : "If you missed @Evan_McMullin's event tonight in #Idaho, the video is up now on his Facebook page: https:\/\/t.co\/kp0a1iXe2e #McMullinFinn",
    "id" : 787114271440109569,
    "created_at" : "2016-10-15 02:14:00 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 787462426719551488,
  "created_at" : "2016-10-16 01:17:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462351884808192",
  "text" : "RT @Evan_McMullin: I'm running for President because I simply felt that it had to be done. It's nothing short of a miracle that we've gotte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787110443672141828",
    "text" : "I'm running for President because I simply felt that it had to be done. It's nothing short of a miracle that we've gotten this far.",
    "id" : 787110443672141828,
    "created_at" : "2016-10-15 01:58:48 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 787462351884808192,
  "created_at" : "2016-10-16 01:17:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787462315130191872",
  "text" : "RT @Evan_McMullin: I don't know of a single successful counterterrorism operation that didn't have Muslims helping, including killing Osama\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787109155488149504",
    "text" : "I don't know of a single successful counterterrorism operation that didn't have Muslims helping, including killing Osama bin Laden",
    "id" : 787109155488149504,
    "created_at" : "2016-10-15 01:53:41 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 787462315130191872,
  "created_at" : "2016-10-16 01:17:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 3, 14 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/X0454bYmxv",
      "expanded_url" : "http:\/\/vine.co\/v\/hxXU6iL6ZTp",
      "display_url" : "vine.co\/v\/hxXU6iL6ZTp"
    } ]
  },
  "geo" : { },
  "id_str" : "787462283077246976",
  "text" : "RT @WWEXStream: She tried to play it off like she wasn't staring.. https:\/\/t.co\/X0454bYmxv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/X0454bYmxv",
        "expanded_url" : "http:\/\/vine.co\/v\/hxXU6iL6ZTp",
        "display_url" : "vine.co\/v\/hxXU6iL6ZTp"
      } ]
    },
    "geo" : { },
    "id_str" : "787461108173008896",
    "text" : "She tried to play it off like she wasn't staring.. https:\/\/t.co\/X0454bYmxv",
    "id" : 787461108173008896,
    "created_at" : "2016-10-16 01:12:13 +0000",
    "user" : {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "protected" : false,
      "id_str" : "305791165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465976113496223744\/iEGR6Kkr_normal.jpeg",
      "id" : 305791165,
      "verified" : false
    }
  },
  "id" : 787462283077246976,
  "created_at" : "2016-10-16 01:16:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787461974141595648\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/pRd3k3giXk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu2gfFsWYAA4Xf-.jpg",
      "id_str" : "787461965824286720",
      "id" : 787461965824286720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu2gfFsWYAA4Xf-.jpg",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/pRd3k3giXk"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787461974141595648\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/pRd3k3giXk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu2gfFqWEAA864y.jpg",
      "id_str" : "787461965815877632",
      "id" : 787461965815877632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu2gfFqWEAA864y.jpg",
      "sizes" : [ {
        "h" : 823,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 529
      } ],
      "display_url" : "pic.twitter.com\/pRd3k3giXk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787461974141595648",
  "text" : "Why can't girls ever say they like Egyptians \uD83D\uDE3F\uD83D\uDE3F\uD83D\uDE3F https:\/\/t.co\/pRd3k3giXk",
  "id" : 787461974141595648,
  "created_at" : "2016-10-16 01:15:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Idaho",
      "indices" : [ 109, 115 ]
    }, {
      "text" : "McMullinFinn",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787323360187416576",
  "text" : "RT @TeamMcMullin: We announced this Idaho Falls event less than 24 hours ago. Standing room only. Thank you, #Idaho! #McMullinFinn #McMulli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/787099049270706176\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/Z4TRKMsEOj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuxWXhLUAAAaRYu.jpg",
        "id_str" : "787098996925792256",
        "id" : 787098996925792256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuxWXhLUAAAaRYu.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/Z4TRKMsEOj"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/787099049270706176\/photo\/1",
        "indices" : [ 129, 152 ],
        "url" : "https:\/\/t.co\/Z4TRKMsEOj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuxWXhgVIAAxapA.jpg",
        "id_str" : "787098997013946368",
        "id" : 787098997013946368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuxWXhgVIAAxapA.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/Z4TRKMsEOj"
      } ],
      "hashtags" : [ {
        "text" : "Idaho",
        "indices" : [ 91, 97 ]
      }, {
        "text" : "McMullinFinn",
        "indices" : [ 99, 112 ]
      }, {
        "text" : "McMullinmentum",
        "indices" : [ 113, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787099049270706176",
    "text" : "We announced this Idaho Falls event less than 24 hours ago. Standing room only. Thank you, #Idaho! #McMullinFinn #McMullinmentum https:\/\/t.co\/Z4TRKMsEOj",
    "id" : 787099049270706176,
    "created_at" : "2016-10-15 01:13:31 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 787323360187416576,
  "created_at" : "2016-10-15 16:04:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787323234224144384",
  "text" : "RT @lorenridinger: \"Circumstances don't defeat you -you defeat yourself when you give up.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787322266669477888",
    "text" : "\"Circumstances don't defeat you -you defeat yourself when you give up.\"",
    "id" : 787322266669477888,
    "created_at" : "2016-10-15 16:00:30 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 787323234224144384,
  "created_at" : "2016-10-15 16:04:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "indices" : [ 3, 14 ],
      "id_str" : "552147406",
      "id" : 552147406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787323177416392704",
  "text" : "RT @TriviaHive: Armadillos have 104 teeth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787322456889520128",
    "text" : "Armadillos have 104 teeth",
    "id" : 787322456889520128,
    "created_at" : "2016-10-15 16:01:16 +0000",
    "user" : {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "protected" : false,
      "id_str" : "552147406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705567159968071680\/PQrm33In_normal.jpg",
      "id" : 552147406,
      "verified" : false
    }
  },
  "id" : 787323177416392704,
  "created_at" : "2016-10-15 16:04:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Felder",
      "screen_name" : "jessefelder",
      "indices" : [ 3, 15 ],
      "id_str" : "1473431",
      "id" : 1473431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787323151676039168",
  "text" : "RT @jessefelder: \"A stock operator has to fight a lot of expensive enemies within himself.\" -Jesse Livermore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "787313018375774208",
    "text" : "\"A stock operator has to fight a lot of expensive enemies within himself.\" -Jesse Livermore",
    "id" : 787313018375774208,
    "created_at" : "2016-10-15 15:23:45 +0000",
    "user" : {
      "name" : "Jesse Felder",
      "screen_name" : "jessefelder",
      "protected" : false,
      "id_str" : "1473431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742476847879839745\/M6qrNdak_normal.jpg",
      "id" : 1473431,
      "verified" : false
    }
  },
  "id" : 787323151676039168,
  "created_at" : "2016-10-15 16:04:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Kerry Davis",
      "screen_name" : "mskerryd",
      "indices" : [ 82, 91 ],
      "id_str" : "176605257",
      "id" : 176605257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/787322581225320448\/video\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/3z8sS9ff1U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu0htQQVYAA8yZH.jpg",
      "id_str" : "787322183571824640",
      "id" : 787322183571824640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu0htQQVYAA8yZH.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3z8sS9ff1U"
    } ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/22WRtTSsEc",
      "expanded_url" : "http:\/\/engt.co\/2e3bwbX",
      "display_url" : "engt.co\/2e3bwbX"
    } ]
  },
  "geo" : { },
  "id_str" : "787323122710089728",
  "text" : "RT @engadget: #ICYMI: The alcohol creating energy, removing pollution and more by @mskerryd https:\/\/t.co\/22WRtTSsEc https:\/\/t.co\/3z8sS9ff1U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kerry Davis",
        "screen_name" : "mskerryd",
        "indices" : [ 68, 77 ],
        "id_str" : "176605257",
        "id" : 176605257
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/787322581225320448\/video\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/3z8sS9ff1U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu0htQQVYAA8yZH.jpg",
        "id_str" : "787322183571824640",
        "id" : 787322183571824640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu0htQQVYAA8yZH.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/3z8sS9ff1U"
      } ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/22WRtTSsEc",
        "expanded_url" : "http:\/\/engt.co\/2e3bwbX",
        "display_url" : "engt.co\/2e3bwbX"
      } ]
    },
    "geo" : { },
    "id_str" : "787322581225320448",
    "text" : "#ICYMI: The alcohol creating energy, removing pollution and more by @mskerryd https:\/\/t.co\/22WRtTSsEc https:\/\/t.co\/3z8sS9ff1U",
    "id" : 787322581225320448,
    "created_at" : "2016-10-15 16:01:45 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 787323122710089728,
  "created_at" : "2016-10-15 16:03:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/vwsG423IXr",
      "expanded_url" : "http:\/\/bit.ly\/2e3fjWy",
      "display_url" : "bit.ly\/2e3fjWy"
    } ]
  },
  "geo" : { },
  "id_str" : "787323028678017024",
  "text" : "RT @Tearieeror: Tata Motors Buka 3 Diler Baru Berkonsep 3 S https:\/\/t.co\/vwsG423IXr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/vwsG423IXr",
        "expanded_url" : "http:\/\/bit.ly\/2e3fjWy",
        "display_url" : "bit.ly\/2e3fjWy"
      } ]
    },
    "geo" : { },
    "id_str" : "787322619888402433",
    "text" : "Tata Motors Buka 3 Diler Baru Berkonsep 3 S https:\/\/t.co\/vwsG423IXr",
    "id" : 787322619888402433,
    "created_at" : "2016-10-15 16:01:54 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 787323028678017024,
  "created_at" : "2016-10-15 16:03:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/0nNP4r1mEH",
      "expanded_url" : "http:\/\/bit.ly\/2e3fZv1",
      "display_url" : "bit.ly\/2e3fZv1"
    } ]
  },
  "geo" : { },
  "id_str" : "787323010814468096",
  "text" : "RT @Tearieeror: Honda BR-V Kian Mantap Jadi Raja di Segmen Low SUV https:\/\/t.co\/0nNP4r1mEH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/0nNP4r1mEH",
        "expanded_url" : "http:\/\/bit.ly\/2e3fZv1",
        "display_url" : "bit.ly\/2e3fZv1"
      } ]
    },
    "geo" : { },
    "id_str" : "787322622350471170",
    "text" : "Honda BR-V Kian Mantap Jadi Raja di Segmen Low SUV https:\/\/t.co\/0nNP4r1mEH",
    "id" : 787322622350471170,
    "created_at" : "2016-10-15 16:01:55 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 787323010814468096,
  "created_at" : "2016-10-15 16:03:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/BSmDYOjiwc",
      "expanded_url" : "http:\/\/ow.ly\/A9YW3057dEU",
      "display_url" : "ow.ly\/A9YW3057dEU"
    } ]
  },
  "geo" : { },
  "id_str" : "787322947698618368",
  "text" : "RT @analyticbridge: The seven people you need on your Big Data team https:\/\/t.co\/BSmDYOjiwc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/BSmDYOjiwc",
        "expanded_url" : "http:\/\/ow.ly\/A9YW3057dEU",
        "display_url" : "ow.ly\/A9YW3057dEU"
      } ]
    },
    "geo" : { },
    "id_str" : "787322650548994048",
    "text" : "The seven people you need on your Big Data team https:\/\/t.co\/BSmDYOjiwc",
    "id" : 787322650548994048,
    "created_at" : "2016-10-15 16:02:02 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 787322947698618368,
  "created_at" : "2016-10-15 16:03:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/787313379568386048\/video\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Z9kyqcxRTV",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787313331115884544\/pu\/img\/i6gppZFhHxy8IguK.jpg",
      "id_str" : "787313331115884544",
      "id" : 787313331115884544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787313331115884544\/pu\/img\/i6gppZFhHxy8IguK.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Z9kyqcxRTV"
    } ],
    "hashtags" : [ {
      "text" : "LWC",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/7HYX4KvGlm",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=xBPubpz0hgg",
      "display_url" : "youtube.com\/watch?v=xBPubp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787322853247086592",
  "text" : "RT @scrowder: It's another installment of Ken Bone! Catch the rest on #LWC! FULL SHOW &gt;&gt; https:\/\/t.co\/7HYX4KvGlm https:\/\/t.co\/Z9kyqcxRTV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/787313379568386048\/video\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Z9kyqcxRTV",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787313331115884544\/pu\/img\/i6gppZFhHxy8IguK.jpg",
        "id_str" : "787313331115884544",
        "id" : 787313331115884544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/787313331115884544\/pu\/img\/i6gppZFhHxy8IguK.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Z9kyqcxRTV"
      } ],
      "hashtags" : [ {
        "text" : "LWC",
        "indices" : [ 56, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/7HYX4KvGlm",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=xBPubpz0hgg",
        "display_url" : "youtube.com\/watch?v=xBPubp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "787313379568386048",
    "text" : "It's another installment of Ken Bone! Catch the rest on #LWC! FULL SHOW &gt;&gt; https:\/\/t.co\/7HYX4KvGlm https:\/\/t.co\/Z9kyqcxRTV",
    "id" : 787313379568386048,
    "created_at" : "2016-10-15 15:25:11 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 787322853247086592,
  "created_at" : "2016-10-15 16:02:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 0, 9 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 10, 22 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/787322782296268800\/photo\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/3zr5Kdnd8o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cu0h5P9WIAAA67N.jpg",
      "id_str" : "787322777279799296",
      "id" : 787322777279799296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cu0h5P9WIAAA67N.jpg",
      "sizes" : [ {
        "h" : 207,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 352
      } ],
      "display_url" : "pic.twitter.com\/3zr5Kdnd8o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787322782296268800",
  "in_reply_to_user_id" : 19091173,
  "text" : "@scrowder @KassyDillon The woman loving liberal response to why porn is bad and people should love woman for their hearts. https:\/\/t.co\/3zr5Kdnd8o",
  "id" : 787322782296268800,
  "created_at" : "2016-10-15 16:02:33 +0000",
  "in_reply_to_screen_name" : "scrowder",
  "in_reply_to_user_id_str" : "19091173",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Gallagher",
      "screen_name" : "TotallySketch",
      "indices" : [ 0, 14 ],
      "id_str" : "20419946",
      "id" : 20419946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786738226501419008",
  "in_reply_to_user_id" : 20419946,
  "text" : "@TotallySketch Your humor becomes more and more dry \uD83D\uDE02",
  "id" : 786738226501419008,
  "created_at" : "2016-10-14 01:19:44 +0000",
  "in_reply_to_screen_name" : "TotallySketch",
  "in_reply_to_user_id_str" : "20419946",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Nelson",
      "screen_name" : "Stevo10211Steve",
      "indices" : [ 3, 19 ],
      "id_str" : "1007989718",
      "id" : 1007989718
    }, {
      "name" : "M. Salinas",
      "screen_name" : "okMute",
      "indices" : [ 21, 28 ],
      "id_str" : "1380717900",
      "id" : 1380717900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786737932753367040",
  "text" : "RT @Stevo10211Steve: @okMute May as well be Bozo and Broom Hilda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M. Salinas",
        "screen_name" : "okMute",
        "indices" : [ 0, 7 ],
        "id_str" : "1380717900",
        "id" : 1380717900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785525208752939008",
    "geo" : { },
    "id_str" : "786657186063773696",
    "in_reply_to_user_id" : 1380717900,
    "text" : "@okMute May as well be Bozo and Broom Hilda",
    "id" : 786657186063773696,
    "in_reply_to_status_id" : 785525208752939008,
    "created_at" : "2016-10-13 19:57:43 +0000",
    "in_reply_to_screen_name" : "okMute",
    "in_reply_to_user_id_str" : "1380717900",
    "user" : {
      "name" : "Steve Nelson",
      "screen_name" : "Stevo10211Steve",
      "protected" : false,
      "id_str" : "1007989718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877355470750715904\/PHQRA8UI_normal.jpg",
      "id" : 1007989718,
      "verified" : false
    }
  },
  "id" : 786737932753367040,
  "created_at" : "2016-10-14 01:18:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/zj0jkSN8eX",
      "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=96&edit=0&userid=1",
      "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "786737691639607296",
  "text" : "RT @BestGamezUp: 10 Consoles That Failed Too Hard For Anyone to Even Notice Them https:\/\/t.co\/zj0jkSN8eX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/zj0jkSN8eX",
        "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=96&edit=0&userid=1",
        "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786734563552849921",
    "text" : "10 Consoles That Failed Too Hard For Anyone to Even Notice Them https:\/\/t.co\/zj0jkSN8eX",
    "id" : 786734563552849921,
    "created_at" : "2016-10-14 01:05:11 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 786737691639607296,
  "created_at" : "2016-10-14 01:17:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A henny has no chase",
      "screen_name" : "hanginwitcoop",
      "indices" : [ 3, 17 ],
      "id_str" : "126096796",
      "id" : 126096796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786737437024419840",
  "text" : "RT @hanginwitcoop: It's weird when ppl text you out the blue and don't hold a conversation. Like why did you even reach out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786732665198276608",
    "text" : "It's weird when ppl text you out the blue and don't hold a conversation. Like why did you even reach out.",
    "id" : 786732665198276608,
    "created_at" : "2016-10-14 00:57:38 +0000",
    "user" : {
      "name" : "A henny has no chase",
      "screen_name" : "hanginwitcoop",
      "protected" : false,
      "id_str" : "126096796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884971122751569920\/NDrMcAYX_normal.jpg",
      "id" : 126096796,
      "verified" : false
    }
  },
  "id" : 786737437024419840,
  "created_at" : "2016-10-14 01:16:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786737041040089088",
  "geo" : { },
  "id_str" : "786737240051486720",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp I just found this humorous for some ironic reason",
  "id" : 786737240051486720,
  "in_reply_to_status_id" : 786737041040089088,
  "created_at" : "2016-10-14 01:15:49 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/493149780902957057\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/pF4rfEC4s0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtgFHOFIYAEs0Li.jpg",
      "id_str" : "493149780793909249",
      "id" : 493149780793909249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtgFHOFIYAEs0Li.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/pF4rfEC4s0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786737124544569346",
  "text" : "RT @BestGamezUp: https:\/\/t.co\/pF4rfEC4s0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/493149780902957057\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/pF4rfEC4s0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtgFHOFIYAEs0Li.jpg",
        "id_str" : "493149780793909249",
        "id" : 493149780793909249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtgFHOFIYAEs0Li.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/pF4rfEC4s0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786737041040089088",
    "text" : "https:\/\/t.co\/pF4rfEC4s0",
    "id" : 786737041040089088,
    "created_at" : "2016-10-14 01:15:02 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 786737124544569346,
  "created_at" : "2016-10-14 01:15:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/786735173425631232\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/PNYxzH1kZs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CusLd8CWgAAIbw7.jpg",
      "id_str" : "786735168866385920",
      "id" : 786735168866385920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusLd8CWgAAIbw7.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/PNYxzH1kZs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/cfD2dkLSuV",
      "expanded_url" : "http:\/\/youtube.com\/stevencrowder",
      "display_url" : "youtube.com\/stevencrowder"
    } ]
  },
  "geo" : { },
  "id_str" : "786736509755990016",
  "text" : "RT @scrowder: Watch live! &gt;&gt; https:\/\/t.co\/cfD2dkLSuV https:\/\/t.co\/PNYxzH1kZs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.newtek.com\" rel=\"nofollow\"\u003ENewTek Publishing App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/786735173425631232\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/PNYxzH1kZs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CusLd8CWgAAIbw7.jpg",
        "id_str" : "786735168866385920",
        "id" : 786735168866385920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CusLd8CWgAAIbw7.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/PNYxzH1kZs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/cfD2dkLSuV",
        "expanded_url" : "http:\/\/youtube.com\/stevencrowder",
        "display_url" : "youtube.com\/stevencrowder"
      } ]
    },
    "geo" : { },
    "id_str" : "786735173425631232",
    "text" : "Watch live! &gt;&gt; https:\/\/t.co\/cfD2dkLSuV https:\/\/t.co\/PNYxzH1kZs",
    "id" : 786735173425631232,
    "created_at" : "2016-10-14 01:07:36 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 786736509755990016,
  "created_at" : "2016-10-14 01:12:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Felton",
      "screen_name" : "hfton15",
      "indices" : [ 3, 11 ],
      "id_str" : "4923804094",
      "id" : 4923804094
    }, {
      "name" : "Jake dicks",
      "screen_name" : "JakeDicks101",
      "indices" : [ 13, 26 ],
      "id_str" : "557685866",
      "id" : 557685866
    }, {
      "name" : "LADbible",
      "screen_name" : "theladbible",
      "indices" : [ 27, 39 ],
      "id_str" : "847846726811754500",
      "id" : 847846726811754500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786736398846005248",
  "text" : "RT @hfton15: @JakeDicks101 @TheLadBible such a shame",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jake dicks",
        "screen_name" : "JakeDicks101",
        "indices" : [ 0, 13 ],
        "id_str" : "557685866",
        "id" : 557685866
      }, {
        "name" : "LADbible",
        "screen_name" : "theladbible",
        "indices" : [ 14, 26 ],
        "id_str" : "847846726811754500",
        "id" : 847846726811754500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "786542144513273856",
    "geo" : { },
    "id_str" : "786542184023588864",
    "in_reply_to_user_id" : 557685866,
    "text" : "@JakeDicks101 @TheLadBible such a shame",
    "id" : 786542184023588864,
    "in_reply_to_status_id" : 786542144513273856,
    "created_at" : "2016-10-13 12:20:44 +0000",
    "in_reply_to_screen_name" : "JakeDicks101",
    "in_reply_to_user_id_str" : "557685866",
    "user" : {
      "name" : "Harry Felton",
      "screen_name" : "hfton15",
      "protected" : false,
      "id_str" : "4923804094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851837102102859777\/IoVCxgiY_normal.jpg",
      "id" : 4923804094,
      "verified" : false
    }
  },
  "id" : 786736398846005248,
  "created_at" : "2016-10-14 01:12:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LADbible",
      "screen_name" : "theladbible",
      "indices" : [ 0, 12 ],
      "id_str" : "847846726811754500",
      "id" : 847846726811754500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786561213731778560",
  "geo" : { },
  "id_str" : "786736270915624960",
  "in_reply_to_user_id" : 331311644,
  "text" : "@TheLadBible This makes me cringe on so many levels",
  "id" : 786736270915624960,
  "in_reply_to_status_id" : 786561213731778560,
  "created_at" : "2016-10-14 01:11:58 +0000",
  "in_reply_to_screen_name" : "ladbible",
  "in_reply_to_user_id_str" : "331311644",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Bowers-Smith",
      "screen_name" : "gemmabowersxo",
      "indices" : [ 3, 17 ],
      "id_str" : "1107103297",
      "id" : 1107103297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HarambesRevenge",
      "indices" : [ 58, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786735544143314944",
  "text" : "RT @gemmabowersxo: This gorilla business is mad in London #HarambesRevenge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HarambesRevenge",
        "indices" : [ 39, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786650019084525568",
    "text" : "This gorilla business is mad in London #HarambesRevenge",
    "id" : 786650019084525568,
    "created_at" : "2016-10-13 19:29:14 +0000",
    "user" : {
      "name" : "Gemma Bowers-Smith",
      "screen_name" : "gemmabowersxo",
      "protected" : false,
      "id_str" : "1107103297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883058920453013505\/zdQtwBzX_normal.jpg",
      "id" : 1107103297,
      "verified" : false
    }
  },
  "id" : 786735544143314944,
  "created_at" : "2016-10-14 01:09:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam Hooper",
      "screen_name" : "liamhooper",
      "indices" : [ 3, 14 ],
      "id_str" : "49444612",
      "id" : 49444612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HarambesRevenge",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786735532294475777",
  "text" : "RT @liamhooper: Driving in London today has been a nightmare. Of course it could only be #HarambesRevenge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HarambesRevenge",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786666317814362112",
    "text" : "Driving in London today has been a nightmare. Of course it could only be #HarambesRevenge",
    "id" : 786666317814362112,
    "created_at" : "2016-10-13 20:34:00 +0000",
    "user" : {
      "name" : "Liam Hooper",
      "screen_name" : "liamhooper",
      "protected" : false,
      "id_str" : "49444612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809182538380017666\/hqfzHDtc_normal.jpg",
      "id" : 49444612,
      "verified" : false
    }
  },
  "id" : 786735532294475777,
  "created_at" : "2016-10-14 01:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheSharkDaymond\/status\/785958041241792513\/video\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/3wvejdIr22",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/785957381490503680\/pu\/img\/pNoGMQhfq7mq4f0H.jpg",
      "id_str" : "785957381490503680",
      "id" : 785957381490503680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/785957381490503680\/pu\/img\/pNoGMQhfq7mq4f0H.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3wvejdIr22"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786734580464230400",
  "text" : "RT @TheSharkDaymond: I can't get enough of this adorable elephant. RT to spread the laughter. https:\/\/t.co\/3wvejdIr22",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheSharkDaymond\/status\/785958041241792513\/video\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/3wvejdIr22",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/785957381490503680\/pu\/img\/pNoGMQhfq7mq4f0H.jpg",
        "id_str" : "785957381490503680",
        "id" : 785957381490503680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/785957381490503680\/pu\/img\/pNoGMQhfq7mq4f0H.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3wvejdIr22"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785958041241792513",
    "text" : "I can't get enough of this adorable elephant. RT to spread the laughter. https:\/\/t.co\/3wvejdIr22",
    "id" : 785958041241792513,
    "created_at" : "2016-10-11 21:39:34 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817056911518482433\/otB2Lkng_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 786734580464230400,
  "created_at" : "2016-10-14 01:05:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikiah Keener",
      "screen_name" : "Mikiah_",
      "indices" : [ 3, 11 ],
      "id_str" : "490784553",
      "id" : 490784553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786734168763953152",
  "text" : "RT @Mikiah_: Without God, I am nothing. \uD83D\uDE4F\uD83C\uDFFE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786590746446958592",
    "text" : "Without God, I am nothing. \uD83D\uDE4F\uD83C\uDFFE",
    "id" : 786590746446958592,
    "created_at" : "2016-10-13 15:33:42 +0000",
    "user" : {
      "name" : "Mikiah Keener",
      "screen_name" : "Mikiah_",
      "protected" : false,
      "id_str" : "490784553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783469408123367424\/3JhIjeLV_normal.jpg",
      "id" : 490784553,
      "verified" : false
    }
  },
  "id" : 786734168763953152,
  "created_at" : "2016-10-14 01:03:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786734141933023232",
  "text" : "Evil doesn't come from God, it comes from people lacking to please God ~ Einstein when he wasn't secular",
  "id" : 786734141933023232,
  "created_at" : "2016-10-14 01:03:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trading Technologies",
      "screen_name" : "Trading_Tech",
      "indices" : [ 3, 16 ],
      "id_str" : "583084442",
      "id" : 583084442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TTMobile",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "ES_F",
      "indices" : [ 44, 49 ]
    }, {
      "text" : "Treasuries",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "Crude",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "natgas",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786732986825895936",
  "text" : "RT @Trading_Tech: Market view on #TTMobile: #ES_F lost a handful while #Treasuries advanced. #Crude added 1\/2% &amp; #natgas ended up almost 4%\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Trading_Tech\/status\/786671109668233220\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/qWfcROsO4n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CurRMygWAAE5UV9.jpg",
        "id_str" : "786671102575640577",
        "id" : 786671102575640577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurRMygWAAE5UV9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        } ],
        "display_url" : "pic.twitter.com\/qWfcROsO4n"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Trading_Tech\/status\/786671109668233220\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/qWfcROsO4n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CurRM6TXEAA8jf-.jpg",
        "id_str" : "786671104668667904",
        "id" : 786671104668667904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurRM6TXEAA8jf-.jpg",
        "sizes" : [ {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/qWfcROsO4n"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Trading_Tech\/status\/786671109668233220\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/qWfcROsO4n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CurRMztWAAAV8dH.jpg",
        "id_str" : "786671102898601984",
        "id" : 786671102898601984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurRMztWAAAV8dH.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        } ],
        "display_url" : "pic.twitter.com\/qWfcROsO4n"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Trading_Tech\/status\/786671109668233220\/photo\/1",
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/qWfcROsO4n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CurRMz-WcAA1pKd.jpg",
        "id_str" : "786671102969933824",
        "id" : 786671102969933824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CurRMz-WcAA1pKd.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        } ],
        "display_url" : "pic.twitter.com\/qWfcROsO4n"
      } ],
      "hashtags" : [ {
        "text" : "TTMobile",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "ES_F",
        "indices" : [ 26, 31 ]
      }, {
        "text" : "Treasuries",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "Crude",
        "indices" : [ 75, 81 ]
      }, {
        "text" : "natgas",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786671109668233220",
    "text" : "Market view on #TTMobile: #ES_F lost a handful while #Treasuries advanced. #Crude added 1\/2% &amp; #natgas ended up almost 4%. https:\/\/t.co\/qWfcROsO4n",
    "id" : 786671109668233220,
    "created_at" : "2016-10-13 20:53:02 +0000",
    "user" : {
      "name" : "Trading Technologies",
      "screen_name" : "Trading_Tech",
      "protected" : false,
      "id_str" : "583084442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562329242390626304\/DYVIftSY_normal.png",
      "id" : 583084442,
      "verified" : true
    }
  },
  "id" : 786732986825895936,
  "created_at" : "2016-10-14 00:58:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RealClearDefense",
      "screen_name" : "RCDefense",
      "indices" : [ 3, 13 ],
      "id_str" : "1222716350",
      "id" : 1222716350
    }, {
      "name" : "Military.com",
      "screen_name" : "Militarydotcom",
      "indices" : [ 71, 86 ],
      "id_str" : "14692385",
      "id" : 14692385
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/uCbUKMuqNa",
      "expanded_url" : "http:\/\/bit.ly\/2dM4vwJ",
      "display_url" : "bit.ly\/2dM4vwJ"
    } ]
  },
  "geo" : { },
  "id_str" : "786732907759099904",
  "text" : "RT @RCDefense: White House Predicts Deadly Drone Attacks in U.S. | via @Militarydotcom #drones https:\/\/t.co\/uCbUKMuqNa https:\/\/t.co\/YJk0BdY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Military.com",
        "screen_name" : "Militarydotcom",
        "indices" : [ 56, 71 ],
        "id_str" : "14692385",
        "id" : 14692385
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RCDefense\/status\/786672105924341760\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/YJk0BdYLGa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CupkJdZVIAALNS5.jpg",
        "id_str" : "786551198602043392",
        "id" : 786551198602043392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CupkJdZVIAALNS5.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/YJk0BdYLGa"
      } ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/uCbUKMuqNa",
        "expanded_url" : "http:\/\/bit.ly\/2dM4vwJ",
        "display_url" : "bit.ly\/2dM4vwJ"
      } ]
    },
    "geo" : { },
    "id_str" : "786672105924341760",
    "text" : "White House Predicts Deadly Drone Attacks in U.S. | via @Militarydotcom #drones https:\/\/t.co\/uCbUKMuqNa https:\/\/t.co\/YJk0BdYLGa",
    "id" : 786672105924341760,
    "created_at" : "2016-10-13 20:57:00 +0000",
    "user" : {
      "name" : "RealClearDefense",
      "screen_name" : "RCDefense",
      "protected" : false,
      "id_str" : "1222716350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767795867487236096\/PGpb9e42_normal.jpg",
      "id" : 1222716350,
      "verified" : true
    }
  },
  "id" : 786732907759099904,
  "created_at" : "2016-10-14 00:58:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reg \/ Video Edits",
      "screen_name" : "RegularMoments",
      "indices" : [ 0, 15 ],
      "id_str" : "704091384123412480",
      "id" : 704091384123412480
    }, {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 16, 31 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    }, {
      "name" : "Jaclyn Glenn",
      "screen_name" : "JaclynGlenn",
      "indices" : [ 32, 44 ],
      "id_str" : "397756361",
      "id" : 397756361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786675611578368000",
  "geo" : { },
  "id_str" : "786732707531358208",
  "in_reply_to_user_id" : 704091384123412480,
  "text" : "@RegularMoments @AvalloneHunter @JaclynGlenn I know right?",
  "id" : 786732707531358208,
  "in_reply_to_status_id" : 786675611578368000,
  "created_at" : "2016-10-14 00:57:48 +0000",
  "in_reply_to_screen_name" : "RegularMoments",
  "in_reply_to_user_id_str" : "704091384123412480",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 0, 15 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    }, {
      "name" : "Jaclyn Glenn",
      "screen_name" : "JaclynGlenn",
      "indices" : [ 16, 28 ],
      "id_str" : "397756361",
      "id" : 397756361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786326249723469825",
  "geo" : { },
  "id_str" : "786732535548182528",
  "in_reply_to_user_id" : 2575373509,
  "text" : "@AvalloneHunter @JaclynGlenn Don't soften up Hunter, the first video was 100% true.",
  "id" : 786732535548182528,
  "in_reply_to_status_id" : 786326249723469825,
  "created_at" : "2016-10-14 00:57:07 +0000",
  "in_reply_to_screen_name" : "AvalloneHunter",
  "in_reply_to_user_id_str" : "2575373509",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 0, 9 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786726395208753156",
  "geo" : { },
  "id_str" : "786732095406280704",
  "in_reply_to_user_id" : 19091173,
  "text" : "@scrowder He does look like Professor X",
  "id" : 786732095406280704,
  "in_reply_to_status_id" : 786726395208753156,
  "created_at" : "2016-10-14 00:55:22 +0000",
  "in_reply_to_screen_name" : "scrowder",
  "in_reply_to_user_id_str" : "19091173",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 0, 10 ],
      "id_str" : "17454769",
      "id" : 17454769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786731978695536641",
  "in_reply_to_user_id" : 17454769,
  "text" : "@glennbeck I'm glad Beck is supporting a constitutionalist rather than a liberal fraud who has an R next to his name",
  "id" : 786731978695536641,
  "created_at" : "2016-10-14 00:54:55 +0000",
  "in_reply_to_screen_name" : "glennbeck",
  "in_reply_to_user_id_str" : "17454769",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 3, 13 ],
      "id_str" : "17454769",
      "id" : 17454769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/0UdmHWVD6w",
      "expanded_url" : "http:\/\/ow.ly\/QaBT3059P8y",
      "display_url" : "ow.ly\/QaBT3059P8y"
    } ]
  },
  "geo" : { },
  "id_str" : "786731690517524480",
  "text" : "RT @glennbeck: Evan McMullin: We Must Seek Honest, Wise Leaders, Not Merely Those the Party Gave Us https:\/\/t.co\/0UdmHWVD6w https:\/\/t.co\/lX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/glennbeck\/status\/786650991965986816\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/lXQVmnp8DR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cuq-6ADXYAAP5Ri.jpg",
        "id_str" : "786650988585377792",
        "id" : 786650988585377792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cuq-6ADXYAAP5Ri.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/lXQVmnp8DR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/0UdmHWVD6w",
        "expanded_url" : "http:\/\/ow.ly\/QaBT3059P8y",
        "display_url" : "ow.ly\/QaBT3059P8y"
      } ]
    },
    "geo" : { },
    "id_str" : "786650991965986816",
    "text" : "Evan McMullin: We Must Seek Honest, Wise Leaders, Not Merely Those the Party Gave Us https:\/\/t.co\/0UdmHWVD6w https:\/\/t.co\/lXQVmnp8DR",
    "id" : 786650991965986816,
    "created_at" : "2016-10-13 19:33:06 +0000",
    "user" : {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "protected" : false,
      "id_str" : "17454769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535418462491791361\/NZmf8ftP_normal.jpeg",
      "id" : 17454769,
      "verified" : true
    }
  },
  "id" : 786731690517524480,
  "created_at" : "2016-10-14 00:53:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 3, 13 ],
      "id_str" : "4248211",
      "id" : 4248211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mcmullinfinn2016",
      "indices" : [ 105, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786731052308062208",
  "text" : "RT @mindyfinn: Didn't mind waking up to this in Utah. Thanks to all of our supporters. You are the best! #mcmullinfinn2016 https:\/\/t.co\/ZN8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mindyfinn\/status\/786572296295026688\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ZN8hv3LBiO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cup3UXeUsAAVUxo.jpg",
        "id_str" : "786572276711862272",
        "id" : 786572276711862272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cup3UXeUsAAVUxo.jpg",
        "sizes" : [ {
          "h" : 981,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 556,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1674,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1674,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ZN8hv3LBiO"
      } ],
      "hashtags" : [ {
        "text" : "mcmullinfinn2016",
        "indices" : [ 90, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786572296295026688",
    "text" : "Didn't mind waking up to this in Utah. Thanks to all of our supporters. You are the best! #mcmullinfinn2016 https:\/\/t.co\/ZN8hv3LBiO",
    "id" : 786572296295026688,
    "created_at" : "2016-10-13 14:20:23 +0000",
    "user" : {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "protected" : false,
      "id_str" : "4248211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852522140360429568\/TB81_9mn_normal.jpg",
      "id" : 4248211,
      "verified" : true
    }
  },
  "id" : 786731052308062208,
  "created_at" : "2016-10-14 00:51:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon",
      "screen_name" : "obaisimon",
      "indices" : [ 3, 13 ],
      "id_str" : "341354218",
      "id" : 341354218
    }, {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 15, 28 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786730718042918912",
  "text" : "RT @obaisimon: @TeamMcMullin i think \"mullinmentum\" could get some traction, just my two cents",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team McMullin",
        "screen_name" : "TeamMcMullin",
        "indices" : [ 0, 13 ],
        "id_str" : "762792021492895749",
        "id" : 762792021492895749
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "786376149068685312",
    "geo" : { },
    "id_str" : "786377037585928192",
    "in_reply_to_user_id" : 762792021492895749,
    "text" : "@TeamMcMullin i think \"mullinmentum\" could get some traction, just my two cents",
    "id" : 786377037585928192,
    "in_reply_to_status_id" : 786376149068685312,
    "created_at" : "2016-10-13 01:24:30 +0000",
    "in_reply_to_screen_name" : "TeamMcMullin",
    "in_reply_to_user_id_str" : "762792021492895749",
    "user" : {
      "name" : "Simon",
      "screen_name" : "obaisimon",
      "protected" : false,
      "id_str" : "341354218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825531396538105856\/1BbUypK0_normal.jpg",
      "id" : 341354218,
      "verified" : false
    }
  },
  "id" : 786730718042918912,
  "created_at" : "2016-10-14 00:49:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786730627127185408",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon If more girls were like you than people would realize that Hillary is a hypocritical feminist who hates woman",
  "id" : 786730627127185408,
  "created_at" : "2016-10-14 00:49:32 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salamingia \u274C",
      "screen_name" : "salamingia",
      "indices" : [ 3, 14 ],
      "id_str" : "415738134",
      "id" : 415738134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786730097038487554",
  "text" : "RT @salamingia: If your name ends with Jr, you automatically qualify to be a NASCAR driver.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786415043009052672",
    "text" : "If your name ends with Jr, you automatically qualify to be a NASCAR driver.",
    "id" : 786415043009052672,
    "created_at" : "2016-10-13 03:55:31 +0000",
    "user" : {
      "name" : "Salamingia \u274C",
      "screen_name" : "salamingia",
      "protected" : false,
      "id_str" : "415738134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884378091778437124\/ouWHyBlu_normal.jpg",
      "id" : 415738134,
      "verified" : false
    }
  },
  "id" : 786730097038487554,
  "created_at" : "2016-10-14 00:47:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786729938086989824",
  "text" : "Can't handle the heat, stay outta the kitchen \uD83D\uDE0E",
  "id" : 786729938086989824,
  "created_at" : "2016-10-14 00:46:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786729578203062272",
  "text" : "Maturity = Wisdom = Common Sense = Logic \"Mind Blown\"",
  "id" : 786729578203062272,
  "created_at" : "2016-10-14 00:45:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786729369465217024",
  "text" : "Girls shouldn't complain about bad relationships if they keep following the wrong guy, doing the same mistakes, or acting in a wrong way",
  "id" : 786729369465217024,
  "created_at" : "2016-10-14 00:44:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/QGHFSV6q9X",
      "expanded_url" : "http:\/\/wapo.st\/2e5pRTF",
      "display_url" : "wapo.st\/2e5pRTF"
    } ]
  },
  "geo" : { },
  "id_str" : "786728905105412096",
  "text" : "RT @washingtonpost: Israeli leaders condemn U.N. resolution on Jerusalem holy site https:\/\/t.co\/QGHFSV6q9X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/QGHFSV6q9X",
        "expanded_url" : "http:\/\/wapo.st\/2e5pRTF",
        "display_url" : "wapo.st\/2e5pRTF"
      } ]
    },
    "geo" : { },
    "id_str" : "786727987840442368",
    "text" : "Israeli leaders condemn U.N. resolution on Jerusalem holy site https:\/\/t.co\/QGHFSV6q9X",
    "id" : 786727987840442368,
    "created_at" : "2016-10-14 00:39:03 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875440182501277696\/n-Ic9nBO_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 786728905105412096,
  "created_at" : "2016-10-14 00:42:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786307501855797248",
  "geo" : { },
  "id_str" : "786728255478984712",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon Good question, better ask google and get back to you",
  "id" : 786728255478984712,
  "in_reply_to_status_id" : 786307501855797248,
  "created_at" : "2016-10-14 00:40:07 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786728130832658432",
  "text" : "I don't know why some emojis even exist \uD83D\uDCA9\uD83C\uDF1D\uD83D\uDD95\uD83C\uDFFC\uD83D\uDC87\uD83C\uDF1A\uD83D\uDD2B\u2620\uD83D\uDD2A\uD83D\uDC8A\uD83D\uDC89\uD83D\uDEBD\u262E\uD83D\uDEB7 Seriously just why?",
  "id" : 786728130832658432,
  "created_at" : "2016-10-14 00:39:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786382435890110464",
  "geo" : { },
  "id_str" : "786727256592875520",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Colored Candy corn is amazing or real homemade kettle corn \uD83D\uDC4F",
  "id" : 786727256592875520,
  "in_reply_to_status_id" : 786382435890110464,
  "created_at" : "2016-10-14 00:36:09 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786726778433900544",
  "text" : "I don't like songs telling young girls they are insecure or to look after a bad guy",
  "id" : 786726778433900544,
  "created_at" : "2016-10-14 00:34:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786726516075945985",
  "text" : "RT @ijustine: SOYLENT LOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786664331651915776",
    "text" : "SOYLENT LOL",
    "id" : 786664331651915776,
    "created_at" : "2016-10-13 20:26:06 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873056728606097408\/KmXQNIx6_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 786726516075945985,
  "created_at" : "2016-10-14 00:33:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "786709674288611328",
  "geo" : { },
  "id_str" : "786726472669073408",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo I wouldn't wanna see normal sized than \uD83D\uDE31",
  "id" : 786726472669073408,
  "in_reply_to_status_id" : 786709674288611328,
  "created_at" : "2016-10-14 00:33:02 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "indices" : [ 3, 18 ],
      "id_str" : "730204715439534080",
      "id" : 730204715439534080
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liberalprivilege",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786726129335988225",
  "text" : "RT @LoConservative: Claim capitalism is a terrible thing, while driving in a brand new BMW, texting on an IPhone  #liberalprivilege",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "liberalprivilege",
        "indices" : [ 94, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786370710851624960",
    "text" : "Claim capitalism is a terrible thing, while driving in a brand new BMW, texting on an IPhone  #liberalprivilege",
    "id" : 786370710851624960,
    "created_at" : "2016-10-13 00:59:22 +0000",
    "user" : {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "protected" : false,
      "id_str" : "730204715439534080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880449921102565376\/zeXwjlU5_normal.jpg",
      "id" : 730204715439534080,
      "verified" : false
    }
  },
  "id" : 786726129335988225,
  "created_at" : "2016-10-14 00:31:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786726092002525184",
  "text" : "Did you know being around a woman makes a men twice more likely to think irrationally?",
  "id" : 786726092002525184,
  "created_at" : "2016-10-14 00:31:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "indices" : [ 3, 19 ],
      "id_str" : "290594346",
      "id" : 290594346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786725853669498880",
  "text" : "RT @Karynne_Summars: Life is like an elevator, sometimes on the way up you have to stop to let some people off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786725801630789632",
    "text" : "Life is like an elevator, sometimes on the way up you have to stop to let some people off.",
    "id" : 786725801630789632,
    "created_at" : "2016-10-14 00:30:22 +0000",
    "user" : {
      "name" : "Karynne Summars",
      "screen_name" : "Karynne_Summars",
      "protected" : false,
      "id_str" : "290594346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702662666960023552\/qIla4_S8_normal.jpg",
      "id" : 290594346,
      "verified" : false
    }
  },
  "id" : 786725853669498880,
  "created_at" : "2016-10-14 00:30:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786725628246626304",
  "text" : "According to the consensus, common sense among millennials is no longer a trend",
  "id" : 786725628246626304,
  "created_at" : "2016-10-14 00:29:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Fabuel",
      "screen_name" : "seovalencia",
      "indices" : [ 3, 15 ],
      "id_str" : "30510564",
      "id" : 30510564
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 108, 124 ],
      "id_str" : "393033324",
      "id" : 393033324
    }, {
      "name" : "Daniel  Allen",
      "screen_name" : "da",
      "indices" : [ 125, 128 ],
      "id_str" : "1139441",
      "id" : 1139441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MachineLearning",
      "indices" : [ 27, 43 ]
    }, {
      "text" : "DataScience",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/bgC2rWOPnr",
      "expanded_url" : "http:\/\/buff.ly\/2a0SyPe",
      "display_url" : "buff.ly\/2a0SyPe"
    } ]
  },
  "geo" : { },
  "id_str" : "786286202911678464",
  "text" : "RT @seovalencia: 50 Useful #MachineLearning and #DataScience Resources + Articles  https:\/\/t.co\/bgC2rWOPnr  @DataScienceCtrl @da...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 91, 107 ],
        "id_str" : "393033324",
        "id" : 393033324
      }, {
        "name" : "Daniel  Allen",
        "screen_name" : "da",
        "indices" : [ 108, 111 ],
        "id_str" : "1139441",
        "id" : 1139441
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MachineLearning",
        "indices" : [ 10, 26 ]
      }, {
        "text" : "DataScience",
        "indices" : [ 31, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/bgC2rWOPnr",
        "expanded_url" : "http:\/\/buff.ly\/2a0SyPe",
        "display_url" : "buff.ly\/2a0SyPe"
      } ]
    },
    "geo" : { },
    "id_str" : "786190604359176192",
    "text" : "50 Useful #MachineLearning and #DataScience Resources + Articles  https:\/\/t.co\/bgC2rWOPnr  @DataScienceCtrl @da...",
    "id" : 786190604359176192,
    "created_at" : "2016-10-12 13:03:41 +0000",
    "user" : {
      "name" : "Carlos Fabuel",
      "screen_name" : "seovalencia",
      "protected" : false,
      "id_str" : "30510564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1787585209\/carlos-twitter_normal.jpg",
      "id" : 30510564,
      "verified" : false
    }
  },
  "id" : 786286202911678464,
  "created_at" : "2016-10-12 19:23:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth McQueen",
      "screen_name" : "ElizabetMcQueen",
      "indices" : [ 3, 19 ],
      "id_str" : "20604335",
      "id" : 20604335
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ElizabetMcQueen\/status\/786286102185467904\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/krQ63fV2ZU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CulzCpDXgAAYN7C.jpg",
      "id_str" : "786286099169771520",
      "id" : 786286099169771520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulzCpDXgAAYN7C.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/krQ63fV2ZU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/agaBPvJRS2",
      "expanded_url" : "http:\/\/cb1.so\/a\/uvethw",
      "display_url" : "cb1.so\/a\/uvethw"
    } ]
  },
  "geo" : { },
  "id_str" : "786286177162825728",
  "text" : "RT @ElizabetMcQueen: What do you think of this newly proposed highway for self-driving cars? https:\/\/t.co\/agaBPvJRS2 https:\/\/t.co\/krQ63fV2ZU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cityblast.com\" rel=\"nofollow\"\u003ECityBlast.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ElizabetMcQueen\/status\/786286102185467904\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/krQ63fV2ZU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulzCpDXgAAYN7C.jpg",
        "id_str" : "786286099169771520",
        "id" : 786286099169771520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulzCpDXgAAYN7C.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/krQ63fV2ZU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/agaBPvJRS2",
        "expanded_url" : "http:\/\/cb1.so\/a\/uvethw",
        "display_url" : "cb1.so\/a\/uvethw"
      } ]
    },
    "geo" : { },
    "id_str" : "786286102185467904",
    "text" : "What do you think of this newly proposed highway for self-driving cars? https:\/\/t.co\/agaBPvJRS2 https:\/\/t.co\/krQ63fV2ZU",
    "id" : 786286102185467904,
    "created_at" : "2016-10-12 19:23:09 +0000",
    "user" : {
      "name" : "Elizabeth McQueen",
      "screen_name" : "ElizabetMcQueen",
      "protected" : false,
      "id_str" : "20604335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696766807504326658\/YdjQlY8s_normal.jpg",
      "id" : 20604335,
      "verified" : false
    }
  },
  "id" : 786286177162825728,
  "created_at" : "2016-10-12 19:23:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786286113824571394",
  "text" : "RT @BONNIELYNN2015: If you want to be insulted you can find a way for that to happen I think just?  I ignore a lot of things and it's healt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786285887822761984",
    "text" : "If you want to be insulted you can find a way for that to happen I think just?  I ignore a lot of things and it's healthier. Kill the bore",
    "id" : 786285887822761984,
    "created_at" : "2016-10-12 19:22:18 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883931234337816576\/xJntU2gN_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 786286113824571394,
  "created_at" : "2016-10-12 19:23:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Baker",
      "screen_name" : "eelrekab",
      "indices" : [ 3, 12 ],
      "id_str" : "1978859582",
      "id" : 1978859582
    }, {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 66, 82 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "abdsc",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/f8wdWOznFe",
      "expanded_url" : "http:\/\/bit.ly\/2d8JZTM",
      "display_url" : "bit.ly\/2d8JZTM"
    } ]
  },
  "geo" : { },
  "id_str" : "786286035839877120",
  "text" : "RT @eelrekab: #BigData Misconceptions https:\/\/t.co\/f8wdWOznFe via @datasciencectrl  #abdsc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 52, 68 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "abdsc",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/f8wdWOznFe",
        "expanded_url" : "http:\/\/bit.ly\/2d8JZTM",
        "display_url" : "bit.ly\/2d8JZTM"
      } ]
    },
    "geo" : { },
    "id_str" : "786219193012215808",
    "text" : "#BigData Misconceptions https:\/\/t.co\/f8wdWOznFe via @datasciencectrl  #abdsc",
    "id" : 786219193012215808,
    "created_at" : "2016-10-12 14:57:17 +0000",
    "user" : {
      "name" : "Lee Baker",
      "screen_name" : "eelrekab",
      "protected" : false,
      "id_str" : "1978859582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628712661\/03a63d6e76d6c05465215279acfbd377_normal.jpeg",
      "id" : 1978859582,
      "verified" : false
    }
  },
  "id" : 786286035839877120,
  "created_at" : "2016-10-12 19:22:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "overleo",
      "screen_name" : "overleo",
      "indices" : [ 3, 11 ],
      "id_str" : "141369076",
      "id" : 141369076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786285976977076225",
  "text" : "RT @overleo: Beyond Deep Learning \u2013 3rd Generation Neural Nets - Data Science Central: Summary: \u00A0If Deep Learning is\u2026 https:\/\/t.co\/E9novzHg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/E9novzHgjv",
        "expanded_url" : "https:\/\/goo.gl\/hz2rPL",
        "display_url" : "goo.gl\/hz2rPL"
      } ]
    },
    "geo" : { },
    "id_str" : "786253629699203072",
    "text" : "Beyond Deep Learning \u2013 3rd Generation Neural Nets - Data Science Central: Summary: \u00A0If Deep Learning is\u2026 https:\/\/t.co\/E9novzHgjv [ml]",
    "id" : 786253629699203072,
    "created_at" : "2016-10-12 17:14:07 +0000",
    "user" : {
      "name" : "overleo",
      "screen_name" : "overleo",
      "protected" : false,
      "id_str" : "141369076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413569805749190656\/X4Ga6heV_normal.jpeg",
      "id" : 141369076,
      "verified" : false
    }
  },
  "id" : 786285976977076225,
  "created_at" : "2016-10-12 19:22:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandeco",
      "screen_name" : "sandeco",
      "indices" : [ 3, 11 ],
      "id_str" : "24675439",
      "id" : 24675439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "IoT",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "DataScience",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qW6r8LxV7n",
      "expanded_url" : "http:\/\/buff.ly\/2cYqrU8",
      "display_url" : "buff.ly\/2cYqrU8"
    } ]
  },
  "geo" : { },
  "id_str" : "786285960577290240",
  "text" : "RT @sandeco: 20 Big Data Repositories You Should Check Out \u2013 Data Science Central https:\/\/t.co\/qW6r8LxV7n #BigData #IoT #DataScience https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sandeco\/status\/786268084172689409\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/4M4pGM6siP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Culip2qXYAAN7y8.jpg",
        "id_str" : "786268081140228096",
        "id" : 786268081140228096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Culip2qXYAAN7y8.jpg",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 521
        } ],
        "display_url" : "pic.twitter.com\/4M4pGM6siP"
      } ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "IoT",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "DataScience",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/qW6r8LxV7n",
        "expanded_url" : "http:\/\/buff.ly\/2cYqrU8",
        "display_url" : "buff.ly\/2cYqrU8"
      } ]
    },
    "geo" : { },
    "id_str" : "786268084172689409",
    "text" : "20 Big Data Repositories You Should Check Out \u2013 Data Science Central https:\/\/t.co\/qW6r8LxV7n #BigData #IoT #DataScience https:\/\/t.co\/4M4pGM6siP",
    "id" : 786268084172689409,
    "created_at" : "2016-10-12 18:11:34 +0000",
    "user" : {
      "name" : "Sandeco",
      "screen_name" : "sandeco",
      "protected" : false,
      "id_str" : "24675439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871535835254075393\/6Nj3DbXs_normal.jpg",
      "id" : 24675439,
      "verified" : false
    }
  },
  "id" : 786285960577290240,
  "created_at" : "2016-10-12 19:22:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786285701625221120",
  "text" : "RT @ABC: FBI joins CT plane crash probe that killed one of two on board; declines to comment on reports crash was intentional https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/786258327248527360\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/kvFhXGW4te",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CulZx8vXgAAdsG7.jpg",
        "id_str" : "786258324606124032",
        "id" : 786258324606124032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CulZx8vXgAAdsG7.jpg",
        "sizes" : [ {
          "h" : 1523,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 893,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1928,
          "resize" : "fit",
          "w" : 2592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/kvFhXGW4te"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/IEBkrtu0wO",
        "expanded_url" : "http:\/\/abcn.ws\/2dws61n",
        "display_url" : "abcn.ws\/2dws61n"
      } ]
    },
    "geo" : { },
    "id_str" : "786258327248527360",
    "text" : "FBI joins CT plane crash probe that killed one of two on board; declines to comment on reports crash was intentional https:\/\/t.co\/IEBkrtu0wO https:\/\/t.co\/kvFhXGW4te",
    "id" : 786258327248527360,
    "created_at" : "2016-10-12 17:32:47 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877547979363758080\/ny06RNTT_normal.jpg",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 786285701625221120,
  "created_at" : "2016-10-12 19:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786285644259745792",
  "text" : "One moment you are cool the next moment she just leaves \uD83E\uDD14",
  "id" : 786285644259745792,
  "created_at" : "2016-10-12 19:21:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/yZpvzJQqpG",
      "expanded_url" : "http:\/\/fb.me\/7yobWpQSw",
      "display_url" : "fb.me\/7yobWpQSw"
    } ]
  },
  "geo" : { },
  "id_str" : "786283295101296640",
  "text" : "RT @EmperorDarroux: Comcast set-top boxes now offer detailed stats for more sports https:\/\/t.co\/yZpvzJQqpG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/yZpvzJQqpG",
        "expanded_url" : "http:\/\/fb.me\/7yobWpQSw",
        "display_url" : "fb.me\/7yobWpQSw"
      } ]
    },
    "geo" : { },
    "id_str" : "786283251602194436",
    "text" : "Comcast set-top boxes now offer detailed stats for more sports https:\/\/t.co\/yZpvzJQqpG",
    "id" : 786283251602194436,
    "created_at" : "2016-10-12 19:11:50 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 786283295101296640,
  "created_at" : "2016-10-12 19:12:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786283216374210560",
  "text" : "RT @Matthiasiam: I will do my best to never tell you how to think, but encourage you to educate yourself. For me to do anything else is hig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786238461527195649",
    "text" : "I will do my best to never tell you how to think, but encourage you to educate yourself. For me to do anything else is highly dangerous.",
    "id" : 786238461527195649,
    "created_at" : "2016-10-12 16:13:51 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878063216936366080\/MYU8BMti_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 786283216374210560,
  "created_at" : "2016-10-12 19:11:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786283139912069120",
  "text" : "RT @BarbaraCorcoran: If you're going to spend 10 to 12 hours a day doing something, you better love doing it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786233901337473024",
    "text" : "If you're going to spend 10 to 12 hours a day doing something, you better love doing it!",
    "id" : 786233901337473024,
    "created_at" : "2016-10-12 15:55:44 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 786283139912069120,
  "created_at" : "2016-10-12 19:11:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786283116746969088",
  "text" : "RT @KassyDillon: I would like to reiterate that the websites I contribute to don't necessarily share my views, and I don't necessarily shar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "786256044821536772",
    "text" : "I would like to reiterate that the websites I contribute to don't necessarily share my views, and I don't necessarily share theirs.",
    "id" : 786256044821536772,
    "created_at" : "2016-10-12 17:23:43 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 786283116746969088,
  "created_at" : "2016-10-12 19:11:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vikas Gupta",
      "screen_name" : "vikasjee",
      "indices" : [ 3, 12 ],
      "id_str" : "14358671",
      "id" : 14358671
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScience",
      "indices" : [ 62, 74 ]
    }, {
      "text" : "abdsc",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/foqWcJ0hKP",
      "expanded_url" : "http:\/\/j.mp\/2e6fQKp",
      "display_url" : "j.mp\/2e6fQKp"
    } ]
  },
  "geo" : { },
  "id_str" : "786283048241430528",
  "text" : "RT @vikasjee: machinelearnbot: RT analyticbridge: 50 years of #DataScience #abdsc DataScienceCtrl https:\/\/t.co\/foqWcJ0hKP https:\/\/t.co\/aTHx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DataScience",
        "indices" : [ 48, 60 ]
      }, {
        "text" : "abdsc",
        "indices" : [ 61, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/foqWcJ0hKP",
        "expanded_url" : "http:\/\/j.mp\/2e6fQKp",
        "display_url" : "j.mp\/2e6fQKp"
      }, {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/aTHxQm1Swr",
        "expanded_url" : "http:\/\/j.mp\/2dcTjFg",
        "display_url" : "j.mp\/2dcTjFg"
      } ]
    },
    "geo" : { },
    "id_str" : "786280996568199168",
    "text" : "machinelearnbot: RT analyticbridge: 50 years of #DataScience #abdsc DataScienceCtrl https:\/\/t.co\/foqWcJ0hKP https:\/\/t.co\/aTHxQm1Swr",
    "id" : 786280996568199168,
    "created_at" : "2016-10-12 19:02:52 +0000",
    "user" : {
      "name" : "Vikas Gupta",
      "screen_name" : "vikasjee",
      "protected" : false,
      "id_str" : "14358671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672957784\/VikasGupta_normal.JPG",
      "id" : 14358671,
      "verified" : false
    }
  },
  "id" : 786283048241430528,
  "created_at" : "2016-10-12 19:11:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786282939919241216",
  "text" : "You never understand females, ever \uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C",
  "id" : 786282939919241216,
  "created_at" : "2016-10-12 19:10:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786214454300205057",
  "text" : "RT @scrowder: Keep in mind that Rasmussen has been either completely accurate or had R's over-performing in polls in 100% of last 4 electio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785488071349379072",
    "text" : "Keep in mind that Rasmussen has been either completely accurate or had R's over-performing in polls in 100% of last 4 elections.",
    "id" : 785488071349379072,
    "created_at" : "2016-10-10 14:32:04 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 786214454300205057,
  "created_at" : "2016-10-12 14:38:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786214395105931264",
  "text" : "RT @tedcruz: UNESCO &amp; the Met want to define Jerusalem as anything but Jewish\u2014but it is the capital of Israel, the Jewish state: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/bD9GEFHMq2",
        "expanded_url" : "http:\/\/www.wsj.com\/articles\/rewriting-the-history-of-jerusalem-1476050331",
        "display_url" : "wsj.com\/articles\/rewri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785481948839890944",
    "text" : "UNESCO &amp; the Met want to define Jerusalem as anything but Jewish\u2014but it is the capital of Israel, the Jewish state: https:\/\/t.co\/bD9GEFHMq2",
    "id" : 785481948839890944,
    "created_at" : "2016-10-10 14:07:44 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 786214395105931264,
  "created_at" : "2016-10-12 14:38:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "indices" : [ 3, 15 ],
      "id_str" : "15231287",
      "id" : 15231287
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThinkCast",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "podcast",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/2OHzCoZgC4",
      "expanded_url" : "http:\/\/gtnr.it\/2bN7AL8",
      "display_url" : "gtnr.it\/2bN7AL8"
    } ]
  },
  "geo" : { },
  "id_str" : "786214307012968448",
  "text" : "RT @Gartner_inc: #ThinkCast, the Gartner #podcast channel, is now on Stitcher &amp; Google Play. Subscribe here: https:\/\/t.co\/2OHzCoZgC4 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.engage121.com\" rel=\"nofollow\"\u003Eengage121\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gartner_inc\/status\/785472469947777024\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/oiuNJFPsJu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuaPDENWEAAu_aI.jpg",
        "id_str" : "785472467854823424",
        "id" : 785472467854823424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuaPDENWEAAu_aI.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/oiuNJFPsJu"
      } ],
      "hashtags" : [ {
        "text" : "ThinkCast",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "podcast",
        "indices" : [ 24, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/2OHzCoZgC4",
        "expanded_url" : "http:\/\/gtnr.it\/2bN7AL8",
        "display_url" : "gtnr.it\/2bN7AL8"
      } ]
    },
    "geo" : { },
    "id_str" : "785472469947777024",
    "text" : "#ThinkCast, the Gartner #podcast channel, is now on Stitcher &amp; Google Play. Subscribe here: https:\/\/t.co\/2OHzCoZgC4 https:\/\/t.co\/oiuNJFPsJu",
    "id" : 785472469947777024,
    "created_at" : "2016-10-10 13:30:04 +0000",
    "user" : {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "protected" : false,
      "id_str" : "15231287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479292472707649536\/HfChXWQy_normal.png",
      "id" : 15231287,
      "verified" : true
    }
  },
  "id" : 786214307012968448,
  "created_at" : "2016-10-12 14:37:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786214137760186368",
  "text" : "I like to feel I am smooth around the ladies but others may have a different opinion \uD83D\uDE1D",
  "id" : 786214137760186368,
  "created_at" : "2016-10-12 14:37:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimqueso",
      "screen_name" : "kimqueso",
      "indices" : [ 3, 12 ],
      "id_str" : "20489149",
      "id" : 20489149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785302259638931457",
  "text" : "RT @kimqueso: New iOS update sucks. No slide to unlock? No slide to stop your alarm? You have to hit STOP for your alarm!? #firstworldprobl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstworldproblem",
        "indices" : [ 109, 127 ]
      }, {
        "text" : "mad",
        "indices" : [ 128, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778243687285420032",
    "text" : "New iOS update sucks. No slide to unlock? No slide to stop your alarm? You have to hit STOP for your alarm!? #firstworldproblem #mad",
    "id" : 778243687285420032,
    "created_at" : "2016-09-20 14:45:28 +0000",
    "user" : {
      "name" : "kimqueso",
      "screen_name" : "kimqueso",
      "protected" : false,
      "id_str" : "20489149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708319839727783936\/e0_s-Wnl_normal.jpg",
      "id" : 20489149,
      "verified" : false
    }
  },
  "id" : 785302259638931457,
  "created_at" : "2016-10-10 02:13:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Average Joe",
      "screen_name" : "Averagejoe1239",
      "indices" : [ 3, 18 ],
      "id_str" : "774688064216109056",
      "id" : 774688064216109056
    }, {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 20, 33 ],
      "id_str" : "19362341",
      "id" : 19362341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301984186425348",
  "text" : "RT @Averagejoe1239: @mariashriver You and Trump are very similar. You both got a head in life from family money! Take that away, were would\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Shriver",
        "screen_name" : "mariashriver",
        "indices" : [ 0, 13 ],
        "id_str" : "19362341",
        "id" : 19362341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785301115558473729",
    "geo" : { },
    "id_str" : "785301631826956289",
    "in_reply_to_user_id" : 19362341,
    "text" : "@mariashriver You and Trump are very similar. You both got a head in life from family money! Take that away, were would you be!",
    "id" : 785301631826956289,
    "in_reply_to_status_id" : 785301115558473729,
    "created_at" : "2016-10-10 02:11:13 +0000",
    "in_reply_to_screen_name" : "mariashriver",
    "in_reply_to_user_id_str" : "19362341",
    "user" : {
      "name" : "Average Joe",
      "screen_name" : "Averagejoe1239",
      "protected" : false,
      "id_str" : "774688064216109056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774693371776421888\/aXsFAJiH_normal.jpg",
      "id" : 774688064216109056,
      "verified" : false
    }
  },
  "id" : 785301984186425348,
  "created_at" : "2016-10-10 02:12:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301726320529413",
  "text" : "RT @KassyDillon: Gary Johnson has no idea what you're talking about Clinton. Aleppo? What's that? #debate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debate",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785300012301332481",
    "text" : "Gary Johnson has no idea what you're talking about Clinton. Aleppo? What's that? #debate",
    "id" : 785300012301332481,
    "created_at" : "2016-10-10 02:04:47 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 785301726320529413,
  "created_at" : "2016-10-10 02:11:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301676832030720",
  "text" : "RT @KassyDillon: Hillary ignored everything said about her rapist husband. #debate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debate",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785289097111797761",
    "text" : "Hillary ignored everything said about her rapist husband. #debate",
    "id" : 785289097111797761,
    "created_at" : "2016-10-10 01:21:25 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 785301676832030720,
  "created_at" : "2016-10-10 02:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FullRepeal",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301588722192385",
  "text" : "RT @tedcruz: What Obamacare needs is #FullRepeal &amp; real reforms to make health care personal, portable &amp; affordable: https:\/\/t.co\/IeWvSyo3f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FullRepeal",
        "indices" : [ 24, 35 ]
      }, {
        "text" : "Debates2016",
        "indices" : [ 136, 148 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/IeWvSyo3fg",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/full-repeal-obamacare\/",
        "display_url" : "tedcruz.org\/l\/full-repeal-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "785291401403723776",
    "text" : "What Obamacare needs is #FullRepeal &amp; real reforms to make health care personal, portable &amp; affordable: https:\/\/t.co\/IeWvSyo3fg #Debates2016",
    "id" : 785291401403723776,
    "created_at" : "2016-10-10 01:30:34 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 785301588722192385,
  "created_at" : "2016-10-10 02:11:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301567515848705",
  "text" : "RT @Evan_McMullin: Trump and Clinton are the personification of America's leadership crisis. It's time for a new generation of leaders. #de\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 117, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785292000568356864",
    "text" : "Trump and Clinton are the personification of America's leadership crisis. It's time for a new generation of leaders. #debates",
    "id" : 785292000568356864,
    "created_at" : "2016-10-10 01:32:57 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 785301567515848705,
  "created_at" : "2016-10-10 02:10:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hammond",
      "screen_name" : "ReggieMoto",
      "indices" : [ 3, 14 ],
      "id_str" : "20701335",
      "id" : 20701335
    }, {
      "name" : "Josh Hammer",
      "screen_name" : "josh_hammer",
      "indices" : [ 16, 28 ],
      "id_str" : "38813274",
      "id" : 38813274
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 29, 43 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Deplorable Doc B",
      "screen_name" : "docbryantrnbsn",
      "indices" : [ 44, 59 ],
      "id_str" : "55841825",
      "id" : 55841825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301517381275648",
  "text" : "RT @ReggieMoto: @josh_hammer @Evan_McMullin @docbryantrnbsn As am I.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Hammer",
        "screen_name" : "josh_hammer",
        "indices" : [ 0, 12 ],
        "id_str" : "38813274",
        "id" : 38813274
      }, {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 13, 27 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      }, {
        "name" : "Deplorable Doc B",
        "screen_name" : "docbryantrnbsn",
        "indices" : [ 28, 43 ],
        "id_str" : "55841825",
        "id" : 55841825
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "785147692196343808",
    "geo" : { },
    "id_str" : "785156851482570752",
    "in_reply_to_user_id" : 38813274,
    "text" : "@josh_hammer @Evan_McMullin @docbryantrnbsn As am I.",
    "id" : 785156851482570752,
    "in_reply_to_status_id" : 785147692196343808,
    "created_at" : "2016-10-09 16:35:55 +0000",
    "in_reply_to_screen_name" : "josh_hammer",
    "in_reply_to_user_id_str" : "38813274",
    "user" : {
      "name" : "David Hammond",
      "screen_name" : "ReggieMoto",
      "protected" : false,
      "id_str" : "20701335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/811775888387932160\/rvFhOsmS_normal.jpg",
      "id" : 20701335,
      "verified" : false
    }
  },
  "id" : 785301517381275648,
  "created_at" : "2016-10-10 02:10:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debate",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301388712677376",
  "text" : "RT @hannahbleau_: Hillary Clinton is blaming Abraham Lincoln right now. This is actually happening. #Debate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debate",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785296142363918336",
    "text" : "Hillary Clinton is blaming Abraham Lincoln right now. This is actually happening. #Debate",
    "id" : 785296142363918336,
    "created_at" : "2016-10-10 01:49:25 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 785301388712677376,
  "created_at" : "2016-10-10 02:10:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301232416071680",
  "text" : "RT @KassyDillon: YES HE BROUGHT UP THE DNC RIGGING THE ELECTION. His energy is back! #debate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debate",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785289512461209600",
    "text" : "YES HE BROUGHT UP THE DNC RIGGING THE ELECTION. His energy is back! #debate",
    "id" : 785289512461209600,
    "created_at" : "2016-10-10 01:23:04 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 785301232416071680,
  "created_at" : "2016-10-10 02:09:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicks On The Right",
      "screen_name" : "chicksonright",
      "indices" : [ 3, 17 ],
      "id_str" : "69666298",
      "id" : 69666298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "benghazi",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301184005468161",
  "text" : "RT @chicksonright: I guess it's no surprise Hillz is blaming a movie.  She's been known to do that before. #benghazi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "benghazi",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785296326929944581",
    "text" : "I guess it's no surprise Hillz is blaming a movie.  She's been known to do that before. #benghazi",
    "id" : 785296326929944581,
    "created_at" : "2016-10-10 01:50:09 +0000",
    "user" : {
      "name" : "Chicks On The Right",
      "screen_name" : "chicksonright",
      "protected" : false,
      "id_str" : "69666298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490956552661000192\/7NzGGyIW_normal.jpeg",
      "id" : 69666298,
      "verified" : true
    }
  },
  "id" : 785301184005468161,
  "created_at" : "2016-10-10 02:09:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301153491869699",
  "text" : "RT @Evan_McMullin: We should be having a debate about ideas, issues and America's destiny. This isn't it and this isn't leadership. #debates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "785290153854050304",
    "text" : "We should be having a debate about ideas, issues and America's destiny. This isn't it and this isn't leadership. #debates",
    "id" : 785290153854050304,
    "created_at" : "2016-10-10 01:25:37 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 785301153491869699,
  "created_at" : "2016-10-10 02:09:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785301101537009668",
  "text" : "I don't support Trump nor Hillary, but Trump is creaming Hillbeast on her bad policies",
  "id" : 785301101537009668,
  "created_at" : "2016-10-10 02:09:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fahmiida",
      "screen_name" : "__Fahmiida",
      "indices" : [ 3, 14 ],
      "id_str" : "2929183139",
      "id" : 2929183139
    }, {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 26, 35 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/__Fahmiida\/status\/784647399213928448\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ipL2ndioGK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuOgo2dUkAAEZ2M.jpg",
      "id_str" : "784647383766306816",
      "id" : 784647383766306816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuOgo2dUkAAEZ2M.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1284,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1284,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ipL2ndioGK"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "orisit",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785174358268473344",
  "text" : "RT @__Fahmiida: Sometimes @oaklandu is actually Narnia. #ThisIsOU #orisit? https:\/\/t.co\/ipL2ndioGK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oakland University",
        "screen_name" : "oaklandu",
        "indices" : [ 10, 19 ],
        "id_str" : "17468189",
        "id" : 17468189
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/__Fahmiida\/status\/784647399213928448\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/ipL2ndioGK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuOgo2dUkAAEZ2M.jpg",
        "id_str" : "784647383766306816",
        "id" : 784647383766306816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuOgo2dUkAAEZ2M.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1284,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1284,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ipL2ndioGK"
      } ],
      "hashtags" : [ {
        "text" : "ThisIsOU",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "orisit",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784647399213928448",
    "text" : "Sometimes @oaklandu is actually Narnia. #ThisIsOU #orisit? https:\/\/t.co\/ipL2ndioGK",
    "id" : 784647399213928448,
    "created_at" : "2016-10-08 06:51:32 +0000",
    "user" : {
      "name" : "Fahmiida",
      "screen_name" : "__Fahmiida",
      "protected" : false,
      "id_str" : "2929183139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817141347396239360\/vQiwfZZq_normal.jpg",
      "id" : 2929183139,
      "verified" : false
    }
  },
  "id" : 785174358268473344,
  "created_at" : "2016-10-09 17:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/g0lJHJ4zrc",
      "expanded_url" : "http:\/\/bit.ly\/2dA0mvx",
      "display_url" : "bit.ly\/2dA0mvx"
    } ]
  },
  "geo" : { },
  "id_str" : "784800476634214400",
  "text" : "RT @Tearieeror: Januari, Stephan Lichtsteiner Ke Barcelona? https:\/\/t.co\/g0lJHJ4zrc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/g0lJHJ4zrc",
        "expanded_url" : "http:\/\/bit.ly\/2dA0mvx",
        "display_url" : "bit.ly\/2dA0mvx"
      } ]
    },
    "geo" : { },
    "id_str" : "784800374423117826",
    "text" : "Januari, Stephan Lichtsteiner Ke Barcelona? https:\/\/t.co\/g0lJHJ4zrc",
    "id" : 784800374423117826,
    "created_at" : "2016-10-08 16:59:24 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 784800476634214400,
  "created_at" : "2016-10-08 16:59:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784800409428824066",
  "text" : "RT @andikhm01: This high school football team is so terrifying, opponents are forfeiting games for their safety - SB Nation https:\/\/t.co\/qc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/qcPw9ntkNJ",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNHEkIgxVKOYIrh9F8OohQAdtr0iLw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779233597049&ei=nCX5V_ihO5XRuAL0soPABQ&url=http%3A%2F%2Fwww.sbnation.com%2Flookit%2F2016%2F10%2F8%2F13210260%2Farchbishop-murphy-high-school-football-video-forfeits-hospital&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784800166272307200",
    "text" : "This high school football team is so terrifying, opponents are forfeiting games for their safety - SB Nation https:\/\/t.co\/qcPw9ntkNJ",
    "id" : 784800166272307200,
    "created_at" : "2016-10-08 16:58:35 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 784800409428824066,
  "created_at" : "2016-10-08 16:59:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/784794320301756416\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/7TI7WGfEbD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQmRGQVUAAmvKa.jpg",
      "id_str" : "784794310248058880",
      "id" : 784794310248058880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQmRGQVUAAmvKa.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/7TI7WGfEbD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784794320301756416",
  "text" : "Vince and Joe's have good Ice Cream https:\/\/t.co\/7TI7WGfEbD",
  "id" : 784794320301756416,
  "created_at" : "2016-10-08 16:35:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN PIECE OF SHIT \uD83D\uDCA9",
      "screen_name" : "renomarky",
      "indices" : [ 3, 13 ],
      "id_str" : "2748582465",
      "id" : 2748582465
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/renomarky\/status\/784545519234187264\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/wxeBBPFv1D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuND-eGXEAAsJZT.jpg",
      "id_str" : "784545500603289600",
      "id" : 784545500603289600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuND-eGXEAAsJZT.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/wxeBBPFv1D"
    } ],
    "hashtags" : [ {
      "text" : "BillCintonRapist",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784572849122111489",
  "text" : "RT @renomarky: #BillCintonRapist https:\/\/t.co\/wxeBBPFv1D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/renomarky\/status\/784545519234187264\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/wxeBBPFv1D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuND-eGXEAAsJZT.jpg",
        "id_str" : "784545500603289600",
        "id" : 784545500603289600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuND-eGXEAAsJZT.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/wxeBBPFv1D"
      } ],
      "hashtags" : [ {
        "text" : "BillCintonRapist",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784545519234187264",
    "text" : "#BillCintonRapist https:\/\/t.co\/wxeBBPFv1D",
    "id" : 784545519234187264,
    "created_at" : "2016-10-08 00:06:42 +0000",
    "user" : {
      "name" : "CNN PIECE OF SHIT \uD83D\uDCA9",
      "screen_name" : "renomarky",
      "protected" : false,
      "id_str" : "2748582465",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861498971101044736\/QRUMbSDL_normal.jpg",
      "id" : 2748582465,
      "verified" : false
    }
  },
  "id" : 784572849122111489,
  "created_at" : "2016-10-08 01:55:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NobelPeacePrize",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784572525288255488",
  "text" : "RT @KassyDillon: Participation trophy? #NobelPeacePrize",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NobelPeacePrize",
        "indices" : [ 22, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784361533824462848",
    "text" : "Participation trophy? #NobelPeacePrize",
    "id" : 784361533824462848,
    "created_at" : "2016-10-07 11:55:37 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 784572525288255488,
  "created_at" : "2016-10-08 01:54:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Fix",
      "screen_name" : "thefix",
      "indices" : [ 3, 10 ],
      "id_str" : "846354889819279360",
      "id" : 846354889819279360
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheFix\/status\/783685399264763905\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/AXzGAjiTkh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuA1tjeWEAEwg3D.jpg",
      "id_str" : "783685391895367681",
      "id" : 783685391895367681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuA1tjeWEAEwg3D.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 896
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 896
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 896
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/AXzGAjiTkh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/n2Zy8wgaJT",
      "expanded_url" : "http:\/\/wpo.st\/vGf22",
      "display_url" : "wpo.st\/vGf22"
    } ]
  },
  "geo" : { },
  "id_str" : "784572439292481536",
  "text" : "RT @TheFix: Young people would really like to vote for someone not named Clinton or Trump https:\/\/t.co\/n2Zy8wgaJT https:\/\/t.co\/AXzGAjiTkh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheFix\/status\/783685399264763905\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/AXzGAjiTkh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuA1tjeWEAEwg3D.jpg",
        "id_str" : "783685391895367681",
        "id" : 783685391895367681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuA1tjeWEAEwg3D.jpg",
        "sizes" : [ {
          "h" : 715,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/AXzGAjiTkh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/n2Zy8wgaJT",
        "expanded_url" : "http:\/\/wpo.st\/vGf22",
        "display_url" : "wpo.st\/vGf22"
      } ]
    },
    "geo" : { },
    "id_str" : "783685399264763905",
    "text" : "Young people would really like to vote for someone not named Clinton or Trump https:\/\/t.co\/n2Zy8wgaJT https:\/\/t.co\/AXzGAjiTkh",
    "id" : 783685399264763905,
    "created_at" : "2016-10-05 15:08:54 +0000",
    "user" : {
      "name" : "Chris Cillizza",
      "screen_name" : "CillizzaCNN",
      "protected" : false,
      "id_str" : "14412533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880017443166584833\/6vnu0fJp_normal.jpg",
      "id" : 14412533,
      "verified" : true
    }
  },
  "id" : 784572439292481536,
  "created_at" : "2016-10-08 01:53:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 3, 13 ],
      "id_str" : "4248211",
      "id" : 4248211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/L9nAOeBzXp",
      "expanded_url" : "https:\/\/twitter.com\/googleforentrep\/status\/783336972395745280",
      "display_url" : "twitter.com\/googleforentre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784572411945619456",
  "text" : "RT @mindyfinn: Love this. https:\/\/t.co\/L9nAOeBzXp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/L9nAOeBzXp",
        "expanded_url" : "https:\/\/twitter.com\/googleforentrep\/status\/783336972395745280",
        "display_url" : "twitter.com\/googleforentre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783687299351674880",
    "text" : "Love this. https:\/\/t.co\/L9nAOeBzXp",
    "id" : 783687299351674880,
    "created_at" : "2016-10-05 15:16:27 +0000",
    "user" : {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "protected" : false,
      "id_str" : "4248211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852522140360429568\/TB81_9mn_normal.jpg",
      "id" : 4248211,
      "verified" : true
    }
  },
  "id" : 784572411945619456,
  "created_at" : "2016-10-08 01:53:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 3, 13 ],
      "id_str" : "4248211",
      "id" : 4248211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784572363606200320",
  "text" : "RT @mindyfinn: Trump repeatedly shows that he views women as objects and second class. We are better than this!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "784505806716829697",
    "text" : "Trump repeatedly shows that he views women as objects and second class. We are better than this!",
    "id" : 784505806716829697,
    "created_at" : "2016-10-07 21:28:54 +0000",
    "user" : {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "protected" : false,
      "id_str" : "4248211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852522140360429568\/TB81_9mn_normal.jpg",
      "id" : 4248211,
      "verified" : true
    }
  },
  "id" : 784572363606200320,
  "created_at" : "2016-10-08 01:53:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "indices" : [ 3, 13 ],
      "id_str" : "4248211",
      "id" : 4248211
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 51, 65 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784572323756175360",
  "text" : "RT @mindyfinn: I'm proud to be running for VP with @Evan_McMullin. Together, we'll offer America a better choice. Join us: https:\/\/t.co\/6PX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 36, 50 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mindyfinn\/status\/784166410482089984\/photo\/1",
        "indices" : [ 132, 155 ],
        "url" : "https:\/\/t.co\/ehEEHJSnaR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuHoOGKUIAAALaU.png",
        "id_str" : "784163139008864256",
        "id" : 784163139008864256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuHoOGKUIAAALaU.png",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 548
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 548
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 548
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 548
        } ],
        "display_url" : "pic.twitter.com\/ehEEHJSnaR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/6PXq00OR4Z",
        "expanded_url" : "https:\/\/www.evanmcmullin.com\/grassroots",
        "display_url" : "evanmcmullin.com\/grassroots"
      } ]
    },
    "geo" : { },
    "id_str" : "784166410482089984",
    "text" : "I'm proud to be running for VP with @Evan_McMullin. Together, we'll offer America a better choice. Join us: https:\/\/t.co\/6PXq00OR4Z https:\/\/t.co\/ehEEHJSnaR",
    "id" : 784166410482089984,
    "created_at" : "2016-10-06 23:00:16 +0000",
    "user" : {
      "name" : "Mindy Finn",
      "screen_name" : "mindyfinn",
      "protected" : false,
      "id_str" : "4248211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852522140360429568\/TB81_9mn_normal.jpg",
      "id" : 4248211,
      "verified" : true
    }
  },
  "id" : 784572323756175360,
  "created_at" : "2016-10-08 01:53:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 3, 11 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784572205720018945",
  "text" : "RT @adwords: 4 steps to follow to create the best possible targeting groups for your DSA campaigns. Watch this 3-min video: https:\/\/t.co\/Hj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adwords\/status\/784563213388087297\/photo\/1",
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/OUTM8ljIUa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuNUFUiWYAcW2fi.png",
        "id_str" : "784563210481459207",
        "id" : 784563210481459207,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuNUFUiWYAcW2fi.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OUTM8ljIUa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/HjOaPZcHOY",
        "expanded_url" : "https:\/\/goo.gl\/6NiK2X",
        "display_url" : "goo.gl\/6NiK2X"
      } ]
    },
    "geo" : { },
    "id_str" : "784563213388087297",
    "text" : "4 steps to follow to create the best possible targeting groups for your DSA campaigns. Watch this 3-min video: https:\/\/t.co\/HjOaPZcHOY https:\/\/t.co\/OUTM8ljIUa",
    "id" : 784563213388087297,
    "created_at" : "2016-10-08 01:17:01 +0000",
    "user" : {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "protected" : false,
      "id_str" : "91220126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618952064576585733\/0XNolOAa_normal.png",
      "id" : 91220126,
      "verified" : true
    }
  },
  "id" : 784572205720018945,
  "created_at" : "2016-10-08 01:52:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "indices" : [ 3, 15 ],
      "id_str" : "56510427",
      "id" : 56510427
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/784115095936827397\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/pVB1o7iRgF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuG8Z2KXgAIrPz9.jpg",
      "id_str" : "784114962360926210",
      "id" : 784114962360926210,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuG8Z2KXgAIrPz9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/pVB1o7iRgF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/GKlDml2kPf",
      "expanded_url" : "http:\/\/bit.ly\/2dODc1I",
      "display_url" : "bit.ly\/2dODc1I"
    } ]
  },
  "geo" : { },
  "id_str" : "784572083946872832",
  "text" : "RT @motherboard: We need to save the internet from the Internet of Things https:\/\/t.co\/GKlDml2kPf https:\/\/t.co\/pVB1o7iRgF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/784115095936827397\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/pVB1o7iRgF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuG8Z2KXgAIrPz9.jpg",
        "id_str" : "784114962360926210",
        "id" : 784114962360926210,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuG8Z2KXgAIrPz9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/pVB1o7iRgF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/GKlDml2kPf",
        "expanded_url" : "http:\/\/bit.ly\/2dODc1I",
        "display_url" : "bit.ly\/2dODc1I"
      } ]
    },
    "geo" : { },
    "id_str" : "784115095936827397",
    "text" : "We need to save the internet from the Internet of Things https:\/\/t.co\/GKlDml2kPf https:\/\/t.co\/pVB1o7iRgF",
    "id" : 784115095936827397,
    "created_at" : "2016-10-06 19:36:21 +0000",
    "user" : {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "protected" : false,
      "id_str" : "56510427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827207967799930880\/ZNgndgEm_normal.jpg",
      "id" : 56510427,
      "verified" : true
    }
  },
  "id" : 784572083946872832,
  "created_at" : "2016-10-08 01:52:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LWC",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ABdrUz9cjR",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=TmNyzvH7H3c",
      "display_url" : "youtube.com\/watch?v=TmNyzv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "784572004439560192",
  "text" : "RT @scrowder: Fighting the power with little to no risk! College socialists unite! #LWC FULL VIDEO &gt;&gt; https:\/\/t.co\/ABdrUz9cjR https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/784054464458153985\/video\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/xR9pYS7pFw",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/784054363371208704\/pu\/img\/IceBBbtkAxkZ0NfR.jpg",
        "id_str" : "784054363371208704",
        "id" : 784054363371208704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/784054363371208704\/pu\/img\/IceBBbtkAxkZ0NfR.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xR9pYS7pFw"
      } ],
      "hashtags" : [ {
        "text" : "LWC",
        "indices" : [ 69, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ABdrUz9cjR",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=TmNyzvH7H3c",
        "display_url" : "youtube.com\/watch?v=TmNyzv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "784054464458153985",
    "text" : "Fighting the power with little to no risk! College socialists unite! #LWC FULL VIDEO &gt;&gt; https:\/\/t.co\/ABdrUz9cjR https:\/\/t.co\/xR9pYS7pFw",
    "id" : 784054464458153985,
    "created_at" : "2016-10-06 15:35:26 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 784572004439560192,
  "created_at" : "2016-10-08 01:51:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784571922164150272",
  "text" : "RT @Evan_McMullin: We can reform entitlements in a way that keeps our promises to seniors &amp; those approaching retirement, but preserves tho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783844754656141312",
    "text" : "We can reform entitlements in a way that keeps our promises to seniors &amp; those approaching retirement, but preserves those programs for all.",
    "id" : 783844754656141312,
    "created_at" : "2016-10-06 01:42:07 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 784571922164150272,
  "created_at" : "2016-10-08 01:51:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/784571869835980800\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/DWiEXlO7qi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuNb80JXEAExGE3.jpg",
      "id_str" : "784571860440780801",
      "id" : 784571860440780801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuNb80JXEAExGE3.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DWiEXlO7qi"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/784571869835980800\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/DWiEXlO7qi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuNb80JWgAEzLSm.jpg",
      "id_str" : "784571860440743937",
      "id" : 784571860440743937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuNb80JWgAEzLSm.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DWiEXlO7qi"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/784571869835980800\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/DWiEXlO7qi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuNb80LW8AAN4pN.jpg",
      "id_str" : "784571860449161216",
      "id" : 784571860449161216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuNb80LW8AAN4pN.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DWiEXlO7qi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784571869835980800",
  "text" : "I had so much food, not that great, must now diet https:\/\/t.co\/DWiEXlO7qi",
  "id" : 784571869835980800,
  "created_at" : "2016-10-08 01:51:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BI Markets",
      "screen_name" : "themoneygame",
      "indices" : [ 3, 16 ],
      "id_str" : "65448361",
      "id" : 65448361
    }, {
      "name" : "Reuters Business",
      "screen_name" : "ReutersBiz",
      "indices" : [ 92, 103 ],
      "id_str" : "15110357",
      "id" : 15110357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/5PvuCFFD9j",
      "expanded_url" : "http:\/\/read.bi\/2cVnhCx",
      "display_url" : "read.bi\/2cVnhCx"
    } ]
  },
  "geo" : { },
  "id_str" : "784116170718908416",
  "text" : "RT @themoneygame: Two huge hedge funds are backing away from bets against Deutsche Bank via @reutersbiz https:\/\/t.co\/5PvuCFFD9j https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.businessinsider.com\" rel=\"nofollow\"\u003EBusiness Insider\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reuters Business",
        "screen_name" : "ReutersBiz",
        "indices" : [ 74, 85 ],
        "id_str" : "15110357",
        "id" : 15110357
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/themoneygame\/status\/784115540075872257\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/6FXZIOCrPK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CuG87VOWEAAobLD.jpg",
        "id_str" : "784115537634791424",
        "id" : 784115537634791424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuG87VOWEAAobLD.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6FXZIOCrPK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/5PvuCFFD9j",
        "expanded_url" : "http:\/\/read.bi\/2cVnhCx",
        "display_url" : "read.bi\/2cVnhCx"
      } ]
    },
    "geo" : { },
    "id_str" : "784115540075872257",
    "text" : "Two huge hedge funds are backing away from bets against Deutsche Bank via @reutersbiz https:\/\/t.co\/5PvuCFFD9j https:\/\/t.co\/6FXZIOCrPK",
    "id" : 784115540075872257,
    "created_at" : "2016-10-06 19:38:07 +0000",
    "user" : {
      "name" : "BI Markets",
      "screen_name" : "themoneygame",
      "protected" : false,
      "id_str" : "65448361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573909730222940162\/pAlz5ADn_normal.png",
      "id" : 65448361,
      "verified" : false
    }
  },
  "id" : 784116170718908416,
  "created_at" : "2016-10-06 19:40:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784116144101785605",
  "text" : "Life confuses you sometimes, it does that \uD83E\uDD14\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14",
  "id" : 784116144101785605,
  "created_at" : "2016-10-06 19:40:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783757610419970049",
  "text" : "Life.... \uD83D\uDE0E\uD83D\uDE10",
  "id" : 783757610419970049,
  "created_at" : "2016-10-05 19:55:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/7DXl6P6yaY",
      "expanded_url" : "http:\/\/fb.me\/RQKdJHmP",
      "display_url" : "fb.me\/RQKdJHmP"
    } ]
  },
  "geo" : { },
  "id_str" : "783757548952444932",
  "text" : "RT @EmperorDarroux: Hurricane Matthew could take out the US' newest weather satellite before it launches https:\/\/t.co\/7DXl6P6yaY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/7DXl6P6yaY",
        "expanded_url" : "http:\/\/fb.me\/RQKdJHmP",
        "display_url" : "fb.me\/RQKdJHmP"
      } ]
    },
    "geo" : { },
    "id_str" : "783751561193332736",
    "text" : "Hurricane Matthew could take out the US' newest weather satellite before it launches https:\/\/t.co\/7DXl6P6yaY",
    "id" : 783751561193332736,
    "created_at" : "2016-10-05 19:31:48 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 783757548952444932,
  "created_at" : "2016-10-05 19:55:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MJ Krey \u2744\uFE0F",
      "screen_name" : "mjkrey",
      "indices" : [ 3, 10 ],
      "id_str" : "21569127",
      "id" : 21569127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783751712020525056",
  "text" : "RT @mjkrey: I have the day off. Could someone please tell me what to draw today?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783694629669629954",
    "text" : "I have the day off. Could someone please tell me what to draw today?",
    "id" : 783694629669629954,
    "created_at" : "2016-10-05 15:45:34 +0000",
    "user" : {
      "name" : "MJ Krey \u2744\uFE0F",
      "screen_name" : "mjkrey",
      "protected" : false,
      "id_str" : "21569127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881608602489954304\/cZ-hcJ6P_normal.jpg",
      "id" : 21569127,
      "verified" : false
    }
  },
  "id" : 783751712020525056,
  "created_at" : "2016-10-05 19:32:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783751570492096513",
  "text" : "People need to mind what they aren't part off \uD83D\uDE20\uD83D\uDE20\uD83D\uDE20",
  "id" : 783751570492096513,
  "created_at" : "2016-10-05 19:31:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BulliesAndBarbells",
      "screen_name" : "jb1027",
      "indices" : [ 3, 10 ],
      "id_str" : "35239014",
      "id" : 35239014
    }, {
      "name" : "Jeff B\/DDHQ",
      "screen_name" : "EsotericCD",
      "indices" : [ 12, 23 ],
      "id_str" : "161163311",
      "id" : 161163311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783751472827752450",
  "text" : "RT @jb1027: @EsotericCD keep an eye out for a headline that been all over the internet for hours \uD83E\uDD14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff B\/DDHQ",
        "screen_name" : "EsotericCD",
        "indices" : [ 0, 11 ],
        "id_str" : "161163311",
        "id" : 161163311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "783643191056666624",
    "geo" : { },
    "id_str" : "783643662269972480",
    "in_reply_to_user_id" : 161163311,
    "text" : "@EsotericCD keep an eye out for a headline that been all over the internet for hours \uD83E\uDD14",
    "id" : 783643662269972480,
    "in_reply_to_status_id" : 783643191056666624,
    "created_at" : "2016-10-05 12:23:03 +0000",
    "in_reply_to_screen_name" : "EsotericCD",
    "in_reply_to_user_id_str" : "161163311",
    "user" : {
      "name" : "BulliesAndBarbells",
      "screen_name" : "jb1027",
      "protected" : false,
      "id_str" : "35239014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875504006126325760\/OLlQtdfw_normal.jpg",
      "id" : 35239014,
      "verified" : false
    }
  },
  "id" : 783751472827752450,
  "created_at" : "2016-10-05 19:31:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/JfZLaVFzv2",
      "expanded_url" : "http:\/\/cleveland.com",
      "display_url" : "cleveland.com"
    } ]
  },
  "geo" : { },
  "id_str" : "783659646573830145",
  "text" : "RT @andikhm01: Ohio State football: The case for Curtis Samuel as the Buckeyes Heisman Trophy candidate - https:\/\/t.co\/JfZLaVFzv2 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/JfZLaVFzv2",
        "expanded_url" : "http:\/\/cleveland.com",
        "display_url" : "cleveland.com"
      }, {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/pNRpjwhN7Y",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNFdjBIjUTOeBYtv1XuuyDxBR0O2jA&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779228221548&ei=H_f0V9DZEcKQuwLVzJfwBw&url=http%3A%2F%2Fwww.cleveland.com%2Fosu%2Findex.ssf%2F2016%2F10%2Fohio_state_football_the_case_f_1.html&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783650718292905984",
    "text" : "Ohio State football: The case for Curtis Samuel as the Buckeyes Heisman Trophy candidate - https:\/\/t.co\/JfZLaVFzv2 https:\/\/t.co\/pNRpjwhN7Y",
    "id" : 783650718292905984,
    "created_at" : "2016-10-05 12:51:05 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 783659646573830145,
  "created_at" : "2016-10-05 13:26:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/jLayq1HQ0J",
      "expanded_url" : "http:\/\/ow.ly\/VY0X304Js8V",
      "display_url" : "ow.ly\/VY0X304Js8V"
    } ]
  },
  "geo" : { },
  "id_str" : "783659546573152260",
  "text" : "RT @analyticbridge: Operationalizing Data Analytics with Pivotal and Forrester https:\/\/t.co\/jLayq1HQ0J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/jLayq1HQ0J",
        "expanded_url" : "http:\/\/ow.ly\/VY0X304Js8V",
        "display_url" : "ow.ly\/VY0X304Js8V"
      } ]
    },
    "geo" : { },
    "id_str" : "783547606832119813",
    "text" : "Operationalizing Data Analytics with Pivotal and Forrester https:\/\/t.co\/jLayq1HQ0J",
    "id" : 783547606832119813,
    "created_at" : "2016-10-05 06:01:21 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 783659546573152260,
  "created_at" : "2016-10-05 13:26:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SocialTechy.com",
      "screen_name" : "SocialTechy",
      "indices" : [ 3, 15 ],
      "id_str" : "550396534",
      "id" : 550396534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/rgi9hqydBH",
      "expanded_url" : "http:\/\/bit.ly\/2dsASQ0",
      "display_url" : "bit.ly\/2dsASQ0"
    } ]
  },
  "geo" : { },
  "id_str" : "783659476863873026",
  "text" : "RT @SocialTechy: The Impact Of Social Signals On SEO: It is a no brainer to say that keywords drive search ra... https:\/\/t.co\/rgi9hqydBH vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SocialTechy.com",
        "screen_name" : "SocialTechy",
        "indices" : [ 124, 136 ],
        "id_str" : "550396534",
        "id" : 550396534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/rgi9hqydBH",
        "expanded_url" : "http:\/\/bit.ly\/2dsASQ0",
        "display_url" : "bit.ly\/2dsASQ0"
      } ]
    },
    "geo" : { },
    "id_str" : "783585942166577152",
    "text" : "The Impact Of Social Signals On SEO: It is a no brainer to say that keywords drive search ra... https:\/\/t.co\/rgi9hqydBH via @SocialTechy",
    "id" : 783585942166577152,
    "created_at" : "2016-10-05 08:33:41 +0000",
    "user" : {
      "name" : "SocialTechy.com",
      "screen_name" : "SocialTechy",
      "protected" : false,
      "id_str" : "550396534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2688351048\/68ab36eb2cf745fbe9dafd889f9f9712_normal.png",
      "id" : 550396534,
      "verified" : false
    }
  },
  "id" : 783659476863873026,
  "created_at" : "2016-10-05 13:25:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783659453342183428",
  "text" : "RT @lorenridinger: \"When you're good at making excuses, it's hard to excel at anything else.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783607862278914049",
    "text" : "\"When you're good at making excuses, it's hard to excel at anything else.\"",
    "id" : 783607862278914049,
    "created_at" : "2016-10-05 10:00:47 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 783659453342183428,
  "created_at" : "2016-10-05 13:25:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "basket of winners",
      "screen_name" : "chalicezimmer",
      "indices" : [ 3, 17 ],
      "id_str" : "741864891879817217",
      "id" : 741864891879817217
    }, {
      "name" : "Sergio Michel",
      "screen_name" : "SMichelMusic",
      "indices" : [ 19, 32 ],
      "id_str" : "233627820",
      "id" : 233627820
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 33, 45 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783659423294185472",
  "text" : "RT @chalicezimmer: @SMichelMusic @KassyDillon I was thinking a strawberry daiquiri but same thing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sergio Michel",
        "screen_name" : "SMichelMusic",
        "indices" : [ 0, 13 ],
        "id_str" : "233627820",
        "id" : 233627820
      }, {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 14, 26 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "783484489066348544",
    "geo" : { },
    "id_str" : "783485034300788736",
    "in_reply_to_user_id" : 233627820,
    "text" : "@SMichelMusic @KassyDillon I was thinking a strawberry daiquiri but same thing",
    "id" : 783485034300788736,
    "in_reply_to_status_id" : 783484489066348544,
    "created_at" : "2016-10-05 01:52:43 +0000",
    "in_reply_to_screen_name" : "SMichelMusic",
    "in_reply_to_user_id_str" : "233627820",
    "user" : {
      "name" : "basket of winners",
      "screen_name" : "chalicezimmer",
      "protected" : false,
      "id_str" : "741864891879817217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830310413233332225\/k5HN_Rhu_normal.jpg",
      "id" : 741864891879817217,
      "verified" : false
    }
  },
  "id" : 783659423294185472,
  "created_at" : "2016-10-05 13:25:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783659258118303745",
  "text" : "RT @Gillette: Growing a beard is one thing. Maintaining it is just as important. Click here for some Gillette Styler ideas.https:\/\/t.co\/nI7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/nI7kUrMlEO",
        "expanded_url" : "http:\/\/spr.ly\/6013Bhsb7",
        "display_url" : "spr.ly\/6013Bhsb7"
      } ]
    },
    "geo" : { },
    "id_str" : "783637870963728384",
    "text" : "Growing a beard is one thing. Maintaining it is just as important. Click here for some Gillette Styler ideas.https:\/\/t.co\/nI7kUrMlEO",
    "id" : 783637870963728384,
    "created_at" : "2016-10-05 12:00:02 +0000",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 783659258118303745,
  "created_at" : "2016-10-05 13:25:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783547574292807680",
  "geo" : { },
  "id_str" : "783659169060708352",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget I like the design behind it",
  "id" : 783659169060708352,
  "in_reply_to_status_id" : 783547574292807680,
  "created_at" : "2016-10-05 13:24:40 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783658948754800640",
  "text" : "RT @scrowder: New Doubts About Hillary? You'll have them after my exclusive interview with Juanita Brodderick on Thursday. Trust me. 8PM ET",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783637170129166336",
    "text" : "New Doubts About Hillary? You'll have them after my exclusive interview with Juanita Brodderick on Thursday. Trust me. 8PM ET",
    "id" : 783637170129166336,
    "created_at" : "2016-10-05 11:57:15 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 783658948754800640,
  "created_at" : "2016-10-05 13:23:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "783637645008273408",
  "geo" : { },
  "id_str" : "783658894912524288",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon One of the coolest girls to rank in the strings of Reddit",
  "id" : 783658894912524288,
  "in_reply_to_status_id" : 783637645008273408,
  "created_at" : "2016-10-05 13:23:34 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/1fCRbZvRHo",
      "expanded_url" : "https:\/\/theringer.com\/ranking-potential-saboteurs-of-elon-musks-spacex-venture-ff66e7e2b23f#.kdgjprg5c",
      "display_url" : "theringer.com\/ranking-potent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783658574165708800",
  "text" : "RT @elonmusk: Sabotage of the rocket is unlikely, but this article has some great theories :)\nhttps:\/\/t.co\/1fCRbZvRHo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/1fCRbZvRHo",
        "expanded_url" : "https:\/\/theringer.com\/ranking-potential-saboteurs-of-elon-musks-spacex-venture-ff66e7e2b23f#.kdgjprg5c",
        "display_url" : "theringer.com\/ranking-potent\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783567161402888192",
    "text" : "Sabotage of the rocket is unlikely, but this article has some great theories :)\nhttps:\/\/t.co\/1fCRbZvRHo",
    "id" : 783567161402888192,
    "created_at" : "2016-10-05 07:19:03 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 783658574165708800,
  "created_at" : "2016-10-05 13:22:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/tvHEul52Wq",
      "expanded_url" : "http:\/\/mashable.com\/2016\/10\/05\/smart-clothing-solar-power\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/10\/05\/sma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783658544377847808",
  "text" : "RT @EmperorDarroux: New 'smart textiles' can produce and store solar energy https:\/\/t.co\/tvHEul52Wq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/tvHEul52Wq",
        "expanded_url" : "http:\/\/mashable.com\/2016\/10\/05\/smart-clothing-solar-power\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/10\/05\/sma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783656636166524928",
    "text" : "New 'smart textiles' can produce and store solar energy https:\/\/t.co\/tvHEul52Wq",
    "id" : 783656636166524928,
    "created_at" : "2016-10-05 13:14:36 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 783658544377847808,
  "created_at" : "2016-10-05 13:22:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dinesh D'Souza",
      "screen_name" : "DineshDSouza",
      "indices" : [ 3, 16 ],
      "id_str" : "91882544",
      "id" : 91882544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783658523997696000",
  "text" : "RT @DineshDSouza: Comey has done incalculable damage to the FBI by making it an accessory--rather than an obstacle--to criminal acts at the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DineshDSouza\/status\/783309772594356225\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/Kkmcll66Dr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct7gE-HVUAALfs2.jpg",
        "id_str" : "783309761206898688",
        "id" : 783309761206898688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct7gE-HVUAALfs2.jpg",
        "sizes" : [ {
          "h" : 470,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1415,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 829,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1415,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Kkmcll66Dr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783309772594356225",
    "text" : "Comey has done incalculable damage to the FBI by making it an accessory--rather than an obstacle--to criminal acts at the highest levels https:\/\/t.co\/Kkmcll66Dr",
    "id" : 783309772594356225,
    "created_at" : "2016-10-04 14:16:17 +0000",
    "user" : {
      "name" : "Dinesh D'Souza",
      "screen_name" : "DineshDSouza",
      "protected" : false,
      "id_str" : "91882544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882308997059104769\/RaDT65KC_normal.jpg",
      "id" : 91882544,
      "verified" : true
    }
  },
  "id" : 783658523997696000,
  "created_at" : "2016-10-05 13:22:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783658494897582080",
  "text" : "RT @Evan_McMullin: Hillary Clinton is a tax-and-spend liberal who favors big, centralized government, but I have more hope that Congress wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783369240648626176",
    "text" : "Hillary Clinton is a tax-and-spend liberal who favors big, centralized government, but I have more hope that Congress would oppose her.",
    "id" : 783369240648626176,
    "created_at" : "2016-10-04 18:12:35 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 783658494897582080,
  "created_at" : "2016-10-05 13:21:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OULife",
      "indices" : [ 98, 105 ]
    }, {
      "text" : "ThisIsOU",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783658438660354048",
  "text" : "That moment when someone you don't know barges in and acts rude towards you, ruins your whole day #OULife #ThisIsOU",
  "id" : 783658438660354048,
  "created_at" : "2016-10-05 13:21:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/783513153707606016\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/FLmW7wLKLi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct-ZDyrW8AAz2Xb.jpg",
      "id_str" : "783513150608044032",
      "id" : 783513150608044032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct-ZDyrW8AAz2Xb.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/FLmW7wLKLi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/birDfzmkli",
      "expanded_url" : "http:\/\/engt.co\/2dHX5r1",
      "display_url" : "engt.co\/2dHX5r1"
    } ]
  },
  "geo" : { },
  "id_str" : "783656873866190849",
  "text" : "RT @engadget: UberPool riders in London might have to do some walking https:\/\/t.co\/birDfzmkli https:\/\/t.co\/FLmW7wLKLi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/783513153707606016\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/FLmW7wLKLi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct-ZDyrW8AAz2Xb.jpg",
        "id_str" : "783513150608044032",
        "id" : 783513150608044032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct-ZDyrW8AAz2Xb.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/FLmW7wLKLi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/birDfzmkli",
        "expanded_url" : "http:\/\/engt.co\/2dHX5r1",
        "display_url" : "engt.co\/2dHX5r1"
      } ]
    },
    "geo" : { },
    "id_str" : "783513153707606016",
    "text" : "UberPool riders in London might have to do some walking https:\/\/t.co\/birDfzmkli https:\/\/t.co\/FLmW7wLKLi",
    "id" : 783513153707606016,
    "created_at" : "2016-10-05 03:44:27 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 783656873866190849,
  "created_at" : "2016-10-05 13:15:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783656693049782272",
  "text" : "I wish I was in real life I am as smooth as I am in my head",
  "id" : 783656693049782272,
  "created_at" : "2016-10-05 13:14:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myrrranda",
      "screen_name" : "MyrWisniewski",
      "indices" : [ 3, 17 ],
      "id_str" : "309229799",
      "id" : 309229799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisisOU",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783499749945204737",
  "text" : "RT @MyrWisniewski: The real question is how many free bibles will I get on campus this year? #ThisisOU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThisisOU",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "781098644850302978",
    "text" : "The real question is how many free bibles will I get on campus this year? #ThisisOU",
    "id" : 781098644850302978,
    "created_at" : "2016-09-28 11:50:03 +0000",
    "user" : {
      "name" : "Myrrranda",
      "screen_name" : "MyrWisniewski",
      "protected" : false,
      "id_str" : "309229799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880119054081695755\/6n_pVmRg_normal.jpg",
      "id" : 309229799,
      "verified" : false
    }
  },
  "id" : 783499749945204737,
  "created_at" : "2016-10-05 02:51:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "indices" : [ 3, 15 ],
      "id_str" : "15231287",
      "id" : 15231287
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cloud",
      "indices" : [ 46, 52 ]
    }, {
      "text" : "App",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/pYnEBqZptw",
      "expanded_url" : "http:\/\/gtnr.it\/2cKO6ux",
      "display_url" : "gtnr.it\/2cKO6ux"
    } ]
  },
  "geo" : { },
  "id_str" : "783406246305140736",
  "text" : "RT @Gartner_inc: Webinar, 10\/5, 10 am ET: How #Cloud Is Revolutionizing Modern #App Development https:\/\/t.co\/pYnEBqZptw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.engage121.com\" rel=\"nofollow\"\u003Eengage121\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cloud",
        "indices" : [ 29, 35 ]
      }, {
        "text" : "App",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/pYnEBqZptw",
        "expanded_url" : "http:\/\/gtnr.it\/2cKO6ux",
        "display_url" : "gtnr.it\/2cKO6ux"
      } ]
    },
    "geo" : { },
    "id_str" : "783365584339730436",
    "text" : "Webinar, 10\/5, 10 am ET: How #Cloud Is Revolutionizing Modern #App Development https:\/\/t.co\/pYnEBqZptw",
    "id" : 783365584339730436,
    "created_at" : "2016-10-04 17:58:04 +0000",
    "user" : {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "protected" : false,
      "id_str" : "15231287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479292472707649536\/HfChXWQy_normal.png",
      "id" : 15231287,
      "verified" : true
    }
  },
  "id" : 783406246305140736,
  "created_at" : "2016-10-04 20:39:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/783318244593721345\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/TrRIkW3iF8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct7nucJXYAIn9FD.jpg",
      "id_str" : "783318170224517122",
      "id" : 783318170224517122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct7nucJXYAIn9FD.jpg",
      "sizes" : [ {
        "h" : 992,
        "resize" : "fit",
        "w" : 1142
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 1142
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 992,
        "resize" : "fit",
        "w" : 1142
      } ],
      "display_url" : "pic.twitter.com\/TrRIkW3iF8"
    } ],
    "hashtags" : [ {
      "text" : "NationalTacoDay",
      "indices" : [ 24, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783406106391506945",
  "text" : "RT @TeamMcMullin: Happy #NationalTacoDay! Thank you to entrepreneurs across the country who sell delicious tacos \uD83C\uDF2E https:\/\/t.co\/TrRIkW3iF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/783318244593721345\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/TrRIkW3iF8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct7nucJXYAIn9FD.jpg",
        "id_str" : "783318170224517122",
        "id" : 783318170224517122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct7nucJXYAIn9FD.jpg",
        "sizes" : [ {
          "h" : 992,
          "resize" : "fit",
          "w" : 1142
        }, {
          "h" : 992,
          "resize" : "fit",
          "w" : 1142
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 992,
          "resize" : "fit",
          "w" : 1142
        } ],
        "display_url" : "pic.twitter.com\/TrRIkW3iF8"
      } ],
      "hashtags" : [ {
        "text" : "NationalTacoDay",
        "indices" : [ 6, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783318244593721345",
    "text" : "Happy #NationalTacoDay! Thank you to entrepreneurs across the country who sell delicious tacos \uD83C\uDF2E https:\/\/t.co\/TrRIkW3iF8",
    "id" : 783318244593721345,
    "created_at" : "2016-10-04 14:49:57 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 783406106391506945,
  "created_at" : "2016-10-04 20:39:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMAOaklandUniversity",
      "screen_name" : "AMA_OU",
      "indices" : [ 0, 7 ],
      "id_str" : "75138351",
      "id" : 75138351
    }, {
      "name" : "Manuella Oraha",
      "screen_name" : "ManuOraha",
      "indices" : [ 8, 18 ],
      "id_str" : "211000945",
      "id" : 211000945
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/783406064997900289\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/5rs2WU8bBp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct83qLDWAAAsvxI.jpg",
      "id_str" : "783406057846603776",
      "id" : 783406057846603776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct83qLDWAAAsvxI.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/5rs2WU8bBp"
    } ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 49, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783406064997900289",
  "in_reply_to_user_id" : 75138351,
  "text" : "@AMA_OU @ManuOraha Marketing week is starting at #OU. Time to see students pretend to make bad fashion choices while looking glamorous, lol https:\/\/t.co\/5rs2WU8bBp",
  "id" : 783406064997900289,
  "created_at" : "2016-10-04 20:38:55 +0000",
  "in_reply_to_screen_name" : "AMA_OU",
  "in_reply_to_user_id_str" : "75138351",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Le' Great",
      "screen_name" : "DarielEmbry",
      "indices" : [ 3, 15 ],
      "id_str" : "313162621",
      "id" : 313162621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783360232537911296",
  "text" : "RT @DarielEmbry: Sometimes people have to make their own mistakes. You can talk to someone till you're blue in the face but they still go d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783029191381954560",
    "text" : "Sometimes people have to make their own mistakes. You can talk to someone till you're blue in the face but they still go do what they want.",
    "id" : 783029191381954560,
    "created_at" : "2016-10-03 19:41:21 +0000",
    "user" : {
      "name" : "Le' Great",
      "screen_name" : "DarielEmbry",
      "protected" : false,
      "id_str" : "313162621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870361048552886276\/Z2bprSgG_normal.jpg",
      "id" : 313162621,
      "verified" : false
    }
  },
  "id" : 783360232537911296,
  "created_at" : "2016-10-04 17:36:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Heat Street",
      "screen_name" : "heatstreet",
      "indices" : [ 105, 116 ],
      "id_str" : "4509306615",
      "id" : 4509306615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/G6XOWeIfdF",
      "expanded_url" : "http:\/\/www.facebook.com\/heatstreetmedia\/videos\/1285638521449139",
      "display_url" : "facebook.com\/heatstreetmedi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783360175176617984",
  "text" : "RT @Evan_McMullin: Our Constitution is inspired, but America needs wise leaders. https:\/\/t.co\/G6XOWeIfdF @heatstreet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heat Street",
        "screen_name" : "heatstreet",
        "indices" : [ 86, 97 ],
        "id_str" : "4509306615",
        "id" : 4509306615
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/G6XOWeIfdF",
        "expanded_url" : "http:\/\/www.facebook.com\/heatstreetmedia\/videos\/1285638521449139",
        "display_url" : "facebook.com\/heatstreetmedi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783359897844920320",
    "text" : "Our Constitution is inspired, but America needs wise leaders. https:\/\/t.co\/G6XOWeIfdF @heatstreet",
    "id" : 783359897844920320,
    "created_at" : "2016-10-04 17:35:28 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 783360175176617984,
  "created_at" : "2016-10-04 17:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar & Jan",
      "screen_name" : "clupko",
      "indices" : [ 3, 10 ],
      "id_str" : "28507777",
      "id" : 28507777
    }, {
      "name" : "Lue Jun Yi",
      "screen_name" : "sixteendec",
      "indices" : [ 79, 90 ],
      "id_str" : "153056822",
      "id" : 153056822
    }, {
      "name" : "Dine in Dublin",
      "screen_name" : "dineindublin",
      "indices" : [ 91, 104 ],
      "id_str" : "1057968542",
      "id" : 1057968542
    }, {
      "name" : "Uchenna Ekweremadu",
      "screen_name" : "Uchekweremadu",
      "indices" : [ 105, 119 ],
      "id_str" : "73684848",
      "id" : 73684848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "friday",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/l6LTi92CfT",
      "expanded_url" : "http:\/\/paper.li\/clupko\/1330788913?edition_id=0f6c3450-8a38-11e6-ab6f-002590a5ba2d",
      "display_url" : "paper.li\/clupko\/1330788\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "783360122940719104",
  "text" : "RT @clupko: The latest Clupko's Music Paper! https:\/\/t.co\/l6LTi92CfT Thanks to @sixteendec @dineindublin @Uchekweremadu #friday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lue Jun Yi",
        "screen_name" : "sixteendec",
        "indices" : [ 67, 78 ],
        "id_str" : "153056822",
        "id" : 153056822
      }, {
        "name" : "Dine in Dublin",
        "screen_name" : "dineindublin",
        "indices" : [ 79, 92 ],
        "id_str" : "1057968542",
        "id" : 1057968542
      }, {
        "name" : "Uchenna Ekweremadu",
        "screen_name" : "Uchekweremadu",
        "indices" : [ 93, 107 ],
        "id_str" : "73684848",
        "id" : 73684848
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "friday",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/l6LTi92CfT",
        "expanded_url" : "http:\/\/paper.li\/clupko\/1330788913?edition_id=0f6c3450-8a38-11e6-ab6f-002590a5ba2d",
        "display_url" : "paper.li\/clupko\/1330788\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "783359843931389952",
    "text" : "The latest Clupko's Music Paper! https:\/\/t.co\/l6LTi92CfT Thanks to @sixteendec @dineindublin @Uchekweremadu #friday",
    "id" : 783359843931389952,
    "created_at" : "2016-10-04 17:35:15 +0000",
    "user" : {
      "name" : "Skylar & Jan",
      "screen_name" : "clupko",
      "protected" : false,
      "id_str" : "28507777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547853184191176706\/NVTHb4L5_normal.jpeg",
      "id" : 28507777,
      "verified" : false
    }
  },
  "id" : 783360122940719104,
  "created_at" : "2016-10-04 17:36:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783360057291501568",
  "text" : "RT @Evan_McMullin: Trump cares more about himself than he cares about the country. He's willing to engage in business deals against our nat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "783359027652591616",
    "text" : "Trump cares more about himself than he cares about the country. He's willing to engage in business deals against our national interest.",
    "id" : 783359027652591616,
    "created_at" : "2016-10-04 17:32:00 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 783360057291501568,
  "created_at" : "2016-10-04 17:36:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/783359881399197700\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/HRyFA2Gb3Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ct8Np87WEAAemSc.jpg",
      "id_str" : "783359874566590464",
      "id" : 783359874566590464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ct8Np87WEAAemSc.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HRyFA2Gb3Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783359881399197700",
  "text" : "This gave me heartburn but wasn't bad https:\/\/t.co\/HRyFA2Gb3Q",
  "id" : 783359881399197700,
  "created_at" : "2016-10-04 17:35:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783359717393530889",
  "text" : "Yara or Lara always seem somewhat excited to see me \uD83D\uDE12",
  "id" : 783359717393530889,
  "created_at" : "2016-10-04 17:34:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Android apps",
      "screen_name" : "NewAndroidApps",
      "indices" : [ 3, 18 ],
      "id_str" : "118044267",
      "id" : 118044267
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "app",
      "indices" : [ 33, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/IqyqGKspHj",
      "expanded_url" : "https:\/\/goo.gl\/V4xXdS",
      "display_url" : "goo.gl\/V4xXdS"
    } ]
  },
  "geo" : { },
  "id_str" : "783024486778109952",
  "text" : "RT @NewAndroidApps: New #android #app: StartHub Pro Messenger https:\/\/t.co\/IqyqGKspHj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.appbrain.com\" rel=\"nofollow\"\u003EAppBrain Android Apps\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "app",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/IqyqGKspHj",
        "expanded_url" : "https:\/\/goo.gl\/V4xXdS",
        "display_url" : "goo.gl\/V4xXdS"
      } ]
    },
    "geo" : { },
    "id_str" : "782817330799587328",
    "text" : "New #android #app: StartHub Pro Messenger https:\/\/t.co\/IqyqGKspHj",
    "id" : 782817330799587328,
    "created_at" : "2016-10-03 05:39:30 +0000",
    "user" : {
      "name" : "New Android apps",
      "screen_name" : "NewAndroidApps",
      "protected" : false,
      "id_str" : "118044267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077889707\/android-logo_normal.jpg",
      "id" : 118044267,
      "verified" : false
    }
  },
  "id" : 783024486778109952,
  "created_at" : "2016-10-03 19:22:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liquid Edge",
      "screen_name" : "Liquid_edge",
      "indices" : [ 3, 15 ],
      "id_str" : "2886943243",
      "id" : 2886943243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoldCoast",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "WebDesign",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Eza5gYxrwS",
      "expanded_url" : "http:\/\/dlvr.it\/LV9Fyl",
      "display_url" : "dlvr.it\/LV9Fyl"
    } ]
  },
  "geo" : { },
  "id_str" : "783024286667829248",
  "text" : "RT @Liquid_edge: #GoldCoast #WebDesign University student Andrew Kamal set to change the world of social\u2026 https:\/\/t.co\/Eza5gYxrwS https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Liquid_edge\/status\/739730829295812608\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/1VXzCGANmy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkQNRJhUkAANJGg.jpg",
        "id_str" : "739730827060219904",
        "id" : 739730827060219904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkQNRJhUkAANJGg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/1VXzCGANmy"
      } ],
      "hashtags" : [ {
        "text" : "GoldCoast",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "WebDesign",
        "indices" : [ 11, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Eza5gYxrwS",
        "expanded_url" : "http:\/\/dlvr.it\/LV9Fyl",
        "display_url" : "dlvr.it\/LV9Fyl"
      } ]
    },
    "geo" : { },
    "id_str" : "739730829295812608",
    "text" : "#GoldCoast #WebDesign University student Andrew Kamal set to change the world of social\u2026 https:\/\/t.co\/Eza5gYxrwS https:\/\/t.co\/1VXzCGANmy",
    "id" : 739730829295812608,
    "created_at" : "2016-06-06 08:09:07 +0000",
    "user" : {
      "name" : "Liquid Edge",
      "screen_name" : "Liquid_edge",
      "protected" : false,
      "id_str" : "2886943243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528742672190562305\/UUc6zLFG_normal.png",
      "id" : 2886943243,
      "verified" : false
    }
  },
  "id" : 783024286667829248,
  "created_at" : "2016-10-03 19:21:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782969782052282368",
  "text" : "RT @BarbaraCorcoran: Remember this: People want to do business with people they like. RT if you agree!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782932231115382784",
    "text" : "Remember this: People want to do business with people they like. RT if you agree!",
    "id" : 782932231115382784,
    "created_at" : "2016-10-03 13:16:04 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 782969782052282368,
  "created_at" : "2016-10-03 15:45:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782969772594044928",
  "text" : "RT @KassyDillon: I can deal with screaming SJWs all day long, but the second you bring a clown or a spider into the equation, I tap out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782941286152175616",
    "text" : "I can deal with screaming SJWs all day long, but the second you bring a clown or a spider into the equation, I tap out.",
    "id" : 782941286152175616,
    "created_at" : "2016-10-03 13:52:03 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882255746267848704\/FuWwYd6d_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 782969772594044928,
  "created_at" : "2016-10-03 15:45:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Luci",
      "screen_name" : "emma_luci",
      "indices" : [ 3, 13 ],
      "id_str" : "2826987097",
      "id" : 2826987097
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IfISeeAClown",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931864076050433",
  "text" : "RT @emma_luci: #IfISeeAClown It could just be Hillary",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IfISeeAClown",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782926265883897857",
    "text" : "#IfISeeAClown It could just be Hillary",
    "id" : 782926265883897857,
    "created_at" : "2016-10-03 12:52:22 +0000",
    "user" : {
      "name" : "Emma Luci",
      "screen_name" : "emma_luci",
      "protected" : false,
      "id_str" : "2826987097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859633010383171585\/DGTrPPBY_normal.jpg",
      "id" : 2826987097,
      "verified" : false
    }
  },
  "id" : 782931864076050433,
  "created_at" : "2016-10-03 13:14:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriela",
      "screen_name" : "prajitoruldinoz",
      "indices" : [ 3, 19 ],
      "id_str" : "187149099",
      "id" : 187149099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931666679504896",
  "text" : "RT @prajitoruldinoz: @itsskirstyy Haha, who is that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "782894669957107712",
    "geo" : { },
    "id_str" : "782901900144472064",
    "in_reply_to_user_id" : 750281739545763840,
    "text" : "@itsskirstyy Haha, who is that?",
    "id" : 782901900144472064,
    "in_reply_to_status_id" : 782894669957107712,
    "created_at" : "2016-10-03 11:15:33 +0000",
    "in_reply_to_screen_name" : "gvldenkirstyy",
    "in_reply_to_user_id_str" : "750281739545763840",
    "user" : {
      "name" : "Gabriela",
      "screen_name" : "prajitoruldinoz",
      "protected" : false,
      "id_str" : "187149099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782971600459137024\/ZXt8-ONh_normal.jpg",
      "id" : 187149099,
      "verified" : false
    }
  },
  "id" : 782931666679504896,
  "created_at" : "2016-10-03 13:13:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric",
      "screen_name" : "elfortney",
      "indices" : [ 3, 13 ],
      "id_str" : "11509132",
      "id" : 11509132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mondaymotivation",
      "indices" : [ 88, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931585377116160",
  "text" : "RT @elfortney: Don't let anything, including Mondays, get in the way of your happiness. #mondaymotivation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 73, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782925740853620736",
    "text" : "Don't let anything, including Mondays, get in the way of your happiness. #mondaymotivation",
    "id" : 782925740853620736,
    "created_at" : "2016-10-03 12:50:17 +0000",
    "user" : {
      "name" : "Eric",
      "screen_name" : "elfortney",
      "protected" : false,
      "id_str" : "11509132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882598059196207104\/MkUtOX-x_normal.jpg",
      "id" : 11509132,
      "verified" : false
    }
  },
  "id" : 782931585377116160,
  "created_at" : "2016-10-03 13:13:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marucci",
      "screen_name" : "MarucciSports",
      "indices" : [ 3, 17 ],
      "id_str" : "90502888",
      "id" : 90502888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931549511614464",
  "text" : "RT @MarucciSports: \"When bad things happen you have 3 choices: \n\nLet it define you, let it destroy you, or let it strengthen you.\"\n\n#monday\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 113, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782925808465768448",
    "text" : "\"When bad things happen you have 3 choices: \n\nLet it define you, let it destroy you, or let it strengthen you.\"\n\n#mondaymotivation",
    "id" : 782925808465768448,
    "created_at" : "2016-10-03 12:50:33 +0000",
    "user" : {
      "name" : "Marucci",
      "screen_name" : "MarucciSports",
      "protected" : false,
      "id_str" : "90502888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446844354187911169\/flQvrtBK_normal.jpeg",
      "id" : 90502888,
      "verified" : true
    }
  },
  "id" : 782931549511614464,
  "created_at" : "2016-10-03 13:13:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Get Fruity",
      "screen_name" : "GetFruityBar",
      "indices" : [ 3, 16 ],
      "id_str" : "2263257781",
      "id" : 2263257781
    }, {
      "name" : "Get Fruity",
      "screen_name" : "GetFruityBar",
      "indices" : [ 100, 113 ],
      "id_str" : "2263257781",
      "id" : 2263257781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WIN",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "Strawberry",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "mondaymotivation",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931496831246337",
  "text" : "RT @GetFruityBar: RT &amp; FOLLOW We want to make your Monday a little better #WIN some #Strawberry @GetFruityBar #mondaymotivation Ends Midnig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Get Fruity",
        "screen_name" : "GetFruityBar",
        "indices" : [ 82, 95 ],
        "id_str" : "2263257781",
        "id" : 2263257781
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GetFruityBar\/status\/782900071008526336\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/Dj7uL4vTuu",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct1q7uuXYAAYTWy.jpg",
        "id_str" : "782899484619661312",
        "id" : 782899484619661312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ct1q7uuXYAAYTWy.jpg",
        "sizes" : [ {
          "h" : 270,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 814,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1192,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Dj7uL4vTuu"
      } ],
      "hashtags" : [ {
        "text" : "WIN",
        "indices" : [ 60, 64 ]
      }, {
        "text" : "Strawberry",
        "indices" : [ 70, 81 ]
      }, {
        "text" : "mondaymotivation",
        "indices" : [ 96, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782900071008526336",
    "text" : "RT &amp; FOLLOW We want to make your Monday a little better #WIN some #Strawberry @GetFruityBar #mondaymotivation Ends Midnight 03\/10\/16 https:\/\/t.co\/Dj7uL4vTuu",
    "id" : 782900071008526336,
    "created_at" : "2016-10-03 11:08:17 +0000",
    "user" : {
      "name" : "Get Fruity",
      "screen_name" : "GetFruityBar",
      "protected" : false,
      "id_str" : "2263257781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454362741298327552\/2xIh1fCl_normal.png",
      "id" : 2263257781,
      "verified" : false
    }
  },
  "id" : 782931496831246337,
  "created_at" : "2016-10-03 13:13:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alissa Payne",
      "screen_name" : "alissapayne16",
      "indices" : [ 4, 18 ],
      "id_str" : "2366449783",
      "id" : 2366449783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782931384159592448",
  "text" : "Ask @alissapayne16 or my other OC buds, I always make people laugh though I am as funny as a cricket",
  "id" : 782931384159592448,
  "created_at" : "2016-10-03 13:12:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pat",
      "screen_name" : "Pcan52",
      "indices" : [ 3, 10 ],
      "id_str" : "619711023",
      "id" : 619711023
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 12, 24 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782911619584159744",
  "text" : "RT @Pcan52: @KassyDillon Why would you ever go to Chicopee? It's a terrible place",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "782793111961538560",
    "geo" : { },
    "id_str" : "782793943897501696",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon Why would you ever go to Chicopee? It's a terrible place",
    "id" : 782793943897501696,
    "in_reply_to_status_id" : 782793111961538560,
    "created_at" : "2016-10-03 04:06:34 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "Pat",
      "screen_name" : "Pcan52",
      "protected" : false,
      "id_str" : "619711023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867850146452779008\/fvgNX6nz_normal.jpg",
      "id" : 619711023,
      "verified" : false
    }
  },
  "id" : 782911619584159744,
  "created_at" : "2016-10-03 11:54:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teddi.zaps",
      "screen_name" : "VonKloss",
      "indices" : [ 3, 12 ],
      "id_str" : "1956515965",
      "id" : 1956515965
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 14, 26 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782911586960830468",
  "text" : "RT @VonKloss: @KassyDillon Is that Bernie hiding from his supporters ???",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "782793111961538560",
    "geo" : { },
    "id_str" : "782793809818161152",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon Is that Bernie hiding from his supporters ???",
    "id" : 782793809818161152,
    "in_reply_to_status_id" : 782793111961538560,
    "created_at" : "2016-10-03 04:06:02 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "teddi.zaps",
      "screen_name" : "VonKloss",
      "protected" : false,
      "id_str" : "1956515965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764912711411064836\/2VESc1k6_normal.jpg",
      "id" : 1956515965,
      "verified" : false
    }
  },
  "id" : 782911586960830468,
  "created_at" : "2016-10-03 11:54:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 20, 32 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782911566450683904",
  "text" : "RT @TheRealSchnick: @KassyDillon one was spotted near my college last week. Scarey as hell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "782793111961538560",
    "geo" : { },
    "id_str" : "782793805217009664",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon one was spotted near my college last week. Scarey as hell",
    "id" : 782793805217009664,
    "in_reply_to_status_id" : 782793111961538560,
    "created_at" : "2016-10-03 04:06:01 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "Tzar Nicholas",
      "screen_name" : "tzarnicholas",
      "protected" : false,
      "id_str" : "711145044154122240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881275844802617345\/D-eddrYz_normal.jpg",
      "id" : 711145044154122240,
      "verified" : false
    }
  },
  "id" : 782911566450683904,
  "created_at" : "2016-10-03 11:53:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782911515204648960",
  "text" : "Lay your weary head to rest, I can't I have morning classes",
  "id" : 782911515204648960,
  "created_at" : "2016-10-03 11:53:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/0Z7f6PBwGx",
      "expanded_url" : "http:\/\/CBSSports.com",
      "display_url" : "CBSSports.com"
    } ]
  },
  "geo" : { },
  "id_str" : "782608028541423618",
  "text" : "RT @andikhm01: College football winners and losers in Week 5: Clemson re-asserts itself in big way - https:\/\/t.co\/0Z7f6PBwGx https:\/\/t.co\/7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/0Z7f6PBwGx",
        "expanded_url" : "http:\/\/CBSSports.com",
        "display_url" : "CBSSports.com"
      }, {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/709yvtqHnD",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNEqdRYILNXqlokWoMRoEmZ7nYbR1Q&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779229982670&ei=ULPwV9ikBo7iugKNk6cw&url=http%3A%2F%2Fwww.cbssports.com%2Fcollege-football%2Fnews%2Fcollege-football-winners-and-losers-in-week-5-clemson-re-asserts-itself-in-big-way%2F&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782478494961836032",
    "text" : "College football winners and losers in Week 5: Clemson re-asserts itself in big way - https:\/\/t.co\/0Z7f6PBwGx https:\/\/t.co\/709yvtqHnD",
    "id" : 782478494961836032,
    "created_at" : "2016-10-02 07:13:05 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 782608028541423618,
  "created_at" : "2016-10-02 15:47:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneur",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607904893382658",
  "text" : "RT @BarbaraCorcoran: Book smarts are overrated. Street smarts and thinking fast on your feet make a great #entrepreneur!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneur",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782563374840344576",
    "text" : "Book smarts are overrated. Street smarts and thinking fast on your feet make a great #entrepreneur!",
    "id" : 782563374840344576,
    "created_at" : "2016-10-02 12:50:22 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 782607904893382658,
  "created_at" : "2016-10-02 15:47:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607851575324672",
  "text" : "RT @Gillette: Wake Up! It's time to watch some football. Are you ready for the day? If not, what's on your pre-game To Do?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782569573694447618",
    "text" : "Wake Up! It's time to watch some football. Are you ready for the day? If not, what's on your pre-game To Do?",
    "id" : 782569573694447618,
    "created_at" : "2016-10-02 13:15:00 +0000",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 782607851575324672,
  "created_at" : "2016-10-02 15:47:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782581080381542400\/video\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/IeNO907KpW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxJVwYVMAA20qv.jpg",
      "id_str" : "782580941591982080",
      "id" : 782580941591982080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxJVwYVMAA20qv.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/IeNO907KpW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9jgQ9ZCHRQ",
      "expanded_url" : "http:\/\/engt.co\/2dq6Qdd",
      "display_url" : "engt.co\/2dq6Qdd"
    } ]
  },
  "geo" : { },
  "id_str" : "782607825830674432",
  "text" : "RT @engadget: Mercedes-Benz\u200B is suddenly taking electric cars very seriously: https:\/\/t.co\/9jgQ9ZCHRQ https:\/\/t.co\/IeNO907KpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782581080381542400\/video\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/IeNO907KpW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxJVwYVMAA20qv.jpg",
        "id_str" : "782580941591982080",
        "id" : 782580941591982080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxJVwYVMAA20qv.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/IeNO907KpW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/9jgQ9ZCHRQ",
        "expanded_url" : "http:\/\/engt.co\/2dq6Qdd",
        "display_url" : "engt.co\/2dq6Qdd"
      } ]
    },
    "geo" : { },
    "id_str" : "782581080381542400",
    "text" : "Mercedes-Benz\u200B is suddenly taking electric cars very seriously: https:\/\/t.co\/9jgQ9ZCHRQ https:\/\/t.co\/IeNO907KpW",
    "id" : 782581080381542400,
    "created_at" : "2016-10-02 14:00:43 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 782607825830674432,
  "created_at" : "2016-10-02 15:47:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "AM Joy w\/Joy Reid",
      "screen_name" : "amjoyshow",
      "indices" : [ 41, 51 ],
      "id_str" : "731132367058968576",
      "id" : 731132367058968576
    }, {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "indices" : [ 57, 68 ],
      "id_str" : "49698134",
      "id" : 49698134
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 72, 78 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607796181225472",
  "text" : "RT @Evan_McMullin: I'm coming up next on @amjoyshow with @JoyAnnReid on @MSNBC.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AM Joy w\/Joy Reid",
        "screen_name" : "amjoyshow",
        "indices" : [ 22, 32 ],
        "id_str" : "731132367058968576",
        "id" : 731132367058968576
      }, {
        "name" : "Joy Reid",
        "screen_name" : "JoyAnnReid",
        "indices" : [ 38, 49 ],
        "id_str" : "49698134",
        "id" : 49698134
      }, {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 53, 59 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782592590264709120",
    "text" : "I'm coming up next on @amjoyshow with @JoyAnnReid on @MSNBC.",
    "id" : 782592590264709120,
    "created_at" : "2016-10-02 14:46:28 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 782607796181225472,
  "created_at" : "2016-10-02 15:46:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/t20R5WWkdM",
      "expanded_url" : "https:\/\/goo.gl\/l9pnI1",
      "display_url" : "goo.gl\/l9pnI1"
    } ]
  },
  "geo" : { },
  "id_str" : "782607769333403648",
  "text" : "RT @scrowder: Justice =&gt; Woman Falsely Accuses \"Date\" of Assaulting Her. She Goes to Jail... https:\/\/t.co\/t20R5WWkdM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/t20R5WWkdM",
        "expanded_url" : "https:\/\/goo.gl\/l9pnI1",
        "display_url" : "goo.gl\/l9pnI1"
      } ]
    },
    "geo" : { },
    "id_str" : "782583337021911040",
    "text" : "Justice =&gt; Woman Falsely Accuses \"Date\" of Assaulting Her. She Goes to Jail... https:\/\/t.co\/t20R5WWkdM",
    "id" : 782583337021911040,
    "created_at" : "2016-10-02 14:09:41 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 782607769333403648,
  "created_at" : "2016-10-02 15:46:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AM Joy w\/Joy Reid",
      "screen_name" : "amjoyshow",
      "indices" : [ 3, 13 ],
      "id_str" : "731132367058968576",
      "id" : 731132367058968576
    }, {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 50, 64 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AMJoy",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "reiders",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607666191355909",
  "text" : "RT @amjoyshow: Independent presidential candidate @EVAN_MCMULLIN joins #AMJoy: I'm the only true conservative candidate #reiders https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 35, 49 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amjoyshow\/status\/782594780568190976\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/uTdCRZow0B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxVlTIXEAAcJKS.jpg",
        "id_str" : "782594534534483968",
        "id" : 782594534534483968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxVlTIXEAAcJKS.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/uTdCRZow0B"
      } ],
      "hashtags" : [ {
        "text" : "AMJoy",
        "indices" : [ 56, 62 ]
      }, {
        "text" : "reiders",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782594780568190976",
    "text" : "Independent presidential candidate @EVAN_MCMULLIN joins #AMJoy: I'm the only true conservative candidate #reiders https:\/\/t.co\/uTdCRZow0B",
    "id" : 782594780568190976,
    "created_at" : "2016-10-02 14:55:10 +0000",
    "user" : {
      "name" : "AM Joy w\/Joy Reid",
      "screen_name" : "amjoyshow",
      "protected" : false,
      "id_str" : "731132367058968576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792717505097822213\/I1MqzYtD_normal.jpg",
      "id" : 731132367058968576,
      "verified" : true
    }
  },
  "id" : 782607666191355909,
  "created_at" : "2016-10-02 15:46:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607591784402948",
  "text" : "RT @Evan_McMullin: If the election makes its way to the House, it would reset the race, &amp; in those conditions, I'd have a good chance of pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AMjoy",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782594801644412928",
    "text" : "If the election makes its way to the House, it would reset the race, &amp; in those conditions, I'd have a good chance of prevailing. #AMjoy",
    "id" : 782594801644412928,
    "created_at" : "2016-10-02 14:55:15 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 782607591784402948,
  "created_at" : "2016-10-02 15:46:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782581888791801856\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/jVE1gg7bQO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxKFFtWgAAb_aL.jpg",
      "id_str" : "782581886547820544",
      "id" : 782581886547820544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxKFFtWgAAb_aL.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/jVE1gg7bQO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BuRXonuSHe",
      "expanded_url" : "http:\/\/engt.co\/2dyOvuE",
      "display_url" : "engt.co\/2dyOvuE"
    } ]
  },
  "geo" : { },
  "id_str" : "782607506874863616",
  "text" : "RT @engadget: Volkswagen's long-distance EV, and more in the week that was https:\/\/t.co\/BuRXonuSHe https:\/\/t.co\/jVE1gg7bQO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782581888791801856\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/jVE1gg7bQO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtxKFFtWgAAb_aL.jpg",
        "id_str" : "782581886547820544",
        "id" : 782581886547820544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtxKFFtWgAAb_aL.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/jVE1gg7bQO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/BuRXonuSHe",
        "expanded_url" : "http:\/\/engt.co\/2dyOvuE",
        "display_url" : "engt.co\/2dyOvuE"
      } ]
    },
    "geo" : { },
    "id_str" : "782581888791801856",
    "text" : "Volkswagen's long-distance EV, and more in the week that was https:\/\/t.co\/BuRXonuSHe https:\/\/t.co\/jVE1gg7bQO",
    "id" : 782581888791801856,
    "created_at" : "2016-10-02 14:03:56 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 782607506874863616,
  "created_at" : "2016-10-02 15:45:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/782515510965571584\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/AW5p8pxAH1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtwNtb7WgAA0_Lt.jpg",
      "id_str" : "782515509497593856",
      "id" : 782515509497593856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtwNtb7WgAA0_Lt.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/AW5p8pxAH1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782607125746888709",
  "text" : "RT @rockindigo: What is your favourite quote? https:\/\/t.co\/AW5p8pxAH1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/782515510965571584\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/AW5p8pxAH1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtwNtb7WgAA0_Lt.jpg",
        "id_str" : "782515509497593856",
        "id" : 782515509497593856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtwNtb7WgAA0_Lt.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/AW5p8pxAH1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782515510965571584",
    "text" : "What is your favourite quote? https:\/\/t.co\/AW5p8pxAH1",
    "id" : 782515510965571584,
    "created_at" : "2016-10-02 09:40:10 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 782607125746888709,
  "created_at" : "2016-10-02 15:44:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/KMLXDZOeNy",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGFlOZkN2OjDdLtRZ2MUqI4RvoLTg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779229953204&ei=HMbwV-gHz5G7AtKyldAE&url=http%3A%2F%2Fwww.newsweek.com%2Ffootball-school-alex-bellos-ben-lyttleton-childrens-literature-sport-504723&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782607071577387008",
  "text" : "RT @andikhm01: 'Football School': How Sport Can Get Children Reading - Newsweek https:\/\/t.co\/KMLXDZOeNy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/KMLXDZOeNy",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGFlOZkN2OjDdLtRZ2MUqI4RvoLTg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779229953204&ei=HMbwV-gHz5G7AtKyldAE&url=http%3A%2F%2Fwww.newsweek.com%2Ffootball-school-alex-bellos-ben-lyttleton-childrens-literature-sport-504723&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782498537875529732",
    "text" : "'Football School': How Sport Can Get Children Reading - Newsweek https:\/\/t.co\/KMLXDZOeNy",
    "id" : 782498537875529732,
    "created_at" : "2016-10-02 08:32:44 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 782607071577387008,
  "created_at" : "2016-10-02 15:44:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/iHExFuoYy9",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGb3VaPkvGiC6PV03DGAhAhzcRBwQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779225204173&ei=_LbwV6jLKImLugLFjIeYDQ&url=https%3A%2F%2Fwww.theguardian.com%2Fsport%2F2016%2Foct%2F01%2Flondon-jacksonville-jaguars-argentina-pumas-marquee-sports&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "782606963913797634",
  "text" : "RT @andikhm01: London proves lush habitat for Jaguars and Pumas hunting cash - The Guardian https:\/\/t.co\/iHExFuoYy9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iHExFuoYy9",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGb3VaPkvGiC6PV03DGAhAhzcRBwQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779225204173&ei=_LbwV6jLKImLugLFjIeYDQ&url=https%3A%2F%2Fwww.theguardian.com%2Fsport%2F2016%2Foct%2F01%2Flondon-jacksonville-jaguars-argentina-pumas-marquee-sports&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "782482271471185920",
    "text" : "London proves lush habitat for Jaguars and Pumas hunting cash - The Guardian https:\/\/t.co\/iHExFuoYy9",
    "id" : 782482271471185920,
    "created_at" : "2016-10-02 07:28:05 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 782606963913797634,
  "created_at" : "2016-10-02 15:43:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782459149741355009\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QoTzj1Oo3R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtvacuBWcAAkmRL.jpg",
      "id_str" : "782459147203801088",
      "id" : 782459147203801088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtvacuBWcAAkmRL.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/QoTzj1Oo3R"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/0eKjWzGGRe",
      "expanded_url" : "http:\/\/engt.co\/2dxXfkF",
      "display_url" : "engt.co\/2dxXfkF"
    } ]
  },
  "geo" : { },
  "id_str" : "782606799656542210",
  "text" : "RT @engadget: Volvo's e-buses will honk at oblivious pedestrians https:\/\/t.co\/0eKjWzGGRe https:\/\/t.co\/QoTzj1Oo3R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/782459149741355009\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/QoTzj1Oo3R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtvacuBWcAAkmRL.jpg",
        "id_str" : "782459147203801088",
        "id" : 782459147203801088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtvacuBWcAAkmRL.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/QoTzj1Oo3R"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/0eKjWzGGRe",
        "expanded_url" : "http:\/\/engt.co\/2dxXfkF",
        "display_url" : "engt.co\/2dxXfkF"
      } ]
    },
    "geo" : { },
    "id_str" : "782459149741355009",
    "text" : "Volvo's e-buses will honk at oblivious pedestrians https:\/\/t.co\/0eKjWzGGRe https:\/\/t.co\/QoTzj1Oo3R",
    "id" : 782459149741355009,
    "created_at" : "2016-10-02 05:56:13 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 782606799656542210,
  "created_at" : "2016-10-02 15:42:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "782452119622123520",
  "geo" : { },
  "id_str" : "782606767721021440",
  "in_reply_to_user_id" : 635930726,
  "text" : "@asvpxdest Well .....",
  "id" : 782606767721021440,
  "in_reply_to_status_id" : 782452119622123520,
  "created_at" : "2016-10-02 15:42:48 +0000",
  "in_reply_to_screen_name" : "stuffedjalapeno",
  "in_reply_to_user_id_str" : "635930726",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782606567749226496",
  "text" : "RT @CopticOrphans: @gamer456148 thanks Andrew! God bless.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "423954129128415232",
    "geo" : { },
    "id_str" : "424751820259725312",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 thanks Andrew! God bless.",
    "id" : 424751820259725312,
    "in_reply_to_status_id" : 423954129128415232,
    "created_at" : "2014-01-19 03:55:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 782606567749226496,
  "created_at" : "2016-10-02 15:42:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782606372353421313",
  "text" : "RT @pluralsight: @gamer456148 Good luck!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shoutlet.com\" rel=\"nofollow\"\u003EShoutlet API\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "610517657918513152",
    "geo" : { },
    "id_str" : "610786123074433024",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Good luck!",
    "id" : 610786123074433024,
    "in_reply_to_status_id" : 610517657918513152,
    "created_at" : "2015-06-16 12:28:54 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659469901178933248\/zdC50ICY_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 782606372353421313,
  "created_at" : "2016-10-02 15:41:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malik Degri",
      "screen_name" : "Mal2782",
      "indices" : [ 3, 11 ],
      "id_str" : "111134678",
      "id" : 111134678
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 26, 38 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782606329101717505",
  "text" : "RT @Mal2782: @gamer456148 @colin_furze Colin needs to take on work experience kids :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 13, 25 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611973202131165184",
    "geo" : { },
    "id_str" : "612007521696542720",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @colin_furze Colin needs to take on work experience kids :D",
    "id" : 612007521696542720,
    "in_reply_to_status_id" : 611973202131165184,
    "created_at" : "2015-06-19 21:22:18 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Malik Degri",
      "screen_name" : "Mal2782",
      "protected" : false,
      "id_str" : "111134678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760740446926667776\/EmQbc7Ik_normal.jpg",
      "id" : 111134678,
      "verified" : false
    }
  },
  "id" : 782606329101717505,
  "created_at" : "2016-10-02 15:41:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782606112495251457",
  "text" : "RT @hannahbleau_: @gamer456148 I believe the Bible is the infallible word of God. And He loves the crap out of us. No sugarcoating there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629410028395601921",
    "geo" : { },
    "id_str" : "629415663501574144",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I believe the Bible is the infallible word of God. And He loves the crap out of us. No sugarcoating there.",
    "id" : 629415663501574144,
    "in_reply_to_status_id" : 629410028395601921,
    "created_at" : "2015-08-06 22:16:02 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 782606112495251457,
  "created_at" : "2016-10-02 15:40:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "indices" : [ 3, 14 ],
      "id_str" : "1685698238",
      "id" : 1685698238
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/5x9SmgAGwy",
      "expanded_url" : "http:\/\/www.phpsimplex.com\/en\/",
      "display_url" : "phpsimplex.com\/en\/"
    } ]
  },
  "geo" : { },
  "id_str" : "782605802536247296",
  "text" : "RT @PHPSimplex: @gamer456148 check it: https:\/\/t.co\/5x9SmgAGwy  (theory, solved examples, tool to solve problems step-by-step,...). If in d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/5x9SmgAGwy",
        "expanded_url" : "http:\/\/www.phpsimplex.com\/en\/",
        "display_url" : "phpsimplex.com\/en\/"
      } ]
    },
    "in_reply_to_status_id_str" : "672792515981025281",
    "geo" : { },
    "id_str" : "672905721768517632",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 check it: https:\/\/t.co\/5x9SmgAGwy  (theory, solved examples, tool to solve problems step-by-step,...). If in doubt, ask us!",
    "id" : 672905721768517632,
    "in_reply_to_status_id" : 672792515981025281,
    "created_at" : "2015-12-04 22:30:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "protected" : false,
      "id_str" : "1685698238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000328895370\/ac13e7a886c26f645af34c01324f00ab_normal.png",
      "id" : 1685698238,
      "verified" : false
    }
  },
  "id" : 782605802536247296,
  "created_at" : "2016-10-02 15:38:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782605448155324416",
  "text" : "I failed at doing almost all my Spanish extra credit because I was sick, also still waiting for reference letters \uD83D\uDE14 #ThisIsOU",
  "id" : 782605448155324416,
  "created_at" : "2016-10-02 15:37:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782308563028815872",
  "text" : "RT @Gillette: Did you know? Gillette has manufactured and distributed our products out of the same location in South Boston since 1904.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "782009130865270784",
    "text" : "Did you know? Gillette has manufactured and distributed our products out of the same location in South Boston since 1904.",
    "id" : 782009130865270784,
    "created_at" : "2016-10-01 00:08:00 +0000",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 782308563028815872,
  "created_at" : "2016-10-01 19:57:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/782308509354303488\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/BcDMEhEoX2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CttRb7yUMAAHn6C.jpg",
      "id_str" : "782308500625960960",
      "id" : 782308500625960960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CttRb7yUMAAHn6C.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/BcDMEhEoX2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "782308509354303488",
  "text" : "Had Bagger Dave's burger 4\/5 stars but still has a rich gourmet taste https:\/\/t.co\/BcDMEhEoX2",
  "id" : 782308509354303488,
  "created_at" : "2016-10-01 19:57:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]