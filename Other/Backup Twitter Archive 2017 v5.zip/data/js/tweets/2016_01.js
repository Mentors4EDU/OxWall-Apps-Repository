Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/693483063792263169\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/8RvYPj66VA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ-_KhhUUAAzoaE.jpg",
      "id_str" : "693483055156056064",
      "id" : 693483055156056064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ-_KhhUUAAzoaE.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8RvYPj66VA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693483063792263169",
  "text" : "From Stoney Creek Roadhouse: 4.85\/5 stars https:\/\/t.co\/8RvYPj66VA",
  "id" : 693483063792263169,
  "created_at" : "2016-01-30 17:17:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "Debunked",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/7fDLsfhJm2",
      "expanded_url" : "https:\/\/youtu.be\/nXZdNIg0CYQ",
      "display_url" : "youtu.be\/nXZdNIg0CYQ"
    } ]
  },
  "geo" : { },
  "id_str" : "693245732292198400",
  "text" : "RT @MarkDice: Equal Pay Day DEBUNKED - The Feminist Fraud of the \"Gender Pay Gap\"  #EqualPay #Debunked  VIDEO: https:\/\/t.co\/7fDLsfhJm2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 69, 78 ]
      }, {
        "text" : "Debunked",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/7fDLsfhJm2",
        "expanded_url" : "https:\/\/youtu.be\/nXZdNIg0CYQ",
        "display_url" : "youtu.be\/nXZdNIg0CYQ"
      } ]
    },
    "geo" : { },
    "id_str" : "693170497542946816",
    "text" : "Equal Pay Day DEBUNKED - The Feminist Fraud of the \"Gender Pay Gap\"  #EqualPay #Debunked  VIDEO: https:\/\/t.co\/7fDLsfhJm2",
    "id" : 693170497542946816,
    "created_at" : "2016-01-29 20:34:59 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 693245732292198400,
  "created_at" : "2016-01-30 01:33:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 14, 23 ],
      "id_str" : "216881337",
      "id" : 216881337
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 34, 46 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693245553447030784",
  "text" : "RT @FoxNews: .@RandPaul: \"If what @billclinton did, any CEO in our country did w\/ an intern... they would be fired.\" #GOPDebate\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Rand Paul",
        "screen_name" : "RandPaul",
        "indices" : [ 1, 10 ],
        "id_str" : "216881337",
        "id" : 216881337
      }, {
        "name" : "Bill Clinton",
        "screen_name" : "billclinton",
        "indices" : [ 21, 33 ],
        "id_str" : "1330457336",
        "id" : 1330457336
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/6lCaoV0xGY",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/ce7d9356-439d-4554-bc0e-303f53871e5f",
        "display_url" : "amp.twimg.com\/v\/ce7d9356-439\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692916954214977536",
    "text" : ".@RandPaul: \"If what @billclinton did, any CEO in our country did w\/ an intern... they would be fired.\" #GOPDebate\nhttps:\/\/t.co\/6lCaoV0xGY",
    "id" : 692916954214977536,
    "created_at" : "2016-01-29 03:47:30 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794654746342662144\/hHnFe4Sx_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 693245553447030784,
  "created_at" : "2016-01-30 01:33:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/xRDhwIzDOq",
      "expanded_url" : "http:\/\/bit.ly\/1PPA94G",
      "display_url" : "bit.ly\/1PPA94G"
    } ]
  },
  "geo" : { },
  "id_str" : "693244343214170112",
  "text" : "Drop the Charges Against David Daleiden and Charge Planned Parenthood - Sign the Petition https:\/\/t.co\/xRDhwIzDOq",
  "id" : 693244343214170112,
  "created_at" : "2016-01-30 01:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693233540335570945",
  "text" : "RT @tedcruz: There is a difference between personal insults and attacks and focusing on issues and substance. I plan to focus on substance.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692891592005328896",
    "text" : "There is a difference between personal insults and attacks and focusing on issues and substance. I plan to focus on substance. #GOPDebate",
    "id" : 692891592005328896,
    "created_at" : "2016-01-29 02:06:43 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 693233540335570945,
  "created_at" : "2016-01-30 00:45:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeMarko Gage :)",
      "screen_name" : "DeMarko_Gage",
      "indices" : [ 3, 16 ],
      "id_str" : "154297611",
      "id" : 154297611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693233259359137796",
  "text" : "RT @DeMarko_Gage: I love to laugh \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693228804433690624",
    "text" : "I love to laugh \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
    "id" : 693228804433690624,
    "created_at" : "2016-01-30 00:26:41 +0000",
    "user" : {
      "name" : "DeMarko Gage :)",
      "screen_name" : "DeMarko_Gage",
      "protected" : false,
      "id_str" : "154297611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845143123651051520\/visfHD_p_normal.jpg",
      "id" : 154297611,
      "verified" : false
    }
  },
  "id" : 693233259359137796,
  "created_at" : "2016-01-30 00:44:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Lowe",
      "screen_name" : "RobLowe",
      "indices" : [ 3, 11 ],
      "id_str" : "121626258",
      "id" : 121626258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693232830537687040",
  "text" : "RT @RobLowe: Watching Bernie Sanders. He's hectoring and yelling at me WHILE he's saying he's going to raise our taxes. Interesting way to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691807380703703046",
    "text" : "Watching Bernie Sanders. He's hectoring and yelling at me WHILE he's saying he's going to raise our taxes. Interesting way to communicate.",
    "id" : 691807380703703046,
    "created_at" : "2016-01-26 02:18:27 +0000",
    "user" : {
      "name" : "Rob Lowe",
      "screen_name" : "RobLowe",
      "protected" : false,
      "id_str" : "121626258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724944219757002752\/LTmwjDfQ_normal.jpg",
      "id" : 121626258,
      "verified" : true
    }
  },
  "id" : 693232830537687040,
  "created_at" : "2016-01-30 00:42:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691368799795298304",
  "text" : "RT @tedcruz: Americans don't care about politicians bickering \u2014 they're concerned about the real problems facing this country!\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6jVxK8Wsgj",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/98c4fe93-a3ee-4ba1-b59e-44a818e20e36",
        "display_url" : "amp.twimg.com\/v\/98c4fe93-a3e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691317802100109313",
    "text" : "Americans don't care about politicians bickering \u2014 they're concerned about the real problems facing this country!\nhttps:\/\/t.co\/6jVxK8Wsgj",
    "id" : 691317802100109313,
    "created_at" : "2016-01-24 17:53:02 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 691368799795298304,
  "created_at" : "2016-01-24 21:15:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691102855348879361",
  "text" : "RT @hannahbleau_: @gamer456148 I'm with you on that one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "690758328431996928",
    "geo" : { },
    "id_str" : "691010171489771520",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I'm with you on that one.",
    "id" : 691010171489771520,
    "in_reply_to_status_id" : 690758328431996928,
    "created_at" : "2016-01-23 21:30:37 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 691102855348879361,
  "created_at" : "2016-01-24 03:38:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Vescovo",
      "screen_name" : "RobVescovo",
      "indices" : [ 3, 14 ],
      "id_str" : "126328280",
      "id" : 126328280
    }, {
      "name" : "Boy Scouts - BSA",
      "screen_name" : "boyscouts",
      "indices" : [ 30, 40 ],
      "id_str" : "20685982",
      "id" : 20685982
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 80, 88 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RobVescovo\/status\/690657274847621120\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/pjyHcOTf47",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZW1C2vUMAAs1f0.jpg",
      "id_str" : "690657178529574912",
      "id" : 690657178529574912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZW1C2vUMAAs1f0.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/pjyHcOTf47"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/RobVescovo\/status\/690657274847621120\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/pjyHcOTf47",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZW1FN3UMAA0zlr.jpg",
      "id_str" : "690657219096883200",
      "id" : 690657219096883200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZW1FN3UMAA0zlr.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/pjyHcOTf47"
    } ],
    "hashtags" : [ {
      "text" : "pinewoodderby",
      "indices" : [ 41, 55 ]
    }, {
      "text" : "CruzCrew",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "Cruz2016",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691102765116846080",
  "text" : "RT @RobVescovo: Headed out to @boyscouts #pinewoodderby with the winning ticket @tedcruz #CruzCrew #Cruz2016 https:\/\/t.co\/pjyHcOTf47",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boy Scouts - BSA",
        "screen_name" : "boyscouts",
        "indices" : [ 14, 24 ],
        "id_str" : "20685982",
        "id" : 20685982
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 64, 72 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobVescovo\/status\/690657274847621120\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/pjyHcOTf47",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZW1C2vUMAAs1f0.jpg",
        "id_str" : "690657178529574912",
        "id" : 690657178529574912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZW1C2vUMAAs1f0.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/pjyHcOTf47"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RobVescovo\/status\/690657274847621120\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/pjyHcOTf47",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZW1FN3UMAA0zlr.jpg",
        "id_str" : "690657219096883200",
        "id" : 690657219096883200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZW1FN3UMAA0zlr.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/pjyHcOTf47"
      } ],
      "hashtags" : [ {
        "text" : "pinewoodderby",
        "indices" : [ 25, 39 ]
      }, {
        "text" : "CruzCrew",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "Cruz2016",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690657274847621120",
    "text" : "Headed out to @boyscouts #pinewoodderby with the winning ticket @tedcruz #CruzCrew #Cruz2016 https:\/\/t.co\/pjyHcOTf47",
    "id" : 690657274847621120,
    "created_at" : "2016-01-22 22:08:20 +0000",
    "user" : {
      "name" : "Rob Vescovo",
      "screen_name" : "RobVescovo",
      "protected" : false,
      "id_str" : "126328280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740271214241812485\/jsNUxI40_normal.jpg",
      "id" : 126328280,
      "verified" : false
    }
  },
  "id" : 691102765116846080,
  "created_at" : "2016-01-24 03:38:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP16",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691102530625875968",
  "text" : "Trump is right on fair trade -#GOP16",
  "id" : 691102530625875968,
  "created_at" : "2016-01-24 03:37:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690761469747560449",
  "text" : "Wow long day :)",
  "id" : 690761469747560449,
  "created_at" : "2016-01-23 05:02:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "25053299",
      "id" : 25053299
    }, {
      "name" : "Robert Herjavec",
      "screen_name" : "robertherjavec",
      "indices" : [ 47, 62 ],
      "id_str" : "39275966",
      "id" : 39275966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FortuneLIVE",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/PfuV2DNEDy",
      "expanded_url" : "http:\/\/for.tn\/1OCCWjO",
      "display_url" : "for.tn\/1OCCWjO"
    } ]
  },
  "geo" : { },
  "id_str" : "690761265686274048",
  "text" : "RT @FortuneMagazine: We chat with Shark Tank's @robertherjavec on #FortuneLIVE this week. Watch live at 3PM EST https:\/\/t.co\/PfuV2DNEDy htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Herjavec",
        "screen_name" : "robertherjavec",
        "indices" : [ 26, 41 ],
        "id_str" : "39275966",
        "id" : 39275966
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FortuneMagazine\/status\/690621228634279938\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/EB6GNtE40k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZWUWPJWEAASqC1.jpg",
        "id_str" : "690621227614998528",
        "id" : 690621227614998528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZWUWPJWEAASqC1.jpg",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EB6GNtE40k"
      } ],
      "hashtags" : [ {
        "text" : "FortuneLIVE",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/PfuV2DNEDy",
        "expanded_url" : "http:\/\/for.tn\/1OCCWjO",
        "display_url" : "for.tn\/1OCCWjO"
      } ]
    },
    "geo" : { },
    "id_str" : "690621228634279938",
    "text" : "We chat with Shark Tank's @robertherjavec on #FortuneLIVE this week. Watch live at 3PM EST https:\/\/t.co\/PfuV2DNEDy https:\/\/t.co\/EB6GNtE40k",
    "id" : 690621228634279938,
    "created_at" : "2016-01-22 19:45:06 +0000",
    "user" : {
      "name" : "Fortune",
      "screen_name" : "FortuneMagazine",
      "protected" : false,
      "id_str" : "25053299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875382047216467972\/3119VjuE_normal.jpg",
      "id" : 25053299,
      "verified" : true
    }
  },
  "id" : 690761265686274048,
  "created_at" : "2016-01-23 05:01:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Demi Grace",
      "screen_name" : "IamDemiGrace",
      "indices" : [ 3, 16 ],
      "id_str" : "137592851",
      "id" : 137592851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690760943056265218",
  "text" : "RT @IamDemiGrace: You never know what anyone is going through",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690758890154237952",
    "text" : "You never know what anyone is going through",
    "id" : 690758890154237952,
    "created_at" : "2016-01-23 04:52:07 +0000",
    "user" : {
      "name" : "Demi Grace",
      "screen_name" : "IamDemiGrace",
      "protected" : false,
      "id_str" : "137592851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844720576514215939\/7sVncprZ_normal.jpg",
      "id" : 137592851,
      "verified" : true
    }
  },
  "id" : 690760943056265218,
  "created_at" : "2016-01-23 05:00:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sauc\u0113",
      "screen_name" : "TriIIPapi",
      "indices" : [ 3, 13 ],
      "id_str" : "2894446524",
      "id" : 2894446524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690760487974268929",
  "text" : "RT @TriIIPapi: I didn't change, I grew up, there's a difference\uD83D\uDCAF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690728784899629056",
    "text" : "I didn't change, I grew up, there's a difference\uD83D\uDCAF",
    "id" : 690728784899629056,
    "created_at" : "2016-01-23 02:52:30 +0000",
    "user" : {
      "name" : "Sauc\u0113",
      "screen_name" : "TriIIPapi",
      "protected" : false,
      "id_str" : "2894446524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679456027708887041\/BNc1NSFi_normal.jpg",
      "id" : 2894446524,
      "verified" : false
    }
  },
  "id" : 690760487974268929,
  "created_at" : "2016-01-23 04:58:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TRAVIS \uD83D\uDE08\uD83C\uDF3A\u2614\uFE0F",
      "screen_name" : "trvxrbs",
      "indices" : [ 3, 11 ],
      "id_str" : "2825508870",
      "id" : 2825508870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690760047727513600",
  "text" : "RT @trvxrbs: Temporary times with temporary things.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690749282706583552",
    "text" : "Temporary times with temporary things.",
    "id" : 690749282706583552,
    "created_at" : "2016-01-23 04:13:57 +0000",
    "user" : {
      "name" : "TRAVIS \uD83D\uDE08\uD83C\uDF3A\u2614\uFE0F",
      "screen_name" : "trvxrbs",
      "protected" : false,
      "id_str" : "2825508870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778480220516921344\/a8f-z5Jb_normal.jpg",
      "id" : 2825508870,
      "verified" : false
    }
  },
  "id" : 690760047727513600,
  "created_at" : "2016-01-23 04:56:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "90s Kids",
      "screen_name" : "WeAre90sKids",
      "indices" : [ 3, 16 ],
      "id_str" : "758543612",
      "id" : 758543612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/baFY36PA4l",
      "expanded_url" : "https:\/\/twitter.com\/ChildhoodFacts\/status\/548141970737356800\/photo\/1",
      "display_url" : "pic.twitter.com\/baFY36PA4l"
    } ]
  },
  "geo" : { },
  "id_str" : "690759905414787072",
  "text" : "RT @WeAre90sKids: The iPad when I was kid: http:\/\/t.co\/baFY36PA4l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/baFY36PA4l",
        "expanded_url" : "https:\/\/twitter.com\/ChildhoodFacts\/status\/548141970737356800\/photo\/1",
        "display_url" : "pic.twitter.com\/baFY36PA4l"
      } ]
    },
    "geo" : { },
    "id_str" : "612749715759886338",
    "text" : "The iPad when I was kid: http:\/\/t.co\/baFY36PA4l",
    "id" : 612749715759886338,
    "created_at" : "2015-06-21 22:31:31 +0000",
    "user" : {
      "name" : "90s Kids",
      "screen_name" : "WeAre90sKids",
      "protected" : false,
      "id_str" : "758543612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000281027107\/b779ec33bf8ab38763ea9f6e737f76b8_normal.png",
      "id" : 758543612,
      "verified" : false
    }
  },
  "id" : 690759905414787072,
  "created_at" : "2016-01-23 04:56:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ADice",
      "screen_name" : "JustAWH_89",
      "indices" : [ 3, 14 ],
      "id_str" : "116624648",
      "id" : 116624648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690759876180447232",
  "text" : "RT @JustAWH_89: It's tough to express feelings in today's society.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690756239504998400",
    "text" : "It's tough to express feelings in today's society.",
    "id" : 690756239504998400,
    "created_at" : "2016-01-23 04:41:35 +0000",
    "user" : {
      "name" : "ADice",
      "screen_name" : "JustAWH_89",
      "protected" : false,
      "id_str" : "116624648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020488477421568\/I6ilIlDq_normal.jpg",
      "id" : 116624648,
      "verified" : false
    }
  },
  "id" : 690759876180447232,
  "created_at" : "2016-01-23 04:56:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon Lilly",
      "screen_name" : "HesGodChild",
      "indices" : [ 3, 15 ],
      "id_str" : "249768433",
      "id" : 249768433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690759845260038145",
  "text" : "RT @HesGodChild: If you don't have a woman who prays for you, you haven't found the right woman yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690756284782538753",
    "text" : "If you don't have a woman who prays for you, you haven't found the right woman yet.",
    "id" : 690756284782538753,
    "created_at" : "2016-01-23 04:41:46 +0000",
    "user" : {
      "name" : "Shannon Lilly",
      "screen_name" : "HesGodChild",
      "protected" : false,
      "id_str" : "249768433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882472928230731776\/MKGyvgAF_normal.jpg",
      "id" : 249768433,
      "verified" : false
    }
  },
  "id" : 690759845260038145,
  "created_at" : "2016-01-23 04:55:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690758709006376960",
  "text" : "RT @seanhannity: Question of the Day: Who do you think won the week? Weigh in using #Hannity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690745529504923648",
    "text" : "Question of the Day: Who do you think won the week? Weigh in using #Hannity.",
    "id" : 690745529504923648,
    "created_at" : "2016-01-23 03:59:02 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 690758709006376960,
  "created_at" : "2016-01-23 04:51:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690758328431996928",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ I am jumping on the Hillary bandwagon, Hillary for PRISON 2016.",
  "id" : 690758328431996928,
  "created_at" : "2016-01-23 04:49:53 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690689088848957440",
  "text" : "Probably not gonna watch the big debate tonight, gotta take a breather, mind set at Cruz.",
  "id" : 690689088848957440,
  "created_at" : "2016-01-23 00:14:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690683061353091072",
  "text" : "I love common sense :)",
  "id" : 690683061353091072,
  "created_at" : "2016-01-22 23:50:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690682859909083136",
  "text" : "The tax system punishes them -Huckabee",
  "id" : 690682859909083136,
  "created_at" : "2016-01-22 23:50:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aspen.",
      "screen_name" : "AspenBurden",
      "indices" : [ 3, 15 ],
      "id_str" : "2269934521",
      "id" : 2269934521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/cf1nDGgkdH",
      "expanded_url" : "https:\/\/twitter.com\/hesgodchild\/status\/682966994233102336",
      "display_url" : "twitter.com\/hesgodchild\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690681445828800513",
  "text" : "RT @AspenBurden: This is it.. https:\/\/t.co\/cf1nDGgkdH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/cf1nDGgkdH",
        "expanded_url" : "https:\/\/twitter.com\/hesgodchild\/status\/682966994233102336",
        "display_url" : "twitter.com\/hesgodchild\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690551624931151872",
    "text" : "This is it.. https:\/\/t.co\/cf1nDGgkdH",
    "id" : 690551624931151872,
    "created_at" : "2016-01-22 15:08:31 +0000",
    "user" : {
      "name" : "aspen.",
      "screen_name" : "AspenBurden",
      "protected" : false,
      "id_str" : "2269934521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846582922236825600\/zS62i-iR_normal.jpg",
      "id" : 2269934521,
      "verified" : false
    }
  },
  "id" : 690681445828800513,
  "created_at" : "2016-01-22 23:44:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "indices" : [ 3, 15 ],
      "id_str" : "231971209",
      "id" : 231971209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690681363419164672",
  "text" : "RT @DJPROEBEATS: Stay committed and keep working",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690680946694160386",
    "text" : "Stay committed and keep working",
    "id" : 690680946694160386,
    "created_at" : "2016-01-22 23:42:24 +0000",
    "user" : {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "protected" : false,
      "id_str" : "231971209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860143616945213440\/VT8Fq69N_normal.jpg",
      "id" : 231971209,
      "verified" : false
    }
  },
  "id" : 690681363419164672,
  "created_at" : "2016-01-22 23:44:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690680803877990400",
  "text" : "RT @HamzeiAnalytics: Better Data + Better Indicators = Better Trades",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690680152888446976",
    "text" : "Better Data + Better Indicators = Better Trades",
    "id" : 690680152888446976,
    "created_at" : "2016-01-22 23:39:15 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 690680803877990400,
  "created_at" : "2016-01-22 23:41:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690680325123366912",
  "text" : "The numbers just don't add up -Santorum",
  "id" : 690680325123366912,
  "created_at" : "2016-01-22 23:39:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "indices" : [ 3, 16 ],
      "id_str" : "2417376644",
      "id" : 2417376644
    }, {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "indices" : [ 118, 131 ],
      "id_str" : "2417376644",
      "id" : 2417376644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/y3HrdLdKnd",
      "expanded_url" : "https:\/\/shar.es\/1u1zah",
      "display_url" : "shar.es\/1u1zah"
    } ]
  },
  "geo" : { },
  "id_str" : "690680067878301696",
  "text" : "RT @ValueWriters: The Ultimate Blog Writers Guide to Creating a Winning Blogging Schedule https:\/\/t.co\/y3HrdLdKnd via @valuewriters #blogwr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Value Writers",
        "screen_name" : "ValueWriters",
        "indices" : [ 100, 113 ],
        "id_str" : "2417376644",
        "id" : 2417376644
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blogwriters",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "content",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/y3HrdLdKnd",
        "expanded_url" : "https:\/\/shar.es\/1u1zah",
        "display_url" : "shar.es\/1u1zah"
      } ]
    },
    "geo" : { },
    "id_str" : "651734537878306816",
    "text" : "The Ultimate Blog Writers Guide to Creating a Winning Blogging Schedule https:\/\/t.co\/y3HrdLdKnd via @valuewriters #blogwriters #content",
    "id" : 651734537878306816,
    "created_at" : "2015-10-07 12:23:17 +0000",
    "user" : {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "protected" : false,
      "id_str" : "2417376644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470953771174866944\/kQf3XnNS_normal.jpeg",
      "id" : 2417376644,
      "verified" : false
    }
  },
  "id" : 690680067878301696,
  "created_at" : "2016-01-22 23:38:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "indices" : [ 3, 16 ],
      "id_str" : "2417376644",
      "id" : 2417376644
    }, {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "indices" : [ 97, 110 ],
      "id_str" : "2417376644",
      "id" : 2417376644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blogging",
      "indices" : [ 111, 120 ]
    }, {
      "text" : "contentmarketing",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690680033006878724",
  "text" : "RT @ValueWriters: 8 Business Blogging Mistakes That Will Cost You $1M over the Next 10 Years via @valuewriters #blogging #contentmarketing \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Value Writers",
        "screen_name" : "ValueWriters",
        "indices" : [ 79, 92 ],
        "id_str" : "2417376644",
        "id" : 2417376644
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blogging",
        "indices" : [ 93, 102 ]
      }, {
        "text" : "contentmarketing",
        "indices" : [ 103, 120 ]
      }, {
        "text" : "blogwriting",
        "indices" : [ 121, 133 ]
      }, {
        "text" : "blog",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656471004965941248",
    "text" : "8 Business Blogging Mistakes That Will Cost You $1M over the Next 10 Years via @valuewriters #blogging #contentmarketing #blogwriting #blog",
    "id" : 656471004965941248,
    "created_at" : "2015-10-20 14:04:18 +0000",
    "user" : {
      "name" : "Value Writers",
      "screen_name" : "ValueWriters",
      "protected" : false,
      "id_str" : "2417376644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470953771174866944\/kQf3XnNS_normal.jpeg",
      "id" : 2417376644,
      "verified" : false
    }
  },
  "id" : 690680033006878724,
  "created_at" : "2016-01-22 23:38:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "indices" : [ 7, 20 ],
      "id_str" : "65691824",
      "id" : 65691824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690677932000436224",
  "text" : "I love @CarlyFiorina taking jabs at Hillary",
  "id" : 690677932000436224,
  "created_at" : "2016-01-22 23:30:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690677242188427264",
  "text" : "We need a leader to make sure other countries know when you mess with America there is a price -Santorum",
  "id" : 690677242188427264,
  "created_at" : "2016-01-22 23:27:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Mike Huckabee",
      "screen_name" : "GovMikeHuckabee",
      "indices" : [ 28, 44 ],
      "id_str" : "15416505",
      "id" : 15416505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690674208460791808",
  "text" : "We need to rebuild our navy @GovMikeHuckabee",
  "id" : 690674208460791808,
  "created_at" : "2016-01-22 23:15:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Santorum",
      "screen_name" : "RickSantorum",
      "indices" : [ 0, 13 ],
      "id_str" : "58379000",
      "id" : 58379000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690672425059528704",
  "in_reply_to_user_id" : 58379000,
  "text" : "@RickSantorum Wait you are running now, where have I been lately? At least we have another good candidate running now, good luck",
  "id" : 690672425059528704,
  "created_at" : "2016-01-22 23:08:32 +0000",
  "in_reply_to_screen_name" : "RickSantorum",
  "in_reply_to_user_id_str" : "58379000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690671673813499904",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ #GOP Debate now, Fox Business",
  "id" : 690671673813499904,
  "created_at" : "2016-01-22 23:05:33 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillaryPun",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690671338285969409",
  "text" : "Carl Fiona starts it out funny #HillaryPun",
  "id" : 690671338285969409,
  "created_at" : "2016-01-22 23:04:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690671160904683520",
  "text" : "Watching the Fox Business Republican debate now :)",
  "id" : 690671160904683520,
  "created_at" : "2016-01-22 23:03:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/4zIdYYpGuv",
      "expanded_url" : "https:\/\/twitter.com\/_cristian_vlad_\/status\/690426033925844992",
      "display_url" : "twitter.com\/_cristian_vlad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690577695080603648",
  "text" : "Cool https:\/\/t.co\/4zIdYYpGuv",
  "id" : 690577695080603648,
  "created_at" : "2016-01-22 16:52:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/UqjgxDdO9o",
      "expanded_url" : "http:\/\/mashable.com\/2016\/01\/22\/apple-battery-case-hump\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/01\/22\/app\u2026"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/2FbmOIMN2g",
      "expanded_url" : "http:\/\/fb.me\/73PGyx6la",
      "display_url" : "fb.me\/73PGyx6la"
    } ]
  },
  "geo" : { },
  "id_str" : "690577631679496192",
  "text" : "RT @EmperorDarroux: Embracing Apple's ugly hump: Design dud, utility triumph https:\/\/t.co\/UqjgxDdO9o https:\/\/t.co\/2FbmOIMN2g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/UqjgxDdO9o",
        "expanded_url" : "http:\/\/mashable.com\/2016\/01\/22\/apple-battery-case-hump\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/01\/22\/app\u2026"
      }, {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/2FbmOIMN2g",
        "expanded_url" : "http:\/\/fb.me\/73PGyx6la",
        "display_url" : "fb.me\/73PGyx6la"
      } ]
    },
    "geo" : { },
    "id_str" : "690573828091609088",
    "text" : "Embracing Apple's ugly hump: Design dud, utility triumph https:\/\/t.co\/UqjgxDdO9o https:\/\/t.co\/2FbmOIMN2g",
    "id" : 690573828091609088,
    "created_at" : "2016-01-22 16:36:45 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 690577631679496192,
  "created_at" : "2016-01-22 16:51:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690577566567153664",
  "text" : "Having Einstein Bros coffee and coffee cake, lol",
  "id" : 690577566567153664,
  "created_at" : "2016-01-22 16:51:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/688826575941431296\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/9vmHMTy5hK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY80HMkUAAAdTlm.jpg",
      "id_str" : "688826566248235008",
      "id" : 688826566248235008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY80HMkUAAAdTlm.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9vmHMTy5hK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688826575941431296",
  "text" : "How a real Donut looks (Gold-N Bakery) https:\/\/t.co\/9vmHMTy5hK",
  "id" : 688826575941431296,
  "created_at" : "2016-01-17 20:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Love",
      "screen_name" : "1LoveOrg",
      "indices" : [ 0, 9 ],
      "id_str" : "153679803",
      "id" : 153679803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688759503618093057",
  "in_reply_to_user_id" : 153679803,
  "text" : "@1LoveOrg You guys may have the best coffee I tasted, and it goes to a cause :)",
  "id" : 688759503618093057,
  "created_at" : "2016-01-17 16:27:16 +0000",
  "in_reply_to_screen_name" : "1LoveOrg",
  "in_reply_to_user_id_str" : "153679803",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688752389201903616",
  "text" : "McDonald's started filling their coffee less thinking I wouldn't notice",
  "id" : 688752389201903616,
  "created_at" : "2016-01-17 15:59:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/USZ3d7HdL9",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BASh9ZDAegU\/",
      "display_url" : "instagram.com\/p\/BASh9ZDAegU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "685613816344887297",
  "text" : "RT @HelloRyanHolmes: Omelette before work https:\/\/t.co\/USZ3d7HdL9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/USZ3d7HdL9",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BASh9ZDAegU\/",
        "display_url" : "instagram.com\/p\/BASh9ZDAegU\/"
      } ]
    },
    "geo" : { },
    "id_str" : "685541318043422721",
    "text" : "Omelette before work https:\/\/t.co\/USZ3d7HdL9",
    "id" : 685541318043422721,
    "created_at" : "2016-01-08 19:19:21 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880486625746223106\/uqol0phE_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 685613816344887297,
  "created_at" : "2016-01-09 00:07:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/1qZpoab9ck",
      "expanded_url" : "http:\/\/www.engadget.com\/2016\/01\/08\/bmws-concept-car-puts-next-gen-interior-in-a-sports-car\/",
      "display_url" : "engadget.com\/2016\/01\/08\/bmw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685471743272706048",
  "text" : "RT @EmperorDarroux: BMW's concept car puts next-gen interior in a sports car https:\/\/t.co\/1qZpoab9ck",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/1qZpoab9ck",
        "expanded_url" : "http:\/\/www.engadget.com\/2016\/01\/08\/bmws-concept-car-puts-next-gen-interior-in-a-sports-car\/",
        "display_url" : "engadget.com\/2016\/01\/08\/bmw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685469828648288257",
    "text" : "BMW's concept car puts next-gen interior in a sports car https:\/\/t.co\/1qZpoab9ck",
    "id" : 685469828648288257,
    "created_at" : "2016-01-08 14:35:17 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 685471743272706048,
  "created_at" : "2016-01-08 14:42:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685471383674056704",
  "text" : "RT @God_Instagram: Scared? Pray.\nOver thinking? Pray.\nLosing hope? Pray.\nWorried? Pray.\nStruggling? Pray.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684390240891482112",
    "text" : "Scared? Pray.\nOver thinking? Pray.\nLosing hope? Pray.\nWorried? Pray.\nStruggling? Pray.",
    "id" : 684390240891482112,
    "created_at" : "2016-01-05 15:05:23 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 685471383674056704,
  "created_at" : "2016-01-08 14:41:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685471338786648064",
  "text" : "Well Andrew happened :(",
  "id" : 685471338786648064,
  "created_at" : "2016-01-08 14:41:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yesterday",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685471278443163648",
  "text" : "That moment when you delete your lab by accident #yesterday",
  "id" : 685471278443163648,
  "created_at" : "2016-01-08 14:41:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Einstein Bros.",
      "screen_name" : "EinsteinBros",
      "indices" : [ 0, 13 ],
      "id_str" : "59834052",
      "id" : 59834052
    }, {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 39, 49 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685470966655352832",
  "in_reply_to_user_id" : 59834052,
  "text" : "@EinsteinBros You guys are better then @Starbucks",
  "id" : 685470966655352832,
  "created_at" : "2016-01-08 14:39:48 +0000",
  "in_reply_to_screen_name" : "EinsteinBros",
  "in_reply_to_user_id_str" : "59834052",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMD UK",
      "screen_name" : "AMD_UK",
      "indices" : [ 3, 10 ],
      "id_str" : "90652918",
      "id" : 90652918
    }, {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "indices" : [ 42, 52 ],
      "id_str" : "403614288",
      "id" : 403614288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AMD_UK\/status\/683942219401838592\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/HkrZQWgSrW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX3Z0kmW8AALiGS.png",
      "id_str" : "683942215631171584",
      "id" : 683942215631171584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX3Z0kmW8AALiGS.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HkrZQWgSrW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/NZzs376H7q",
      "expanded_url" : "https:\/\/youtu.be\/LXOaCkbt4lI",
      "display_url" : "youtu.be\/LXOaCkbt4lI"
    } ]
  },
  "geo" : { },
  "id_str" : "684013726689812480",
  "text" : "RT @AMD_UK: 7 gamers. One rig. Created by @LinusTech. Want! https:\/\/t.co\/NZzs376H7q https:\/\/t.co\/HkrZQWgSrW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linus Tech Tips",
        "screen_name" : "LinusTech",
        "indices" : [ 30, 40 ],
        "id_str" : "403614288",
        "id" : 403614288
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AMD_UK\/status\/683942219401838592\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/HkrZQWgSrW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX3Z0kmW8AALiGS.png",
        "id_str" : "683942215631171584",
        "id" : 683942215631171584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX3Z0kmW8AALiGS.png",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HkrZQWgSrW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/NZzs376H7q",
        "expanded_url" : "https:\/\/youtu.be\/LXOaCkbt4lI",
        "display_url" : "youtu.be\/LXOaCkbt4lI"
      } ]
    },
    "geo" : { },
    "id_str" : "683942219401838592",
    "text" : "7 gamers. One rig. Created by @LinusTech. Want! https:\/\/t.co\/NZzs376H7q https:\/\/t.co\/HkrZQWgSrW",
    "id" : 683942219401838592,
    "created_at" : "2016-01-04 09:25:06 +0000",
    "user" : {
      "name" : "AMD UK",
      "screen_name" : "AMD_UK",
      "protected" : false,
      "id_str" : "90652918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794488190103121920\/Jm9By3Ld_normal.jpg",
      "id" : 90652918,
      "verified" : true
    }
  },
  "id" : 684013726689812480,
  "created_at" : "2016-01-04 14:09:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheff",
      "screen_name" : "SheffStation",
      "indices" : [ 3, 16 ],
      "id_str" : "169489285",
      "id" : 169489285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684013662600884224",
  "text" : "RT @SheffStation: My YE 2015 review w\/ Portfolio Charts, Balances, &amp; Thoughts for trading\/investing in 2016. Continued success! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Sl62ZDp5Xe",
        "expanded_url" : "http:\/\/bit.ly\/1RkVx5R",
        "display_url" : "bit.ly\/1RkVx5R"
      } ]
    },
    "geo" : { },
    "id_str" : "684013234517483520",
    "text" : "My YE 2015 review w\/ Portfolio Charts, Balances, &amp; Thoughts for trading\/investing in 2016. Continued success! https:\/\/t.co\/Sl62ZDp5Xe",
    "id" : 684013234517483520,
    "created_at" : "2016-01-04 14:07:18 +0000",
    "user" : {
      "name" : "Sheff",
      "screen_name" : "SheffStation",
      "protected" : true,
      "id_str" : "169489285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849865043718004737\/6Q78z0wY_normal.jpg",
      "id" : 169489285,
      "verified" : false
    }
  },
  "id" : 684013662600884224,
  "created_at" : "2016-01-04 14:09:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684013636482940928",
  "text" : "Just handed out my first business card, don't think they are a perspective client, but who knows. Did it anyways to seem polite.",
  "id" : 684013636482940928,
  "created_at" : "2016-01-04 14:08:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/525430090448900096\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/rI55JQGyWI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qz4ehCEAAixuC.jpg",
      "id_str" : "525430089387741184",
      "id" : 525430089387741184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qz4ehCEAAixuC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/rI55JQGyWI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Pey1Ai2FK2",
      "expanded_url" : "http:\/\/goo.gl\/Nyn8ov",
      "display_url" : "goo.gl\/Nyn8ov"
    } ]
  },
  "geo" : { },
  "id_str" : "684013178888536066",
  "text" : "RT @BestGamezUp: $1400 portable PS4 and XB1 - Xbook and PlayBook https:\/\/t.co\/Pey1Ai2FK2 https:\/\/t.co\/rI55JQGyWI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/525430090448900096\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/rI55JQGyWI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qz4ehCEAAixuC.jpg",
        "id_str" : "525430089387741184",
        "id" : 525430089387741184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qz4ehCEAAixuC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/rI55JQGyWI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/Pey1Ai2FK2",
        "expanded_url" : "http:\/\/goo.gl\/Nyn8ov",
        "display_url" : "goo.gl\/Nyn8ov"
      } ]
    },
    "geo" : { },
    "id_str" : "684012671398756352",
    "text" : "$1400 portable PS4 and XB1 - Xbook and PlayBook https:\/\/t.co\/Pey1Ai2FK2 https:\/\/t.co\/rI55JQGyWI",
    "id" : 684012671398756352,
    "created_at" : "2016-01-04 14:05:03 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 684013178888536066,
  "created_at" : "2016-01-04 14:07:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682901986426118144",
  "geo" : { },
  "id_str" : "683847494690828289",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze My favorite project, definitely the bunker :)",
  "id" : 683847494690828289,
  "in_reply_to_status_id" : 682901986426118144,
  "created_at" : "2016-01-04 03:08:42 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u270E",
      "screen_name" : "hunterwalk",
      "indices" : [ 0, 11 ],
      "id_str" : "46063",
      "id" : 46063
    }, {
      "name" : "Nicholas Carlson",
      "screen_name" : "nichcarlson",
      "indices" : [ 12, 24 ],
      "id_str" : "9549942",
      "id" : 9549942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421673518447591424",
  "geo" : { },
  "id_str" : "683553537947766784",
  "in_reply_to_user_id" : 46063,
  "text" : "@hunterwalk @nichcarlson Lol",
  "id" : 683553537947766784,
  "in_reply_to_status_id" : 421673518447591424,
  "created_at" : "2016-01-03 07:40:37 +0000",
  "in_reply_to_screen_name" : "hunterwalk",
  "in_reply_to_user_id_str" : "46063",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "worddiction",
      "screen_name" : "worddiction",
      "indices" : [ 3, 15 ],
      "id_str" : "454939382",
      "id" : 454939382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Vh4Ze0F0HR",
      "expanded_url" : "https:\/\/twitter.com\/PoemsPorn\/status\/681320800406736897\/photo\/1",
      "display_url" : "pic.twitter.com\/Vh4Ze0F0HR"
    } ]
  },
  "geo" : { },
  "id_str" : "683428823837310977",
  "text" : "RT @worddiction: https:\/\/t.co\/Vh4Ze0F0HR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/Vh4Ze0F0HR",
        "expanded_url" : "https:\/\/twitter.com\/PoemsPorn\/status\/681320800406736897\/photo\/1",
        "display_url" : "pic.twitter.com\/Vh4Ze0F0HR"
      } ]
    },
    "geo" : { },
    "id_str" : "683426321259728897",
    "text" : "https:\/\/t.co\/Vh4Ze0F0HR",
    "id" : 683426321259728897,
    "created_at" : "2016-01-02 23:15:07 +0000",
    "user" : {
      "name" : "worddiction",
      "screen_name" : "worddiction",
      "protected" : false,
      "id_str" : "454939382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598587924557488128\/44F0q09U_normal.jpg",
      "id" : 454939382,
      "verified" : false
    }
  },
  "id" : 683428823837310977,
  "created_at" : "2016-01-02 23:25:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683428541082550273",
  "text" : "RT @God_Instagram: The word \"lucky\" is an understatement. I think the word \"BLESSED\" best describes my life. Thank you God!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683424301924483072",
    "text" : "The word \"lucky\" is an understatement. I think the word \"BLESSED\" best describes my life. Thank you God!",
    "id" : 683424301924483072,
    "created_at" : "2016-01-02 23:07:05 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 683428541082550273,
  "created_at" : "2016-01-02 23:23:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/683428479195557888\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/uN62ItYwhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXwGk0LWwAAUZoc.jpg",
      "id_str" : "683428473004802048",
      "id" : 683428473004802048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXwGk0LWwAAUZoc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uN62ItYwhb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683428479195557888",
  "text" : "Had the Cajun chicken sandwich at JW's sports bar 3.72\/5 stars https:\/\/t.co\/uN62ItYwhb",
  "id" : 683428479195557888,
  "created_at" : "2016-01-02 23:23:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/451950605842403328\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/O61QaJgNkS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkWmrmoCcAAtEI6.jpg",
      "id_str" : "451950605653667840",
      "id" : 451950605653667840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkWmrmoCcAAtEI6.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 897
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 897
      } ],
      "display_url" : "pic.twitter.com\/O61QaJgNkS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683324707588960256",
  "text" : "RT @BestGamezUp: Desperate GameStop https:\/\/t.co\/O61QaJgNkS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/451950605842403328\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/O61QaJgNkS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkWmrmoCcAAtEI6.jpg",
        "id_str" : "451950605653667840",
        "id" : 451950605653667840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkWmrmoCcAAtEI6.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 897
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 897
        } ],
        "display_url" : "pic.twitter.com\/O61QaJgNkS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683324495227150337",
    "text" : "Desperate GameStop https:\/\/t.co\/O61QaJgNkS",
    "id" : 683324495227150337,
    "created_at" : "2016-01-02 16:30:29 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 683324707588960256,
  "created_at" : "2016-01-02 16:31:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspired",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683324274569003014",
  "text" : "I am #inspired",
  "id" : 683324274569003014,
  "created_at" : "2016-01-02 16:29:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683324190401900544",
  "text" : "RT @God_Instagram: We may not understand God's plan now...but eventually we will. He is the author of our life. Everything happens for a pu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683107012608040960",
    "text" : "We may not understand God's plan now...but eventually we will. He is the author of our life. Everything happens for a purpose.",
    "id" : 683107012608040960,
    "created_at" : "2016-01-02 02:06:17 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 683324190401900544,
  "created_at" : "2016-01-02 16:29:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683043949456551936",
  "text" : "RT @God_Instagram: Thank you, God for everything. The big things and the small, For \"every good gift comes from God\", The Giver of them all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682766830427963392",
    "text" : "Thank you, God for everything. The big things and the small, For \"every good gift comes from God\", The Giver of them all.",
    "id" : 682766830427963392,
    "created_at" : "2016-01-01 03:34:32 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 683043949456551936,
  "created_at" : "2016-01-01 21:55:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683043918062206981",
  "text" : "RT @God_Instagram: God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682932926871285765",
    "text" : "God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
    "id" : 682932926871285765,
    "created_at" : "2016-01-01 14:34:32 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 683043918062206981,
  "created_at" : "2016-01-01 21:55:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/683043485335818240\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/XP1r45BKFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXqobErWAAA-ElV.jpg",
      "id_str" : "683043476565524480",
      "id" : 683043476565524480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXqobErWAAA-ElV.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XP1r45BKFf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683043485335818240",
  "text" : "From West Coast Pizza 4.8\/5 stars, great pizza hands down https:\/\/t.co\/XP1r45BKFf",
  "id" : 683043485335818240,
  "created_at" : "2016-01-01 21:53:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]