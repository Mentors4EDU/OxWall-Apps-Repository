Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Goodell",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513721828460609536",
  "text" : "RT @MarkDice: Only in an Idiocracy would a press conference about football interrupt regular programing on all TV networks.  #Goodell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Goodell",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513045066550890498",
    "text" : "Only in an Idiocracy would a press conference about football interrupt regular programing on all TV networks.  #Goodell",
    "id" : 513045066550890498,
    "created_at" : "2014-09-19 19:20:50 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 513721828460609536,
  "created_at" : "2014-09-21 16:10:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5C3pIhacgj",
      "expanded_url" : "http:\/\/youtu.be\/Czg8F1hSZvw?a",
      "display_url" : "youtu.be\/Czg8F1hSZvw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "513721143157477376",
  "text" : "RT @VigilantChrist: NFL Quarterback Denied Jesus Before Men !!! Matthew 10:33  http:\/\/t.co\/5C3pIhacgj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/5C3pIhacgj",
        "expanded_url" : "http:\/\/youtu.be\/Czg8F1hSZvw?a",
        "display_url" : "youtu.be\/Czg8F1hSZvw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "512215250741886977",
    "text" : "NFL Quarterback Denied Jesus Before Men !!! Matthew 10:33  http:\/\/t.co\/5C3pIhacgj",
    "id" : 512215250741886977,
    "created_at" : "2014-09-17 12:23:26 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 513721143157477376,
  "created_at" : "2014-09-21 16:07:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/9nPK8FYIfr",
      "expanded_url" : "http:\/\/1drv.ms\/Z5mUu1",
      "display_url" : "1drv.ms\/Z5mUu1"
    } ]
  },
  "geo" : { },
  "id_str" : "513720877179871233",
  "text" : "The honey peanut butter delight http:\/\/t.co\/9nPK8FYIfr",
  "id" : 513720877179871233,
  "created_at" : "2014-09-21 16:06:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lulBCCp19e",
      "expanded_url" : "http:\/\/1drv.ms\/XDuOJr",
      "display_url" : "1drv.ms\/XDuOJr"
    } ]
  },
  "geo" : { },
  "id_str" : "513511158423117825",
  "text" : "Tasted great http:\/\/t.co\/lulBCCp19e",
  "id" : 513511158423117825,
  "created_at" : "2014-09-21 02:12:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/t3kKL0AeQP",
      "expanded_url" : "http:\/\/youtu.be\/hczJ4ev1pu4?a",
      "display_url" : "youtu.be\/hczJ4ev1pu4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "510993545184829441",
  "text" : "RT @VigilantChrist: ANIMAL CRUELTY IS A NASTY AND EVIL SIN !!! The Bible &amp; Pets  http:\/\/t.co\/t3kKL0AeQP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/t3kKL0AeQP",
        "expanded_url" : "http:\/\/youtu.be\/hczJ4ev1pu4?a",
        "display_url" : "youtu.be\/hczJ4ev1pu4?a"
      } ]
    },
    "geo" : { },
    "id_str" : "510030158514749441",
    "text" : "ANIMAL CRUELTY IS A NASTY AND EVIL SIN !!! The Bible &amp; Pets  http:\/\/t.co\/t3kKL0AeQP",
    "id" : 510030158514749441,
    "created_at" : "2014-09-11 11:40:40 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 510993545184829441,
  "created_at" : "2014-09-14 03:28:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510993178841739264",
  "text" : "I love using Baconit and Kik for the windows phone, well actually love their UI design, just got a KIK account, lol",
  "id" : 510993178841739264,
  "created_at" : "2014-09-14 03:27:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510855889012539392",
  "text" : "Hungry Howies makes good calzones, yum",
  "id" : 510855889012539392,
  "created_at" : "2014-09-13 18:21:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/hFS48Ml8mL",
      "expanded_url" : "http:\/\/1drv.ms\/1xWj1a3",
      "display_url" : "1drv.ms\/1xWj1a3"
    } ]
  },
  "geo" : { },
  "id_str" : "510630502257025025",
  "text" : "So good :) Plus love their cookie pie :P http:\/\/t.co\/hFS48Ml8mL",
  "id" : 510630502257025025,
  "created_at" : "2014-09-13 03:26:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerfornothin",
      "indices" : [ 46, 59 ]
    }, {
      "text" : "ad",
      "indices" : [ 60, 63 ]
    }, {
      "text" : "batman",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/dZb7Es3Fvq",
      "expanded_url" : "http:\/\/youtu.be\/y4HD94W7on4",
      "display_url" : "youtu.be\/y4HD94W7on4"
    } ]
  },
  "geo" : { },
  "id_str" : "509388192198320129",
  "text" : "RT @colin_furze: Ultimate NERF Shooting Range #nerfornothin #ad #batman http:\/\/t.co\/dZb7Es3Fvq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube\/id544007664?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube on iOS_\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerfornothin",
        "indices" : [ 29, 42 ]
      }, {
        "text" : "ad",
        "indices" : [ 43, 46 ]
      }, {
        "text" : "batman",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/dZb7Es3Fvq",
        "expanded_url" : "http:\/\/youtu.be\/y4HD94W7on4",
        "display_url" : "youtu.be\/y4HD94W7on4"
      } ]
    },
    "geo" : { },
    "id_str" : "509245930605125632",
    "text" : "Ultimate NERF Shooting Range #nerfornothin #ad #batman http:\/\/t.co\/dZb7Es3Fvq",
    "id" : 509245930605125632,
    "created_at" : "2014-09-09 07:44:25 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 509388192198320129,
  "created_at" : "2014-09-09 17:09:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 7, 16 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/PGTuZwBdgq",
      "expanded_url" : "http:\/\/1drv.ms\/1xEb35n",
      "display_url" : "1drv.ms\/1xEb35n"
    } ]
  },
  "geo" : { },
  "id_str" : "509387623169667074",
  "text" : "Thanks @gillette http:\/\/t.co\/PGTuZwBdgq",
  "id" : 509387623169667074,
  "created_at" : "2014-09-09 17:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509097451119063040",
  "text" : "I love the PitaPit",
  "id" : 509097451119063040,
  "created_at" : "2014-09-08 21:54:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Aaron Manges",
      "screen_name" : "michael_manges",
      "indices" : [ 3, 18 ],
      "id_str" : "2706009970",
      "id" : 2706009970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/flyjH0mKuL",
      "expanded_url" : "http:\/\/on.fb.me\/ZbW4Ac",
      "display_url" : "on.fb.me\/ZbW4Ac"
    } ]
  },
  "geo" : { },
  "id_str" : "508629680384008192",
  "text" : "RT @michael_manges: Please like my friend's page http:\/\/t.co\/flyjH0mKuL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/flyjH0mKuL",
        "expanded_url" : "http:\/\/on.fb.me\/ZbW4Ac",
        "display_url" : "on.fb.me\/ZbW4Ac"
      } ]
    },
    "geo" : { },
    "id_str" : "508570986049200128",
    "text" : "Please like my friend's page http:\/\/t.co\/flyjH0mKuL",
    "id" : 508570986049200128,
    "created_at" : "2014-09-07 11:02:26 +0000",
    "user" : {
      "name" : "Michael Aaron Manges",
      "screen_name" : "michael_manges",
      "protected" : false,
      "id_str" : "2706009970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488199342835384320\/n4P-cy_U_normal.jpeg",
      "id" : 2706009970,
      "verified" : false
    }
  },
  "id" : 508629680384008192,
  "created_at" : "2014-09-07 14:55:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/YAnzUrW79q",
      "expanded_url" : "http:\/\/youtu.be\/TBNBt05kojM?a",
      "display_url" : "youtu.be\/TBNBt05kojM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "508063674880126977",
  "text" : "RT @VigilantChrist: HOW TO SPOT A LEGALIST WOLF IN SHEEP'S CLOTHING !!! BE VIGILANT !!! http:\/\/t.co\/YAnzUrW79q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/YAnzUrW79q",
        "expanded_url" : "http:\/\/youtu.be\/TBNBt05kojM?a",
        "display_url" : "youtu.be\/TBNBt05kojM?a"
      } ]
    },
    "geo" : { },
    "id_str" : "507505381971476480",
    "text" : "HOW TO SPOT A LEGALIST WOLF IN SHEEP'S CLOTHING !!! BE VIGILANT !!! http:\/\/t.co\/YAnzUrW79q",
    "id" : 507505381971476480,
    "created_at" : "2014-09-04 12:28:06 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 508063674880126977,
  "created_at" : "2014-09-06 01:26:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508063440737275905",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice That fake phone call video was hilarious, you never fail to amuse me. Keep in mind though, God likes you to rebuke not mock.",
  "id" : 508063440737275905,
  "created_at" : "2014-09-06 01:25:38 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/EMxpWpsM0d",
      "expanded_url" : "http:\/\/1drv.ms\/1pVgCIe",
      "display_url" : "1drv.ms\/1pVgCIe"
    } ]
  },
  "geo" : { },
  "id_str" : "508062802817200128",
  "text" : "Tasted nice 4.4\/5 http:\/\/t.co\/EMxpWpsM0d",
  "id" : 508062802817200128,
  "created_at" : "2014-09-06 01:23:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]