Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/582914007419510784\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/eTkVCn5Al8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBbtMtaWEAAcd9-.jpg",
      "id_str" : "582914004395364352",
      "id" : 582914004395364352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBbtMtaWEAAcd9-.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eTkVCn5Al8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/gwSPuoUzEs",
      "expanded_url" : "http:\/\/engt.co\/1FdR51O",
      "display_url" : "engt.co\/1FdR51O"
    } ]
  },
  "geo" : { },
  "id_str" : "582926117876690946",
  "text" : "RT @engadget: LG and Samsung end their war over broken washing machines http:\/\/t.co\/gwSPuoUzEs http:\/\/t.co\/eTkVCn5Al8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.aol.com\" rel=\"nofollow\"\u003EAOL Blogsmith\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/582914007419510784\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/eTkVCn5Al8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBbtMtaWEAAcd9-.jpg",
        "id_str" : "582914004395364352",
        "id" : 582914004395364352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBbtMtaWEAAcd9-.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eTkVCn5Al8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/gwSPuoUzEs",
        "expanded_url" : "http:\/\/engt.co\/1FdR51O",
        "display_url" : "engt.co\/1FdR51O"
      } ]
    },
    "geo" : { },
    "id_str" : "582914007419510784",
    "text" : "LG and Samsung end their war over broken washing machines http:\/\/t.co\/gwSPuoUzEs http:\/\/t.co\/eTkVCn5Al8",
    "id" : 582914007419510784,
    "created_at" : "2015-03-31 14:35:04 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 582926117876690946,
  "created_at" : "2015-03-31 15:23:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/582925862686842880\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/UzRsa5Cp29",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBb3-8fW4AABw7K.jpg",
      "id_str" : "582925862552657920",
      "id" : 582925862552657920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBb3-8fW4AABw7K.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/UzRsa5Cp29"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582925862686842880",
  "text" : "Had French Toast at Marcus Grill 3.75\/5 stars http:\/\/t.co\/UzRsa5Cp29",
  "id" : 582925862686842880,
  "created_at" : "2015-03-31 15:22:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582135674649837568",
  "geo" : { },
  "id_str" : "582521127257292800",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze LOL",
  "id" : 582521127257292800,
  "in_reply_to_status_id" : 582135674649837568,
  "created_at" : "2015-03-30 12:33:54 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582521073897324544",
  "text" : "RT @colin_furze: Green rooms are only cool when there's more than one person in them. And you know who they are to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581529872884977664",
    "text" : "Green rooms are only cool when there's more than one person in them. And you know who they are to.",
    "id" : 581529872884977664,
    "created_at" : "2015-03-27 18:55:00 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 582521073897324544,
  "created_at" : "2015-03-30 12:33:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582520720892170240",
  "in_reply_to_user_id" : 1873023223,
  "text" : "@CyberDustApp I just discovered your app, really innovative concept :)",
  "id" : 582520720892170240,
  "created_at" : "2015-03-30 12:32:17 +0000",
  "in_reply_to_screen_name" : "DustMessaging",
  "in_reply_to_user_id_str" : "1873023223",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 0, 10 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582519989002846208",
  "in_reply_to_user_id" : 386131152,
  "text" : "@SEOClerks Where are the new status updates?",
  "id" : 582519989002846208,
  "created_at" : "2015-03-30 12:29:22 +0000",
  "in_reply_to_screen_name" : "SEOClerks",
  "in_reply_to_user_id_str" : "386131152",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "friends",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582519587746402305",
  "text" : "Checkout my #friends @ cheapseoservices.tk",
  "id" : 582519587746402305,
  "created_at" : "2015-03-30 12:27:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/582519457626488832\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/IxCuTZ0SzO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBWGXA3UsAELo0m.jpg",
      "id_str" : "582519456741502977",
      "id" : 582519456741502977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBWGXA3UsAELo0m.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 380
      } ],
      "display_url" : "pic.twitter.com\/IxCuTZ0SzO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/m0K6mqjPvv",
      "expanded_url" : "http:\/\/cheapseoservices.tk",
      "display_url" : "cheapseoservices.tk"
    } ]
  },
  "geo" : { },
  "id_str" : "582519457626488832",
  "text" : "320+ High Quality PR2-7 Backlinks For $1 ONLY at http:\/\/t.co\/m0K6mqjPvv http:\/\/t.co\/IxCuTZ0SzO",
  "id" : 582519457626488832,
  "created_at" : "2015-03-30 12:27:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582321485454282752",
  "text" : "RT @seanhannity: Question of the Day: Do you think spring break destinations need to do a better job at keeping kids safe in their communit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581289628713422848",
    "text" : "Question of the Day: Do you think spring break destinations need to do a better job at keeping kids safe in their communities? #Hannity",
    "id" : 581289628713422848,
    "created_at" : "2015-03-27 03:00:21 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 582321485454282752,
  "created_at" : "2015-03-29 23:20:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582320752541638656",
  "text" : "Went to my nephew's birthday party, was a bit noisy, but nice to see some of the family again!!!",
  "id" : 582320752541638656,
  "created_at" : "2015-03-29 23:17:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/581876923447451648\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4IrYLwWHci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBM9-pWUYAAGsDj.jpg",
      "id_str" : "581876923321573376",
      "id" : 581876923321573376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBM9-pWUYAAGsDj.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4IrYLwWHci"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581876923447451648",
  "text" : "Went to Gamestop and got these, then went to Wing On Chinese Restaurant and got Crab Ragoons, fun day!!! http:\/\/t.co\/4IrYLwWHci",
  "id" : 581876923447451648,
  "created_at" : "2015-03-28 17:54:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 3, 14 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "headtalker",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/xx6yMXmKlk",
      "expanded_url" : "http:\/\/goo.gl\/kjfjZa",
      "display_url" : "goo.gl\/kjfjZa"
    } ]
  },
  "geo" : { },
  "id_str" : "581531475054481408",
  "text" : "RT @Headtalker Please help Andrew Magdy Kamal meet his #headtalker goal http:\/\/t.co\/xx6yMXmKlk",
  "id" : 581531475054481408,
  "created_at" : "2015-03-27 19:01:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JavaScript",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581218255857012738",
  "text" : "I turn caffeine to code #JavaScript",
  "id" : 581218255857012738,
  "created_at" : "2015-03-26 22:16:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581217758303498240",
  "text" : "I ate alot today. I had a Huge German Waffle, Popsicles, a Lamb sandwich, chocolate, and a Paraline. Man I need to diet, lol \uD83D\uDE01",
  "id" : 581217758303498240,
  "created_at" : "2015-03-26 22:14:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOOC",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "Blogposts",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "Awesomeness",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/v43hgv5KlB",
      "expanded_url" : "http:\/\/edustudio.org",
      "display_url" : "edustudio.org"
    } ]
  },
  "geo" : { },
  "id_str" : "581164419805278208",
  "text" : "I love making #MOOC Courses and #Blogposts on STEM, IT, and Design #Awesomeness http:\/\/t.co\/v43hgv5KlB",
  "id" : 581164419805278208,
  "created_at" : "2015-03-26 18:42:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578847342570430464",
  "geo" : { },
  "id_str" : "581163483347214336",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Really Colin?",
  "id" : 581163483347214336,
  "in_reply_to_status_id" : 578847342570430464,
  "created_at" : "2015-03-26 18:39:06 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581163299024277504",
  "text" : "RT @colin_furze: Sony XD handy cams and FCPX don't seem to connect without a converter right.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "579273650156789760",
    "text" : "Sony XD handy cams and FCPX don't seem to connect without a converter right.",
    "id" : 579273650156789760,
    "created_at" : "2015-03-21 13:29:35 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 581163299024277504,
  "created_at" : "2015-03-26 18:38:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/580823500291727360\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/riMSgcZ0CO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9_5PPWgAE3vM4.png",
      "id_str" : "580823498274275329",
      "id" : 580823498274275329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9_5PPWgAE3vM4.png",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1166,
        "resize" : "fit",
        "w" : 2472
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/riMSgcZ0CO"
    } ],
    "hashtags" : [ {
      "text" : "FirstOnVessel",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/BTzQ2Cr3RW",
      "expanded_url" : "https:\/\/www.vessel.com\/channels\/colinfurze",
      "display_url" : "vessel.com\/channels\/colin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581163167646138370",
  "text" : "RT @colin_furze: follow me on vessel  https:\/\/t.co\/BTzQ2Cr3RW \u2026 #FirstOnVessel http:\/\/t.co\/riMSgcZ0CO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/580823500291727360\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/riMSgcZ0CO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9_5PPWgAE3vM4.png",
        "id_str" : "580823498274275329",
        "id" : 580823498274275329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9_5PPWgAE3vM4.png",
        "sizes" : [ {
          "h" : 483,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1166,
          "resize" : "fit",
          "w" : 2472
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/riMSgcZ0CO"
      } ],
      "hashtags" : [ {
        "text" : "FirstOnVessel",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/BTzQ2Cr3RW",
        "expanded_url" : "https:\/\/www.vessel.com\/channels\/colinfurze",
        "display_url" : "vessel.com\/channels\/colin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580823500291727360",
    "text" : "follow me on vessel  https:\/\/t.co\/BTzQ2Cr3RW \u2026 #FirstOnVessel http:\/\/t.co\/riMSgcZ0CO",
    "id" : 580823500291727360,
    "created_at" : "2015-03-25 20:08:08 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 581163167646138370,
  "created_at" : "2015-03-26 18:37:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581084194228604929",
  "text" : "I just hope Obama doesn't get a third term, then he will really be a dictator.",
  "id" : 581084194228604929,
  "created_at" : "2015-03-26 13:24:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FullRepeal",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/PVsiCtsMqj",
      "expanded_url" : "http:\/\/www.tedcruz.org",
      "display_url" : "tedcruz.org"
    } ]
  },
  "geo" : { },
  "id_str" : "581084054109442051",
  "text" : "RT @tedcruz: In 2017, if we win this race, I hope &amp; expect to sign a #FullRepeal of Obamacare. Join us: http:\/\/t.co\/PVsiCtsMqj https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FullRepeal",
        "indices" : [ 60, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/PVsiCtsMqj",
        "expanded_url" : "http:\/\/www.tedcruz.org",
        "display_url" : "tedcruz.org"
      }, {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/8c8MSMJUg3",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rX4tgPPAbzE",
        "display_url" : "youtube.com\/watch?v=rX4tgP\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580781260668149760",
    "text" : "In 2017, if we win this race, I hope &amp; expect to sign a #FullRepeal of Obamacare. Join us: http:\/\/t.co\/PVsiCtsMqj https:\/\/t.co\/8c8MSMJUg3",
    "id" : 580781260668149760,
    "created_at" : "2015-03-25 17:20:17 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 581084054109442051,
  "created_at" : "2015-03-26 13:23:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/581083717537415168\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/gDN2NNvOtB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBBsj-0UYAA_JCl.jpg",
      "id_str" : "581083717344452608",
      "id" : 581083717344452608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBBsj-0UYAA_JCl.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gDN2NNvOtB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581083717537415168",
  "text" : "I went to the Pantry 4.4\/5 stars for their German Waffles http:\/\/t.co\/gDN2NNvOtB",
  "id" : 581083717537415168,
  "created_at" : "2015-03-26 13:22:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/YBcXsTJlj4",
      "expanded_url" : "http:\/\/tedcruz.org",
      "display_url" : "tedcruz.org"
    } ]
  },
  "geo" : { },
  "id_str" : "580494796973850625",
  "text" : "RT @tedcruz: I am running for President to stand with each of you to reignite the promise of America: http:\/\/t.co\/YBcXsTJlj4 https:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/YBcXsTJlj4",
        "expanded_url" : "http:\/\/tedcruz.org",
        "display_url" : "tedcruz.org"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/iAKxzEMte0",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ujW071RLYNg",
        "display_url" : "youtube.com\/watch?v=ujW071\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580146957651300352",
    "text" : "I am running for President to stand with each of you to reignite the promise of America: http:\/\/t.co\/YBcXsTJlj4 https:\/\/t.co\/iAKxzEMte0",
    "id" : 580146957651300352,
    "created_at" : "2015-03-23 23:19:47 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 580494796973850625,
  "created_at" : "2015-03-24 22:21:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mentor4U",
      "screen_name" : "teamtheta",
      "indices" : [ 3, 13 ],
      "id_str" : "2851392103",
      "id" : 2851392103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alive",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Bf9cE6miDx",
      "expanded_url" : "http:\/\/Edustudio.org",
      "display_url" : "Edustudio.org"
    } ]
  },
  "geo" : { },
  "id_str" : "580104248974708736",
  "text" : "RT @teamtheta: We are still #alive check us out on our facebook page or at http:\/\/t.co\/Bf9cE6miDx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alive",
        "indices" : [ 13, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/Bf9cE6miDx",
        "expanded_url" : "http:\/\/Edustudio.org",
        "display_url" : "Edustudio.org"
      } ]
    },
    "geo" : { },
    "id_str" : "580104085967282176",
    "text" : "We are still #alive check us out on our facebook page or at http:\/\/t.co\/Bf9cE6miDx",
    "id" : 580104085967282176,
    "created_at" : "2015-03-23 20:29:26 +0000",
    "user" : {
      "name" : "Mentor4U",
      "screen_name" : "teamtheta",
      "protected" : false,
      "id_str" : "2851392103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520745022648369153\/We3wBQ6y_normal.png",
      "id" : 2851392103,
      "verified" : false
    }
  },
  "id" : 580104248974708736,
  "created_at" : "2015-03-23 20:30:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/579815529235361792\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/mIufV8b1XV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAvrJtlUYAAmfVw.jpg",
      "id_str" : "579815529134710784",
      "id" : 579815529134710784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAvrJtlUYAAmfVw.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/mIufV8b1XV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579815529235361792",
  "text" : "That was a good Sandwich http:\/\/t.co\/mIufV8b1XV",
  "id" : 579815529235361792,
  "created_at" : "2015-03-23 01:22:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/fFAO6w76En",
      "expanded_url" : "http:\/\/edustudio.org\/",
      "display_url" : "edustudio.org"
    } ]
  },
  "geo" : { },
  "id_str" : "579716386215321600",
  "text" : "What to do on this awesome day, I know head on to: http:\/\/t.co\/fFAO6w76En",
  "id" : 579716386215321600,
  "created_at" : "2015-03-22 18:48:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "indices" : [ 3, 10 ],
      "id_str" : "150248263",
      "id" : 150248263
    }, {
      "name" : "Md Asaduzzaman",
      "screen_name" : "mr4miss",
      "indices" : [ 12, 20 ],
      "id_str" : "225855268",
      "id" : 225855268
    }, {
      "name" : "FiverrSupport",
      "screen_name" : "FiverrSupport",
      "indices" : [ 21, 35 ],
      "id_str" : "2359020440",
      "id" : 2359020440
    }, {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "indices" : [ 36, 43 ],
      "id_str" : "150248263",
      "id" : 150248263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579715656695726080",
  "text" : "RT @fiverr: @mr4miss @FiverrSupport @Fiverr Hello, everything is back up and running!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Md Asaduzzaman",
        "screen_name" : "mr4miss",
        "indices" : [ 0, 8 ],
        "id_str" : "225855268",
        "id" : 225855268
      }, {
        "name" : "FiverrSupport",
        "screen_name" : "FiverrSupport",
        "indices" : [ 9, 23 ],
        "id_str" : "2359020440",
        "id" : 2359020440
      }, {
        "name" : "Fiverr",
        "screen_name" : "fiverr",
        "indices" : [ 24, 31 ],
        "id_str" : "150248263",
        "id" : 150248263
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "579702715233611776",
    "geo" : { },
    "id_str" : "579714962165080064",
    "in_reply_to_user_id" : 225855268,
    "text" : "@mr4miss @FiverrSupport @Fiverr Hello, everything is back up and running!",
    "id" : 579714962165080064,
    "in_reply_to_status_id" : 579702715233611776,
    "created_at" : "2015-03-22 18:43:12 +0000",
    "in_reply_to_screen_name" : "mr4miss",
    "in_reply_to_user_id_str" : "225855268",
    "user" : {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "protected" : false,
      "id_str" : "150248263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818489482345201665\/owRu5UmW_normal.jpg",
      "id" : 150248263,
      "verified" : true
    }
  },
  "id" : 579715656695726080,
  "created_at" : "2015-03-22 18:45:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ubuntu",
      "screen_name" : "ubuntu",
      "indices" : [ 0, 7 ],
      "id_str" : "2480951",
      "id" : 2480951
    }, {
      "name" : "openSUSE",
      "screen_name" : "openSUSE",
      "indices" : [ 12, 21 ],
      "id_str" : "15134408",
      "id" : 15134408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579704811387424768",
  "in_reply_to_user_id" : 2480951,
  "text" : "@Ubuntu vs. @openSUSE who will win?",
  "id" : 579704811387424768,
  "created_at" : "2015-03-22 18:02:52 +0000",
  "in_reply_to_screen_name" : "ubuntu",
  "in_reply_to_user_id_str" : "2480951",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salesforce",
      "screen_name" : "salesforce",
      "indices" : [ 3, 14 ],
      "id_str" : "33612317",
      "id" : 33612317
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/salesforce\/status\/578232074383056896\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/2FrOvnLFtY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZLAgyWQAAL6Cx.jpg",
      "id_str" : "578232074336878592",
      "id" : 578232074336878592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZLAgyWQAAL6Cx.jpg",
      "sizes" : [ {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 594
      } ],
      "display_url" : "pic.twitter.com\/2FrOvnLFtY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/cA75y2GGV2",
      "expanded_url" : "http:\/\/sforce.co\/1O6w7XQ",
      "display_url" : "sforce.co\/1O6w7XQ"
    } ]
  },
  "geo" : { },
  "id_str" : "579704430368440320",
  "text" : "RT @salesforce: Announcing Availability of the Salesforce App for Outlook http:\/\/t.co\/cA75y2GGV2 http:\/\/t.co\/2FrOvnLFtY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/salesforce\/status\/578232074383056896\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/2FrOvnLFtY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZLAgyWQAAL6Cx.jpg",
        "id_str" : "578232074336878592",
        "id" : 578232074336878592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZLAgyWQAAL6Cx.jpg",
        "sizes" : [ {
          "h" : 155,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/2FrOvnLFtY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/cA75y2GGV2",
        "expanded_url" : "http:\/\/sforce.co\/1O6w7XQ",
        "display_url" : "sforce.co\/1O6w7XQ"
      } ]
    },
    "geo" : { },
    "id_str" : "578232074383056896",
    "text" : "Announcing Availability of the Salesforce App for Outlook http:\/\/t.co\/cA75y2GGV2 http:\/\/t.co\/2FrOvnLFtY",
    "id" : 578232074383056896,
    "created_at" : "2015-03-18 16:30:44 +0000",
    "user" : {
      "name" : "Salesforce",
      "screen_name" : "salesforce",
      "protected" : false,
      "id_str" : "33612317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716283264881700865\/voT_NePC_normal.jpg",
      "id" : 33612317,
      "verified" : true
    }
  },
  "id" : 579704430368440320,
  "created_at" : "2015-03-22 18:01:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579699417474686978",
  "text" : "People need to stop making fake celebrity or public figure accounts. What's wrong with you man? Lol",
  "id" : 579699417474686978,
  "created_at" : "2015-03-22 17:41:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579698955006668800",
  "text" : "When is the new @IE coming out, perhaps with a faster, less laggy UI, and more secure with extensions such as ad block?",
  "id" : 579698955006668800,
  "created_at" : "2015-03-22 17:39:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imthebus Excel",
      "screen_name" : "Imabus_Excel",
      "indices" : [ 3, 16 ],
      "id_str" : "3091783175",
      "id" : 3091783175
    }, {
      "name" : "Analytics Vidhya",
      "screen_name" : "AnalyticsVidhya",
      "indices" : [ 18, 34 ],
      "id_str" : "2311645130",
      "id" : 2311645130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579696907250892800",
  "text" : "RT @Imabus_Excel: @AnalyticsVidhya the most simply powerful but unknown short-cut I find is navigating the worksheet with &lt;ctrl&gt; \u2192\u2193\u2191\u2190 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Analytics Vidhya",
        "screen_name" : "AnalyticsVidhya",
        "indices" : [ 0, 16 ],
        "id_str" : "2311645130",
        "id" : 2311645130
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Imabus_Excel\/status\/577760188490522624\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/lxyI0j8Oqw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CASd1GBUcAA7l2W.jpg",
        "id_str" : "577760187685040128",
        "id" : 577760187685040128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CASd1GBUcAA7l2W.jpg",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lxyI0j8Oqw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "576367827579441152",
    "geo" : { },
    "id_str" : "577760188490522624",
    "in_reply_to_user_id" : 2311645130,
    "text" : "@AnalyticsVidhya the most simply powerful but unknown short-cut I find is navigating the worksheet with &lt;ctrl&gt; \u2192\u2193\u2191\u2190 http:\/\/t.co\/lxyI0j8Oqw",
    "id" : 577760188490522624,
    "in_reply_to_status_id" : 576367827579441152,
    "created_at" : "2015-03-17 09:15:37 +0000",
    "in_reply_to_screen_name" : "AnalyticsVidhya",
    "in_reply_to_user_id_str" : "2311645130",
    "user" : {
      "name" : "Imthebus Excel",
      "screen_name" : "Imabus_Excel",
      "protected" : false,
      "id_str" : "3091783175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576835272605704192\/kJ8F9GLp_normal.png",
      "id" : 3091783175,
      "verified" : false
    }
  },
  "id" : 579696907250892800,
  "created_at" : "2015-03-22 17:31:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash Ash K.\u2764",
      "screen_name" : "MissingTruth",
      "indices" : [ 0, 13 ],
      "id_str" : "2828722807",
      "id" : 2828722807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579638900165095424",
  "geo" : { },
  "id_str" : "579684104255324160",
  "in_reply_to_user_id" : 2828722807,
  "text" : "@MissingTruth if that is the IPhone 7, bring it on, lol, nice UI",
  "id" : 579684104255324160,
  "in_reply_to_status_id" : 579638900165095424,
  "created_at" : "2015-03-22 16:40:35 +0000",
  "in_reply_to_screen_name" : "MissingTruth",
  "in_reply_to_user_id_str" : "2828722807",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 3, 8 ],
      "id_str" : "30261067",
      "id" : 30261067
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CNET\/status\/579648756871786496\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/qKL7EIMRbK",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CAtTeR9WsAAuuwD.png",
      "id_str" : "579648756729163776",
      "id" : 579648756729163776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CAtTeR9WsAAuuwD.png",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/qKL7EIMRbK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/6dZ3u6nAjk",
      "expanded_url" : "http:\/\/cnet.co\/1ALoxZu",
      "display_url" : "cnet.co\/1ALoxZu"
    } ]
  },
  "geo" : { },
  "id_str" : "579683558354247680",
  "text" : "RT @CNET: This is what Apple's website looked like in 1998 http:\/\/t.co\/6dZ3u6nAjk http:\/\/t.co\/qKL7EIMRbK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CNET\/status\/579648756871786496\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/qKL7EIMRbK",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CAtTeR9WsAAuuwD.png",
        "id_str" : "579648756729163776",
        "id" : 579648756729163776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CAtTeR9WsAAuuwD.png",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/qKL7EIMRbK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/6dZ3u6nAjk",
        "expanded_url" : "http:\/\/cnet.co\/1ALoxZu",
        "display_url" : "cnet.co\/1ALoxZu"
      } ]
    },
    "geo" : { },
    "id_str" : "579648756871786496",
    "text" : "This is what Apple's website looked like in 1998 http:\/\/t.co\/6dZ3u6nAjk http:\/\/t.co\/qKL7EIMRbK",
    "id" : 579648756871786496,
    "created_at" : "2015-03-22 14:20:07 +0000",
    "user" : {
      "name" : "CNET",
      "screen_name" : "CNET",
      "protected" : false,
      "id_str" : "30261067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843183285031202816\/RX-c7ZSe_normal.jpg",
      "id" : 30261067,
      "verified" : true
    }
  },
  "id" : 579683558354247680,
  "created_at" : "2015-03-22 16:38:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "indices" : [ 0, 7 ],
      "id_str" : "150248263",
      "id" : 150248263
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Madness",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579681546711482369",
  "in_reply_to_user_id" : 150248263,
  "text" : "@Fiverr is down, probably updating servers, stop the #Madness",
  "id" : 579681546711482369,
  "created_at" : "2015-03-22 16:30:25 +0000",
  "in_reply_to_screen_name" : "fiverr",
  "in_reply_to_user_id_str" : "150248263",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 0, 9 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/578898980093972481\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/JV0yQgac25",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAipjh1WoAAC7X9.jpg",
      "id_str" : "578898979959775232",
      "id" : 578898979959775232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAipjh1WoAAC7X9.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JV0yQgac25"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578898980093972481",
  "in_reply_to_user_id" : 17468189,
  "text" : "@Oaklandu Cyber Summit 2015 http:\/\/t.co\/JV0yQgac25",
  "id" : 578898980093972481,
  "created_at" : "2015-03-20 12:40:46 +0000",
  "in_reply_to_screen_name" : "oaklandu",
  "in_reply_to_user_id_str" : "17468189",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wozniak",
      "screen_name" : "stevewoz",
      "indices" : [ 3, 12 ],
      "id_str" : "22938914",
      "id" : 22938914
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stevewoz\/status\/523945025437040640\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/dZVxLh6nGg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0VtOKYCYAEXRmN.jpg",
      "id_str" : "523945021729300481",
      "id" : 523945021729300481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0VtOKYCYAEXRmN.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dZVxLh6nGg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578631134407340033",
  "text" : "RT @stevewoz: \"Do Not Flush Over Cities\" spotted on flight to Sydney. http:\/\/t.co\/dZVxLh6nGg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stevewoz\/status\/523945025437040640\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dZVxLh6nGg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0VtOKYCYAEXRmN.jpg",
        "id_str" : "523945021729300481",
        "id" : 523945021729300481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0VtOKYCYAEXRmN.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dZVxLh6nGg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523945025437040640",
    "text" : "\"Do Not Flush Over Cities\" spotted on flight to Sydney. http:\/\/t.co\/dZVxLh6nGg",
    "id" : 523945025437040640,
    "created_at" : "2014-10-19 21:13:23 +0000",
    "user" : {
      "name" : "Steve Wozniak",
      "screen_name" : "stevewoz",
      "protected" : false,
      "id_str" : "22938914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1365311061\/Janet_and_Woz_normal.jpg",
      "id" : 22938914,
      "verified" : true
    }
  },
  "id" : 578631134407340033,
  "created_at" : "2015-03-19 18:56:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudia Alende",
      "screen_name" : "claudiaalende",
      "indices" : [ 6, 20 ],
      "id_str" : "25102250",
      "id" : 25102250
    }, {
      "name" : "HeadFunder",
      "screen_name" : "headfunder",
      "indices" : [ 33, 44 ],
      "id_str" : "2828887771",
      "id" : 2828887771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "Children",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ENvbZ8h35n",
      "expanded_url" : "http:\/\/goo.gl\/1G6Kam",
      "display_url" : "goo.gl\/1G6Kam"
    } ]
  },
  "geo" : { },
  "id_str" : "578629060584050688",
  "text" : "Model @claudiaalende supports my @headfunder campaign, you should too, go to: http:\/\/t.co\/ENvbZ8h35n #STEM #Children",
  "id" : 578629060584050688,
  "created_at" : "2015-03-19 18:48:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inspired",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577929706357399552",
  "text" : "What does it mean to be #inspired",
  "id" : 577929706357399552,
  "created_at" : "2015-03-17 20:29:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoViral @HeadTalker",
      "screen_name" : "loveheadtalker",
      "indices" : [ 3, 18 ],
      "id_str" : "539539884",
      "id" : 539539884
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 24, 36 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 87, 98 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/1p6gE03rGs",
      "expanded_url" : "https:\/\/headtalker.com\/?p=13471",
      "display_url" : "headtalker.com\/?p=13471"
    } ]
  },
  "geo" : { },
  "id_str" : "577929360402837504",
  "text" : "RT @loveheadtalker: Hey @gamer456148 I just supported Education for $9: Mentors4EDU on @HeadTalker   https:\/\/t.co\/1p6gE03rGs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 4, 16 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "HeadTalker",
        "screen_name" : "headtalker",
        "indices" : [ 67, 78 ],
        "id_str" : "2177390274",
        "id" : 2177390274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/1p6gE03rGs",
        "expanded_url" : "https:\/\/headtalker.com\/?p=13471",
        "display_url" : "headtalker.com\/?p=13471"
      } ]
    },
    "geo" : { },
    "id_str" : "577632577063796736",
    "text" : "Hey @gamer456148 I just supported Education for $9: Mentors4EDU on @HeadTalker   https:\/\/t.co\/1p6gE03rGs",
    "id" : 577632577063796736,
    "created_at" : "2015-03-17 00:48:32 +0000",
    "user" : {
      "name" : "GoViral @HeadTalker",
      "screen_name" : "loveheadtalker",
      "protected" : false,
      "id_str" : "539539884",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616414520299290624\/qZHiy_9w_normal.jpg",
      "id" : 539539884,
      "verified" : false
    }
  },
  "id" : 577929360402837504,
  "created_at" : "2015-03-17 20:27:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/C5HaQYyXjw",
      "expanded_url" : "http:\/\/dlvr.it\/8zxqXX",
      "display_url" : "dlvr.it\/8zxqXX"
    } ]
  },
  "geo" : { },
  "id_str" : "577598444652486656",
  "text" : "RT @copticworld: Egypt: Christians Face Harassment, Violence in Attempting to Rebuild Church: Egypt: Christians\u2026 http:\/\/t.co\/C5HaQYyXjw @Co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CopticWorld",
        "screen_name" : "copticworld",
        "indices" : [ 119, 131 ],
        "id_str" : "136923775",
        "id" : 136923775
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coptic",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/C5HaQYyXjw",
        "expanded_url" : "http:\/\/dlvr.it\/8zxqXX",
        "display_url" : "dlvr.it\/8zxqXX"
      } ]
    },
    "geo" : { },
    "id_str" : "577555203991285760",
    "text" : "Egypt: Christians Face Harassment, Violence in Attempting to Rebuild Church: Egypt: Christians\u2026 http:\/\/t.co\/C5HaQYyXjw @CopticWorld #coptic",
    "id" : 577555203991285760,
    "created_at" : "2015-03-16 19:41:05 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 577598444652486656,
  "created_at" : "2015-03-16 22:32:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 3, 14 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577596836648599552",
  "text" : "RT @headtalker: @gamer456148 very soon :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "577582414752411648",
    "geo" : { },
    "id_str" : "577595704840867841",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 very soon :)",
    "id" : 577595704840867841,
    "in_reply_to_status_id" : 577582414752411648,
    "created_at" : "2015-03-16 22:22:01 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "protected" : false,
      "id_str" : "2177390274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724693924669886465\/ShWXP5Jt_normal.jpg",
      "id" : 2177390274,
      "verified" : false
    }
  },
  "id" : 577596836648599552,
  "created_at" : "2015-03-16 22:26:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 0, 9 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 23, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577583457242497024",
  "in_reply_to_user_id" : 17468189,
  "text" : "@oaklandu Just got the #CyberSummit information packet, can't wait tell the 20th!!!",
  "id" : 577583457242497024,
  "created_at" : "2015-03-16 21:33:21 +0000",
  "in_reply_to_screen_name" : "oaklandu",
  "in_reply_to_user_id_str" : "17468189",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 0, 11 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excited",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577582414752411648",
  "in_reply_to_user_id" : 2177390274,
  "text" : "@headtalker I just made a campaign, hopefully it will get approved #excited",
  "id" : 577582414752411648,
  "created_at" : "2015-03-16 21:29:13 +0000",
  "in_reply_to_screen_name" : "headtalker",
  "in_reply_to_user_id_str" : "2177390274",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BA-EXPERTS",
      "screen_name" : "BAEXPERTS",
      "indices" : [ 3, 13 ],
      "id_str" : "804603721",
      "id" : 804603721
    }, {
      "name" : "Kapil Apshankar",
      "screen_name" : "KapilApshankar",
      "indices" : [ 34, 49 ],
      "id_str" : "14710234",
      "id" : 14710234
    }, {
      "name" : "Sell More Talk Less",
      "screen_name" : "SellMoreTalkLes",
      "indices" : [ 68, 84 ],
      "id_str" : "1711457802",
      "id" : 1711457802
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 85, 97 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "SharperTrades",
      "screen_name" : "SharperTrades",
      "indices" : [ 98, 112 ],
      "id_str" : "2224310420",
      "id" : 2224310420
    }, {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 113, 119 ],
      "id_str" : "70266297",
      "id" : 70266297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baot",
      "indices" : [ 120, 125 ]
    }, {
      "text" : "pmot",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577485892215971840",
  "text" : "RT @BAEXPERTS: Read MOOC Watch by @KapilApshankar \u25B8 Top stories via @SellMoreTalkLes @gamer456148 @SharperTrades @Udemy #baot #pmot http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kapil Apshankar",
        "screen_name" : "KapilApshankar",
        "indices" : [ 19, 34 ],
        "id_str" : "14710234",
        "id" : 14710234
      }, {
        "name" : "Sell More Talk Less",
        "screen_name" : "SellMoreTalkLes",
        "indices" : [ 53, 69 ],
        "id_str" : "1711457802",
        "id" : 1711457802
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 70, 82 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "SharperTrades",
        "screen_name" : "SharperTrades",
        "indices" : [ 83, 97 ],
        "id_str" : "2224310420",
        "id" : 2224310420
      }, {
        "name" : "Udemy",
        "screen_name" : "udemy",
        "indices" : [ 98, 104 ],
        "id_str" : "70266297",
        "id" : 70266297
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "baot",
        "indices" : [ 105, 110 ]
      }, {
        "text" : "pmot",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1bEc6i7102",
        "expanded_url" : "http:\/\/ow.ly\/KnbWh",
        "display_url" : "ow.ly\/KnbWh"
      } ]
    },
    "geo" : { },
    "id_str" : "577377885981446144",
    "text" : "Read MOOC Watch by @KapilApshankar \u25B8 Top stories via @SellMoreTalkLes @gamer456148 @SharperTrades @Udemy #baot #pmot http:\/\/t.co\/1bEc6i7102",
    "id" : 577377885981446144,
    "created_at" : "2015-03-16 07:56:29 +0000",
    "user" : {
      "name" : "BA-EXPERTS",
      "screen_name" : "BAEXPERTS",
      "protected" : false,
      "id_str" : "804603721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2651101843\/e4563d377f5191194e382f4738f68668_normal.png",
      "id" : 804603721,
      "verified" : false
    }
  },
  "id" : 577485892215971840,
  "created_at" : "2015-03-16 15:05:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autodesk Education",
      "screen_name" : "AutodeskEDU",
      "indices" : [ 3, 15 ],
      "id_str" : "72975707",
      "id" : 72975707
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AutodeskEDU\/status\/576027367048630272\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BWJT91Sjs9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_511pxWcAAzOtF.jpg",
      "id_str" : "576027366956363776",
      "id" : 576027366956363776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_511pxWcAAzOtF.jpg",
      "sizes" : [ {
        "h" : 444,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BWJT91Sjs9"
    } ],
    "hashtags" : [ {
      "text" : "REAL2015",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "3DPrinting",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/pj1vwcagCM",
      "expanded_url" : "http:\/\/autode.sk\/1AP9fSd",
      "display_url" : "autode.sk\/1AP9fSd"
    } ]
  },
  "geo" : { },
  "id_str" : "577114060036001792",
  "text" : "RT @AutodeskEDU: Did you miss #REAL2015? Check out these highlights #3DPrinting http:\/\/t.co\/pj1vwcagCM http:\/\/t.co\/BWJT91Sjs9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AutodeskEDU\/status\/576027367048630272\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/BWJT91Sjs9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_511pxWcAAzOtF.jpg",
        "id_str" : "576027366956363776",
        "id" : 576027366956363776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_511pxWcAAzOtF.jpg",
        "sizes" : [ {
          "h" : 444,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BWJT91Sjs9"
      } ],
      "hashtags" : [ {
        "text" : "REAL2015",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "3DPrinting",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/pj1vwcagCM",
        "expanded_url" : "http:\/\/autode.sk\/1AP9fSd",
        "display_url" : "autode.sk\/1AP9fSd"
      } ]
    },
    "geo" : { },
    "id_str" : "576027367048630272",
    "text" : "Did you miss #REAL2015? Check out these highlights #3DPrinting http:\/\/t.co\/pj1vwcagCM http:\/\/t.co\/BWJT91Sjs9",
    "id" : 576027367048630272,
    "created_at" : "2015-03-12 14:30:01 +0000",
    "user" : {
      "name" : "Autodesk Education",
      "screen_name" : "AutodeskEDU",
      "protected" : false,
      "id_str" : "72975707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674667605328728064\/eza7xdI1_normal.png",
      "id" : 72975707,
      "verified" : false
    }
  },
  "id" : 577114060036001792,
  "created_at" : "2015-03-15 14:28:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "India Today",
      "screen_name" : "IndiaToday",
      "indices" : [ 121, 132 ],
      "id_str" : "19897138",
      "id" : 19897138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/IeUFmM86dI",
      "expanded_url" : "http:\/\/indiatoday.intoday.in\/story\/world-cup-2015-india-vs-zimbabwe-live-score-pool-b-match-39\/1\/423790.html",
      "display_url" : "indiatoday.intoday.in\/story\/world-cu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577113477887582208",
  "text" : "World Cup: India remain unbeaten, trump Zimbabwe by six wickets : Updates, News - India Today http:\/\/t.co\/IeUFmM86dI via @IndiaToday",
  "id" : 577113477887582208,
  "created_at" : "2015-03-15 14:25:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spoiled",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576750273718136832",
  "text" : "My little sister is so #spoiled",
  "id" : 576750273718136832,
  "created_at" : "2015-03-14 14:22:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 78, 90 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Online",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "video",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "course",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "Udemy",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RNCG0izwwF",
      "expanded_url" : "http:\/\/coupontru.mp\/39189b",
      "display_url" : "coupontru.mp\/39189b"
    } ]
  },
  "geo" : { },
  "id_str" : "576748524760510464",
  "text" : "RT @CouponTrump: #Online #video #course Hackathon ABC: An Introduction #Udemy @gamer456148 http:\/\/t.co\/RNCG0izwwF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.coupontrump.com\" rel=\"nofollow\"\u003ECpnt_Autotweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 61, 73 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Online",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "video",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "course",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "Udemy",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/RNCG0izwwF",
        "expanded_url" : "http:\/\/coupontru.mp\/39189b",
        "display_url" : "coupontru.mp\/39189b"
      } ]
    },
    "geo" : { },
    "id_str" : "576622107280424960",
    "text" : "#Online #video #course Hackathon ABC: An Introduction #Udemy @gamer456148 http:\/\/t.co\/RNCG0izwwF",
    "id" : 576622107280424960,
    "created_at" : "2015-03-14 05:53:18 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 576748524760510464,
  "created_at" : "2015-03-14 14:15:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alison victoria",
      "screen_name" : "alisonvictoria3",
      "indices" : [ 20, 36 ],
      "id_str" : "613889171",
      "id" : 613889171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KitchenCrashers",
      "indices" : [ 76, 92 ]
    }, {
      "text" : "DIYNetwork",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575787118632402945",
  "text" : "I wish I could meet @alisonvictoria3 but my kitchen is already great!!! Lol #KitchenCrashers #DIYNetwork",
  "id" : 575787118632402945,
  "created_at" : "2015-03-11 22:35:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cyber OU",
      "screen_name" : "CyberOU",
      "indices" : [ 3, 11 ],
      "id_str" : "1329353672",
      "id" : 1329353672
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/favJAn6bJr",
      "expanded_url" : "http:\/\/CyberOU.com\/Summit",
      "display_url" : "CyberOU.com\/Summit"
    } ]
  },
  "geo" : { },
  "id_str" : "575337512849162241",
  "text" : "RT @CyberOU: @gamer456148 you can always find our more about The Summit at http:\/\/t.co\/favJAn6bJr. We are super excited to see you there!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/favJAn6bJr",
        "expanded_url" : "http:\/\/CyberOU.com\/Summit",
        "display_url" : "CyberOU.com\/Summit"
      } ]
    },
    "in_reply_to_status_id_str" : "574968979157950464",
    "geo" : { },
    "id_str" : "575095356603678720",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 you can always find our more about The Summit at http:\/\/t.co\/favJAn6bJr. We are super excited to see you there!!!",
    "id" : 575095356603678720,
    "in_reply_to_status_id" : 574968979157950464,
    "created_at" : "2015-03-10 00:46:32 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Cyber OU",
      "screen_name" : "CyberOU",
      "protected" : false,
      "id_str" : "1329353672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505815811496218625\/1Mi4JgRg_normal.png",
      "id" : 1329353672,
      "verified" : false
    }
  },
  "id" : 575337512849162241,
  "created_at" : "2015-03-10 16:48:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575016757846413313",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Waiting for a new video, maybe a Quirky DIYer?",
  "id" : 575016757846413313,
  "created_at" : "2015-03-09 19:34:13 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 3, 14 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teaparty",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "tcot",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/xwcusQUCF2",
      "expanded_url" : "http:\/\/bit.ly\/1FSgf5j",
      "display_url" : "bit.ly\/1FSgf5j"
    } ]
  },
  "geo" : { },
  "id_str" : "575016519509258240",
  "text" : "RT @TPPatriots: Let's shock the Washington establishment! http:\/\/t.co\/xwcusQUCF2 #teaparty #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teaparty",
        "indices" : [ 65, 74 ]
      }, {
        "text" : "tcot",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/xwcusQUCF2",
        "expanded_url" : "http:\/\/bit.ly\/1FSgf5j",
        "display_url" : "bit.ly\/1FSgf5j"
      } ]
    },
    "geo" : { },
    "id_str" : "574979577346285568",
    "text" : "Let's shock the Washington establishment! http:\/\/t.co\/xwcusQUCF2 #teaparty #tcot",
    "id" : 574979577346285568,
    "created_at" : "2015-03-09 17:06:28 +0000",
    "user" : {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "protected" : false,
      "id_str" : "86177206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496315557872807936\/mcs0nVcY_normal.jpeg",
      "id" : 86177206,
      "verified" : true
    }
  },
  "id" : 575016519509258240,
  "created_at" : "2015-03-09 19:33:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 3, 14 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teaparty",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xwcusQUCF2",
      "expanded_url" : "http:\/\/bit.ly\/1FSgf5j",
      "display_url" : "bit.ly\/1FSgf5j"
    } ]
  },
  "geo" : { },
  "id_str" : "575016501477908481",
  "text" : "RT @TPPatriots: Celebrate 6 years with us + help raise an unprecedented amount of funding! http:\/\/t.co\/xwcusQUCF2 #teaparty http:\/\/t.co\/BY5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TPPatriots\/status\/574979355769622528\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/BY5jbFgWgW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_q8rXfU8AEetcl.jpg",
        "id_str" : "574979355668967425",
        "id" : 574979355668967425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_q8rXfU8AEetcl.jpg",
        "sizes" : [ {
          "h" : 200,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BY5jbFgWgW"
      } ],
      "hashtags" : [ {
        "text" : "teaparty",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/xwcusQUCF2",
        "expanded_url" : "http:\/\/bit.ly\/1FSgf5j",
        "display_url" : "bit.ly\/1FSgf5j"
      } ]
    },
    "geo" : { },
    "id_str" : "574979355769622528",
    "text" : "Celebrate 6 years with us + help raise an unprecedented amount of funding! http:\/\/t.co\/xwcusQUCF2 #teaparty http:\/\/t.co\/BY5jbFgWgW",
    "id" : 574979355769622528,
    "created_at" : "2015-03-09 17:05:35 +0000",
    "user" : {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "protected" : false,
      "id_str" : "86177206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496315557872807936\/mcs0nVcY_normal.jpeg",
      "id" : 86177206,
      "verified" : true
    }
  },
  "id" : 575016501477908481,
  "created_at" : "2015-03-09 19:33:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "saved",
      "screen_name" : "ashleymardell",
      "indices" : [ 0, 14 ],
      "id_str" : "800446837895237632",
      "id" : 800446837895237632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575016278106091520",
  "in_reply_to_user_id" : 101129043,
  "text" : "@AshleyMardell I haven't watched your channel for years, and you changed way too much, not gonna watch your channel again, too weird for me",
  "id" : 575016278106091520,
  "created_at" : "2015-03-09 19:32:18 +0000",
  "in_reply_to_screen_name" : "AshHardell",
  "in_reply_to_user_id_str" : "101129043",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unity",
      "screen_name" : "unity3d",
      "indices" : [ 0, 8 ],
      "id_str" : "15531582",
      "id" : 15531582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Unity5",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574998808251133953",
  "in_reply_to_user_id" : 15531582,
  "text" : "@Unity3D #Unity5.0 is here, and my favorite Engine Unreal may have some serious competition.",
  "id" : 574998808251133953,
  "created_at" : "2015-03-09 18:22:53 +0000",
  "in_reply_to_screen_name" : "unity3d",
  "in_reply_to_user_id_str" : "15531582",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 20, 29 ],
      "id_str" : "17468189",
      "id" : 17468189
    }, {
      "name" : "Cyber OU",
      "screen_name" : "CyberOU",
      "indices" : [ 30, 38 ],
      "id_str" : "1329353672",
      "id" : 1329353672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IT",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574968979157950464",
  "text" : "I signed up for the @oaklandu @CyberOU Cyber Summit, if it is anything like the Hackathons I attended, it will probably be awesome. #IT",
  "id" : 574968979157950464,
  "created_at" : "2015-03-09 16:24:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach King",
      "screen_name" : "FinalCutKing",
      "indices" : [ 3, 16 ],
      "id_str" : "30599331",
      "id" : 30599331
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PetePeeve",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "NationalCerealDay",
      "indices" : [ 79, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/xnhkp0SFvS",
      "expanded_url" : "https:\/\/vine.co\/v\/OEiPO972TYe",
      "display_url" : "vine.co\/v\/OEiPO972TYe"
    } ]
  },
  "geo" : { },
  "id_str" : "574715233085710336",
  "text" : "RT @FinalCutKing: Don't you hate when your friends eat like slobs!? #PetePeeve #NationalCerealDay https:\/\/t.co\/xnhkp0SFvS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PetePeeve",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "NationalCerealDay",
        "indices" : [ 61, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/xnhkp0SFvS",
        "expanded_url" : "https:\/\/vine.co\/v\/OEiPO972TYe",
        "display_url" : "vine.co\/v\/OEiPO972TYe"
      } ]
    },
    "geo" : { },
    "id_str" : "574286729420541953",
    "text" : "Don't you hate when your friends eat like slobs!? #PetePeeve #NationalCerealDay https:\/\/t.co\/xnhkp0SFvS",
    "id" : 574286729420541953,
    "created_at" : "2015-03-07 19:13:20 +0000",
    "user" : {
      "name" : "Zach King",
      "screen_name" : "FinalCutKing",
      "protected" : false,
      "id_str" : "30599331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473970390868316161\/KZvt_QCh_normal.jpeg",
      "id" : 30599331,
      "verified" : true
    }
  },
  "id" : 574715233085710336,
  "created_at" : "2015-03-08 23:36:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574715074125791235",
  "text" : "I just watched Mika Leon on TV at Guy's grocery games, wow what a beautiful talented young chef. XD",
  "id" : 574715074125791235,
  "created_at" : "2015-03-08 23:35:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nirbhay Taneja",
      "screen_name" : "NirbhayTaneja",
      "indices" : [ 0, 14 ],
      "id_str" : "2267144640",
      "id" : 2267144640
    }, {
      "name" : "LearnSocial",
      "screen_name" : "learnsocial",
      "indices" : [ 15, 27 ],
      "id_str" : "458581537",
      "id" : 458581537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "570205143364300800",
  "geo" : { },
  "id_str" : "574602782100996097",
  "in_reply_to_user_id" : 2267144640,
  "text" : "@NirbhayTaneja @learnsocial I might check that out in the future, it all depends...",
  "id" : 574602782100996097,
  "in_reply_to_status_id" : 570205143364300800,
  "created_at" : "2015-03-08 16:09:13 +0000",
  "in_reply_to_screen_name" : "NirbhayTaneja",
  "in_reply_to_user_id_str" : "2267144640",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KoGaMa",
      "screen_name" : "KOGAMAGAME",
      "indices" : [ 3, 14 ],
      "id_str" : "337616593",
      "id" : 337616593
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574602188531503105",
  "text" : "RT @KOGAMAGAME: @gamer456148 KoGaMa is awesome ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "574601327889666049",
    "geo" : { },
    "id_str" : "574601447431602178",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 KoGaMa is awesome ;-)",
    "id" : 574601447431602178,
    "in_reply_to_status_id" : 574601327889666049,
    "created_at" : "2015-03-08 16:03:55 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "KoGaMa",
      "screen_name" : "KOGAMAGAME",
      "protected" : false,
      "id_str" : "337616593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748486078005379072\/rVDKz5SZ_normal.jpg",
      "id" : 337616593,
      "verified" : false
    }
  },
  "id" : 574602188531503105,
  "created_at" : "2015-03-08 16:06:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sploder.com",
      "screen_name" : "sploder",
      "indices" : [ 3, 11 ],
      "id_str" : "39554440",
      "id" : 39554440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamedev",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/T08EDWtMKr",
      "expanded_url" : "http:\/\/www.sploder.com\/multiplayer\/sploderheads\/",
      "display_url" : "sploder.com\/multiplayer\/sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "574601985468424194",
  "text" : "RT @sploder: Multiplayer updated! The game is now fully mobile, too! Try it on a phone or tablet! http:\/\/t.co\/T08EDWtMKr #gamedev http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sploder\/status\/543146061104443394\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/XPHMpAoxwG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4mkdtrIMAEHdhJ.png",
        "id_str" : "543146060458504193",
        "id" : 543146060458504193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4mkdtrIMAEHdhJ.png",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XPHMpAoxwG"
      } ],
      "hashtags" : [ {
        "text" : "gamedev",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/T08EDWtMKr",
        "expanded_url" : "http:\/\/www.sploder.com\/multiplayer\/sploderheads\/",
        "display_url" : "sploder.com\/multiplayer\/sp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "543146061104443394",
    "text" : "Multiplayer updated! The game is now fully mobile, too! Try it on a phone or tablet! http:\/\/t.co\/T08EDWtMKr #gamedev http:\/\/t.co\/XPHMpAoxwG",
    "id" : 543146061104443394,
    "created_at" : "2014-12-11 20:51:26 +0000",
    "user" : {
      "name" : "Sploder.com",
      "screen_name" : "sploder",
      "protected" : false,
      "id_str" : "39554440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461767018379620352\/BaExDAaO_normal.png",
      "id" : 39554440,
      "verified" : false
    }
  },
  "id" : 574601985468424194,
  "created_at" : "2015-03-08 16:06:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KoGaMa",
      "screen_name" : "KOGAMAGAME",
      "indices" : [ 26, 37 ],
      "id_str" : "337616593",
      "id" : 337616593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574601327889666049",
  "text" : "What do you guys think of @KOGAMAGAME?",
  "id" : 574601327889666049,
  "created_at" : "2015-03-08 16:03:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 11, 21 ],
      "id_str" : "74286565",
      "id" : 74286565
    }, {
      "name" : "Minecraft",
      "screen_name" : "Minecraft",
      "indices" : [ 58, 68 ],
      "id_str" : "64565898",
      "id" : 64565898
    }, {
      "name" : "Sploder.com",
      "screen_name" : "sploder",
      "indices" : [ 88, 96 ],
      "id_str" : "39554440",
      "id" : 39554440
    }, {
      "name" : "Roblox",
      "screen_name" : "Roblox",
      "indices" : [ 100, 107 ],
      "id_str" : "16745055",
      "id" : 16745055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574600972632113153",
  "text" : "I think if @Microsoft goes too overboard, then eventually @Minecraft can be replaced by @sploder or @ROBLOX",
  "id" : 574600972632113153,
  "created_at" : "2015-03-08 16:02:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "indices" : [ 3, 13 ],
      "id_str" : "685513",
      "id" : 685513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574278884679532545",
  "text" : "RT @WordPress: WordPress 4.1 \u201CDinah\u201D helps you focus on your writing, and the new Twenty Fifteen theme lets you show it off in style http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/swKBJjFy0G",
        "expanded_url" : "http:\/\/wp.me\/sZhYe-dinah",
        "display_url" : "wp.me\/sZhYe-dinah"
      } ]
    },
    "geo" : { },
    "id_str" : "545655921070723072",
    "text" : "WordPress 4.1 \u201CDinah\u201D helps you focus on your writing, and the new Twenty Fifteen theme lets you show it off in style http:\/\/t.co\/swKBJjFy0G",
    "id" : 545655921070723072,
    "created_at" : "2014-12-18 19:04:44 +0000",
    "user" : {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "protected" : false,
      "id_str" : "685513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59801350\/logo_normal.png",
      "id" : 685513,
      "verified" : true
    }
  },
  "id" : 574278884679532545,
  "created_at" : "2015-03-07 18:42:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "indices" : [ 3, 13 ],
      "id_str" : "685513",
      "id" : 685513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/13k79WVckG",
      "expanded_url" : "http:\/\/wp.me\/pZhYe-Tq",
      "display_url" : "wp.me\/pZhYe-Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "574278862655246337",
  "text" : "RT @WordPress: WordPress 4.1.1 Maintenance Release: http:\/\/t.co\/13k79WVckG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/13k79WVckG",
        "expanded_url" : "http:\/\/wp.me\/pZhYe-Tq",
        "display_url" : "wp.me\/pZhYe-Tq"
      } ]
    },
    "geo" : { },
    "id_str" : "568193447640723457",
    "text" : "WordPress 4.1.1 Maintenance Release: http:\/\/t.co\/13k79WVckG",
    "id" : 568193447640723457,
    "created_at" : "2015-02-18 23:40:49 +0000",
    "user" : {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "protected" : false,
      "id_str" : "685513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/59801350\/logo_normal.png",
      "id" : 685513,
      "verified" : true
    }
  },
  "id" : 574278862655246337,
  "created_at" : "2015-03-07 18:42:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/574277948565364736\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/p7cMazCKzU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_g-wDTUcAAMbDT.png",
      "id_str" : "574277947730718720",
      "id" : 574277947730718720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_g-wDTUcAAMbDT.png",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 738
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 738
      } ],
      "display_url" : "pic.twitter.com\/p7cMazCKzU"
    } ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574277948565364736",
  "text" : "Who are the pioneers of the internet industry? #wordpress http:\/\/t.co\/p7cMazCKzU",
  "id" : 574277948565364736,
  "created_at" : "2015-03-07 18:38:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Awesomeness",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574236723758026753",
  "text" : "Have you ever tried Double Dunker ice cream, if not, you should #Awesomeness",
  "id" : 574236723758026753,
  "created_at" : "2015-03-07 15:54:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572824080040251393",
  "geo" : { },
  "id_str" : "573161220619968512",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice ABC Family and Disney are pushing absolutely disgusting propaganda on America's youth.",
  "id" : 573161220619968512,
  "in_reply_to_status_id" : 572824080040251393,
  "created_at" : "2015-03-04 16:40:58 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/nDz8TMvVbt",
      "expanded_url" : "http:\/\/youtu.be\/aYJzdvuBjc4",
      "display_url" : "youtu.be\/aYJzdvuBjc4"
    } ]
  },
  "geo" : { },
  "id_str" : "573160893632004096",
  "text" : "RT @MarkDice: Star Trek Depicts Satan as Savior of Mankind in 1973 Animated Series Magicks of Megas-Tu Episode  http:\/\/t.co\/nDz8TMvVbt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/nDz8TMvVbt",
        "expanded_url" : "http:\/\/youtu.be\/aYJzdvuBjc4",
        "display_url" : "youtu.be\/aYJzdvuBjc4"
      } ]
    },
    "geo" : { },
    "id_str" : "571775664010895360",
    "text" : "Star Trek Depicts Satan as Savior of Mankind in 1973 Animated Series Magicks of Megas-Tu Episode  http:\/\/t.co\/nDz8TMvVbt",
    "id" : 571775664010895360,
    "created_at" : "2015-02-28 20:55:16 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 573160893632004096,
  "created_at" : "2015-03-04 16:39:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572903117919895552",
  "text" : "I used to watch this show about a magical Irish pig when I was young, it was called Jakers, oh the memory brings me back, lol",
  "id" : 572903117919895552,
  "created_at" : "2015-03-03 23:35:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guns.com",
      "screen_name" : "Guns_com",
      "indices" : [ 3, 12 ],
      "id_str" : "182433311",
      "id" : 182433311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JMCQsnmgel",
      "expanded_url" : "http:\/\/www.guns.com\/?p=136797",
      "display_url" : "guns.com\/?p=136797"
    } ]
  },
  "geo" : { },
  "id_str" : "572880061461762049",
  "text" : "RT @Guns_com: How many water balloons does it take to stop a .44 Magnum? (VIDEO) http:\/\/t.co\/JMCQsnmgel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.guns.com\" rel=\"nofollow\"\u003EGuns WP App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/JMCQsnmgel",
        "expanded_url" : "http:\/\/www.guns.com\/?p=136797",
        "display_url" : "guns.com\/?p=136797"
      } ]
    },
    "geo" : { },
    "id_str" : "572870467238813696",
    "text" : "How many water balloons does it take to stop a .44 Magnum? (VIDEO) http:\/\/t.co\/JMCQsnmgel",
    "id" : 572870467238813696,
    "created_at" : "2015-03-03 21:25:37 +0000",
    "user" : {
      "name" : "Guns.com",
      "screen_name" : "Guns_com",
      "protected" : false,
      "id_str" : "182433311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1490682661\/guns_normal.jpg",
      "id" : 182433311,
      "verified" : true
    }
  },
  "id" : 572880061461762049,
  "created_at" : "2015-03-03 22:03:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ripoff Report",
      "screen_name" : "RipoffReport",
      "indices" : [ 95, 108 ],
      "id_str" : "322136702",
      "id" : 322136702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/N1y7gduWPh",
      "expanded_url" : "http:\/\/www.ripoffreport.com\/r\/sm-1213097",
      "display_url" : "ripoffreport.com\/r\/sm-1213097"
    } ]
  },
  "geo" : { },
  "id_str" : "572879747903930369",
  "text" : "Ripoff Report | Quirky Complaint Review New York, New York: 1213097 http:\/\/t.co\/N1y7gduWPh via @ripoffreport",
  "id" : 572879747903930369,
  "created_at" : "2015-03-03 22:02:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Awesome",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572860770154762240",
  "text" : "I was shoveling the snow and kept falling down because it rained and turned into ice, I left, came back and found the snow gone #Awesome",
  "id" : 572860770154762240,
  "created_at" : "2015-03-03 20:47:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 3, 12 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/X7JcYEtW8G",
      "expanded_url" : "http:\/\/ow.ly\/JK0iV",
      "display_url" : "ow.ly\/JK0iV"
    } ]
  },
  "geo" : { },
  "id_str" : "572856892596203520",
  "text" : "RT @oaklandu: How OU is leveraging its green campus to teach programs and conduct research on energy efficiency http:\/\/t.co\/X7JcYEtW8G #Thi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThisIsOU",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/X7JcYEtW8G",
        "expanded_url" : "http:\/\/ow.ly\/JK0iV",
        "display_url" : "ow.ly\/JK0iV"
      } ]
    },
    "geo" : { },
    "id_str" : "571447203509743617",
    "text" : "How OU is leveraging its green campus to teach programs and conduct research on energy efficiency http:\/\/t.co\/X7JcYEtW8G #ThisIsOU",
    "id" : 571447203509743617,
    "created_at" : "2015-02-27 23:10:04 +0000",
    "user" : {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "protected" : false,
      "id_str" : "17468189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474898532759912448\/Dxj_fOZo_normal.jpeg",
      "id" : 17468189,
      "verified" : false
    }
  },
  "id" : 572856892596203520,
  "created_at" : "2015-03-03 20:31:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katie stout",
      "screen_name" : "ummmsmile",
      "indices" : [ 7, 17 ],
      "id_str" : "2825743064",
      "id" : 2825743064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "passion",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572592558942994433",
  "text" : "I knew @ummmsmile was going to win. Poor Tim though, life can be tough. Both were very talented. I love Katy's quirkiness though. #passion",
  "id" : 572592558942994433,
  "created_at" : "2015-03-03 03:01:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]