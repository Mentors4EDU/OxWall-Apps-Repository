Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 36, 44 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/9I2THw7i",
      "expanded_url" : "http:\/\/youtu.be\/dJos0OrFxx0?a",
      "display_url" : "youtu.be\/dJos0OrFxx0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "296809157422620672",
  "text" : "My Tattoo: http:\/\/t.co\/9I2THw7i via @YouTube",
  "id" : 296809157422620672,
  "created_at" : "2013-01-31 02:36:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/S31PFtU5",
      "expanded_url" : "http:\/\/youtu.be\/fJR84trAP7Q?a",
      "display_url" : "youtu.be\/fJR84trAP7Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "294641820313456640",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/S31PFtU5 Shabbat Shalom (Modern Version) AMKAMAL Coverup",
  "id" : 294641820313456640,
  "created_at" : "2013-01-25 03:04:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/ecdjxf5i",
      "expanded_url" : "http:\/\/youtu.be\/xv3gK2bmkAk?a",
      "display_url" : "youtu.be\/xv3gK2bmkAk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "294467522105860096",
  "text" : "I liked a @YouTube video http:\/\/t.co\/ecdjxf5i Best of Stupid Game Show Answers (SGSA)",
  "id" : 294467522105860096,
  "created_at" : "2013-01-24 15:31:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/XuTxUIQT",
      "expanded_url" : "http:\/\/youtu.be\/LBYJbR-3RVM?a",
      "display_url" : "youtu.be\/LBYJbR-3RVM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "294459537275105281",
  "text" : "I liked a @YouTube video http:\/\/t.co\/XuTxUIQT Shalom Aleichem",
  "id" : 294459537275105281,
  "created_at" : "2013-01-24 14:59:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/zMM5o2hp",
      "expanded_url" : "http:\/\/youtu.be\/-MBgACM_LcE?a",
      "display_url" : "youtu.be\/-MBgACM_LcE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "294458025052348416",
  "text" : "I liked a @YouTube video http:\/\/t.co\/zMM5o2hp Shabbat Shalom with lyrics ( Medley by Jonathan Settel )",
  "id" : 294458025052348416,
  "created_at" : "2013-01-24 14:53:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/h3OLQIDP",
      "expanded_url" : "http:\/\/youtu.be\/bdJ0mVqQUjU?a",
      "display_url" : "youtu.be\/bdJ0mVqQUjU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293941815286054912",
  "text" : "that girl is right for standing up for herself, God bless that dear child (@YouTube http:\/\/t.co\/h3OLQIDP)",
  "id" : 293941815286054912,
  "created_at" : "2013-01-23 04:42:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/4XmWxp6p",
      "expanded_url" : "http:\/\/youtu.be\/7WoIt3SXlUY?a",
      "display_url" : "youtu.be\/7WoIt3SXlUY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481660253618176",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/4XmWxp6p I will be singing my song of praise tonight",
  "id" : 293481660253618176,
  "created_at" : "2013-01-21 22:14:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/8EJvBsc2",
      "expanded_url" : "http:\/\/youtu.be\/yssprWWmRvk?a",
      "display_url" : "youtu.be\/yssprWWmRvk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481658995318785",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/8EJvBsc2 My Song",
  "id" : 293481658995318785,
  "created_at" : "2013-01-21 22:14:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/f2MbWwsH",
      "expanded_url" : "http:\/\/youtu.be\/oqb0b4ani2Y?a",
      "display_url" : "youtu.be\/oqb0b4ani2Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481544247566338",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/f2MbWwsH Do You See What I See (Christmas Song)",
  "id" : 293481544247566338,
  "created_at" : "2013-01-21 22:13:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/XGcHvzg4",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481460747362305",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/XGcHvzg4 Undeniable Proof that Obama is the AntiChrist",
  "id" : 293481460747362305,
  "created_at" : "2013-01-21 22:13:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/IpsKpd79",
      "expanded_url" : "http:\/\/youtu.be\/rnMwrUQade8?a",
      "display_url" : "youtu.be\/rnMwrUQade8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481461951102976",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/IpsKpd79 Miracle: A Face Sponataneously Appears next to the Image of God",
  "id" : 293481461951102976,
  "created_at" : "2013-01-21 22:13:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/wapaLCUV",
      "expanded_url" : "http:\/\/youtu.be\/9oKk71cwCFQ?a",
      "display_url" : "youtu.be\/9oKk71cwCFQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481442858651650",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/wapaLCUV My Chat With Zendaya about the Coptic Orphans Program",
  "id" : 293481442858651650,
  "created_at" : "2013-01-21 22:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/moOQMaF1",
      "expanded_url" : "http:\/\/youtu.be\/OGfVsHG1Tow?a",
      "display_url" : "youtu.be\/OGfVsHG1Tow?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481445207457793",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/moOQMaF1 Yirat Adonai",
  "id" : 293481445207457793,
  "created_at" : "2013-01-21 22:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/WL8cuvXL",
      "expanded_url" : "http:\/\/youtu.be\/G8kwmuu5Q5M?a",
      "display_url" : "youtu.be\/G8kwmuu5Q5M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481091644411904",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/WL8cuvXL REMORSE FOR AN UNCLE",
  "id" : 293481091644411904,
  "created_at" : "2013-01-21 22:11:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/nxAMD8Cn",
      "expanded_url" : "http:\/\/youtu.be\/mdS0ZIn7ssw?a",
      "display_url" : "youtu.be\/mdS0ZIn7ssw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481019103920129",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/nxAMD8Cn Obama 666 Mark of the Beast Implantation Law",
  "id" : 293481019103920129,
  "created_at" : "2013-01-21 22:11:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/qMGTOtSi",
      "expanded_url" : "http:\/\/youtu.be\/1fWKeWrtmTk?a",
      "display_url" : "youtu.be\/1fWKeWrtmTk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293481020328656896",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/qMGTOtSi Christian Songs",
  "id" : 293481020328656896,
  "created_at" : "2013-01-21 22:11:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/e1VjAXiy",
      "expanded_url" : "http:\/\/youtu.be\/4328q73rElE?a",
      "display_url" : "youtu.be\/4328q73rElE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293480989987053568",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/e1VjAXiy Is Sandy Hooks, Sandy Hoax????",
  "id" : 293480989987053568,
  "created_at" : "2013-01-21 22:11:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/9XMoglvK",
      "expanded_url" : "http:\/\/youtu.be\/QumkZHv7kNQ?a",
      "display_url" : "youtu.be\/QumkZHv7kNQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293480991236972545",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/9XMoglvK William Wagener's Presentation on \"Name of Antichrist\"",
  "id" : 293480991236972545,
  "created_at" : "2013-01-21 22:11:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/mVNsxB8Y",
      "expanded_url" : "http:\/\/youtu.be\/YY5DQY-XoWM?a",
      "display_url" : "youtu.be\/YY5DQY-XoWM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293480960941518849",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/mVNsxB8Y Beauty of the Modern Coptic Cross",
  "id" : 293480960941518849,
  "created_at" : "2013-01-21 22:11:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/lU5nl3P2",
      "expanded_url" : "http:\/\/youtu.be\/XbC06w3okdc?a",
      "display_url" : "youtu.be\/XbC06w3okdc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293456998849208320",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/lU5nl3P2 Andrew Magdy Kamal Featured on Entrepreneur TV",
  "id" : 293456998849208320,
  "created_at" : "2013-01-21 20:36:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/yMbl8mRM",
      "expanded_url" : "http:\/\/youtu.be\/TGRwvdlgWz8?a",
      "display_url" : "youtu.be\/TGRwvdlgWz8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293432344537333760",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/yMbl8mRM A quick 30 seconds to thank Andrew Magdy Kamal",
  "id" : 293432344537333760,
  "created_at" : "2013-01-21 18:58:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/yMbl8mRM",
      "expanded_url" : "http:\/\/youtu.be\/TGRwvdlgWz8?a",
      "display_url" : "youtu.be\/TGRwvdlgWz8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293432281635360768",
  "text" : "I liked a @YouTube video http:\/\/t.co\/yMbl8mRM A quick 30 seconds to thank Andrew Magdy Kamal",
  "id" : 293432281635360768,
  "created_at" : "2013-01-21 18:58:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/LrEO5Ua5",
      "expanded_url" : "http:\/\/youtu.be\/lQW79EMf304?a",
      "display_url" : "youtu.be\/lQW79EMf304?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293410145562660865",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/LrEO5Ua5 January 21st, 2013 Hebrew Calander",
  "id" : 293410145562660865,
  "created_at" : "2013-01-21 17:30:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/LrEO5Ua5",
      "expanded_url" : "http:\/\/youtu.be\/lQW79EMf304?a",
      "display_url" : "youtu.be\/lQW79EMf304?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293410119138557952",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/LrEO5Ua5 January 21st, 2013 Hebrew Calander",
  "id" : 293410119138557952,
  "created_at" : "2013-01-21 17:29:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/nxAMD8Cn",
      "expanded_url" : "http:\/\/youtu.be\/mdS0ZIn7ssw?a",
      "display_url" : "youtu.be\/mdS0ZIn7ssw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293218018421526528",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/nxAMD8Cn Obama 666 Mark of the Beast Implantation Law",
  "id" : 293218018421526528,
  "created_at" : "2013-01-21 04:46:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/kvsemBfI",
      "expanded_url" : "http:\/\/youtu.be\/fzcVfX3Pogw?a",
      "display_url" : "youtu.be\/fzcVfX3Pogw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293141190012968960",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/kvsemBfI Youngest Professor",
  "id" : 293141190012968960,
  "created_at" : "2013-01-20 23:41:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/wcyX0rr5",
      "expanded_url" : "http:\/\/youtu.be\/8pWWtL9GDXY?a",
      "display_url" : "youtu.be\/8pWWtL9GDXY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293042595091849216",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/wcyX0rr5 Lumosity Brain Grade Results",
  "id" : 293042595091849216,
  "created_at" : "2013-01-20 17:09:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/XCWyU22Z",
      "expanded_url" : "http:\/\/youtu.be\/mgAWoGzUW1A?a",
      "display_url" : "youtu.be\/mgAWoGzUW1A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293036037305933824",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/XCWyU22Z The LLERRAH Genius Quiz",
  "id" : 293036037305933824,
  "created_at" : "2013-01-20 16:43:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/CKkjOhrC",
      "expanded_url" : "http:\/\/youtu.be\/N-IT-Sk3mvg?a",
      "display_url" : "youtu.be\/N-IT-Sk3mvg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "293033507167559681",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/CKkjOhrC Other Measurements of my IQ",
  "id" : 293033507167559681,
  "created_at" : "2013-01-20 16:33:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ibLjREz4",
      "expanded_url" : "http:\/\/youtu.be\/xjm0y9ULs5s?a",
      "display_url" : "youtu.be\/xjm0y9ULs5s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292798182524592129",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ibLjREz4 Cerebrals IAW IQ SCORE=232",
  "id" : 292798182524592129,
  "created_at" : "2013-01-20 00:58:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/ZlawWCko",
      "expanded_url" : "http:\/\/youtu.be\/m705Gsth7kg?a",
      "display_url" : "youtu.be\/m705Gsth7kg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292743127977037824",
  "text" : "My new desk: http:\/\/t.co\/ZlawWCko via @YouTube",
  "id" : 292743127977037824,
  "created_at" : "2013-01-19 21:19:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/flmZ3IkS",
      "expanded_url" : "http:\/\/youtu.be\/W1l47vG2j8c?a",
      "display_url" : "youtu.be\/W1l47vG2j8c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292698162517405696",
  "text" : "Day 1 of Racquet Ball training: http:\/\/t.co\/flmZ3IkS via @YouTube",
  "id" : 292698162517405696,
  "created_at" : "2013-01-19 18:20:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/H8ho16lG",
      "expanded_url" : "http:\/\/youtu.be\/2OqWJ2dY1Z8?a",
      "display_url" : "youtu.be\/2OqWJ2dY1Z8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292681256553041921",
  "text" : "4 New Additions to my Collection: http:\/\/t.co\/H8ho16lG via @YouTube",
  "id" : 292681256553041921,
  "created_at" : "2013-01-19 17:13:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/b9bwc2nI",
      "expanded_url" : "http:\/\/youtu.be\/oDn7PqhYB98?a",
      "display_url" : "youtu.be\/oDn7PqhYB98?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292482988686602241",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/b9bwc2nI My New Flexi Tail Skin",
  "id" : 292482988686602241,
  "created_at" : "2013-01-19 04:05:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/b9bwc2nI",
      "expanded_url" : "http:\/\/youtu.be\/oDn7PqhYB98?a",
      "display_url" : "youtu.be\/oDn7PqhYB98?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292475566236508161",
  "text" : "My New Flexi Tail Skin: http:\/\/t.co\/b9bwc2nI via @YouTube",
  "id" : 292475566236508161,
  "created_at" : "2013-01-19 03:36:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/psetlI9i",
      "expanded_url" : "http:\/\/youtu.be\/z5BmkRBuNzI?a",
      "display_url" : "youtu.be\/z5BmkRBuNzI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292420229697519618",
  "text" : "Just Practiced B-Ball: http:\/\/t.co\/psetlI9i via @YouTube",
  "id" : 292420229697519618,
  "created_at" : "2013-01-18 23:56:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 46, 54 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/HEJkfjx0",
      "expanded_url" : "http:\/\/youtu.be\/I6nK64GX4a0?a",
      "display_url" : "youtu.be\/I6nK64GX4a0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292371602308489216",
  "text" : "Flying balloon fail: http:\/\/t.co\/HEJkfjx0 via @YouTube",
  "id" : 292371602308489216,
  "created_at" : "2013-01-18 20:43:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/t2QyubOa",
      "expanded_url" : "http:\/\/youtu.be\/Jm__oet88N8?a",
      "display_url" : "youtu.be\/Jm__oet88N8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292359432820625408",
  "text" : "My cross tattoo: http:\/\/t.co\/t2QyubOa via @YouTube",
  "id" : 292359432820625408,
  "created_at" : "2013-01-18 19:54:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/cirF4Ndh",
      "expanded_url" : "http:\/\/youtu.be\/EpeD3u-FDQ4?a",
      "display_url" : "youtu.be\/EpeD3u-FDQ4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292305719393406976",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/cirF4Ndh A Math Problem for a Genius",
  "id" : 292305719393406976,
  "created_at" : "2013-01-18 16:21:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/E4kpjLfA",
      "expanded_url" : "http:\/\/youtu.be\/NOhwVgGMmQc?a",
      "display_url" : "youtu.be\/NOhwVgGMmQc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292295155871006720",
  "text" : "only up to two codes per person@flame7766 (@YouTube http:\/\/t.co\/E4kpjLfA)",
  "id" : 292295155871006720,
  "created_at" : "2013-01-18 15:39:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 25, 33 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/E4kpjLfA",
      "expanded_url" : "http:\/\/youtu.be\/NOhwVgGMmQc?a",
      "display_url" : "youtu.be\/NOhwVgGMmQc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292295077928251392",
  "text" : "557 872 6238 @flame7766 (@YouTube http:\/\/t.co\/E4kpjLfA)",
  "id" : 292295077928251392,
  "created_at" : "2013-01-18 15:39:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 25, 33 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/E4kpjLfA",
      "expanded_url" : "http:\/\/youtu.be\/NOhwVgGMmQc?a",
      "display_url" : "youtu.be\/NOhwVgGMmQc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292294691339255808",
  "text" : "562 628 9173 @flame7766 (@YouTube http:\/\/t.co\/E4kpjLfA)",
  "id" : 292294691339255808,
  "created_at" : "2013-01-18 15:37:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/uYBYU9Q9",
      "expanded_url" : "http:\/\/youtu.be\/JgTeXXuijFI?a",
      "display_url" : "youtu.be\/JgTeXXuijFI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292078827310563328",
  "text" : "Using Nautrius Climber Fir a Second Time: http:\/\/t.co\/uYBYU9Q9 via @YouTube",
  "id" : 292078827310563328,
  "created_at" : "2013-01-18 01:19:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ifERacfl",
      "expanded_url" : "http:\/\/youtu.be\/LPrYaWJvHX4?a",
      "display_url" : "youtu.be\/LPrYaWJvHX4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292061600121249792",
  "text" : "Technogym at lifestyle fitness part 2: http:\/\/t.co\/ifERacfl via @YouTube",
  "id" : 292061600121249792,
  "created_at" : "2013-01-18 00:11:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/B1FDdbnV",
      "expanded_url" : "http:\/\/youtu.be\/02pJmWR-Pw8?a",
      "display_url" : "youtu.be\/02pJmWR-Pw8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292061589597745153",
  "text" : "Technogym at lifestyle fitness part 1: http:\/\/t.co\/B1FDdbnV via @YouTube",
  "id" : 292061589597745153,
  "created_at" : "2013-01-18 00:11:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/fwBCHYZ5",
      "expanded_url" : "http:\/\/youtu.be\/XdEoeLYT_QM?a",
      "display_url" : "youtu.be\/XdEoeLYT_QM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292039917117251584",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/fwBCHYZ5 Sequences for a Genius",
  "id" : 292039917117251584,
  "created_at" : "2013-01-17 22:45:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Wmf1Urkb",
      "expanded_url" : "http:\/\/youtu.be\/xMBU7rDyRi8?a",
      "display_url" : "youtu.be\/xMBU7rDyRi8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "292032685021478914",
  "text" : "Signed Warriors comic book added to my collection: http:\/\/t.co\/Wmf1Urkb via @YouTube",
  "id" : 292032685021478914,
  "created_at" : "2013-01-17 22:16:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/nvnGynXc",
      "expanded_url" : "http:\/\/youtu.be\/-Y9n5_EAivg?a",
      "display_url" : "youtu.be\/-Y9n5_EAivg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "291885015447515136",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/nvnGynXc P vs. NP Abstract Presentation",
  "id" : 291885015447515136,
  "created_at" : "2013-01-17 12:29:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/q7tkosAQ",
      "expanded_url" : "http:\/\/youtu.be\/OEPHmd4zYNE?a",
      "display_url" : "youtu.be\/OEPHmd4zYNE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "291743623106686977",
  "text" : "Just joined lifetime fitness today: http:\/\/t.co\/q7tkosAQ via @YouTube",
  "id" : 291743623106686977,
  "created_at" : "2013-01-17 03:07:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/CFDE1F00",
      "expanded_url" : "http:\/\/youtu.be\/oCHNo_gYA4E?a",
      "display_url" : "youtu.be\/oCHNo_gYA4E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "291009221011574784",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/CFDE1F00 Cerebrals Society IAW (Answers 1-20)",
  "id" : 291009221011574784,
  "created_at" : "2013-01-15 02:29:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/guQVSHLq",
      "expanded_url" : "http:\/\/youtu.be\/OUgR9OJ_IpA?a",
      "display_url" : "youtu.be\/OUgR9OJ_IpA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "291008047717945346",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/guQVSHLq bandicam 2013 01 14 21 17 28 136",
  "id" : 291008047717945346,
  "created_at" : "2013-01-15 02:24:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/otvUpCyv",
      "expanded_url" : "http:\/\/youtu.be\/DOjeXgqC1JE?a",
      "display_url" : "youtu.be\/DOjeXgqC1JE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "291007131304460289",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/otvUpCyv bandicam 2013 01 14 21 17 28 136",
  "id" : 291007131304460289,
  "created_at" : "2013-01-15 02:21:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/oFhlV8oD",
      "expanded_url" : "http:\/\/youtu.be\/la2daJXOeak?a",
      "display_url" : "youtu.be\/la2daJXOeak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290990920566980608",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/oFhlV8oD Holoptics Atari-Cosmos Inspired IPhone Case",
  "id" : 290990920566980608,
  "created_at" : "2013-01-15 01:16:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/z8CPHDX7",
      "expanded_url" : "http:\/\/youtu.be\/lOT58_L_28w?a",
      "display_url" : "youtu.be\/lOT58_L_28w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290677171729620992",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/z8CPHDX7 My game console design",
  "id" : 290677171729620992,
  "created_at" : "2013-01-14 04:30:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/odCdowZw",
      "expanded_url" : "http:\/\/youtu.be\/VsK1C-BWYhI?a",
      "display_url" : "youtu.be\/VsK1C-BWYhI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290676094904967170",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/odCdowZw Design Idea of Hologram Projecting MP3",
  "id" : 290676094904967170,
  "created_at" : "2013-01-14 04:25:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/TCZC8Qsq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fzcVfX3Pogw&sns=tw",
      "display_url" : "youtube.com\/watch?v=fzcVfX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290543444856807425",
  "text" : "Youngest Professor http:\/\/t.co\/TCZC8Qsq via @youtube",
  "id" : 290543444856807425,
  "created_at" : "2013-01-13 19:38:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 37, 45 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/LsI9NINA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gBosM_hWtFs&sns=tw",
      "display_url" : "youtube.com\/watch?v=gBosM_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290525635930099712",
  "text" : "my audition http:\/\/t.co\/LsI9NINA via @youtube",
  "id" : 290525635930099712,
  "created_at" : "2013-01-13 18:28:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci-Fi MonStar",
      "screen_name" : "FantasySci",
      "indices" : [ 0, 11 ],
      "id_str" : "503786103",
      "id" : 503786103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "290466564300496896",
  "in_reply_to_user_id" : 503786103,
  "text" : "@FantasySci check out http:\/\/t.co\/YMSYvz7h",
  "id" : 290466564300496896,
  "created_at" : "2013-01-13 14:33:20 +0000",
  "in_reply_to_screen_name" : "FantasySci",
  "in_reply_to_user_id_str" : "503786103",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nasir Germain",
      "screen_name" : "NasirGermain",
      "indices" : [ 33, 46 ],
      "id_str" : "2546646350",
      "id" : 2546646350
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/lU5nl3P2",
      "expanded_url" : "http:\/\/youtu.be\/XbC06w3okdc?a",
      "display_url" : "youtu.be\/XbC06w3okdc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290341450888126464",
  "text" : "your not nasir, your his brother @nasirgermain (@YouTube http:\/\/t.co\/lU5nl3P2)",
  "id" : 290341450888126464,
  "created_at" : "2013-01-13 06:16:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/K9qXl6D5",
      "expanded_url" : "http:\/\/youtu.be\/IxaJ8n6N7S4?a",
      "display_url" : "youtu.be\/IxaJ8n6N7S4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290339463945666560",
  "text" : "i never bully anyone (@YouTube http:\/\/t.co\/K9qXl6D5)",
  "id" : 290339463945666560,
  "created_at" : "2013-01-13 06:08:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 87, 95 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/K9qXl6D5",
      "expanded_url" : "http:\/\/youtu.be\/IxaJ8n6N7S4?a",
      "display_url" : "youtu.be\/IxaJ8n6N7S4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290338657980788736",
  "text" : "I have a PhD and Professirial so why did you insult my videos and dislike all of them (@YouTube http:\/\/t.co\/K9qXl6D5)",
  "id" : 290338657980788736,
  "created_at" : "2013-01-13 06:05:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/K9qXl6D5",
      "expanded_url" : "http:\/\/youtu.be\/IxaJ8n6N7S4?a",
      "display_url" : "youtu.be\/IxaJ8n6N7S4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290335931892920320",
  "text" : "my iq average os is 231.734 and I won over 94 awards in physics aloje, so how are you smarter (@YouTube http:\/\/t.co\/K9qXl6D5)",
  "id" : 290335931892920320,
  "created_at" : "2013-01-13 05:54:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/e1VjAXiy",
      "expanded_url" : "http:\/\/youtu.be\/4328q73rElE?a",
      "display_url" : "youtu.be\/4328q73rElE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290303379777937408",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/e1VjAXiy Is Sandy Hooks, Sandy Hoax????",
  "id" : 290303379777937408,
  "created_at" : "2013-01-13 03:44:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/e1VjAXiy",
      "expanded_url" : "http:\/\/youtu.be\/4328q73rElE?a",
      "display_url" : "youtu.be\/4328q73rElE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290303355417419776",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/e1VjAXiy Is Sandy Hooks, Sandy Hoax????",
  "id" : 290303355417419776,
  "created_at" : "2013-01-13 03:44:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/PHpLCpot",
      "expanded_url" : "http:\/\/youtu.be\/H5IGqHeQDgg?a",
      "display_url" : "youtu.be\/H5IGqHeQDgg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290276917498748928",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/PHpLCpot Answer to the \"Genius\" Puzzle",
  "id" : 290276917498748928,
  "created_at" : "2013-01-13 01:59:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/kvsemBfI",
      "expanded_url" : "http:\/\/youtu.be\/fzcVfX3Pogw?a",
      "display_url" : "youtu.be\/fzcVfX3Pogw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273566711230464",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/kvsemBfI Youngest Professor",
  "id" : 290273566711230464,
  "created_at" : "2013-01-13 01:46:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/bNPAjavV",
      "expanded_url" : "http:\/\/youtu.be\/gNlaPigzIoQ?a",
      "display_url" : "youtu.be\/gNlaPigzIoQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273439221182464",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/bNPAjavV My World Record for Highest IQ Average Anounced Next to Historical",
  "id" : 290273439221182464,
  "created_at" : "2013-01-13 01:45:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/6jhKJcFa",
      "expanded_url" : "http:\/\/youtu.be\/I_ugwVveTk4?a",
      "display_url" : "youtu.be\/I_ugwVveTk4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273413174538240",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6jhKJcFa \"Skinny by Tara\" Reviewing my World Record!!!",
  "id" : 290273413174538240,
  "created_at" : "2013-01-13 01:45:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/lU5nl3P2",
      "expanded_url" : "http:\/\/youtu.be\/XbC06w3okdc?a",
      "display_url" : "youtu.be\/XbC06w3okdc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273414860644353",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/lU5nl3P2 Andrew Magdy Kamal Featured on Entrepreneur TV",
  "id" : 290273414860644353,
  "created_at" : "2013-01-13 01:45:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/L7f94f0e",
      "expanded_url" : "http:\/\/youtu.be\/zo44YUiOL4I?a",
      "display_url" : "youtu.be\/zo44YUiOL4I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273292210810880",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/L7f94f0e SakaProductions News Announcement for ME",
  "id" : 290273292210810880,
  "created_at" : "2013-01-13 01:45:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/J9k815t6",
      "expanded_url" : "http:\/\/youtu.be\/sA79VVxnkaQ?a",
      "display_url" : "youtu.be\/sA79VVxnkaQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273288813436929",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/J9k815t6 VOICEMAIL OF RHR Celebrating My World Record For Highest IQ",
  "id" : 290273288813436929,
  "created_at" : "2013-01-13 01:45:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/Y9PZRBSj",
      "expanded_url" : "http:\/\/youtu.be\/kvQrZw2CdpU?a",
      "display_url" : "youtu.be\/kvQrZw2CdpU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273177328816128",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Y9PZRBSj ORB IQ Test Solution",
  "id" : 290273177328816128,
  "created_at" : "2013-01-13 01:44:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/gcE7bej9",
      "expanded_url" : "http:\/\/youtu.be\/htR13s3W65w?a",
      "display_url" : "youtu.be\/htR13s3W65w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290273037486530561",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/gcE7bej9 Scenario IQ Game and Mind Trainer Video Game High Score",
  "id" : 290273037486530561,
  "created_at" : "2013-01-13 01:44:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/jH4uNe1C",
      "expanded_url" : "http:\/\/youtu.be\/rg6x8BLg2g0?a",
      "display_url" : "youtu.be\/rg6x8BLg2g0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290272833328779264",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/jH4uNe1C A Few Logic Questions",
  "id" : 290272833328779264,
  "created_at" : "2013-01-13 01:43:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/UZWFoIXE",
      "expanded_url" : "http:\/\/youtu.be\/KsYRgsJQAaE?a",
      "display_url" : "youtu.be\/KsYRgsJQAaE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290260407971639296",
  "text" : "great showing of intellectual abilities :\/ (@YouTube http:\/\/t.co\/UZWFoIXE)",
  "id" : 290260407971639296,
  "created_at" : "2013-01-13 00:54:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/lU5nl3P2",
      "expanded_url" : "http:\/\/youtu.be\/XbC06w3okdc?a",
      "display_url" : "youtu.be\/XbC06w3okdc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "290249640492814336",
  "text" : "If I disgust you then you wouldnt even have tooken time to say tharmt, but if it is an (@YouTube http:\/\/t.co\/lU5nl3P2)",
  "id" : 290249640492814336,
  "created_at" : "2013-01-13 00:11:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290211047644741632",
  "text" : "Their is such a lonely life to that of a genius",
  "id" : 290211047644741632,
  "created_at" : "2013-01-12 21:38:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/5Gxk7Xpz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=L6HHxVZMU3k&sns=tw",
      "display_url" : "youtube.com\/watch?v=L6HHxV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290176092751409152",
  "text" : "Redesigning the De Vinci Flying Machine http:\/\/t.co\/5Gxk7Xpz via @youtube",
  "id" : 290176092751409152,
  "created_at" : "2013-01-12 19:19:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/O71ny6Q4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ST612P_YJDQ&sns=tw",
      "display_url" : "youtube.com\/watch?v=ST612P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290175716597825536",
  "text" : "The best turkey bacon sandwich ever http:\/\/t.co\/O71ny6Q4 via @youtube",
  "id" : 290175716597825536,
  "created_at" : "2013-01-12 19:17:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/sbQ2h4h8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=YY5DQY-XoWM&sns=tw",
      "display_url" : "youtube.com\/watch?v=YY5DQY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290174689991618561",
  "text" : "Beauty of the Modern Coptic Cross http:\/\/t.co\/sbQ2h4h8 via @youtube",
  "id" : 290174689991618561,
  "created_at" : "2013-01-12 19:13:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 47, 55 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/aBZfzl1M",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kvQrZw2CdpU&sns=tw",
      "display_url" : "youtube.com\/watch?v=kvQrZw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290174097856536576",
  "text" : "ORB  IQ Test Solution http:\/\/t.co\/aBZfzl1M via @youtube",
  "id" : 290174097856536576,
  "created_at" : "2013-01-12 19:11:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 55, 63 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/naIEgwkz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=H5IGqHeQDgg&sns=tw",
      "display_url" : "youtube.com\/watch?v=H5IGqH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290173560528465920",
  "text" : "Answer to the \"Genius\" Puzzle http:\/\/t.co\/naIEgwkz via @youtube",
  "id" : 290173560528465920,
  "created_at" : "2013-01-12 19:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/mTzSk6YD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=E7nNdWSnF80&sns=tw",
      "display_url" : "youtube.com\/watch?v=E7nNdW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290172547734073345",
  "text" : "My Sponsorships http:\/\/t.co\/mTzSk6YD via @youtube",
  "id" : 290172547734073345,
  "created_at" : "2013-01-12 19:05:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/nZNVE6I9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1fWKeWrtmTk&sns=tw",
      "display_url" : "youtube.com\/watch?v=1fWKeW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290172457195827200",
  "text" : "Christian Songs http:\/\/t.co\/nZNVE6I9 via @youtube",
  "id" : 290172457195827200,
  "created_at" : "2013-01-12 19:04:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 46, 54 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/RhYGSUXa",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mjV6GtiyF9g&sns=tw",
      "display_url" : "youtube.com\/watch?v=mjV6Gt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290172260491341824",
  "text" : "The Superhero Effect http:\/\/t.co\/RhYGSUXa via @youtube",
  "id" : 290172260491341824,
  "created_at" : "2013-01-12 19:03:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/hWvh3HXS",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lXJFHtmS2LU&sns=tw",
      "display_url" : "youtube.com\/watch?v=lXJFHt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290171965568847872",
  "text" : "FHB Galaxies (As Seen on the Discovery Channel) http:\/\/t.co\/hWvh3HXS via @youtube",
  "id" : 290171965568847872,
  "created_at" : "2013-01-12 19:02:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/OGIS6qvX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mdS0ZIn7ssw&sns=tw",
      "display_url" : "youtube.com\/watch?v=mdS0ZI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290171880948764672",
  "text" : "Obama 666 Mark of the Beast Implantation Law http:\/\/t.co\/OGIS6qvX via @youtube",
  "id" : 290171880948764672,
  "created_at" : "2013-01-12 19:02:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TdHTKyyJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6fl9_P2Oz7Q&sns=tw",
      "display_url" : "youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290171799474429953",
  "text" : "Crevolution 2851 - Cerberus 2010 - Drive system http:\/\/t.co\/TdHTKyyJ via @youtube",
  "id" : 290171799474429953,
  "created_at" : "2013-01-12 19:02:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 36, 44 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/gkriShqz",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=313uecy8-Gk&sns=tw",
      "display_url" : "youtube.com\/watch?v=313uec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289952055139901440",
  "text" : "Inventions http:\/\/t.co\/gkriShqz via @youtube",
  "id" : 289952055139901440,
  "created_at" : "2013-01-12 04:28:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 53, 61 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/JhBKJB4j",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=aebm5O5mFoo&sns=tw",
      "display_url" : "youtube.com\/watch?v=aebm5O\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289950848639975424",
  "text" : "A Message for Rush Limbaugh http:\/\/t.co\/JhBKJB4j via @youtube",
  "id" : 289950848639975424,
  "created_at" : "2013-01-12 04:24:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/wTGn0E3P",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=XCO7FoxlPIQ&sns=tw",
      "display_url" : "youtube.com\/watch?v=XCO7Fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289950464072617984",
  "text" : "BOINC Projects (Latest) http:\/\/t.co\/wTGn0E3P via @youtube",
  "id" : 289950464072617984,
  "created_at" : "2013-01-12 04:22:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/oE9WiKng",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=D_FKOJFiUXc&sns=tw",
      "display_url" : "youtube.com\/watch?v=D_FKOJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289943837550452736",
  "text" : "Google Science Project http:\/\/t.co\/oE9WiKng via @youtube",
  "id" : 289943837550452736,
  "created_at" : "2013-01-12 03:56:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/sbQ2h4h8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=YY5DQY-XoWM&sns=tw",
      "display_url" : "youtube.com\/watch?v=YY5DQY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289925063866720257",
  "text" : "Beauty of the Modern Coptic Cross so elegant http:\/\/t.co\/sbQ2h4h8 via @youtube",
  "id" : 289925063866720257,
  "created_at" : "2013-01-12 02:41:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/6to3lVGL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5NsHn6v2B7U&sns=tw",
      "display_url" : "youtube.com\/watch?v=5NsHn6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289917455311175680",
  "text" : "RC Vehicle Attachment (Design Concept) cool http:\/\/t.co\/6to3lVGL via @youtube",
  "id" : 289917455311175680,
  "created_at" : "2013-01-12 02:11:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/s6h8FxWX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=etD-CiP3hPA&sns=tw",
      "display_url" : "youtube.com\/watch?v=etD-Ci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289899858020679681",
  "text" : "August 30th, 1983 KSC launch Commemorative Coin http:\/\/t.co\/s6h8FxWX via @youtube",
  "id" : 289899858020679681,
  "created_at" : "2013-01-12 01:01:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289899306335485952",
  "text" : "Join AndSocialREW",
  "id" : 289899306335485952,
  "created_at" : "2013-01-12 00:59:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/0mwbZG29",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=QumkZHv7kNQ&sns=tw",
      "display_url" : "youtube.com\/watch?v=QumkZH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289899175968129024",
  "text" : "William Wagener's Presentation on \"Name of Antichrist\" http:\/\/t.co\/0mwbZG29 via @youtube",
  "id" : 289899175968129024,
  "created_at" : "2013-01-12 00:58:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 0, 8 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289898689005223936",
  "in_reply_to_user_id" : 10228272,
  "text" : "@YouTube go to http:\/\/t.co\/YMSYvz7h",
  "id" : 289898689005223936,
  "created_at" : "2013-01-12 00:56:48 +0000",
  "in_reply_to_screen_name" : "YouTube",
  "in_reply_to_user_id_str" : "10228272",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/sbQ2h4h8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=YY5DQY-XoWM&sns=tw",
      "display_url" : "youtube.com\/watch?v=YY5DQY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289898446377349120",
  "text" : "Beauty of the Modern Coptic Cross http:\/\/t.co\/sbQ2h4h8 via @youtube",
  "id" : 289898446377349120,
  "created_at" : "2013-01-12 00:55:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/fwYO8gA2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hkagNjXzaHE&sns=tw",
      "display_url" : "youtube.com\/watch?v=hkagNj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289898316093878272",
  "text" : "One of my Most Elegant Watches http:\/\/t.co\/fwYO8gA2 via @youtube",
  "id" : 289898316093878272,
  "created_at" : "2013-01-12 00:55:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/pBU8p4lL",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=zMp-oy6KLjc",
      "display_url" : "m.youtube.com\/#\/watch?v=zMp-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289896345664372736",
  "text" : "http:\/\/t.co\/pBU8p4lL\nwatch this",
  "id" : 289896345664372736,
  "created_at" : "2013-01-12 00:47:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TdHTKyyJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6fl9_P2Oz7Q&sns=tw",
      "display_url" : "youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289887201989361665",
  "text" : "Crevolution 2851 - Cerberus 2010 - Drive system http:\/\/t.co\/TdHTKyyJ via @youtube Awsome",
  "id" : 289887201989361665,
  "created_at" : "2013-01-12 00:11:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/6to3lVGL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5NsHn6v2B7U&sns=tw",
      "display_url" : "youtube.com\/watch?v=5NsHn6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289886641609383938",
  "text" : "RC Vehicle Attachment (Design Concept) http:\/\/t.co\/6to3lVGL via @youtube",
  "id" : 289886641609383938,
  "created_at" : "2013-01-12 00:08:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/aMq5t832",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=76pTLHymYPY&sns=tw",
      "display_url" : "youtube.com\/watch?v=76pTLH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289886538458886146",
  "text" : "The Story About My First Chess Trophies in 2004 http:\/\/t.co\/aMq5t832 via @youtube",
  "id" : 289886538458886146,
  "created_at" : "2013-01-12 00:08:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 37, 45 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/LsI9NINA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gBosM_hWtFs&sns=tw",
      "display_url" : "youtube.com\/watch?v=gBosM_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289886400650829824",
  "text" : "my audition http:\/\/t.co\/LsI9NINA via @youtube",
  "id" : 289886400650829824,
  "created_at" : "2013-01-12 00:07:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/mTzSk6YD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=E7nNdWSnF80&sns=tw",
      "display_url" : "youtube.com\/watch?v=E7nNdW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289886104621031424",
  "text" : "My Sponsorships http:\/\/t.co\/mTzSk6YD via @youtube",
  "id" : 289886104621031424,
  "created_at" : "2013-01-12 00:06:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 73, 81 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/TdHTKyyJ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6fl9_P2Oz7Q&sns=tw",
      "display_url" : "youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289885772146946049",
  "text" : "Crevolution 2851 - Cerberus 2010 - Drive system http:\/\/t.co\/TdHTKyyJ via @youtube",
  "id" : 289885772146946049,
  "created_at" : "2013-01-12 00:05:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/dDBciB3Z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zMp-oy6KLjc&sns=tw",
      "display_url" : "youtube.com\/watch?v=zMp-oy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289885645046943744",
  "text" : "\"The Unseen Part of Forest Gump\" http:\/\/t.co\/dDBciB3Z via @youtube",
  "id" : 289885645046943744,
  "created_at" : "2013-01-12 00:04:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uCC3D\uACBD\uD3EC\uB7FC [\uB274\uC2A4\uD50C\uB7AB\uD3FC]",
      "screen_name" : "smbaforum",
      "indices" : [ 0, 10 ],
      "id_str" : "156556003",
      "id" : 156556003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/CE4MmLJU",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=6fl9_P2Oz7Q&feature=m-ch-fea",
      "display_url" : "m.youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289885219954257920",
  "in_reply_to_user_id" : 156556003,
  "text" : "@smbaforum http:\/\/t.co\/CE4MmLJU",
  "id" : 289885219954257920,
  "created_at" : "2013-01-12 00:03:16 +0000",
  "in_reply_to_screen_name" : "smbaforum",
  "in_reply_to_user_id_str" : "156556003",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarcasm",
      "screen_name" : "TheFunnyTeens",
      "indices" : [ 0, 14 ],
      "id_str" : "66339576",
      "id" : 66339576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/CE4MmLJU",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=6fl9_P2Oz7Q&feature=m-ch-fea",
      "display_url" : "m.youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289885058800709632",
  "in_reply_to_user_id" : 66339576,
  "text" : "@TheFunnyTeens watch this at http:\/\/t.co\/CE4MmLJU",
  "id" : 289885058800709632,
  "created_at" : "2013-01-12 00:02:38 +0000",
  "in_reply_to_screen_name" : "TheFunnyTeens",
  "in_reply_to_user_id_str" : "66339576",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Trew",
      "screen_name" : "Cameron_Trew",
      "indices" : [ 0, 13 ],
      "id_str" : "352301117",
      "id" : 352301117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/CE4MmLJU",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=6fl9_P2Oz7Q&feature=m-ch-fea",
      "display_url" : "m.youtube.com\/watch?v=6fl9_P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289884771826421760",
  "in_reply_to_user_id" : 352301117,
  "text" : "@Cameron_Trew look at http:\/\/t.co\/CE4MmLJU",
  "id" : 289884771826421760,
  "created_at" : "2013-01-12 00:01:30 +0000",
  "in_reply_to_screen_name" : "Cameron_Trew",
  "in_reply_to_user_id_str" : "352301117",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 0, 5 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/ElHNHTiL",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=lXJFHtmS2LU&feature=plpp",
      "display_url" : "m.youtube.com\/#\/watch?v=lXJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289884360717520897",
  "in_reply_to_user_id" : 11348282,
  "text" : "@NASA look at http:\/\/t.co\/ElHNHTiL",
  "id" : 289884360717520897,
  "created_at" : "2013-01-11 23:59:52 +0000",
  "in_reply_to_screen_name" : "NASA",
  "in_reply_to_user_id_str" : "11348282",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 0, 14 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/ElHNHTiL",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=lXJFHtmS2LU&feature=plpp",
      "display_url" : "m.youtube.com\/#\/watch?v=lXJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289884133918912512",
  "in_reply_to_user_id" : 34892616,
  "text" : "@lorenridinger http:\/\/t.co\/ElHNHTiL",
  "id" : 289884133918912512,
  "created_at" : "2013-01-11 23:58:57 +0000",
  "in_reply_to_screen_name" : "lorenridinger",
  "in_reply_to_user_id_str" : "34892616",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/ElHNHTiL",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=lXJFHtmS2LU&feature=plpp",
      "display_url" : "m.youtube.com\/#\/watch?v=lXJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289884000246435840",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux look at this http:\/\/t.co\/ElHNHTiL",
  "id" : 289884000246435840,
  "created_at" : "2013-01-11 23:58:26 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/ElHNHTiL",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?v=lXJFHtmS2LU&feature=plpp",
      "display_url" : "m.youtube.com\/#\/watch?v=lXJF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289883784189444096",
  "text" : "http:\/\/t.co\/ElHNHTiL",
  "id" : 289883784189444096,
  "created_at" : "2013-01-11 23:57:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u044F \u041A\u043E\u0432\u0430\u043B\u0451\u043D\u043E\u043A",
      "screen_name" : "E_Stranged",
      "indices" : [ 0, 11 ],
      "id_str" : "778658030",
      "id" : 778658030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289881140339306498",
  "in_reply_to_user_id" : 25471221,
  "text" : "@E_Stranged look at http:\/\/t.co\/YMSYvz7h",
  "id" : 289881140339306498,
  "created_at" : "2013-01-11 23:47:04 +0000",
  "in_reply_to_screen_name" : "Nintelligent",
  "in_reply_to_user_id_str" : "25471221",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skylar & Jan",
      "screen_name" : "clupko",
      "indices" : [ 0, 7 ],
      "id_str" : "28507777",
      "id" : 28507777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289880653623877632",
  "in_reply_to_user_id" : 28507777,
  "text" : "@clupko check out http:\/\/t.co\/YMSYvz7h",
  "id" : 289880653623877632,
  "created_at" : "2013-01-11 23:45:08 +0000",
  "in_reply_to_screen_name" : "clupko",
  "in_reply_to_user_id_str" : "28507777",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Fouts",
      "screen_name" : "jfouts",
      "indices" : [ 0, 7 ],
      "id_str" : "11063312",
      "id" : 11063312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/ljDyCsZ5",
      "expanded_url" : "http:\/\/YouTube.com\/mrganer456148",
      "display_url" : "YouTube.com\/mrganer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289880234902290432",
  "in_reply_to_user_id" : 11063312,
  "text" : "@jfouts check http:\/\/t.co\/ljDyCsZ5",
  "id" : 289880234902290432,
  "created_at" : "2013-01-11 23:43:28 +0000",
  "in_reply_to_screen_name" : "jfouts",
  "in_reply_to_user_id_str" : "11063312",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Evans",
      "screen_name" : "JustinJumpstart",
      "indices" : [ 0, 16 ],
      "id_str" : "62087551",
      "id" : 62087551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289879961194594305",
  "in_reply_to_user_id" : 62087551,
  "text" : "@JustinJumpstart check out http:\/\/t.co\/YMSYvz7h",
  "id" : 289879961194594305,
  "created_at" : "2013-01-11 23:42:23 +0000",
  "in_reply_to_screen_name" : "JustinJumpstart",
  "in_reply_to_user_id_str" : "62087551",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/YMSYvz7h",
      "expanded_url" : "http:\/\/YouTube.com\/mrgamer456148",
      "display_url" : "YouTube.com\/mrgamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "289879557920661504",
  "text" : "Go to http:\/\/t.co\/YMSYvz7h",
  "id" : 289879557920661504,
  "created_at" : "2013-01-11 23:40:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/9XMoglvK",
      "expanded_url" : "http:\/\/youtu.be\/QumkZHv7kNQ?a",
      "display_url" : "youtu.be\/QumkZHv7kNQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "289781848345829377",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/9XMoglvK William Wagener's Presentation on \"Name of Antichrist\"",
  "id" : 289781848345829377,
  "created_at" : "2013-01-11 17:12:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/rRzIiCzX",
      "expanded_url" : "http:\/\/youtu.be\/nyH6qQ8jPcw?a",
      "display_url" : "youtu.be\/nyH6qQ8jPcw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "289040000329326592",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/rRzIiCzX FHB Galaxies (As Seen on the Discovery Channel)",
  "id" : 289040000329326592,
  "created_at" : "2013-01-09 16:04:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/uJ5VP3hq",
      "expanded_url" : "http:\/\/caspiangames.net",
      "display_url" : "caspiangames.net"
    } ]
  },
  "geo" : { },
  "id_str" : "288819210891689985",
  "text" : "look at http:\/\/t.co\/uJ5VP3hq",
  "id" : 288819210891689985,
  "created_at" : "2013-01-09 01:27:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/uJ5VP3hq",
      "expanded_url" : "http:\/\/caspiangames.net",
      "display_url" : "caspiangames.net"
    } ]
  },
  "geo" : { },
  "id_str" : "288819165685501952",
  "text" : "go to http:\/\/t.co\/uJ5VP3hq",
  "id" : 288819165685501952,
  "created_at" : "2013-01-09 01:27:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/uJ5VP3hq",
      "expanded_url" : "http:\/\/caspiangames.net",
      "display_url" : "caspiangames.net"
    } ]
  },
  "geo" : { },
  "id_str" : "288818887594754049",
  "text" : "http:\/\/t.co\/uJ5VP3hq",
  "id" : 288818887594754049,
  "created_at" : "2013-01-09 01:26:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/nxAMD8Cn",
      "expanded_url" : "http:\/\/youtu.be\/mdS0ZIn7ssw?a",
      "display_url" : "youtu.be\/mdS0ZIn7ssw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288424400909377537",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/nxAMD8Cn Obama 666 Mark of the Beast Implantation Law",
  "id" : 288424400909377537,
  "created_at" : "2013-01-07 23:18:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/qam1LiAI",
      "expanded_url" : "http:\/\/youtu.be\/AaZ2DAx6fYo?a",
      "display_url" : "youtu.be\/AaZ2DAx6fYo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288403783942295552",
  "text" : "Hanukkah really is the date you provided (@YouTube http:\/\/t.co\/qam1LiAI)",
  "id" : 288403783942295552,
  "created_at" : "2013-01-07 21:56:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/qam1LiAI",
      "expanded_url" : "http:\/\/youtu.be\/AaZ2DAx6fYo?a",
      "display_url" : "youtu.be\/AaZ2DAx6fYo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288403700429492224",
  "text" : "I think I had a dream about the rapture just yesterday (@YouTube http:\/\/t.co\/qam1LiAI)",
  "id" : 288403700429492224,
  "created_at" : "2013-01-07 21:56:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/qMGTOtSi",
      "expanded_url" : "http:\/\/youtu.be\/1fWKeWrtmTk?a",
      "display_url" : "youtu.be\/1fWKeWrtmTk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288088644131115008",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/qMGTOtSi Christian Songs",
  "id" : 288088644131115008,
  "created_at" : "2013-01-07 01:04:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/qMGTOtSi",
      "expanded_url" : "http:\/\/youtu.be\/1fWKeWrtmTk?a",
      "display_url" : "youtu.be\/1fWKeWrtmTk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288088616033452033",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/qMGTOtSi Christian Songs",
  "id" : 288088616033452033,
  "created_at" : "2013-01-07 01:04:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/qMGTOtSi",
      "expanded_url" : "http:\/\/youtu.be\/1fWKeWrtmTk?a",
      "display_url" : "youtu.be\/1fWKeWrtmTk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "288088433459613696",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/qMGTOtSi Christian Songs",
  "id" : 288088433459613696,
  "created_at" : "2013-01-07 01:03:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/eV49ca1y",
      "expanded_url" : "http:\/\/youtu.be\/ST612P_YJDQ?a",
      "display_url" : "youtu.be\/ST612P_YJDQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287782997112004608",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/eV49ca1y The best turkey bacon sandwich ever",
  "id" : 287782997112004608,
  "created_at" : "2013-01-06 04:49:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Zlpbc3lR",
      "expanded_url" : "http:\/\/youtu.be\/hkagNjXzaHE?a",
      "display_url" : "youtu.be\/hkagNjXzaHE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287768627200024576",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Zlpbc3lR One of my Most Elegant Watches",
  "id" : 287768627200024576,
  "created_at" : "2013-01-06 03:52:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 6, 14 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/j5dkPgwk",
      "expanded_url" : "http:\/\/youtu.be\/sUYDUW8x6ws?a",
      "display_url" : "youtu.be\/sUYDUW8x6ws?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287650043568193536",
  "text" : "cool (@YouTube http:\/\/t.co\/j5dkPgwk)",
  "id" : 287650043568193536,
  "created_at" : "2013-01-05 20:01:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 8, 16 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/31aDuUiR",
      "expanded_url" : "http:\/\/youtu.be\/6Mx_A7TOY6U?a",
      "display_url" : "youtu.be\/6Mx_A7TOY6U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287649919743963136",
  "text" : "awsome (@YouTube http:\/\/t.co\/31aDuUiR)",
  "id" : 287649919743963136,
  "created_at" : "2013-01-05 20:00:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WN1g6bQO",
      "expanded_url" : "http:\/\/youtu.be\/1S_9hBEqjeE?a",
      "display_url" : "youtu.be\/1S_9hBEqjeE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287429228927016962",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/WN1g6bQO Webcam video from January 5, 2013 12:23 AM",
  "id" : 287429228927016962,
  "created_at" : "2013-01-05 05:24:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ErT4FHKH",
      "expanded_url" : "http:\/\/youtu.be\/IAw3zlZwYus?a",
      "display_url" : "youtu.be\/IAw3zlZwYus?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287428391978823680",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ErT4FHKH Two Comics I Added to my Collection Today",
  "id" : 287428391978823680,
  "created_at" : "2013-01-05 05:20:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/xPEfqda2",
      "expanded_url" : "http:\/\/youtu.be\/lhuDgrVJnGc?a",
      "display_url" : "youtu.be\/lhuDgrVJnGc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287246024731406336",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/xPEfqda2 The Dogers Tracy Woodson Rare",
  "id" : 287246024731406336,
  "created_at" : "2013-01-04 17:16:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/bul9UoLV",
      "expanded_url" : "http:\/\/youtu.be\/d27VHjPzfaE?a",
      "display_url" : "youtu.be\/d27VHjPzfaE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287245126886100993",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/bul9UoLV Extremely Rare Flare 94' Cards",
  "id" : 287245126886100993,
  "created_at" : "2013-01-04 17:12:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/z8CPHDX7",
      "expanded_url" : "http:\/\/youtu.be\/lOT58_L_28w?a",
      "display_url" : "youtu.be\/lOT58_L_28w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287244486101331968",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/z8CPHDX7 My game console design",
  "id" : 287244486101331968,
  "created_at" : "2013-01-04 17:09:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/06shg5Pi",
      "expanded_url" : "http:\/\/youtu.be\/etD-CiP3hPA?a",
      "display_url" : "youtu.be\/etD-CiP3hPA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "287242307571445760",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/06shg5Pi August 30th, 1983 KSC launch Commemorative Coin",
  "id" : 287242307571445760,
  "created_at" : "2013-01-04 17:01:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/np0R01gv",
      "expanded_url" : "http:\/\/youtu.be\/PnXzgldlGvw?a",
      "display_url" : "youtu.be\/PnXzgldlGvw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286980421609201665",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/np0R01gv Funny Mother's Day Style Video",
  "id" : 286980421609201665,
  "created_at" : "2013-01-03 23:40:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/rw6KgBAe",
      "expanded_url" : "http:\/\/youtu.be\/vzadkgRdvs8?a",
      "display_url" : "youtu.be\/vzadkgRdvs8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286976898393841664",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/rw6KgBAe Tree Killer",
  "id" : 286976898393841664,
  "created_at" : "2013-01-03 23:26:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Sf8Iq9mY",
      "expanded_url" : "http:\/\/youtu.be\/ig9nwIrX4c4?a",
      "display_url" : "youtu.be\/ig9nwIrX4c4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286975835393622016",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Sf8Iq9mY Funny Sled Race",
  "id" : 286975835393622016,
  "created_at" : "2013-01-03 23:22:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/YbXU5r1Z",
      "expanded_url" : "http:\/\/youtu.be\/rxUpMtqCc_Q?a",
      "display_url" : "youtu.be\/rxUpMtqCc_Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286970494098497537",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/YbXU5r1Z Funniest Comedy Demo 2",
  "id" : 286970494098497537,
  "created_at" : "2013-01-03 23:01:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/xqJME5kv",
      "expanded_url" : "http:\/\/youtu.be\/42jRviL-xUE?a",
      "display_url" : "youtu.be\/42jRviL-xUE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286969088679505920",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/xqJME5kv Funniest Comedy Demo 1",
  "id" : 286969088679505920,
  "created_at" : "2013-01-03 22:55:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/woUJijjf",
      "expanded_url" : "http:\/\/youtu.be\/1DT__S5QLMA?a",
      "display_url" : "youtu.be\/1DT__S5QLMA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286967807193796610",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/woUJijjf How to Play Destructo Truck Part 2",
  "id" : 286967807193796610,
  "created_at" : "2013-01-03 22:50:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/u6Q9kcnq",
      "expanded_url" : "http:\/\/youtu.be\/SqBsMELVlC8?a",
      "display_url" : "youtu.be\/SqBsMELVlC8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286923774513803266",
  "text" : "Need carbon nanotubes= need $10,000, to expensive for a lightsaber (@YouTube http:\/\/t.co\/u6Q9kcnq)",
  "id" : 286923774513803266,
  "created_at" : "2013-01-03 19:55:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/u6Q9kcnq",
      "expanded_url" : "http:\/\/youtu.be\/SqBsMELVlC8?a",
      "display_url" : "youtu.be\/SqBsMELVlC8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286921689529454592",
  "text" : "I love this video (@YouTube http:\/\/t.co\/u6Q9kcnq)",
  "id" : 286921689529454592,
  "created_at" : "2013-01-03 19:47:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/u6Q9kcnq",
      "expanded_url" : "http:\/\/youtu.be\/SqBsMELVlC8?a",
      "display_url" : "youtu.be\/SqBsMELVlC8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286921147449237504",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/u6Q9kcnq Sci-Fi Science Physics of the Impossible S01E08: How to Build a Light",
  "id" : 286921147449237504,
  "created_at" : "2013-01-03 19:45:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/0nOuasFS",
      "expanded_url" : "http:\/\/youtu.be\/S3Eu7UCyiDc?a",
      "display_url" : "youtu.be\/S3Eu7UCyiDc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286863072671436800",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/0nOuasFS Strange UFO Sightings on January 1st, 2013",
  "id" : 286863072671436800,
  "created_at" : "2013-01-03 15:54:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WxeykKDZ",
      "expanded_url" : "http:\/\/youtu.be\/dKRHQRzH7NM?a",
      "display_url" : "youtu.be\/dKRHQRzH7NM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286699256742543360",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/WxeykKDZ Something I Sponsored in 2012",
  "id" : 286699256742543360,
  "created_at" : "2013-01-03 05:03:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/XQJHXCww",
      "expanded_url" : "http:\/\/youtu.be\/lXJFHtmS2LU?a",
      "display_url" : "youtu.be\/lXJFHtmS2LU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286658037597470720",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/XQJHXCww FHB Galaxies (As Seen on the Discovery Channel)",
  "id" : 286658037597470720,
  "created_at" : "2013-01-03 02:19:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/oYF9ZYNM",
      "expanded_url" : "http:\/\/youtu.be\/2L_9D1B11Qw?a",
      "display_url" : "youtu.be\/2L_9D1B11Qw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286590168562024448",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/oYF9ZYNM My Hypothesis",
  "id" : 286590168562024448,
  "created_at" : "2013-01-02 21:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/oYF9ZYNM",
      "expanded_url" : "http:\/\/youtu.be\/2L_9D1B11Qw?a",
      "display_url" : "youtu.be\/2L_9D1B11Qw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286590020574380032",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/oYF9ZYNM My Hypothesis",
  "id" : 286590020574380032,
  "created_at" : "2013-01-02 21:49:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/qlhJGevU",
      "expanded_url" : "http:\/\/youtu.be\/a_Ab1wVunj0?a",
      "display_url" : "youtu.be\/a_Ab1wVunj0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286545611187171328",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/qlhJGevU Sam Bacile's The Muhammad Movie (3D)",
  "id" : 286545611187171328,
  "created_at" : "2013-01-02 18:52:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/OU0nW0L0",
      "expanded_url" : "http:\/\/youtu.be\/aebm5O5mFoo?a",
      "display_url" : "youtu.be\/aebm5O5mFoo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286528034637500416",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/OU0nW0L0 A Message for Rush Limbaugh",
  "id" : 286528034637500416,
  "created_at" : "2013-01-02 17:43:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/fF6jcgAr",
      "expanded_url" : "http:\/\/youtu.be\/iRDsIOWc_fY?a",
      "display_url" : "youtu.be\/iRDsIOWc_fY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286508434210291712",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/fF6jcgAr P vs. NP Graphed + Main Abstract Part",
  "id" : 286508434210291712,
  "created_at" : "2013-01-02 16:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/fF6jcgAr",
      "expanded_url" : "http:\/\/youtu.be\/iRDsIOWc_fY?a",
      "display_url" : "youtu.be\/iRDsIOWc_fY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286508314655858688",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/fF6jcgAr P vs. NP Graphed + Main Abstract Part",
  "id" : 286508314655858688,
  "created_at" : "2013-01-02 16:24:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/DtKRGA6M",
      "expanded_url" : "http:\/\/youtu.be\/LE2MH85mdl4?a",
      "display_url" : "youtu.be\/LE2MH85mdl4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286295247749779456",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/DtKRGA6M Final Redesign of the Da Vinci Flying Machine",
  "id" : 286295247749779456,
  "created_at" : "2013-01-02 02:18:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/DtKRGA6M",
      "expanded_url" : "http:\/\/youtu.be\/LE2MH85mdl4?a",
      "display_url" : "youtu.be\/LE2MH85mdl4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286295152564244481",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/DtKRGA6M Final Redesign of the Da Vinci Flying Machine",
  "id" : 286295152564244481,
  "created_at" : "2013-01-02 02:17:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/DkNZDeSa",
      "expanded_url" : "http:\/\/youtu.be\/h9F9q2CVxQI?a",
      "display_url" : "youtu.be\/h9F9q2CVxQI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286226458836365312",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/DkNZDeSa A 360 DEGREE VIEW OF NORTHWEST OHIO",
  "id" : 286226458836365312,
  "created_at" : "2013-01-01 21:44:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/zM7ekhTI",
      "expanded_url" : "http:\/\/youtu.be\/1QGz76C9-24?a",
      "display_url" : "youtu.be\/1QGz76C9-24?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286220940294115330",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/zM7ekhTI Beautiful Statue of God",
  "id" : 286220940294115330,
  "created_at" : "2013-01-01 21:22:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286219003767185408",
  "text" : "Will be on the rush show tomorrow hopefully!!!!",
  "id" : 286219003767185408,
  "created_at" : "2013-01-01 21:15:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/YYnJRAcI",
      "expanded_url" : "http:\/\/youtu.be\/dFGr_sIbc2A?a",
      "display_url" : "youtu.be\/dFGr_sIbc2A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "286216082967117825",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/YYnJRAcI Graffiti near Norwood, Ohio",
  "id" : 286216082967117825,
  "created_at" : "2013-01-01 21:03:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/tgATny7S",
      "expanded_url" : "http:\/\/sdrv.ms\/TESJlJ",
      "display_url" : "sdrv.ms\/TESJlJ"
    } ]
  },
  "geo" : { },
  "id_str" : "286191858164592640",
  "text" : "P vs. NP graphed ((400!)-(100!*3)) http:\/\/t.co\/tgATny7S",
  "id" : 286191858164592640,
  "created_at" : "2013-01-01 19:27:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 58, 66 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/s7GCt6ZF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=-Y9n5_EAivg&sns=tw",
      "display_url" : "youtube.com\/watch?v=-Y9n5_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286169692429750272",
  "text" : "SEFMD 2013 Abstract Presentation http:\/\/t.co\/s7GCt6ZF via @youtube",
  "id" : 286169692429750272,
  "created_at" : "2013-01-01 17:59:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]