Grailbird.data.tweets_2017_11 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/95wAlhv31l",
      "expanded_url" : "http:\/\/ift.tt\/2yCzXZY",
      "display_url" : "ift.tt\/2yCzXZY"
    } ]
  },
  "geo" : { },
  "id_str" : "927771264697106432",
  "text" : "RT @dronepilots: Student Teams Compete in Service Academies Swarm Challenge \u2013 with GTRI Assistance | DronePilots - https:\/\/t.co\/95wAlhv31l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/95wAlhv31l",
        "expanded_url" : "http:\/\/ift.tt\/2yCzXZY",
        "display_url" : "ift.tt\/2yCzXZY"
      } ]
    },
    "geo" : { },
    "id_str" : "927766947965612032",
    "text" : "Student Teams Compete in Service Academies Swarm Challenge \u2013 with GTRI Assistance | DronePilots - https:\/\/t.co\/95wAlhv31l #drones",
    "id" : 927766947965612032,
    "created_at" : "2017-11-07 05:17:32 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927771264697106432,
  "created_at" : "2017-11-07 05:34:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Business",
      "screen_name" : "TwitterBusiness",
      "indices" : [ 0, 16 ],
      "id_str" : "121291606",
      "id" : 121291606
    }, {
      "name" : "Twitter Verified",
      "screen_name" : "verified",
      "indices" : [ 128, 137 ],
      "id_str" : "63796828",
      "id" : 63796828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927771132530487296",
  "in_reply_to_user_id" : 121291606,
  "text" : "@TwitterBusiness I am active in STEM &amp; been struggling to get my account verified since 2011, please show some startup love @Verified",
  "id" : 927771132530487296,
  "created_at" : "2017-11-07 05:34:09 +0000",
  "in_reply_to_screen_name" : "TwitterBusiness",
  "in_reply_to_user_id_str" : "121291606",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Guardian sport",
      "screen_name" : "guardian_sport",
      "indices" : [ 108, 123 ],
      "id_str" : "46403451",
      "id" : 46403451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/oIOX3CqRSF",
      "expanded_url" : "https:\/\/trib.al\/TKOgyu4",
      "display_url" : "trib.al\/TKOgyu4"
    } ]
  },
  "geo" : { },
  "id_str" : "927759089463103490",
  "text" : "RT @guardian: Melbourne Cup 2017: horses, form, fashion and latest tips \u2013 live! https:\/\/t.co\/oIOX3CqRSF via @guardian_sport",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guardian sport",
        "screen_name" : "guardian_sport",
        "indices" : [ 94, 109 ],
        "id_str" : "46403451",
        "id" : 46403451
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/oIOX3CqRSF",
        "expanded_url" : "https:\/\/trib.al\/TKOgyu4",
        "display_url" : "trib.al\/TKOgyu4"
      } ]
    },
    "geo" : { },
    "id_str" : "927695375854702595",
    "text" : "Melbourne Cup 2017: horses, form, fashion and latest tips \u2013 live! https:\/\/t.co\/oIOX3CqRSF via @guardian_sport",
    "id" : 927695375854702595,
    "created_at" : "2017-11-07 00:33:08 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877153924637175809\/deHwf3Qu_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 927759089463103490,
  "created_at" : "2017-11-07 04:46:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "indices" : [ 3, 12 ],
      "id_str" : "742143",
      "id" : 742143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/iDbrGLap3c",
      "expanded_url" : "http:\/\/bbc.in\/2lYJQLB",
      "display_url" : "bbc.in\/2lYJQLB"
    } ]
  },
  "geo" : { },
  "id_str" : "927758861590847489",
  "text" : "RT @BBCWorld: Argentina: First funerals held for NY truck attack victims https:\/\/t.co\/iDbrGLap3c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/iDbrGLap3c",
        "expanded_url" : "http:\/\/bbc.in\/2lYJQLB",
        "display_url" : "bbc.in\/2lYJQLB"
      } ]
    },
    "geo" : { },
    "id_str" : "927743741758267393",
    "text" : "Argentina: First funerals held for NY truck attack victims https:\/\/t.co\/iDbrGLap3c",
    "id" : 927743741758267393,
    "created_at" : "2017-11-07 03:45:19 +0000",
    "user" : {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "protected" : false,
      "id_str" : "742143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702138680246273\/BfQLzf7G_normal.jpg",
      "id" : 742143,
      "verified" : true
    }
  },
  "id" : 927758861590847489,
  "created_at" : "2017-11-07 04:45:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "change",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758663141511168",
  "text" : "RT @JayHoque: Do you love your work? \"The only way to do great work is to love what you do.\" Steve Jobs #change",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "change",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927702152818049024",
    "text" : "Do you love your work? \"The only way to do great work is to love what you do.\" Steve Jobs #change",
    "id" : 927702152818049024,
    "created_at" : "2017-11-07 01:00:03 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927758663141511168,
  "created_at" : "2017-11-07 04:44:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ability",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758638386745344",
  "text" : "RT @JayHoque: Are you ready to take a risk? \"If you don't risk anything, then you risk even more.\" Erica Jong #ability",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ability",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927732350808506369",
    "text" : "Are you ready to take a risk? \"If you don't risk anything, then you risk even more.\" Erica Jong #ability",
    "id" : 927732350808506369,
    "created_at" : "2017-11-07 03:00:03 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927758638386745344,
  "created_at" : "2017-11-07 04:44:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758600608419840",
  "text" : "RT @PFF_Brett: Stafford is straight dealing. Second week in a row. Good to see.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927739666299871232",
    "text" : "Stafford is straight dealing. Second week in a row. Good to see.",
    "id" : 927739666299871232,
    "created_at" : "2017-11-07 03:29:07 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920477903309230081\/lu_lxlxH_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 927758600608419840,
  "created_at" : "2017-11-07 04:44:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758579771367425",
  "text" : "RT @PFF_Brett: I know game is in hand but considering red zone woes. I'm going for the TD here as practice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927749118939844609",
    "text" : "I know game is in hand but considering red zone woes. I'm going for the TD here as practice.",
    "id" : 927749118939844609,
    "created_at" : "2017-11-07 04:06:41 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920477903309230081\/lu_lxlxH_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 927758579771367425,
  "created_at" : "2017-11-07 04:44:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Future Society",
      "screen_name" : "WorldFutureSoc",
      "indices" : [ 3, 18 ],
      "id_str" : "47939390",
      "id" : 47939390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758485835698178",
  "text" : "RT @WorldFutureSoc: \"How can we create a brand new narrative that makes the old system obsolete\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926229700556488704",
    "text" : "\"How can we create a brand new narrative that makes the old system obsolete\"",
    "id" : 926229700556488704,
    "created_at" : "2017-11-02 23:29:03 +0000",
    "user" : {
      "name" : "World Future Society",
      "screen_name" : "WorldFutureSoc",
      "protected" : false,
      "id_str" : "47939390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843851000075112448\/IiP1MuCh_normal.jpg",
      "id" : 47939390,
      "verified" : false
    }
  },
  "id" : 927758485835698178,
  "created_at" : "2017-11-07 04:43:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Future Society",
      "screen_name" : "WorldFutureSoc",
      "indices" : [ 3, 18 ],
      "id_str" : "47939390",
      "id" : 47939390
    }, {
      "name" : "Meta Julie",
      "screen_name" : "MetaJulie1",
      "indices" : [ 119, 130 ],
      "id_str" : "701842584",
      "id" : 701842584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927758427081801734",
  "text" : "RT @WorldFutureSoc: \"The problem with our education system is that we have one single human brain assigned to 40 kids\" @MetaJulie1 #futureo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meta Julie",
        "screen_name" : "MetaJulie1",
        "indices" : [ 99, 110 ],
        "id_str" : "701842584",
        "id" : 701842584
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futureofedu",
        "indices" : [ 111, 123 ]
      }, {
        "text" : "stem",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926550600153694208",
    "text" : "\"The problem with our education system is that we have one single human brain assigned to 40 kids\" @MetaJulie1 #futureofedu #stem",
    "id" : 926550600153694208,
    "created_at" : "2017-11-03 20:44:12 +0000",
    "user" : {
      "name" : "World Future Society",
      "screen_name" : "WorldFutureSoc",
      "protected" : false,
      "id_str" : "47939390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843851000075112448\/IiP1MuCh_normal.jpg",
      "id" : 47939390,
      "verified" : false
    }
  },
  "id" : 927758427081801734,
  "created_at" : "2017-11-07 04:43:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927757308351967232",
  "text" : "RT @lorenridinger: \"Be thankful for what you have and all the blessings in your life and you will surely dose off peacefully and wake up fe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927747546973396992",
    "text" : "\"Be thankful for what you have and all the blessings in your life and you will surely dose off peacefully and wake up feeling refreshed.\"",
    "id" : 927747546973396992,
    "created_at" : "2017-11-07 04:00:26 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 927757308351967232,
  "created_at" : "2017-11-07 04:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/V1gn4XW188",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4qk40",
      "display_url" : "cards.twitter.com\/cards\/a6dip\/4q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927757242711117826",
  "text" : "RT @hootsuite: There IS a way to increase your reach on Facebook (without paying for it) \uD83D\uDCB8 https:\/\/t.co\/V1gn4XW188",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/V1gn4XW188",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4qk40",
        "display_url" : "cards.twitter.com\/cards\/a6dip\/4q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927751235226275840",
    "text" : "There IS a way to increase your reach on Facebook (without paying for it) \uD83D\uDCB8 https:\/\/t.co\/V1gn4XW188",
    "id" : 927751235226275840,
    "created_at" : "2017-11-07 04:15:05 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 927757242711117826,
  "created_at" : "2017-11-07 04:38:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerOfBroke",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927736878627020801",
  "text" : "RT @TheSharkDaymond: With a good idea, passion and a committed work ethic, you can succeed even without financial resources. #PowerOfBroke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PowerOfBroke",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927615319782449152",
    "text" : "With a good idea, passion and a committed work ethic, you can succeed even without financial resources. #PowerOfBroke",
    "id" : 927615319782449152,
    "created_at" : "2017-11-06 19:15:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817056911518482433\/otB2Lkng_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 927736878627020801,
  "created_at" : "2017-11-07 03:18:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houston Outlaws",
      "screen_name" : "OutlawsOW",
      "indices" : [ 3, 13 ],
      "id_str" : "920664872786059264",
      "id" : 920664872786059264
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/QaUPwvLWFh",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gzp9NArJfkk",
      "display_url" : "youtube.com\/watch?v=gzp9NA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927736339872743424",
  "text" : "RT @OutlawsOW: Houston Outlaws: Boink Interview!: https:\/\/t.co\/QaUPwvLWFh via @Youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 63, 71 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/QaUPwvLWFh",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gzp9NArJfkk",
        "display_url" : "youtube.com\/watch?v=gzp9NA\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925829965895086080",
    "text" : "Houston Outlaws: Boink Interview!: https:\/\/t.co\/QaUPwvLWFh via @Youtube",
    "id" : 925829965895086080,
    "created_at" : "2017-11-01 21:00:39 +0000",
    "user" : {
      "name" : "Houston Outlaws",
      "screen_name" : "OutlawsOW",
      "protected" : false,
      "id_str" : "920664872786059264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925463951957041152\/7jyasCrg_normal.jpg",
      "id" : 920664872786059264,
      "verified" : true
    }
  },
  "id" : 927736339872743424,
  "created_at" : "2017-11-07 03:15:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Envy",
      "screen_name" : "TeamEnVyUs",
      "indices" : [ 3, 14 ],
      "id_str" : "115038550",
      "id" : 115038550
    }, {
      "name" : "AGO Gaming",
      "screen_name" : "AGOcsgo",
      "indices" : [ 79, 87 ],
      "id_str" : "917383683627241472",
      "id" : 917383683627241472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927736224563032064",
  "text" : "RT @TeamEnVyUs: A close final match and series but we take the series 2-1 over @AGOcsgo. We play Optic for a spot in the Major qualifier ne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AGO Gaming",
        "screen_name" : "AGOcsgo",
        "indices" : [ 63, 71 ],
        "id_str" : "917383683627241472",
        "id" : 917383683627241472
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BoysinBlue",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927129113567121408",
    "text" : "A close final match and series but we take the series 2-1 over @AGOcsgo. We play Optic for a spot in the Major qualifier next! #BoysinBlue",
    "id" : 927129113567121408,
    "created_at" : "2017-11-05 11:03:00 +0000",
    "user" : {
      "name" : "Team Envy",
      "screen_name" : "TeamEnVyUs",
      "protected" : false,
      "id_str" : "115038550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720691210768269312\/IrRM-XjR_normal.jpg",
      "id" : 115038550,
      "verified" : true
    }
  },
  "id" : 927736224563032064,
  "created_at" : "2017-11-07 03:15:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denial Esports",
      "screen_name" : "DenialEsports",
      "indices" : [ 3, 17 ],
      "id_str" : "1269608078",
      "id" : 1269608078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927736145735225344",
  "text" : "RT @DenialEsports: We understand the restlessness, we ask that you be patient. There are a lot of backend moving pieces before we make our\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "908021237699489797",
    "text" : "We understand the restlessness, we ask that you be patient. There are a lot of backend moving pieces before we make our statement.",
    "id" : 908021237699489797,
    "created_at" : "2017-09-13 17:35:07 +0000",
    "user" : {
      "name" : "Denial Esports",
      "screen_name" : "DenialEsports",
      "protected" : false,
      "id_str" : "1269608078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903085425904033793\/Pe_zTFgj_normal.jpg",
      "id" : 1269608078,
      "verified" : true
    }
  },
  "id" : 927736145735225344,
  "created_at" : "2017-11-07 03:15:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denial Esports",
      "screen_name" : "DenialEsports",
      "indices" : [ 3, 17 ],
      "id_str" : "1269608078",
      "id" : 1269608078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927736130312851456",
  "text" : "RT @DenialEsports: We will be resuming social media efforts as soon as all issues at hand are solved. Bear with us. Everyone is working on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "915634717843771393",
    "text" : "We will be resuming social media efforts as soon as all issues at hand are solved. Bear with us. Everyone is working on it.",
    "id" : 915634717843771393,
    "created_at" : "2017-10-04 17:48:23 +0000",
    "user" : {
      "name" : "Denial Esports",
      "screen_name" : "DenialEsports",
      "protected" : false,
      "id_str" : "1269608078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903085425904033793\/Pe_zTFgj_normal.jpg",
      "id" : 1269608078,
      "verified" : true
    }
  },
  "id" : 927736130312851456,
  "created_at" : "2017-11-07 03:15:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 3, 16 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Mi5gec8Z5U",
      "expanded_url" : "http:\/\/econ.st\/2yzZ1kr",
      "display_url" : "econ.st\/2yzZ1kr"
    } ]
  },
  "geo" : { },
  "id_str" : "927735470196436992",
  "text" : "RT @TheEconomist: Saudi Arabia\u2019s unprecedented shake-up https:\/\/t.co\/Mi5gec8Z5U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/Mi5gec8Z5U",
        "expanded_url" : "http:\/\/econ.st\/2yzZ1kr",
        "display_url" : "econ.st\/2yzZ1kr"
      } ]
    },
    "geo" : { },
    "id_str" : "927728675872755713",
    "text" : "Saudi Arabia\u2019s unprecedented shake-up https:\/\/t.co\/Mi5gec8Z5U",
    "id" : 927728675872755713,
    "created_at" : "2017-11-07 02:45:27 +0000",
    "user" : {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "protected" : false,
      "id_str" : "5988062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879361767914262528\/HdRauDM-_normal.jpg",
      "id" : 5988062,
      "verified" : true
    }
  },
  "id" : 927735470196436992,
  "created_at" : "2017-11-07 03:12:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radeon RX",
      "screen_name" : "Radeon",
      "indices" : [ 3, 10 ],
      "id_str" : "23127272",
      "id" : 23127272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wolf2",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927734792921190400",
  "text" : "RT @Radeon: Get ready to take down the evil in #Wolf2 with the help of fellow resistance fighters and our recommended settings. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wolf2",
        "indices" : [ 35, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/vS7gWIFNBt",
        "expanded_url" : "http:\/\/bit.ly\/2hGPMnM",
        "display_url" : "bit.ly\/2hGPMnM"
      } ]
    },
    "geo" : { },
    "id_str" : "926933669733982216",
    "text" : "Get ready to take down the evil in #Wolf2 with the help of fellow resistance fighters and our recommended settings. https:\/\/t.co\/vS7gWIFNBt",
    "id" : 926933669733982216,
    "created_at" : "2017-11-04 22:06:23 +0000",
    "user" : {
      "name" : "Radeon RX",
      "screen_name" : "Radeon",
      "protected" : false,
      "id_str" : "23127272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891869436831039488\/sHld6k94_normal.jpg",
      "id" : 23127272,
      "verified" : true
    }
  },
  "id" : 927734792921190400,
  "created_at" : "2017-11-07 03:09:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phandroid",
      "screen_name" : "Phandroid",
      "indices" : [ 3, 13 ],
      "id_str" : "17932641",
      "id" : 17932641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ZKeCX2GPwk",
      "expanded_url" : "http:\/\/bit.ly\/2zcSziR",
      "display_url" : "bit.ly\/2zcSziR"
    } ]
  },
  "geo" : { },
  "id_str" : "927734607642005505",
  "text" : "RT @Phandroid: The new Rounded UI is showing up in the Google App https:\/\/t.co\/ZKeCX2GPwk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/ZKeCX2GPwk",
        "expanded_url" : "http:\/\/bit.ly\/2zcSziR",
        "display_url" : "bit.ly\/2zcSziR"
      } ]
    },
    "geo" : { },
    "id_str" : "926525700097609728",
    "text" : "The new Rounded UI is showing up in the Google App https:\/\/t.co\/ZKeCX2GPwk",
    "id" : 926525700097609728,
    "created_at" : "2017-11-03 19:05:15 +0000",
    "user" : {
      "name" : "Phandroid",
      "screen_name" : "Phandroid",
      "protected" : false,
      "id_str" : "17932641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876790725731651590\/s10LgrPt_normal.jpg",
      "id" : 17932641,
      "verified" : true
    }
  },
  "id" : 927734607642005505,
  "created_at" : "2017-11-07 03:09:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phandroid",
      "screen_name" : "Phandroid",
      "indices" : [ 3, 13 ],
      "id_str" : "17932641",
      "id" : 17932641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/V8wYedsCPw",
      "expanded_url" : "http:\/\/bit.ly\/2yArZ3s",
      "display_url" : "bit.ly\/2yArZ3s"
    } ]
  },
  "geo" : { },
  "id_str" : "927734428482392064",
  "text" : "RT @Phandroid: Broadcom officially offers bid for Qualcomm for $130 billion https:\/\/t.co\/V8wYedsCPw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/V8wYedsCPw",
        "expanded_url" : "http:\/\/bit.ly\/2yArZ3s",
        "display_url" : "bit.ly\/2yArZ3s"
      } ]
    },
    "geo" : { },
    "id_str" : "927593385552203777",
    "text" : "Broadcom officially offers bid for Qualcomm for $130 billion https:\/\/t.co\/V8wYedsCPw",
    "id" : 927593385552203777,
    "created_at" : "2017-11-06 17:47:51 +0000",
    "user" : {
      "name" : "Phandroid",
      "screen_name" : "Phandroid",
      "protected" : false,
      "id_str" : "17932641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876790725731651590\/s10LgrPt_normal.jpg",
      "id" : 17932641,
      "verified" : true
    }
  },
  "id" : 927734428482392064,
  "created_at" : "2017-11-07 03:08:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/maiqb3Y2uR",
      "expanded_url" : "https:\/\/drd.life\/2y941YO",
      "display_url" : "drd.life\/2y941YO"
    } ]
  },
  "geo" : { },
  "id_str" : "927734323238891520",
  "text" : "RT @droid_life: Monument Valley 2 now available for Android, priced at $5 - https:\/\/t.co\/maiqb3Y2uR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/maiqb3Y2uR",
        "expanded_url" : "https:\/\/drd.life\/2y941YO",
        "display_url" : "drd.life\/2y941YO"
      } ]
    },
    "geo" : { },
    "id_str" : "927715982088556544",
    "text" : "Monument Valley 2 now available for Android, priced at $5 - https:\/\/t.co\/maiqb3Y2uR",
    "id" : 927715982088556544,
    "created_at" : "2017-11-07 01:55:00 +0000",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875714366850580480\/CRYnH5uF_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 927734323238891520,
  "created_at" : "2017-11-07 03:07:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "indices" : [ 3, 14 ],
      "id_str" : "96501375",
      "id" : 96501375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/mW7x4aKeUJ",
      "expanded_url" : "https:\/\/drd.life\/2yanpEE",
      "display_url" : "drd.life\/2yanpEE"
    } ]
  },
  "geo" : { },
  "id_str" : "927734299381596160",
  "text" : "RT @droid_life: November 16 is officially OnePlus 5T unveiling day - https:\/\/t.co\/mW7x4aKeUJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/mW7x4aKeUJ",
        "expanded_url" : "https:\/\/drd.life\/2yanpEE",
        "display_url" : "drd.life\/2yanpEE"
      } ]
    },
    "geo" : { },
    "id_str" : "927726047210045440",
    "text" : "November 16 is officially OnePlus 5T unveiling day - https:\/\/t.co\/mW7x4aKeUJ",
    "id" : 927726047210045440,
    "created_at" : "2017-11-07 02:35:00 +0000",
    "user" : {
      "name" : "Droid Life",
      "screen_name" : "droid_life",
      "protected" : false,
      "id_str" : "96501375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875714366850580480\/CRYnH5uF_normal.jpg",
      "id" : 96501375,
      "verified" : true
    }
  },
  "id" : 927734299381596160,
  "created_at" : "2017-11-07 03:07:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikko RC",
      "screen_name" : "NikkoRC",
      "indices" : [ 3, 11 ],
      "id_str" : "271407791",
      "id" : 271407791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927734034469474304",
  "text" : "RT @NikkoRC: Check out the Nikko VaporizR\u2122 2, a @ToyInsider pick for the hottest summer toys, on @CBSPhilly! https:\/\/t.co\/SSCLrQH3Q6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBS Philly",
        "screen_name" : "CBSPhilly",
        "indices" : [ 84, 94 ],
        "id_str" : "16083576",
        "id" : 16083576
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/SSCLrQH3Q6",
        "expanded_url" : "http:\/\/bit.ly\/2sjtjQh",
        "display_url" : "bit.ly\/2sjtjQh"
      } ]
    },
    "geo" : { },
    "id_str" : "880134958169325568",
    "text" : "Check out the Nikko VaporizR\u2122 2, a @ToyInsider pick for the hottest summer toys, on @CBSPhilly! https:\/\/t.co\/SSCLrQH3Q6",
    "id" : 880134958169325568,
    "created_at" : "2017-06-28 18:45:00 +0000",
    "user" : {
      "name" : "Nikko RC",
      "screen_name" : "NikkoRC",
      "protected" : false,
      "id_str" : "271407791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806931503569637376\/wG1CpC2V_normal.jpg",
      "id" : 271407791,
      "verified" : false
    }
  },
  "id" : 927734034469474304,
  "created_at" : "2017-11-07 03:06:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Temple",
      "screen_name" : "Slogomanify",
      "indices" : [ 3, 15 ],
      "id_str" : "1615483848",
      "id" : 1615483848
    }, {
      "name" : "Nikko RC",
      "screen_name" : "NikkoRC",
      "indices" : [ 126, 134 ],
      "id_str" : "271407791",
      "id" : 271407791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ad",
      "indices" : [ 122, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Qu4PBPo4Ut",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=N__HAO1zyPY",
      "display_url" : "youtube.com\/watch?v=N__HAO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927733954932854784",
  "text" : "RT @Slogomanify: New video live! Check it out https:\/\/t.co\/Qu4PBPo4Ut - Racing the new Nikko Air Drones against the clock #ad @NikkoRC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nikko RC",
        "screen_name" : "NikkoRC",
        "indices" : [ 109, 117 ],
        "id_str" : "271407791",
        "id" : 271407791
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ad",
        "indices" : [ 105, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/Qu4PBPo4Ut",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=N__HAO1zyPY",
        "display_url" : "youtube.com\/watch?v=N__HAO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927295915030974465",
    "text" : "New video live! Check it out https:\/\/t.co\/Qu4PBPo4Ut - Racing the new Nikko Air Drones against the clock #ad @NikkoRC",
    "id" : 927295915030974465,
    "created_at" : "2017-11-05 22:05:49 +0000",
    "user" : {
      "name" : "Joshua Temple",
      "screen_name" : "Slogomanify",
      "protected" : false,
      "id_str" : "1615483848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920761428767924224\/IJFY_Dzu_normal.jpg",
      "id" : 1615483848,
      "verified" : true
    }
  },
  "id" : 927733954932854784,
  "created_at" : "2017-11-07 03:06:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "game",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1MrEEcwH5x",
      "expanded_url" : "http:\/\/phy.so\/429160427",
      "display_url" : "phy.so\/429160427"
    } ]
  },
  "geo" : { },
  "id_str" : "927733848338784256",
  "text" : "RT @physorg_com: Distinguishing between humans and computers in the #game of go https:\/\/t.co\/1MrEEcwH5x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "game",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/1MrEEcwH5x",
        "expanded_url" : "http:\/\/phy.so\/429160427",
        "display_url" : "phy.so\/429160427"
      } ]
    },
    "geo" : { },
    "id_str" : "927543605492928512",
    "text" : "Distinguishing between humans and computers in the #game of go https:\/\/t.co\/1MrEEcwH5x",
    "id" : 927543605492928512,
    "created_at" : "2017-11-06 14:30:03 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 927733848338784256,
  "created_at" : "2017-11-07 03:06:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927733373841362949\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/1hG97w42g9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_4gmtX4AM8lIJ.jpg",
      "id_str" : "927733287291969539",
      "id" : 927733287291969539,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_4gmtX4AM8lIJ.jpg",
      "sizes" : [ {
        "h" : 732,
        "resize" : "fit",
        "w" : 1213
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1213
      } ],
      "display_url" : "pic.twitter.com\/1hG97w42g9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927733373841362949",
  "text" : "Thanks for those who believe in our project so far, we are doing our best, (regardless if goal is met or not) in pursuing our tech further https:\/\/t.co\/1hG97w42g9",
  "id" : 927733373841362949,
  "created_at" : "2017-11-07 03:04:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brilliantpad",
      "indices" : [ 112, 125 ]
    }, {
      "text" : "SharkTank",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927727987188957184",
  "text" : "RT @BarbaraCorcoran: I don\u2019t think your ask is reasonable and this deal is a little too high risk, so I am out! #brilliantpad #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brilliantpad",
        "indices" : [ 91, 104 ]
      }, {
        "text" : "SharkTank",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927371629038010368",
    "text" : "I don\u2019t think your ask is reasonable and this deal is a little too high risk, so I am out! #brilliantpad #SharkTank",
    "id" : 927371629038010368,
    "created_at" : "2017-11-06 03:06:40 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 927727987188957184,
  "created_at" : "2017-11-07 02:42:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927727953152217088",
  "text" : "Gonna minimize event attendances next few month unless absolutely have to so I can focus on meetings and learning more instead.",
  "id" : 927727953152217088,
  "created_at" : "2017-11-07 02:42:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdTech K\u201312 Magazine",
      "screen_name" : "EdTech_K12",
      "indices" : [ 3, 14 ],
      "id_str" : "67700256",
      "id" : 67700256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DigitalLiteracy",
      "indices" : [ 16, 32 ]
    }, {
      "text" : "K12",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "edtech",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/EeeCnv39g0",
      "expanded_url" : "http:\/\/tech.mg\/GvSKYx",
      "display_url" : "tech.mg\/GvSKYx"
    } ]
  },
  "geo" : { },
  "id_str" : "927718964842680321",
  "text" : "RT @EdTech_K12: #DigitalLiteracy is at the forefront of #K12 #edtech for both teachers &amp; students. https:\/\/t.co\/EeeCnv39g0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DigitalLiteracy",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "K12",
        "indices" : [ 40, 44 ]
      }, {
        "text" : "edtech",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/EeeCnv39g0",
        "expanded_url" : "http:\/\/tech.mg\/GvSKYx",
        "display_url" : "tech.mg\/GvSKYx"
      } ]
    },
    "geo" : { },
    "id_str" : "927649687057895424",
    "text" : "#DigitalLiteracy is at the forefront of #K12 #edtech for both teachers &amp; students. https:\/\/t.co\/EeeCnv39g0",
    "id" : 927649687057895424,
    "created_at" : "2017-11-06 21:31:34 +0000",
    "user" : {
      "name" : "EdTech K\u201312 Magazine",
      "screen_name" : "EdTech_K12",
      "protected" : false,
      "id_str" : "67700256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885149829898407936\/1wM-yApS_normal.jpg",
      "id" : 67700256,
      "verified" : false
    }
  },
  "id" : 927718964842680321,
  "created_at" : "2017-11-07 02:06:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/oxedP70rST",
      "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/r-spatial-representation\/?s=1",
      "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927718694830174218",
  "text" : "RT @analyticbridge: https:\/\/t.co\/oxedP70rST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/oxedP70rST",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/r-spatial-representation\/?s=1",
        "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927717417542930433",
    "text" : "https:\/\/t.co\/oxedP70rST",
    "id" : 927717417542930433,
    "created_at" : "2017-11-07 02:00:43 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 927718694830174218,
  "created_at" : "2017-11-07 02:05:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Irvine",
      "screen_name" : "geogmi",
      "indices" : [ 3, 10 ],
      "id_str" : "66894590",
      "id" : 66894590
    }, {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 86, 99 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/elAK83Bh97",
      "expanded_url" : "https:\/\/shar.es\/1PEv6b",
      "display_url" : "shar.es\/1PEv6b"
    } ]
  },
  "geo" : { },
  "id_str" : "927718592585617410",
  "text" : "RT @geogmi: Intel Optane SSD 900P Review - Tom's Hardware https:\/\/t.co\/elAK83Bh97 via @tomshardware",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom's Hardware",
        "screen_name" : "tomshardware",
        "indices" : [ 74, 87 ],
        "id_str" : "17064514",
        "id" : 17064514
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/elAK83Bh97",
        "expanded_url" : "https:\/\/shar.es\/1PEv6b",
        "display_url" : "shar.es\/1PEv6b"
      } ]
    },
    "geo" : { },
    "id_str" : "927198061100597248",
    "text" : "Intel Optane SSD 900P Review - Tom's Hardware https:\/\/t.co\/elAK83Bh97 via @tomshardware",
    "id" : 927198061100597248,
    "created_at" : "2017-11-05 15:36:58 +0000",
    "user" : {
      "name" : "George Irvine",
      "screen_name" : "geogmi",
      "protected" : false,
      "id_str" : "66894590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534468851\/DSC09962_normal.JPG",
      "id" : 66894590,
      "verified" : false
    }
  },
  "id" : 927718592585617410,
  "created_at" : "2017-11-07 02:05:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Z. Nardi",
      "screen_name" : "willthethinker",
      "indices" : [ 3, 18 ],
      "id_str" : "725754026894184448",
      "id" : 725754026894184448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927718574835322881",
  "text" : "RT @willthethinker: \u201CReason is the slave of passion\u201D\u2014David Hume",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927716465901555712",
    "text" : "\u201CReason is the slave of passion\u201D\u2014David Hume",
    "id" : 927716465901555712,
    "created_at" : "2017-11-07 01:56:56 +0000",
    "user" : {
      "name" : "William Z. Nardi",
      "screen_name" : "willthethinker",
      "protected" : false,
      "id_str" : "725754026894184448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913815903837605893\/466Xtu7J_normal.jpg",
      "id" : 725754026894184448,
      "verified" : false
    }
  },
  "id" : 927718574835322881,
  "created_at" : "2017-11-07 02:05:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "indices" : [ 3, 17 ],
      "id_str" : "34356320",
      "id" : 34356320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927718563594604544",
  "text" : "RT @jorgevictoria: Every day may not be good but there is something good in every day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927717423914143745",
    "text" : "Every day may not be good but there is something good in every day.",
    "id" : 927717423914143745,
    "created_at" : "2017-11-07 02:00:44 +0000",
    "user" : {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "protected" : false,
      "id_str" : "34356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912009359047249921\/4cdwMLey_normal.jpg",
      "id" : 34356320,
      "verified" : false
    }
  },
  "id" : 927718563594604544,
  "created_at" : "2017-11-07 02:05:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DreamBig",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927718516123414529",
  "text" : "RT @JayHoque: Choose to be with the best.  \"Surround yourself with those who make you better.\" Adam Braun #DreamBig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DreamBig",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927717249921646594",
    "text" : "Choose to be with the best.  \"Surround yourself with those who make you better.\" Adam Braun #DreamBig",
    "id" : 927717249921646594,
    "created_at" : "2017-11-07 02:00:03 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927718516123414529,
  "created_at" : "2017-11-07 02:05:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927718470434816000",
  "text" : "RT @PFF_Brett: Quandre Diggs' ability to make the most awkward tackles is an unspoken skill. Dude always comes up with impossible looking s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927716985189883904",
    "text" : "Quandre Diggs' ability to make the most awkward tackles is an unspoken skill. Dude always comes up with impossible looking stops.",
    "id" : 927716985189883904,
    "created_at" : "2017-11-07 01:59:00 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920477903309230081\/lu_lxlxH_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 927718470434816000,
  "created_at" : "2017-11-07 02:04:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "indices" : [ 3, 10 ],
      "id_str" : "15919988",
      "id" : 15919988
    }, {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 120, 127 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/qepfvviNet",
      "expanded_url" : "https:\/\/goo.gl\/9asCx8",
      "display_url" : "goo.gl\/9asCx8"
    } ]
  },
  "geo" : { },
  "id_str" : "927718454215479297",
  "text" : "RT @xprize: This void was discovered in the Great Pyramid using a new method: muon radiography. https:\/\/t.co\/qepfvviNet @NatGeo @michaelgre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Geographic",
        "screen_name" : "NatGeo",
        "indices" : [ 108, 115 ],
        "id_str" : "17471979",
        "id" : 17471979
      }, {
        "name" : "Michael Greshko",
        "screen_name" : "michaelgreshko",
        "indices" : [ 116, 131 ],
        "id_str" : "80203745",
        "id" : 80203745
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/qepfvviNet",
        "expanded_url" : "https:\/\/goo.gl\/9asCx8",
        "display_url" : "goo.gl\/9asCx8"
      } ]
    },
    "geo" : { },
    "id_str" : "927717354099929088",
    "text" : "This void was discovered in the Great Pyramid using a new method: muon radiography. https:\/\/t.co\/qepfvviNet @NatGeo @michaelgreshko",
    "id" : 927717354099929088,
    "created_at" : "2017-11-07 02:00:28 +0000",
    "user" : {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "protected" : false,
      "id_str" : "15919988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890261363808886784\/WJyNCRI__normal.jpg",
      "id" : 15919988,
      "verified" : true
    }
  },
  "id" : 927718454215479297,
  "created_at" : "2017-11-07 02:04:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JayzTwoCents",
      "screen_name" : "JayzTwoCents",
      "indices" : [ 3, 16 ],
      "id_str" : "431947388",
      "id" : 431947388
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 113, 121 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/dHa4N0jIR1",
      "expanded_url" : "http:\/\/youtu.be\/JonBbRx8Nuw?a",
      "display_url" : "youtu.be\/JonBbRx8Nuw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927718258475765760",
  "text" : "RT @JayzTwoCents: My first time Overclocking on Liquid Nitrogen - NEW WORLD RECORD!: https:\/\/t.co\/dHa4N0jIR1 via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 95, 103 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/dHa4N0jIR1",
        "expanded_url" : "http:\/\/youtu.be\/JonBbRx8Nuw?a",
        "display_url" : "youtu.be\/JonBbRx8Nuw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "927256698091433984",
    "text" : "My first time Overclocking on Liquid Nitrogen - NEW WORLD RECORD!: https:\/\/t.co\/dHa4N0jIR1 via @YouTube",
    "id" : 927256698091433984,
    "created_at" : "2017-11-05 19:29:59 +0000",
    "user" : {
      "name" : "JayzTwoCents",
      "screen_name" : "JayzTwoCents",
      "protected" : false,
      "id_str" : "431947388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926231438701117441\/fBJP-GqU_normal.jpg",
      "id" : 431947388,
      "verified" : true
    }
  },
  "id" : 927718258475765760,
  "created_at" : "2017-11-07 02:04:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle",
      "screen_name" : "bitwitkyle",
      "indices" : [ 3, 14 ],
      "id_str" : "803091096",
      "id" : 803091096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/SuPyfPvVq8",
      "expanded_url" : "https:\/\/youtu.be\/bYYj_k5qXkQ",
      "display_url" : "youtu.be\/bYYj_k5qXkQ"
    } ]
  },
  "geo" : { },
  "id_str" : "927718173230714885",
  "text" : "RT @bitwitkyle: Dropping that new video like it's hot!! https:\/\/t.co\/SuPyfPvVq8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/SuPyfPvVq8",
        "expanded_url" : "https:\/\/youtu.be\/bYYj_k5qXkQ",
        "display_url" : "youtu.be\/bYYj_k5qXkQ"
      } ]
    },
    "geo" : { },
    "id_str" : "927669464140673026",
    "text" : "Dropping that new video like it's hot!! https:\/\/t.co\/SuPyfPvVq8",
    "id" : 927669464140673026,
    "created_at" : "2017-11-06 22:50:10 +0000",
    "user" : {
      "name" : "Kyle",
      "screen_name" : "bitwitkyle",
      "protected" : false,
      "id_str" : "803091096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919297783047139328\/MMm_Idzi_normal.jpg",
      "id" : 803091096,
      "verified" : false
    }
  },
  "id" : 927718173230714885,
  "created_at" : "2017-11-07 02:03:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Destiny2",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "PC",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/sQQ1kFQmRk",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/destiny-2-pc-stuttering-fix,35859.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/destiny-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927718081123749889",
  "text" : "RT @tomshardware: \u25B8 Latest '#Destiny2' Patch Fixes #PC Stuttering Issues https:\/\/t.co\/sQQ1kFQmRk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Destiny2",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "PC",
        "indices" : [ 33, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/sQQ1kFQmRk",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/destiny-2-pc-stuttering-fix,35859.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/destiny-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927639992255397889",
    "text" : "\u25B8 Latest '#Destiny2' Patch Fixes #PC Stuttering Issues https:\/\/t.co\/sQQ1kFQmRk",
    "id" : 927639992255397889,
    "created_at" : "2017-11-06 20:53:03 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927718081123749889,
  "created_at" : "2017-11-07 02:03:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PC",
      "indices" : [ 34, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/k4IUDry07g",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/injustice-2-pc-beta-launches,35862.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/injustice\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927718036060164097",
  "text" : "RT @tomshardware: \u25B8 'Injustice 2' #PC Beta Kicks Off Today https:\/\/t.co\/k4IUDry07g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PC",
        "indices" : [ 16, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/k4IUDry07g",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/injustice-2-pc-beta-launches,35862.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/injustice\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927661636814389248",
    "text" : "\u25B8 'Injustice 2' #PC Beta Kicks Off Today https:\/\/t.co\/k4IUDry07g",
    "id" : 927661636814389248,
    "created_at" : "2017-11-06 22:19:03 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927718036060164097,
  "created_at" : "2017-11-07 02:03:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startups",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927717990581391360",
  "text" : "Exciting things to come maybe? #startups",
  "id" : 927717990581391360,
  "created_at" : "2017-11-07 02:02:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P3",
      "screen_name" : "mfitri97",
      "indices" : [ 3, 12 ],
      "id_str" : "439300804",
      "id" : 439300804
    }, {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 94, 107 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/7TVNgc5tYA",
      "expanded_url" : "https:\/\/shar.es\/1P80hy",
      "display_url" : "shar.es\/1P80hy"
    } ]
  },
  "geo" : { },
  "id_str" : "927715336270548997",
  "text" : "RT @mfitri97: AMD To Develop Semi-Custom Graphics Chip For Intel  https:\/\/t.co\/7TVNgc5tYA via @tomshardware",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom's Hardware",
        "screen_name" : "tomshardware",
        "indices" : [ 80, 93 ],
        "id_str" : "17064514",
        "id" : 17064514
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/7TVNgc5tYA",
        "expanded_url" : "https:\/\/shar.es\/1P80hy",
        "display_url" : "shar.es\/1P80hy"
      } ]
    },
    "geo" : { },
    "id_str" : "927569584504180737",
    "text" : "AMD To Develop Semi-Custom Graphics Chip For Intel  https:\/\/t.co\/7TVNgc5tYA via @tomshardware",
    "id" : 927569584504180737,
    "created_at" : "2017-11-06 16:13:17 +0000",
    "user" : {
      "name" : "P3",
      "screen_name" : "mfitri97",
      "protected" : false,
      "id_str" : "439300804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917993326586073088\/jqw2vFR3_normal.jpg",
      "id" : 439300804,
      "verified" : false
    }
  },
  "id" : 927715336270548997,
  "created_at" : "2017-11-07 01:52:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Sierra",
      "screen_name" : "Jesss_Sierra",
      "indices" : [ 3, 16 ],
      "id_str" : "343804940",
      "id" : 343804940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927714523527761920",
  "text" : "RT @Jesss_Sierra: It\u2019s crazy how much your life can change in a month\u2019s time",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927174984027516928",
    "text" : "It\u2019s crazy how much your life can change in a month\u2019s time",
    "id" : 927174984027516928,
    "created_at" : "2017-11-05 14:05:16 +0000",
    "user" : {
      "name" : "Jessica Sierra",
      "screen_name" : "Jesss_Sierra",
      "protected" : false,
      "id_str" : "343804940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926810606665117696\/mg_yXEnt_normal.jpg",
      "id" : 343804940,
      "verified" : false
    }
  },
  "id" : 927714523527761920,
  "created_at" : "2017-11-07 01:49:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QQm86LsJYj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iFplPkZEbPw",
      "display_url" : "youtube.com\/watch?v=iFplPk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927714279830249472",
  "text" : "RT @Matthiasiam: Bonus video! I prank some people in the office that I dropped the iPhone X. Some great reactions XD https:\/\/t.co\/QQm86LsJYj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/QQm86LsJYj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iFplPkZEbPw",
        "display_url" : "youtube.com\/watch?v=iFplPk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926887494917881856",
    "text" : "Bonus video! I prank some people in the office that I dropped the iPhone X. Some great reactions XD https:\/\/t.co\/QQm86LsJYj",
    "id" : 926887494917881856,
    "created_at" : "2017-11-04 19:02:54 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 927714279830249472,
  "created_at" : "2017-11-07 01:48:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927714108056723456",
  "text" : "RT @jacksfilms: Finally upgrading from laptop to desktop as my editing rig. Only took me 11 years. Now I'll leave the house even LESS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927705281978441728",
    "text" : "Finally upgrading from laptop to desktop as my editing rig. Only took me 11 years. Now I'll leave the house even LESS",
    "id" : 927705281978441728,
    "created_at" : "2017-11-07 01:12:29 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927717097051799552\/zUMLDlBG_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 927714108056723456,
  "created_at" : "2017-11-07 01:47:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/naUYC77fgL",
      "expanded_url" : "http:\/\/engt.co\/2lXVfvj",
      "display_url" : "engt.co\/2lXVfvj"
    } ]
  },
  "geo" : { },
  "id_str" : "927714077861916672",
  "text" : "RT @engadget: The Lamborghini Terzo Millennio is a brutally fantastic EV supercar concept https:\/\/t.co\/naUYC77fgL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/naUYC77fgL",
        "expanded_url" : "http:\/\/engt.co\/2lXVfvj",
        "display_url" : "engt.co\/2lXVfvj"
      } ]
    },
    "geo" : { },
    "id_str" : "927700955751206913",
    "text" : "The Lamborghini Terzo Millennio is a brutally fantastic EV supercar concept https:\/\/t.co\/naUYC77fgL",
    "id" : 927700955751206913,
    "created_at" : "2017-11-07 00:55:18 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 927714077861916672,
  "created_at" : "2017-11-07 01:47:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927714064335241216",
  "text" : "RT @dronepilots: Advantech Wireless releases new Tactical SATCOM Network Architecture for Drones and UAVs | DronePilots - https:\/\/t.co\/2AJs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/2AJs5ITYZM",
        "expanded_url" : "http:\/\/ift.tt\/2j6mmTU",
        "display_url" : "ift.tt\/2j6mmTU"
      } ]
    },
    "geo" : { },
    "id_str" : "927712779020259328",
    "text" : "Advantech Wireless releases new Tactical SATCOM Network Architecture for Drones and UAVs | DronePilots - https:\/\/t.co\/2AJs5ITYZM #drones",
    "id" : 927712779020259328,
    "created_at" : "2017-11-07 01:42:17 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927714064335241216,
  "created_at" : "2017-11-07 01:47:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    }, {
      "name" : "Naomi Wu",
      "screen_name" : "RealSexyCyborg",
      "indices" : [ 26, 41 ],
      "id_str" : "3562121415",
      "id" : 3562121415
    }, {
      "name" : "Dale Dougherty",
      "screen_name" : "dalepd",
      "indices" : [ 80, 87 ],
      "id_str" : "14405393",
      "id" : 14405393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/krsEVfhFUG",
      "expanded_url" : "https:\/\/makezine.com\/2017\/11\/06\/open-note-to-naomi-wu\/",
      "display_url" : "makezine.com\/2017\/11\/06\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927714039198871557",
  "text" : "RT @make: An Open Note to @realsexycyborg Naomi Wu (and Makers everywhere) from @dalepd https:\/\/t.co\/krsEVfhFUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Naomi Wu",
        "screen_name" : "RealSexyCyborg",
        "indices" : [ 16, 31 ],
        "id_str" : "3562121415",
        "id" : 3562121415
      }, {
        "name" : "Dale Dougherty",
        "screen_name" : "dalepd",
        "indices" : [ 70, 77 ],
        "id_str" : "14405393",
        "id" : 14405393
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/krsEVfhFUG",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/06\/open-note-to-naomi-wu\/",
        "display_url" : "makezine.com\/2017\/11\/06\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927704288947855360",
    "text" : "An Open Note to @realsexycyborg Naomi Wu (and Makers everywhere) from @dalepd https:\/\/t.co\/krsEVfhFUG",
    "id" : 927704288947855360,
    "created_at" : "2017-11-07 01:08:33 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 927714039198871557,
  "created_at" : "2017-11-07 01:47:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF22\uFF32\uFF21\uFF2E\uFF24\uFF2F\uFF2E \uD83E\uDD83",
      "screen_name" : "BrandonBurner66",
      "indices" : [ 3, 19 ],
      "id_str" : "809725772466360320",
      "id" : 809725772466360320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ExplainFootballPoorly",
      "indices" : [ 90, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927684586078982145",
  "text" : "RT @BrandonBurner66: A reason to eat wings, drink beer, and get away from your girlfriend #ExplainFootballPoorly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ExplainFootballPoorly",
        "indices" : [ 69, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927630406115053568",
    "text" : "A reason to eat wings, drink beer, and get away from your girlfriend #ExplainFootballPoorly",
    "id" : 927630406115053568,
    "created_at" : "2017-11-06 20:14:58 +0000",
    "user" : {
      "name" : "\uFF22\uFF32\uFF21\uFF2E\uFF24\uFF2F\uFF2E \uD83E\uDD83",
      "screen_name" : "BrandonBurner66",
      "protected" : false,
      "id_str" : "809725772466360320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900895070106386433\/331-2vpb_normal.jpg",
      "id" : 809725772466360320,
      "verified" : false
    }
  },
  "id" : 927684586078982145,
  "created_at" : "2017-11-06 23:50:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927684502683561984\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/ld9q82Lhw1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DN_MIO0UMAEPdko.jpg",
      "id_str" : "927684490050154497",
      "id" : 927684490050154497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DN_MIO0UMAEPdko.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/ld9q82Lhw1"
    } ],
    "hashtags" : [ {
      "text" : "Blockchain",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "Dev",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "BTC",
      "indices" : [ 126, 130 ]
    }, {
      "text" : "Math",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/FLt0Gsq2YC",
      "expanded_url" : "http:\/\/mqtcrypto.com",
      "display_url" : "mqtcrypto.com"
    }, {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/zERjuiiXBp",
      "expanded_url" : "http:\/\/crowd-coin.org",
      "display_url" : "crowd-coin.org"
    } ]
  },
  "geo" : { },
  "id_str" : "927684502683561984",
  "text" : "Yes, we are working on the cryptocurrency revolution via https:\/\/t.co\/FLt0Gsq2YC and https:\/\/t.co\/zERjuiiXBp #Blockchain #Dev #BTC #Math https:\/\/t.co\/ld9q82Lhw1",
  "id" : 927684502683561984,
  "created_at" : "2017-11-06 23:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "potch",
      "screen_name" : "potch",
      "indices" : [ 3, 9 ],
      "id_str" : "15334840",
      "id" : 15334840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927683238021292032",
  "text" : "RT @potch: Good morning! I built a tool that helps you figure out how to port a Chrome extension to Firefox. Try it out! https:\/\/t.co\/z26bx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/z26bxB7mTk",
        "expanded_url" : "https:\/\/www.extensiontest.com\/",
        "display_url" : "extensiontest.com"
      } ]
    },
    "geo" : { },
    "id_str" : "900746114508312576",
    "text" : "Good morning! I built a tool that helps you figure out how to port a Chrome extension to Firefox. Try it out! https:\/\/t.co\/z26bxB7mTk",
    "id" : 900746114508312576,
    "created_at" : "2017-08-24 15:46:23 +0000",
    "user" : {
      "name" : "potch",
      "screen_name" : "potch",
      "protected" : false,
      "id_str" : "15334840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919024849132986369\/lFPxE7Hj_normal.jpg",
      "id" : 15334840,
      "verified" : false
    }
  },
  "id" : 927683238021292032,
  "created_at" : "2017-11-06 23:44:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge @ JSConf \uD83C\uDDE8\uD83C\uDDF4",
      "screen_name" : "javebratt",
      "indices" : [ 3, 13 ],
      "id_str" : "102394668",
      "id" : 102394668
    }, {
      "name" : "Firebase",
      "screen_name" : "Firebase",
      "indices" : [ 35, 44 ],
      "id_str" : "447644824",
      "id" : 447644824
    }, {
      "name" : "ionic",
      "screen_name" : "Ionicframework",
      "indices" : [ 71, 86 ],
      "id_str" : "1723662264",
      "id" : 1723662264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/mTd59ttegi",
      "expanded_url" : "https:\/\/javebratt.com\/cloud-firestore-intro\/",
      "display_url" : "javebratt.com\/cloud-firestor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927683134619111425",
  "text" : "RT @javebratt: Trying to integrate @Firebase Cloud Firestore into your @Ionicframework apps? https:\/\/t.co\/mTd59ttegi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Firebase",
        "screen_name" : "Firebase",
        "indices" : [ 20, 29 ],
        "id_str" : "447644824",
        "id" : 447644824
      }, {
        "name" : "ionic",
        "screen_name" : "Ionicframework",
        "indices" : [ 56, 71 ],
        "id_str" : "1723662264",
        "id" : 1723662264
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/mTd59ttegi",
        "expanded_url" : "https:\/\/javebratt.com\/cloud-firestore-intro\/",
        "display_url" : "javebratt.com\/cloud-firestor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "923914077684097024",
    "text" : "Trying to integrate @Firebase Cloud Firestore into your @Ionicframework apps? https:\/\/t.co\/mTd59ttegi",
    "id" : 923914077684097024,
    "created_at" : "2017-10-27 14:07:36 +0000",
    "user" : {
      "name" : "Jorge @ JSConf \uD83C\uDDE8\uD83C\uDDF4",
      "screen_name" : "javebratt",
      "protected" : false,
      "id_str" : "102394668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919207474003144705\/MNR0xyqD_normal.jpg",
      "id" : 102394668,
      "verified" : false
    }
  },
  "id" : 927683134619111425,
  "created_at" : "2017-11-06 23:44:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Geller",
      "screen_name" : "davidgeller",
      "indices" : [ 3, 15 ],
      "id_str" : "791258",
      "id" : 791258
    }, {
      "name" : "ionic",
      "screen_name" : "Ionicframework",
      "indices" : [ 71, 86 ],
      "id_str" : "1723662264",
      "id" : 1723662264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927683078214111232",
  "text" : "RT @davidgeller: Love the new CLI command \u201Cionic doctor check.\u201D Thanks @Ionicframework",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ionic",
        "screen_name" : "Ionicframework",
        "indices" : [ 54, 69 ],
        "id_str" : "1723662264",
        "id" : 1723662264
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925767990833954816",
    "text" : "Love the new CLI command \u201Cionic doctor check.\u201D Thanks @Ionicframework",
    "id" : 925767990833954816,
    "created_at" : "2017-11-01 16:54:23 +0000",
    "user" : {
      "name" : "David Geller",
      "screen_name" : "davidgeller",
      "protected" : false,
      "id_str" : "791258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422649920755998720\/kzoxs6qP_normal.png",
      "id" : 791258,
      "verified" : false
    }
  },
  "id" : 927683078214111232,
  "created_at" : "2017-11-06 23:44:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Shelton",
      "screen_name" : "tweenout",
      "indices" : [ 3, 12 ],
      "id_str" : "19594751",
      "id" : 19594751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ionic",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "ionicframework",
      "indices" : [ 62, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/eO1ZyTHLsi",
      "expanded_url" : "http:\/\/youtu.be\/MKXc_PYtWMY?a",
      "display_url" : "youtu.be\/MKXc_PYtWMY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927683043053228032",
  "text" : "RT @tweenout: Learn how to add headers to your list in #ionic #ionicframework https:\/\/t.co\/eO1ZyTHLsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ionic",
        "indices" : [ 41, 47 ]
      }, {
        "text" : "ionicframework",
        "indices" : [ 48, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/eO1ZyTHLsi",
        "expanded_url" : "http:\/\/youtu.be\/MKXc_PYtWMY?a",
        "display_url" : "youtu.be\/MKXc_PYtWMY?a"
      } ]
    },
    "geo" : { },
    "id_str" : "926452447232577536",
    "text" : "Learn how to add headers to your list in #ionic #ionicframework https:\/\/t.co\/eO1ZyTHLsi",
    "id" : 926452447232577536,
    "created_at" : "2017-11-03 14:14:10 +0000",
    "user" : {
      "name" : "Todd Shelton",
      "screen_name" : "tweenout",
      "protected" : false,
      "id_str" : "19594751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631123966\/ts_normal.jpg",
      "id" : 19594751,
      "verified" : false
    }
  },
  "id" : 927683043053228032,
  "created_at" : "2017-11-06 23:44:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angular News",
      "screen_name" : "AngularJS_News",
      "indices" : [ 3, 18 ],
      "id_str" : "1425295999",
      "id" : 1425295999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Angular",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/uZucR8WjL0",
      "expanded_url" : "https:\/\/themeforest.net\/item\/minotaur-angular-admin-dashboard\/19319935?ref=jobsi",
      "display_url" : "themeforest.net\/item\/minotaur-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927682987478650880",
  "text" : "RT @AngularJS_News: Deliver Faster! #Angular Code Repo: Minotaur - Angular Admin Dashboard Download now \uD83D\uDC49 https:\/\/t.co\/uZucR8WjL0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/huginn-muninn.herokuapp.com\" rel=\"nofollow\"\u003Ehuginn-muninn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Angular",
        "indices" : [ 16, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/uZucR8WjL0",
        "expanded_url" : "https:\/\/themeforest.net\/item\/minotaur-angular-admin-dashboard\/19319935?ref=jobsi",
        "display_url" : "themeforest.net\/item\/minotaur-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927661756100632577",
    "text" : "Deliver Faster! #Angular Code Repo: Minotaur - Angular Admin Dashboard Download now \uD83D\uDC49 https:\/\/t.co\/uZucR8WjL0",
    "id" : 927661756100632577,
    "created_at" : "2017-11-06 22:19:32 +0000",
    "user" : {
      "name" : "Angular News",
      "screen_name" : "AngularJS_News",
      "protected" : false,
      "id_str" : "1425295999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716053815133356032\/UIW3xmYm_normal.jpg",
      "id" : 1425295999,
      "verified" : false
    }
  },
  "id" : 927682987478650880,
  "created_at" : "2017-11-06 23:43:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angular News",
      "screen_name" : "AngularJS_News",
      "indices" : [ 3, 18 ],
      "id_str" : "1425295999",
      "id" : 1425295999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/u0ut1FtB5C",
      "expanded_url" : "https:\/\/jsup.io\/b\/angular-crash-course",
      "display_url" : "jsup.io\/b\/angular-cras\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927682975709396994",
  "text" : "RT @AngularJS_News: Meet your Angular Teacher.   Learn Angular in 10 hours! Enroll now \uD83D\uDC49 https:\/\/t.co\/u0ut1FtB5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/huginn-muninn.herokuapp.com\" rel=\"nofollow\"\u003Ehuginn-muninn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/u0ut1FtB5C",
        "expanded_url" : "https:\/\/jsup.io\/b\/angular-crash-course",
        "display_url" : "jsup.io\/b\/angular-cras\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927638506939338753",
    "text" : "Meet your Angular Teacher.   Learn Angular in 10 hours! Enroll now \uD83D\uDC49 https:\/\/t.co\/u0ut1FtB5C",
    "id" : 927638506939338753,
    "created_at" : "2017-11-06 20:47:09 +0000",
    "user" : {
      "name" : "Angular News",
      "screen_name" : "AngularJS_News",
      "protected" : false,
      "id_str" : "1425295999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716053815133356032\/UIW3xmYm_normal.jpg",
      "id" : 1425295999,
      "verified" : false
    }
  },
  "id" : 927682975709396994,
  "created_at" : "2017-11-06 23:43:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Android Developers",
      "screen_name" : "AndroidDev",
      "indices" : [ 3, 14 ],
      "id_str" : "93711247",
      "id" : 93711247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Android",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927682929337229318",
  "text" : "RT @AndroidDev: Today, we're excited to announce availability of the #Android Instant Apps SDK 1.1\n\nRead our blog here \u2193 https:\/\/t.co\/elGIk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Android",
        "indices" : [ 53, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/elGIk2L3I5",
        "expanded_url" : "http:\/\/goo.gl\/J7dujn",
        "display_url" : "goo.gl\/J7dujn"
      } ]
    },
    "geo" : { },
    "id_str" : "918589091909947399",
    "text" : "Today, we're excited to announce availability of the #Android Instant Apps SDK 1.1\n\nRead our blog here \u2193 https:\/\/t.co\/elGIk2L3I5",
    "id" : 918589091909947399,
    "created_at" : "2017-10-12 21:28:00 +0000",
    "user" : {
      "name" : "Android Developers",
      "screen_name" : "AndroidDev",
      "protected" : false,
      "id_str" : "93711247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606585229034135553\/2NqZJYQI_normal.png",
      "id" : 93711247,
      "verified" : true
    }
  },
  "id" : 927682929337229318,
  "created_at" : "2017-11-06 23:43:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927682685086109696",
  "text" : "RT @make: Check out these two engineering students who are on a mission to spread the good word of the maker movement https:\/\/t.co\/Fnf4MNKj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/Fnf4MNKjel",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/04\/weekend-watch-beauty-and-the-bolt\/",
        "display_url" : "makezine.com\/2017\/11\/04\/wee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927585195326394368",
    "text" : "Check out these two engineering students who are on a mission to spread the good word of the maker movement https:\/\/t.co\/Fnf4MNKjel",
    "id" : 927585195326394368,
    "created_at" : "2017-11-06 17:15:18 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 927682685086109696,
  "created_at" : "2017-11-06 23:42:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927682647324872704",
  "text" : "RT @make: Whether you're moving to NY or been living there your whole life, this guide will help you discover some new spots https:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/dbPgaEW2UY",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/06\/makers-guide-rochester-new-york\/",
        "display_url" : "makezine.com\/2017\/11\/06\/mak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927620387311112192",
    "text" : "Whether you're moving to NY or been living there your whole life, this guide will help you discover some new spots https:\/\/t.co\/dbPgaEW2UY",
    "id" : 927620387311112192,
    "created_at" : "2017-11-06 19:35:09 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 927682647324872704,
  "created_at" : "2017-11-06 23:42:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIY Drones",
      "screen_name" : "DIYDrones",
      "indices" : [ 3, 13 ],
      "id_str" : "72769277",
      "id" : 72769277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/FUM3O7fcdB",
      "expanded_url" : "http:\/\/ift.tt\/2hvyx8X",
      "display_url" : "ift.tt\/2hvyx8X"
    } ]
  },
  "geo" : { },
  "id_str" : "927682610230382592",
  "text" : "RT @DIYDrones: What are the 5 Top Beginner Drone Kits You Can Buy in 2017 to Learn and Build Your Drone https:\/\/t.co\/FUM3O7fcdB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/FUM3O7fcdB",
        "expanded_url" : "http:\/\/ift.tt\/2hvyx8X",
        "display_url" : "ift.tt\/2hvyx8X"
      } ]
    },
    "geo" : { },
    "id_str" : "925784440730804229",
    "text" : "What are the 5 Top Beginner Drone Kits You Can Buy in 2017 to Learn and Build Your Drone https:\/\/t.co\/FUM3O7fcdB",
    "id" : 925784440730804229,
    "created_at" : "2017-11-01 17:59:45 +0000",
    "user" : {
      "name" : "DIY Drones",
      "screen_name" : "DIYDrones",
      "protected" : false,
      "id_str" : "72769277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000634208070\/7dfb8a0c9178e854734254922822fdb2_normal.jpeg",
      "id" : 72769277,
      "verified" : false
    }
  },
  "id" : 927682610230382592,
  "created_at" : "2017-11-06 23:42:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIY Drones",
      "screen_name" : "DIYDrones",
      "indices" : [ 3, 13 ],
      "id_str" : "72769277",
      "id" : 72769277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/14DIHYxVrB",
      "expanded_url" : "http:\/\/ift.tt\/2hhu5h6",
      "display_url" : "ift.tt\/2hhu5h6"
    } ]
  },
  "geo" : { },
  "id_str" : "927682590110289920",
  "text" : "RT @DIYDrones: Autonomous boat to sail across the Atlantic \u2013 Proof of concept https:\/\/t.co\/14DIHYxVrB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/14DIHYxVrB",
        "expanded_url" : "http:\/\/ift.tt\/2hhu5h6",
        "display_url" : "ift.tt\/2hhu5h6"
      } ]
    },
    "geo" : { },
    "id_str" : "927654360213020677",
    "text" : "Autonomous boat to sail across the Atlantic \u2013 Proof of concept https:\/\/t.co\/14DIHYxVrB",
    "id" : 927654360213020677,
    "created_at" : "2017-11-06 21:50:09 +0000",
    "user" : {
      "name" : "DIY Drones",
      "screen_name" : "DIYDrones",
      "protected" : false,
      "id_str" : "72769277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000634208070\/7dfb8a0c9178e854734254922822fdb2_normal.jpeg",
      "id" : 72769277,
      "verified" : false
    }
  },
  "id" : 927682590110289920,
  "created_at" : "2017-11-06 23:42:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927682508841504769\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/i89ru2GI7c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_KUmCUQAAfki3.jpg",
      "id_str" : "927682503418068992",
      "id" : 927682503418068992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_KUmCUQAAfki3.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/i89ru2GI7c"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/dEEb3Zc2DK",
      "expanded_url" : "http:\/\/platinumskincare.com",
      "display_url" : "platinumskincare.com"
    } ]
  },
  "geo" : { },
  "id_str" : "927682508841504769",
  "text" : "Wanna get rid of those pesky stretch marks? via https:\/\/t.co\/dEEb3Zc2DK https:\/\/t.co\/i89ru2GI7c",
  "id" : 927682508841504769,
  "created_at" : "2017-11-06 23:42:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "Geneia@home",
      "screen_name" : "home",
      "indices" : [ 102, 107 ],
      "id_str" : "2817995382",
      "id" : 2817995382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/FuWz4LSgQl",
      "expanded_url" : "http:\/\/phy.so\/429208711",
      "display_url" : "phy.so\/429208711"
    } ]
  },
  "geo" : { },
  "id_str" : "927682272257601537",
  "text" : "RT @physorg_com: Beyond good vibrations: New insights into metamaterial magic https:\/\/t.co\/FuWz4LSgQl @home",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geneia@home",
        "screen_name" : "home",
        "indices" : [ 85, 90 ],
        "id_str" : "2817995382",
        "id" : 2817995382
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/FuWz4LSgQl",
        "expanded_url" : "http:\/\/phy.so\/429208711",
        "display_url" : "phy.so\/429208711"
      } ]
    },
    "geo" : { },
    "id_str" : "927651522485391360",
    "text" : "Beyond good vibrations: New insights into metamaterial magic https:\/\/t.co\/FuWz4LSgQl @home",
    "id" : 927651522485391360,
    "created_at" : "2017-11-06 21:38:52 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 927682272257601537,
  "created_at" : "2017-11-06 23:41:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927682004551917568\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/rjzyxUpUae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_JwuBVoAA4Ipu.jpg",
      "id_str" : "927681887086157824",
      "id" : 927681887086157824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_JwuBVoAA4Ipu.jpg",
      "sizes" : [ {
        "h" : 1367,
        "resize" : "fit",
        "w" : 1394
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1367,
        "resize" : "fit",
        "w" : 1394
      }, {
        "h" : 1177,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/rjzyxUpUae"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927682004551917568\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/rjzyxUpUae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_Jz1JUMAAfZNE.jpg",
      "id_str" : "927681940538273792",
      "id" : 927681940538273792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_Jz1JUMAAfZNE.jpg",
      "sizes" : [ {
        "h" : 501,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3018,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1509,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/rjzyxUpUae"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927682004551917568\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/rjzyxUpUae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_J28uU8AAauOR.jpg",
      "id_str" : "927681994112167936",
      "id" : 927681994112167936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_J28uU8AAauOR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rjzyxUpUae"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/kToLot5mnb",
      "expanded_url" : "http:\/\/bit.ly\/2zoJTpe",
      "display_url" : "bit.ly\/2zoJTpe"
    } ]
  },
  "geo" : { },
  "id_str" : "927682004551917568",
  "text" : "Many people are saying it is all about grip via https:\/\/t.co\/kToLot5mnb https:\/\/t.co\/rjzyxUpUae",
  "id" : 927682004551917568,
  "created_at" : "2017-11-06 23:40:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "AAS Publishing",
      "screen_name" : "AAS_Publishing",
      "indices" : [ 122, 137 ],
      "id_str" : "2859178324",
      "id" : 2859178324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1zBgoh9HUJ",
      "expanded_url" : "http:\/\/phy.so\/429211104",
      "display_url" : "phy.so\/429211104"
    } ]
  },
  "geo" : { },
  "id_str" : "927679526892703744",
  "text" : "RT @physorg_com: 18-month twinkle in a forming star suggests the existence of a very young planet https:\/\/t.co\/1zBgoh9HUJ @AAS_Publishing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AAS Publishing",
        "screen_name" : "AAS_Publishing",
        "indices" : [ 105, 120 ],
        "id_str" : "2859178324",
        "id" : 2859178324
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/1zBgoh9HUJ",
        "expanded_url" : "http:\/\/phy.so\/429211104",
        "display_url" : "phy.so\/429211104"
      } ]
    },
    "geo" : { },
    "id_str" : "927661511736209418",
    "text" : "18-month twinkle in a forming star suggests the existence of a very young planet https:\/\/t.co\/1zBgoh9HUJ @AAS_Publishing",
    "id" : 927661511736209418,
    "created_at" : "2017-11-06 22:18:34 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 927679526892703744,
  "created_at" : "2017-11-06 23:30:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/zBpoQnw6jq",
      "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/lilly-and-curevac-to-collaborate-on-mrna-cancer-vaccines\/3008234.article",
      "display_url" : "chemistryworld.com\/news\/lilly-and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927679449587429376",
  "text" : "RT @ChemistryWorld: Lilly and CureVac join forces to develop up to five mRNA cancer vaccines https:\/\/t.co\/zBpoQnw6jq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/zBpoQnw6jq",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/lilly-and-curevac-to-collaborate-on-mrna-cancer-vaccines\/3008234.article",
        "display_url" : "chemistryworld.com\/news\/lilly-and\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927527236797788160",
    "text" : "Lilly and CureVac join forces to develop up to five mRNA cancer vaccines https:\/\/t.co\/zBpoQnw6jq",
    "id" : 927527236797788160,
    "created_at" : "2017-11-06 13:25:00 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 927679449587429376,
  "created_at" : "2017-11-06 23:29:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wavesplatform",
      "screen_name" : "wavesplatform",
      "indices" : [ 3, 17 ],
      "id_str" : "707515829798182912",
      "id" : 707515829798182912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927679375566352385",
  "text" : "RT @wavesplatform: Nov.6 is official holidays in Russia, $WAVES team will be back on Tuesday :) Join Waves-NG stress test on Wednesday! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/BClC4BsiB5",
        "expanded_url" : "https:\/\/waves-ng.wavesplatform.com\/",
        "display_url" : "waves-ng.wavesplatform.com"
      } ]
    },
    "geo" : { },
    "id_str" : "927268767746404352",
    "text" : "Nov.6 is official holidays in Russia, $WAVES team will be back on Tuesday :) Join Waves-NG stress test on Wednesday! https:\/\/t.co\/BClC4BsiB5",
    "id" : 927268767746404352,
    "created_at" : "2017-11-05 20:17:56 +0000",
    "user" : {
      "name" : "wavesplatform",
      "screen_name" : "wavesplatform",
      "protected" : false,
      "id_str" : "707515829798182912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747698942561894400\/aBT9ePdS_normal.jpg",
      "id" : 707515829798182912,
      "verified" : false
    }
  },
  "id" : 927679375566352385,
  "created_at" : "2017-11-06 23:29:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927679321069752321",
  "text" : "RT @dronepilots: UAV Drones Market Analysis, Recent Trends And Regional Growth Forecast By Types And Applications 2017 | DronePilots - \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927672858435825664",
    "text" : "UAV Drones Market Analysis, Recent Trends And Regional Growth Forecast By Types And Applications 2017 | DronePilots - \u2026",
    "id" : 927672858435825664,
    "created_at" : "2017-11-06 23:03:39 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927679321069752321,
  "created_at" : "2017-11-06 23:29:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ygIrx52jUu",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/06\/film-test-shows-greatly-improved-new-polaroid-originals-color-films\/",
      "display_url" : "thephoblographer.com\/2017\/11\/06\/fil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927679232515461120",
  "text" : "RT @JayHoque: Film Test Shows Greatly Improved New Polaroid Originals Color Films: https:\/\/t.co\/ygIrx52jUu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/ygIrx52jUu",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/06\/film-test-shows-greatly-improved-new-polaroid-originals-color-films\/",
        "display_url" : "thephoblographer.com\/2017\/11\/06\/fil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927679185484746752",
    "text" : "Film Test Shows Greatly Improved New Polaroid Originals Color Films: https:\/\/t.co\/ygIrx52jUu",
    "id" : 927679185484746752,
    "created_at" : "2017-11-06 23:28:47 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927679232515461120,
  "created_at" : "2017-11-06 23:28:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927679136511987712\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/1WwJ8wgoJq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN_HJwwV4AAH7Ro.jpg",
      "id_str" : "927679018782023680",
      "id" : 927679018782023680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN_HJwwV4AAH7Ro.jpg",
      "sizes" : [ {
        "h" : 457,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1656
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1656
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1WwJ8wgoJq"
    } ],
    "hashtags" : [ {
      "text" : "Activewear",
      "indices" : [ 57, 68 ]
    }, {
      "text" : "fitness",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/vpX2YoIIZ8",
      "expanded_url" : "https:\/\/youtu.be\/l-a3sDPV6VI",
      "display_url" : "youtu.be\/l-a3sDPV6VI"
    } ]
  },
  "geo" : { },
  "id_str" : "927679136511987712",
  "text" : "Where fashion meets function via https:\/\/t.co\/vpX2YoIIZ8 #Activewear #fitness https:\/\/t.co\/1WwJ8wgoJq",
  "id" : 927679136511987712,
  "created_at" : "2017-11-06 23:28:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barefoot",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "fitness",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/nPlsPnvBv1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=l-a3sDPV6VI",
      "display_url" : "youtube.com\/watch?v=l-a3sD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927678382674006017",
  "text" : "Check out this lady's cool footwear business for Yoga and active wear #barefoot #fitness: https:\/\/t.co\/nPlsPnvBv1",
  "id" : 927678382674006017,
  "created_at" : "2017-11-06 23:25:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omar",
      "screen_name" : "socialchanger",
      "indices" : [ 3, 17 ],
      "id_str" : "65772802",
      "id" : 65772802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "df17",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927633562320457728",
  "text" : "RT @socialchanger: \u201CPutting everything in one place doesn\u2019t sound revolutionary. Until you do it.\u201D \u20146th gr teacher Mike Rutherford at #df17\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salesforce.org",
        "screen_name" : "SalesforceOrg",
        "indices" : [ 126, 140 ],
        "id_str" : "36958179",
        "id" : 36958179
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "df17",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "k12",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927631550006542337",
    "text" : "\u201CPutting everything in one place doesn\u2019t sound revolutionary. Until you do it.\u201D \u20146th gr teacher Mike Rutherford at #df17 #k12 @SalesforceOrg",
    "id" : 927631550006542337,
    "created_at" : "2017-11-06 20:19:30 +0000",
    "user" : {
      "name" : "Omar",
      "screen_name" : "socialchanger",
      "protected" : false,
      "id_str" : "65772802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748730190201647104\/NHIdFBHg_normal.jpg",
      "id" : 65772802,
      "verified" : false
    }
  },
  "id" : 927633562320457728,
  "created_at" : "2017-11-06 20:27:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Ch8t6X0DIL",
      "expanded_url" : "http:\/\/engt.co\/2lXz5cr",
      "display_url" : "engt.co\/2lXz5cr"
    } ]
  },
  "geo" : { },
  "id_str" : "927633479986241538",
  "text" : "RT @engadget: AT&amp;T's 'Flying COW' drone provides cell service to Puerto Rico https:\/\/t.co\/Ch8t6X0DIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Ch8t6X0DIL",
        "expanded_url" : "http:\/\/engt.co\/2lXz5cr",
        "display_url" : "engt.co\/2lXz5cr"
      } ]
    },
    "geo" : { },
    "id_str" : "927632855001370624",
    "text" : "AT&amp;T's 'Flying COW' drone provides cell service to Puerto Rico https:\/\/t.co\/Ch8t6X0DIL",
    "id" : 927632855001370624,
    "created_at" : "2017-11-06 20:24:41 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 927633479986241538,
  "created_at" : "2017-11-06 20:27:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927632412904972290",
  "text" : "RT @BarbaraCorcoran: All the best entrepreneurs are not working to become rich, they\u2019re working to solve something.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927629228203560960",
    "text" : "All the best entrepreneurs are not working to become rich, they\u2019re working to solve something.",
    "id" : 927629228203560960,
    "created_at" : "2017-11-06 20:10:17 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 927632412904972290,
  "created_at" : "2017-11-06 20:22:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ghCmtFAOwo",
      "expanded_url" : "http:\/\/engt.co\/2zj358g",
      "display_url" : "engt.co\/2zj358g"
    } ]
  },
  "geo" : { },
  "id_str" : "927629412614500353",
  "text" : "RT @engadget: Uber will donate $5 million to sexual assault prevention https:\/\/t.co\/ghCmtFAOwo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ghCmtFAOwo",
        "expanded_url" : "http:\/\/engt.co\/2zj358g",
        "display_url" : "engt.co\/2zj358g"
      } ]
    },
    "geo" : { },
    "id_str" : "927617860209446913",
    "text" : "Uber will donate $5 million to sexual assault prevention https:\/\/t.co\/ghCmtFAOwo",
    "id" : 927617860209446913,
    "created_at" : "2017-11-06 19:25:06 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 927629412614500353,
  "created_at" : "2017-11-06 20:11:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "AOC Gaming",
      "screen_name" : "AOC_Gaming",
      "indices" : [ 20, 31 ],
      "id_str" : "2461989242",
      "id" : 2461989242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gaming",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/htIzFJ0mqy",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/aoc-ag352ucg-curved-g-sync-gaming-monitor,5280.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/aoc-ag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927629129515663363",
  "text" : "RT @tomshardware: \u25B8 @AOC_Gaming AG352UCG Curved G-Sync #Gaming Monitor Review https:\/\/t.co\/htIzFJ0mqy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AOC Gaming",
        "screen_name" : "AOC_Gaming",
        "indices" : [ 2, 13 ],
        "id_str" : "2461989242",
        "id" : 2461989242
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gaming",
        "indices" : [ 37, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/htIzFJ0mqy",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/aoc-ag352ucg-curved-g-sync-gaming-monitor,5280.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/aoc-ag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927538087294525440",
    "text" : "\u25B8 @AOC_Gaming AG352UCG Curved G-Sync #Gaming Monitor Review https:\/\/t.co\/htIzFJ0mqy",
    "id" : 927538087294525440,
    "created_at" : "2017-11-06 14:08:07 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927629129515663363,
  "created_at" : "2017-11-06 20:09:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "indices" : [ 3, 15 ],
      "id_str" : "912653647036715008",
      "id" : 912653647036715008
    }, {
      "name" : "Rob Miles",
      "screen_name" : "robmiles",
      "indices" : [ 20, 29 ],
      "id_str" : "2479801",
      "id" : 2479801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927628923692863488",
  "text" : "RT @CodePenYork: Hi @robmiles fancy showing off your Pixelbots at the our CodePen show &amp; tell on 16\/11?! \uD83D\uDE03",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Miles",
        "screen_name" : "robmiles",
        "indices" : [ 3, 12 ],
        "id_str" : "2479801",
        "id" : 2479801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927506492311425024",
    "text" : "Hi @robmiles fancy showing off your Pixelbots at the our CodePen show &amp; tell on 16\/11?! \uD83D\uDE03",
    "id" : 927506492311425024,
    "created_at" : "2017-11-06 12:02:34 +0000",
    "user" : {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "protected" : false,
      "id_str" : "912653647036715008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916985186948190208\/1oFbpvDO_normal.jpg",
      "id" : 912653647036715008,
      "verified" : false
    }
  },
  "id" : 927628923692863488,
  "created_at" : "2017-11-06 20:09:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Miles",
      "screen_name" : "robmiles",
      "indices" : [ 3, 12 ],
      "id_str" : "2479801",
      "id" : 2479801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/DSZDW4dm5b",
      "expanded_url" : "http:\/\/www.robmiles.com\/journal\/2017\/10\/25\/cqrs",
      "display_url" : "robmiles.com\/journal\/2017\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927628915165794304",
  "text" : "RT @robmiles: CQPRS and Event Sourcing at Hull Developers  https:\/\/t.co\/DSZDW4dm5b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.squarespace.com\" rel=\"nofollow\"\u003ESquarespace\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/DSZDW4dm5b",
        "expanded_url" : "http:\/\/www.robmiles.com\/journal\/2017\/10\/25\/cqrs",
        "display_url" : "robmiles.com\/journal\/2017\/1\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.76964, -0.36716499999999996 ]
    },
    "id_str" : "923627871616331776",
    "text" : "CQPRS and Event Sourcing at Hull Developers  https:\/\/t.co\/DSZDW4dm5b",
    "id" : 923627871616331776,
    "created_at" : "2017-10-26 19:10:19 +0000",
    "user" : {
      "name" : "Rob Miles",
      "screen_name" : "robmiles",
      "protected" : false,
      "id_str" : "2479801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/150108107\/me2_normal.jpg",
      "id" : 2479801,
      "verified" : false
    }
  },
  "id" : 927628915165794304,
  "created_at" : "2017-11-06 20:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Miles",
      "screen_name" : "robmiles",
      "indices" : [ 3, 12 ],
      "id_str" : "2479801",
      "id" : 2479801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/N1qjA0K60p",
      "expanded_url" : "http:\/\/www.robmiles.com\/journal\/2017\/10\/27\/lora-gateway-live",
      "display_url" : "robmiles.com\/journal\/2017\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927628882790043648",
  "text" : "RT @robmiles: Lora Gateway Live  https:\/\/t.co\/N1qjA0K60p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.squarespace.com\" rel=\"nofollow\"\u003ESquarespace\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/N1qjA0K60p",
        "expanded_url" : "http:\/\/www.robmiles.com\/journal\/2017\/10\/27\/lora-gateway-live",
        "display_url" : "robmiles.com\/journal\/2017\/1\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.76964, -0.36716499999999996 ]
    },
    "id_str" : "924000624181698561",
    "text" : "Lora Gateway Live  https:\/\/t.co\/N1qjA0K60p",
    "id" : 924000624181698561,
    "created_at" : "2017-10-27 19:51:30 +0000",
    "user" : {
      "name" : "Rob Miles",
      "screen_name" : "robmiles",
      "protected" : false,
      "id_str" : "2479801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/150108107\/me2_normal.jpg",
      "id" : 2479801,
      "verified" : false
    }
  },
  "id" : 927628882790043648,
  "created_at" : "2017-11-06 20:08:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "indices" : [ 3, 15 ],
      "id_str" : "912653647036715008",
      "id" : 912653647036715008
    }, {
      "name" : "CodePen.IO",
      "screen_name" : "CodePen",
      "indices" : [ 30, 38 ],
      "id_str" : "517021184",
      "id" : 517021184
    }, {
      "name" : "University of York",
      "screen_name" : "UniOfYork",
      "indices" : [ 66, 76 ],
      "id_str" : "27035508",
      "id" : 27035508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ATEmtBxYnU",
      "expanded_url" : "http:\/\/nvite.co\/zd3yj1",
      "display_url" : "nvite.co\/zd3yj1"
    } ]
  },
  "geo" : { },
  "id_str" : "927628756163940353",
  "text" : "RT @CodePenYork: York's first @CodePen Show and Tell will be held @UniofYork, 16 Nov 6:30-9:30pm RSVP today! https:\/\/t.co\/ATEmtBxYnU #codep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CodePen.IO",
        "screen_name" : "CodePen",
        "indices" : [ 13, 21 ],
        "id_str" : "517021184",
        "id" : 517021184
      }, {
        "name" : "University of York",
        "screen_name" : "UniOfYork",
        "indices" : [ 49, 59 ],
        "id_str" : "27035508",
        "id" : 27035508
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "codepenyork",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/ATEmtBxYnU",
        "expanded_url" : "http:\/\/nvite.co\/zd3yj1",
        "display_url" : "nvite.co\/zd3yj1"
      } ]
    },
    "geo" : { },
    "id_str" : "916987174339346433",
    "text" : "York's first @CodePen Show and Tell will be held @UniofYork, 16 Nov 6:30-9:30pm RSVP today! https:\/\/t.co\/ATEmtBxYnU #codepenyork",
    "id" : 916987174339346433,
    "created_at" : "2017-10-08 11:22:33 +0000",
    "user" : {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "protected" : false,
      "id_str" : "912653647036715008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916985186948190208\/1oFbpvDO_normal.jpg",
      "id" : 912653647036715008,
      "verified" : false
    }
  },
  "id" : 927628756163940353,
  "created_at" : "2017-11-06 20:08:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Qq5jyb6mvZ",
      "expanded_url" : "https:\/\/www.photographytalk.com\/post-processing\/7996-five-new-things-in-photoshop-cc-2018-that-you-must-know",
      "display_url" : "photographytalk.com\/post-processin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927628517562609666",
  "text" : "RT @PhotographyTalk: For those of you that missed the memo, Photoshop CC 2018 recently came out.\n\nhttps:\/\/t.co\/Qq5jyb6mvZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Qq5jyb6mvZ",
        "expanded_url" : "https:\/\/www.photographytalk.com\/post-processing\/7996-five-new-things-in-photoshop-cc-2018-that-you-must-know",
        "display_url" : "photographytalk.com\/post-processin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926906523925827585",
    "text" : "For those of you that missed the memo, Photoshop CC 2018 recently came out.\n\nhttps:\/\/t.co\/Qq5jyb6mvZ",
    "id" : 926906523925827585,
    "created_at" : "2017-11-04 20:18:31 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 927628517562609666,
  "created_at" : "2017-11-06 20:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jPJR9PPoWC",
      "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7993-this-photographer-waits-for-people-to-interact-with-famous-artworks-and-the-results-are-amazing",
      "display_url" : "photographytalk.com\/photography-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927628494250696705",
  "text" : "RT @PhotographyTalk: French photographer Stefan Draschan has come up with a wildly entertaining type of photography\n\nhttps:\/\/t.co\/jPJR9PPoWC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/jPJR9PPoWC",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7993-this-photographer-waits-for-people-to-interact-with-famous-artworks-and-the-results-are-amazing",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927148193724489728",
    "text" : "French photographer Stefan Draschan has come up with a wildly entertaining type of photography\n\nhttps:\/\/t.co\/jPJR9PPoWC",
    "id" : 927148193724489728,
    "created_at" : "2017-11-05 12:18:49 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 927628494250696705,
  "created_at" : "2017-11-06 20:07:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marilynn",
      "screen_name" : "marilynnrox",
      "indices" : [ 3, 15 ],
      "id_str" : "486181298",
      "id" : 486181298
    }, {
      "name" : "Dina",
      "screen_name" : "dina_ess",
      "indices" : [ 17, 26 ],
      "id_str" : "146678916",
      "id" : 146678916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927628436583133184",
  "text" : "RT @marilynnrox: @dina_ess 1 Corinthians 12:11 but all these worketh that one and the selfsame Spirit, dividing to every man severally as h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dina",
        "screen_name" : "dina_ess",
        "indices" : [ 0, 9 ],
        "id_str" : "146678916",
        "id" : 146678916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "927578968106176513",
    "geo" : { },
    "id_str" : "927626738108194822",
    "in_reply_to_user_id" : 146678916,
    "text" : "@dina_ess 1 Corinthians 12:11 but all these worketh that one and the selfsame Spirit, dividing to every man severally as he will",
    "id" : 927626738108194822,
    "in_reply_to_status_id" : 927578968106176513,
    "created_at" : "2017-11-06 20:00:23 +0000",
    "in_reply_to_screen_name" : "dina_ess",
    "in_reply_to_user_id_str" : "146678916",
    "user" : {
      "name" : "marilynn",
      "screen_name" : "marilynnrox",
      "protected" : false,
      "id_str" : "486181298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927292704542855168\/GWs9MBSW_normal.jpg",
      "id" : 486181298,
      "verified" : false
    }
  },
  "id" : 927628436583133184,
  "created_at" : "2017-11-06 20:07:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gab",
      "screen_name" : "getongab",
      "indices" : [ 0, 9 ],
      "id_str" : "767960339547774976",
      "id" : 767960339547774976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927628320098963456",
  "in_reply_to_user_id" : 767960339547774976,
  "text" : "@getongab I sent a request for account verification and no reply back after a week or way to check on the status :(",
  "id" : 927628320098963456,
  "created_at" : "2017-11-06 20:06:40 +0000",
  "in_reply_to_screen_name" : "getongab",
  "in_reply_to_user_id_str" : "767960339547774976",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Gt8NwioxHX",
      "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/06\/photographed-iss-crossing-full-moon\/",
      "display_url" : "petapixel.com\/2017\/11\/06\/pho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927627811191513089",
  "text" : "RT @JayHoque: I Photographed the ISS Crossing the Full Moon: https:\/\/t.co\/Gt8NwioxHX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/Gt8NwioxHX",
        "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/06\/photographed-iss-crossing-full-moon\/",
        "display_url" : "petapixel.com\/2017\/11\/06\/pho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927627486980116481",
    "text" : "I Photographed the ISS Crossing the Full Moon: https:\/\/t.co\/Gt8NwioxHX",
    "id" : 927627486980116481,
    "created_at" : "2017-11-06 20:03:22 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927627811191513089,
  "created_at" : "2017-11-06 20:04:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DroneGames",
      "screen_name" : "dronegamescom",
      "indices" : [ 3, 17 ],
      "id_str" : "3232393167",
      "id" : 3232393167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/nRL0o13p19",
      "expanded_url" : "http:\/\/ift.tt\/2iADhtV",
      "display_url" : "ift.tt\/2iADhtV"
    } ]
  },
  "geo" : { },
  "id_str" : "927627763376427008",
  "text" : "RT @dronegamescom: Police drone finds lost hunter near Byron | DroneGames - https:\/\/t.co\/nRL0o13p19 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/nRL0o13p19",
        "expanded_url" : "http:\/\/ift.tt\/2iADhtV",
        "display_url" : "ift.tt\/2iADhtV"
      } ]
    },
    "geo" : { },
    "id_str" : "927581207319244800",
    "text" : "Police drone finds lost hunter near Byron | DroneGames - https:\/\/t.co\/nRL0o13p19 #drones",
    "id" : 927581207319244800,
    "created_at" : "2017-11-06 16:59:28 +0000",
    "user" : {
      "name" : "DroneGames",
      "screen_name" : "dronegamescom",
      "protected" : false,
      "id_str" : "3232393167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595269305509412864\/cUKvaUKK_normal.png",
      "id" : 3232393167,
      "verified" : false
    }
  },
  "id" : 927627763376427008,
  "created_at" : "2017-11-06 20:04:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lNUpjKqJCj",
      "expanded_url" : "http:\/\/ift.tt\/2hik0AP",
      "display_url" : "ift.tt\/2hik0AP"
    } ]
  },
  "geo" : { },
  "id_str" : "927627634665717760",
  "text" : "RT @dronepilots: Drone Golf Championship Takes Place in Turkey | DronePilots - https:\/\/t.co\/lNUpjKqJCj #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/lNUpjKqJCj",
        "expanded_url" : "http:\/\/ift.tt\/2hik0AP",
        "display_url" : "ift.tt\/2hik0AP"
      } ]
    },
    "geo" : { },
    "id_str" : "927612075337187328",
    "text" : "Drone Golf Championship Takes Place in Turkey | DronePilots - https:\/\/t.co\/lNUpjKqJCj #drones",
    "id" : 927612075337187328,
    "created_at" : "2017-11-06 19:02:07 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927627634665717760,
  "created_at" : "2017-11-06 20:03:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ijMdaaYpIT",
      "expanded_url" : "http:\/\/ift.tt\/2hLgxI0",
      "display_url" : "ift.tt\/2hLgxI0"
    } ]
  },
  "geo" : { },
  "id_str" : "927627601811828736",
  "text" : "RT @dronepilots: Drone-Mixology: Meet Your Aerial Bartender | DronePilots - https:\/\/t.co\/ijMdaaYpIT #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/ijMdaaYpIT",
        "expanded_url" : "http:\/\/ift.tt\/2hLgxI0",
        "display_url" : "ift.tt\/2hLgxI0"
      } ]
    },
    "geo" : { },
    "id_str" : "927621817329647617",
    "text" : "Drone-Mixology: Meet Your Aerial Bartender | DronePilots - https:\/\/t.co\/ijMdaaYpIT #drones",
    "id" : 927621817329647617,
    "created_at" : "2017-11-06 19:40:50 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927627601811828736,
  "created_at" : "2017-11-06 20:03:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dina",
      "screen_name" : "dina_ess",
      "indices" : [ 3, 12 ],
      "id_str" : "146678916",
      "id" : 146678916
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 14, 26 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927627486162292736",
  "text" : "RT @dina_ess: @gamer456148 Ah thank you. \nYeah, he's clearly not trying to understand!! Lol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "927626762951057409",
    "geo" : { },
    "id_str" : "927627443443290115",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Ah thank you. \nYeah, he's clearly not trying to understand!! Lol",
    "id" : 927627443443290115,
    "in_reply_to_status_id" : 927626762951057409,
    "created_at" : "2017-11-06 20:03:11 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Dina",
      "screen_name" : "dina_ess",
      "protected" : false,
      "id_str" : "146678916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918463272935968770\/-gzS4s2m_normal.jpg",
      "id" : 146678916,
      "verified" : false
    }
  },
  "id" : 927627486162292736,
  "created_at" : "2017-11-06 20:03:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 3, 12 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927627166413721601",
  "text" : "RT @makerbot: With MakerBot, Montclair School District students are experiencing 3D printing from elementary through high school.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927626652967948288",
    "text" : "With MakerBot, Montclair School District students are experiencing 3D printing from elementary through high school.",
    "id" : 927626652967948288,
    "created_at" : "2017-11-06 20:00:03 +0000",
    "user" : {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "protected" : false,
      "id_str" : "22021097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458718156517679104\/9XyyKdC6_normal.jpeg",
      "id" : 22021097,
      "verified" : true
    }
  },
  "id" : 927627166413721601,
  "created_at" : "2017-11-06 20:02:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 3, 10 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/gDsxlOon2e",
      "expanded_url" : "https:\/\/www.forbes.com\/sites\/lizryan\/2017\/05\/19\/smart-job-seekers-break-these-ten-resume-writing-rules\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
      "display_url" : "forbes.com\/sites\/lizryan\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927627121228500992",
  "text" : "RT @Forbes: Smart Job Seekers Break These Ten Resume-Writing Rules https:\/\/t.co\/gDsxlOon2e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.forbes.com\" rel=\"nofollow\"\u003EMalorie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/gDsxlOon2e",
        "expanded_url" : "https:\/\/www.forbes.com\/sites\/lizryan\/2017\/05\/19\/smart-job-seekers-break-these-ten-resume-writing-rules\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
        "display_url" : "forbes.com\/sites\/lizryan\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927626640942882823",
    "text" : "Smart Job Seekers Break These Ten Resume-Writing Rules https:\/\/t.co\/gDsxlOon2e",
    "id" : 927626640942882823,
    "created_at" : "2017-11-06 20:00:00 +0000",
    "user" : {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "protected" : false,
      "id_str" : "91478624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882603270484766720\/YFx4Lsh4_normal.jpg",
      "id" : 91478624,
      "verified" : true
    }
  },
  "id" : 927627121228500992,
  "created_at" : "2017-11-06 20:01:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "UW-Madison",
      "screen_name" : "UWMadison",
      "indices" : [ 112, 122 ],
      "id_str" : "15763818",
      "id" : 15763818
    }, {
      "name" : "PNAS",
      "screen_name" : "PNASNews",
      "indices" : [ 123, 132 ],
      "id_str" : "258847118",
      "id" : 258847118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eruption",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/PdAKrn0k0Y",
      "expanded_url" : "http:\/\/phy.so\/429173427",
      "display_url" : "phy.so\/429173427"
    } ]
  },
  "geo" : { },
  "id_str" : "927626853984210944",
  "text" : "RT @physorg_com: Cool idea: Magma held in 'cold storage' before giant volcano #eruption https:\/\/t.co\/PdAKrn0k0Y @UWMadison @PNASNews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UW-Madison",
        "screen_name" : "UWMadison",
        "indices" : [ 95, 105 ],
        "id_str" : "15763818",
        "id" : 15763818
      }, {
        "name" : "PNAS",
        "screen_name" : "PNASNews",
        "indices" : [ 106, 115 ],
        "id_str" : "258847118",
        "id" : 258847118
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eruption",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/PdAKrn0k0Y",
        "expanded_url" : "http:\/\/phy.so\/429173427",
        "display_url" : "phy.so\/429173427"
      } ]
    },
    "geo" : { },
    "id_str" : "927626664753889280",
    "text" : "Cool idea: Magma held in 'cold storage' before giant volcano #eruption https:\/\/t.co\/PdAKrn0k0Y @UWMadison @PNASNews",
    "id" : 927626664753889280,
    "created_at" : "2017-11-06 20:00:06 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 927626853984210944,
  "created_at" : "2017-11-06 20:00:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/xkaIWrXtzK",
      "expanded_url" : "https:\/\/twitter.com\/dina_ess\/status\/927620919153045509",
      "display_url" : "twitter.com\/dina_ess\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927626762951057409",
  "text" : "Dina you are very smart, don't stoop to this guy's level https:\/\/t.co\/xkaIWrXtzK",
  "id" : 927626762951057409,
  "created_at" : "2017-11-06 20:00:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/elmxeFYre1",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/best-motherboards,3984.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/best-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927626064079282181",
  "text" : "RT @tomshardware: \u25B8 Best Motherboards https:\/\/t.co\/elmxeFYre1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/elmxeFYre1",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/best-motherboards,3984.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/best-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927594699292008449",
    "text" : "\u25B8 Best Motherboards https:\/\/t.co\/elmxeFYre1",
    "id" : 927594699292008449,
    "created_at" : "2017-11-06 17:53:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927626064079282181,
  "created_at" : "2017-11-06 19:57:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927626041232908289",
  "text" : "Meeting tomorrow, stuff need to get ready for, I got this",
  "id" : 927626041232908289,
  "created_at" : "2017-11-06 19:57:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927600004327501824",
  "text" : "RT @lorenridinger: \"If you raise your standards, you will enjoy the journey because you too will change into a stronger person in the proce\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927430490596036608",
    "text" : "\"If you raise your standards, you will enjoy the journey because you too will change into a stronger person in the process.\"",
    "id" : 927430490596036608,
    "created_at" : "2017-11-06 07:00:34 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 927600004327501824,
  "created_at" : "2017-11-06 18:14:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.theodysseyonline.com\/\" rel=\"nofollow\"\u003EOdyssey - Twitter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/VPVYuFnWZv",
      "expanded_url" : "https:\/\/www.theodysseyonline.com\/motivational",
      "display_url" : "theodysseyonline.com\/motivational"
    } ]
  },
  "geo" : { },
  "id_str" : "927594962564284417",
  "text" : "Here is what drives me https:\/\/t.co\/VPVYuFnWZv",
  "id" : 927594962564284417,
  "created_at" : "2017-11-06 17:54:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/WLEBVbiBTc",
      "expanded_url" : "http:\/\/thndr.me\/IHps1M",
      "display_url" : "thndr.me\/IHps1M"
    } ]
  },
  "geo" : { },
  "id_str" : "927581396889227264",
  "text" : "November 6 will be the release of our first game on Steam.\nGenre(s): Action, Shooter, Shoot-'Em-Up, Top-Down.\n https:\/\/t.co\/WLEBVbiBTc",
  "id" : 927581396889227264,
  "created_at" : "2017-11-06 17:00:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "AMD",
      "screen_name" : "AMD",
      "indices" : [ 20, 24 ],
      "id_str" : "14861876",
      "id" : 14861876
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 66, 72 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/TeSE0V9Li1",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/amd-intel-gpu-emib-soc,35852.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/amd-intel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927573054204542976",
  "text" : "RT @tomshardware: \u25B8 @AMD To Develop Semi-Custom Graphics Chip For @Intel https:\/\/t.co\/TeSE0V9Li1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMD",
        "screen_name" : "AMD",
        "indices" : [ 2, 6 ],
        "id_str" : "14861876",
        "id" : 14861876
      }, {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 48, 54 ],
        "id_str" : "2803191",
        "id" : 2803191
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/TeSE0V9Li1",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/amd-intel-gpu-emib-soc,35852.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/amd-intel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927554683807318017",
    "text" : "\u25B8 @AMD To Develop Semi-Custom Graphics Chip For @Intel https:\/\/t.co\/TeSE0V9Li1",
    "id" : 927554683807318017,
    "created_at" : "2017-11-06 15:14:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927573054204542976,
  "created_at" : "2017-11-06 16:27:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927396515630538753",
  "text" : "RT @TheSharkDaymond: Being an entrepreneur is all about perseverance and drive no matter what you\u2019re up against. RT if you\u2019re with me. #Sha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927376244701773824",
    "text" : "Being an entrepreneur is all about perseverance and drive no matter what you\u2019re up against. RT if you\u2019re with me. #SharkTank",
    "id" : 927376244701773824,
    "created_at" : "2017-11-06 03:25:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817056911518482433\/otB2Lkng_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 927396515630538753,
  "created_at" : "2017-11-06 04:45:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    }, {
      "name" : "Alex Rodriguez",
      "screen_name" : "AROD",
      "indices" : [ 35, 40 ],
      "id_str" : "348217747",
      "id" : 348217747
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927391053640028160",
  "text" : "RT @BarbaraCorcoran: My money\u2019s on @Arod for the rematch! #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Rodriguez",
        "screen_name" : "AROD",
        "indices" : [ 14, 19 ],
        "id_str" : "348217747",
        "id" : 348217747
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927380485856260096",
    "text" : "My money\u2019s on @Arod for the rematch! #SharkTank",
    "id" : 927380485856260096,
    "created_at" : "2017-11-06 03:41:52 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 927391053640028160,
  "created_at" : "2017-11-06 04:23:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927390706993455104",
  "text" : "RT @lorenridinger: \"If you want to be great, you have to take risks.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927385154821197824",
    "text" : "\"If you want to be great, you have to take risks.\"",
    "id" : 927385154821197824,
    "created_at" : "2017-11-06 04:00:25 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 927390706993455104,
  "created_at" : "2017-11-06 04:22:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/LiLWBlSKui",
      "expanded_url" : "http:\/\/depot.ly\/Dv1g30glmDt",
      "display_url" : "depot.ly\/Dv1g30glmDt"
    } ]
  },
  "geo" : { },
  "id_str" : "927355526077435904",
  "text" : "RT @DesignerDepot: 5 Ways to Improve the UX of Site Search https:\/\/t.co\/LiLWBlSKui",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/LiLWBlSKui",
        "expanded_url" : "http:\/\/depot.ly\/Dv1g30glmDt",
        "display_url" : "depot.ly\/Dv1g30glmDt"
      } ]
    },
    "geo" : { },
    "id_str" : "926851582058205184",
    "text" : "5 Ways to Improve the UX of Site Search https:\/\/t.co\/LiLWBlSKui",
    "id" : 926851582058205184,
    "created_at" : "2017-11-04 16:40:11 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 927355526077435904,
  "created_at" : "2017-11-06 02:02:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DEPLORABLESus #TCOT",
      "screen_name" : "susanbnj",
      "indices" : [ 3, 12 ],
      "id_str" : "234789656",
      "id" : 234789656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teeth",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ehzmEopm9D",
      "expanded_url" : "http:\/\/NaturalNews.com",
      "display_url" : "NaturalNews.com"
    } ]
  },
  "geo" : { },
  "id_str" : "927355064733323264",
  "text" : "RT @susanbnj: Repair decayed #teeth with \u201Cbioactive\u201D glass that remineralizes teeth without fluoride \u2013 https:\/\/t.co\/ehzmEopm9D https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teeth",
        "indices" : [ 15, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/ehzmEopm9D",
        "expanded_url" : "http:\/\/NaturalNews.com",
        "display_url" : "NaturalNews.com"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/zedFz9z8Ek",
        "expanded_url" : "https:\/\/www.naturalnews.com\/2017-11-04-repair-decayed-teeth-with-bioactive-glass-that-remineralizes-teeth-without-fluoride.html",
        "display_url" : "naturalnews.com\/2017-11-04-rep\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927288863328034816",
    "text" : "Repair decayed #teeth with \u201Cbioactive\u201D glass that remineralizes teeth without fluoride \u2013 https:\/\/t.co\/ehzmEopm9D https:\/\/t.co\/zedFz9z8Ek",
    "id" : 927288863328034816,
    "created_at" : "2017-11-05 21:37:47 +0000",
    "user" : {
      "name" : "DEPLORABLESus #TCOT",
      "screen_name" : "susanbnj",
      "protected" : false,
      "id_str" : "234789656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623224723439136769\/I_-XD4DR_normal.jpg",
      "id" : 234789656,
      "verified" : false
    }
  },
  "id" : 927355064733323264,
  "created_at" : "2017-11-06 02:00:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Lefkofsky",
      "screen_name" : "lefkofsky",
      "indices" : [ 3, 13 ],
      "id_str" : "15716974",
      "id" : 15716974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/I3J2iGPU2L",
      "expanded_url" : "https:\/\/www.usnews.com\/news\/healthcare-of-tomorrow\/articles\/2017-11-01\/op-ed-enlisting-big-data-in-the-war-against-cancer",
      "display_url" : "usnews.com\/news\/healthcar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927354735694434304",
  "text" : "RT @lefkofsky: We need to reimagine how we battle cancer. https:\/\/t.co\/I3J2iGPU2L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/I3J2iGPU2L",
        "expanded_url" : "https:\/\/www.usnews.com\/news\/healthcare-of-tomorrow\/articles\/2017-11-01\/op-ed-enlisting-big-data-in-the-war-against-cancer",
        "display_url" : "usnews.com\/news\/healthcar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925777569613537281",
    "text" : "We need to reimagine how we battle cancer. https:\/\/t.co\/I3J2iGPU2L",
    "id" : 925777569613537281,
    "created_at" : "2017-11-01 17:32:27 +0000",
    "user" : {
      "name" : "Eric Lefkofsky",
      "screen_name" : "lefkofsky",
      "protected" : false,
      "id_str" : "15716974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590978647869169664\/lNfCzciV_normal.jpg",
      "id" : 15716974,
      "verified" : true
    }
  },
  "id" : 927354735694434304,
  "created_at" : "2017-11-06 01:59:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED Science",
      "screen_name" : "WIREDScience",
      "indices" : [ 3, 16 ],
      "id_str" : "8963722",
      "id" : 8963722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/fAjUSsVcPf",
      "expanded_url" : "https:\/\/trib.al\/iDndyUJ",
      "display_url" : "trib.al\/iDndyUJ"
    } ]
  },
  "geo" : { },
  "id_str" : "927354527107485696",
  "text" : "RT @WIREDScience: A group of researchers have discovered a new space in the Great Pyramid of Giza https:\/\/t.co\/fAjUSsVcPf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/fAjUSsVcPf",
        "expanded_url" : "https:\/\/trib.al\/iDndyUJ",
        "display_url" : "trib.al\/iDndyUJ"
      } ]
    },
    "geo" : { },
    "id_str" : "926918340970450944",
    "text" : "A group of researchers have discovered a new space in the Great Pyramid of Giza https:\/\/t.co\/fAjUSsVcPf",
    "id" : 926918340970450944,
    "created_at" : "2017-11-04 21:05:28 +0000",
    "user" : {
      "name" : "WIRED Science",
      "screen_name" : "WIREDScience",
      "protected" : false,
      "id_str" : "8963722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575691167385325569\/DOVl8RCl_normal.png",
      "id" : 8963722,
      "verified" : true
    }
  },
  "id" : 927354527107485696,
  "created_at" : "2017-11-06 01:58:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED Science",
      "screen_name" : "WIREDScience",
      "indices" : [ 3, 16 ],
      "id_str" : "8963722",
      "id" : 8963722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/7bSMRVtciD",
      "expanded_url" : "https:\/\/trib.al\/XJCoSV8",
      "display_url" : "trib.al\/XJCoSV8"
    } ]
  },
  "geo" : { },
  "id_str" : "927354508874866689",
  "text" : "RT @WIREDScience: Aquaman isn't bound to any laws, even the laws of physics https:\/\/t.co\/7bSMRVtciD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/7bSMRVtciD",
        "expanded_url" : "https:\/\/trib.al\/XJCoSV8",
        "display_url" : "trib.al\/XJCoSV8"
      } ]
    },
    "geo" : { },
    "id_str" : "927127288306597889",
    "text" : "Aquaman isn't bound to any laws, even the laws of physics https:\/\/t.co\/7bSMRVtciD",
    "id" : 927127288306597889,
    "created_at" : "2017-11-05 10:55:45 +0000",
    "user" : {
      "name" : "WIRED Science",
      "screen_name" : "WIREDScience",
      "protected" : false,
      "id_str" : "8963722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575691167385325569\/DOVl8RCl_normal.png",
      "id" : 8963722,
      "verified" : true
    }
  },
  "id" : 927354508874866689,
  "created_at" : "2017-11-06 01:58:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Caplan",
      "screen_name" : "joshdcaplan",
      "indices" : [ 3, 15 ],
      "id_str" : "744070482832596992",
      "id" : 744070482832596992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/k7l8cNrA8m",
      "expanded_url" : "http:\/\/www.thegatewaypundit.com\/2017\/11\/must-see-hero-caught-gunman-devin-kelley-interviewed-chased-truck-video\/",
      "display_url" : "thegatewaypundit.com\/2017\/11\/must-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927353549381685248",
  "text" : "RT @joshdcaplan: Hero Who Caught Gunman Devin Kelley Interviewed \u2014 Chased Him Down In His Truck! (VIDEO)\nhttps:\/\/t.co\/k7l8cNrA8m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/k7l8cNrA8m",
        "expanded_url" : "http:\/\/www.thegatewaypundit.com\/2017\/11\/must-see-hero-caught-gunman-devin-kelley-interviewed-chased-truck-video\/",
        "display_url" : "thegatewaypundit.com\/2017\/11\/must-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927346849022963712",
    "text" : "Hero Who Caught Gunman Devin Kelley Interviewed \u2014 Chased Him Down In His Truck! (VIDEO)\nhttps:\/\/t.co\/k7l8cNrA8m",
    "id" : 927346849022963712,
    "created_at" : "2017-11-06 01:28:12 +0000",
    "user" : {
      "name" : "Josh Caplan",
      "screen_name" : "joshdcaplan",
      "protected" : false,
      "id_str" : "744070482832596992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880995844455059456\/JP5kPKkQ_normal.jpg",
      "id" : 744070482832596992,
      "verified" : false
    }
  },
  "id" : 927353549381685248,
  "created_at" : "2017-11-06 01:54:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927353519560151041",
  "text" : "RT @BONNIELYNN2015: Texas shooting at First Baptist Church in Sutherland Springs leaves 26 dead -- live stream, updates - CBS News https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/6Qp11462cx",
        "expanded_url" : "https:\/\/www.cbsnews.com\/amp\/news\/texas-church-shooting-sutherland-springs-first-baptist-church-live-stream-updates\/",
        "display_url" : "cbsnews.com\/amp\/news\/texas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927349304984924160",
    "text" : "Texas shooting at First Baptist Church in Sutherland Springs leaves 26 dead -- live stream, updates - CBS News https:\/\/t.co\/6Qp11462cx",
    "id" : 927349304984924160,
    "created_at" : "2017-11-06 01:37:58 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927433831929413632\/duExUEVU_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 927353519560151041,
  "created_at" : "2017-11-06 01:54:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/32ev2biISs",
      "expanded_url" : "http:\/\/ift.tt\/2hIVoxM",
      "display_url" : "ift.tt\/2hIVoxM"
    } ]
  },
  "geo" : { },
  "id_str" : "927352839176830976",
  "text" : "RT @dronepilots: Emiri Air Force opens copter simulator training centre | DronePilots - https:\/\/t.co\/32ev2biISs #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/32ev2biISs",
        "expanded_url" : "http:\/\/ift.tt\/2hIVoxM",
        "display_url" : "ift.tt\/2hIVoxM"
      } ]
    },
    "geo" : { },
    "id_str" : "927294707612479488",
    "text" : "Emiri Air Force opens copter simulator training centre | DronePilots - https:\/\/t.co\/32ev2biISs #drones",
    "id" : 927294707612479488,
    "created_at" : "2017-11-05 22:01:01 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927352839176830976,
  "created_at" : "2017-11-06 01:52:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "indices" : [ 3, 16 ],
      "id_str" : "2544537620",
      "id" : 2544537620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927352819765661696",
  "text" : "RT @Snapzu_Earth: Fun Fact: Tuna fish can swim 40 miles in a single day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927290808708997120",
    "text" : "Fun Fact: Tuna fish can swim 40 miles in a single day.",
    "id" : 927290808708997120,
    "created_at" : "2017-11-05 21:45:31 +0000",
    "user" : {
      "name" : "Snapzu Earth",
      "screen_name" : "Snapzu_Earth",
      "protected" : false,
      "id_str" : "2544537620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473960994603929600\/VdOt4omo_normal.png",
      "id" : 2544537620,
      "verified" : false
    }
  },
  "id" : 927352819765661696,
  "created_at" : "2017-11-06 01:51:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/UOdGS4SO4L",
      "expanded_url" : "https:\/\/twitter.com\/hoesuueee\/status\/926961144660574208",
      "display_url" : "twitter.com\/hoesuueee\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927352702929195009",
  "text" : "Lol \uD83D\uDE02 https:\/\/t.co\/UOdGS4SO4L",
  "id" : 927352702929195009,
  "created_at" : "2017-11-06 01:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spartan Sports Page",
      "screen_name" : "SpartanSports",
      "indices" : [ 3, 17 ],
      "id_str" : "15613033",
      "id" : 15613033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/xjowVw3UYH",
      "expanded_url" : "http:\/\/ow.ly\/t7kT30gn28K",
      "display_url" : "ow.ly\/t7kT30gn28K"
    } ]
  },
  "geo" : { },
  "id_str" : "927352518723686400",
  "text" : "RT @SpartanSports: Inside the Spartans: Michigan State survives storm to be contenders https:\/\/t.co\/xjowVw3UYH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/xjowVw3UYH",
        "expanded_url" : "http:\/\/ow.ly\/t7kT30gn28K",
        "display_url" : "ow.ly\/t7kT30gn28K"
      } ]
    },
    "geo" : { },
    "id_str" : "927348579240480769",
    "text" : "Inside the Spartans: Michigan State survives storm to be contenders https:\/\/t.co\/xjowVw3UYH",
    "id" : 927348579240480769,
    "created_at" : "2017-11-06 01:35:05 +0000",
    "user" : {
      "name" : "Spartan Sports Page",
      "screen_name" : "SpartanSports",
      "protected" : false,
      "id_str" : "15613033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/121736739\/scan0002smaller_normal.png",
      "id" : 15613033,
      "verified" : false
    }
  },
  "id" : 927352518723686400,
  "created_at" : "2017-11-06 01:50:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/ZKj5HQBxBq",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4uwlo",
      "display_url" : "cards.twitter.com\/cards\/a6dip\/4u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927352495415971841",
  "text" : "RT @hootsuite: 13 Facebook Live tips from Hootsuite\u2019s social media team: https:\/\/t.co\/ZKj5HQBxBq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/ZKj5HQBxBq",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4uwlo",
        "display_url" : "cards.twitter.com\/cards\/a6dip\/4u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927351106522501120",
    "text" : "13 Facebook Live tips from Hootsuite\u2019s social media team: https:\/\/t.co\/ZKj5HQBxBq",
    "id" : 927351106522501120,
    "created_at" : "2017-11-06 01:45:07 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 927352495415971841,
  "created_at" : "2017-11-06 01:50:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Ransom",
      "screen_name" : "Diane411Ransom",
      "indices" : [ 3, 18 ],
      "id_str" : "1412781536",
      "id" : 1412781536
    }, {
      "name" : "Bill Pulte",
      "screen_name" : "pulte",
      "indices" : [ 20, 26 ],
      "id_str" : "25029495",
      "id" : 25029495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927352443029086208",
  "text" : "RT @Diane411Ransom: @pulte Give the people something good to reach for and they will choose it rather than the bad.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Pulte",
        "screen_name" : "pulte",
        "indices" : [ 0, 6 ],
        "id_str" : "25029495",
        "id" : 25029495
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "927311866426200069",
    "geo" : { },
    "id_str" : "927332602805145600",
    "in_reply_to_user_id" : 25029495,
    "text" : "@pulte Give the people something good to reach for and they will choose it rather than the bad.",
    "id" : 927332602805145600,
    "in_reply_to_status_id" : 927311866426200069,
    "created_at" : "2017-11-06 00:31:36 +0000",
    "in_reply_to_screen_name" : "pulte",
    "in_reply_to_user_id_str" : "25029495",
    "user" : {
      "name" : "Diane Ransom",
      "screen_name" : "Diane411Ransom",
      "protected" : false,
      "id_str" : "1412781536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921084722394132481\/OIZ5XhAR_normal.jpg",
      "id" : 1412781536,
      "verified" : false
    }
  },
  "id" : 927352443029086208,
  "created_at" : "2017-11-06 01:50:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Ong",
      "screen_name" : "iambobongquotes",
      "indices" : [ 3, 19 ],
      "id_str" : "938887459",
      "id" : 938887459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927352377614708736",
  "text" : "RT @iambobongquotes: \"A good relationship is worth the wait.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927351087547539457",
    "text" : "\"A good relationship is worth the wait.\"",
    "id" : 927351087547539457,
    "created_at" : "2017-11-06 01:45:03 +0000",
    "user" : {
      "name" : "Bob Ong",
      "screen_name" : "iambobongquotes",
      "protected" : false,
      "id_str" : "938887459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839270928097792000\/VNfJEw-c_normal.jpg",
      "id" : 938887459,
      "verified" : false
    }
  },
  "id" : 927352377614708736,
  "created_at" : "2017-11-06 01:50:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927352341107478529",
  "text" : "I got this friend in the church, she is so awesome, but let us hope everything doesn't fall apart like some of those really bad indie films",
  "id" : 927352341107478529,
  "created_at" : "2017-11-06 01:50:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 144, 167 ],
      "url" : "https:\/\/t.co\/M8YQE6sGBM",
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/927247809803358208",
      "display_url" : "twitter.com\/KassyDillon\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927352014157352961",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon don't worry Kassy, u r the princess of Twitter who'll use her magic wand to vanish him to the land of trolls &amp; forgotten memes https:\/\/t.co\/M8YQE6sGBM",
  "id" : 927352014157352961,
  "created_at" : "2017-11-06 01:48:44 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ztLbkwJiuP",
      "expanded_url" : "https:\/\/twitter.com\/Craftmastah\/status\/927320761571991552",
      "display_url" : "twitter.com\/Craftmastah\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927350958992035840",
  "text" : "He's definitely not a conservative. But let us put politics aside and know how we as a country can heal together. https:\/\/t.co\/ztLbkwJiuP",
  "id" : 927350958992035840,
  "created_at" : "2017-11-06 01:44:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/EtNYtmmza2",
      "expanded_url" : "http:\/\/engt.co\/2zf3ngl",
      "display_url" : "engt.co\/2zf3ngl"
    } ]
  },
  "geo" : { },
  "id_str" : "927343170878365697",
  "text" : "RT @engadget: Cable giant Altice will become a wireless carrier with Sprint's help https:\/\/t.co\/EtNYtmmza2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/EtNYtmmza2",
        "expanded_url" : "http:\/\/engt.co\/2zf3ngl",
        "display_url" : "engt.co\/2zf3ngl"
      } ]
    },
    "geo" : { },
    "id_str" : "927309207040294913",
    "text" : "Cable giant Altice will become a wireless carrier with Sprint's help https:\/\/t.co\/EtNYtmmza2",
    "id" : 927309207040294913,
    "created_at" : "2017-11-05 22:58:38 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 927343170878365697,
  "created_at" : "2017-11-06 01:13:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everytown",
      "screen_name" : "Everytown",
      "indices" : [ 3, 13 ],
      "id_str" : "250386727",
      "id" : 250386727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927342777901428737",
  "text" : "RT @Everytown: Our hearts go out to all those impacted by the shooting at First Baptist Church in Sutherland Springs, Texas today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927257823146323969",
    "text" : "Our hearts go out to all those impacted by the shooting at First Baptist Church in Sutherland Springs, Texas today.",
    "id" : 927257823146323969,
    "created_at" : "2017-11-05 19:34:27 +0000",
    "user" : {
      "name" : "Everytown",
      "screen_name" : "Everytown",
      "protected" : false,
      "id_str" : "250386727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871736995877453824\/xD2ruYkE_normal.jpg",
      "id" : 250386727,
      "verified" : true
    }
  },
  "id" : 927342777901428737,
  "created_at" : "2017-11-06 01:12:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "indices" : [ 3, 15 ],
      "id_str" : "912653647036715008",
      "id" : 912653647036715008
    }, {
      "name" : "Dot York",
      "screen_name" : "Dot_York",
      "indices" : [ 45, 54 ],
      "id_str" : "2242323835",
      "id" : 2242323835
    }, {
      "name" : "CodePen.IO",
      "screen_name" : "CodePen",
      "indices" : [ 84, 92 ],
      "id_str" : "517021184",
      "id" : 517021184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/74hsAKfTTq",
      "expanded_url" : "https:\/\/nvite.com\/CodePenYork",
      "display_url" : "nvite.com\/CodePenYork"
    } ]
  },
  "geo" : { },
  "id_str" : "927342625178505217",
  "text" : "RT @CodePenYork: Just under a week to go for @Dot_York and 2 weeks for York's first @CodePen meet up! RSVP today! https:\/\/t.co\/74hsAKfTTq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dot York",
        "screen_name" : "Dot_York",
        "indices" : [ 28, 37 ],
        "id_str" : "2242323835",
        "id" : 2242323835
      }, {
        "name" : "CodePen.IO",
        "screen_name" : "CodePen",
        "indices" : [ 67, 75 ],
        "id_str" : "517021184",
        "id" : 517021184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/74hsAKfTTq",
        "expanded_url" : "https:\/\/nvite.com\/CodePenYork",
        "display_url" : "nvite.com\/CodePenYork"
      } ]
    },
    "geo" : { },
    "id_str" : "926445159134433281",
    "text" : "Just under a week to go for @Dot_York and 2 weeks for York's first @CodePen meet up! RSVP today! https:\/\/t.co\/74hsAKfTTq",
    "id" : 926445159134433281,
    "created_at" : "2017-11-03 13:45:13 +0000",
    "user" : {
      "name" : "CodePen York",
      "screen_name" : "CodePenYork",
      "protected" : false,
      "id_str" : "912653647036715008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916985186948190208\/1oFbpvDO_normal.jpg",
      "id" : 912653647036715008,
      "verified" : false
    }
  },
  "id" : 927342625178505217,
  "created_at" : "2017-11-06 01:11:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "net magazine",
      "screen_name" : "netmag",
      "indices" : [ 3, 10 ],
      "id_str" : "17648193",
      "id" : 17648193
    }, {
      "name" : "CodePen.IO",
      "screen_name" : "CodePen",
      "indices" : [ 37, 45 ],
      "id_str" : "517021184",
      "id" : 517021184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/4dlGoMha3G",
      "expanded_url" : "http:\/\/www.creativebloq.com\/features\/how-codepen-made-itself-secure",
      "display_url" : "creativebloq.com\/features\/how-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927342563706785793",
  "text" : "RT @netmag: Case study: Find out how @CodePen undertook the mammoth task switching entirely to a secure protocol. https:\/\/t.co\/4dlGoMha3G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CodePen.IO",
        "screen_name" : "CodePen",
        "indices" : [ 25, 33 ],
        "id_str" : "517021184",
        "id" : 517021184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/4dlGoMha3G",
        "expanded_url" : "http:\/\/www.creativebloq.com\/features\/how-codepen-made-itself-secure",
        "display_url" : "creativebloq.com\/features\/how-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926468461139841024",
    "text" : "Case study: Find out how @CodePen undertook the mammoth task switching entirely to a secure protocol. https:\/\/t.co\/4dlGoMha3G",
    "id" : 926468461139841024,
    "created_at" : "2017-11-03 15:17:48 +0000",
    "user" : {
      "name" : "net magazine",
      "screen_name" : "netmag",
      "protected" : false,
      "id_str" : "17648193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000697523305\/d556bef753c6ac3933e9d5bf9f147418_normal.jpeg",
      "id" : 17648193,
      "verified" : false
    }
  },
  "id" : 927342563706785793,
  "created_at" : "2017-11-06 01:11:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "indices" : [ 3, 16 ],
      "id_str" : "418597196",
      "id" : 418597196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/5OgSvz2Ig3",
      "expanded_url" : "http:\/\/www.creativebloq.com\/features\/the-best-adobe-deals-for-november-2017",
      "display_url" : "creativebloq.com\/features\/the-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927342543746076677",
  "text" : "RT @CreativeBloq: We've rounded up the best Creative Cloud deals this month: https:\/\/t.co\/5OgSvz2Ig3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/5OgSvz2Ig3",
        "expanded_url" : "http:\/\/www.creativebloq.com\/features\/the-best-adobe-deals-for-november-2017",
        "display_url" : "creativebloq.com\/features\/the-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926485575787597826",
    "text" : "We've rounded up the best Creative Cloud deals this month: https:\/\/t.co\/5OgSvz2Ig3",
    "id" : 926485575787597826,
    "created_at" : "2017-11-03 16:25:49 +0000",
    "user" : {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "protected" : false,
      "id_str" : "418597196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880112520383606785\/cBPw6RSd_normal.jpg",
      "id" : 418597196,
      "verified" : true
    }
  },
  "id" : 927342543746076677,
  "created_at" : "2017-11-06 01:11:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "indices" : [ 3, 16 ],
      "id_str" : "418597196",
      "id" : 418597196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/NzTnHJ4uRl",
      "expanded_url" : "http:\/\/www.creativebloq.com\/how-to\/create-a-digital-oil-painting-using-artrage",
      "display_url" : "creativebloq.com\/how-to\/create-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927342533444857857",
  "text" : "RT @CreativeBloq: Oil painting without the mess. https:\/\/t.co\/NzTnHJ4uRl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/NzTnHJ4uRl",
        "expanded_url" : "http:\/\/www.creativebloq.com\/how-to\/create-a-digital-oil-painting-using-artrage",
        "display_url" : "creativebloq.com\/how-to\/create-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926494013582118913",
    "text" : "Oil painting without the mess. https:\/\/t.co\/NzTnHJ4uRl",
    "id" : 926494013582118913,
    "created_at" : "2017-11-03 16:59:20 +0000",
    "user" : {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "protected" : false,
      "id_str" : "418597196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880112520383606785\/cBPw6RSd_normal.jpg",
      "id" : 418597196,
      "verified" : true
    }
  },
  "id" : 927342533444857857,
  "created_at" : "2017-11-06 01:11:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "indices" : [ 3, 10 ],
      "id_str" : "15919988",
      "id" : 15919988
    }, {
      "name" : "Patrick Caughill",
      "screen_name" : "pmcaughill",
      "indices" : [ 91, 102 ],
      "id_str" : "819777198",
      "id" : 819777198
    }, {
      "name" : "NBC News MACH",
      "screen_name" : "NBCNewsMACH",
      "indices" : [ 103, 115 ],
      "id_str" : "11856442",
      "id" : 11856442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/CMeS4P73AE",
      "expanded_url" : "https:\/\/goo.gl\/7TdPXf",
      "display_url" : "goo.gl\/7TdPXf"
    } ]
  },
  "geo" : { },
  "id_str" : "927342358236139520",
  "text" : "RT @xprize: Power from...seaweed? The U.S. DOE is looking into it: https:\/\/t.co\/CMeS4P73AE @pmcaughill @NBCNewsMACH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Caughill",
        "screen_name" : "pmcaughill",
        "indices" : [ 79, 90 ],
        "id_str" : "819777198",
        "id" : 819777198
      }, {
        "name" : "NBC News MACH",
        "screen_name" : "NBCNewsMACH",
        "indices" : [ 91, 103 ],
        "id_str" : "11856442",
        "id" : 11856442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/CMeS4P73AE",
        "expanded_url" : "https:\/\/goo.gl\/7TdPXf",
        "display_url" : "goo.gl\/7TdPXf"
      } ]
    },
    "geo" : { },
    "id_str" : "927264370958176256",
    "text" : "Power from...seaweed? The U.S. DOE is looking into it: https:\/\/t.co\/CMeS4P73AE @pmcaughill @NBCNewsMACH",
    "id" : 927264370958176256,
    "created_at" : "2017-11-05 20:00:28 +0000",
    "user" : {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "protected" : false,
      "id_str" : "15919988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890261363808886784\/WJyNCRI__normal.jpg",
      "id" : 15919988,
      "verified" : true
    }
  },
  "id" : 927342358236139520,
  "created_at" : "2017-11-06 01:10:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MultiGP Drone Racing",
      "screen_name" : "Multi_GP",
      "indices" : [ 3, 12 ],
      "id_str" : "3088654755",
      "id" : 3088654755
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/8acAACq9S0",
      "expanded_url" : "http:\/\/youtu.be\/_7w94ruTxTM?a",
      "display_url" : "youtu.be\/_7w94ruTxTM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927342059635331072",
  "text" : "RT @Multi_GP: Flite Fest South, Day 1: A Family Reunion of Flight: https:\/\/t.co\/8acAACq9S0 via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 81, 89 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/8acAACq9S0",
        "expanded_url" : "http:\/\/youtu.be\/_7w94ruTxTM?a",
        "display_url" : "youtu.be\/_7w94ruTxTM?a"
      } ]
    },
    "geo" : { },
    "id_str" : "926544418596950016",
    "text" : "Flite Fest South, Day 1: A Family Reunion of Flight: https:\/\/t.co\/8acAACq9S0 via @YouTube",
    "id" : 926544418596950016,
    "created_at" : "2017-11-03 20:19:38 +0000",
    "user" : {
      "name" : "MultiGP Drone Racing",
      "screen_name" : "Multi_GP",
      "protected" : false,
      "id_str" : "3088654755",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682281292361285632\/mkJkcFgU_normal.png",
      "id" : 3088654755,
      "verified" : false
    }
  },
  "id" : 927342059635331072,
  "created_at" : "2017-11-06 01:09:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drone Racing League",
      "screen_name" : "DroneRaceLeague",
      "indices" : [ 3, 19 ],
      "id_str" : "3240985277",
      "id" : 3240985277
    }, {
      "name" : "Star Wars",
      "screen_name" : "starwars",
      "indices" : [ 29, 38 ],
      "id_str" : "20106852",
      "id" : 20106852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/BqItrmspZg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?time_continue=10&v=ikXP1NT_eZA",
      "display_url" : "youtube.com\/watch?time_con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927341993369403393",
  "text" : "RT @DroneRaceLeague: No way. @starwars for the Halloween win. \n\nhttps:\/\/t.co\/BqItrmspZg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Star Wars",
        "screen_name" : "starwars",
        "indices" : [ 8, 17 ],
        "id_str" : "20106852",
        "id" : 20106852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/BqItrmspZg",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?time_continue=10&v=ikXP1NT_eZA",
        "display_url" : "youtube.com\/watch?time_con\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925116577237884930",
    "text" : "No way. @starwars for the Halloween win. \n\nhttps:\/\/t.co\/BqItrmspZg",
    "id" : 925116577237884930,
    "created_at" : "2017-10-30 21:45:54 +0000",
    "user" : {
      "name" : "Drone Racing League",
      "screen_name" : "DroneRaceLeague",
      "protected" : false,
      "id_str" : "3240985277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697088587813232641\/BNpS83NR_normal.jpg",
      "id" : 3240985277,
      "verified" : true
    }
  },
  "id" : 927341993369403393,
  "created_at" : "2017-11-06 01:08:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rcairplanes",
      "screen_name" : "rcplanes2",
      "indices" : [ 3, 13 ],
      "id_str" : "4636121842",
      "id" : 4636121842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FPVpilot",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/weWYPM3HuN",
      "expanded_url" : "http:\/\/youtu.be\/dPpQWIA59Wo",
      "display_url" : "youtu.be\/dPpQWIA59Wo"
    } ]
  },
  "geo" : { },
  "id_str" : "927341976680390656",
  "text" : "RT @rcplanes2: World's Fastest Drone | Drone Racing League #FPVpilot https:\/\/t.co\/weWYPM3HuN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.rcvids.com\" rel=\"nofollow\"\u003Ercvids\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FPVpilot",
        "indices" : [ 44, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/weWYPM3HuN",
        "expanded_url" : "http:\/\/youtu.be\/dPpQWIA59Wo",
        "display_url" : "youtu.be\/dPpQWIA59Wo"
      } ]
    },
    "geo" : { },
    "id_str" : "925165458197803012",
    "text" : "World's Fastest Drone | Drone Racing League #FPVpilot https:\/\/t.co\/weWYPM3HuN",
    "id" : 925165458197803012,
    "created_at" : "2017-10-31 01:00:08 +0000",
    "user" : {
      "name" : "rcairplanes",
      "screen_name" : "rcplanes2",
      "protected" : false,
      "id_str" : "4636121842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681581804252454912\/MScOg39I_normal.png",
      "id" : 4636121842,
      "verified" : false
    }
  },
  "id" : 927341976680390656,
  "created_at" : "2017-11-06 01:08:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/927341621720600576\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/DJp1fi1s2o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN6USEOX4AAuccy.jpg",
      "id_str" : "927341611377483776",
      "id" : 927341611377483776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN6USEOX4AAuccy.jpg",
      "sizes" : [ {
        "h" : 629,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 798
      } ],
      "display_url" : "pic.twitter.com\/DJp1fi1s2o"
    } ],
    "hashtags" : [ {
      "text" : "hardware",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "STEM",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "Tech",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "Design",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "Research",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927341621720600576",
  "text" : "Finished that challenge, applied for a grant #hardware #STEM #Tech #Design #Research https:\/\/t.co\/DJp1fi1s2o",
  "id" : 927341621720600576,
  "created_at" : "2017-11-06 01:07:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 3, 11 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/fF174iEfce",
      "expanded_url" : "http:\/\/reut.rs\/2lT5rVN",
      "display_url" : "reut.rs\/2lT5rVN"
    } ]
  },
  "geo" : { },
  "id_str" : "927302328402751488",
  "text" : "RT @Reuters: Growth without scale: Deutsche Telekom's T-Mobile headache https:\/\/t.co\/fF174iEfce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/fF174iEfce",
        "expanded_url" : "http:\/\/reut.rs\/2lT5rVN",
        "display_url" : "reut.rs\/2lT5rVN"
      } ]
    },
    "geo" : { },
    "id_str" : "927188154528026624",
    "text" : "Growth without scale: Deutsche Telekom's T-Mobile headache https:\/\/t.co\/fF174iEfce",
    "id" : 927188154528026624,
    "created_at" : "2017-11-05 14:57:37 +0000",
    "user" : {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "protected" : false,
      "id_str" : "1652541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877554927932891136\/ZBEs235N_normal.jpg",
      "id" : 1652541,
      "verified" : true
    }
  },
  "id" : 927302328402751488,
  "created_at" : "2017-11-05 22:31:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NY Hall of Science",
      "screen_name" : "nysci",
      "indices" : [ 3, 9 ],
      "id_str" : "20081176",
      "id" : 20081176
    }, {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 11, 16 ],
      "id_str" : "30261067",
      "id" : 30261067
    }, {
      "name" : "Maker Faire",
      "screen_name" : "makerfaire",
      "indices" : [ 23, 34 ],
      "id_str" : "1578141",
      "id" : 1578141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927301708946006016",
  "text" : "RT @nysci: @cnet World @MakerFaire New York, features #STEM projects by tinkerers, artisans, &amp; startups from all walks of life: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNET",
        "screen_name" : "CNET",
        "indices" : [ 0, 5 ],
        "id_str" : "30261067",
        "id" : 30261067
      }, {
        "name" : "Maker Faire",
        "screen_name" : "makerfaire",
        "indices" : [ 12, 23 ],
        "id_str" : "1578141",
        "id" : 1578141
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 43, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/XqztMUVCIX",
        "expanded_url" : "http:\/\/cnet.co\/2z504bw",
        "display_url" : "cnet.co\/2z504bw"
      } ]
    },
    "geo" : { },
    "id_str" : "925759339436048386",
    "in_reply_to_user_id" : 30261067,
    "text" : "@cnet World @MakerFaire New York, features #STEM projects by tinkerers, artisans, &amp; startups from all walks of life: https:\/\/t.co\/XqztMUVCIX",
    "id" : 925759339436048386,
    "created_at" : "2017-11-01 16:20:00 +0000",
    "in_reply_to_screen_name" : "CNET",
    "in_reply_to_user_id_str" : "30261067",
    "user" : {
      "name" : "NY Hall of Science",
      "screen_name" : "nysci",
      "protected" : false,
      "id_str" : "20081176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821039861343940608\/mO1w84lq_normal.jpg",
      "id" : 20081176,
      "verified" : false
    }
  },
  "id" : 927301708946006016,
  "created_at" : "2017-11-05 22:28:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Field Ready",
      "screen_name" : "FldRdy",
      "indices" : [ 3, 10 ],
      "id_str" : "3233716407",
      "id" : 3233716407
    }, {
      "name" : "Humanitarian Makers",
      "screen_name" : "H_Makers",
      "indices" : [ 120, 129 ],
      "id_str" : "4785348162",
      "id" : 4785348162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927301675337084928",
  "text" : "RT @FldRdy: A look at Mapping Initiatives and Distributed Manufacturing in Ghana, Kenya &amp; Nepal. Who are we missing?@H_Makers https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Humanitarian Makers",
        "screen_name" : "H_Makers",
        "indices" : [ 108, 117 ],
        "id_str" : "4785348162",
        "id" : 4785348162
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/6diIhGTKXa",
        "expanded_url" : "http:\/\/www.makernet.global\/blog\/mappingsurvey",
        "display_url" : "makernet.global\/blog\/mappingsu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926512939187576833",
    "text" : "A look at Mapping Initiatives and Distributed Manufacturing in Ghana, Kenya &amp; Nepal. Who are we missing?@H_Makers https:\/\/t.co\/6diIhGTKXa",
    "id" : 926512939187576833,
    "created_at" : "2017-11-03 18:14:33 +0000",
    "user" : {
      "name" : "Field Ready",
      "screen_name" : "FldRdy",
      "protected" : false,
      "id_str" : "3233716407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727511272984576001\/8Hybr7M1_normal.jpg",
      "id" : 3233716407,
      "verified" : false
    }
  },
  "id" : 927301675337084928,
  "created_at" : "2017-11-05 22:28:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FirstResponderGaming",
      "screen_name" : "EM4FRG",
      "indices" : [ 3, 10 ],
      "id_str" : "879036696",
      "id" : 879036696
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/lTlDSuv77Y",
      "expanded_url" : "http:\/\/youtu.be\/q8iFRIASO_s?a",
      "display_url" : "youtu.be\/q8iFRIASO_s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927301581242097665",
  "text" : "RT @EM4FRG: EM4: Episode 789 Jordansville Mod: https:\/\/t.co\/lTlDSuv77Y via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 63, 71 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/lTlDSuv77Y",
        "expanded_url" : "http:\/\/youtu.be\/q8iFRIASO_s?a",
        "display_url" : "youtu.be\/q8iFRIASO_s?a"
      } ]
    },
    "geo" : { },
    "id_str" : "925801655173558272",
    "text" : "EM4: Episode 789 Jordansville Mod: https:\/\/t.co\/lTlDSuv77Y via @YouTube",
    "id" : 925801655173558272,
    "created_at" : "2017-11-01 19:08:09 +0000",
    "user" : {
      "name" : "FirstResponderGaming",
      "screen_name" : "EM4FRG",
      "protected" : false,
      "id_str" : "879036696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587965495556509697\/OVdBXC8I_normal.png",
      "id" : 879036696,
      "verified" : false
    }
  },
  "id" : 927301581242097665,
  "created_at" : "2017-11-05 22:28:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/0HxjOgc10X",
      "expanded_url" : "https:\/\/twitter.com\/latimes\/status\/927257798685200389",
      "display_url" : "twitter.com\/latimes\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927301482109693952",
  "text" : "This is sad! https:\/\/t.co\/0HxjOgc10X",
  "id" : 927301482109693952,
  "created_at" : "2017-11-05 22:27:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/H7gs59uVAr",
      "expanded_url" : "http:\/\/depot.ly\/5g3830gln5U",
      "display_url" : "depot.ly\/5g3830gln5U"
    } ]
  },
  "geo" : { },
  "id_str" : "927301018848825350",
  "text" : "RT @DesignerDepot: How to Convert a WordPress Site into a Mobile App https:\/\/t.co\/H7gs59uVAr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/H7gs59uVAr",
        "expanded_url" : "http:\/\/depot.ly\/5g3830gln5U",
        "display_url" : "depot.ly\/5g3830gln5U"
      } ]
    },
    "geo" : { },
    "id_str" : "927208941628674053",
    "text" : "How to Convert a WordPress Site into a Mobile App https:\/\/t.co\/H7gs59uVAr",
    "id" : 927208941628674053,
    "created_at" : "2017-11-05 16:20:13 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 927301018848825350,
  "created_at" : "2017-11-05 22:26:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/iEP2XKBBDB",
      "expanded_url" : "https:\/\/fstoppers.com\/composite\/making-150-megapixel-photographs-10-year-old-camera-202617?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/composite\/maki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927300622377943042",
  "text" : "RT @JayHoque: Making 150-Megapixel Photographs on a 10-Year-Old Camera: https:\/\/t.co\/iEP2XKBBDB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/iEP2XKBBDB",
        "expanded_url" : "https:\/\/fstoppers.com\/composite\/making-150-megapixel-photographs-10-year-old-camera-202617?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/composite\/maki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927220998134484998",
    "text" : "Making 150-Megapixel Photographs on a 10-Year-Old Camera: https:\/\/t.co\/iEP2XKBBDB",
    "id" : 927220998134484998,
    "created_at" : "2017-11-05 17:08:07 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 927300622377943042,
  "created_at" : "2017-11-05 22:24:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/udQBNHxhn3",
      "expanded_url" : "http:\/\/engt.co\/2lJbigm",
      "display_url" : "engt.co\/2lJbigm"
    } ]
  },
  "geo" : { },
  "id_str" : "927300601037443072",
  "text" : "RT @engadget: Xbox One X review: A console that keeps up with gaming PCs https:\/\/t.co\/udQBNHxhn3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/udQBNHxhn3",
        "expanded_url" : "http:\/\/engt.co\/2lJbigm",
        "display_url" : "engt.co\/2lJbigm"
      } ]
    },
    "geo" : { },
    "id_str" : "927250163806232576",
    "text" : "Xbox One X review: A console that keeps up with gaming PCs https:\/\/t.co\/udQBNHxhn3",
    "id" : 927250163806232576,
    "created_at" : "2017-11-05 19:04:01 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 927300601037443072,
  "created_at" : "2017-11-05 22:24:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927300577545113600",
  "text" : "Gotta love that Middle Eastern food, lol",
  "id" : 927300577545113600,
  "created_at" : "2017-11-05 22:24:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Lori Greiner",
      "screen_name" : "LoriGreiner",
      "indices" : [ 119, 131 ],
      "id_str" : "31869934",
      "id" : 31869934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927289769431846912",
  "text" : "RT @TheSharkDaymond: \"Is it something people need, does it solve a problem, can it be made affordable?\" Great criteria @LoriGreiner  #Shark\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori Greiner",
        "screen_name" : "LoriGreiner",
        "indices" : [ 98, 110 ],
        "id_str" : "31869934",
        "id" : 31869934
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 112, 122 ]
      }, {
        "text" : "GeoOrbital",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924828702894157825",
    "text" : "\"Is it something people need, does it solve a problem, can it be made affordable?\" Great criteria @LoriGreiner  #SharkTank #GeoOrbital",
    "id" : 924828702894157825,
    "created_at" : "2017-10-30 02:41:59 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817056911518482433\/otB2Lkng_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 927289769431846912,
  "created_at" : "2017-11-05 21:41:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CMU Mechanical Eng.",
      "screen_name" : "CMU_Mech",
      "indices" : [ 3, 12 ],
      "id_str" : "177957319",
      "id" : 177957319
    }, {
      "name" : "J. Mater. Chem.",
      "screen_name" : "JMaterChem",
      "indices" : [ 124, 135 ],
      "id_str" : "23571754",
      "id" : 23571754
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ceramic",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/SPWli6vbta",
      "expanded_url" : "http:\/\/rsc.li\/2lF6Fnl",
      "display_url" : "rsc.li\/2lF6Fnl"
    } ]
  },
  "geo" : { },
  "id_str" : "927289479286673408",
  "text" : "RT @CMU_Mech: Unlocking structure of mixed #ceramic oxide films with low temperature EM excitation: https:\/\/t.co\/SPWli6vbta @JMaterChem @b_\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "J. Mater. Chem.",
        "screen_name" : "JMaterChem",
        "indices" : [ 110, 121 ],
        "id_str" : "23571754",
        "id" : 23571754
      }, {
        "name" : "Reeja Jayan",
        "screen_name" : "b_reeja",
        "indices" : [ 122, 130 ],
        "id_str" : "220804239",
        "id" : 220804239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ceramic",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/SPWli6vbta",
        "expanded_url" : "http:\/\/rsc.li\/2lF6Fnl",
        "display_url" : "rsc.li\/2lF6Fnl"
      } ]
    },
    "geo" : { },
    "id_str" : "926132000335024133",
    "text" : "Unlocking structure of mixed #ceramic oxide films with low temperature EM excitation: https:\/\/t.co\/SPWli6vbta @JMaterChem @b_reeja",
    "id" : 926132000335024133,
    "created_at" : "2017-11-02 17:00:50 +0000",
    "user" : {
      "name" : "CMU Mechanical Eng.",
      "screen_name" : "CMU_Mech",
      "protected" : false,
      "id_str" : "177957319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778702094299598849\/6BYyxKUk_normal.jpg",
      "id" : 177957319,
      "verified" : false
    }
  },
  "id" : 927289479286673408,
  "created_at" : "2017-11-05 21:40:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hof",
      "screen_name" : "hofmania",
      "indices" : [ 3, 12 ],
      "id_str" : "36511131",
      "id" : 36511131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/8Xu0Zx0Zud",
      "expanded_url" : "https:\/\/buff.ly\/2zm834n",
      "display_url" : "buff.ly\/2zm834n"
    } ]
  },
  "geo" : { },
  "id_str" : "927289229729783810",
  "text" : "RT @hofmania: Why the Customer Is the Center of Everything in the Membership Economy https:\/\/t.co\/8Xu0Zx0Zud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/8Xu0Zx0Zud",
        "expanded_url" : "https:\/\/buff.ly\/2zm834n",
        "display_url" : "buff.ly\/2zm834n"
      } ]
    },
    "geo" : { },
    "id_str" : "925463904435699713",
    "text" : "Why the Customer Is the Center of Everything in the Membership Economy https:\/\/t.co\/8Xu0Zx0Zud",
    "id" : 925463904435699713,
    "created_at" : "2017-10-31 20:46:03 +0000",
    "user" : {
      "name" : "Hof",
      "screen_name" : "hofmania",
      "protected" : false,
      "id_str" : "36511131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691793094912647169\/Ob-texZ1_normal.jpg",
      "id" : 36511131,
      "verified" : false
    }
  },
  "id" : 927289229729783810,
  "created_at" : "2017-11-05 21:39:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNNMoney",
      "screen_name" : "CNNMoney",
      "indices" : [ 3, 12 ],
      "id_str" : "16184358",
      "id" : 16184358
    }, {
      "name" : "McDonald's",
      "screen_name" : "McDonalds",
      "indices" : [ 44, 54 ],
      "id_str" : "71026122",
      "id" : 71026122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/tImRqGirsJ",
      "expanded_url" : "http:\/\/cnnmon.ie\/2z83iuT",
      "display_url" : "cnnmon.ie\/2z83iuT"
    } ]
  },
  "geo" : { },
  "id_str" : "927289150944014346",
  "text" : "RT @CNNMoney: Get ready for the return of a @McDonalds cult classic. https:\/\/t.co\/tImRqGirsJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "McDonald's",
        "screen_name" : "McDonalds",
        "indices" : [ 30, 40 ],
        "id_str" : "71026122",
        "id" : 71026122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/tImRqGirsJ",
        "expanded_url" : "http:\/\/cnnmon.ie\/2z83iuT",
        "display_url" : "cnnmon.ie\/2z83iuT"
      } ]
    },
    "geo" : { },
    "id_str" : "927288915941314560",
    "text" : "Get ready for the return of a @McDonalds cult classic. https:\/\/t.co\/tImRqGirsJ",
    "id" : 927288915941314560,
    "created_at" : "2017-11-05 21:38:00 +0000",
    "user" : {
      "name" : "CNNMoney",
      "screen_name" : "CNNMoney",
      "protected" : false,
      "id_str" : "16184358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921416918711635968\/sYrMI3VY_normal.jpg",
      "id" : 16184358,
      "verified" : true
    }
  },
  "id" : 927289150944014346,
  "created_at" : "2017-11-05 21:38:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Status",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927289093456912392",
  "text" : "Will be some downtime again today as rebooting P2P servers, plan on maybe doing an upgrade, working on huge research proposal today #Status",
  "id" : 927289093456912392,
  "created_at" : "2017-11-05 21:38:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927254833341624320",
  "text" : "RT @lorenridinger: \"Everyone faces obstacles. What matters is how you deal with them. The choice is entirely yours.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927204125036642306",
    "text" : "\"Everyone faces obstacles. What matters is how you deal with them. The choice is entirely yours.\"",
    "id" : 927204125036642306,
    "created_at" : "2017-11-05 16:01:04 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 927254833341624320,
  "created_at" : "2017-11-05 19:22:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Z370",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hN8lAc4x3y",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/asrock-z370-taichi-intel-coffee-lake-atx-motherboard,5279.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/asrock\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927220271320326149",
  "text" : "RT @tomshardware: \u25B8 ASRock #Z370 Taichi \u2018Coffee Lake\u2019 Motherboard Review https:\/\/t.co\/hN8lAc4x3y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Z370",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hN8lAc4x3y",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/asrock-z370-taichi-intel-coffee-lake-atx-motherboard,5279.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/asrock\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "927160088120274946",
    "text" : "\u25B8 ASRock #Z370 Taichi \u2018Coffee Lake\u2019 Motherboard Review https:\/\/t.co\/hN8lAc4x3y",
    "id" : 927160088120274946,
    "created_at" : "2017-11-05 13:06:05 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 927220271320326149,
  "created_at" : "2017-11-05 17:05:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BangerOfTheDay",
      "screen_name" : "BangerOfTheDay",
      "indices" : [ 3, 18 ],
      "id_str" : "3152485242",
      "id" : 3152485242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927039215552159744",
  "text" : "RT @BangerOfTheDay: One day all those late nights and early mornings will pay off.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926800698678894592",
    "text" : "One day all those late nights and early mornings will pay off.",
    "id" : 926800698678894592,
    "created_at" : "2017-11-04 13:18:00 +0000",
    "user" : {
      "name" : "BangerOfTheDay",
      "screen_name" : "BangerOfTheDay",
      "protected" : false,
      "id_str" : "3152485242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757213762268999680\/VU2sHjYf_normal.jpg",
      "id" : 3152485242,
      "verified" : false
    }
  },
  "id" : 927039215552159744,
  "created_at" : "2017-11-05 05:05:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D World",
      "screen_name" : "3DWorldMag",
      "indices" : [ 3, 14 ],
      "id_str" : "45561740",
      "id" : 45561740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ZRXAjHfUuI",
      "expanded_url" : "http:\/\/www.creativebloq.com\/how-to\/how-to-move-between-daz-studio-and-zbrush",
      "display_url" : "creativebloq.com\/how-to\/how-to-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927039159260368896",
  "text" : "RT @3DWorldMag: Get the most out of two popular 3D tools with these tips. https:\/\/t.co\/ZRXAjHfUuI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/ZRXAjHfUuI",
        "expanded_url" : "http:\/\/www.creativebloq.com\/how-to\/how-to-move-between-daz-studio-and-zbrush",
        "display_url" : "creativebloq.com\/how-to\/how-to-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "923491397218467840",
    "text" : "Get the most out of two popular 3D tools with these tips. https:\/\/t.co\/ZRXAjHfUuI",
    "id" : 923491397218467840,
    "created_at" : "2017-10-26 10:08:01 +0000",
    "user" : {
      "name" : "3D World",
      "screen_name" : "3DWorldMag",
      "protected" : false,
      "id_str" : "45561740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440833561851990016\/IYSna6yF_normal.jpeg",
      "id" : 45561740,
      "verified" : false
    }
  },
  "id" : 927039159260368896,
  "created_at" : "2017-11-05 05:05:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "indices" : [ 3, 16 ],
      "id_str" : "418597196",
      "id" : 418597196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OL5y8s2KQI",
      "expanded_url" : "http:\/\/www.creativebloq.com\/jobs\/free-creative-business-card-templates-designers-12121565",
      "display_url" : "creativebloq.com\/jobs\/free-crea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927039035574546432",
  "text" : "RT @CreativeBloq: Need to create a business card but not sure where to start? https:\/\/t.co\/OL5y8s2KQI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/OL5y8s2KQI",
        "expanded_url" : "http:\/\/www.creativebloq.com\/jobs\/free-creative-business-card-templates-designers-12121565",
        "display_url" : "creativebloq.com\/jobs\/free-crea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925773471489159168",
    "text" : "Need to create a business card but not sure where to start? https:\/\/t.co\/OL5y8s2KQI",
    "id" : 925773471489159168,
    "created_at" : "2017-11-01 17:16:10 +0000",
    "user" : {
      "name" : "Creative Bloq",
      "screen_name" : "CreativeBloq",
      "protected" : false,
      "id_str" : "418597196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880112520383606785\/cBPw6RSd_normal.jpg",
      "id" : 418597196,
      "verified" : true
    }
  },
  "id" : 927039035574546432,
  "created_at" : "2017-11-05 05:05:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/O4gsOlFcvF",
      "expanded_url" : "https:\/\/resources.github.com\/webcasts\/Engineering-the-new-automotive-ecosystem\/?utm_source=twitter&utm_medium=social&utm_campaign=amer-wbr-engineeringnewautoeco-201701116",
      "display_url" : "resources.github.com\/webcasts\/Engin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927038878116139008",
  "text" : "RT @github: We're discussing what's driving engineers in the automotive industry. Join in November 14! https:\/\/t.co\/O4gsOlFcvF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/O4gsOlFcvF",
        "expanded_url" : "https:\/\/resources.github.com\/webcasts\/Engineering-the-new-automotive-ecosystem\/?utm_source=twitter&utm_medium=social&utm_campaign=amer-wbr-engineeringnewautoeco-201701116",
        "display_url" : "resources.github.com\/webcasts\/Engin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926584805596237824",
    "text" : "We're discussing what's driving engineers in the automotive industry. Join in November 14! https:\/\/t.co\/O4gsOlFcvF",
    "id" : 926584805596237824,
    "created_at" : "2017-11-03 23:00:07 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616309728688238592\/pBeeJQDQ_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 927038878116139008,
  "created_at" : "2017-11-05 05:04:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The PocketLab",
      "screen_name" : "ThePocketLab",
      "indices" : [ 3, 16 ],
      "id_str" : "2494549105",
      "id" : 2494549105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PocketLabIt",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927038484048687105",
  "text" : "RT @ThePocketLab: PocketLab Voyager's wireless rangefinder provides a unique experience in the physics classroom! #PocketLabIt https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/myemma.com\" rel=\"nofollow\"\u003EEmma Social Connector\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PocketLabIt",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/DWttegXoBN",
        "expanded_url" : "https:\/\/t.e2ma.net\/cshare\/inbound\/t\/kkobo\/534d7a1890ea256e22fb6a8cabdf1b3b",
        "display_url" : "t.e2ma.net\/cshare\/inbound\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918192367534071810",
    "text" : "PocketLab Voyager's wireless rangefinder provides a unique experience in the physics classroom! #PocketLabIt https:\/\/t.co\/DWttegXoBN",
    "id" : 918192367534071810,
    "created_at" : "2017-10-11 19:11:34 +0000",
    "user" : {
      "name" : "The PocketLab",
      "screen_name" : "ThePocketLab",
      "protected" : false,
      "id_str" : "2494549105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555425080188993536\/5qGT9mMP_normal.png",
      "id" : 2494549105,
      "verified" : false
    }
  },
  "id" : 927038484048687105,
  "created_at" : "2017-11-05 05:02:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brilliant.org",
      "screen_name" : "brilliantorg",
      "indices" : [ 3, 16 ],
      "id_str" : "987070152",
      "id" : 987070152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927038211175612416",
  "text" : "RT @brilliantorg: We are in awe that so many people spent part of their summer attacking these challenging math puzzles. 1,799 attempted al\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "910199082869592064",
    "geo" : { },
    "id_str" : "910201017068748800",
    "in_reply_to_user_id" : 987070152,
    "text" : "We are in awe that so many people spent part of their summer attacking these challenging math puzzles. 1,799 attempted all 100 -- nice work!",
    "id" : 910201017068748800,
    "in_reply_to_status_id" : 910199082869592064,
    "created_at" : "2017-09-19 17:56:47 +0000",
    "in_reply_to_screen_name" : "brilliantorg",
    "in_reply_to_user_id_str" : "987070152",
    "user" : {
      "name" : "Brilliant.org",
      "screen_name" : "brilliantorg",
      "protected" : false,
      "id_str" : "987070152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618096880304566272\/mMyKMQfN_normal.png",
      "id" : 987070152,
      "verified" : true
    }
  },
  "id" : 927038211175612416,
  "created_at" : "2017-11-05 05:01:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927038059778052096",
  "text" : "RT @Fact: Sometimes you have to walk away from people, not because you don't care, but because they don't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "927016121437388803",
    "text" : "Sometimes you have to walk away from people, not because you don't care, but because they don't.",
    "id" : 927016121437388803,
    "created_at" : "2017-11-05 03:34:01 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 927038059778052096,
  "created_at" : "2017-11-05 05:01:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Sweeney",
      "screen_name" : "TimSweeneyEpic",
      "indices" : [ 3, 18 ],
      "id_str" : "1686323288",
      "id" : 1686323288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927038041977483265",
  "text" : "RT @TimSweeneyEpic: This is an incredibly repulsive idea, that word processing software could dictate what you are allowed to write about a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/GmHhNVTeXU",
        "expanded_url" : "https:\/\/twitter.com\/themarialima\/status\/925414006755610630",
        "display_url" : "twitter.com\/themarialima\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925424232531677184",
    "text" : "This is an incredibly repulsive idea, that word processing software could dictate what you are allowed to write about and publish. https:\/\/t.co\/GmHhNVTeXU",
    "id" : 925424232531677184,
    "created_at" : "2017-10-31 18:08:25 +0000",
    "user" : {
      "name" : "Tim Sweeney",
      "screen_name" : "TimSweeneyEpic",
      "protected" : false,
      "id_str" : "1686323288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795819168629198849\/SBY3ARvZ_normal.jpg",
      "id" : 1686323288,
      "verified" : false
    }
  },
  "id" : 927038041977483265,
  "created_at" : "2017-11-05 05:01:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/OVv8aL3d6H",
      "expanded_url" : "http:\/\/ift.tt\/2A8OrgB",
      "display_url" : "ift.tt\/2A8OrgB"
    } ]
  },
  "geo" : { },
  "id_str" : "927034958891413504",
  "text" : "RT @dronepilots: Drone lost during filming on Keuka Lake | DronePilots - https:\/\/t.co\/OVv8aL3d6H #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/OVv8aL3d6H",
        "expanded_url" : "http:\/\/ift.tt\/2A8OrgB",
        "display_url" : "ift.tt\/2A8OrgB"
      } ]
    },
    "geo" : { },
    "id_str" : "927025254500888576",
    "text" : "Drone lost during filming on Keuka Lake | DronePilots - https:\/\/t.co\/OVv8aL3d6H #drones",
    "id" : 927025254500888576,
    "created_at" : "2017-11-05 04:10:18 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 927034958891413504,
  "created_at" : "2017-11-05 04:48:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotlight Show",
      "screen_name" : "SpotlightShow12",
      "indices" : [ 3, 19 ],
      "id_str" : "621122060",
      "id" : 621122060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/k1VB66jfjX",
      "expanded_url" : "http:\/\/dlvr.it\/PzDRsB",
      "display_url" : "dlvr.it\/PzDRsB"
    } ]
  },
  "geo" : { },
  "id_str" : "927024978591182848",
  "text" : "RT @SpotlightShow12: First Rock From Outside the Solar System Sails Past Earth - National Geographic https:\/\/t.co\/k1VB66jfjX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/k1VB66jfjX",
        "expanded_url" : "http:\/\/dlvr.it\/PzDRsB",
        "display_url" : "dlvr.it\/PzDRsB"
      } ]
    },
    "geo" : { },
    "id_str" : "926856983533125633",
    "text" : "First Rock From Outside the Solar System Sails Past Earth - National Geographic https:\/\/t.co\/k1VB66jfjX",
    "id" : 926856983533125633,
    "created_at" : "2017-11-04 17:01:39 +0000",
    "user" : {
      "name" : "Spotlight Show",
      "screen_name" : "SpotlightShow12",
      "protected" : false,
      "id_str" : "621122060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2389591625\/h25n5mzbwuuq1hg2hdk1_normal.jpeg",
      "id" : 621122060,
      "verified" : false
    }
  },
  "id" : 927024978591182848,
  "created_at" : "2017-11-05 04:09:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "indices" : [ 3, 10 ],
      "id_str" : "15919988",
      "id" : 15919988
    }, {
      "name" : "Science News",
      "screen_name" : "ScienceNews",
      "indices" : [ 79, 91 ],
      "id_str" : "19402238",
      "id" : 19402238
    }, {
      "name" : "Emily Conover",
      "screen_name" : "emcconover",
      "indices" : [ 92, 103 ],
      "id_str" : "1614057440",
      "id" : 1614057440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/G7h66cRyn7",
      "expanded_url" : "https:\/\/goo.gl\/55nyrk",
      "display_url" : "goo.gl\/55nyrk"
    } ]
  },
  "geo" : { },
  "id_str" : "927024861649784832",
  "text" : "RT @xprize: Some interesting new insight into photons: https:\/\/t.co\/G7h66cRyn7 @ScienceNews @emcconover",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science News",
        "screen_name" : "ScienceNews",
        "indices" : [ 67, 79 ],
        "id_str" : "19402238",
        "id" : 19402238
      }, {
        "name" : "Emily Conover",
        "screen_name" : "emcconover",
        "indices" : [ 80, 91 ],
        "id_str" : "1614057440",
        "id" : 1614057440
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/G7h66cRyn7",
        "expanded_url" : "https:\/\/goo.gl\/55nyrk",
        "display_url" : "goo.gl\/55nyrk"
      } ]
    },
    "geo" : { },
    "id_str" : "927022705601368065",
    "text" : "Some interesting new insight into photons: https:\/\/t.co\/G7h66cRyn7 @ScienceNews @emcconover",
    "id" : 927022705601368065,
    "created_at" : "2017-11-05 04:00:10 +0000",
    "user" : {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "protected" : false,
      "id_str" : "15919988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890261363808886784\/WJyNCRI__normal.jpg",
      "id" : 15919988,
      "verified" : true
    }
  },
  "id" : 927024861649784832,
  "created_at" : "2017-11-05 04:08:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/nSveqt4Dpt",
      "expanded_url" : "http:\/\/depot.ly\/QCpD30ggPKE",
      "display_url" : "depot.ly\/QCpD30ggPKE"
    } ]
  },
  "geo" : { },
  "id_str" : "927024173934956544",
  "text" : "RT @DesignerDepot: Transform SVG into React Components https:\/\/t.co\/nSveqt4Dpt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/nSveqt4Dpt",
        "expanded_url" : "http:\/\/depot.ly\/QCpD30ggPKE",
        "display_url" : "depot.ly\/QCpD30ggPKE"
      } ]
    },
    "geo" : { },
    "id_str" : "925668789211074560",
    "text" : "Transform SVG into React Components https:\/\/t.co\/nSveqt4Dpt",
    "id" : 925668789211074560,
    "created_at" : "2017-11-01 10:20:12 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 927024173934956544,
  "created_at" : "2017-11-05 04:06:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vsauce",
      "screen_name" : "tweetsauce",
      "indices" : [ 3, 14 ],
      "id_str" : "395477244",
      "id" : 395477244
    }, {
      "name" : "Brian Cox",
      "screen_name" : "ProfBrianCox",
      "indices" : [ 30, 43 ],
      "id_str" : "17939037",
      "id" : 17939037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/8OhJi1HJ6f",
      "expanded_url" : "https:\/\/youtu.be\/E43-CfukEgs",
      "display_url" : "youtu.be\/E43-CfukEgs"
    } ]
  },
  "geo" : { },
  "id_str" : "927023930212278272",
  "text" : "RT @tweetsauce: So beautiful. @ProfBrianCox watches a bowling ball and feather fall in a giant vacuum chamber https:\/\/t.co\/8OhJi1HJ6f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Cox",
        "screen_name" : "ProfBrianCox",
        "indices" : [ 14, 27 ],
        "id_str" : "17939037",
        "id" : 17939037
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/8OhJi1HJ6f",
        "expanded_url" : "https:\/\/youtu.be\/E43-CfukEgs",
        "display_url" : "youtu.be\/E43-CfukEgs"
      } ]
    },
    "geo" : { },
    "id_str" : "926993288430784512",
    "text" : "So beautiful. @ProfBrianCox watches a bowling ball and feather fall in a giant vacuum chamber https:\/\/t.co\/8OhJi1HJ6f",
    "id" : 926993288430784512,
    "created_at" : "2017-11-05 02:03:17 +0000",
    "user" : {
      "name" : "Vsauce",
      "screen_name" : "tweetsauce",
      "protected" : false,
      "id_str" : "395477244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431436560009932800\/PqD9V8km_normal.png",
      "id" : 395477244,
      "verified" : true
    }
  },
  "id" : 927023930212278272,
  "created_at" : "2017-11-05 04:05:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/JKz0nlM5Z9",
      "expanded_url" : "http:\/\/youtu.be\/VsRot0p7ObY?a",
      "display_url" : "youtu.be\/VsRot0p7ObY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927023846275928065",
  "text" : "RT @colin_furze: How did it live so long https:\/\/t.co\/JKz0nlM5Z9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/JKz0nlM5Z9",
        "expanded_url" : "http:\/\/youtu.be\/VsRot0p7ObY?a",
        "display_url" : "youtu.be\/VsRot0p7ObY?a"
      } ]
    },
    "geo" : { },
    "id_str" : "926118097563586560",
    "text" : "How did it live so long https:\/\/t.co\/JKz0nlM5Z9",
    "id" : 926118097563586560,
    "created_at" : "2017-11-02 16:05:35 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 927023846275928065,
  "created_at" : "2017-11-05 04:04:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "indices" : [ 3, 15 ],
      "id_str" : "207784631",
      "id" : 207784631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927023675127271424",
  "text" : "RT @JonTronShow: JK the Seinfeld one could never get boring and how dare you suggest it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926623709422608384",
    "geo" : { },
    "id_str" : "926623884945903616",
    "in_reply_to_user_id" : 207784631,
    "text" : "JK the Seinfeld one could never get boring and how dare you suggest it",
    "id" : 926623884945903616,
    "in_reply_to_status_id" : 926623709422608384,
    "created_at" : "2017-11-04 01:35:24 +0000",
    "in_reply_to_screen_name" : "JonTronShow",
    "in_reply_to_user_id_str" : "207784631",
    "user" : {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "protected" : false,
      "id_str" : "207784631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923267770548211713\/LWemsfa3_normal.jpg",
      "id" : 207784631,
      "verified" : true
    }
  },
  "id" : 927023675127271424,
  "created_at" : "2017-11-05 04:04:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Stuffin Devon",
      "screen_name" : "josephdevon",
      "indices" : [ 3, 15 ],
      "id_str" : "19367241",
      "id" : 19367241
    }, {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "indices" : [ 17, 29 ],
      "id_str" : "207784631",
      "id" : 207784631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927023651731529728",
  "text" : "RT @josephdevon: @JonTronShow Why do you do these things, Jon?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JonTron",
        "screen_name" : "JonTronShow",
        "indices" : [ 0, 12 ],
        "id_str" : "207784631",
        "id" : 207784631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926625383855902725",
    "geo" : { },
    "id_str" : "926625657890705408",
    "in_reply_to_user_id" : 207784631,
    "text" : "@JonTronShow Why do you do these things, Jon?",
    "id" : 926625657890705408,
    "in_reply_to_status_id" : 926625383855902725,
    "created_at" : "2017-11-04 01:42:27 +0000",
    "in_reply_to_screen_name" : "JonTronShow",
    "in_reply_to_user_id_str" : "207784631",
    "user" : {
      "name" : "Joseph Stuffin Devon",
      "screen_name" : "josephdevon",
      "protected" : false,
      "id_str" : "19367241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/124236595\/mereadingcrop_normal.jpg",
      "id" : 19367241,
      "verified" : false
    }
  },
  "id" : 927023651731529728,
  "created_at" : "2017-11-05 04:03:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "indices" : [ 3, 15 ],
      "id_str" : "207784631",
      "id" : 207784631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927023611663265792",
  "text" : "RT @JonTronShow: Has anyone made a sitcom porno parody called \"Parks and Procreation\" yet? The Seinfeld one is getting boring...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926623709422608384",
    "text" : "Has anyone made a sitcom porno parody called \"Parks and Procreation\" yet? The Seinfeld one is getting boring...",
    "id" : 926623709422608384,
    "created_at" : "2017-11-04 01:34:42 +0000",
    "user" : {
      "name" : "JonTron",
      "screen_name" : "JonTronShow",
      "protected" : false,
      "id_str" : "207784631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923267770548211713\/LWemsfa3_normal.jpg",
      "id" : 207784631,
      "verified" : true
    }
  },
  "id" : 927023611663265792,
  "created_at" : "2017-11-05 04:03:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Game Grumps",
      "screen_name" : "GameGrumps",
      "indices" : [ 3, 14 ],
      "id_str" : "701983068",
      "id" : 701983068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/EYx2K9xrNH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=a2tSrUb7EGU",
      "display_url" : "youtube.com\/watch?v=a2tSrU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927023529618497537",
  "text" : "RT @GameGrumps: It's our best of October 2017! https:\/\/t.co\/EYx2K9xrNH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/EYx2K9xrNH",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=a2tSrUb7EGU",
        "display_url" : "youtube.com\/watch?v=a2tSrU\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926969120742031360",
    "text" : "It's our best of October 2017! https:\/\/t.co\/EYx2K9xrNH",
    "id" : 926969120742031360,
    "created_at" : "2017-11-05 00:27:15 +0000",
    "user" : {
      "name" : "Game Grumps",
      "screen_name" : "GameGrumps",
      "protected" : false,
      "id_str" : "701983068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848986633063890945\/RrJ8tOFD_normal.jpg",
      "id" : 701983068,
      "verified" : true
    }
  },
  "id" : 927023529618497537,
  "created_at" : "2017-11-05 04:03:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motor Trend",
      "screen_name" : "MotorTrend",
      "indices" : [ 3, 14 ],
      "id_str" : "25383000",
      "id" : 25383000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ludicrous",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "WGDR7",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ImvNAm2Yop",
      "expanded_url" : "http:\/\/www.motortrend.com\/news\/worlds-greatest-drag-race-7\/",
      "display_url" : "motortrend.com\/news\/worlds-gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927023276412596224",
  "text" : "RT @MotorTrend: Shocking winner of our latest, World's Greatest Drag Race 7! Maybe even #ludicrous? #WGDR7 https:\/\/t.co\/ImvNAm2Yop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ludicrous",
        "indices" : [ 72, 82 ]
      }, {
        "text" : "WGDR7",
        "indices" : [ 84, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ImvNAm2Yop",
        "expanded_url" : "http:\/\/www.motortrend.com\/news\/worlds-greatest-drag-race-7\/",
        "display_url" : "motortrend.com\/news\/worlds-gr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "910853351406919680",
    "text" : "Shocking winner of our latest, World's Greatest Drag Race 7! Maybe even #ludicrous? #WGDR7 https:\/\/t.co\/ImvNAm2Yop",
    "id" : 910853351406919680,
    "created_at" : "2017-09-21 13:08:56 +0000",
    "user" : {
      "name" : "Motor Trend",
      "screen_name" : "MotorTrend",
      "protected" : false,
      "id_str" : "25383000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809800077048807425\/HXRG5DLO_normal.jpg",
      "id" : 25383000,
      "verified" : true
    }
  },
  "id" : 927023276412596224,
  "created_at" : "2017-11-05 04:02:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927023238391222272",
  "text" : "RT @elonmusk: Tesla Semi unveil now Nov 16. Diverting resources to fix Model 3 bottlenecks &amp; increase battery production for Puerto Rico &amp;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "916395155120205825",
    "text" : "Tesla Semi unveil now Nov 16. Diverting resources to fix Model 3 bottlenecks &amp; increase battery production for Puerto Rico &amp; other affected areas.",
    "id" : 916395155120205825,
    "created_at" : "2017-10-06 20:10:05 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 927023238391222272,
  "created_at" : "2017-11-05 04:02:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00E9bastien Miglio",
      "screen_name" : "smiglio",
      "indices" : [ 3, 11 ],
      "id_str" : "28145093",
      "id" : 28145093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/5JmuWK1DV4",
      "expanded_url" : "https:\/\/lnkd.in\/dGJU4sm",
      "display_url" : "lnkd.in\/dGJU4sm"
    } ]
  },
  "geo" : { },
  "id_str" : "927023108543959040",
  "text" : "RT @smiglio: Epic Conversations at Autodesk University 2017 https:\/\/t.co\/5JmuWK1DV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/5JmuWK1DV4",
        "expanded_url" : "https:\/\/lnkd.in\/dGJU4sm",
        "display_url" : "lnkd.in\/dGJU4sm"
      } ]
    },
    "geo" : { },
    "id_str" : "925116272064516096",
    "text" : "Epic Conversations at Autodesk University 2017 https:\/\/t.co\/5JmuWK1DV4",
    "id" : 925116272064516096,
    "created_at" : "2017-10-30 21:44:41 +0000",
    "user" : {
      "name" : "S\u00E9bastien Miglio",
      "screen_name" : "smiglio",
      "protected" : false,
      "id_str" : "28145093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872057817137545217\/sCrCOiho_normal.jpg",
      "id" : 28145093,
      "verified" : false
    }
  },
  "id" : 927023108543959040,
  "created_at" : "2017-11-05 04:01:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathew Wadstein",
      "screen_name" : "mathewwadstein",
      "indices" : [ 3, 18 ],
      "id_str" : "362297591",
      "id" : 362297591
    }, {
      "name" : "Unreal Engine",
      "screen_name" : "UnrealEngine",
      "indices" : [ 90, 103 ],
      "id_str" : "164081884",
      "id" : 164081884
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UE4",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZPKQz70zQG",
      "expanded_url" : "https:\/\/youtu.be\/Wv3U2iOL3C4",
      "display_url" : "youtu.be\/Wv3U2iOL3C4"
    } ]
  },
  "geo" : { },
  "id_str" : "927022983973097473",
  "text" : "RT @mathewwadstein: Today, I take a look at Volumetric Lightmaps &amp; Fog interaction in @UnrealEngine 4.18 #UE4 https:\/\/t.co\/ZPKQz70zQG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unreal Engine",
        "screen_name" : "UnrealEngine",
        "indices" : [ 70, 83 ],
        "id_str" : "164081884",
        "id" : 164081884
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UE4",
        "indices" : [ 89, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ZPKQz70zQG",
        "expanded_url" : "https:\/\/youtu.be\/Wv3U2iOL3C4",
        "display_url" : "youtu.be\/Wv3U2iOL3C4"
      } ]
    },
    "geo" : { },
    "id_str" : "926124721237721088",
    "text" : "Today, I take a look at Volumetric Lightmaps &amp; Fog interaction in @UnrealEngine 4.18 #UE4 https:\/\/t.co\/ZPKQz70zQG",
    "id" : 926124721237721088,
    "created_at" : "2017-11-02 16:31:54 +0000",
    "user" : {
      "name" : "Mathew Wadstein",
      "screen_name" : "mathewwadstein",
      "protected" : false,
      "id_str" : "362297591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662347318650212352\/hu-AiNud_normal.jpg",
      "id" : 362297591,
      "verified" : false
    }
  },
  "id" : 927022983973097473,
  "created_at" : "2017-11-05 04:01:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mathew Wadstein",
      "screen_name" : "mathewwadstein",
      "indices" : [ 3, 18 ],
      "id_str" : "362297591",
      "id" : 362297591
    }, {
      "name" : "Unreal Engine",
      "screen_name" : "UnrealEngine",
      "indices" : [ 69, 82 ],
      "id_str" : "164081884",
      "id" : 164081884
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UE4",
      "indices" : [ 88, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/rOJ3SZ7zUb",
      "expanded_url" : "http:\/\/youtu.be\/DFlVhJRgZBE?a",
      "display_url" : "youtu.be\/DFlVhJRgZBE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "927022939538624512",
  "text" : "RT @mathewwadstein: Here's a quick overview of a few new features in @UnrealEngine 4.18 #UE4 https:\/\/t.co\/rOJ3SZ7zUb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unreal Engine",
        "screen_name" : "UnrealEngine",
        "indices" : [ 49, 62 ],
        "id_str" : "164081884",
        "id" : 164081884
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UE4",
        "indices" : [ 68, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/rOJ3SZ7zUb",
        "expanded_url" : "http:\/\/youtu.be\/DFlVhJRgZBE?a",
        "display_url" : "youtu.be\/DFlVhJRgZBE?a"
      } ]
    },
    "geo" : { },
    "id_str" : "926826438786875393",
    "text" : "Here's a quick overview of a few new features in @UnrealEngine 4.18 #UE4 https:\/\/t.co\/rOJ3SZ7zUb",
    "id" : 926826438786875393,
    "created_at" : "2017-11-04 15:00:17 +0000",
    "user" : {
      "name" : "Mathew Wadstein",
      "screen_name" : "mathewwadstein",
      "protected" : false,
      "id_str" : "362297591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662347318650212352\/hu-AiNud_normal.jpg",
      "id" : 362297591,
      "verified" : false
    }
  },
  "id" : 927022939538624512,
  "created_at" : "2017-11-05 04:01:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parrot",
      "screen_name" : "Parrot",
      "indices" : [ 3, 10 ],
      "id_str" : "45519721",
      "id" : 45519721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParrotProfessional",
      "indices" : [ 106, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927022842448883712",
  "text" : "RT @Parrot: \"Parrot is continuing its push into the commercial drone space\". Nice article from TechCrunch #ParrotProfessional\n\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParrotProfessional",
        "indices" : [ 94, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/LVeiCKaENM",
        "expanded_url" : "https:\/\/techcrunch.com\/2017\/10\/24\/parrot-releases-drones-for-firefighters-and-farmers\/",
        "display_url" : "techcrunch.com\/2017\/10\/24\/par\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "923199723028209664",
    "text" : "\"Parrot is continuing its push into the commercial drone space\". Nice article from TechCrunch #ParrotProfessional\n\nhttps:\/\/t.co\/LVeiCKaENM",
    "id" : 923199723028209664,
    "created_at" : "2017-10-25 14:49:00 +0000",
    "user" : {
      "name" : "Parrot",
      "screen_name" : "Parrot",
      "protected" : false,
      "id_str" : "45519721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699530027688464384\/gCAR8Asz_normal.png",
      "id" : 45519721,
      "verified" : true
    }
  },
  "id" : 927022842448883712,
  "created_at" : "2017-11-05 04:00:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parrot",
      "screen_name" : "Parrot",
      "indices" : [ 3, 10 ],
      "id_str" : "45519721",
      "id" : 45519721
    }, {
      "name" : "Apple",
      "screen_name" : "Apple",
      "indices" : [ 22, 28 ],
      "id_str" : "380749300",
      "id" : 380749300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927022786735943680",
  "text" : "RT @Parrot: Thanks to @Apple 11.1 iOS release, you should no longer experience USB connection problems with your Parrot Skycontroller 2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apple",
        "screen_name" : "Apple",
        "indices" : [ 10, 16 ],
        "id_str" : "380749300",
        "id" : 380749300
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926498524816080897",
    "text" : "Thanks to @Apple 11.1 iOS release, you should no longer experience USB connection problems with your Parrot Skycontroller 2",
    "id" : 926498524816080897,
    "created_at" : "2017-11-03 17:17:16 +0000",
    "user" : {
      "name" : "Parrot",
      "screen_name" : "Parrot",
      "protected" : false,
      "id_str" : "45519721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699530027688464384\/gCAR8Asz_normal.png",
      "id" : 45519721,
      "verified" : true
    }
  },
  "id" : 927022786735943680,
  "created_at" : "2017-11-05 04:00:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/fqPAOzICbk",
      "expanded_url" : "https:\/\/twitter.com\/giveawayzotrix\/status\/867055466358198273",
      "display_url" : "twitter.com\/giveawayzotrix\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927022453636894720",
  "text" : "Oh the memories, lol https:\/\/t.co\/fqPAOzICbk",
  "id" : 927022453636894720,
  "created_at" : "2017-11-05 03:59:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BitcoinAgile",
      "screen_name" : "bitcoinagile",
      "indices" : [ 3, 16 ],
      "id_str" : "2281314234",
      "id" : 2281314234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "blockchain",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "medium",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/E4L2H1MK7O",
      "expanded_url" : "https:\/\/medium.com\/@gamer456148\/why-cryptocurrency-needs-to-benefit-us-563b858503c9",
      "display_url" : "medium.com\/@gamer456148\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927022248871055360",
  "text" : "RT @bitcoinagile: Why Cryptocurrency Needs to Benefit Us?  Andrew Kamal  Medium #bitcoin #blockchain #medium https:\/\/t.co\/E4L2H1MK7O https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcoinagile.com\" rel=\"nofollow\"\u003Ebitcoinagile\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bitcoinagile\/status\/908325405374992384\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/d6JFKsvbzo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DJsFJDSXkAAfGDE.jpg",
        "id_str" : "908325402904596480",
        "id" : 908325402904596480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DJsFJDSXkAAfGDE.jpg",
        "sizes" : [ {
          "h" : 638,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 638,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/d6JFKsvbzo"
      } ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "blockchain",
        "indices" : [ 71, 82 ]
      }, {
        "text" : "medium",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/E4L2H1MK7O",
        "expanded_url" : "https:\/\/medium.com\/@gamer456148\/why-cryptocurrency-needs-to-benefit-us-563b858503c9",
        "display_url" : "medium.com\/@gamer456148\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "908325405374992384",
    "text" : "Why Cryptocurrency Needs to Benefit Us?  Andrew Kamal  Medium #bitcoin #blockchain #medium https:\/\/t.co\/E4L2H1MK7O https:\/\/t.co\/d6JFKsvbzo",
    "id" : 908325405374992384,
    "created_at" : "2017-09-14 13:43:47 +0000",
    "user" : {
      "name" : "BitcoinAgile",
      "screen_name" : "bitcoinagile",
      "protected" : false,
      "id_str" : "2281314234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/902617531109617665\/-5e-1IJw_normal.jpg",
      "id" : 2281314234,
      "verified" : false
    }
  },
  "id" : 927022248871055360,
  "created_at" : "2017-11-05 03:58:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netlify",
      "screen_name" : "Netlify",
      "indices" : [ 3, 11 ],
      "id_str" : "2571501973",
      "id" : 2571501973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodevember2017",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/wl7EH0fjc3",
      "expanded_url" : "https:\/\/buff.ly\/2yjR4zr",
      "display_url" : "buff.ly\/2yjR4zr"
    } ]
  },
  "geo" : { },
  "id_str" : "927021808288747520",
  "text" : "RT @Netlify: Two days of Node and JavaScript? We're in! See you in a few weeks at #nodevember2017 https:\/\/t.co\/wl7EH0fjc3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nodevember2017",
        "indices" : [ 69, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/wl7EH0fjc3",
        "expanded_url" : "https:\/\/buff.ly\/2yjR4zr",
        "display_url" : "buff.ly\/2yjR4zr"
      } ]
    },
    "geo" : { },
    "id_str" : "925736985427312640",
    "text" : "Two days of Node and JavaScript? We're in! See you in a few weeks at #nodevember2017 https:\/\/t.co\/wl7EH0fjc3",
    "id" : 925736985427312640,
    "created_at" : "2017-11-01 14:51:11 +0000",
    "user" : {
      "name" : "Netlify",
      "screen_name" : "Netlify",
      "protected" : false,
      "id_str" : "2571501973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872120900824465409\/wzHpXdzl_normal.jpg",
      "id" : 2571501973,
      "verified" : false
    }
  },
  "id" : 927021808288747520,
  "created_at" : "2017-11-05 03:56:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "React",
      "screen_name" : "reactjs",
      "indices" : [ 3, 11 ],
      "id_str" : "1566463268",
      "id" : 1566463268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/6dPgYxaeyq",
      "expanded_url" : "https:\/\/twitter.com\/dan_abramov\/status\/917137653593772032",
      "display_url" : "twitter.com\/dan_abramov\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927021704148332544",
  "text" : "RT @reactjs: Check out these awesome projects and examples! https:\/\/t.co\/6dPgYxaeyq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/6dPgYxaeyq",
        "expanded_url" : "https:\/\/twitter.com\/dan_abramov\/status\/917137653593772032",
        "display_url" : "twitter.com\/dan_abramov\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918037452455018497",
    "text" : "Check out these awesome projects and examples! https:\/\/t.co\/6dPgYxaeyq",
    "id" : 918037452455018497,
    "created_at" : "2017-10-11 08:55:59 +0000",
    "user" : {
      "name" : "React",
      "screen_name" : "reactjs",
      "protected" : false,
      "id_str" : "1566463268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446356636710363136\/OYIaJ1KK_normal.png",
      "id" : 1566463268,
      "verified" : false
    }
  },
  "id" : 927021704148332544,
  "created_at" : "2017-11-05 03:56:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Savkin",
      "screen_name" : "victorsavkin",
      "indices" : [ 3, 16 ],
      "id_str" : "14742078",
      "id" : 14742078
    }, {
      "name" : "Nrwl",
      "screen_name" : "nrwl_io",
      "indices" : [ 112, 120 ],
      "id_str" : "805177910378123265",
      "id" : 805177910378123265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "angular",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927021647240089600",
  "text" : "RT @victorsavkin: A blog post showing how to set up a hybrid app (NgUpgrade or NgUpgrade Lite) in seconds using @nrwl_io Nx #angular\n\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nrwl",
        "screen_name" : "nrwl_io",
        "indices" : [ 94, 102 ],
        "id_str" : "805177910378123265",
        "id" : 805177910378123265
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "angular",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/nXigVOt4Fm",
        "expanded_url" : "https:\/\/blog.nrwl.io\/using-nrwl-nx-to-upgrade-you-angularjs-applications-to-angular-f5b8adf188aa",
        "display_url" : "blog.nrwl.io\/using-nrwl-nx-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926459587473166337",
    "text" : "A blog post showing how to set up a hybrid app (NgUpgrade or NgUpgrade Lite) in seconds using @nrwl_io Nx #angular\n\nhttps:\/\/t.co\/nXigVOt4Fm",
    "id" : 926459587473166337,
    "created_at" : "2017-11-03 14:42:33 +0000",
    "user" : {
      "name" : "Victor Savkin",
      "screen_name" : "victorsavkin",
      "protected" : false,
      "id_str" : "14742078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904049991018151937\/3tsNmuSW_normal.jpg",
      "id" : 14742078,
      "verified" : false
    }
  },
  "id" : 927021647240089600,
  "created_at" : "2017-11-05 03:55:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    }, {
      "name" : "Jacksepticeye",
      "screen_name" : "Jack_Septic_Eye",
      "indices" : [ 16, 32 ],
      "id_str" : "77596200",
      "id" : 77596200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927021368209825792",
  "text" : "RT @jacksfilms: @Jack_Septic_Eye Congrats but like can you name them all from memory",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacksepticeye",
        "screen_name" : "Jack_Septic_Eye",
        "indices" : [ 0, 16 ],
        "id_str" : "77596200",
        "id" : 77596200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926990625563701248",
    "geo" : { },
    "id_str" : "927012478734688256",
    "in_reply_to_user_id" : 77596200,
    "text" : "@Jack_Septic_Eye Congrats but like can you name them all from memory",
    "id" : 927012478734688256,
    "in_reply_to_status_id" : 926990625563701248,
    "created_at" : "2017-11-05 03:19:32 +0000",
    "in_reply_to_screen_name" : "Jack_Septic_Eye",
    "in_reply_to_user_id_str" : "77596200",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927717097051799552\/zUMLDlBG_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 927021368209825792,
  "created_at" : "2017-11-05 03:54:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ANlJPKkqMz",
      "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/236-photography-business-tips\/7557-4-mistakes-photographers-make-when-buying-a-franchise",
      "display_url" : "photographytalk.com\/photography-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927021089364078593",
  "text" : "RT @PhotographyTalk: Let's take a closer look at four mistakes photographers make when buying a franchise.\n\nhttps:\/\/t.co\/ANlJPKkqMz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ANlJPKkqMz",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/236-photography-business-tips\/7557-4-mistakes-photographers-make-when-buying-a-franchise",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926903374838190080",
    "text" : "Let's take a closer look at four mistakes photographers make when buying a franchise.\n\nhttps:\/\/t.co\/ANlJPKkqMz",
    "id" : 926903374838190080,
    "created_at" : "2017-11-04 20:06:00 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 927021089364078593,
  "created_at" : "2017-11-05 03:53:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927021043809742848",
  "text" : "RT @PhotographyTalk: This particular invention was intended to be used to fight crime in New York City in the late 1930s.\nhttps:\/\/t.co\/PEHk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/PEHk2He6wf",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7994-this-revolver-camera-is-one-i-don-t-want-to-say-cheese-for",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926986661023698944",
    "text" : "This particular invention was intended to be used to fight crime in New York City in the late 1930s.\nhttps:\/\/t.co\/PEHk2He6wf",
    "id" : 926986661023698944,
    "created_at" : "2017-11-05 01:36:57 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 927021043809742848,
  "created_at" : "2017-11-05 03:53:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927020928751587333",
  "geo" : { },
  "id_str" : "927020988935569409",
  "in_reply_to_user_id" : 210979938,
  "text" : "Now just waiting, ugh, lol :)",
  "id" : 927020988935569409,
  "in_reply_to_status_id" : 927020928751587333,
  "created_at" : "2017-11-05 03:53:21 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CoolCoil",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927020928751587333",
  "text" : "Just got this cheap 3D printer to do miniature models + a collapsible water tank cause of #CoolCoil\/Water project as well, eBay is awesome!",
  "id" : 927020928751587333,
  "created_at" : "2017-11-05 03:53:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drone Racing League",
      "screen_name" : "DroneRaceLeague",
      "indices" : [ 3, 19 ],
      "id_str" : "3240985277",
      "id" : 3240985277
    }, {
      "name" : "BMW",
      "screen_name" : "BMW",
      "indices" : [ 31, 35 ],
      "id_str" : "1545994664",
      "id" : 1545994664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/edskSX5EAD",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fCjgGYPx8mE",
      "display_url" : "youtube.com\/watch?v=fCjgGY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927013913463590912",
  "text" : "RT @DroneRaceLeague: DRL &amp; @BMW. Drone Racing. \n\nhttps:\/\/t.co\/edskSX5EAD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BMW",
        "screen_name" : "BMW",
        "indices" : [ 10, 14 ],
        "id_str" : "1545994664",
        "id" : 1545994664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/edskSX5EAD",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=fCjgGYPx8mE",
        "display_url" : "youtube.com\/watch?v=fCjgGY\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926872623820263426",
    "text" : "DRL &amp; @BMW. Drone Racing. \n\nhttps:\/\/t.co\/edskSX5EAD",
    "id" : 926872623820263426,
    "created_at" : "2017-11-04 18:03:48 +0000",
    "user" : {
      "name" : "Drone Racing League",
      "screen_name" : "DroneRaceLeague",
      "protected" : false,
      "id_str" : "3240985277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697088587813232641\/BNpS83NR_normal.jpg",
      "id" : 3240985277,
      "verified" : true
    }
  },
  "id" : 927013913463590912,
  "created_at" : "2017-11-05 03:25:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Atkins",
      "screen_name" : "GarrettEAtkins",
      "indices" : [ 3, 18 ],
      "id_str" : "785646081447047168",
      "id" : 785646081447047168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927013825987129344",
  "text" : "RT @GarrettEAtkins: Success is walking from failure to failure with no loss in enthusiasm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924669856833835010",
    "text" : "Success is walking from failure to failure with no loss in enthusiasm",
    "id" : 924669856833835010,
    "created_at" : "2017-10-29 16:10:48 +0000",
    "user" : {
      "name" : "Garrett Atkins",
      "screen_name" : "GarrettEAtkins",
      "protected" : false,
      "id_str" : "785646081447047168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920833792415186945\/0lGZU6oq_normal.jpg",
      "id" : 785646081447047168,
      "verified" : false
    }
  },
  "id" : 927013825987129344,
  "created_at" : "2017-11-05 03:24:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Brown",
      "screen_name" : "ericbrown_stl",
      "indices" : [ 3, 17 ],
      "id_str" : "716859868825530368",
      "id" : 716859868825530368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927013798548033538",
  "text" : "RT @ericbrown_stl: Stop wasting time and take action! There is no better time than right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926140278305710082",
    "text" : "Stop wasting time and take action! There is no better time than right now.",
    "id" : 926140278305710082,
    "created_at" : "2017-11-02 17:33:43 +0000",
    "user" : {
      "name" : "Eric Brown",
      "screen_name" : "ericbrown_stl",
      "protected" : false,
      "id_str" : "716859868825530368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850429934459682816\/ajku2fS3_normal.jpg",
      "id" : 716859868825530368,
      "verified" : false
    }
  },
  "id" : 927013798548033538,
  "created_at" : "2017-11-05 03:24:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startups",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/Wtw2JGuOl1",
      "expanded_url" : "https:\/\/betalist.com\/@gamer456148",
      "display_url" : "betalist.com\/@gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "927010936145276928",
  "text" : "Follow me on BetaList, stuff may be there soon ;) #startups https:\/\/t.co\/Wtw2JGuOl1",
  "id" : 927010936145276928,
  "created_at" : "2017-11-05 03:13:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Killoran",
      "screen_name" : "kimkilloran",
      "indices" : [ 3, 15 ],
      "id_str" : "335431288",
      "id" : 335431288
    }, {
      "name" : "Stratasys",
      "screen_name" : "Stratasys",
      "indices" : [ 113, 123 ],
      "id_str" : "24952305",
      "id" : 24952305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SEMA2017",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ItTEksnwRJ",
      "expanded_url" : "http:\/\/fordauthority.com\/2017\/10\/roushs-custom-2017-sema-build-is-a-modern-take-on-the-boss-429-mustang\/",
      "display_url" : "fordauthority.com\/2017\/10\/roushs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926969821404827649",
  "text" : "RT @kimkilloran: Roush's Custom #SEMA2017 Build Is A Modern Take On The Boss 429 Mustang https:\/\/t.co\/ItTEksnwRJ @Stratasys #RoushPerforman\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stratasys",
        "screen_name" : "Stratasys",
        "indices" : [ 96, 106 ],
        "id_str" : "24952305",
        "id" : 24952305
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SEMA2017",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "RoushPerformance",
        "indices" : [ 107, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/ItTEksnwRJ",
        "expanded_url" : "http:\/\/fordauthority.com\/2017\/10\/roushs-custom-2017-sema-build-is-a-modern-take-on-the-boss-429-mustang\/",
        "display_url" : "fordauthority.com\/2017\/10\/roushs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "923612838177968128",
    "text" : "Roush's Custom #SEMA2017 Build Is A Modern Take On The Boss 429 Mustang https:\/\/t.co\/ItTEksnwRJ @Stratasys #RoushPerformance",
    "id" : 923612838177968128,
    "created_at" : "2017-10-26 18:10:35 +0000",
    "user" : {
      "name" : "Kim Killoran",
      "screen_name" : "kimkilloran",
      "protected" : false,
      "id_str" : "335431288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543142991225835520\/gRYlxe2a_normal.jpeg",
      "id" : 335431288,
      "verified" : false
    }
  },
  "id" : 926969821404827649,
  "created_at" : "2017-11-05 00:30:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Purple Platypus",
      "screen_name" : "PrintPrototypes",
      "indices" : [ 3, 19 ],
      "id_str" : "116081328",
      "id" : 116081328
    }, {
      "name" : "Stratasys",
      "screen_name" : "Stratasys",
      "indices" : [ 65, 75 ],
      "id_str" : "24952305",
      "id" : 24952305
    }, {
      "name" : "Desktop Metal",
      "screen_name" : "DesktopMetal",
      "indices" : [ 82, 95 ],
      "id_str" : "3653221577",
      "id" : 3653221577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926969752995684352",
  "text" : "RT @PrintPrototypes: Join us Nov 15-16 &amp; learn all about how @Stratasys &amp; @DesktopMetal are advancing the way products are manufactured. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stratasys",
        "screen_name" : "Stratasys",
        "indices" : [ 44, 54 ],
        "id_str" : "24952305",
        "id" : 24952305
      }, {
        "name" : "Desktop Metal",
        "screen_name" : "DesktopMetal",
        "indices" : [ 61, 74 ],
        "id_str" : "3653221577",
        "id" : 3653221577
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/VHPqyCWL8d",
        "expanded_url" : "http:\/\/ow.ly\/dhh530gi64A",
        "display_url" : "ow.ly\/dhh530gi64A"
      } ]
    },
    "geo" : { },
    "id_str" : "925833698351763456",
    "text" : "Join us Nov 15-16 &amp; learn all about how @Stratasys &amp; @DesktopMetal are advancing the way products are manufactured. https:\/\/t.co\/VHPqyCWL8d",
    "id" : 925833698351763456,
    "created_at" : "2017-11-01 21:15:29 +0000",
    "user" : {
      "name" : "Purple Platypus",
      "screen_name" : "PrintPrototypes",
      "protected" : false,
      "id_str" : "116081328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911310894209970176\/iBtvrUPb_normal.jpg",
      "id" : 116081328,
      "verified" : false
    }
  },
  "id" : 926969752995684352,
  "created_at" : "2017-11-05 00:29:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D Systems",
      "screen_name" : "3dsystems",
      "indices" : [ 3, 13 ],
      "id_str" : "41580964",
      "id" : 41580964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3dprinted",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/2bNert1NqC",
      "expanded_url" : "http:\/\/bit.ly\/2z2poP5",
      "display_url" : "bit.ly\/2z2poP5"
    } ]
  },
  "geo" : { },
  "id_str" : "926969713405677570",
  "text" : "RT @3dsystems: #3dprinted casting patterns helped Vaupell produce 20 parts in just 2.5 days https:\/\/t.co\/2bNert1NqC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3dprinted",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/2bNert1NqC",
        "expanded_url" : "http:\/\/bit.ly\/2z2poP5",
        "display_url" : "bit.ly\/2z2poP5"
      } ]
    },
    "geo" : { },
    "id_str" : "926060077873811456",
    "text" : "#3dprinted casting patterns helped Vaupell produce 20 parts in just 2.5 days https:\/\/t.co\/2bNert1NqC",
    "id" : 926060077873811456,
    "created_at" : "2017-11-02 12:15:02 +0000",
    "user" : {
      "name" : "3D Systems",
      "screen_name" : "3dsystems",
      "protected" : false,
      "id_str" : "41580964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775394580929720320\/4t72wWwG_normal.jpg",
      "id" : 41580964,
      "verified" : true
    }
  },
  "id" : 926969713405677570,
  "created_at" : "2017-11-05 00:29:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "3D Systems",
      "screen_name" : "3dsystems",
      "indices" : [ 3, 13 ],
      "id_str" : "41580964",
      "id" : 41580964
    }, {
      "name" : "Dubai Airshow",
      "screen_name" : "DubaiAirshow",
      "indices" : [ 38, 51 ],
      "id_str" : "43122860",
      "id" : 43122860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 113, 127 ]
    }, {
      "text" : "DAS17",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/5NNHo4LZzl",
      "expanded_url" : "http:\/\/bit.ly\/2lN1e5S",
      "display_url" : "bit.ly\/2lN1e5S"
    } ]
  },
  "geo" : { },
  "id_str" : "926969686364913665",
  "text" : "RT @3dsystems: 3D Systems to keynote  @DubaiAirshow enabling a new equation in aerospace https:\/\/t.co\/5NNHo4LZzl #manufacturing #DAS17",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dubai Airshow",
        "screen_name" : "DubaiAirshow",
        "indices" : [ 23, 36 ],
        "id_str" : "43122860",
        "id" : 43122860
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 98, 112 ]
      }, {
        "text" : "DAS17",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/5NNHo4LZzl",
        "expanded_url" : "http:\/\/bit.ly\/2lN1e5S",
        "display_url" : "bit.ly\/2lN1e5S"
      } ]
    },
    "geo" : { },
    "id_str" : "926481515441213441",
    "text" : "3D Systems to keynote  @DubaiAirshow enabling a new equation in aerospace https:\/\/t.co\/5NNHo4LZzl #manufacturing #DAS17",
    "id" : 926481515441213441,
    "created_at" : "2017-11-03 16:09:41 +0000",
    "user" : {
      "name" : "3D Systems",
      "screen_name" : "3dsystems",
      "protected" : false,
      "id_str" : "41580964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775394580929720320\/4t72wWwG_normal.jpg",
      "id" : 41580964,
      "verified" : true
    }
  },
  "id" : 926969686364913665,
  "created_at" : "2017-11-05 00:29:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Carlos Bagnell",
      "screen_name" : "SomeGadgetGuy",
      "indices" : [ 3, 17 ],
      "id_str" : "160463859",
      "id" : 160463859
    }, {
      "name" : "Petedavis1",
      "screen_name" : "Petedavis1",
      "indices" : [ 19, 30 ],
      "id_str" : "14778671",
      "id" : 14778671
    }, {
      "name" : "Trisha Hershberger",
      "screen_name" : "thatgrltrish",
      "indices" : [ 31, 44 ],
      "id_str" : "509656977",
      "id" : 509656977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926969474263154688",
  "text" : "RT @SomeGadgetGuy: @Petedavis1 @thatgrltrish MMMmmm egg nog... We have to do something like that for the holidays...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Petedavis1",
        "screen_name" : "Petedavis1",
        "indices" : [ 0, 11 ],
        "id_str" : "14778671",
        "id" : 14778671
      }, {
        "name" : "Trisha Hershberger",
        "screen_name" : "thatgrltrish",
        "indices" : [ 12, 25 ],
        "id_str" : "509656977",
        "id" : 509656977
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "923247953447448576",
    "geo" : { },
    "id_str" : "923248231668105216",
    "in_reply_to_user_id" : 14778671,
    "text" : "@Petedavis1 @thatgrltrish MMMmmm egg nog... We have to do something like that for the holidays...",
    "id" : 923248231668105216,
    "in_reply_to_status_id" : 923247953447448576,
    "created_at" : "2017-10-25 18:01:46 +0000",
    "in_reply_to_screen_name" : "Petedavis1",
    "in_reply_to_user_id_str" : "14778671",
    "user" : {
      "name" : "Juan Carlos Bagnell",
      "screen_name" : "SomeGadgetGuy",
      "protected" : false,
      "id_str" : "160463859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000382110063\/8da6092d74e03c349d0da576ef22f54c_normal.jpeg",
      "id" : 160463859,
      "verified" : true
    }
  },
  "id" : 926969474263154688,
  "created_at" : "2017-11-05 00:28:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Carlos Bagnell",
      "screen_name" : "SomeGadgetGuy",
      "indices" : [ 3, 17 ],
      "id_str" : "160463859",
      "id" : 160463859
    }, {
      "name" : "Trisha Hershberger",
      "screen_name" : "thatgrltrish",
      "indices" : [ 111, 124 ],
      "id_str" : "509656977",
      "id" : 509656977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/aB7bDxqZWZ",
      "expanded_url" : "https:\/\/vid.me\/LzO7i",
      "display_url" : "vid.me\/LzO7i"
    } ]
  },
  "geo" : { },
  "id_str" : "926969457125314561",
  "text" : "RT @SomeGadgetGuy: Vlogging On the set of Newegg Now! Our first episode went live!\nhttps:\/\/t.co\/aB7bDxqZWZ How @thatgrltrish saved my ass d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trisha Hershberger",
        "screen_name" : "thatgrltrish",
        "indices" : [ 92, 105 ],
        "id_str" : "509656977",
        "id" : 509656977
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/aB7bDxqZWZ",
        "expanded_url" : "https:\/\/vid.me\/LzO7i",
        "display_url" : "vid.me\/LzO7i"
      } ]
    },
    "geo" : { },
    "id_str" : "923246787107766272",
    "text" : "Vlogging On the set of Newegg Now! Our first episode went live!\nhttps:\/\/t.co\/aB7bDxqZWZ How @thatgrltrish saved my ass during a live demo...",
    "id" : 923246787107766272,
    "created_at" : "2017-10-25 17:56:01 +0000",
    "user" : {
      "name" : "Juan Carlos Bagnell",
      "screen_name" : "SomeGadgetGuy",
      "protected" : false,
      "id_str" : "160463859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000382110063\/8da6092d74e03c349d0da576ef22f54c_normal.jpeg",
      "id" : 160463859,
      "verified" : true
    }
  },
  "id" : 926969457125314561,
  "created_at" : "2017-11-05 00:28:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XFX (Official)",
      "screen_name" : "XFX_PlayHard",
      "indices" : [ 3, 16 ],
      "id_str" : "1453127558",
      "id" : 1453127558
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 101, 109 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/OKq8hmSXsH",
      "expanded_url" : "http:\/\/youtu.be\/PRRyKBAxLYc?a",
      "display_url" : "youtu.be\/PRRyKBAxLYc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "926968872632188928",
  "text" : "RT @XFX_PlayHard: Destiny 2 Campaign PC - XFX RX 580 Live Gameplay - 4k: https:\/\/t.co\/OKq8hmSXsH via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 83, 91 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/OKq8hmSXsH",
        "expanded_url" : "http:\/\/youtu.be\/PRRyKBAxLYc?a",
        "display_url" : "youtu.be\/PRRyKBAxLYc?a"
      } ]
    },
    "geo" : { },
    "id_str" : "924030801548922882",
    "text" : "Destiny 2 Campaign PC - XFX RX 580 Live Gameplay - 4k: https:\/\/t.co\/OKq8hmSXsH via @YouTube",
    "id" : 924030801548922882,
    "created_at" : "2017-10-27 21:51:25 +0000",
    "user" : {
      "name" : "XFX (Official)",
      "screen_name" : "XFX_PlayHard",
      "protected" : false,
      "id_str" : "1453127558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783002992916127744\/zVgClWBQ_normal.jpg",
      "id" : 1453127558,
      "verified" : false
    }
  },
  "id" : 926968872632188928,
  "created_at" : "2017-11-05 00:26:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "NVIDIA",
      "screen_name" : "nvidia",
      "indices" : [ 20, 27 ],
      "id_str" : "61559439",
      "id" : 61559439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/jfOgyhb6na",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/nvidia-teases-titan-x-collectors-edition,35837.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/nvidia-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926968544952274945",
  "text" : "RT @tomshardware: \u25B8 @Nvidia Teases New Titan X Collector's Edition https:\/\/t.co\/jfOgyhb6na",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NVIDIA",
        "screen_name" : "nvidia",
        "indices" : [ 2, 9 ],
        "id_str" : "61559439",
        "id" : 61559439
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/jfOgyhb6na",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/nvidia-teases-titan-x-collectors-edition,35837.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/nvidia-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926478496569835520",
    "text" : "\u25B8 @Nvidia Teases New Titan X Collector's Edition https:\/\/t.co\/jfOgyhb6na",
    "id" : 926478496569835520,
    "created_at" : "2017-11-03 15:57:41 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926968544952274945,
  "created_at" : "2017-11-05 00:24:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/KOTrNeO6X1",
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/922691827031068672",
      "display_url" : "twitter.com\/elonmusk\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926968437783580672",
  "text" : "Some AI researcher, writers and developers are insane. The one Elon Musk is referring to is! https:\/\/t.co\/KOTrNeO6X1",
  "id" : 926968437783580672,
  "created_at" : "2017-11-05 00:24:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "XFX (Official)",
      "screen_name" : "XFX_PlayHard",
      "indices" : [ 20, 33 ],
      "id_str" : "1453127558",
      "id" : 1453127558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vega",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/fY7X6YH4zE",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/xfx-custom-vega-graphics-card,35843.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/xfx-custo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926967906814103552",
  "text" : "RT @tomshardware: \u25B8 @XFX_PlayHard Teases Custom #Vega Graphics Card https:\/\/t.co\/fY7X6YH4zE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "XFX (Official)",
        "screen_name" : "XFX_PlayHard",
        "indices" : [ 2, 15 ],
        "id_str" : "1453127558",
        "id" : 1453127558
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vega",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/fY7X6YH4zE",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/xfx-custom-vega-graphics-card,35843.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/xfx-custo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926554354873593857",
    "text" : "\u25B8 @XFX_PlayHard Teases Custom #Vega Graphics Card https:\/\/t.co\/fY7X6YH4zE",
    "id" : 926554354873593857,
    "created_at" : "2017-11-03 20:59:07 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926967906814103552,
  "created_at" : "2017-11-05 00:22:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/99CduQ24qb",
      "expanded_url" : "http:\/\/depot.ly\/l7fH30glopX",
      "display_url" : "depot.ly\/l7fH30glopX"
    } ]
  },
  "geo" : { },
  "id_str" : "926967764123824128",
  "text" : "RT @DesignerDepot: Figma Pages https:\/\/t.co\/99CduQ24qb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/99CduQ24qb",
        "expanded_url" : "http:\/\/depot.ly\/l7fH30glopX",
        "display_url" : "depot.ly\/l7fH30glopX"
      } ]
    },
    "geo" : { },
    "id_str" : "926725732549742592",
    "text" : "Figma Pages https:\/\/t.co\/99CduQ24qb",
    "id" : 926725732549742592,
    "created_at" : "2017-11-04 08:20:07 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926967764123824128,
  "created_at" : "2017-11-05 00:21:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/nPBGHhIyt3",
      "expanded_url" : "http:\/\/depot.ly\/1s5c30glmFW",
      "display_url" : "depot.ly\/1s5c30glmFW"
    } ]
  },
  "geo" : { },
  "id_str" : "926967620527689728",
  "text" : "RT @DesignerDepot: 5 Ways to Design With Accelerated Mobile Pages https:\/\/t.co\/nPBGHhIyt3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/nPBGHhIyt3",
        "expanded_url" : "http:\/\/depot.ly\/1s5c30glmFW",
        "display_url" : "depot.ly\/1s5c30glmFW"
      } ]
    },
    "geo" : { },
    "id_str" : "926945929340637184",
    "text" : "5 Ways to Design With Accelerated Mobile Pages https:\/\/t.co\/nPBGHhIyt3",
    "id" : 926945929340637184,
    "created_at" : "2017-11-04 22:55:06 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926967620527689728,
  "created_at" : "2017-11-05 00:21:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharm Excursions",
      "screen_name" : "sharmclub",
      "indices" : [ 3, 13 ],
      "id_str" : "50932560",
      "id" : 50932560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926967334132166656",
  "text" : "RT @sharmclub: Egypt\u2019s Great Pyramid of Giza\u2014one of the wonders of the ancient world, and a dazzling feat of architectural... https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/FtBaR10LkJ",
        "expanded_url" : "http:\/\/fb.me\/7Ci1lBxcI",
        "display_url" : "fb.me\/7Ci1lBxcI"
      } ]
    },
    "geo" : { },
    "id_str" : "926862556794376192",
    "text" : "Egypt\u2019s Great Pyramid of Giza\u2014one of the wonders of the ancient world, and a dazzling feat of architectural... https:\/\/t.co\/FtBaR10LkJ",
    "id" : 926862556794376192,
    "created_at" : "2017-11-04 17:23:48 +0000",
    "user" : {
      "name" : "Sharm Excursions",
      "screen_name" : "sharmclub",
      "protected" : false,
      "id_str" : "50932560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1235437010\/correct_logo_normal.jpg",
      "id" : 50932560,
      "verified" : false
    }
  },
  "id" : 926967334132166656,
  "created_at" : "2017-11-05 00:20:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Era",
      "screen_name" : "digitalera_io",
      "indices" : [ 3, 17 ],
      "id_str" : "4849125291",
      "id" : 4849125291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/2LzTQ1xnzY",
      "expanded_url" : "https:\/\/buff.ly\/2zX1XVl",
      "display_url" : "buff.ly\/2zX1XVl"
    } ]
  },
  "geo" : { },
  "id_str" : "926966904627089410",
  "text" : "RT @digitalera_io: If you\u2019ve found a way to turn one dollar into two dollars, keep doing it. But don\u2019t stop there https:\/\/t.co\/2LzTQ1xnzY #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ppc",
        "indices" : [ 119, 123 ]
      }, {
        "text" : "marketing",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/2LzTQ1xnzY",
        "expanded_url" : "https:\/\/buff.ly\/2zX1XVl",
        "display_url" : "buff.ly\/2zX1XVl"
      } ]
    },
    "geo" : { },
    "id_str" : "926964529526910977",
    "text" : "If you\u2019ve found a way to turn one dollar into two dollars, keep doing it. But don\u2019t stop there https:\/\/t.co\/2LzTQ1xnzY #ppc #marketing",
    "id" : 926964529526910977,
    "created_at" : "2017-11-05 00:09:00 +0000",
    "user" : {
      "name" : "Digital Era",
      "screen_name" : "digitalera_io",
      "protected" : false,
      "id_str" : "4849125291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691929846625255425\/hzZAnpnD_normal.png",
      "id" : 4849125291,
      "verified" : false
    }
  },
  "id" : 926966904627089410,
  "created_at" : "2017-11-05 00:18:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina",
      "screen_name" : "UteFanChristina",
      "indices" : [ 3, 19 ],
      "id_str" : "314426294",
      "id" : 314426294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getaroom",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926966650452180992",
  "text" : "RT @UteFanChristina: This guy a few rows in front of me is having some really nice alone time with his cowboy corn dog. #getaroom!! \uD83D\uDE2E\uD83C\uDF2D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getaroom",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926613396375482368",
    "text" : "This guy a few rows in front of me is having some really nice alone time with his cowboy corn dog. #getaroom!! \uD83D\uDE2E\uD83C\uDF2D",
    "id" : 926613396375482368,
    "created_at" : "2017-11-04 00:53:43 +0000",
    "user" : {
      "name" : "Christina",
      "screen_name" : "UteFanChristina",
      "protected" : false,
      "id_str" : "314426294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412097338019024896\/aWVCWchc_normal.jpeg",
      "id" : 314426294,
      "verified" : false
    }
  },
  "id" : 926966650452180992,
  "created_at" : "2017-11-05 00:17:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Swaim",
      "screen_name" : "zachthomasprime",
      "indices" : [ 3, 19 ],
      "id_str" : "325929087",
      "id" : 325929087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926966375633039361",
  "text" : "RT @zachthomasprime: Why would someone want to attack Rand Paul? He doesn\u2019t vote for either party\u2019s agenda!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926957252279402496",
    "text" : "Why would someone want to attack Rand Paul? He doesn\u2019t vote for either party\u2019s agenda!",
    "id" : 926957252279402496,
    "created_at" : "2017-11-04 23:40:05 +0000",
    "user" : {
      "name" : "Zach Swaim",
      "screen_name" : "zachthomasprime",
      "protected" : false,
      "id_str" : "325929087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888129896005771264\/dyuDeQR0_normal.jpg",
      "id" : 325929087,
      "verified" : false
    }
  },
  "id" : 926966375633039361,
  "created_at" : "2017-11-05 00:16:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/5WnyLMjKp9",
      "expanded_url" : "http:\/\/engt.co\/2zeyys0",
      "display_url" : "engt.co\/2zeyys0"
    } ]
  },
  "geo" : { },
  "id_str" : "926966336135290880",
  "text" : "RT @engadget: Internet giants now support bill to curb online sex trafficking https:\/\/t.co\/5WnyLMjKp9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/5WnyLMjKp9",
        "expanded_url" : "http:\/\/engt.co\/2zeyys0",
        "display_url" : "engt.co\/2zeyys0"
      } ]
    },
    "geo" : { },
    "id_str" : "926952124059148293",
    "text" : "Internet giants now support bill to curb online sex trafficking https:\/\/t.co\/5WnyLMjKp9",
    "id" : 926952124059148293,
    "created_at" : "2017-11-04 23:19:42 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926966336135290880,
  "created_at" : "2017-11-05 00:16:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Morse",
      "screen_name" : "TheBrandonMorse",
      "indices" : [ 3, 19 ],
      "id_str" : "31136822",
      "id" : 31136822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926966288618016768",
  "text" : "RT @TheBrandonMorse: Rand Paul has been assaulted at his home. Welcome to politics 2017.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926900413613342723",
    "text" : "Rand Paul has been assaulted at his home. Welcome to politics 2017.",
    "id" : 926900413613342723,
    "created_at" : "2017-11-04 19:54:14 +0000",
    "user" : {
      "name" : "Brandon Morse",
      "screen_name" : "TheBrandonMorse",
      "protected" : false,
      "id_str" : "31136822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876591494919987200\/5SiR0_yp_normal.jpg",
      "id" : 31136822,
      "verified" : true
    }
  },
  "id" : 926966288618016768,
  "created_at" : "2017-11-05 00:16:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926966179855585281",
  "text" : "RT @jacksfilms: tHE cool thing about COFFEE is that it never RUNS OUT HAHA you can ALWAYS MAKE MORE WEEEE more CCOOFFFFEE IT'S FOREVER",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926905978355818496",
    "text" : "tHE cool thing about COFFEE is that it never RUNS OUT HAHA you can ALWAYS MAKE MORE WEEEE more CCOOFFFFEE IT'S FOREVER",
    "id" : 926905978355818496,
    "created_at" : "2017-11-04 20:16:20 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927717097051799552\/zUMLDlBG_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 926966179855585281,
  "created_at" : "2017-11-05 00:15:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/AsGUlPMnlK",
      "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/04\/italian-town-positano-now-1100-tax-profit-photos\/",
      "display_url" : "petapixel.com\/2017\/11\/04\/ita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926966122942955521",
  "text" : "RT @JayHoque: The Italian Town of Positano Now Has a $1,100+ Tax on For-Profit Photos: https:\/\/t.co\/AsGUlPMnlK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/AsGUlPMnlK",
        "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/04\/italian-town-positano-now-1100-tax-profit-photos\/",
        "display_url" : "petapixel.com\/2017\/11\/04\/ita\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926864520252940289",
    "text" : "The Italian Town of Positano Now Has a $1,100+ Tax on For-Profit Photos: https:\/\/t.co\/AsGUlPMnlK",
    "id" : 926864520252940289,
    "created_at" : "2017-11-04 17:31:36 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926966122942955521,
  "created_at" : "2017-11-05 00:15:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happiness",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926966100306419713",
  "text" : "RT @JayHoque: Face it to find it! \"There's much to be said for challenging fate instead of ducking behind it.\" Diana Trilling #happiness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "happiness",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926962276556345344",
    "text" : "Face it to find it! \"There's much to be said for challenging fate instead of ducking behind it.\" Diana Trilling #happiness",
    "id" : 926962276556345344,
    "created_at" : "2017-11-05 00:00:03 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926966100306419713,
  "created_at" : "2017-11-05 00:15:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926965938133635072",
  "text" : "Ugh long day, so much to deal with. Thank God for all the challenges and obstacles he put in my life so I can grow to a better man.",
  "id" : 926965938133635072,
  "created_at" : "2017-11-05 00:14:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926951676694749185",
  "text" : "RT @Matthiasiam: YouTube doesn\u2019t know how to handle the one letter named channel. Any other channel name suggestions for \u201Cm.\u201D? Go!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926911533866631168",
    "text" : "YouTube doesn\u2019t know how to handle the one letter named channel. Any other channel name suggestions for \u201Cm.\u201D? Go!",
    "id" : 926911533866631168,
    "created_at" : "2017-11-04 20:38:25 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 926951676694749185,
  "created_at" : "2017-11-04 23:17:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "electricity",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/7guwSwMtnV",
      "expanded_url" : "http:\/\/phy.so\/428991671",
      "display_url" : "phy.so\/428991671"
    } ]
  },
  "geo" : { },
  "id_str" : "926906182148804611",
  "text" : "RT @physorg_com: Solar greenhouses generate #electricity and grow crops at the same time https:\/\/t.co\/7guwSwMtnV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "electricity",
        "indices" : [ 27, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/7guwSwMtnV",
        "expanded_url" : "http:\/\/phy.so\/428991671",
        "display_url" : "phy.so\/428991671"
      } ]
    },
    "geo" : { },
    "id_str" : "926741231627096064",
    "text" : "Solar greenhouses generate #electricity and grow crops at the same time https:\/\/t.co\/7guwSwMtnV",
    "id" : 926741231627096064,
    "created_at" : "2017-11-04 09:21:42 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 926906182148804611,
  "created_at" : "2017-11-04 20:17:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 71, 87 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926906090230550528",
  "text" : "RT @TheSharkDaymond: \u201CAlways choose attitude over experience. Always.\u201D @BarbaraCorcoran #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barbara Corcoran",
        "screen_name" : "BarbaraCorcoran",
        "indices" : [ 50, 66 ],
        "id_str" : "36728196",
        "id" : 36728196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926521613616664576",
    "text" : "\u201CAlways choose attitude over experience. Always.\u201D @BarbaraCorcoran #SharkTank",
    "id" : 926521613616664576,
    "created_at" : "2017-11-03 18:49:01 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817056911518482433\/otB2Lkng_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 926906090230550528,
  "created_at" : "2017-11-04 20:16:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926906085637844997",
  "text" : "RT @BarbaraCorcoran: The #1 mistake entrepreneurs make is saying YES! The problem with saying yes is that you're saying yes to someone else\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926838987855159296",
    "text" : "The #1 mistake entrepreneurs make is saying YES! The problem with saying yes is that you're saying yes to someone else's agenda - NOT yours!",
    "id" : 926838987855159296,
    "created_at" : "2017-11-04 15:50:09 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926906085637844997,
  "created_at" : "2017-11-04 20:16:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Mueller",
      "screen_name" : "cominvestmentch",
      "indices" : [ 3, 19 ],
      "id_str" : "2777979585",
      "id" : 2777979585
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 21, 28 ],
      "id_str" : "91478624",
      "id" : 91478624
    }, {
      "name" : "Gaby Rojas",
      "screen_name" : "gabriella_rz",
      "indices" : [ 29, 42 ],
      "id_str" : "49807031",
      "id" : 49807031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926905682544259073",
  "text" : "RT @cominvestmentch: @Forbes @gabriella_rz he wants to buy Bitcoin instead;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 0, 7 ],
        "id_str" : "91478624",
        "id" : 91478624
      }, {
        "name" : "Gaby Rojas",
        "screen_name" : "gabriella_rz",
        "indices" : [ 8, 21 ],
        "id_str" : "49807031",
        "id" : 49807031
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926810386262777857",
    "geo" : { },
    "id_str" : "926825461367402497",
    "in_reply_to_user_id" : 91478624,
    "text" : "@Forbes @gabriella_rz he wants to buy Bitcoin instead;-)",
    "id" : 926825461367402497,
    "in_reply_to_status_id" : 926810386262777857,
    "created_at" : "2017-11-04 14:56:24 +0000",
    "in_reply_to_screen_name" : "Forbes",
    "in_reply_to_user_id_str" : "91478624",
    "user" : {
      "name" : "Christian Mueller",
      "screen_name" : "cominvestmentch",
      "protected" : false,
      "id_str" : "2777979585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841797888460099592\/OWHKlFFB_normal.jpg",
      "id" : 2777979585,
      "verified" : false
    }
  },
  "id" : 926905682544259073,
  "created_at" : "2017-11-04 20:15:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/iDtM4N3vyv",
      "expanded_url" : "http:\/\/ift.tt\/2hCEj92",
      "display_url" : "ift.tt\/2hCEj92"
    } ]
  },
  "geo" : { },
  "id_str" : "926905453589786624",
  "text" : "RT @dronepilots: First Drone Institute inspires students to think differently | DronePilots - https:\/\/t.co\/iDtM4N3vyv #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iDtM4N3vyv",
        "expanded_url" : "http:\/\/ift.tt\/2hCEj92",
        "display_url" : "ift.tt\/2hCEj92"
      } ]
    },
    "geo" : { },
    "id_str" : "926874262291603457",
    "text" : "First Drone Institute inspires students to think differently | DronePilots - https:\/\/t.co\/iDtM4N3vyv #drones",
    "id" : 926874262291603457,
    "created_at" : "2017-11-04 18:10:19 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926905453589786624,
  "created_at" : "2017-11-04 20:14:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/yK9Jlsz1MQ",
      "expanded_url" : "http:\/\/ift.tt\/2lJNysr",
      "display_url" : "ift.tt\/2lJNysr"
    } ]
  },
  "geo" : { },
  "id_str" : "926867928137584640",
  "text" : "RT @dronepilots: Drones become crime-fighting tool, but perfection is elusive | DronePilots - https:\/\/t.co\/yK9Jlsz1MQ #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/yK9Jlsz1MQ",
        "expanded_url" : "http:\/\/ift.tt\/2lJNysr",
        "display_url" : "ift.tt\/2lJNysr"
      } ]
    },
    "geo" : { },
    "id_str" : "926836586268028931",
    "text" : "Drones become crime-fighting tool, but perfection is elusive | DronePilots - https:\/\/t.co\/yK9Jlsz1MQ #drones",
    "id" : 926836586268028931,
    "created_at" : "2017-11-04 15:40:36 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926867928137584640,
  "created_at" : "2017-11-04 17:45:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 3, 10 ],
      "id_str" : "16228398",
      "id" : 16228398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/dMfsxpnv0z",
      "expanded_url" : "https:\/\/www.knockoutcollege.com\/single-post\/2017\/05\/04\/4-Ways-to-Save-Money-on-College",
      "display_url" : "knockoutcollege.com\/single-post\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926867716903972864",
  "text" : "RT @mcuban: 4 Ways to Save Money on College\n https:\/\/t.co\/dMfsxpnv0z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/dMfsxpnv0z",
        "expanded_url" : "https:\/\/www.knockoutcollege.com\/single-post\/2017\/05\/04\/4-Ways-to-Save-Money-on-College",
        "display_url" : "knockoutcollege.com\/single-post\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926851770403508225",
    "text" : "4 Ways to Save Money on College\n https:\/\/t.co\/dMfsxpnv0z",
    "id" : 926851770403508225,
    "created_at" : "2017-11-04 16:40:56 +0000",
    "user" : {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "protected" : false,
      "id_str" : "16228398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1422637130\/mccigartrophy_normal.jpg",
      "id" : 16228398,
      "verified" : true
    }
  },
  "id" : 926867716903972864,
  "created_at" : "2017-11-04 17:44:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farnell element14",
      "screen_name" : "FarnellNews",
      "indices" : [ 3, 15 ],
      "id_str" : "43127170",
      "id" : 43127170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Halloween",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926867374950768640",
  "text" : "RT @FarnellNews: One of our Community members built #Halloween costumes for his grandchildren: LadyBug Girl and Rocket Boy https:\/\/t.co\/08g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Halloween",
        "indices" : [ 35, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/08gwF7Ook4",
        "expanded_url" : "http:\/\/bit.ly\/2z689vX",
        "display_url" : "bit.ly\/2z689vX"
      } ]
    },
    "geo" : { },
    "id_str" : "926788717448085505",
    "text" : "One of our Community members built #Halloween costumes for his grandchildren: LadyBug Girl and Rocket Boy https:\/\/t.co\/08gwF7Ook4",
    "id" : 926788717448085505,
    "created_at" : "2017-11-04 12:30:23 +0000",
    "user" : {
      "name" : "Farnell element14",
      "screen_name" : "FarnellNews",
      "protected" : false,
      "id_str" : "43127170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1845611414\/twitterlogo_normal.jpg",
      "id" : 43127170,
      "verified" : false
    }
  },
  "id" : 926867374950768640,
  "created_at" : "2017-11-04 17:42:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medical Xpress",
      "screen_name" : "medical_xpress",
      "indices" : [ 3, 18 ],
      "id_str" : "287568380",
      "id" : 287568380
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 116, 123 ],
      "id_str" : "487833518",
      "id" : 487833518
    }, {
      "name" : "eLife - the journal",
      "screen_name" : "eLife",
      "indices" : [ 124, 130 ],
      "id_str" : "380816062",
      "id" : 380816062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Electronmicroscopy",
      "indices" : [ 20, 39 ]
    }, {
      "text" : "brain",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Y2BjsVHGhY",
      "expanded_url" : "http:\/\/medx.cc\/428922938",
      "display_url" : "medx.cc\/428922938"
    } ]
  },
  "geo" : { },
  "id_str" : "926867282743177217",
  "text" : "RT @medical_xpress: #Electronmicroscopy uncovers unexpected connections in fruit fly #brain https:\/\/t.co\/Y2BjsVHGhY @nature @elife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nature",
        "screen_name" : "nature",
        "indices" : [ 96, 103 ],
        "id_str" : "487833518",
        "id" : 487833518
      }, {
        "name" : "eLife - the journal",
        "screen_name" : "eLife",
        "indices" : [ 104, 110 ],
        "id_str" : "380816062",
        "id" : 380816062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Electronmicroscopy",
        "indices" : [ 0, 19 ]
      }, {
        "text" : "brain",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/Y2BjsVHGhY",
        "expanded_url" : "http:\/\/medx.cc\/428922938",
        "display_url" : "medx.cc\/428922938"
      } ]
    },
    "geo" : { },
    "id_str" : "926452872350519301",
    "text" : "#Electronmicroscopy uncovers unexpected connections in fruit fly #brain https:\/\/t.co\/Y2BjsVHGhY @nature @elife",
    "id" : 926452872350519301,
    "created_at" : "2017-11-03 14:15:52 +0000",
    "user" : {
      "name" : "Medical Xpress",
      "screen_name" : "medical_xpress",
      "protected" : false,
      "id_str" : "287568380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324543229\/logo_normal.jpg",
      "id" : 287568380,
      "verified" : false
    }
  },
  "id" : 926867282743177217,
  "created_at" : "2017-11-04 17:42:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/IsVjPMayNE",
      "expanded_url" : "https:\/\/medium.com\/p\/14-turning-points-in-the-history-of-photography-ce6814d326c",
      "display_url" : "medium.com\/p\/14-turning-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926867108478308352",
  "text" : "RT @PhotographyTalk: I just published \u201C14 Turning Points in the History of Photography\u201D https:\/\/t.co\/IsVjPMayNE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/IsVjPMayNE",
        "expanded_url" : "https:\/\/medium.com\/p\/14-turning-points-in-the-history-of-photography-ce6814d326c",
        "display_url" : "medium.com\/p\/14-turning-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926219607333048322",
    "text" : "I just published \u201C14 Turning Points in the History of Photography\u201D https:\/\/t.co\/IsVjPMayNE",
    "id" : 926219607333048322,
    "created_at" : "2017-11-02 22:48:57 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 926867108478308352,
  "created_at" : "2017-11-04 17:41:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926867069613887489",
  "text" : "RT @PhotographyTalk: The a7R II is a heck of a camera, and one that has won many accolades, including an incredibly high rating\n\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/HvheXCHaeP",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/7992-the-a7r-iii-is-sony-s-new-weapon-in-the-full-frame-camera-wars",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926443519153246215",
    "text" : "The a7R II is a heck of a camera, and one that has won many accolades, including an incredibly high rating\n\nhttps:\/\/t.co\/HvheXCHaeP",
    "id" : 926443519153246215,
    "created_at" : "2017-11-03 13:38:42 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 926867069613887489,
  "created_at" : "2017-11-04 17:41:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926866931981979648\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CELxs4Drio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNzkjKGUEAE2pQA.jpg",
      "id_str" : "926866915988869121",
      "id" : 926866915988869121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNzkjKGUEAE2pQA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/CELxs4Drio"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926866931981979648\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CELxs4Drio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNzkjKGV4AAbaV8.jpg",
      "id_str" : "926866915988987904",
      "id" : 926866915988987904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNzkjKGV4AAbaV8.jpg",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CELxs4Drio"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926866931981979648\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/CELxs4Drio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNzkjKHV4AAJgxn.jpg",
      "id_str" : "926866915993182208",
      "id" : 926866915993182208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNzkjKHV4AAJgxn.jpg",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 930
      } ],
      "display_url" : "pic.twitter.com\/CELxs4Drio"
    } ],
    "hashtags" : [ {
      "text" : "blockchain",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "mining",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "cryptocurrency",
      "indices" : [ 82, 97 ]
    }, {
      "text" : "CrowdCoin",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "Dev",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926866931981979648",
  "text" : "Much progress though not fully ready syncing or frontend wise #blockchain #mining #cryptocurrency #CrowdCoin #Dev https:\/\/t.co\/CELxs4Drio",
  "id" : 926866931981979648,
  "created_at" : "2017-11-04 17:41:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/IYmR7MxKkj",
      "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/04\/rezivot-instant-film-processor-shoot-instax-film-camera\/",
      "display_url" : "petapixel.com\/2017\/11\/04\/rez\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926864864148148224",
  "text" : "RT @JayHoque: Rezivot Instant Film Processor: Shoot Instax with Your Film Camera: https:\/\/t.co\/IYmR7MxKkj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/IYmR7MxKkj",
        "expanded_url" : "https:\/\/petapixel.com\/2017\/11\/04\/rezivot-instant-film-processor-shoot-instax-film-camera\/",
        "display_url" : "petapixel.com\/2017\/11\/04\/rez\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926853143786291200",
    "text" : "Rezivot Instant Film Processor: Shoot Instax with Your Film Camera: https:\/\/t.co\/IYmR7MxKkj",
    "id" : 926853143786291200,
    "created_at" : "2017-11-04 16:46:24 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926864864148148224,
  "created_at" : "2017-11-04 17:32:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "indices" : [ 3, 16 ],
      "id_str" : "61417559",
      "id" : 61417559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BQynfsB5rG",
      "expanded_url" : "http:\/\/moneyandstate.com\/the-true-cost-of-bitcoin-transactions\/",
      "display_url" : "moneyandstate.com\/the-true-cost-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926864742739841024",
  "text" : "RT @ErikVoorhees: I wrote this back in Feb when avg fees were \"only\" $0.83. https:\/\/t.co\/BQynfsB5rG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/BQynfsB5rG",
        "expanded_url" : "http:\/\/moneyandstate.com\/the-true-cost-of-bitcoin-transactions\/",
        "display_url" : "moneyandstate.com\/the-true-cost-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926798213524348928",
    "text" : "I wrote this back in Feb when avg fees were \"only\" $0.83. https:\/\/t.co\/BQynfsB5rG",
    "id" : 926798213524348928,
    "created_at" : "2017-11-04 13:08:07 +0000",
    "user" : {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "protected" : false,
      "id_str" : "61417559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/339147710\/atlas_02-1_normal.jpg",
      "id" : 61417559,
      "verified" : true
    }
  },
  "id" : 926864742739841024,
  "created_at" : "2017-11-04 17:32:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 3, 10 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/wHvWxsknob",
      "expanded_url" : "https:\/\/www.forbes.com\/sites\/victorlipman\/2017\/06\/07\/if-your-boss-shows-these-4-signs-head-for-the-hills\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
      "display_url" : "forbes.com\/sites\/victorli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926864733482962945",
  "text" : "RT @Forbes: If Your Boss Shows These 4 Signs, Head For The Hills https:\/\/t.co\/wHvWxsknob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.forbes.com\" rel=\"nofollow\"\u003EMalorie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/wHvWxsknob",
        "expanded_url" : "https:\/\/www.forbes.com\/sites\/victorlipman\/2017\/06\/07\/if-your-boss-shows-these-4-signs-head-for-the-hills\/?utm_source=TWITTER&utm_medium=social&utm_term=Malorie\/#6d616c6f7269",
        "display_url" : "forbes.com\/sites\/victorli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926864116249133056",
    "text" : "If Your Boss Shows These 4 Signs, Head For The Hills https:\/\/t.co\/wHvWxsknob",
    "id" : 926864116249133056,
    "created_at" : "2017-11-04 17:30:00 +0000",
    "user" : {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "protected" : false,
      "id_str" : "91478624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882603270484766720\/YFx4Lsh4_normal.jpg",
      "id" : 91478624,
      "verified" : true
    }
  },
  "id" : 926864733482962945,
  "created_at" : "2017-11-04 17:32:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926863662786244608",
  "geo" : { },
  "id_str" : "926864684292198400",
  "in_reply_to_user_id" : 210979938,
  "text" : "That trophy and moon animation was insane, then they fight for peach and awkward, lol",
  "id" : 926864684292198400,
  "in_reply_to_status_id" : 926863662786244608,
  "created_at" : "2017-11-04 17:32:15 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/7evWyVA9Qd",
      "expanded_url" : "https:\/\/fstoppers.com\/education\/introduction-creative-portrait-techniques-202567?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/education\/intr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926863708017627137",
  "text" : "RT @JayHoque: An Introduction to Creative Portrait Techniques: https:\/\/t.co\/7evWyVA9Qd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/7evWyVA9Qd",
        "expanded_url" : "https:\/\/fstoppers.com\/education\/introduction-creative-portrait-techniques-202567?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/education\/intr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926846938242338816",
    "text" : "An Introduction to Creative Portrait Techniques: https:\/\/t.co\/7evWyVA9Qd",
    "id" : 926846938242338816,
    "created_at" : "2017-11-04 16:21:44 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926863708017627137,
  "created_at" : "2017-11-04 17:28:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926863686052077571",
  "text" : "RT @lorenridinger: \"It is easier to act yourself into a new way of feeling rather than feel your way into a new way of acting.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926841785917280256",
    "text" : "\"It is easier to act yourself into a new way of feeling rather than feel your way into a new way of acting.\u201D",
    "id" : 926841785917280256,
    "created_at" : "2017-11-04 16:01:16 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 926863686052077571,
  "created_at" : "2017-11-04 17:28:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926863662786244608",
  "text" : "Beat Mario Odyssey with my friend, an alternative punk rock band at a Mario game, lol",
  "id" : 926863662786244608,
  "created_at" : "2017-11-04 17:28:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 97, 105 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/UkPSgSRjHW",
      "expanded_url" : "http:\/\/youtu.be\/u08TcI6bCjw?a",
      "display_url" : "youtu.be\/u08TcI6bCjw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "926830545065017345",
  "text" : "RT @colin_furze: Ultimate Pooch Palace - Furze World Wonders (Ep 7): https:\/\/t.co\/UkPSgSRjHW via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 80, 88 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/UkPSgSRjHW",
        "expanded_url" : "http:\/\/youtu.be\/u08TcI6bCjw?a",
        "display_url" : "youtu.be\/u08TcI6bCjw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "925740500241575937",
    "text" : "Ultimate Pooch Palace - Furze World Wonders (Ep 7): https:\/\/t.co\/UkPSgSRjHW via @YouTube",
    "id" : 925740500241575937,
    "created_at" : "2017-11-01 15:05:09 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 926830545065017345,
  "created_at" : "2017-11-04 15:16:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/2tZ87bVmq0",
      "expanded_url" : "http:\/\/www.businessinsider.com\/barbara-corcoran-real-estate-mogul-investor-and-shark-tank-star-2017-11",
      "display_url" : "businessinsider.com\/barbara-corcor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926830466728153088",
  "text" : "RT @BarbaraCorcoran: Learn all about my rag to riches story here: https:\/\/t.co\/2tZ87bVmq0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/2tZ87bVmq0",
        "expanded_url" : "http:\/\/www.businessinsider.com\/barbara-corcoran-real-estate-mogul-investor-and-shark-tank-star-2017-11",
        "display_url" : "businessinsider.com\/barbara-corcor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926796566324584449",
    "text" : "Learn all about my rag to riches story here: https:\/\/t.co\/2tZ87bVmq0",
    "id" : 926796566324584449,
    "created_at" : "2017-11-04 13:01:35 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926830466728153088,
  "created_at" : "2017-11-04 15:16:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926830407290470403",
  "text" : "RT @BarbaraCorcoran: I worked for 22 people before I started my own business. I loved every job, but I sure hated having a boss to report t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926798729931210752",
    "text" : "I worked for 22 people before I started my own business. I loved every job, but I sure hated having a boss to report to.",
    "id" : 926798729931210752,
    "created_at" : "2017-11-04 13:10:10 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926830407290470403,
  "created_at" : "2017-11-04 15:16:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/LSuLK5lDJi",
      "expanded_url" : "https:\/\/digital-photography-school.com\/create-beautiful-online-gallery-lightroom-classic-cc-adobe-portfolio-15-minutes\/",
      "display_url" : "digital-photography-school.com\/create-beautif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926830359257509889",
  "text" : "RT @JayHoque: How to Create a Beautiful Online Gallery with Lightroom Classic CC and Adobe Portfolio in 15 Minutes: https:\/\/t.co\/LSuLK5lDJi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/LSuLK5lDJi",
        "expanded_url" : "https:\/\/digital-photography-school.com\/create-beautiful-online-gallery-lightroom-classic-cc-adobe-portfolio-15-minutes\/",
        "display_url" : "digital-photography-school.com\/create-beautif\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926799019623325698",
    "text" : "How to Create a Beautiful Online Gallery with Lightroom Classic CC and Adobe Portfolio in 15 Minutes: https:\/\/t.co\/LSuLK5lDJi",
    "id" : 926799019623325698,
    "created_at" : "2017-11-04 13:11:20 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926830359257509889,
  "created_at" : "2017-11-04 15:15:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jael Sierra",
      "screen_name" : "realJaelSierra",
      "indices" : [ 3, 18 ],
      "id_str" : "832909090766598144",
      "id" : 832909090766598144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926830283319492608",
  "text" : "RT @realJaelSierra: Compassion does not require you to compromise your beliefs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926608756443463680",
    "text" : "Compassion does not require you to compromise your beliefs.",
    "id" : 926608756443463680,
    "created_at" : "2017-11-04 00:35:17 +0000",
    "user" : {
      "name" : "Jael Sierra",
      "screen_name" : "realJaelSierra",
      "protected" : false,
      "id_str" : "832909090766598144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/857570751821611008\/ZeBGrzlw_normal.jpg",
      "id" : 832909090766598144,
      "verified" : false
    }
  },
  "id" : 926830283319492608,
  "created_at" : "2017-11-04 15:15:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/uv58PtfMjz",
      "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/how-do-liquid-metal-snowflakes-grow\/3008231.article",
      "display_url" : "chemistryworld.com\/news\/how-do-li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926830231838531584",
  "text" : "RT @ChemistryWorld: Drops of liquid metal can be grown into amazing fractal patterns by applying the right voltage https:\/\/t.co\/uv58PtfMjz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/uv58PtfMjz",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/how-do-liquid-metal-snowflakes-grow\/3008231.article",
        "display_url" : "chemistryworld.com\/news\/how-do-li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926500471535054848",
    "text" : "Drops of liquid metal can be grown into amazing fractal patterns by applying the right voltage https:\/\/t.co\/uv58PtfMjz",
    "id" : 926500471535054848,
    "created_at" : "2017-11-03 17:25:00 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 926830231838531584,
  "created_at" : "2017-11-04 15:15:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "indices" : [ 3, 16 ],
      "id_str" : "61417559",
      "id" : 61417559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926830199102234624",
  "text" : "RT @ErikVoorhees: The average Bitcoin transaction fee ($10.17) is now more than twice the cost of Bitcoin itself when I first learned of it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926791347016646658",
    "text" : "The average Bitcoin transaction fee ($10.17) is now more than twice the cost of Bitcoin itself when I first learned of it ($5) in 2011 :(",
    "id" : 926791347016646658,
    "created_at" : "2017-11-04 12:40:50 +0000",
    "user" : {
      "name" : "Erik Voorhees",
      "screen_name" : "ErikVoorhees",
      "protected" : false,
      "id_str" : "61417559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/339147710\/atlas_02-1_normal.jpg",
      "id" : 61417559,
      "verified" : true
    }
  },
  "id" : 926830199102234624,
  "created_at" : "2017-11-04 15:15:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple",
      "screen_name" : "Apple",
      "indices" : [ 68, 74 ],
      "id_str" : "380749300",
      "id" : 380749300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/mjLVBnL52i",
      "expanded_url" : "https:\/\/amp.businessinsider.com\/ginger-emojis-are-finally-coming-to-the-iphone-2017-8",
      "display_url" : "amp.businessinsider.com\/ginger-emojis-\u2026"
    }, {
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/kEdwNY2ZsY",
      "expanded_url" : "https:\/\/twitter.com\/LeighaNotLeia\/status\/926809296549175296",
      "display_url" : "twitter.com\/LeighaNotLeia\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926830150871932929",
  "text" : "Smh, but they don't have a ginger haired emoji for people like you, @Apple get to it, wait Unicode in 2018? https:\/\/t.co\/mjLVBnL52i https:\/\/t.co\/kEdwNY2ZsY",
  "id" : 926830150871932929,
  "created_at" : "2017-11-04 15:15:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926829552592146432",
  "text" : "RT @lorenridinger: \u201CI think goals should never be easy, they should force you to work, even if they are uncomfortable at the time.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926690548362170368",
    "text" : "\u201CI think goals should never be easy, they should force you to work, even if they are uncomfortable at the time.\u201D",
    "id" : 926690548362170368,
    "created_at" : "2017-11-04 06:00:18 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 926829552592146432,
  "created_at" : "2017-11-04 15:12:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "performance",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926794245448626177",
  "text" : "RT @JayHoque: Let yourself be moved. \"Can you move and glide and spin?...Or do you get stuck and heavy?\" Laura Probert #performance",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "performance",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926705587466813440",
    "text" : "Let yourself be moved. \"Can you move and glide and spin?...Or do you get stuck and heavy?\" Laura Probert #performance",
    "id" : 926705587466813440,
    "created_at" : "2017-11-04 07:00:04 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926794245448626177,
  "created_at" : "2017-11-04 12:52:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pez D Spencer",
      "screen_name" : "Glorio",
      "indices" : [ 3, 10 ],
      "id_str" : "21822380",
      "id" : 21822380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926678169373077504",
  "text" : "RT @Glorio: french horn for my real friends, real horn for my french friends",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740918973093576704",
    "text" : "french horn for my real friends, real horn for my french friends",
    "id" : 740918973093576704,
    "created_at" : "2016-06-09 14:50:23 +0000",
    "user" : {
      "name" : "Pez D Spencer",
      "screen_name" : "Glorio",
      "protected" : false,
      "id_str" : "21822380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513121805096079361\/TeJ6_7o2_normal.png",
      "id" : 21822380,
      "verified" : false
    }
  },
  "id" : 926678169373077504,
  "created_at" : "2017-11-04 05:11:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leo Garcia",
      "screen_name" : "coffeenwinesite",
      "indices" : [ 3, 19 ],
      "id_str" : "2349673958",
      "id" : 2349673958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/6v24k4KTTv",
      "expanded_url" : "http:\/\/crwd.fr\/2yRPGDV",
      "display_url" : "crwd.fr\/2yRPGDV"
    } ]
  },
  "geo" : { },
  "id_str" : "926678118487789568",
  "text" : "RT @coffeenwinesite: The week in wildlife - in pictures https:\/\/t.co\/6v24k4KTTv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdfireapp.com\" rel=\"nofollow\"\u003ECrowdfire - Go Big\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/6v24k4KTTv",
        "expanded_url" : "http:\/\/crwd.fr\/2yRPGDV",
        "display_url" : "crwd.fr\/2yRPGDV"
      } ]
    },
    "geo" : { },
    "id_str" : "926485415992815616",
    "text" : "The week in wildlife - in pictures https:\/\/t.co\/6v24k4KTTv",
    "id" : 926485415992815616,
    "created_at" : "2017-11-03 16:25:11 +0000",
    "user" : {
      "name" : "leo Garcia",
      "screen_name" : "coffeenwinesite",
      "protected" : false,
      "id_str" : "2349673958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922997666392440833\/21xoPJsI_normal.jpg",
      "id" : 2349673958,
      "verified" : false
    }
  },
  "id" : 926678118487789568,
  "created_at" : "2017-11-04 05:10:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "indices" : [ 3, 10 ],
      "id_str" : "8315692",
      "id" : 8315692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ljt9dZYgws",
      "expanded_url" : "https:\/\/twitter.com\/HappyHooker1157\/status\/926118634975629312",
      "display_url" : "twitter.com\/HappyHooker115\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926678002016096256",
  "text" : "RT @GlennF: S\u2026Spalding, old friend. Is that you? https:\/\/t.co\/ljt9dZYgws",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/ljt9dZYgws",
        "expanded_url" : "https:\/\/twitter.com\/HappyHooker1157\/status\/926118634975629312",
        "display_url" : "twitter.com\/HappyHooker115\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926503022448074752",
    "text" : "S\u2026Spalding, old friend. Is that you? https:\/\/t.co\/ljt9dZYgws",
    "id" : 926503022448074752,
    "created_at" : "2017-11-03 17:35:08 +0000",
    "user" : {
      "name" : "Glenn Fleishman",
      "screen_name" : "GlennF",
      "protected" : false,
      "id_str" : "8315692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849008122152734720\/Bv0k3pr9_normal.jpg",
      "id" : 8315692,
      "verified" : true
    }
  },
  "id" : 926678002016096256,
  "created_at" : "2017-11-04 05:10:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Gilbert",
      "screen_name" : "HappyHooker1157",
      "indices" : [ 3, 19 ],
      "id_str" : "1364931128",
      "id" : 1364931128
    }, {
      "name" : "Rowanne Westhenry",
      "screen_name" : "agirlintheshed",
      "indices" : [ 21, 36 ],
      "id_str" : "850742875",
      "id" : 850742875
    }, {
      "name" : "William E Bonsense",
      "screen_name" : "freshyvc",
      "indices" : [ 37, 46 ],
      "id_str" : "784130290826510336",
      "id" : 784130290826510336
    }, {
      "name" : "Pez D Spencer",
      "screen_name" : "Glorio",
      "indices" : [ 47, 54 ],
      "id_str" : "21822380",
      "id" : 21822380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926677964481232896",
  "text" : "RT @HappyHooker1157: @agirlintheshed @freshyvc @Glorio It was released back into the sea to continue on its journey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rowanne Westhenry",
        "screen_name" : "agirlintheshed",
        "indices" : [ 0, 15 ],
        "id_str" : "850742875",
        "id" : 850742875
      }, {
        "name" : "William E Bonsense",
        "screen_name" : "freshyvc",
        "indices" : [ 16, 25 ],
        "id_str" : "784130290826510336",
        "id" : 784130290826510336
      }, {
        "name" : "Pez D Spencer",
        "screen_name" : "Glorio",
        "indices" : [ 26, 33 ],
        "id_str" : "21822380",
        "id" : 21822380
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926401054899691520",
    "geo" : { },
    "id_str" : "926406477480452096",
    "in_reply_to_user_id" : 850742875,
    "text" : "@agirlintheshed @freshyvc @Glorio It was released back into the sea to continue on its journey",
    "id" : 926406477480452096,
    "in_reply_to_status_id" : 926401054899691520,
    "created_at" : "2017-11-03 11:11:30 +0000",
    "in_reply_to_screen_name" : "agirlintheshed",
    "in_reply_to_user_id_str" : "850742875",
    "user" : {
      "name" : "Annie Gilbert",
      "screen_name" : "HappyHooker1157",
      "protected" : false,
      "id_str" : "1364931128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901311553827483648\/DnJHrw7K_normal.jpg",
      "id" : 1364931128,
      "verified" : false
    }
  },
  "id" : 926677964481232896,
  "created_at" : "2017-11-04 05:10:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Holcomb",
      "screen_name" : "ashleyxholcomb",
      "indices" : [ 3, 18 ],
      "id_str" : "44372488",
      "id" : 44372488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926675726505476096",
  "text" : "RT @ashleyxholcomb: on my last day of a job I thought taking the sugar and cream out of the break room was so dangerous",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926272271177732096",
    "text" : "on my last day of a job I thought taking the sugar and cream out of the break room was so dangerous",
    "id" : 926272271177732096,
    "created_at" : "2017-11-03 02:18:13 +0000",
    "user" : {
      "name" : "Ashley Holcomb",
      "screen_name" : "ashleyxholcomb",
      "protected" : false,
      "id_str" : "44372488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915070328715530240\/ekPlhjo8_normal.jpg",
      "id" : 44372488,
      "verified" : false
    }
  },
  "id" : 926675726505476096,
  "created_at" : "2017-11-04 05:01:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Geiser *",
      "screen_name" : "therealbradg",
      "indices" : [ 3, 16 ],
      "id_str" : "117685747",
      "id" : 117685747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926675491234484224",
  "text" : "RT @therealbradg: Type \u201CI was born\u201D and then let your predictive write your autobiography.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926260526270652416",
    "text" : "Type \u201CI was born\u201D and then let your predictive write your autobiography.",
    "id" : 926260526270652416,
    "created_at" : "2017-11-03 01:31:33 +0000",
    "user" : {
      "name" : "Bradley Geiser *",
      "screen_name" : "therealbradg",
      "protected" : false,
      "id_str" : "117685747",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904479255848828928\/knfa3ZQv_normal.jpg",
      "id" : 117685747,
      "verified" : false
    }
  },
  "id" : 926675491234484224,
  "created_at" : "2017-11-04 05:00:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DjangoCon Europe",
      "screen_name" : "DjangoConEurope",
      "indices" : [ 3, 19 ],
      "id_str" : "2231147510",
      "id" : 2231147510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926675390692839424",
  "text" : "RT @DjangoConEurope: Hey! :) Using Django at work? Have you already talked to your employer about sponsoring DjangoCon Europe 2018? :)\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7PVd8bQvU8",
        "expanded_url" : "https:\/\/2018.djangocon.eu\/sponsoring\/",
        "display_url" : "2018.djangocon.eu\/sponsoring\/"
      } ]
    },
    "geo" : { },
    "id_str" : "925001407140417537",
    "text" : "Hey! :) Using Django at work? Have you already talked to your employer about sponsoring DjangoCon Europe 2018? :)\nhttps:\/\/t.co\/7PVd8bQvU8",
    "id" : 925001407140417537,
    "created_at" : "2017-10-30 14:08:15 +0000",
    "user" : {
      "name" : "DjangoCon Europe",
      "screen_name" : "DjangoConEurope",
      "protected" : false,
      "id_str" : "2231147510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922577505348935680\/AwONGIQ4_normal.jpg",
      "id" : 2231147510,
      "verified" : false
    }
  },
  "id" : 926675390692839424,
  "created_at" : "2017-11-04 05:00:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 3, 15 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926675120114094080",
  "text" : "RT @FryRsquared: Today in \"how weird is my life right now\" you can bid to have dinner with me! All to raise\uD83D\uDCB0for the Royal Institution https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0NiwsUcYrf",
        "expanded_url" : "https:\/\/www.givergy.com\/listing\/the-royal-institution\/dinner-hannah-fry",
        "display_url" : "givergy.com\/listing\/the-ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926084843385049088",
    "text" : "Today in \"how weird is my life right now\" you can bid to have dinner with me! All to raise\uD83D\uDCB0for the Royal Institution https:\/\/t.co\/0NiwsUcYrf",
    "id" : 926084843385049088,
    "created_at" : "2017-11-02 13:53:27 +0000",
    "user" : {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "protected" : false,
      "id_str" : "273375532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549666331805483009\/vYR8d3e0_normal.jpeg",
      "id" : 273375532,
      "verified" : true
    }
  },
  "id" : 926675120114094080,
  "created_at" : "2017-11-04 04:59:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maths History",
      "screen_name" : "mathshistory",
      "indices" : [ 3, 16 ],
      "id_str" : "149449715",
      "id" : 149449715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/pX66jXoVMt",
      "expanded_url" : "http:\/\/bit.ly\/tbI8na",
      "display_url" : "bit.ly\/tbI8na"
    } ]
  },
  "geo" : { },
  "id_str" : "926674888357744640",
  "text" : "RT @mathshistory: Giambattista della Porta (1535-1615) worked on cryptography and optics, born 1 Nov https:\/\/t.co\/pX66jXoVMt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/peterrowlett.net\/\" rel=\"nofollow\"\u003EPeter Rowlett\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/pX66jXoVMt",
        "expanded_url" : "http:\/\/bit.ly\/tbI8na",
        "display_url" : "bit.ly\/tbI8na"
      } ]
    },
    "geo" : { },
    "id_str" : "925669506369884160",
    "text" : "Giambattista della Porta (1535-1615) worked on cryptography and optics, born 1 Nov https:\/\/t.co\/pX66jXoVMt",
    "id" : 925669506369884160,
    "created_at" : "2017-11-01 10:23:03 +0000",
    "user" : {
      "name" : "Maths History",
      "screen_name" : "mathshistory",
      "protected" : false,
      "id_str" : "149449715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864524433427386368\/dU53YME0_normal.jpg",
      "id" : 149449715,
      "verified" : false
    }
  },
  "id" : 926674888357744640,
  "created_at" : "2017-11-04 04:58:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Analysis Fact",
      "screen_name" : "AnalysisFact",
      "indices" : [ 3, 16 ],
      "id_str" : "100394466",
      "id" : 100394466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674857152131072",
  "text" : "RT @AnalysisFact: Interpolation is generally more trustworthy than extrapolation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926471710261510144",
    "text" : "Interpolation is generally more trustworthy than extrapolation.",
    "id" : 926471710261510144,
    "created_at" : "2017-11-03 15:30:43 +0000",
    "user" : {
      "name" : "Analysis Fact",
      "screen_name" : "AnalysisFact",
      "protected" : false,
      "id_str" : "100394466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851637179394605056\/IE4Nrk_2_normal.jpg",
      "id" : 100394466,
      "verified" : false
    }
  },
  "id" : 926674857152131072,
  "created_at" : "2017-11-04 04:57:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Algebra Fact",
      "screen_name" : "AlgebraFact",
      "indices" : [ 3, 15 ],
      "id_str" : "109958517",
      "id" : 109958517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674836084097024",
  "text" : "RT @AlgebraFact: A module M is projective if Hom(M,.) is an exact functor, and injective if Hom(.,M) is an exact functor.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926184748816437248",
    "text" : "A module M is projective if Hom(M,.) is an exact functor, and injective if Hom(.,M) is an exact functor.",
    "id" : 926184748816437248,
    "created_at" : "2017-11-02 20:30:26 +0000",
    "user" : {
      "name" : "Algebra Fact",
      "screen_name" : "AlgebraFact",
      "protected" : false,
      "id_str" : "109958517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851638135771365376\/fJ4I3nvX_normal.jpg",
      "id" : 109958517,
      "verified" : false
    }
  },
  "id" : 926674836084097024,
  "created_at" : "2017-11-04 04:57:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Algebra Fact",
      "screen_name" : "AlgebraFact",
      "indices" : [ 3, 15 ],
      "id_str" : "109958517",
      "id" : 109958517
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Bh6Ww8Z2MP",
      "expanded_url" : "http:\/\/bit.ly\/dvB9aL",
      "display_url" : "bit.ly\/dvB9aL"
    } ]
  },
  "geo" : { },
  "id_str" : "926674825602633728",
  "text" : "RT @AlgebraFact: Euler: If m and n are relatively prime, n^\u007Bphi(m)\u007D is congruent to 1 modulo m. Definition of phi(n) https:\/\/t.co\/Bh6Ww8Z2MP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Bh6Ww8Z2MP",
        "expanded_url" : "http:\/\/bit.ly\/dvB9aL",
        "display_url" : "bit.ly\/dvB9aL"
      } ]
    },
    "geo" : { },
    "id_str" : "926465296017346561",
    "text" : "Euler: If m and n are relatively prime, n^\u007Bphi(m)\u007D is congruent to 1 modulo m. Definition of phi(n) https:\/\/t.co\/Bh6Ww8Z2MP",
    "id" : 926465296017346561,
    "created_at" : "2017-11-03 15:05:14 +0000",
    "user" : {
      "name" : "Algebra Fact",
      "screen_name" : "AlgebraFact",
      "protected" : false,
      "id_str" : "109958517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851638135771365376\/fJ4I3nvX_normal.jpg",
      "id" : 109958517,
      "verified" : false
    }
  },
  "id" : 926674825602633728,
  "created_at" : "2017-11-04 04:57:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Probability Fact",
      "screen_name" : "ProbFact",
      "indices" : [ 3, 12 ],
      "id_str" : "93494670",
      "id" : 93494670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674797114920960",
  "text" : "RT @ProbFact: \"Probability is the intersection of the most rigorous mathematics and the messiest of life.\" -- Nassim Taleb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639801388529250304",
    "text" : "\"Probability is the intersection of the most rigorous mathematics and the messiest of life.\" -- Nassim Taleb",
    "id" : 639801388529250304,
    "created_at" : "2015-09-04 14:05:12 +0000",
    "user" : {
      "name" : "Probability Fact",
      "screen_name" : "ProbFact",
      "protected" : false,
      "id_str" : "93494670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851637715544100864\/Ok4o9SkZ_normal.jpg",
      "id" : 93494670,
      "verified" : false
    }
  },
  "id" : 926674797114920960,
  "created_at" : "2017-11-04 04:57:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Fact",
      "screen_name" : "DataSciFact",
      "indices" : [ 3, 15 ],
      "id_str" : "220139885",
      "id" : 220139885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674775233187840",
  "text" : "RT @DataSciFact: Professionals should be candid about the limits of their profession.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926462769762897920",
    "text" : "Professionals should be candid about the limits of their profession.",
    "id" : 926462769762897920,
    "created_at" : "2017-11-03 14:55:11 +0000",
    "user" : {
      "name" : "Data Science Fact",
      "screen_name" : "DataSciFact",
      "protected" : false,
      "id_str" : "220139885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871521787300855809\/sMpYCCGn_normal.jpg",
      "id" : 220139885,
      "verified" : false
    }
  },
  "id" : 926674775233187840,
  "created_at" : "2017-11-04 04:57:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Fact",
      "screen_name" : "DataSciFact",
      "indices" : [ 3, 15 ],
      "id_str" : "220139885",
      "id" : 220139885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674753242451968",
  "text" : "RT @DataSciFact: 'Errors using inadequate data are much less than those using no data at all.' -- Charles Babbage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633341436822482944",
    "text" : "'Errors using inadequate data are much less than those using no data at all.' -- Charles Babbage",
    "id" : 633341436822482944,
    "created_at" : "2015-08-17 18:15:40 +0000",
    "user" : {
      "name" : "Data Science Fact",
      "screen_name" : "DataSciFact",
      "protected" : false,
      "id_str" : "220139885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871521787300855809\/sMpYCCGn_normal.jpg",
      "id" : 220139885,
      "verified" : false
    }
  },
  "id" : 926674753242451968,
  "created_at" : "2017-11-04 04:57:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "indices" : [ 3, 12 ],
      "id_str" : "254791849",
      "id" : 254791849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/BNQBxdQqs4",
      "expanded_url" : "http:\/\/yt-project.org\/",
      "display_url" : "yt-project.org"
    } ]
  },
  "geo" : { },
  "id_str" : "926674726440898561",
  "text" : "RT @SciPyTip: Volumetric data analysis for astronomy https:\/\/t.co\/BNQBxdQqs4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/BNQBxdQqs4",
        "expanded_url" : "http:\/\/yt-project.org\/",
        "display_url" : "yt-project.org"
      } ]
    },
    "geo" : { },
    "id_str" : "926107939953434626",
    "text" : "Volumetric data analysis for astronomy https:\/\/t.co\/BNQBxdQqs4",
    "id" : 926107939953434626,
    "created_at" : "2017-11-02 15:25:13 +0000",
    "user" : {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "protected" : false,
      "id_str" : "254791849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851631720008867840\/29BG3PNG_normal.jpg",
      "id" : 254791849,
      "verified" : false
    }
  },
  "id" : 926674726440898561,
  "created_at" : "2017-11-04 04:57:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "indices" : [ 3, 12 ],
      "id_str" : "254791849",
      "id" : 254791849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926674719096655877",
  "text" : "RT @SciPyTip: Special functions (Bessel functions, Gamma function, etc.) are located in scipy.special.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926198519383412736",
    "text" : "Special functions (Bessel functions, Gamma function, etc.) are located in scipy.special.",
    "id" : 926198519383412736,
    "created_at" : "2017-11-02 21:25:09 +0000",
    "user" : {
      "name" : "Scientific Python",
      "screen_name" : "SciPyTip",
      "protected" : false,
      "id_str" : "254791849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851631720008867840\/29BG3PNG_normal.jpg",
      "id" : 254791849,
      "verified" : false
    }
  },
  "id" : 926674719096655877,
  "created_at" : "2017-11-04 04:57:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Django",
      "screen_name" : "djangoproject",
      "indices" : [ 3, 17 ],
      "id_str" : "191225303",
      "id" : 191225303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Iag4wkAU8Q",
      "expanded_url" : "http:\/\/ift.tt\/2zdtyAk",
      "display_url" : "ift.tt\/2zdtyAk"
    } ]
  },
  "geo" : { },
  "id_str" : "926674685454159874",
  "text" : "RT @djangoproject: Django 2.0 beta 1 released https:\/\/t.co\/Iag4wkAU8Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/Iag4wkAU8Q",
        "expanded_url" : "http:\/\/ift.tt\/2zdtyAk",
        "display_url" : "ift.tt\/2zdtyAk"
      } ]
    },
    "geo" : { },
    "id_str" : "920111986591092736",
    "text" : "Django 2.0 beta 1 released https:\/\/t.co\/Iag4wkAU8Q",
    "id" : 920111986591092736,
    "created_at" : "2017-10-17 02:19:27 +0000",
    "user" : {
      "name" : "Django",
      "screen_name" : "djangoproject",
      "protected" : false,
      "id_str" : "191225303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544873453346500608\/4aGjtNQv_normal.png",
      "id" : 191225303,
      "verified" : true
    }
  },
  "id" : 926674685454159874,
  "created_at" : "2017-11-04 04:57:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Django",
      "screen_name" : "djangoproject",
      "indices" : [ 3, 17 ],
      "id_str" : "191225303",
      "id" : 191225303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/J3hN9pe7CC",
      "expanded_url" : "http:\/\/ift.tt\/2lErbVk",
      "display_url" : "ift.tt\/2lErbVk"
    } ]
  },
  "geo" : { },
  "id_str" : "926674675014553600",
  "text" : "RT @djangoproject: Django bugfix release: 1.11.7 https:\/\/t.co\/J3hN9pe7CC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/J3hN9pe7CC",
        "expanded_url" : "http:\/\/ift.tt\/2lErbVk",
        "display_url" : "ift.tt\/2lErbVk"
      } ]
    },
    "geo" : { },
    "id_str" : "925912401865854976",
    "text" : "Django bugfix release: 1.11.7 https:\/\/t.co\/J3hN9pe7CC",
    "id" : 925912401865854976,
    "created_at" : "2017-11-02 02:28:13 +0000",
    "user" : {
      "name" : "Django",
      "screen_name" : "djangoproject",
      "protected" : false,
      "id_str" : "191225303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544873453346500608\/4aGjtNQv_normal.png",
      "id" : 191225303,
      "verified" : true
    }
  },
  "id" : 926674675014553600,
  "created_at" : "2017-11-04 04:57:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "indices" : [ 3, 10 ],
      "id_str" : "63873759",
      "id" : 63873759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/QR9Pqi2jvp",
      "expanded_url" : "https:\/\/www.meetup.com\/austinpython\/events\/242025685\/",
      "display_url" : "meetup.com\/austinpython\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926674649446043648",
  "text" : "RT @ThePSF: Austin Python meetup Nov. 8: https:\/\/t.co\/QR9Pqi2jvp. Lightning talks, discussion, and Q&amp;A.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/QR9Pqi2jvp",
        "expanded_url" : "https:\/\/www.meetup.com\/austinpython\/events\/242025685\/",
        "display_url" : "meetup.com\/austinpython\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926554590924935168",
    "text" : "Austin Python meetup Nov. 8: https:\/\/t.co\/QR9Pqi2jvp. Lightning talks, discussion, and Q&amp;A.",
    "id" : 926554590924935168,
    "created_at" : "2017-11-03 21:00:03 +0000",
    "user" : {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "protected" : false,
      "id_str" : "63873759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439154912719413248\/pUBY5pVj_normal.png",
      "id" : 63873759,
      "verified" : true
    }
  },
  "id" : 926674649446043648,
  "created_at" : "2017-11-04 04:57:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evolved Office",
      "screen_name" : "EvolvedOfficeUS",
      "indices" : [ 3, 19 ],
      "id_str" : "256666920",
      "id" : 256666920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/HBrFxKY9wu",
      "expanded_url" : "http:\/\/ow.ly\/diyi30fsWyH",
      "display_url" : "ow.ly\/diyi30fsWyH"
    } ]
  },
  "geo" : { },
  "id_str" : "926674418973192193",
  "text" : "RT @EvolvedOfficeUS: Science Says You Should Leave Work at 2 p.m. and Go for a Walk. https:\/\/t.co\/HBrFxKY9wu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/HBrFxKY9wu",
        "expanded_url" : "http:\/\/ow.ly\/diyi30fsWyH",
        "display_url" : "ow.ly\/diyi30fsWyH"
      } ]
    },
    "geo" : { },
    "id_str" : "926458963494924288",
    "text" : "Science Says You Should Leave Work at 2 p.m. and Go for a Walk. https:\/\/t.co\/HBrFxKY9wu",
    "id" : 926458963494924288,
    "created_at" : "2017-11-03 14:40:04 +0000",
    "user" : {
      "name" : "Evolved Office",
      "screen_name" : "EvolvedOfficeUS",
      "protected" : false,
      "id_str" : "256666920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791624166680199168\/UpgjMD1D_normal.jpg",
      "id" : 256666920,
      "verified" : false
    }
  },
  "id" : 926674418973192193,
  "created_at" : "2017-11-04 04:56:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/RKq9YqU1Ec",
      "expanded_url" : "https:\/\/www.recode.net\/2017\/10\/30\/16567378\/david-rosenblatt-1stdibs-luxury-marketplace-commerce-amazon-recode-decode-kara-swisher-podcast?utm_campaign=recode.social&utm_content=recode&utm_medium=social&utm_source=twitter",
      "display_url" : "recode.net\/2017\/10\/30\/165\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926673916944412672",
  "text" : "RT @Recode: Meet David Rosenblatt, the e-commerce CEO who\u2019s not afraid of Amazon:\nhttps:\/\/t.co\/RKq9YqU1Ec",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/RKq9YqU1Ec",
        "expanded_url" : "https:\/\/www.recode.net\/2017\/10\/30\/16567378\/david-rosenblatt-1stdibs-luxury-marketplace-commerce-amazon-recode-decode-kara-swisher-podcast?utm_campaign=recode.social&utm_content=recode&utm_medium=social&utm_source=twitter",
        "display_url" : "recode.net\/2017\/10\/30\/165\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926613720125513728",
    "text" : "Meet David Rosenblatt, the e-commerce CEO who\u2019s not afraid of Amazon:\nhttps:\/\/t.co\/RKq9YqU1Ec",
    "id" : 926613720125513728,
    "created_at" : "2017-11-04 00:55:01 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 926673916944412672,
  "created_at" : "2017-11-04 04:54:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 90, 96 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bRhU2vRmX3",
      "expanded_url" : "https:\/\/www.theverge.com\/2017\/11\/3\/16602352\/face-with-tears-of-joy-emoji-most-popular-apple-study?utm_campaign=theverge.social&utm_content=recode&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2017\/11\/3\/1660\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926673892885843969",
  "text" : "RT @Recode: The Face with Tears of Joy emoji is the most popular, according to Apple. Via @verge: https:\/\/t.co\/bRhU2vRmX3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Verge",
        "screen_name" : "verge",
        "indices" : [ 78, 84 ],
        "id_str" : "275686563",
        "id" : 275686563
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/bRhU2vRmX3",
        "expanded_url" : "https:\/\/www.theverge.com\/2017\/11\/3\/16602352\/face-with-tears-of-joy-emoji-most-popular-apple-study?utm_campaign=theverge.social&utm_content=recode&utm_medium=social&utm_source=twitter",
        "display_url" : "theverge.com\/2017\/11\/3\/1660\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926633854005366785",
    "text" : "The Face with Tears of Joy emoji is the most popular, according to Apple. Via @verge: https:\/\/t.co\/bRhU2vRmX3",
    "id" : 926633854005366785,
    "created_at" : "2017-11-04 02:15:01 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 926673892885843969,
  "created_at" : "2017-11-04 04:54:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sanette Tanaka",
      "screen_name" : "ssktanaka",
      "indices" : [ 3, 13 ],
      "id_str" : "170034527",
      "id" : 170034527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/3Fxk1dbVKb",
      "expanded_url" : "https:\/\/twitter.com\/pgcat\/status\/926087833500180481",
      "display_url" : "twitter.com\/pgcat\/status\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926673438151979008",
  "text" : "RT @ssktanaka: Come work with me! https:\/\/t.co\/3Fxk1dbVKb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/3Fxk1dbVKb",
        "expanded_url" : "https:\/\/twitter.com\/pgcat\/status\/926087833500180481",
        "display_url" : "twitter.com\/pgcat\/status\/9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926090220973576192",
    "text" : "Come work with me! https:\/\/t.co\/3Fxk1dbVKb",
    "id" : 926090220973576192,
    "created_at" : "2017-11-02 14:14:49 +0000",
    "user" : {
      "name" : "Sanette Tanaka",
      "screen_name" : "ssktanaka",
      "protected" : false,
      "id_str" : "170034527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821402169890967554\/OQYwcgIJ_normal.jpg",
      "id" : 170034527,
      "verified" : true
    }
  },
  "id" : 926673438151979008,
  "created_at" : "2017-11-04 04:52:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4yAiLkInSN",
      "expanded_url" : "http:\/\/ift.tt\/2A5QS3a",
      "display_url" : "ift.tt\/2A5QS3a"
    } ]
  },
  "geo" : { },
  "id_str" : "926672965311266821",
  "text" : "RT @dronepilots: Gov. Martinez touts New Mexico for federal drone experiment | DronePilots - https:\/\/t.co\/4yAiLkInSN #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/4yAiLkInSN",
        "expanded_url" : "http:\/\/ift.tt\/2A5QS3a",
        "display_url" : "ift.tt\/2A5QS3a"
      } ]
    },
    "geo" : { },
    "id_str" : "926622770854756353",
    "text" : "Gov. Martinez touts New Mexico for federal drone experiment | DronePilots - https:\/\/t.co\/4yAiLkInSN #drones",
    "id" : 926622770854756353,
    "created_at" : "2017-11-04 01:30:59 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926672965311266821,
  "created_at" : "2017-11-04 04:50:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926672570946072576",
  "text" : "Some events &amp; potential stuff looking forward to",
  "id" : 926672570946072576,
  "created_at" : "2017-11-04 04:48:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "indices" : [ 3, 10 ],
      "id_str" : "63873759",
      "id" : 63873759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pycon",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/PCWBDjuvwe",
      "expanded_url" : "https:\/\/www.eventbrite.com\/e\/startup-row-pitch-event-indy-tickets-36908331814?aff=PSF",
      "display_url" : "eventbrite.com\/e\/startup-row-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926669482399076352",
  "text" : "RT @ThePSF: Indy Startup Row Pitch for #pycon 2018. Event Jan. 9, 2018: https:\/\/t.co\/PCWBDjuvwe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pycon",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/PCWBDjuvwe",
        "expanded_url" : "https:\/\/www.eventbrite.com\/e\/startup-row-pitch-event-indy-tickets-36908331814?aff=PSF",
        "display_url" : "eventbrite.com\/e\/startup-row-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926101613416210433",
    "text" : "Indy Startup Row Pitch for #pycon 2018. Event Jan. 9, 2018: https:\/\/t.co\/PCWBDjuvwe",
    "id" : 926101613416210433,
    "created_at" : "2017-11-02 15:00:05 +0000",
    "user" : {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "protected" : false,
      "id_str" : "63873759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439154912719413248\/pUBY5pVj_normal.png",
      "id" : 63873759,
      "verified" : true
    }
  },
  "id" : 926669482399076352,
  "created_at" : "2017-11-04 04:36:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "At Mind",
      "screen_name" : "atmind",
      "indices" : [ 3, 10 ],
      "id_str" : "34893678",
      "id" : 34893678
    }, {
      "name" : "Python Software",
      "screen_name" : "ThePSF",
      "indices" : [ 103, 110 ],
      "id_str" : "63873759",
      "id" : 63873759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "b3d",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "b3d101",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926669322185052160",
  "text" : "RT @atmind: Our Pymove3D tutorials have been translated to Latin Spanish. Thank you Carlos Santana and @ThePSF #b3d #b3d101 https:\/\/t.co\/RJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Python Software",
        "screen_name" : "ThePSF",
        "indices" : [ 91, 98 ],
        "id_str" : "63873759",
        "id" : 63873759
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "b3d",
        "indices" : [ 99, 103 ]
      }, {
        "text" : "b3d101",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/RJkOBNRKr0",
        "expanded_url" : "https:\/\/b3d101.org\/es\/python\/",
        "display_url" : "b3d101.org\/es\/python\/"
      } ]
    },
    "geo" : { },
    "id_str" : "926437230343806977",
    "text" : "Our Pymove3D tutorials have been translated to Latin Spanish. Thank you Carlos Santana and @ThePSF #b3d #b3d101 https:\/\/t.co\/RJkOBNRKr0",
    "id" : 926437230343806977,
    "created_at" : "2017-11-03 13:13:42 +0000",
    "user" : {
      "name" : "At Mind",
      "screen_name" : "atmind",
      "protected" : false,
      "id_str" : "34893678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1235799845\/330db530-3dd7-4ccf-885d-d5b2985d50ae_normal.png",
      "id" : 34893678,
      "verified" : false
    }
  },
  "id" : 926669322185052160,
  "created_at" : "2017-11-04 04:35:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 3, 10 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noms",
      "indices" : [ 23, 28 ]
    }, {
      "text" : "NationalSandwichDay",
      "indices" : [ 29, 49 ]
    }, {
      "text" : "SeenOnFlickr",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/wIs5wvbK6P",
      "expanded_url" : "https:\/\/flic.kr\/p\/LgDMZ9",
      "display_url" : "flic.kr\/p\/LgDMZ9"
    } ]
  },
  "geo" : { },
  "id_str" : "926669151237738496",
  "text" : "RT @Flickr: We be like #noms #NationalSandwichDay #SeenOnFlickr --&gt; https:\/\/t.co\/wIs5wvbK6P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noms",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "NationalSandwichDay",
        "indices" : [ 17, 37 ]
      }, {
        "text" : "SeenOnFlickr",
        "indices" : [ 38, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/wIs5wvbK6P",
        "expanded_url" : "https:\/\/flic.kr\/p\/LgDMZ9",
        "display_url" : "flic.kr\/p\/LgDMZ9"
      } ]
    },
    "geo" : { },
    "id_str" : "926544689045504000",
    "text" : "We be like #noms #NationalSandwichDay #SeenOnFlickr --&gt; https:\/\/t.co\/wIs5wvbK6P",
    "id" : 926544689045504000,
    "created_at" : "2017-11-03 20:20:42 +0000",
    "user" : {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "protected" : false,
      "id_str" : "21237045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666413114489831424\/aJZNErvd_normal.png",
      "id" : 21237045,
      "verified" : true
    }
  },
  "id" : 926669151237738496,
  "created_at" : "2017-11-04 04:35:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3TfFoSPqMn",
      "expanded_url" : "https:\/\/www.photographytalk.com\/beginner-photography-tips\/7574-10-unique-photography-tricks-anyone-can-do-at-home",
      "display_url" : "photographytalk.com\/beginner-photo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926669035282059264",
  "text" : "RT @PhotographyTalk: Check out the video and a summary of each trick below:\n\nhttps:\/\/t.co\/3TfFoSPqMn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/3TfFoSPqMn",
        "expanded_url" : "https:\/\/www.photographytalk.com\/beginner-photography-tips\/7574-10-unique-photography-tricks-anyone-can-do-at-home",
        "display_url" : "photographytalk.com\/beginner-photo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926444330637824000",
    "text" : "Check out the video and a summary of each trick below:\n\nhttps:\/\/t.co\/3TfFoSPqMn",
    "id" : 926444330637824000,
    "created_at" : "2017-11-03 13:41:55 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 926669035282059264,
  "created_at" : "2017-11-04 04:34:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "95590606",
      "id" : 95590606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ANlJPKkqMz",
      "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/236-photography-business-tips\/7557-4-mistakes-photographers-make-when-buying-a-franchise",
      "display_url" : "photographytalk.com\/photography-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926668998959394821",
  "text" : "RT @PhotographyTalk: Let's take a closer look at four mistakes photographers make when buying a franchise.\n\nhttps:\/\/t.co\/ANlJPKkqMz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ANlJPKkqMz",
        "expanded_url" : "https:\/\/www.photographytalk.com\/photography-articles\/236-photography-business-tips\/7557-4-mistakes-photographers-make-when-buying-a-franchise",
        "display_url" : "photographytalk.com\/photography-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926444655763443717",
    "text" : "Let's take a closer look at four mistakes photographers make when buying a franchise.\n\nhttps:\/\/t.co\/ANlJPKkqMz",
    "id" : 926444655763443717,
    "created_at" : "2017-11-03 13:43:13 +0000",
    "user" : {
      "name" : "PhotographyTalk",
      "screen_name" : "PhotographyTalk",
      "protected" : false,
      "id_str" : "95590606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829487881274040320\/kZ5ZmyEP_normal.jpg",
      "id" : 95590606,
      "verified" : false
    }
  },
  "id" : 926668998959394821,
  "created_at" : "2017-11-04 04:34:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "CMU Mechanical Eng.",
      "screen_name" : "CMU_Mech",
      "indices" : [ 95, 104 ],
      "id_str" : "177957319",
      "id" : 177957319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/IeFVl7NGJM",
      "expanded_url" : "http:\/\/phy.so\/428944333",
      "display_url" : "phy.so\/428944333"
    } ]
  },
  "geo" : { },
  "id_str" : "926668944425078784",
  "text" : "RT @physorg_com: Fluidic transistor ushers the age of liquid computers https:\/\/t.co\/IeFVl7NGJM @CMU_Mech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CMU Mechanical Eng.",
        "screen_name" : "CMU_Mech",
        "indices" : [ 78, 87 ],
        "id_str" : "177957319",
        "id" : 177957319
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/IeFVl7NGJM",
        "expanded_url" : "http:\/\/phy.so\/428944333",
        "display_url" : "phy.so\/428944333"
      } ]
    },
    "geo" : { },
    "id_str" : "926542577003790341",
    "text" : "Fluidic transistor ushers the age of liquid computers https:\/\/t.co\/IeFVl7NGJM @CMU_Mech",
    "id" : 926542577003790341,
    "created_at" : "2017-11-03 20:12:19 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 926668944425078784,
  "created_at" : "2017-11-04 04:34:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "indices" : [ 0, 11 ],
      "id_str" : "18009781",
      "id" : 18009781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926668763625377797",
  "in_reply_to_user_id" : 18009781,
  "text" : "@joshgroban You should sell alarm clocks that serenade people when they wake up",
  "id" : 926668763625377797,
  "created_at" : "2017-11-04 04:33:44 +0000",
  "in_reply_to_screen_name" : "joshgroban",
  "in_reply_to_user_id_str" : "18009781",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "indices" : [ 3, 14 ],
      "id_str" : "18009781",
      "id" : 18009781
    }, {
      "name" : "Me",
      "screen_name" : "4everSharkie",
      "indices" : [ 16, 29 ],
      "id_str" : "444328193",
      "id" : 444328193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926668583496814595",
  "text" : "RT @joshgroban: @4everSharkie Please continue not being attracted to me, thank you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Me",
        "screen_name" : "4everSharkie",
        "indices" : [ 0, 13 ],
        "id_str" : "444328193",
        "id" : 444328193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "914667516542308352",
    "geo" : { },
    "id_str" : "914672160987320320",
    "in_reply_to_user_id" : 444328193,
    "text" : "@4everSharkie Please continue not being attracted to me, thank you",
    "id" : 914672160987320320,
    "in_reply_to_status_id" : 914667516542308352,
    "created_at" : "2017-10-02 02:03:31 +0000",
    "in_reply_to_screen_name" : "4everSharkie",
    "in_reply_to_user_id_str" : "444328193",
    "user" : {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "protected" : false,
      "id_str" : "18009781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880503021855272960\/klhrNu-e_normal.jpg",
      "id" : 18009781,
      "verified" : true
    }
  },
  "id" : 926668583496814595,
  "created_at" : "2017-11-04 04:33:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "indices" : [ 3, 14 ],
      "id_str" : "18009781",
      "id" : 18009781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926668533798526977",
  "text" : "RT @joshgroban: You can now pre-order my upcoming coffee table book Stage to Stage! Jam packed with picturey goodness and love. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/ULLNXBk9Gy",
        "expanded_url" : "http:\/\/smarturl.it\/STAGETOSTAGEBOOK",
        "display_url" : "smarturl.it\/STAGETOSTAGEBO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "890963577254932493",
    "text" : "You can now pre-order my upcoming coffee table book Stage to Stage! Jam packed with picturey goodness and love. https:\/\/t.co\/ULLNXBk9Gy",
    "id" : 890963577254932493,
    "created_at" : "2017-07-28 15:54:04 +0000",
    "user" : {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "protected" : false,
      "id_str" : "18009781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880503021855272960\/klhrNu-e_normal.jpg",
      "id" : 18009781,
      "verified" : true
    }
  },
  "id" : 926668533798526977,
  "created_at" : "2017-11-04 04:32:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 3, 11 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/uZbNMHoNfL",
      "expanded_url" : "http:\/\/reut.rs\/2z9q7yh",
      "display_url" : "reut.rs\/2z9q7yh"
    } ]
  },
  "geo" : { },
  "id_str" : "926668330878078976",
  "text" : "RT @Reuters: Syria declares victory over Islamic State in Deir al-Zor https:\/\/t.co\/uZbNMHoNfL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/uZbNMHoNfL",
        "expanded_url" : "http:\/\/reut.rs\/2z9q7yh",
        "display_url" : "reut.rs\/2z9q7yh"
      } ]
    },
    "geo" : { },
    "id_str" : "926367883453698050",
    "text" : "Syria declares victory over Islamic State in Deir al-Zor https:\/\/t.co\/uZbNMHoNfL",
    "id" : 926367883453698050,
    "created_at" : "2017-11-03 08:38:09 +0000",
    "user" : {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "protected" : false,
      "id_str" : "1652541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877554927932891136\/ZBEs235N_normal.jpg",
      "id" : 1652541,
      "verified" : true
    }
  },
  "id" : 926668330878078976,
  "created_at" : "2017-11-04 04:32:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Lucy Rogers",
      "screen_name" : "DrLucyRogers",
      "indices" : [ 3, 16 ],
      "id_str" : "24239110",
      "id" : 24239110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926668028665913344",
  "text" : "RT @DrLucyRogers: The Guild of Makers is now out of stealth mode. Have a look at our website to see what we're about :) https:\/\/t.co\/vWSBtI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/vWSBtIaL9u",
        "expanded_url" : "http:\/\/www.guildofmakers.org",
        "display_url" : "guildofmakers.org"
      } ]
    },
    "geo" : { },
    "id_str" : "926219444430532610",
    "text" : "The Guild of Makers is now out of stealth mode. Have a look at our website to see what we're about :) https:\/\/t.co\/vWSBtIaL9u",
    "id" : 926219444430532610,
    "created_at" : "2017-11-02 22:48:18 +0000",
    "user" : {
      "name" : "Dr Lucy Rogers",
      "screen_name" : "DrLucyRogers",
      "protected" : false,
      "id_str" : "24239110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920344513444499456\/qpcDPwfF_normal.jpg",
      "id" : 24239110,
      "verified" : true
    }
  },
  "id" : 926668028665913344,
  "created_at" : "2017-11-04 04:30:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The MagPi",
      "screen_name" : "TheMagP1",
      "indices" : [ 3, 12 ],
      "id_str" : "550247610",
      "id" : 550247610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926667915918704640",
  "text" : "RT @TheMagP1: Rob is off to Disney World! Twitter will now be in the safe(r) hands of Lucy for a couple weeks. Byeeeeeeee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "923581903336329216",
    "text" : "Rob is off to Disney World! Twitter will now be in the safe(r) hands of Lucy for a couple weeks. Byeeeeeeee",
    "id" : 923581903336329216,
    "created_at" : "2017-10-26 16:07:39 +0000",
    "user" : {
      "name" : "The MagPi",
      "screen_name" : "TheMagP1",
      "protected" : false,
      "id_str" : "550247610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887960758952357888\/z2Q17ojM_normal.jpg",
      "id" : 550247610,
      "verified" : false
    }
  },
  "id" : 926667915918704640,
  "created_at" : "2017-11-04 04:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/4xTJSyjAc0",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4qk90",
      "display_url" : "cards.twitter.com\/cards\/a6dip\/4q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926667580613562375",
  "text" : "RT @hootsuite: Stay updated with the latest social media terminology \uD83D\uDE01 226 essential definitions. https:\/\/t.co\/4xTJSyjAc0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/4xTJSyjAc0",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4qk90",
        "display_url" : "cards.twitter.com\/cards\/a6dip\/4q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926664068261441536",
    "text" : "Stay updated with the latest social media terminology \uD83D\uDE01 226 essential definitions. https:\/\/t.co\/4xTJSyjAc0",
    "id" : 926664068261441536,
    "created_at" : "2017-11-04 04:15:05 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 926667580613562375,
  "created_at" : "2017-11-04 04:29:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/3PQ2cwhI6y",
      "expanded_url" : "https:\/\/twitter.com\/raphaelalnajaar\/status\/926571137143799808",
      "display_url" : "twitter.com\/raphaelalnajaa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926666887374794752",
  "text" : "RT @garyvee: Headed to Moscow to connect to LA as we speak https:\/\/t.co\/3PQ2cwhI6y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/3PQ2cwhI6y",
        "expanded_url" : "https:\/\/twitter.com\/raphaelalnajaar\/status\/926571137143799808",
        "display_url" : "twitter.com\/raphaelalnajaa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926571830554619904",
    "text" : "Headed to Moscow to connect to LA as we speak https:\/\/t.co\/3PQ2cwhI6y",
    "id" : 926571830554619904,
    "created_at" : "2017-11-03 22:08:33 +0000",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839672994159013894\/ndVV3x8D_normal.jpg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 926666887374794752,
  "created_at" : "2017-11-04 04:26:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krista Nightengale",
      "screen_name" : "Knightengale",
      "indices" : [ 3, 16 ],
      "id_str" : "22339534",
      "id" : 22339534
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 107, 114 ],
      "id_str" : "16228398",
      "id" : 16228398
    }, {
      "name" : "TREC Dallas",
      "screen_name" : "TRECDallas",
      "indices" : [ 118, 129 ],
      "id_str" : "96022902",
      "id" : 96022902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dallas",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926666737566830592",
  "text" : "RT @Knightengale: \"No matter what I do for #Dallas, it will never equal what Dallas has done for me,\" says @mcuban at @TRECDallas' Shark Ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 89, 96 ],
        "id_str" : "16228398",
        "id" : 16228398
      }, {
        "name" : "TREC Dallas",
        "screen_name" : "TRECDallas",
        "indices" : [ 100, 111 ],
        "id_str" : "96022902",
        "id" : 96022902
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dallas",
        "indices" : [ 25, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926246986558341120",
    "text" : "\"No matter what I do for #Dallas, it will never equal what Dallas has done for me,\" says @mcuban at @TRECDallas' Shark Tank.",
    "id" : 926246986558341120,
    "created_at" : "2017-11-03 00:37:45 +0000",
    "user" : {
      "name" : "Krista Nightengale",
      "screen_name" : "Knightengale",
      "protected" : false,
      "id_str" : "22339534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875862726597255168\/nxLqjk7q_normal.jpg",
      "id" : 22339534,
      "verified" : false
    }
  },
  "id" : 926666737566830592,
  "created_at" : "2017-11-04 04:25:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brady Verge",
      "screen_name" : "Bradynsvencicki",
      "indices" : [ 0, 16 ],
      "id_str" : "24623795",
      "id" : 24623795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926665708737650688",
  "geo" : { },
  "id_str" : "926666529625829376",
  "in_reply_to_user_id" : 24623795,
  "text" : "@Bradynsvencicki Overall for long term investment correlation still remains positive",
  "id" : 926666529625829376,
  "in_reply_to_status_id" : 926665708737650688,
  "created_at" : "2017-11-04 04:24:51 +0000",
  "in_reply_to_screen_name" : "Bradynsvencicki",
  "in_reply_to_user_id_str" : "24623795",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brady Verge",
      "screen_name" : "Bradynsvencicki",
      "indices" : [ 0, 16 ],
      "id_str" : "24623795",
      "id" : 24623795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926665708737650688",
  "geo" : { },
  "id_str" : "926666426018140160",
  "in_reply_to_user_id" : 24623795,
  "text" : "@Bradynsvencicki The fork will slow down the price progress. Every time any cryptocurrency has a fork the price usually drops by some margin.",
  "id" : 926666426018140160,
  "in_reply_to_status_id" : 926665708737650688,
  "created_at" : "2017-11-04 04:24:27 +0000",
  "in_reply_to_screen_name" : "Bradynsvencicki",
  "in_reply_to_user_id_str" : "24623795",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techy Blogger",
      "screen_name" : "TechyBloggr",
      "indices" : [ 3, 15 ],
      "id_str" : "1891180976",
      "id" : 1891180976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SearchCap",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/mrQWCOmo2q",
      "expanded_url" : "https:\/\/selnd.com\/2iZA1fi",
      "display_url" : "selnd.com\/2iZA1fi"
    } ]
  },
  "geo" : { },
  "id_str" : "926665462582214656",
  "text" : "RT @TechyBloggr: #SearchCap: Google mobile design, Google News breaks RSS feeds &amp; Baidu hack by rustybrick https:\/\/t.co\/mrQWCOmo2q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SearchCap",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/mrQWCOmo2q",
        "expanded_url" : "https:\/\/selnd.com\/2iZA1fi",
        "display_url" : "selnd.com\/2iZA1fi"
      } ]
    },
    "geo" : { },
    "id_str" : "926665073795436545",
    "text" : "#SearchCap: Google mobile design, Google News breaks RSS feeds &amp; Baidu hack by rustybrick https:\/\/t.co\/mrQWCOmo2q",
    "id" : 926665073795436545,
    "created_at" : "2017-11-04 04:19:04 +0000",
    "user" : {
      "name" : "Techy Blogger",
      "screen_name" : "TechyBloggr",
      "protected" : false,
      "id_str" : "1891180976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809483187181252610\/T5J1BMOD_normal.jpg",
      "id" : 1891180976,
      "verified" : false
    }
  },
  "id" : 926665462582214656,
  "created_at" : "2017-11-04 04:20:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarCraft",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/arwiSjDdkA",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/starcraft-ii-goes-free-to-play-blizzcon-2017,35841.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/starcraft\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926665395297312769",
  "text" : "RT @tomshardware: \u25B8 '#StarCraft II' Goes Free-To-Play Later This Month https:\/\/t.co\/arwiSjDdkA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StarCraft",
        "indices" : [ 3, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/arwiSjDdkA",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/starcraft-ii-goes-free-to-play-blizzcon-2017,35841.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/starcraft\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926534962404196352",
    "text" : "\u25B8 '#StarCraft II' Goes Free-To-Play Later This Month https:\/\/t.co\/arwiSjDdkA",
    "id" : 926534962404196352,
    "created_at" : "2017-11-03 19:42:03 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926665395297312769,
  "created_at" : "2017-11-04 04:20:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jArKRihUDK",
      "expanded_url" : "https:\/\/makezine.com\/2017\/11\/02\/skill-builder-using-a-combination-square\/",
      "display_url" : "makezine.com\/2017\/11\/02\/ski\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926665365601611776",
  "text" : "RT @make: Combining a sliding ruler and angle-measuring tool, this device is certainly something that's nice to have https:\/\/t.co\/jArKRihUDK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/jArKRihUDK",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/02\/skill-builder-using-a-combination-square\/",
        "display_url" : "makezine.com\/2017\/11\/02\/ski\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926480416114139138",
    "text" : "Combining a sliding ruler and angle-measuring tool, this device is certainly something that's nice to have https:\/\/t.co\/jArKRihUDK",
    "id" : 926480416114139138,
    "created_at" : "2017-11-03 16:05:19 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 926665365601611776,
  "created_at" : "2017-11-04 04:20:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.I.M.B.R.O.W.S.K.I.",
      "screen_name" : "PeaceAndCheese",
      "indices" : [ 3, 18 ],
      "id_str" : "34666113",
      "id" : 34666113
    }, {
      "name" : "badria Jibril",
      "screen_name" : "BadriaJibril",
      "indices" : [ 20, 33 ],
      "id_str" : "31248264",
      "id" : 31248264
    }, {
      "name" : "terrycrews",
      "screen_name" : "terrycrews",
      "indices" : [ 34, 45 ],
      "id_str" : "16305370",
      "id" : 16305370
    }, {
      "name" : "Tichina Arnold",
      "screen_name" : "TichinaArnold",
      "indices" : [ 115, 129 ],
      "id_str" : "22037660",
      "id" : 22037660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926665164061110272",
  "text" : "RT @PeaceAndCheese: @BadriaJibril @terrycrews This means more money in the household (possibly) &amp; a reason for @TichinaArnold to say, \"I do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "badria Jibril",
        "screen_name" : "BadriaJibril",
        "indices" : [ 0, 13 ],
        "id_str" : "31248264",
        "id" : 31248264
      }, {
        "name" : "terrycrews",
        "screen_name" : "terrycrews",
        "indices" : [ 14, 25 ],
        "id_str" : "16305370",
        "id" : 16305370
      }, {
        "name" : "Tichina Arnold",
        "screen_name" : "TichinaArnold",
        "indices" : [ 95, 109 ],
        "id_str" : "22037660",
        "id" : 22037660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926199573927907328",
    "geo" : { },
    "id_str" : "926204421134061568",
    "in_reply_to_user_id" : 31248264,
    "text" : "@BadriaJibril @terrycrews This means more money in the household (possibly) &amp; a reason for @TichinaArnold to say, \"I don't need this! My man has THREE jobs, OK?!\".",
    "id" : 926204421134061568,
    "in_reply_to_status_id" : 926199573927907328,
    "created_at" : "2017-11-02 21:48:36 +0000",
    "in_reply_to_screen_name" : "BadriaJibril",
    "in_reply_to_user_id_str" : "31248264",
    "user" : {
      "name" : "J.I.M.B.R.O.W.S.K.I.",
      "screen_name" : "PeaceAndCheese",
      "protected" : false,
      "id_str" : "34666113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000814663442\/e1fa9f906ab85ac545d908b790569b39_normal.png",
      "id" : 34666113,
      "verified" : false
    }
  },
  "id" : 926665164061110272,
  "created_at" : "2017-11-04 04:19:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xKP6Ntt3mK",
      "expanded_url" : "http:\/\/ift.tt\/2zcv86E",
      "display_url" : "ift.tt\/2zcv86E"
    } ]
  },
  "geo" : { },
  "id_str" : "926664836515287040",
  "text" : "RT @dronepilots: Drone races held at Louisville Mega Cavern | DronePilots - https:\/\/t.co\/xKP6Ntt3mK #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/xKP6Ntt3mK",
        "expanded_url" : "http:\/\/ift.tt\/2zcv86E",
        "display_url" : "ift.tt\/2zcv86E"
      } ]
    },
    "geo" : { },
    "id_str" : "926662836528574471",
    "text" : "Drone races held at Louisville Mega Cavern | DronePilots - https:\/\/t.co\/xKP6Ntt3mK #drones",
    "id" : 926662836528574471,
    "created_at" : "2017-11-04 04:10:11 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926664836515287040,
  "created_at" : "2017-11-04 04:18:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926664769909686272",
  "text" : "RT @engadget: 'House of Cards' producer Media Rights Capital announced Spacey has been suspended \"effective immediately.\" https:\/\/t.co\/ihc7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ihc7JhLzcv",
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/926639054644539399",
        "display_url" : "twitter.com\/engadget\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926642715848212480",
    "text" : "'House of Cards' producer Media Rights Capital announced Spacey has been suspended \"effective immediately.\" https:\/\/t.co\/ihc7JhLzcv",
    "id" : 926642715848212480,
    "created_at" : "2017-11-04 02:50:14 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926664769909686272,
  "created_at" : "2017-11-04 04:17:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motivation",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926664744420986880",
  "text" : "RT @JayHoque: Clear your mind. \"Easy, free and clear.\" Laura Probert #motivation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "motivation",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926645188667174912",
    "text" : "Clear your mind. \"Easy, free and clear.\" Laura Probert #motivation",
    "id" : 926645188667174912,
    "created_at" : "2017-11-04 03:00:03 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926664744420986880,
  "created_at" : "2017-11-04 04:17:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/T39QGGCQht",
      "expanded_url" : "http:\/\/ift.tt\/2A5bqsA",
      "display_url" : "ift.tt\/2A5bqsA"
    } ]
  },
  "geo" : { },
  "id_str" : "926664684664651776",
  "text" : "RT @dronepilots: For drones, the next front may be underwater | DronePilots - https:\/\/t.co\/T39QGGCQht #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/T39QGGCQht",
        "expanded_url" : "http:\/\/ift.tt\/2A5bqsA",
        "display_url" : "ift.tt\/2A5bqsA"
      } ]
    },
    "geo" : { },
    "id_str" : "926642782634201088",
    "text" : "For drones, the next front may be underwater | DronePilots - https:\/\/t.co\/T39QGGCQht #drones",
    "id" : 926642782634201088,
    "created_at" : "2017-11-04 02:50:30 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926664684664651776,
  "created_at" : "2017-11-04 04:17:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JorFru",
      "screen_name" : "JorFru_",
      "indices" : [ 3, 11 ],
      "id_str" : "784788842733862912",
      "id" : 784788842733862912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/S6bfe8mlIC",
      "expanded_url" : "https:\/\/youtu.be\/i5i0SKQwOns",
      "display_url" : "youtu.be\/i5i0SKQwOns"
    } ]
  },
  "geo" : { },
  "id_str" : "926664560035155968",
  "text" : "RT @JorFru_: Tienes que ver esto\n\nhttps:\/\/t.co\/S6bfe8mlIC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/S6bfe8mlIC",
        "expanded_url" : "https:\/\/youtu.be\/i5i0SKQwOns",
        "display_url" : "youtu.be\/i5i0SKQwOns"
      } ]
    },
    "geo" : { },
    "id_str" : "925154112852905984",
    "text" : "Tienes que ver esto\n\nhttps:\/\/t.co\/S6bfe8mlIC",
    "id" : 925154112852905984,
    "created_at" : "2017-10-31 00:15:03 +0000",
    "user" : {
      "name" : "JorFru",
      "screen_name" : "JorFru_",
      "protected" : false,
      "id_str" : "784788842733862912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829449102656208898\/G6H2biio_normal.jpg",
      "id" : 784788842733862912,
      "verified" : false
    }
  },
  "id" : 926664560035155968,
  "created_at" : "2017-11-04 04:17:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JorFru",
      "screen_name" : "JorFru_",
      "indices" : [ 3, 11 ],
      "id_str" : "784788842733862912",
      "id" : 784788842733862912
    }, {
      "name" : "Maker Share",
      "screen_name" : "TheMakerShare",
      "indices" : [ 13, 27 ],
      "id_str" : "874412001086234624",
      "id" : 874412001086234624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/25aqLQD48a",
      "expanded_url" : "https:\/\/github.com\/UC3Music\/PolyTuna",
      "display_url" : "github.com\/UC3Music\/PolyT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926664415465926656",
  "text" : "RT @JorFru_: @TheMakerShare You also need a PolyTuna guitar tuner embedded, using your matrix of course https:\/\/t.co\/25aqLQD48a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maker Share",
        "screen_name" : "TheMakerShare",
        "indices" : [ 0, 14 ],
        "id_str" : "874412001086234624",
        "id" : 874412001086234624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/25aqLQD48a",
        "expanded_url" : "https:\/\/github.com\/UC3Music\/PolyTuna",
        "display_url" : "github.com\/UC3Music\/PolyT\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "926506008175788032",
    "geo" : { },
    "id_str" : "926596711644061697",
    "in_reply_to_user_id" : 874412001086234624,
    "text" : "@TheMakerShare You also need a PolyTuna guitar tuner embedded, using your matrix of course https:\/\/t.co\/25aqLQD48a",
    "id" : 926596711644061697,
    "in_reply_to_status_id" : 926506008175788032,
    "created_at" : "2017-11-03 23:47:26 +0000",
    "in_reply_to_screen_name" : "TheMakerShare",
    "in_reply_to_user_id_str" : "874412001086234624",
    "user" : {
      "name" : "JorFru",
      "screen_name" : "JorFru_",
      "protected" : false,
      "id_str" : "784788842733862912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829449102656208898\/G6H2biio_normal.jpg",
      "id" : 784788842733862912,
      "verified" : false
    }
  },
  "id" : 926664415465926656,
  "created_at" : "2017-11-04 04:16:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ZVA0W3SopX",
      "expanded_url" : "https:\/\/makezine.com\/2017\/11\/03\/ohio-organ-maker-founds-his-own-makerspace\/",
      "display_url" : "makezine.com\/2017\/11\/03\/ohi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926664344129167360",
  "text" : "RT @make: Looking for a little inspiration for starting your own makerspace? https:\/\/t.co\/ZVA0W3SopX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/ZVA0W3SopX",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/03\/ohio-organ-maker-founds-his-own-makerspace\/",
        "display_url" : "makezine.com\/2017\/11\/03\/ohi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926523663322681344",
    "text" : "Looking for a little inspiration for starting your own makerspace? https:\/\/t.co\/ZVA0W3SopX",
    "id" : 926523663322681344,
    "created_at" : "2017-11-03 18:57:09 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 926664344129167360,
  "created_at" : "2017-11-04 04:16:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/yJMde0VtuE",
      "expanded_url" : "https:\/\/makezine.com\/2017\/02\/06\/blacksmithing-basics\/",
      "display_url" : "makezine.com\/2017\/02\/06\/bla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926664041724030976",
  "text" : "RT @make: It's never a bad time to start getting into blacksmithing https:\/\/t.co\/yJMde0VtuE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/yJMde0VtuE",
        "expanded_url" : "https:\/\/makezine.com\/2017\/02\/06\/blacksmithing-basics\/",
        "display_url" : "makezine.com\/2017\/02\/06\/bla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926533228181315585",
    "text" : "It's never a bad time to start getting into blacksmithing https:\/\/t.co\/yJMde0VtuE",
    "id" : 926533228181315585,
    "created_at" : "2017-11-03 19:35:10 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 926664041724030976,
  "created_at" : "2017-11-04 04:14:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926663867207442433\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/gJ6P7hon9s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwr08lW4AA-Pil.jpg",
      "id_str" : "926663811947487232",
      "id" : 926663811947487232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwr08lW4AA-Pil.jpg",
      "sizes" : [ {
        "h" : 345,
        "resize" : "fit",
        "w" : 871
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 871
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 871
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/gJ6P7hon9s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926663867207442433",
  "text" : "South Koreans still use Dash &amp; Dash Pay alot though, and knew this for a while https:\/\/t.co\/gJ6P7hon9s",
  "id" : 926663867207442433,
  "created_at" : "2017-11-04 04:14:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926663561245577216\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/43xMa3z92I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwrkIsWsAEZjEq.jpg",
      "id_str" : "926663523140284417",
      "id" : 926663523140284417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwrkIsWsAEZjEq.jpg",
      "sizes" : [ {
        "h" : 580,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/43xMa3z92I"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926663561245577216\/photo\/1",
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/43xMa3z92I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwrkIrXUAATfbD.jpg",
      "id_str" : "926663523136131072",
      "id" : 926663523136131072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwrkIrXUAATfbD.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 1128
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 1128
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 1128
      } ],
      "display_url" : "pic.twitter.com\/43xMa3z92I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926663561245577216",
  "text" : "Dash is expected to be a slow recovery if it recovers. However with the crypto rise given the technical viotality, potential upsides as well https:\/\/t.co\/43xMa3z92I",
  "id" : 926663561245577216,
  "created_at" : "2017-11-04 04:13:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926662468541218822\/photo\/1",
      "indices" : [ 143, 166 ],
      "url" : "https:\/\/t.co\/uVda4Xz3gy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwqaDDXUAYNnBx.jpg",
      "id_str" : "926662250315862022",
      "id" : 926662250315862022,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwqaDDXUAYNnBx.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/uVda4Xz3gy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926662468541218822\/photo\/1",
      "indices" : [ 143, 166 ],
      "url" : "https:\/\/t.co\/uVda4Xz3gy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwqlOXX0AEVCw1.jpg",
      "id_str" : "926662442331131905",
      "id" : 926662442331131905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwqlOXX0AEVCw1.jpg",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 1197
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 1197
      } ],
      "display_url" : "pic.twitter.com\/uVda4Xz3gy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926662468541218822",
  "text" : "Dude $BTC is exploding in price, much MORE positive correlations expected as always w\/ the BTC monster. Even after BTC Gold fork &amp; updates https:\/\/t.co\/uVda4Xz3gy",
  "id" : 926662468541218822,
  "created_at" : "2017-11-04 04:08:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/T39cUXLMxO",
      "expanded_url" : "http:\/\/tcrn.ch\/2lM45fp",
      "display_url" : "tcrn.ch\/2lM45fp"
    } ]
  },
  "geo" : { },
  "id_str" : "926641493258964992",
  "text" : "RT @TechCrunch: Niantic acqui-hires Evertoon to add a social network to Pok\u00E9mon Go and other apps https:\/\/t.co\/T39cUXLMxO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/T39cUXLMxO",
        "expanded_url" : "http:\/\/tcrn.ch\/2lM45fp",
        "display_url" : "tcrn.ch\/2lM45fp"
      } ]
    },
    "geo" : { },
    "id_str" : "926619271165247488",
    "text" : "Niantic acqui-hires Evertoon to add a social network to Pok\u00E9mon Go and other apps https:\/\/t.co\/T39cUXLMxO",
    "id" : 926619271165247488,
    "created_at" : "2017-11-04 01:17:04 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879359733936701440\/sitcq7wY_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 926641493258964992,
  "created_at" : "2017-11-04 02:45:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    }, {
      "name" : "Onextrapixel",
      "screen_name" : "onextrapixel",
      "indices" : [ 100, 113 ],
      "id_str" : "29734071",
      "id" : 29734071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/HBV7zpwx8T",
      "expanded_url" : "http:\/\/depot.ly\/vkMq30ggQal",
      "display_url" : "depot.ly\/vkMq30ggQal"
    } ]
  },
  "geo" : { },
  "id_str" : "926641385729675264",
  "text" : "RT @DesignerDepot: Launching a Website: Your Complete Content Checklist https:\/\/t.co\/HBV7zpwx8T via @onextrapixel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Onextrapixel",
        "screen_name" : "onextrapixel",
        "indices" : [ 81, 94 ],
        "id_str" : "29734071",
        "id" : 29734071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/HBV7zpwx8T",
        "expanded_url" : "http:\/\/depot.ly\/vkMq30ggQal",
        "display_url" : "depot.ly\/vkMq30ggQal"
      } ]
    },
    "geo" : { },
    "id_str" : "925896507278143489",
    "text" : "Launching a Website: Your Complete Content Checklist https:\/\/t.co\/HBV7zpwx8T via @onextrapixel",
    "id" : 925896507278143489,
    "created_at" : "2017-11-02 01:25:04 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926641385729675264,
  "created_at" : "2017-11-04 02:44:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926641236752125952",
  "text" : "RT @ChemistryWorld: Could this be the first 2D material to contain completely planar octacoordinate transition metal atoms? https:\/\/t.co\/9a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/9aHKn2kss2",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/material-containing-perfectly-planar-octacoordinate-titanium-predicted\/3008232.article",
        "display_url" : "chemistryworld.com\/news\/material-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926478750686072832",
    "text" : "Could this be the first 2D material to contain completely planar octacoordinate transition metal atoms? https:\/\/t.co\/9aHKn2kss2",
    "id" : 926478750686072832,
    "created_at" : "2017-11-03 15:58:41 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 926641236752125952,
  "created_at" : "2017-11-04 02:44:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926641178925305857",
  "text" : "RT @ChemistryWorld: Found a spare $400,000 down the back of the couch? Why not buy Cyril Hinshelwood\u2019s 1956 chemistry Nobel prize medal? ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/fpIdVsV7mi",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/news\/hinshelwoods-1956-chemistry-nobel-prize-medal-to-be-auctioned\/3008228.article",
        "display_url" : "chemistryworld.com\/news\/hinshelwo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926535709757984770",
    "text" : "Found a spare $400,000 down the back of the couch? Why not buy Cyril Hinshelwood\u2019s 1956 chemistry Nobel prize medal? https:\/\/t.co\/fpIdVsV7mi",
    "id" : 926535709757984770,
    "created_at" : "2017-11-03 19:45:02 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 926641178925305857,
  "created_at" : "2017-11-04 02:44:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sandum",
      "screen_name" : "DavidSandum",
      "indices" : [ 3, 15 ],
      "id_str" : "35067421",
      "id" : 35067421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926641125246603265",
  "text" : "RT @DavidSandum: How do you like my new twitter header? It is one of my etchings with a mirror effect. A friend in Ireland did it :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926623032650665985",
    "text" : "How do you like my new twitter header? It is one of my etchings with a mirror effect. A friend in Ireland did it :)",
    "id" : 926623032650665985,
    "created_at" : "2017-11-04 01:32:01 +0000",
    "user" : {
      "name" : "David Sandum",
      "screen_name" : "DavidSandum",
      "protected" : false,
      "id_str" : "35067421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752883208186986496\/EgGWl5Me_normal.jpg",
      "id" : 35067421,
      "verified" : false
    }
  },
  "id" : 926641125246603265,
  "created_at" : "2017-11-04 02:43:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Saleh",
      "screen_name" : "Dude_Br0",
      "indices" : [ 3, 12 ],
      "id_str" : "255754440",
      "id" : 255754440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926641087111991296",
  "text" : "RT @Dude_Br0: Has Apple acknowledged this texting glitch yet? I\uFE0F don\u2019t get it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926528438415998976",
    "text" : "Has Apple acknowledged this texting glitch yet? I\uFE0F don\u2019t get it",
    "id" : 926528438415998976,
    "created_at" : "2017-11-03 19:16:08 +0000",
    "user" : {
      "name" : "A Saleh",
      "screen_name" : "Dude_Br0",
      "protected" : false,
      "id_str" : "255754440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419168211788369920\/g_bORQKe_normal.jpeg",
      "id" : 255754440,
      "verified" : false
    }
  },
  "id" : 926641087111991296,
  "created_at" : "2017-11-04 02:43:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/K3rxV3GhLX",
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/926630640841252864",
      "display_url" : "twitter.com\/engadget\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926641071383248896",
  "text" : "Yes! https:\/\/t.co\/K3rxV3GhLX",
  "id" : 926641071383248896,
  "created_at" : "2017-11-04 02:43:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/fmNV7dqubc",
      "expanded_url" : "http:\/\/ift.tt\/2A3TgYi",
      "display_url" : "ift.tt\/2A3TgYi"
    } ]
  },
  "geo" : { },
  "id_str" : "926640978580078594",
  "text" : "RT @dronepilots: US Central Command Scrambles to Field Electronic Anti-Drone Weapon | DronePilots - https:\/\/t.co\/fmNV7dqubc #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/fmNV7dqubc",
        "expanded_url" : "http:\/\/ift.tt\/2A3TgYi",
        "display_url" : "ift.tt\/2A3TgYi"
      } ]
    },
    "geo" : { },
    "id_str" : "926637863365693440",
    "text" : "US Central Command Scrambles to Field Electronic Anti-Drone Weapon | DronePilots - https:\/\/t.co\/fmNV7dqubc #drones",
    "id" : 926637863365693440,
    "created_at" : "2017-11-04 02:30:57 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926640978580078594,
  "created_at" : "2017-11-04 02:43:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/7tow6tcc9p",
      "expanded_url" : "http:\/\/engt.co\/2lO7NW1",
      "display_url" : "engt.co\/2lO7NW1"
    } ]
  },
  "geo" : { },
  "id_str" : "926640940479139845",
  "text" : "RT @engadget: Amazon reportedly eyeing a 'Lord of the Rings' TV series https:\/\/t.co\/7tow6tcc9p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/7tow6tcc9p",
        "expanded_url" : "http:\/\/engt.co\/2lO7NW1",
        "display_url" : "engt.co\/2lO7NW1"
      } ]
    },
    "geo" : { },
    "id_str" : "926632066766303233",
    "text" : "Amazon reportedly eyeing a 'Lord of the Rings' TV series https:\/\/t.co\/7tow6tcc9p",
    "id" : 926632066766303233,
    "created_at" : "2017-11-04 02:07:55 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926640940479139845,
  "created_at" : "2017-11-04 02:43:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Euth5PziV7",
      "expanded_url" : "http:\/\/depot.ly\/TIVs30gllFU",
      "display_url" : "depot.ly\/TIVs30gllFU"
    } ]
  },
  "geo" : { },
  "id_str" : "926640887073005568",
  "text" : "RT @DesignerDepot: 7 Design Challenges to Sharpen Your Skills https:\/\/t.co\/Euth5PziV7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Euth5PziV7",
        "expanded_url" : "http:\/\/depot.ly\/TIVs30gllFU",
        "display_url" : "depot.ly\/TIVs30gllFU"
      } ]
    },
    "geo" : { },
    "id_str" : "926640161508732930",
    "text" : "7 Design Challenges to Sharpen Your Skills https:\/\/t.co\/Euth5PziV7",
    "id" : 926640161508732930,
    "created_at" : "2017-11-04 02:40:05 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926640887073005568,
  "created_at" : "2017-11-04 02:42:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/Nd0exZCSq5",
      "expanded_url" : "https:\/\/twitter.com\/FractalDesignNA\/status\/926186634873397249",
      "display_url" : "twitter.com\/FractalDesignN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926640864209899520",
  "text" : "You need a case ASAP dude, lol https:\/\/t.co\/Nd0exZCSq5",
  "id" : 926640864209899520,
  "created_at" : "2017-11-04 02:42:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/9h6aGgg0Rw",
      "expanded_url" : "https:\/\/twitter.com\/DistLedger\/status\/926504546574262273",
      "display_url" : "twitter.com\/DistLedger\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926640701898620931",
  "text" : "StartHub anyone? AI automated marketing, strategized algorithmic analysis? https:\/\/t.co\/9h6aGgg0Rw",
  "id" : 926640701898620931,
  "created_at" : "2017-11-04 02:42:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bitcoin Magazine",
      "screen_name" : "BitcoinMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "361289499",
      "id" : 361289499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "BitcoinGold",
      "indices" : [ 66, 78 ]
    }, {
      "text" : "segwit2",
      "indices" : [ 122, 130 ]
    }, {
      "text" : "segwit",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/mP4crCEAAV",
      "expanded_url" : "https:\/\/bitcoinmagazine.com\/articles\/bitcoin-beginners-guide-surviving-bgold-and-segwit2x-forks\/",
      "display_url" : "bitcoinmagazine.com\/articles\/bitco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926640302701588480",
  "text" : "RT @BitcoinMagazine: A #Bitcoin Beginner\u2019s Guide to Surviving the #BitcoinGold and SegWit2x Forks https:\/\/t.co\/mP4crCEAAV #segwit2 #segwit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 2, 10 ]
      }, {
        "text" : "BitcoinGold",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "segwit2",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "segwit",
        "indices" : [ 110, 117 ]
      }, {
        "text" : "blockchain",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/mP4crCEAAV",
        "expanded_url" : "https:\/\/bitcoinmagazine.com\/articles\/bitcoin-beginners-guide-surviving-bgold-and-segwit2x-forks\/",
        "display_url" : "bitcoinmagazine.com\/articles\/bitco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918836916933537797",
    "text" : "A #Bitcoin Beginner\u2019s Guide to Surviving the #BitcoinGold and SegWit2x Forks https:\/\/t.co\/mP4crCEAAV #segwit2 #segwit #blockchain",
    "id" : 918836916933537797,
    "created_at" : "2017-10-13 13:52:46 +0000",
    "user" : {
      "name" : "Bitcoin Magazine",
      "screen_name" : "BitcoinMagazine",
      "protected" : false,
      "id_str" : "361289499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927697522583154688\/5UbrDpS7_normal.jpg",
      "id" : 361289499,
      "verified" : true
    }
  },
  "id" : 926640302701588480,
  "created_at" : "2017-11-04 02:40:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "status",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "dev",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "programming",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926639919858151425",
  "text" : "Need to switch Apache on the server to pure Python #status #dev #programming",
  "id" : 926639919858151425,
  "created_at" : "2017-11-04 02:39:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/4ul7sXkl93",
      "expanded_url" : "http:\/\/engt.co\/2lOEFO8",
      "display_url" : "engt.co\/2lOEFO8"
    } ]
  },
  "geo" : { },
  "id_str" : "926622485499596801",
  "text" : "RT @engadget: Ryder is adding 125 electric vans to its rental fleet https:\/\/t.co\/4ul7sXkl93",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/4ul7sXkl93",
        "expanded_url" : "http:\/\/engt.co\/2lOEFO8",
        "display_url" : "engt.co\/2lOEFO8"
      } ]
    },
    "geo" : { },
    "id_str" : "926614601629827073",
    "text" : "Ryder is adding 125 electric vans to its rental fleet https:\/\/t.co\/4ul7sXkl93",
    "id" : 926614601629827073,
    "created_at" : "2017-11-04 00:58:31 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926622485499596801,
  "created_at" : "2017-11-04 01:29:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926622414192173056",
  "text" : "$BTC is over $7k right now!",
  "id" : 926622414192173056,
  "created_at" : "2017-11-04 01:29:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SSD",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZhVgmcBax7",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/toms-hardware-community-roundup,31407.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/toms-hard\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926613179479875584",
  "text" : "RT @tomshardware: \u25B8 #SSD Giveaway And Community Gift Guides: Community Roundup https:\/\/t.co\/ZhVgmcBax7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SSD",
        "indices" : [ 2, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/ZhVgmcBax7",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/toms-hardware-community-roundup,31407.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/toms-hard\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926538237325148160",
    "text" : "\u25B8 #SSD Giveaway And Community Gift Guides: Community Roundup https:\/\/t.co\/ZhVgmcBax7",
    "id" : 926538237325148160,
    "created_at" : "2017-11-03 19:55:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926613179479875584,
  "created_at" : "2017-11-04 00:52:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/fSJNwPuF1Y",
      "expanded_url" : "http:\/\/ift.tt\/2xYJq9A",
      "display_url" : "ift.tt\/2xYJq9A"
    } ]
  },
  "geo" : { },
  "id_str" : "926612274663608320",
  "text" : "RT @dronepilots: Amazon's Latest Patent: Drones that Charge Vehicles | DronePilots - https:\/\/t.co\/fSJNwPuF1Y #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/fSJNwPuF1Y",
        "expanded_url" : "http:\/\/ift.tt\/2xYJq9A",
        "display_url" : "ift.tt\/2xYJq9A"
      } ]
    },
    "geo" : { },
    "id_str" : "926611302801387520",
    "text" : "Amazon's Latest Patent: Drones that Charge Vehicles | DronePilots - https:\/\/t.co\/fSJNwPuF1Y #drones",
    "id" : 926611302801387520,
    "created_at" : "2017-11-04 00:45:24 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926612274663608320,
  "created_at" : "2017-11-04 00:49:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Z. Nardi",
      "screen_name" : "willthethinker",
      "indices" : [ 3, 18 ],
      "id_str" : "725754026894184448",
      "id" : 725754026894184448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926612155293667330",
  "text" : "RT @willthethinker: \u201CHappiness is understanding and accepting the moments of tension and feeling gratitude when the tension resolves\u201D-@Flor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mfck",
        "screen_name" : "FlorganMack",
        "indices" : [ 114, 126 ],
        "id_str" : "1177437698",
        "id" : 1177437698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926463870931210240",
    "text" : "\u201CHappiness is understanding and accepting the moments of tension and feeling gratitude when the tension resolves\u201D-@FlorganMack",
    "id" : 926463870931210240,
    "created_at" : "2017-11-03 14:59:34 +0000",
    "user" : {
      "name" : "William Z. Nardi",
      "screen_name" : "willthethinker",
      "protected" : false,
      "id_str" : "725754026894184448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/913815903837605893\/466Xtu7J_normal.jpg",
      "id" : 725754026894184448,
      "verified" : false
    }
  },
  "id" : 926612155293667330,
  "created_at" : "2017-11-04 00:48:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Rouser",
      "screen_name" : "RouserNews",
      "indices" : [ 3, 14 ],
      "id_str" : "755485620110299136",
      "id" : 755485620110299136
    }, {
      "name" : "Jessica Hughes",
      "screen_name" : "Just___Jess99",
      "indices" : [ 21, 35 ],
      "id_str" : "2311222284",
      "id" : 2311222284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/pP4rJsGmAC",
      "expanded_url" : "https:\/\/rousernews.com\/2017\/11\/02\/i-speak-for-michigan\/",
      "display_url" : "rousernews.com\/2017\/11\/02\/i-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926612027702988805",
  "text" : "RT @RouserNews: Read @Just___Jess99\u2019s article on importance of preserving Michigan\u2019s beautiful environment. https:\/\/t.co\/pP4rJsGmAC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jessica Hughes",
        "screen_name" : "Just___Jess99",
        "indices" : [ 5, 19 ],
        "id_str" : "2311222284",
        "id" : 2311222284
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/pP4rJsGmAC",
        "expanded_url" : "https:\/\/rousernews.com\/2017\/11\/02\/i-speak-for-michigan\/",
        "display_url" : "rousernews.com\/2017\/11\/02\/i-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926297531822297091",
    "text" : "Read @Just___Jess99\u2019s article on importance of preserving Michigan\u2019s beautiful environment. https:\/\/t.co\/pP4rJsGmAC",
    "id" : 926297531822297091,
    "created_at" : "2017-11-03 03:58:36 +0000",
    "user" : {
      "name" : "The Rouser",
      "screen_name" : "RouserNews",
      "protected" : false,
      "id_str" : "755485620110299136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830983497531678720\/hJkKcBRO_normal.jpg",
      "id" : 755485620110299136,
      "verified" : false
    }
  },
  "id" : 926612027702988805,
  "created_at" : "2017-11-04 00:48:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/YDlf5omb51",
      "expanded_url" : "http:\/\/ift.tt\/2zhUmCw",
      "display_url" : "ift.tt\/2zhUmCw"
    } ]
  },
  "geo" : { },
  "id_str" : "926611979179094016",
  "text" : "RT @dronepilots: Start-up Company Pioneers Small SIGINT Sensors For UAVs | DronePilots - https:\/\/t.co\/YDlf5omb51 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/YDlf5omb51",
        "expanded_url" : "http:\/\/ift.tt\/2zhUmCw",
        "display_url" : "ift.tt\/2zhUmCw"
      } ]
    },
    "geo" : { },
    "id_str" : "926611292282150912",
    "text" : "Start-up Company Pioneers Small SIGINT Sensors For UAVs | DronePilots - https:\/\/t.co\/YDlf5omb51 #drones",
    "id" : 926611292282150912,
    "created_at" : "2017-11-04 00:45:22 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926611979179094016,
  "created_at" : "2017-11-04 00:48:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926611697560940545",
  "text" : "Life is tough sometimes but people are dealing with worse. Hold on when things aren't looking the best &amp; all I can say is must have hope.",
  "id" : 926611697560940545,
  "created_at" : "2017-11-04 00:46:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yesenia Perez-Cruz",
      "screen_name" : "yeseniaa",
      "indices" : [ 3, 12 ],
      "id_str" : "19042148",
      "id" : 19042148
    }, {
      "name" : "Sanette Tanaka",
      "screen_name" : "ssktanaka",
      "indices" : [ 90, 100 ],
      "id_str" : "170034527",
      "id" : 170034527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926609744378331138",
  "text" : "RT @yeseniaa: Take something frustrating, write about what you learned, share it. \u2714\uFE0F\nLove @ssktanaka's approach with this piece. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sanette Tanaka",
        "screen_name" : "ssktanaka",
        "indices" : [ 76, 86 ],
        "id_str" : "170034527",
        "id" : 170034527
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/XXw78Rg5aR",
        "expanded_url" : "https:\/\/product.voxmedia.com\/2017\/11\/1\/16562200\/a-highly-subjective-guide-to-design-prototyping-tools",
        "display_url" : "product.voxmedia.com\/2017\/11\/1\/1656\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926150497186217985",
    "text" : "Take something frustrating, write about what you learned, share it. \u2714\uFE0F\nLove @ssktanaka's approach with this piece. https:\/\/t.co\/XXw78Rg5aR",
    "id" : 926150497186217985,
    "created_at" : "2017-11-02 18:14:20 +0000",
    "user" : {
      "name" : "Yesenia Perez-Cruz",
      "screen_name" : "yeseniaa",
      "protected" : false,
      "id_str" : "19042148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881260045526343684\/nyQ23BxU_normal.jpg",
      "id" : 19042148,
      "verified" : false
    }
  },
  "id" : 926609744378331138,
  "created_at" : "2017-11-04 00:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UX",
      "indices" : [ 41, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/irKQzo4Wsn",
      "expanded_url" : "http:\/\/depot.ly\/sPyq30giDnk",
      "display_url" : "depot.ly\/sPyq30giDnk"
    } ]
  },
  "geo" : { },
  "id_str" : "926609660639096832",
  "text" : "RT @DesignerDepot: 5 Ways to Improve the #UX of Site Search https:\/\/t.co\/irKQzo4Wsn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UX",
        "indices" : [ 22, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/irKQzo4Wsn",
        "expanded_url" : "http:\/\/depot.ly\/sPyq30giDnk",
        "display_url" : "depot.ly\/sPyq30giDnk"
      } ]
    },
    "geo" : { },
    "id_str" : "926109323511640065",
    "text" : "5 Ways to Improve the #UX of Site Search https:\/\/t.co\/irKQzo4Wsn",
    "id" : 926109323511640065,
    "created_at" : "2017-11-02 15:30:43 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926609660639096832,
  "created_at" : "2017-11-04 00:38:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    }, {
      "name" : "freeCodeCamp",
      "screen_name" : "freeCodeCamp",
      "indices" : [ 104, 117 ],
      "id_str" : "1668100142",
      "id" : 1668100142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/dcMUCx3cMu",
      "expanded_url" : "http:\/\/depot.ly\/Z3RL30glnMW",
      "display_url" : "depot.ly\/Z3RL30glnMW"
    } ]
  },
  "geo" : { },
  "id_str" : "926609612337541120",
  "text" : "RT @DesignerDepot: What\u2019s the difference between JavaScript and ECMAScript? https:\/\/t.co\/dcMUCx3cMu via @freeCodeCamp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "freeCodeCamp",
        "screen_name" : "freeCodeCamp",
        "indices" : [ 85, 98 ],
        "id_str" : "1668100142",
        "id" : 1668100142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/dcMUCx3cMu",
        "expanded_url" : "http:\/\/depot.ly\/Z3RL30glnMW",
        "display_url" : "depot.ly\/Z3RL30glnMW"
      } ]
    },
    "geo" : { },
    "id_str" : "926578516707160065",
    "text" : "What\u2019s the difference between JavaScript and ECMAScript? https:\/\/t.co\/dcMUCx3cMu via @freeCodeCamp",
    "id" : 926578516707160065,
    "created_at" : "2017-11-03 22:35:08 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 926609612337541120,
  "created_at" : "2017-11-04 00:38:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "LSU",
      "screen_name" : "lsu",
      "indices" : [ 114, 118 ],
      "id_str" : "44156044",
      "id" : 44156044
    }, {
      "name" : "Physical Review Lett",
      "screen_name" : "PhysRevLett",
      "indices" : [ 119, 131 ],
      "id_str" : "3039504459",
      "id" : 3039504459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/prbVYDi6KP",
      "expanded_url" : "http:\/\/phy.so\/428924997",
      "display_url" : "phy.so\/428924997"
    } ]
  },
  "geo" : { },
  "id_str" : "926609560147808257",
  "text" : "RT @physorg_com: CALET makes first direct measurements of high #energy electrons in space https:\/\/t.co\/prbVYDi6KP @lsu @physrevlett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LSU",
        "screen_name" : "lsu",
        "indices" : [ 97, 101 ],
        "id_str" : "44156044",
        "id" : 44156044
      }, {
        "name" : "Physical Review Lett",
        "screen_name" : "PhysRevLett",
        "indices" : [ 102, 114 ],
        "id_str" : "3039504459",
        "id" : 3039504459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 46, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/prbVYDi6KP",
        "expanded_url" : "http:\/\/phy.so\/428924997",
        "display_url" : "phy.so\/428924997"
      } ]
    },
    "geo" : { },
    "id_str" : "926461493255733248",
    "text" : "CALET makes first direct measurements of high #energy electrons in space https:\/\/t.co\/prbVYDi6KP @lsu @physrevlett",
    "id" : 926461493255733248,
    "created_at" : "2017-11-03 14:50:07 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 926609560147808257,
  "created_at" : "2017-11-04 00:38:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/SbwQNZQi02",
      "expanded_url" : "http:\/\/plrsig.ht\/2xmVf8v",
      "display_url" : "plrsig.ht\/2xmVf8v"
    } ]
  },
  "geo" : { },
  "id_str" : "926609249966477322",
  "text" : "RT @pluralsight: A bimodal approach to IT doesn't work anymore. Here's what does work and why: https:\/\/t.co\/SbwQNZQi02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/SbwQNZQi02",
        "expanded_url" : "http:\/\/plrsig.ht\/2xmVf8v",
        "display_url" : "plrsig.ht\/2xmVf8v"
      } ]
    },
    "geo" : { },
    "id_str" : "926602898368233472",
    "text" : "A bimodal approach to IT doesn't work anymore. Here's what does work and why: https:\/\/t.co\/SbwQNZQi02",
    "id" : 926602898368233472,
    "created_at" : "2017-11-04 00:12:01 +0000",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908381030821675009\/nOwJrmgq_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 926609249966477322,
  "created_at" : "2017-11-04 00:37:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/xtLYrO7BvR",
      "expanded_url" : "http:\/\/www.dpreview.com\/news\/5597491783\/hasselblad-unveils-135mm-f2-8-for-x1d-promises-80mm-with-fastest-aperture-yet",
      "display_url" : "dpreview.com\/news\/559749178\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926609129023639560",
  "text" : "RT @JayHoque: Hasselblad unveils 135mm F2.8 for X1D, promises 80mm with fastest aperture yet: https:\/\/t.co\/xtLYrO7BvR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/xtLYrO7BvR",
        "expanded_url" : "http:\/\/www.dpreview.com\/news\/5597491783\/hasselblad-unveils-135mm-f2-8-for-x1d-promises-80mm-with-fastest-aperture-yet",
        "display_url" : "dpreview.com\/news\/559749178\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926481886649749504",
    "text" : "Hasselblad unveils 135mm F2.8 for X1D, promises 80mm with fastest aperture yet: https:\/\/t.co\/xtLYrO7BvR",
    "id" : 926481886649749504,
    "created_at" : "2017-11-03 16:11:09 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926609129023639560,
  "created_at" : "2017-11-04 00:36:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926609100636598272",
  "text" : "RT @ChemistryWorld: The life and research of Marie Curie, a migrant chemist whose work has inspired generations of scientists https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/8v4EsBwIf1",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/feature\/marie-curie-the-migrant-chemist\/3008087.article",
        "display_url" : "chemistryworld.com\/feature\/marie-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926455180937310208",
    "text" : "The life and research of Marie Curie, a migrant chemist whose work has inspired generations of scientists https:\/\/t.co\/8v4EsBwIf1",
    "id" : 926455180937310208,
    "created_at" : "2017-11-03 14:25:02 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 926609100636598272,
  "created_at" : "2017-11-04 00:36:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/2N7vYvlqYu",
      "expanded_url" : "http:\/\/ift.tt\/2xZ5BfL",
      "display_url" : "ift.tt\/2xZ5BfL"
    } ]
  },
  "geo" : { },
  "id_str" : "926609038569299969",
  "text" : "RT @dronepilots: WSU student uses drone to help people after Hurricane Harvey | DronePilots - https:\/\/t.co\/2N7vYvlqYu #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/2N7vYvlqYu",
        "expanded_url" : "http:\/\/ift.tt\/2xZ5BfL",
        "display_url" : "ift.tt\/2xZ5BfL"
      } ]
    },
    "geo" : { },
    "id_str" : "926602491877298176",
    "text" : "WSU student uses drone to help people after Hurricane Harvey | DronePilots - https:\/\/t.co\/2N7vYvlqYu #drones",
    "id" : 926602491877298176,
    "created_at" : "2017-11-04 00:10:24 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926609038569299969,
  "created_at" : "2017-11-04 00:36:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tomshardware\/status\/926460508928176129\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9TL25qLKTt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNty1qtXUAABSZD.png",
      "id_str" : "926460414677962752",
      "id" : 926460414677962752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNty1qtXUAABSZD.png",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/9TL25qLKTt"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/tomshardware\/status\/926460508928176129\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9TL25qLKTt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNty2_yXkAAuePJ.jpg",
      "id_str" : "926460437515964416",
      "id" : 926460437515964416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNty2_yXkAAuePJ.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/9TL25qLKTt"
    } ],
    "hashtags" : [ {
      "text" : "FridayFeeling",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926609015609741313",
  "text" : "RT @tomshardware: #FridayFeeling You Vs The guy she says you shouldn't worry about. https:\/\/t.co\/9TL25qLKTt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tomshardware\/status\/926460508928176129\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/9TL25qLKTt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNty1qtXUAABSZD.png",
        "id_str" : "926460414677962752",
        "id" : 926460414677962752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNty1qtXUAABSZD.png",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/9TL25qLKTt"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/tomshardware\/status\/926460508928176129\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/9TL25qLKTt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNty2_yXkAAuePJ.jpg",
        "id_str" : "926460437515964416",
        "id" : 926460437515964416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNty2_yXkAAuePJ.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/9TL25qLKTt"
      } ],
      "hashtags" : [ {
        "text" : "FridayFeeling",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926460508928176129",
    "text" : "#FridayFeeling You Vs The guy she says you shouldn't worry about. https:\/\/t.co\/9TL25qLKTt",
    "id" : 926460508928176129,
    "created_at" : "2017-11-03 14:46:12 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926609015609741313,
  "created_at" : "2017-11-04 00:36:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926608964439113728\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/IW4eGPARhq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNv571xXkAA9fou.jpg",
      "id_str" : "926608954796511232",
      "id" : 926608954796511232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNv571xXkAA9fou.jpg",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 681
      } ],
      "display_url" : "pic.twitter.com\/IW4eGPARhq"
    } ],
    "hashtags" : [ {
      "text" : "code",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "dev",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926608964439113728",
  "text" : "Now using PostMan #code #dev https:\/\/t.co\/IW4eGPARhq",
  "id" : 926608964439113728,
  "created_at" : "2017-11-04 00:36:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hearthstone",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/08HQAWInwP",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/hearthstone-kobolds-and-catacombs-expansion-blizzcon-2017,35840.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/hearthsto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926553556852846595",
  "text" : "RT @tomshardware: \u25B8 '#Hearthstone' Gets New 'Kobolds &amp; Catacombs' Expansion, Single-Player Mode https:\/\/t.co\/08HQAWInwP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hearthstone",
        "indices" : [ 3, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/08HQAWInwP",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/hearthstone-kobolds-and-catacombs-expansion-blizzcon-2017,35840.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/hearthsto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926541758359412736",
    "text" : "\u25B8 '#Hearthstone' Gets New 'Kobolds &amp; Catacombs' Expansion, Single-Player Mode https:\/\/t.co\/08HQAWInwP",
    "id" : 926541758359412736,
    "created_at" : "2017-11-03 20:09:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926553556852846595,
  "created_at" : "2017-11-03 20:55:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926553532857274368",
  "text" : "RT @BarbaraCorcoran: Leaders come in two flavors, expanders and containers. The best leadership teams have a mix of both.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926526960121065477",
    "text" : "Leaders come in two flavors, expanders and containers. The best leadership teams have a mix of both.",
    "id" : 926526960121065477,
    "created_at" : "2017-11-03 19:10:15 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926553532857274368,
  "created_at" : "2017-11-03 20:55:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ijXwR5dZTJ",
      "expanded_url" : "http:\/\/engt.co\/2lNKviQ",
      "display_url" : "engt.co\/2lNKviQ"
    } ]
  },
  "geo" : { },
  "id_str" : "926553507095826432",
  "text" : "RT @engadget: Apple says 'tears of joy' face is the most-used emoji https:\/\/t.co\/ijXwR5dZTJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/ijXwR5dZTJ",
        "expanded_url" : "http:\/\/engt.co\/2lNKviQ",
        "display_url" : "engt.co\/2lNKviQ"
      } ]
    },
    "geo" : { },
    "id_str" : "926530193455505409",
    "text" : "Apple says 'tears of joy' face is the most-used emoji https:\/\/t.co\/ijXwR5dZTJ",
    "id" : 926530193455505409,
    "created_at" : "2017-11-03 19:23:06 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926553507095826432,
  "created_at" : "2017-11-03 20:55:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/8VyQ771NBT",
      "expanded_url" : "http:\/\/www.dpreview.com\/news\/4684396697\/positano-italy-will-start-charing-1-150-fee-for-commercial-photography-2-300-for-video",
      "display_url" : "dpreview.com\/news\/468439669\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926553473256181762",
  "text" : "RT @JayHoque: Positano, Italy will start charging $1,150 fee for commercial photography, $2,300 for video: https:\/\/t.co\/8VyQ771NBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/8VyQ771NBT",
        "expanded_url" : "http:\/\/www.dpreview.com\/news\/4684396697\/positano-italy-will-start-charing-1-150-fee-for-commercial-photography-2-300-for-video",
        "display_url" : "dpreview.com\/news\/468439669\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926547398683516929",
    "text" : "Positano, Italy will start charging $1,150 fee for commercial photography, $2,300 for video: https:\/\/t.co\/8VyQ771NBT",
    "id" : 926547398683516929,
    "created_at" : "2017-11-03 20:31:28 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926553473256181762,
  "created_at" : "2017-11-03 20:55:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926553447750688768",
  "text" : "RT @BarbaraCorcoran: Over the years I've developed huge muscles in my brain and my body to stand back up and take another shot!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926477881697619968",
    "text" : "Over the years I've developed huge muscles in my brain and my body to stand back up and take another shot!",
    "id" : 926477881697619968,
    "created_at" : "2017-11-03 15:55:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926553447750688768,
  "created_at" : "2017-11-03 20:55:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926553413910958080",
  "text" : "Stressful work day, but getting through this",
  "id" : 926553413910958080,
  "created_at" : "2017-11-03 20:55:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "indices" : [ 3, 14 ],
      "id_str" : "36912323",
      "id" : 36912323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/eVdSYxRcUW",
      "expanded_url" : "http:\/\/feeds.mashable.com\/~r\/Mashable\/~3\/YSU_5jOOTNE\/",
      "display_url" : "feeds.mashable.com\/~r\/Mashable\/~3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926329482235056128",
  "text" : "RT @grattonboy: Inside Xbox's sleepover pop-up, where gamers can play all night long https:\/\/t.co\/eVdSYxRcUW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/eVdSYxRcUW",
        "expanded_url" : "http:\/\/feeds.mashable.com\/~r\/Mashable\/~3\/YSU_5jOOTNE\/",
        "display_url" : "feeds.mashable.com\/~r\/Mashable\/~3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926328774060322816",
    "text" : "Inside Xbox's sleepover pop-up, where gamers can play all night long https:\/\/t.co\/eVdSYxRcUW",
    "id" : 926328774060322816,
    "created_at" : "2017-11-03 06:02:44 +0000",
    "user" : {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "protected" : false,
      "id_str" : "36912323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819521494371934208\/8cPchIQ-_normal.jpg",
      "id" : 36912323,
      "verified" : true
    }
  },
  "id" : 926329482235056128,
  "created_at" : "2017-11-03 06:05:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/mGrgYIAz0d",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/silverstone-ad120-t-adapter-laptops-sff-pcs,35830.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/silversto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926314736207187968",
  "text" : "RT @tomshardware: \u25B8 SilverStone Releases A 120W AC Adapter For Laptops And SFF PCs https:\/\/t.co\/mGrgYIAz0d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/mGrgYIAz0d",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/silverstone-ad120-t-adapter-laptops-sff-pcs,35830.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/silversto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926223668681703424",
    "text" : "\u25B8 SilverStone Releases A 120W AC Adapter For Laptops And SFF PCs https:\/\/t.co\/mGrgYIAz0d",
    "id" : 926223668681703424,
    "created_at" : "2017-11-02 23:05:05 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926314736207187968,
  "created_at" : "2017-11-03 05:06:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "giffgaff",
      "screen_name" : "giffgaff",
      "indices" : [ 3, 12 ],
      "id_str" : "29484376",
      "id" : 29484376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926313443099070464",
  "text" : "RT @giffgaff: Even the strongest relationships are tested by a cold night and a thermostat. Let the central heating debate begin.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926184649231077379",
    "text" : "Even the strongest relationships are tested by a cold night and a thermostat. Let the central heating debate begin.",
    "id" : 926184649231077379,
    "created_at" : "2017-11-02 20:30:02 +0000",
    "user" : {
      "name" : "giffgaff",
      "screen_name" : "giffgaff",
      "protected" : false,
      "id_str" : "29484376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925684195367800832\/hVCuT2bU_normal.jpg",
      "id" : 29484376,
      "verified" : true
    }
  },
  "id" : 926313443099070464,
  "created_at" : "2017-11-03 05:01:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/wfMQ3IyNlB",
      "expanded_url" : "https:\/\/twitter.com\/Razer\/status\/926162010449969153",
      "display_url" : "twitter.com\/Razer\/status\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926312064980832257",
  "text" : "Oh my goodness https:\/\/t.co\/wfMQ3IyNlB",
  "id" : 926312064980832257,
  "created_at" : "2017-11-03 04:56:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AutoGrind",
      "screen_name" : "grindlabs",
      "indices" : [ 3, 13 ],
      "id_str" : "770095848457900034",
      "id" : 770095848457900034
    }, {
      "name" : "Antonio Sosa",
      "screen_name" : "4kSosa",
      "indices" : [ 15, 22 ],
      "id_str" : "805932926831652866",
      "id" : 805932926831652866
    }, {
      "name" : "R\u039BZ\u039ER",
      "screen_name" : "Razer",
      "indices" : [ 23, 29 ],
      "id_str" : "15880163",
      "id" : 15880163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926312012862377984",
  "text" : "RT @grindlabs: @4kSosa @Razer They made the Razer Edge a few years ago with Windows 8. Not as good of a screen tho.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Antonio Sosa",
        "screen_name" : "4kSosa",
        "indices" : [ 0, 7 ],
        "id_str" : "805932926831652866",
        "id" : 805932926831652866
      }, {
        "name" : "R\u039BZ\u039ER",
        "screen_name" : "Razer",
        "indices" : [ 8, 14 ],
        "id_str" : "15880163",
        "id" : 15880163
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926263542969458688",
    "geo" : { },
    "id_str" : "926283786085642240",
    "in_reply_to_user_id" : 805932926831652866,
    "text" : "@4kSosa @Razer They made the Razer Edge a few years ago with Windows 8. Not as good of a screen tho.",
    "id" : 926283786085642240,
    "in_reply_to_status_id" : 926263542969458688,
    "created_at" : "2017-11-03 03:03:58 +0000",
    "in_reply_to_screen_name" : "4kSosa",
    "in_reply_to_user_id_str" : "805932926831652866",
    "user" : {
      "name" : "AutoGrind",
      "screen_name" : "grindlabs",
      "protected" : false,
      "id_str" : "770095848457900034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903972258938531840\/zI2tLiDd_normal.jpg",
      "id" : 770095848457900034,
      "verified" : false
    }
  },
  "id" : 926312012862377984,
  "created_at" : "2017-11-03 04:56:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/ak1jpWeaP6",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/03\/first-impressions-fujifilm-gf-23mm-f4-r-wr\/",
      "display_url" : "thephoblographer.com\/2017\/11\/03\/fir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926308054139920390",
  "text" : "RT @JayHoque: First Impressions: Fujifilm GF 23mm F4 R WR: https:\/\/t.co\/ak1jpWeaP6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/ak1jpWeaP6",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/03\/first-impressions-fujifilm-gf-23mm-f4-r-wr\/",
        "display_url" : "thephoblographer.com\/2017\/11\/03\/fir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926307015353348096",
    "text" : "First Impressions: Fujifilm GF 23mm F4 R WR: https:\/\/t.co\/ak1jpWeaP6",
    "id" : 926307015353348096,
    "created_at" : "2017-11-03 04:36:17 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926308054139920390,
  "created_at" : "2017-11-03 04:40:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/cX0BWxcuBz",
      "expanded_url" : "http:\/\/www.howtocookhero.com\/homemade-french-fries\/",
      "display_url" : "howtocookhero.com\/homemade-frenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926308019494883328",
  "text" : "I think this is what Gramps used to do: https:\/\/t.co\/cX0BWxcuBz",
  "id" : 926308019494883328,
  "created_at" : "2017-11-03 04:40:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "progress",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926290027776274433",
  "text" : "RT @JayHoque: Attitude is everything.  \"Knowledge is power, but enthusiasm pulls the switch.\" Ivern Ball #progress",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nimblequotes.com\/\" rel=\"nofollow\"\u003ENimble Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "progress",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925980813245661185",
    "text" : "Attitude is everything.  \"Knowledge is power, but enthusiasm pulls the switch.\" Ivern Ball #progress",
    "id" : 925980813245661185,
    "created_at" : "2017-11-02 07:00:04 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926290027776274433,
  "created_at" : "2017-11-03 03:28:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/pJlXNPTFj9",
      "expanded_url" : "https:\/\/twitter.com\/AlArabiya_Eng\/status\/925014435550306305",
      "display_url" : "twitter.com\/AlArabiya_Eng\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926288881430999040",
  "text" : "Absolutely wrong and disgusting. https:\/\/t.co\/pJlXNPTFj9",
  "id" : 926288881430999040,
  "created_at" : "2017-11-03 03:24:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 3, 10 ],
      "id_str" : "64643056",
      "id" : 64643056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egyptian",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/WfIJtktSkh",
      "expanded_url" : "https:\/\/on.rt.com\/8r94",
      "display_url" : "on.rt.com\/8r94"
    } ]
  },
  "geo" : { },
  "id_str" : "926286089194745856",
  "text" : "RT @RT_com: Mysterious giant chamber found inside #Egyptian pyramid https:\/\/t.co\/WfIJtktSkh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egyptian",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/WfIJtktSkh",
        "expanded_url" : "https:\/\/on.rt.com\/8r94",
        "display_url" : "on.rt.com\/8r94"
      } ]
    },
    "geo" : { },
    "id_str" : "926207302746755072",
    "text" : "Mysterious giant chamber found inside #Egyptian pyramid https:\/\/t.co\/WfIJtktSkh",
    "id" : 926207302746755072,
    "created_at" : "2017-11-02 22:00:03 +0000",
    "user" : {
      "name" : "RT",
      "screen_name" : "RT_com",
      "protected" : false,
      "id_str" : "64643056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875388705258831872\/H4_uLagc_normal.jpg",
      "id" : 64643056,
      "verified" : true
    }
  },
  "id" : 926286089194745856,
  "created_at" : "2017-11-03 03:13:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 3, 14 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/m5zxZiHSwO",
      "expanded_url" : "http:\/\/dailym.ai\/2zZJyX0",
      "display_url" : "dailym.ai\/2zZJyX0"
    } ]
  },
  "geo" : { },
  "id_str" : "926286071515828229",
  "text" : "RT @MailOnline: 2,000-year old child mummy from Egypt is revealed in incredible detail using 3D scanning https:\/\/t.co\/m5zxZiHSwO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/m5zxZiHSwO",
        "expanded_url" : "http:\/\/dailym.ai\/2zZJyX0",
        "display_url" : "dailym.ai\/2zZJyX0"
      } ]
    },
    "geo" : { },
    "id_str" : "926278020490498048",
    "text" : "2,000-year old child mummy from Egypt is revealed in incredible detail using 3D scanning https:\/\/t.co\/m5zxZiHSwO",
    "id" : 926278020490498048,
    "created_at" : "2017-11-03 02:41:04 +0000",
    "user" : {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "protected" : false,
      "id_str" : "15438913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907912182523981824\/3vkEVuHh_normal.jpg",
      "id" : 15438913,
      "verified" : true
    }
  },
  "id" : 926286071515828229,
  "created_at" : "2017-11-03 03:13:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egyptian",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926286002125144065",
  "text" : "Labneh is one of the best cheeses #Egyptian",
  "id" : 926286002125144065,
  "created_at" : "2017-11-03 03:12:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunner Gomez",
      "screen_name" : "GunGomz",
      "indices" : [ 3, 11 ],
      "id_str" : "3072090042",
      "id" : 3072090042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926274316236476416",
  "text" : "RT @GunGomz: These screaming bird memes have to be the best thing that has happened to the internet in a while.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "922501352894349312",
    "text" : "These screaming bird memes have to be the best thing that has happened to the internet in a while.",
    "id" : 922501352894349312,
    "created_at" : "2017-10-23 16:33:56 +0000",
    "user" : {
      "name" : "Gunner Gomez",
      "screen_name" : "GunGomz",
      "protected" : false,
      "id_str" : "3072090042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916101918006534144\/WLs6R0cT_normal.jpg",
      "id" : 3072090042,
      "verified" : false
    }
  },
  "id" : 926274316236476416,
  "created_at" : "2017-11-03 02:26:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "particles",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/YdMGuFMh6y",
      "expanded_url" : "http:\/\/phy.so\/428850794",
      "display_url" : "phy.so\/428850794"
    } ]
  },
  "geo" : { },
  "id_str" : "926273851947995137",
  "text" : "RT @physorg_com: Physicists show how lifeless #particles can become 'life-like' by switching behaviors https:\/\/t.co\/YdMGuFMh6y @EmoryUniver\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emory University",
        "screen_name" : "EmoryUniversity",
        "indices" : [ 110, 126 ],
        "id_str" : "16438655",
        "id" : 16438655
      }, {
        "name" : "Physical Review Lett",
        "screen_name" : "PhysRevLett",
        "indices" : [ 127, 139 ],
        "id_str" : "3039504459",
        "id" : 3039504459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "particles",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/YdMGuFMh6y",
        "expanded_url" : "http:\/\/phy.so\/428850794",
        "display_url" : "phy.so\/428850794"
      } ]
    },
    "geo" : { },
    "id_str" : "926150286439337984",
    "text" : "Physicists show how lifeless #particles can become 'life-like' by switching behaviors https:\/\/t.co\/YdMGuFMh6y @EmoryUniversity @physrevlett",
    "id" : 926150286439337984,
    "created_at" : "2017-11-02 18:13:29 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 926273851947995137,
  "created_at" : "2017-11-03 02:24:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Del Moro",
      "screen_name" : "MikeDelMoro",
      "indices" : [ 3, 15 ],
      "id_str" : "31059230",
      "id" : 31059230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926273401148399618",
  "text" : "RT @MikeDelMoro: Oh wow... Twitter confirms the deactivation of the President's account was an employee \"who did this on the employee\u2019s las\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926269021665812482",
    "text" : "Oh wow... Twitter confirms the deactivation of the President's account was an employee \"who did this on the employee\u2019s last day\"",
    "id" : 926269021665812482,
    "created_at" : "2017-11-03 02:05:18 +0000",
    "user" : {
      "name" : "Michael Del Moro",
      "screen_name" : "MikeDelMoro",
      "protected" : false,
      "id_str" : "31059230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718185950891896832\/Qzap0pFq_normal.jpg",
      "id" : 31059230,
      "verified" : true
    }
  },
  "id" : 926273401148399618,
  "created_at" : "2017-11-03 02:22:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsILearnedInCollege",
      "indices" : [ 86, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926273116199903234",
  "text" : "RT @KassyDillon: The more bumper and laptop stickers you have, the more woke you are. #ThingsILearnedInCollege",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsILearnedInCollege",
        "indices" : [ 69, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926272787215536128",
    "text" : "The more bumper and laptop stickers you have, the more woke you are. #ThingsILearnedInCollege",
    "id" : 926272787215536128,
    "created_at" : "2017-11-03 02:20:16 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924765802456408064\/-jL6Yg2a_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 926273116199903234,
  "created_at" : "2017-11-03 02:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926273083073269761",
  "text" : "In other news chain data started synchronizing well after switched to being able to run Python 2.7 on CentOS 6",
  "id" : 926273083073269761,
  "created_at" : "2017-11-03 02:21:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926272938789232640",
  "text" : "My life has too much drama, not supposed to be a soap opera at this age",
  "id" : 926272938789232640,
  "created_at" : "2017-11-03 02:20:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u216Figuel N. P.",
      "screen_name" : "LTEstyles",
      "indices" : [ 3, 13 ],
      "id_str" : "113229899",
      "id" : 113229899
    }, {
      "name" : "Jon Prosser",
      "screen_name" : "jon_prosser",
      "indices" : [ 15, 27 ],
      "id_str" : "106542971",
      "id" : 106542971
    }, {
      "name" : "R\u039BZ\u039ER @ BlizzCon",
      "screen_name" : "Razer",
      "indices" : [ 28, 34 ],
      "id_str" : "15880163",
      "id" : 15880163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926242808620601344",
  "text" : "RT @LTEstyles: @jon_prosser @Razer I think it's cool too! I like that design language a lot more than infinity displays which is why I boug\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Prosser",
        "screen_name" : "jon_prosser",
        "indices" : [ 0, 12 ],
        "id_str" : "106542971",
        "id" : 106542971
      }, {
        "name" : "R\u039BZ\u039ER @ BlizzCon",
        "screen_name" : "Razer",
        "indices" : [ 13, 19 ],
        "id_str" : "15880163",
        "id" : 15880163
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "926235031344906240",
    "geo" : { },
    "id_str" : "926237846251425792",
    "in_reply_to_user_id" : 106542971,
    "text" : "@jon_prosser @Razer I think it's cool too! I like that design language a lot more than infinity displays which is why I bought a Sony Xperia XZ1.",
    "id" : 926237846251425792,
    "in_reply_to_status_id" : 926235031344906240,
    "created_at" : "2017-11-03 00:01:25 +0000",
    "in_reply_to_screen_name" : "jon_prosser",
    "in_reply_to_user_id_str" : "106542971",
    "user" : {
      "name" : "\u216Figuel N. P.",
      "screen_name" : "LTEstyles",
      "protected" : false,
      "id_str" : "113229899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894326072254377984\/1AWoTkLA_normal.jpg",
      "id" : 113229899,
      "verified" : false
    }
  },
  "id" : 926242808620601344,
  "created_at" : "2017-11-03 00:21:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STARxd",
      "screen_name" : "STARxd_GD",
      "indices" : [ 3, 13 ],
      "id_str" : "715328595674181633",
      "id" : 715328595674181633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926242660909834240",
  "text" : "RT @STARxd_GD: The Razer phone has 120hz, anyone mobile GD players out there?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926164443645599744",
    "text" : "The Razer phone has 120hz, anyone mobile GD players out there?",
    "id" : 926164443645599744,
    "created_at" : "2017-11-02 19:09:45 +0000",
    "user" : {
      "name" : "STARxd",
      "screen_name" : "STARxd_GD",
      "protected" : false,
      "id_str" : "715328595674181633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715351020381954048\/N-LLhKe7_normal.jpg",
      "id" : 715328595674181633,
      "verified" : false
    }
  },
  "id" : 926242660909834240,
  "created_at" : "2017-11-03 00:20:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis",
      "screen_name" : "UnboxTherapy",
      "indices" : [ 3, 16 ],
      "id_str" : "239672340",
      "id" : 239672340
    }, {
      "name" : "R\u039BZ\u039ER @ BlizzCon",
      "screen_name" : "Razer",
      "indices" : [ 39, 45 ],
      "id_str" : "15880163",
      "id" : 15880163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926242605825953792",
  "text" : "RT @UnboxTherapy: The speakers on this @Razer phone are the best I've ever heard on a phone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "R\u039BZ\u039ER @ BlizzCon",
        "screen_name" : "Razer",
        "indices" : [ 21, 27 ],
        "id_str" : "15880163",
        "id" : 15880163
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926093645433864192",
    "text" : "The speakers on this @Razer phone are the best I've ever heard on a phone.",
    "id" : 926093645433864192,
    "created_at" : "2017-11-02 14:28:25 +0000",
    "user" : {
      "name" : "Lewis",
      "screen_name" : "UnboxTherapy",
      "protected" : false,
      "id_str" : "239672340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866518738769661952\/hwNn2RL8_normal.jpg",
      "id" : 239672340,
      "verified" : true
    }
  },
  "id" : 926242605825953792,
  "created_at" : "2017-11-03 00:20:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ZbexbpdzJg",
      "expanded_url" : "http:\/\/ift.tt\/2zrfBmu",
      "display_url" : "ift.tt\/2zrfBmu"
    } ]
  },
  "geo" : { },
  "id_str" : "926179923533942784",
  "text" : "RT @dronepilots: Partners Integrate UAV-Borne LiDAR In Geospatial Data - Sensors Online | DronePilots - https:\/\/t.co\/ZbexbpdzJg #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ZbexbpdzJg",
        "expanded_url" : "http:\/\/ift.tt\/2zrfBmu",
        "display_url" : "ift.tt\/2zrfBmu"
      } ]
    },
    "geo" : { },
    "id_str" : "926131230839640064",
    "text" : "Partners Integrate UAV-Borne LiDAR In Geospatial Data - Sensors Online | DronePilots - https:\/\/t.co\/ZbexbpdzJg #drones",
    "id" : 926131230839640064,
    "created_at" : "2017-11-02 16:57:46 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926179923533942784,
  "created_at" : "2017-11-02 20:11:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/sP40QNsc9Z",
      "expanded_url" : "http:\/\/engt.co\/2z8LmA0",
      "display_url" : "engt.co\/2z8LmA0"
    } ]
  },
  "geo" : { },
  "id_str" : "926179887983013888",
  "text" : "RT @engadget: Men's health tech creates shame-free ways to get treatment https:\/\/t.co\/sP40QNsc9Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/sP40QNsc9Z",
        "expanded_url" : "http:\/\/engt.co\/2z8LmA0",
        "display_url" : "engt.co\/2z8LmA0"
      } ]
    },
    "geo" : { },
    "id_str" : "926136638895509504",
    "text" : "Men's health tech creates shame-free ways to get treatment https:\/\/t.co\/sP40QNsc9Z",
    "id" : 926136638895509504,
    "created_at" : "2017-11-02 17:19:16 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926179887983013888,
  "created_at" : "2017-11-02 20:11:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/pwxrQrGVAm",
      "expanded_url" : "https:\/\/fstoppers.com\/originals\/dealing-criticism-photographer-202103?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/originals\/deal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926179794756218880",
  "text" : "RT @JayHoque: Dealing With Criticism as a Photographer: https:\/\/t.co\/pwxrQrGVAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/pwxrQrGVAm",
        "expanded_url" : "https:\/\/fstoppers.com\/originals\/dealing-criticism-photographer-202103?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/originals\/deal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926133554232348672",
    "text" : "Dealing With Criticism as a Photographer: https:\/\/t.co\/pwxrQrGVAm",
    "id" : 926133554232348672,
    "created_at" : "2017-11-02 17:07:00 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926179794756218880,
  "created_at" : "2017-11-02 20:10:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/2gHZ7GRZv9",
      "expanded_url" : "http:\/\/ift.tt\/2z86UdH",
      "display_url" : "ift.tt\/2z86UdH"
    } ]
  },
  "geo" : { },
  "id_str" : "926179772639727617",
  "text" : "RT @dronepilots: The latest unmanned drone is a version of an existing manned one - The Economist | DronePilots - https:\/\/t.co\/2gHZ7GRZv9 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/2gHZ7GRZv9",
        "expanded_url" : "http:\/\/ift.tt\/2z86UdH",
        "display_url" : "ift.tt\/2z86UdH"
      } ]
    },
    "geo" : { },
    "id_str" : "926129943116963842",
    "text" : "The latest unmanned drone is a version of an existing manned one - The Economist | DronePilots - https:\/\/t.co\/2gHZ7GRZv9 #drones",
    "id" : 926129943116963842,
    "created_at" : "2017-11-02 16:52:39 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 926179772639727617,
  "created_at" : "2017-11-02 20:10:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/7Z1EVQvx42",
      "expanded_url" : "http:\/\/engt.co\/2lIrFcW",
      "display_url" : "engt.co\/2lIrFcW"
    } ]
  },
  "geo" : { },
  "id_str" : "926179751529676801",
  "text" : "RT @engadget: Samsung wants you to beta test the next Galaxy phone's software https:\/\/t.co\/7Z1EVQvx42",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/7Z1EVQvx42",
        "expanded_url" : "http:\/\/engt.co\/2lIrFcW",
        "display_url" : "engt.co\/2lIrFcW"
      } ]
    },
    "geo" : { },
    "id_str" : "926132832304541699",
    "text" : "Samsung wants you to beta test the next Galaxy phone's software https:\/\/t.co\/7Z1EVQvx42",
    "id" : 926132832304541699,
    "created_at" : "2017-11-02 17:04:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 926179751529676801,
  "created_at" : "2017-11-02 20:10:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/A7vCiiq2Ck",
      "expanded_url" : "http:\/\/www.dpreview.com\/news\/0808513956\/htc-u11-combines-u11-camera-specs-with-large-6-inch-display",
      "display_url" : "dpreview.com\/news\/080851395\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926179671041101826",
  "text" : "RT @JayHoque: HTC U11+ combines U11 camera specs with large 6-inch display: https:\/\/t.co\/A7vCiiq2Ck",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/A7vCiiq2Ck",
        "expanded_url" : "http:\/\/www.dpreview.com\/news\/0808513956\/htc-u11-combines-u11-camera-specs-with-large-6-inch-display",
        "display_url" : "dpreview.com\/news\/080851395\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926133549958299648",
    "text" : "HTC U11+ combines U11 camera specs with large 6-inch display: https:\/\/t.co\/A7vCiiq2Ck",
    "id" : 926133549958299648,
    "created_at" : "2017-11-02 17:06:59 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 926179671041101826,
  "created_at" : "2017-11-02 20:10:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5iZOVRiV0L",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/backblaze-hdd-report-enterprise-premium,35825.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/backblaze\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926179625490886656",
  "text" : "RT @tomshardware: \u25B8 Backblaze's HDD Reliability Report Questions Enterprise Drive Premium https:\/\/t.co\/5iZOVRiV0L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/5iZOVRiV0L",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/backblaze-hdd-report-enterprise-premium,35825.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/backblaze\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926134828348485632",
    "text" : "\u25B8 Backblaze's HDD Reliability Report Questions Enterprise Drive Premium https:\/\/t.co\/5iZOVRiV0L",
    "id" : 926134828348485632,
    "created_at" : "2017-11-02 17:12:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926179625490886656,
  "created_at" : "2017-11-02 20:10:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926179612438167552",
  "text" : "RT @lorenridinger: \"One of the big lessons I have learned from my journey is you can't please everyone, so don't try.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926132192606121985",
    "text" : "\"One of the big lessons I have learned from my journey is you can't please everyone, so don't try.\"",
    "id" : 926132192606121985,
    "created_at" : "2017-11-02 17:01:36 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 926179612438167552,
  "created_at" : "2017-11-02 20:10:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926138689683587072",
  "geo" : { },
  "id_str" : "926179580028874754",
  "in_reply_to_user_id" : 210979938,
  "text" : "I had so much BBQ, they way too overfed me, lol, think I am done for the day",
  "id" : 926179580028874754,
  "in_reply_to_status_id" : 926138689683587072,
  "created_at" : "2017-11-02 20:09:54 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/926138689683587072\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/M0UAP7BlJR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNpONYXUMAAVbPa.jpg",
      "id_str" : "926138665163567104",
      "id" : 926138665163567104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNpONYXUMAAVbPa.jpg",
      "sizes" : [ {
        "h" : 1354,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1354,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/M0UAP7BlJR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926138689683587072",
  "text" : "Had BBQ and also a burger sandwich at work, so good, they should do this more often, lol https:\/\/t.co\/M0UAP7BlJR",
  "id" : 926138689683587072,
  "created_at" : "2017-11-02 17:27:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    }, {
      "name" : "BitFenix",
      "screen_name" : "BitFenix",
      "indices" : [ 20, 29 ],
      "id_str" : "116843989",
      "id" : 116843989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/x7h7jvx14Q",
      "expanded_url" : "http:\/\/www.tomshardware.com\/news\/bitfenix-releases-formula-gold-psus,35822.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/news\/bitfenix-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926123225918136320",
  "text" : "RT @tomshardware: \u25B8 @BitFenix Releases The Formula Gold PSU Line https:\/\/t.co\/x7h7jvx14Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BitFenix",
        "screen_name" : "BitFenix",
        "indices" : [ 2, 11 ],
        "id_str" : "116843989",
        "id" : 116843989
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/x7h7jvx14Q",
        "expanded_url" : "http:\/\/www.tomshardware.com\/news\/bitfenix-releases-formula-gold-psus,35822.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/news\/bitfenix-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926122246241841152",
    "text" : "\u25B8 @BitFenix Releases The Formula Gold PSU Line https:\/\/t.co\/x7h7jvx14Q",
    "id" : 926122246241841152,
    "created_at" : "2017-11-02 16:22:04 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 926123225918136320,
  "created_at" : "2017-11-02 16:25:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Wire",
      "screen_name" : "realDailyWire",
      "indices" : [ 3, 17 ],
      "id_str" : "4081106480",
      "id" : 4081106480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/azDfZlDRvu",
      "expanded_url" : "http:\/\/dld.bz\/gr2Bm",
      "display_url" : "dld.bz\/gr2Bm"
    } ]
  },
  "geo" : { },
  "id_str" : "926121002765094912",
  "text" : "RT @realDailyWire: Archaeologists Discover Mysterious Void Deep Inside Great Pyramid Of Giza https:\/\/t.co\/azDfZlDRvu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/azDfZlDRvu",
        "expanded_url" : "http:\/\/dld.bz\/gr2Bm",
        "display_url" : "dld.bz\/gr2Bm"
      } ]
    },
    "geo" : { },
    "id_str" : "926118745419993088",
    "text" : "Archaeologists Discover Mysterious Void Deep Inside Great Pyramid Of Giza https:\/\/t.co\/azDfZlDRvu",
    "id" : 926118745419993088,
    "created_at" : "2017-11-02 16:08:10 +0000",
    "user" : {
      "name" : "The Daily Wire",
      "screen_name" : "realDailyWire",
      "protected" : false,
      "id_str" : "4081106480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660488928240119808\/QqX7ED73_normal.png",
      "id" : 4081106480,
      "verified" : true
    }
  },
  "id" : 926121002765094912,
  "created_at" : "2017-11-02 16:17:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926118189863460864",
  "text" : "RT @BarbaraCorcoran: I prefer to invest in entrepreneurs who know hardship- who want and need to prove something and are hungry for success.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "926114226946658306",
    "text" : "I prefer to invest in entrepreneurs who know hardship- who want and need to prove something and are hungry for success.",
    "id" : 926114226946658306,
    "created_at" : "2017-11-02 15:50:12 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 926118189863460864,
  "created_at" : "2017-11-02 16:05:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/NIpb8aixIf",
      "expanded_url" : "https:\/\/makezine.com\/2017\/11\/01\/track-stylus-in-3d-space\/",
      "display_url" : "makezine.com\/2017\/11\/01\/tra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "926113716810240000",
  "text" : "RT @make: Make your own low cost sensor for real-time tracking of the precise coordinates of the tip of a stylus https:\/\/t.co\/NIpb8aixIf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/NIpb8aixIf",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/01\/track-stylus-in-3d-space\/",
        "display_url" : "makezine.com\/2017\/11\/01\/tra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "926082778218876932",
    "text" : "Make your own low cost sensor for real-time tracking of the precise coordinates of the tip of a stylus https:\/\/t.co\/NIpb8aixIf",
    "id" : 926082778218876932,
    "created_at" : "2017-11-02 13:45:14 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 926113716810240000,
  "created_at" : "2017-11-02 15:48:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "indices" : [ 3, 10 ],
      "id_str" : "15919988",
      "id" : 15919988
    }, {
      "name" : "New Atlas",
      "screen_name" : "nwtls",
      "indices" : [ 55, 61 ],
      "id_str" : "3031911076",
      "id" : 3031911076
    }, {
      "name" : "David Szondy",
      "screen_name" : "davidszondy",
      "indices" : [ 62, 74 ],
      "id_str" : "813693824",
      "id" : 813693824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/qK1dvdnLHH",
      "expanded_url" : "https:\/\/goo.gl\/21bqcB",
      "display_url" : "goo.gl\/21bqcB"
    } ]
  },
  "geo" : { },
  "id_str" : "926022540958593024",
  "text" : "RT @xprize: Lobsters + space = https:\/\/t.co\/qK1dvdnLHH @nwtls @davidszondy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Atlas",
        "screen_name" : "nwtls",
        "indices" : [ 43, 49 ],
        "id_str" : "3031911076",
        "id" : 3031911076
      }, {
        "name" : "David Szondy",
        "screen_name" : "davidszondy",
        "indices" : [ 50, 62 ],
        "id_str" : "813693824",
        "id" : 813693824
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/qK1dvdnLHH",
        "expanded_url" : "https:\/\/goo.gl\/21bqcB",
        "display_url" : "goo.gl\/21bqcB"
      } ]
    },
    "geo" : { },
    "id_str" : "925977031829086208",
    "text" : "Lobsters + space = https:\/\/t.co\/qK1dvdnLHH @nwtls @davidszondy",
    "id" : 925977031829086208,
    "created_at" : "2017-11-02 06:45:02 +0000",
    "user" : {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "protected" : false,
      "id_str" : "15919988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890261363808886784\/WJyNCRI__normal.jpg",
      "id" : 15919988,
      "verified" : true
    }
  },
  "id" : 926022540958593024,
  "created_at" : "2017-11-02 09:45:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "indices" : [ 3, 14 ],
      "id_str" : "36912323",
      "id" : 36912323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/RsIZWJzRKD",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/TheNextWeb\/~3\/X7uEgEQgiVg\/",
      "display_url" : "feedproxy.google.com\/~r\/TheNextWeb\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925973862071832576",
  "text" : "RT @grattonboy: Hands-on: The Razer Phone comes with a 120hz display and incredibly good speakers https:\/\/t.co\/RsIZWJzRKD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/RsIZWJzRKD",
        "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/TheNextWeb\/~3\/X7uEgEQgiVg\/",
        "display_url" : "feedproxy.google.com\/~r\/TheNextWeb\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925972814603177984",
    "text" : "Hands-on: The Razer Phone comes with a 120hz display and incredibly good speakers https:\/\/t.co\/RsIZWJzRKD",
    "id" : 925972814603177984,
    "created_at" : "2017-11-02 06:28:17 +0000",
    "user" : {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "protected" : false,
      "id_str" : "36912323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819521494371934208\/8cPchIQ-_normal.jpg",
      "id" : 36912323,
      "verified" : true
    }
  },
  "id" : 925973862071832576,
  "created_at" : "2017-11-02 06:32:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925973515962077184",
  "text" : "RT @BONNIELYNN2015: Fake people suck the air out of the room especially the \" ones\" acting real but then never loved anyone but themselves",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925969345439719424",
    "text" : "Fake people suck the air out of the room especially the \" ones\" acting real but then never loved anyone but themselves",
    "id" : 925969345439719424,
    "created_at" : "2017-11-02 06:14:30 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927433831929413632\/duExUEVU_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 925973515962077184,
  "created_at" : "2017-11-02 06:31:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokia Fansclub",
      "screen_name" : "NokiaFansclub1",
      "indices" : [ 3, 18 ],
      "id_str" : "1037583997",
      "id" : 1037583997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/fRU9vBy7Io",
      "expanded_url" : "http:\/\/ETTelecom.com",
      "display_url" : "ETTelecom.com"
    } ]
  },
  "geo" : { },
  "id_str" : "925973352073912321",
  "text" : "RT @NokiaFansclub1: Our focus is to make India ready for 5G and IoT: Sanjay Malik, Nokia India head - https:\/\/t.co\/fRU9vBy7Io https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/fRU9vBy7Io",
        "expanded_url" : "http:\/\/ETTelecom.com",
        "display_url" : "ETTelecom.com"
      }, {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/eOCeZGhYf5",
        "expanded_url" : "http:\/\/dlvr.it\/PypNld",
        "display_url" : "dlvr.it\/PypNld"
      } ]
    },
    "geo" : { },
    "id_str" : "925967124169867265",
    "text" : "Our focus is to make India ready for 5G and IoT: Sanjay Malik, Nokia India head - https:\/\/t.co\/fRU9vBy7Io https:\/\/t.co\/eOCeZGhYf5",
    "id" : 925967124169867265,
    "created_at" : "2017-11-02 06:05:40 +0000",
    "user" : {
      "name" : "Nokia Fansclub",
      "screen_name" : "NokiaFansclub1",
      "protected" : false,
      "id_str" : "1037583997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3348886746\/5359ff9f16907ac5fe780b9c187a9c84_normal.jpeg",
      "id" : 1037583997,
      "verified" : false
    }
  },
  "id" : 925973352073912321,
  "created_at" : "2017-11-02 06:30:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925973339931402240",
  "text" : "RT @hootsuite: Yes, there is more than one type of social media \uD83D\uDE42 10 different types of social media and what they\u2019re used for. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/s7Ad5pRT70",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/a6dip\/4qk9e",
        "display_url" : "cards.twitter.com\/cards\/a6dip\/4q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925969495159656448",
    "text" : "Yes, there is more than one type of social media \uD83D\uDE42 10 different types of social media and what they\u2019re used for. https:\/\/t.co\/s7Ad5pRT70",
    "id" : 925969495159656448,
    "created_at" : "2017-11-02 06:15:05 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 925973339931402240,
  "created_at" : "2017-11-02 06:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lil lay \uD83D\uDC7D",
      "screen_name" : "xolaysha",
      "indices" : [ 0, 9 ],
      "id_str" : "948676328",
      "id" : 948676328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925535918722777088",
  "geo" : { },
  "id_str" : "925972977979707392",
  "in_reply_to_user_id" : 948676328,
  "text" : "@xolaysha I don't take you as a joke",
  "id" : 925972977979707392,
  "in_reply_to_status_id" : 925535918722777088,
  "created_at" : "2017-11-02 06:28:56 +0000",
  "in_reply_to_screen_name" : "xolaysha",
  "in_reply_to_user_id_str" : "948676328",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ljGO7r4uF1",
      "expanded_url" : "http:\/\/ift.tt\/2ymI2lt",
      "display_url" : "ift.tt\/2ymI2lt"
    } ]
  },
  "geo" : { },
  "id_str" : "925955888082554880",
  "text" : "RT @dronepilots: MacDill AFB officials throw 'Drone Rodeo' in Ybor City - ABC Action News | DronePilots - https:\/\/t.co\/ljGO7r4uF1 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/ljGO7r4uF1",
        "expanded_url" : "http:\/\/ift.tt\/2ymI2lt",
        "display_url" : "ift.tt\/2ymI2lt"
      } ]
    },
    "geo" : { },
    "id_str" : "925914709152411648",
    "text" : "MacDill AFB officials throw 'Drone Rodeo' in Ybor City - ABC Action News | DronePilots - https:\/\/t.co\/ljGO7r4uF1 #drones",
    "id" : 925914709152411648,
    "created_at" : "2017-11-02 02:37:23 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 925955888082554880,
  "created_at" : "2017-11-02 05:21:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925952946340290561",
  "text" : "RT @BONNIELYNN2015: I have a vivid imagination \uD83D\uDC7B\uD83D\uDC7B\uD83D\uDC7B\uD83C\uDFA5\uD83C\uDFA5\uD83C\uDFA5\uD83D\uDCDD\uD83D\uDCDD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925952599961960448",
    "text" : "I have a vivid imagination \uD83D\uDC7B\uD83D\uDC7B\uD83D\uDC7B\uD83C\uDFA5\uD83C\uDFA5\uD83C\uDFA5\uD83D\uDCDD\uD83D\uDCDD",
    "id" : 925952599961960448,
    "created_at" : "2017-11-02 05:07:57 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927433831929413632\/duExUEVU_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 925952946340290561,
  "created_at" : "2017-11-02 05:09:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ALYINAS",
      "screen_name" : "alyinas",
      "indices" : [ 3, 11 ],
      "id_str" : "2240315020",
      "id" : 2240315020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925951682617446400",
  "text" : "RT @alyinas: the best revenge is no revenge. move on. be happy. find inner peace. flourish.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925234031746306048",
    "text" : "the best revenge is no revenge. move on. be happy. find inner peace. flourish.",
    "id" : 925234031746306048,
    "created_at" : "2017-10-31 05:32:37 +0000",
    "user" : {
      "name" : "ALYINAS",
      "screen_name" : "alyinas",
      "protected" : false,
      "id_str" : "2240315020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926530532954877952\/l-r30CSg_normal.jpg",
      "id" : 2240315020,
      "verified" : false
    }
  },
  "id" : 925951682617446400,
  "created_at" : "2017-11-02 05:04:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/hyF2y27lQh",
      "expanded_url" : "http:\/\/tcrn.ch\/2lEIe9P",
      "display_url" : "tcrn.ch\/2lEIe9P"
    } ]
  },
  "geo" : { },
  "id_str" : "925945557675278336",
  "text" : "RT @TechCrunch: With Apple lawsuits still looming, Qualcomm beats revenue expectations https:\/\/t.co\/hyF2y27lQh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/hyF2y27lQh",
        "expanded_url" : "http:\/\/tcrn.ch\/2lEIe9P",
        "display_url" : "tcrn.ch\/2lEIe9P"
      } ]
    },
    "geo" : { },
    "id_str" : "925904807810002946",
    "text" : "With Apple lawsuits still looming, Qualcomm beats revenue expectations https:\/\/t.co\/hyF2y27lQh",
    "id" : 925904807810002946,
    "created_at" : "2017-11-02 01:58:03 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879359733936701440\/sitcq7wY_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 925945557675278336,
  "created_at" : "2017-11-02 04:39:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Personal Finance",
      "screen_name" : "WSJpersfinance",
      "indices" : [ 3, 18 ],
      "id_str" : "28175577",
      "id" : 28175577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qwsVI9wdT4",
      "expanded_url" : "http:\/\/on.wsj.com\/2ilHZeK",
      "display_url" : "on.wsj.com\/2ilHZeK"
    } ]
  },
  "geo" : { },
  "id_str" : "925945249180024832",
  "text" : "RT @WSJpersfinance: Five situations where it is better to use a Roth 401(k) rather than a traditional version | https:\/\/t.co\/qwsVI9wdT4 via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 120, 124 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/qwsVI9wdT4",
        "expanded_url" : "http:\/\/on.wsj.com\/2ilHZeK",
        "display_url" : "on.wsj.com\/2ilHZeK"
      } ]
    },
    "geo" : { },
    "id_str" : "925822579176300549",
    "text" : "Five situations where it is better to use a Roth 401(k) rather than a traditional version | https:\/\/t.co\/qwsVI9wdT4 via @WSJ",
    "id" : 925822579176300549,
    "created_at" : "2017-11-01 20:31:18 +0000",
    "user" : {
      "name" : "WSJ Personal Finance",
      "screen_name" : "WSJpersfinance",
      "protected" : false,
      "id_str" : "28175577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2190622417\/wsj-twitter-personal-finance_normal.png",
      "id" : 28175577,
      "verified" : false
    }
  },
  "id" : 925945249180024832,
  "created_at" : "2017-11-02 04:38:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "indices" : [ 3, 10 ],
      "id_str" : "15919988",
      "id" : 15919988
    }, {
      "name" : "New Atlas",
      "screen_name" : "nwtls",
      "indices" : [ 99, 105 ],
      "id_str" : "3031911076",
      "id" : 3031911076
    }, {
      "name" : "Nick Lavars",
      "screen_name" : "NickLavars",
      "indices" : [ 106, 117 ],
      "id_str" : "579291477",
      "id" : 579291477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/jfHEBOQVBG",
      "expanded_url" : "https:\/\/goo.gl\/3Z7U8J",
      "display_url" : "goo.gl\/3Z7U8J"
    } ]
  },
  "geo" : { },
  "id_str" : "925944993201704961",
  "text" : "RT @xprize: This robot could help do the heavy lifting for postal workers: https:\/\/t.co\/jfHEBOQVBG @nwtls @NickLavars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Atlas",
        "screen_name" : "nwtls",
        "indices" : [ 87, 93 ],
        "id_str" : "3031911076",
        "id" : 3031911076
      }, {
        "name" : "Nick Lavars",
        "screen_name" : "NickLavars",
        "indices" : [ 94, 105 ],
        "id_str" : "579291477",
        "id" : 579291477
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/jfHEBOQVBG",
        "expanded_url" : "https:\/\/goo.gl\/3Z7U8J",
        "display_url" : "goo.gl\/3Z7U8J"
      } ]
    },
    "geo" : { },
    "id_str" : "921239605441044480",
    "text" : "This robot could help do the heavy lifting for postal workers: https:\/\/t.co\/jfHEBOQVBG @nwtls @NickLavars",
    "id" : 921239605441044480,
    "created_at" : "2017-10-20 05:00:12 +0000",
    "user" : {
      "name" : "XPRIZE",
      "screen_name" : "xprize",
      "protected" : false,
      "id_str" : "15919988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890261363808886784\/WJyNCRI__normal.jpg",
      "id" : 15919988,
      "verified" : true
    }
  },
  "id" : 925944993201704961,
  "created_at" : "2017-11-02 04:37:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "Brown University",
      "screen_name" : "BrownUniversity",
      "indices" : [ 97, 113 ],
      "id_str" : "14884486",
      "id" : 14884486
    }, {
      "name" : "Physical Review Lett",
      "screen_name" : "PhysRevLett",
      "indices" : [ 114, 126 ],
      "id_str" : "3039504459",
      "id" : 3039504459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "matter",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/eBgDuiwvYc",
      "expanded_url" : "http:\/\/phy.so\/428762581",
      "display_url" : "phy.so\/428762581"
    } ]
  },
  "geo" : { },
  "id_str" : "925944701320138752",
  "text" : "RT @physorg_com: Physicists describe new dark #matter detection strategy https:\/\/t.co\/eBgDuiwvYc @BrownUniversity @physrevlett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brown University",
        "screen_name" : "BrownUniversity",
        "indices" : [ 80, 96 ],
        "id_str" : "14884486",
        "id" : 14884486
      }, {
        "name" : "Physical Review Lett",
        "screen_name" : "PhysRevLett",
        "indices" : [ 97, 109 ],
        "id_str" : "3039504459",
        "id" : 3039504459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "matter",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/eBgDuiwvYc",
        "expanded_url" : "http:\/\/phy.so\/428762581",
        "display_url" : "phy.so\/428762581"
      } ]
    },
    "geo" : { },
    "id_str" : "925780362306998273",
    "text" : "Physicists describe new dark #matter detection strategy https:\/\/t.co\/eBgDuiwvYc @BrownUniversity @physrevlett",
    "id" : 925780362306998273,
    "created_at" : "2017-11-01 17:43:33 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 925944701320138752,
  "created_at" : "2017-11-02 04:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "ACS App Mat Interf",
      "screen_name" : "ACS_AMI",
      "indices" : [ 101, 109 ],
      "id_str" : "1566304268",
      "id" : 1566304268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skin",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/oqWEVfEYQK",
      "expanded_url" : "http:\/\/phy.so\/428774749",
      "display_url" : "phy.so\/428774749"
    } ]
  },
  "geo" : { },
  "id_str" : "925944511762784256",
  "text" : "RT @physorg_com: Jellyfish-inspired electronic #skin glows when it gets hurt https:\/\/t.co\/oqWEVfEYQK @ACS_AMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ACS App Mat Interf",
        "screen_name" : "ACS_AMI",
        "indices" : [ 84, 92 ],
        "id_str" : "1566304268",
        "id" : 1566304268
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "skin",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/oqWEVfEYQK",
        "expanded_url" : "http:\/\/phy.so\/428774749",
        "display_url" : "phy.so\/428774749"
      } ]
    },
    "geo" : { },
    "id_str" : "925831308269498368",
    "text" : "Jellyfish-inspired electronic #skin glows when it gets hurt https:\/\/t.co\/oqWEVfEYQK @ACS_AMI",
    "id" : 925831308269498368,
    "created_at" : "2017-11-01 21:05:59 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 925944511762784256,
  "created_at" : "2017-11-02 04:35:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/2zZioTIhXG",
      "expanded_url" : "https:\/\/twitter.com\/Forbes\/status\/925943304092573696",
      "display_url" : "twitter.com\/Forbes\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925944090872643585",
  "text" : "Good for him https:\/\/t.co\/2zZioTIhXG",
  "id" : 925944090872643585,
  "created_at" : "2017-11-02 04:34:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925939611850985472",
  "geo" : { },
  "id_str" : "925943991413166081",
  "in_reply_to_user_id" : 210979938,
  "text" : "*Tell, geez",
  "id" : 925943991413166081,
  "in_reply_to_status_id" : 925939611850985472,
  "created_at" : "2017-11-02 04:33:45 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925942600519086080",
  "text" : "RT @lorenridinger: \"If you want to live a happy life, tie it to a goal, not to people or things.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925860238976274432",
    "text" : "\"If you want to live a happy life, tie it to a goal, not to people or things.\"",
    "id" : 925860238976274432,
    "created_at" : "2017-11-01 23:00:57 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 925942600519086080,
  "created_at" : "2017-11-02 04:28:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925942579929255937",
  "text" : "RT @BarbaraCorcoran: You can always come up with 100 reasons not to do something. The trick is ignoring all of them!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925706548592152576",
    "text" : "You can always come up with 100 reasons not to do something. The trick is ignoring all of them!",
    "id" : 925706548592152576,
    "created_at" : "2017-11-01 12:50:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 925942579929255937,
  "created_at" : "2017-11-02 04:28:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Jb9eTGyLCA",
      "expanded_url" : "http:\/\/depot.ly\/FhfA30ggP7T",
      "display_url" : "depot.ly\/FhfA30ggP7T"
    } ]
  },
  "geo" : { },
  "id_str" : "925940381233111040",
  "text" : "RT @DesignerDepot: 5 Ways to Design With Accelerated Mobile Pages https:\/\/t.co\/Jb9eTGyLCA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/Jb9eTGyLCA",
        "expanded_url" : "http:\/\/depot.ly\/FhfA30ggP7T",
        "display_url" : "depot.ly\/FhfA30ggP7T"
      } ]
    },
    "geo" : { },
    "id_str" : "925928004412432384",
    "text" : "5 Ways to Design With Accelerated Mobile Pages https:\/\/t.co\/Jb9eTGyLCA",
    "id" : 925928004412432384,
    "created_at" : "2017-11-02 03:30:13 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 925940381233111040,
  "created_at" : "2017-11-02 04:19:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian McElhaney",
      "screen_name" : "BJMcElhaney",
      "indices" : [ 3, 15 ],
      "id_str" : "24946044",
      "id" : 24946044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925940250911879169",
  "text" : "RT @BJMcElhaney: This is pretty nerdy but here it is: Mario Odyssey is SO Banjo-Kazooie and I am over the freakin (power)moon because of it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925909512040611840",
    "text" : "This is pretty nerdy but here it is: Mario Odyssey is SO Banjo-Kazooie and I am over the freakin (power)moon because of it.",
    "id" : 925909512040611840,
    "created_at" : "2017-11-02 02:16:44 +0000",
    "user" : {
      "name" : "Brian McElhaney",
      "screen_name" : "BJMcElhaney",
      "protected" : false,
      "id_str" : "24946044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860873159003832320\/iBwFk38G_normal.jpg",
      "id" : 24946044,
      "verified" : true
    }
  },
  "id" : 925940250911879169,
  "created_at" : "2017-11-02 04:18:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "indices" : [ 3, 14 ],
      "id_str" : "18009781",
      "id" : 18009781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925940134448648192",
  "text" : "RT @joshgroban: Still can\u2019t type the letter \uD83D\uDC41. Gonna have to start talking like Tarzan. Me ready for dinner. Me had a good day at studio.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925904372848087042",
    "text" : "Still can\u2019t type the letter \uD83D\uDC41. Gonna have to start talking like Tarzan. Me ready for dinner. Me had a good day at studio.",
    "id" : 925904372848087042,
    "created_at" : "2017-11-02 01:56:19 +0000",
    "user" : {
      "name" : "josh groban",
      "screen_name" : "joshgroban",
      "protected" : false,
      "id_str" : "18009781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880503021855272960\/klhrNu-e_normal.jpg",
      "id" : 18009781,
      "verified" : true
    }
  },
  "id" : 925940134448648192,
  "created_at" : "2017-11-02 04:18:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/SElYRHeFGA",
      "expanded_url" : "http:\/\/ift.tt\/2z6i70M",
      "display_url" : "ift.tt\/2z6i70M"
    } ]
  },
  "geo" : { },
  "id_str" : "925940102861344768",
  "text" : "RT @dronepilots: Hiker Pleads Guilty To Operating Drone In Wilderness - Adirondack Explorer | DronePilots - https:\/\/t.co\/SElYRHeFGA #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/SElYRHeFGA",
        "expanded_url" : "http:\/\/ift.tt\/2z6i70M",
        "display_url" : "ift.tt\/2z6i70M"
      } ]
    },
    "geo" : { },
    "id_str" : "925884482766467072",
    "text" : "Hiker Pleads Guilty To Operating Drone In Wilderness - Adirondack Explorer | DronePilots - https:\/\/t.co\/SElYRHeFGA #drones",
    "id" : 925884482766467072,
    "created_at" : "2017-11-02 00:37:17 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 925940102861344768,
  "created_at" : "2017-11-02 04:18:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/b8XntUuMQS",
      "expanded_url" : "https:\/\/www.lightstalking.com\/sony-announces-new-software-along-with-%ce%b17r-iii\/",
      "display_url" : "lightstalking.com\/sony-announces\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925940079750713344",
  "text" : "RT @JayHoque: Sony Announces New Software Along with \u03B17R III: https:\/\/t.co\/b8XntUuMQS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/b8XntUuMQS",
        "expanded_url" : "https:\/\/www.lightstalking.com\/sony-announces-new-software-along-with-%ce%b17r-iii\/",
        "display_url" : "lightstalking.com\/sony-announces\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925932691396157440",
    "text" : "Sony Announces New Software Along with \u03B17R III: https:\/\/t.co\/b8XntUuMQS",
    "id" : 925932691396157440,
    "created_at" : "2017-11-02 03:48:51 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 925940079750713344,
  "created_at" : "2017-11-02 04:18:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Butcher",
      "screen_name" : "DaniSButcher",
      "indices" : [ 3, 16 ],
      "id_str" : "400599700",
      "id" : 400599700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925940056992419840",
  "text" : "RT @DaniSButcher: Very Important PSA: the bee emoji got a makeover. \uD83D\uDC1D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925915555936292864",
    "text" : "Very Important PSA: the bee emoji got a makeover. \uD83D\uDC1D",
    "id" : 925915555936292864,
    "created_at" : "2017-11-02 02:40:45 +0000",
    "user" : {
      "name" : "Danielle Butcher",
      "screen_name" : "DaniSButcher",
      "protected" : false,
      "id_str" : "400599700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925575178842726400\/fsRaiTpW_normal.jpg",
      "id" : 400599700,
      "verified" : false
    }
  },
  "id" : 925940056992419840,
  "created_at" : "2017-11-02 04:18:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/iIgpengU0h",
      "expanded_url" : "http:\/\/ift.tt\/2h4iLVR",
      "display_url" : "ift.tt\/2h4iLVR"
    } ]
  },
  "geo" : { },
  "id_str" : "925939838444064768",
  "text" : "RT @dronepilots: Govt issues draft rules for using drones in India - Livemint | DronePilots - https:\/\/t.co\/iIgpengU0h #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iIgpengU0h",
        "expanded_url" : "http:\/\/ift.tt\/2h4iLVR",
        "display_url" : "ift.tt\/2h4iLVR"
      } ]
    },
    "geo" : { },
    "id_str" : "925937339792228352",
    "text" : "Govt issues draft rules for using drones in India - Livemint | DronePilots - https:\/\/t.co\/iIgpengU0h #drones",
    "id" : 925937339792228352,
    "created_at" : "2017-11-02 04:07:19 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 925939838444064768,
  "created_at" : "2017-11-02 04:17:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925939805535514630",
  "text" : "RT @lorenridinger: \"Sometimes the questions are complicated and the answers are simple.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925920526098366464",
    "text" : "\"Sometimes the questions are complicated and the answers are simple.\"",
    "id" : 925920526098366464,
    "created_at" : "2017-11-02 03:00:30 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 925939805535514630,
  "created_at" : "2017-11-02 04:17:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/925939611850985472\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/DHxWlOJCjB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNmZKNcXUAAZmGg.jpg",
      "id_str" : "925939599087718400",
      "id" : 925939599087718400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNmZKNcXUAAZmGg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1071,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1071,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/DHxWlOJCjB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925939611850985472",
  "text" : "Too this day still learning some stuff, well refreshing https:\/\/t.co\/DHxWlOJCjB",
  "id" : 925939611850985472,
  "created_at" : "2017-11-02 04:16:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Yc6wXfSows",
      "expanded_url" : "http:\/\/depot.ly\/eZGi30ggQ5v",
      "display_url" : "depot.ly\/eZGi30ggQ5v"
    } ]
  },
  "geo" : { },
  "id_str" : "925870307252072451",
  "text" : "RT @DesignerDepot: 11 Fastest Lazy Load Image Plugins For WordPress https:\/\/t.co\/Yc6wXfSows",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/Yc6wXfSows",
        "expanded_url" : "http:\/\/depot.ly\/eZGi30ggQ5v",
        "display_url" : "depot.ly\/eZGi30ggQ5v"
      } ]
    },
    "geo" : { },
    "id_str" : "925866322440974340",
    "text" : "11 Fastest Lazy Load Image Plugins For WordPress https:\/\/t.co\/Yc6wXfSows",
    "id" : 925866322440974340,
    "created_at" : "2017-11-01 23:25:07 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 925870307252072451,
  "created_at" : "2017-11-01 23:40:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Twopcharts",
      "screen_name" : "twopcharts_gl",
      "indices" : [ 3, 17 ],
      "id_str" : "65666267",
      "id" : 65666267
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Q6hMSP7FMu",
      "expanded_url" : "http:\/\/twopcharts.com\/gamer456148",
      "display_url" : "twopcharts.com\/gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "925870163001569282",
  "text" : "RT @twopcharts_gl: @gamer456148 Congratulations, it is now exactly 7 years ago that you started with Twitter. https:\/\/t.co\/Q6hMSP7FMu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twopcharts.com\" rel=\"nofollow\"\u003EToS compliant Twopcharts\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Q6hMSP7FMu",
        "expanded_url" : "http:\/\/twopcharts.com\/gamer456148",
        "display_url" : "twopcharts.com\/gamer456148"
      } ]
    },
    "geo" : { },
    "id_str" : "925870085587300354",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Congratulations, it is now exactly 7 years ago that you started with Twitter. https:\/\/t.co\/Q6hMSP7FMu",
    "id" : 925870085587300354,
    "created_at" : "2017-11-01 23:40:04 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Global Twopcharts",
      "screen_name" : "twopcharts_gl",
      "protected" : false,
      "id_str" : "65666267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/362880274\/547px-Scale_one_to_thousand_volume_svg_normal.png",
      "id" : 65666267,
      "verified" : false
    }
  },
  "id" : 925870163001569282,
  "created_at" : "2017-11-01 23:40:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Staying Healthy",
      "screen_name" : "4StayingHealthy",
      "indices" : [ 3, 19 ],
      "id_str" : "974361823",
      "id" : 974361823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ja1pqklmXP",
      "expanded_url" : "http:\/\/bit.ly\/2p2LoE9",
      "display_url" : "bit.ly\/2p2LoE9"
    } ]
  },
  "geo" : { },
  "id_str" : "925864046649331712",
  "text" : "RT @4StayingHealthy: Lyrid meteor shower to peak on Earth Day https:\/\/t.co\/ja1pqklmXP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/ja1pqklmXP",
        "expanded_url" : "http:\/\/bit.ly\/2p2LoE9",
        "display_url" : "bit.ly\/2p2LoE9"
      } ]
    },
    "geo" : { },
    "id_str" : "925754969025925120",
    "text" : "Lyrid meteor shower to peak on Earth Day https:\/\/t.co\/ja1pqklmXP",
    "id" : 925754969025925120,
    "created_at" : "2017-11-01 16:02:38 +0000",
    "user" : {
      "name" : "Staying Healthy",
      "screen_name" : "4StayingHealthy",
      "protected" : false,
      "id_str" : "974361823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535910475037286400\/UdLSH5PP_normal.jpeg",
      "id" : 974361823,
      "verified" : false
    }
  },
  "id" : 925864046649331712,
  "created_at" : "2017-11-01 23:16:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xiobus",
      "screen_name" : "xiobus",
      "indices" : [ 3, 10 ],
      "id_str" : "45605536",
      "id" : 45605536
    }, {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 88, 100 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/4gWGoCnLFt",
      "expanded_url" : "http:\/\/www.motherjones.com\/environment\/2017\/10\/climatedesk-tesla-wants-to-put-puerto-rico-back-on-the-grid\/",
      "display_url" : "motherjones.com\/environment\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925863509006651392",
  "text" : "RT @xiobus: Tesla wants to put Puerto Rico back on the grid https:\/\/t.co\/4gWGoCnLFt via @MotherJones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mother Jones",
        "screen_name" : "MotherJones",
        "indices" : [ 76, 88 ],
        "id_str" : "18510860",
        "id" : 18510860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/4gWGoCnLFt",
        "expanded_url" : "http:\/\/www.motherjones.com\/environment\/2017\/10\/climatedesk-tesla-wants-to-put-puerto-rico-back-on-the-grid\/",
        "display_url" : "motherjones.com\/environment\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925722271636951041",
    "text" : "Tesla wants to put Puerto Rico back on the grid https:\/\/t.co\/4gWGoCnLFt via @MotherJones",
    "id" : 925722271636951041,
    "created_at" : "2017-11-01 13:52:43 +0000",
    "user" : {
      "name" : "Xiobus",
      "screen_name" : "xiobus",
      "protected" : false,
      "id_str" : "45605536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839736527374565377\/1fsmBq5K_normal.jpg",
      "id" : 45605536,
      "verified" : false
    }
  },
  "id" : 925863509006651392,
  "created_at" : "2017-11-01 23:13:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/bo1uVM9InT",
      "expanded_url" : "http:\/\/engt.co\/2z56dUW",
      "display_url" : "engt.co\/2z56dUW"
    } ]
  },
  "geo" : { },
  "id_str" : "925860116028645376",
  "text" : "RT @engadget: It rains sunscreen on this 'hot Jupiter' exoplanet https:\/\/t.co\/bo1uVM9InT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/bo1uVM9InT",
        "expanded_url" : "http:\/\/engt.co\/2z56dUW",
        "display_url" : "engt.co\/2z56dUW"
      } ]
    },
    "geo" : { },
    "id_str" : "925855022944006144",
    "text" : "It rains sunscreen on this 'hot Jupiter' exoplanet https:\/\/t.co\/bo1uVM9InT",
    "id" : 925855022944006144,
    "created_at" : "2017-11-01 22:40:13 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 925860116028645376,
  "created_at" : "2017-11-01 23:00:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/DNdLG98Mej",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/01\/cheap-photo-50-off-the-art-of-travel-photography-video-course\/",
      "display_url" : "thephoblographer.com\/2017\/11\/01\/che\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925859599059771392",
  "text" : "RT @JayHoque: Cheap Photo: $50 Off The Art Of Travel Photography Video Course: https:\/\/t.co\/DNdLG98Mej",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/DNdLG98Mej",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2017\/11\/01\/cheap-photo-50-off-the-art-of-travel-photography-video-course\/",
        "display_url" : "thephoblographer.com\/2017\/11\/01\/che\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925854663999676416",
    "text" : "Cheap Photo: $50 Off The Art Of Travel Photography Video Course: https:\/\/t.co\/DNdLG98Mej",
    "id" : 925854663999676416,
    "created_at" : "2017-11-01 22:38:48 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 925859599059771392,
  "created_at" : "2017-11-01 22:58:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/925859415789592583\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/QhfZArN5S2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNlQOg3X4AAND8Z.jpg",
      "id_str" : "925859408671924224",
      "id" : 925859408671924224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNlQOg3X4AAND8Z.jpg",
      "sizes" : [ {
        "h" : 482,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 925
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 925
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 925
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/QhfZArN5S2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/925859415789592583\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/QhfZArN5S2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNlQOgcXkAA5bC2.jpg",
      "id_str" : "925859408558657536",
      "id" : 925859408558657536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNlQOgcXkAA5bC2.jpg",
      "sizes" : [ {
        "h" : 462,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1241
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 844,
        "resize" : "fit",
        "w" : 1241
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/QhfZArN5S2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925859415789592583",
  "text" : "Ripple isn't doing so well today :( https:\/\/t.co\/QhfZArN5S2",
  "id" : 925859415789592583,
  "created_at" : "2017-11-01 22:57:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/KzLIZJuJ0w",
      "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/7-python-tools-all-data-scientists-should-know-how-to-use\/?s=1",
      "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925849494729756672",
  "text" : "RT @analyticbridge: https:\/\/t.co\/KzLIZJuJ0w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/KzLIZJuJ0w",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/7-python-tools-all-data-scientists-should-know-how-to-use\/?s=1",
        "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925845023891054593",
    "text" : "https:\/\/t.co\/KzLIZJuJ0w",
    "id" : 925845023891054593,
    "created_at" : "2017-11-01 22:00:29 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 925849494729756672,
  "created_at" : "2017-11-01 22:18:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Meresandra",
      "screen_name" : "SunnyMeresandra",
      "indices" : [ 81, 97 ],
      "id_str" : "910557227093766144",
      "id" : 910557227093766144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/5YMfdqkGQ3",
      "expanded_url" : "http:\/\/Amazon.com",
      "display_url" : "Amazon.com"
    }, {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/329GTnv4FP",
      "expanded_url" : "https:\/\/medium.com\/swlh\/google-has-called-amazon-com-its-direct-competitor-a385c5c381fb",
      "display_url" : "medium.com\/swlh\/google-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925849381101821953",
  "text" : "RT @Medium: \u201CGoogle Has Called https:\/\/t.co\/5YMfdqkGQ3 Its Direct Competitor\u201D by @SunnyMeresandra https:\/\/t.co\/329GTnv4FP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meresandra",
        "screen_name" : "SunnyMeresandra",
        "indices" : [ 69, 85 ],
        "id_str" : "910557227093766144",
        "id" : 910557227093766144
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/5YMfdqkGQ3",
        "expanded_url" : "http:\/\/Amazon.com",
        "display_url" : "Amazon.com"
      }, {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/329GTnv4FP",
        "expanded_url" : "https:\/\/medium.com\/swlh\/google-has-called-amazon-com-its-direct-competitor-a385c5c381fb",
        "display_url" : "medium.com\/swlh\/google-ha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925845148763799553",
    "text" : "\u201CGoogle Has Called https:\/\/t.co\/5YMfdqkGQ3 Its Direct Competitor\u201D by @SunnyMeresandra https:\/\/t.co\/329GTnv4FP",
    "id" : 925845148763799553,
    "created_at" : "2017-11-01 22:00:59 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/900033008685666305\/c6Q38U35_normal.png",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 925849381101821953,
  "created_at" : "2017-11-01 22:17:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925849239271374848",
  "text" : "RT @lorenridinger: \"If you try, you risk failure. If you don\u2019t, you ensure it.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925799993377742855",
    "text" : "\"If you try, you risk failure. If you don\u2019t, you ensure it.\"",
    "id" : 925799993377742855,
    "created_at" : "2017-11-01 19:01:33 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 925849239271374848,
  "created_at" : "2017-11-01 22:17:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925849206581092352",
  "text" : "RT @BarbaraCorcoran: Always create a sense of demand, rather than waiting to have demand.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925798400603418630",
    "text" : "Always create a sense of demand, rather than waiting to have demand.",
    "id" : 925798400603418630,
    "created_at" : "2017-11-01 18:55:13 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 925849206581092352,
  "created_at" : "2017-11-01 22:17:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/VM1TuveMCY",
      "expanded_url" : "https:\/\/makezine.com\/2017\/11\/01\/open-world-20-databases-help-find-local-maker-resources\/",
      "display_url" : "makezine.com\/2017\/11\/01\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925849187006275584",
  "text" : "RT @make: You might be surprised to learn of how many makerspaces are in your area https:\/\/t.co\/VM1TuveMCY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/VM1TuveMCY",
        "expanded_url" : "https:\/\/makezine.com\/2017\/11\/01\/open-world-20-databases-help-find-local-maker-resources\/",
        "display_url" : "makezine.com\/2017\/11\/01\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925788353143984130",
    "text" : "You might be surprised to learn of how many makerspaces are in your area https:\/\/t.co\/VM1TuveMCY",
    "id" : 925788353143984130,
    "created_at" : "2017-11-01 18:15:18 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 925849187006275584,
  "created_at" : "2017-11-01 22:17:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925843936182226944",
  "geo" : { },
  "id_str" : "925849140021678082",
  "in_reply_to_user_id" : 210979938,
  "text" : "Still no fix, but gonna ask &amp; may have a plan",
  "id" : 925849140021678082,
  "in_reply_to_status_id" : 925843936182226944,
  "created_at" : "2017-11-01 22:16:51 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "indices" : [ 3, 15 ],
      "id_str" : "1122883339",
      "id" : 1122883339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drones",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/JVStcwf6a4",
      "expanded_url" : "http:\/\/ift.tt\/2z6xa8i",
      "display_url" : "ift.tt\/2z6xa8i"
    } ]
  },
  "geo" : { },
  "id_str" : "925844305851363328",
  "text" : "RT @dronepilots: Heartland's Drones Speaker Sees Upside In Disruption - WGLT News | DronePilots - https:\/\/t.co\/JVStcwf6a4 #drones",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drones",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/JVStcwf6a4",
        "expanded_url" : "http:\/\/ift.tt\/2z6xa8i",
        "display_url" : "ift.tt\/2z6xa8i"
      } ]
    },
    "geo" : { },
    "id_str" : "925820342844776448",
    "text" : "Heartland's Drones Speaker Sees Upside In Disruption - WGLT News | DronePilots - https:\/\/t.co\/JVStcwf6a4 #drones",
    "id" : 925820342844776448,
    "created_at" : "2017-11-01 20:22:25 +0000",
    "user" : {
      "name" : "DronePilots",
      "screen_name" : "dronepilots",
      "protected" : false,
      "id_str" : "1122883339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614930406333218816\/gDo8WYMM_normal.png",
      "id" : 1122883339,
      "verified" : false
    }
  },
  "id" : 925844305851363328,
  "created_at" : "2017-11-01 21:57:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/RqOxm5zNzT",
      "expanded_url" : "https:\/\/www.diyphotography.net\/outex-launches-clear-lightweight-modular-underwater-housing-fits-camera-bag\/",
      "display_url" : "diyphotography.net\/outex-launches\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925844253674176512",
  "text" : "RT @JayHoque: Outex launches clear, lightweight and modular underwater housing that fits in any camera bag: https:\/\/t.co\/RqOxm5zNzT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/RqOxm5zNzT",
        "expanded_url" : "https:\/\/www.diyphotography.net\/outex-launches-clear-lightweight-modular-underwater-housing-fits-camera-bag\/",
        "display_url" : "diyphotography.net\/outex-launches\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925829410263007233",
    "text" : "Outex launches clear, lightweight and modular underwater housing that fits in any camera bag: https:\/\/t.co\/RqOxm5zNzT",
    "id" : 925829410263007233,
    "created_at" : "2017-11-01 20:58:27 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 925844253674176512,
  "created_at" : "2017-11-01 21:57:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925844233612820480",
  "text" : "RT @BarbaraCorcoran: Don\u2019t moan and groan or bitch\u2014I\u2019ve never tolerated that, because it\u2019s contagious.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925843690844835841",
    "text" : "Don\u2019t moan and groan or bitch\u2014I\u2019ve never tolerated that, because it\u2019s contagious.",
    "id" : 925843690844835841,
    "created_at" : "2017-11-01 21:55:11 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 925844233612820480,
  "created_at" : "2017-11-01 21:57:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    }, {
      "name" : "Opendesk",
      "screen_name" : "open_desk",
      "indices" : [ 18, 28 ],
      "id_str" : "1420775173",
      "id" : 1420775173
    }, {
      "name" : "Anne Filson",
      "screen_name" : "aefilson",
      "indices" : [ 62, 71 ],
      "id_str" : "819966704516206593",
      "id" : 819966704516206593
    }, {
      "name" : "Gary Rohrbacher",
      "screen_name" : "gary_rohrbacher",
      "indices" : [ 74, 90 ],
      "id_str" : "2435482436",
      "id" : 2435482436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/zepOPoOaId",
      "expanded_url" : "http:\/\/ht.ly\/Mo3W30ghOAT",
      "display_url" : "ht.ly\/Mo3W30ghOAT"
    } ]
  },
  "geo" : { },
  "id_str" : "925844205393661954",
  "text" : "RT @make: Amazing @open_desk blog w\/ 'Design for CNC' authors @aefilson + @gary_rohrbacher https:\/\/t.co\/zepOPoOaId",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Opendesk",
        "screen_name" : "open_desk",
        "indices" : [ 8, 18 ],
        "id_str" : "1420775173",
        "id" : 1420775173
      }, {
        "name" : "Anne Filson",
        "screen_name" : "aefilson",
        "indices" : [ 52, 61 ],
        "id_str" : "819966704516206593",
        "id" : 819966704516206593
      }, {
        "name" : "Gary Rohrbacher",
        "screen_name" : "gary_rohrbacher",
        "indices" : [ 64, 80 ],
        "id_str" : "2435482436",
        "id" : 2435482436
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/zepOPoOaId",
        "expanded_url" : "http:\/\/ht.ly\/Mo3W30ghOAT",
        "display_url" : "ht.ly\/Mo3W30ghOAT"
      } ]
    },
    "geo" : { },
    "id_str" : "925826081948684288",
    "text" : "Amazing @open_desk blog w\/ 'Design for CNC' authors @aefilson + @gary_rohrbacher https:\/\/t.co\/zepOPoOaId",
    "id" : 925826081948684288,
    "created_at" : "2017-11-01 20:45:13 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 925844205393661954,
  "created_at" : "2017-11-01 21:57:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925844187941081088",
  "text" : "RT @ChemistryWorld: A total synthesis that showcases a modern take on the vinylcyclopropane annulation as its key step https:\/\/t.co\/dfV9AAo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/dfV9AAoS6o",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/opinion\/-pavidolide-b\/3008139.article",
        "display_url" : "chemistryworld.com\/opinion\/-pavid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925829813553770498",
    "text" : "A total synthesis that showcases a modern take on the vinylcyclopropane annulation as its key step https:\/\/t.co\/dfV9AAoS6o",
    "id" : 925829813553770498,
    "created_at" : "2017-11-01 21:00:03 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 925844187941081088,
  "created_at" : "2017-11-01 21:57:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechnoBabble",
      "screen_name" : "LiquidPanic",
      "indices" : [ 3, 15 ],
      "id_str" : "3377039805",
      "id" : 3377039805
    }, {
      "name" : "GoldenLag",
      "screen_name" : "LaggingCentral",
      "indices" : [ 17, 32 ],
      "id_str" : "2521121788",
      "id" : 2521121788
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 33, 45 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Linus Tech Tips",
      "screen_name" : "LinusTech",
      "indices" : [ 46, 56 ],
      "id_str" : "403614288",
      "id" : 403614288
    }, {
      "name" : "jake",
      "screen_name" : "jakkuh_t",
      "indices" : [ 57, 66 ],
      "id_str" : "593326286",
      "id" : 593326286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925843949696225280",
  "text" : "RT @LiquidPanic: @LaggingCentral @gamer456148 @LinusTech @jakkuh_t That entirely depends on the cryptocurrency and the mining algorithms it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GoldenLag",
        "screen_name" : "LaggingCentral",
        "indices" : [ 0, 15 ],
        "id_str" : "2521121788",
        "id" : 2521121788
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 16, 28 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Linus Tech Tips",
        "screen_name" : "LinusTech",
        "indices" : [ 29, 39 ],
        "id_str" : "403614288",
        "id" : 403614288
      }, {
        "name" : "jake",
        "screen_name" : "jakkuh_t",
        "indices" : [ 40, 49 ],
        "id_str" : "593326286",
        "id" : 593326286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "925619035227684864",
    "geo" : { },
    "id_str" : "925825106177286144",
    "in_reply_to_user_id" : 2521121788,
    "text" : "@LaggingCentral @gamer456148 @LinusTech @jakkuh_t That entirely depends on the cryptocurrency and the mining algorithms it uses. There are plenty out there where CPUs are better.",
    "id" : 925825106177286144,
    "in_reply_to_status_id" : 925619035227684864,
    "created_at" : "2017-11-01 20:41:20 +0000",
    "in_reply_to_screen_name" : "LaggingCentral",
    "in_reply_to_user_id_str" : "2521121788",
    "user" : {
      "name" : "TechnoBabble",
      "screen_name" : "LiquidPanic",
      "protected" : false,
      "id_str" : "3377039805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806757280339267584\/BcgTlqWq_normal.jpg",
      "id" : 3377039805,
      "verified" : false
    }
  },
  "id" : 925843949696225280,
  "created_at" : "2017-11-01 21:56:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/925843936182226944\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/TvBrt8XHLb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNlCJPIXcAE1VJb.jpg",
      "id_str" : "925843924849225729",
      "id" : 925843924849225729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNlCJPIXcAE1VJb.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/TvBrt8XHLb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925843936182226944",
  "text" : "Needed to install setup files https:\/\/t.co\/TvBrt8XHLb",
  "id" : 925843936182226944,
  "created_at" : "2017-11-01 21:56:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bitcoin Magazine",
      "screen_name" : "BitcoinMagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "361289499",
      "id" : 361289499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blockchain",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "smartcontracts",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/DDbb55GN3G",
      "expanded_url" : "https:\/\/bitcoinmagazine.com\/articles\/op-ed-three-legal-pitfalls-avoid-blockchain-smart-contracts\/",
      "display_url" : "bitcoinmagazine.com\/articles\/op-ed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925805712063762432",
  "text" : "RT @BitcoinMagazine: Op Ed: Three Legal Pitfalls to Avoid in #Blockchain Smart Contracts https:\/\/t.co\/DDbb55GN3G #smartcontracts #blockchai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blockchain",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "smartcontracts",
        "indices" : [ 92, 107 ]
      }, {
        "text" : "blockchains",
        "indices" : [ 108, 120 ]
      }, {
        "text" : "LegalTech",
        "indices" : [ 121, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/DDbb55GN3G",
        "expanded_url" : "https:\/\/bitcoinmagazine.com\/articles\/op-ed-three-legal-pitfalls-avoid-blockchain-smart-contracts\/",
        "display_url" : "bitcoinmagazine.com\/articles\/op-ed\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925780322914054144",
    "text" : "Op Ed: Three Legal Pitfalls to Avoid in #Blockchain Smart Contracts https:\/\/t.co\/DDbb55GN3G #smartcontracts #blockchains #LegalTech",
    "id" : 925780322914054144,
    "created_at" : "2017-11-01 17:43:23 +0000",
    "user" : {
      "name" : "Bitcoin Magazine",
      "screen_name" : "BitcoinMagazine",
      "protected" : false,
      "id_str" : "361289499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927697522583154688\/5UbrDpS7_normal.jpg",
      "id" : 361289499,
      "verified" : true
    }
  },
  "id" : 925805712063762432,
  "created_at" : "2017-11-01 19:24:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "indices" : [ 3, 16 ],
      "id_str" : "17064514",
      "id" : 17064514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Halloween",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/3B5s1fq4rJ",
      "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/best-pc-cases,4183.html#xtor=RSS-100",
      "display_url" : "tomshardware.com\/reviews\/best-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925805205958070278",
  "text" : "RT @tomshardware: \uD83C\uDF83 Best Cases https:\/\/t.co\/3B5s1fq4rJ #Halloween",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Halloween",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/3B5s1fq4rJ",
        "expanded_url" : "http:\/\/www.tomshardware.com\/reviews\/best-pc-cases,4183.html#xtor=RSS-100",
        "display_url" : "tomshardware.com\/reviews\/best-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925800143835709441",
    "text" : "\uD83C\uDF83 Best Cases https:\/\/t.co\/3B5s1fq4rJ #Halloween",
    "id" : 925800143835709441,
    "created_at" : "2017-11-01 19:02:09 +0000",
    "user" : {
      "name" : "Tom's Hardware",
      "screen_name" : "tomshardware",
      "protected" : false,
      "id_str" : "17064514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896131473236869120\/tKFWGj5d_normal.jpg",
      "id" : 17064514,
      "verified" : true
    }
  },
  "id" : 925805205958070278,
  "created_at" : "2017-11-01 19:22:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 3, 10 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/L03wGFuSo6",
      "expanded_url" : "http:\/\/www.forbes.com\/sites\/noahkirsch\/2017\/11\/01\/papa-johns-founder-net-worth-falls-70-million-in-hours-blames-nfl-protests\/?utm_source=TWITTER&utm_medium=social&utm_term=ViEWS%20Alerts#76616c657269",
      "display_url" : "forbes.com\/sites\/noahkirs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925791932172955648",
  "text" : "RT @Forbes: Papa John Loses Dough: Pizza Chain Founder Loses $70 Million In Hours, Blames NFL https:\/\/t.co\/L03wGFuSo6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.forbes.com\/\" rel=\"nofollow\"\u003EForbes ViEWS Twitter Hook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/L03wGFuSo6",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/noahkirsch\/2017\/11\/01\/papa-johns-founder-net-worth-falls-70-million-in-hours-blames-nfl-protests\/?utm_source=TWITTER&utm_medium=social&utm_term=ViEWS%20Alerts#76616c657269",
        "display_url" : "forbes.com\/sites\/noahkirs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925790415122501633",
    "text" : "Papa John Loses Dough: Pizza Chain Founder Loses $70 Million In Hours, Blames NFL https:\/\/t.co\/L03wGFuSo6",
    "id" : 925790415122501633,
    "created_at" : "2017-11-01 18:23:29 +0000",
    "user" : {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "protected" : false,
      "id_str" : "91478624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882603270484766720\/YFx4Lsh4_normal.jpg",
      "id" : 91478624,
      "verified" : true
    }
  },
  "id" : 925791932172955648,
  "created_at" : "2017-11-01 18:29:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/zxOWjiUj2S",
      "expanded_url" : "http:\/\/engt.co\/2z7gpMO",
      "display_url" : "engt.co\/2z7gpMO"
    } ]
  },
  "geo" : { },
  "id_str" : "925791897536356353",
  "text" : "RT @engadget: Samsung's work-focused Note 8 has better support than your phone https:\/\/t.co\/zxOWjiUj2S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/zxOWjiUj2S",
        "expanded_url" : "http:\/\/engt.co\/2z7gpMO",
        "display_url" : "engt.co\/2z7gpMO"
      } ]
    },
    "geo" : { },
    "id_str" : "925790202995585025",
    "text" : "Samsung's work-focused Note 8 has better support than your phone https:\/\/t.co\/zxOWjiUj2S",
    "id" : 925790202995585025,
    "created_at" : "2017-11-01 18:22:39 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 925791897536356353,
  "created_at" : "2017-11-01 18:29:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925791851776442369",
  "text" : "$BTC hits a $6.6k+ high today! #Bitcoin",
  "id" : 925791851776442369,
  "created_at" : "2017-11-01 18:29:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "UC San Diego",
      "screen_name" : "UCSanDiego",
      "indices" : [ 109, 120 ],
      "id_str" : "338660808",
      "id" : 338660808
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 121, 128 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Microbiome",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "Project",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/0urhVlVNaR",
      "expanded_url" : "http:\/\/phy.so\/428747610",
      "display_url" : "phy.so\/428747610"
    } ]
  },
  "geo" : { },
  "id_str" : "925788252426162177",
  "text" : "RT @physorg_com: Earth #Microbiome #Project: Mapping the microbiome of... everything https:\/\/t.co\/0urhVlVNaR @ucsandiego @nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UC San Diego",
        "screen_name" : "UCSanDiego",
        "indices" : [ 92, 103 ],
        "id_str" : "338660808",
        "id" : 338660808
      }, {
        "name" : "nature",
        "screen_name" : "nature",
        "indices" : [ 104, 111 ],
        "id_str" : "487833518",
        "id" : 487833518
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Microbiome",
        "indices" : [ 6, 17 ]
      }, {
        "text" : "Project",
        "indices" : [ 18, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/0urhVlVNaR",
        "expanded_url" : "http:\/\/phy.so\/428747610",
        "display_url" : "phy.so\/428747610"
      } ]
    },
    "geo" : { },
    "id_str" : "925784529511608321",
    "text" : "Earth #Microbiome #Project: Mapping the microbiome of... everything https:\/\/t.co\/0urhVlVNaR @ucsandiego @nature",
    "id" : 925784529511608321,
    "created_at" : "2017-11-01 18:00:06 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 925788252426162177,
  "created_at" : "2017-11-01 18:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Xm1K8e1rgg",
      "expanded_url" : "http:\/\/depot.ly\/yrHh30ggPPZ",
      "display_url" : "depot.ly\/yrHh30ggPPZ"
    } ]
  },
  "geo" : { },
  "id_str" : "925788184285458437",
  "text" : "RT @DesignerDepot: The Graphcool Framework is now open source https:\/\/t.co\/Xm1K8e1rgg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/Xm1K8e1rgg",
        "expanded_url" : "http:\/\/depot.ly\/yrHh30ggPPZ",
        "display_url" : "depot.ly\/yrHh30ggPPZ"
      } ]
    },
    "geo" : { },
    "id_str" : "925774500565839873",
    "text" : "The Graphcool Framework is now open source https:\/\/t.co\/Xm1K8e1rgg",
    "id" : 925774500565839873,
    "created_at" : "2017-11-01 17:20:15 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 925788184285458437,
  "created_at" : "2017-11-01 18:14:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925788137103724544",
  "text" : "RT @jacksfilms: ugh fine I'll write an award-winning Thanksgiving song",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925787019455819776",
    "text" : "ugh fine I'll write an award-winning Thanksgiving song",
    "id" : 925787019455819776,
    "created_at" : "2017-11-01 18:10:00 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927717097051799552\/zUMLDlBG_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 925788137103724544,
  "created_at" : "2017-11-01 18:14:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925788065683136513",
  "text" : "RT @BarbaraCorcoran: In business, you\u2019re ALWAYS the Chief Salesman!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925751859494768640",
    "text" : "In business, you\u2019re ALWAYS the Chief Salesman!",
    "id" : 925751859494768640,
    "created_at" : "2017-11-01 15:50:17 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 925788065683136513,
  "created_at" : "2017-11-01 18:14:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925788058137583617",
  "text" : "RT @lorenridinger: \u201CIf you don\u2019t find the time, if you don\u2019t do the work, you don\u2019t get the results.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925739610998738945",
    "text" : "\u201CIf you don\u2019t find the time, if you don\u2019t do the work, you don\u2019t get the results.\u201D",
    "id" : 925739610998738945,
    "created_at" : "2017-11-01 15:01:37 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 925788058137583617,
  "created_at" : "2017-11-01 18:14:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925788031327580160",
  "text" : "RT @PFF_Brett: In Terron Armsteads first game back from his shoulder injury, he earned an 81.0 game grade and didnt allow a pressure in pas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925775402693521408",
    "text" : "In Terron Armsteads first game back from his shoulder injury, he earned an 81.0 game grade and didnt allow a pressure in pass protection.",
    "id" : 925775402693521408,
    "created_at" : "2017-11-01 17:23:50 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920477903309230081\/lu_lxlxH_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 925788031327580160,
  "created_at" : "2017-11-01 18:14:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/I4mc6GEhIn",
      "expanded_url" : "https:\/\/fstoppers.com\/aerial\/six-quick-drone-photography-tips-beginners-201927?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/aerial\/six-qui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925787979716681733",
  "text" : "RT @JayHoque: Six Quick Drone Photography Tips for Beginners: https:\/\/t.co\/I4mc6GEhIn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/I4mc6GEhIn",
        "expanded_url" : "https:\/\/fstoppers.com\/aerial\/six-quick-drone-photography-tips-beginners-201927?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/aerial\/six-qui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925787829061476354",
    "text" : "Six Quick Drone Photography Tips for Beginners: https:\/\/t.co\/I4mc6GEhIn",
    "id" : 925787829061476354,
    "created_at" : "2017-11-01 18:13:13 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 925787979716681733,
  "created_at" : "2017-11-01 18:13:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dev",
      "indices" : [ 104, 108 ]
    }, {
      "text" : "cryptocurrency",
      "indices" : [ 109, 124 ]
    }, {
      "text" : "blockchain",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925787905834016770",
  "text" : "Updated and added a Git repo to CrowdCoin-Team. Progress being made and discovering new things everyday #dev #cryptocurrency #blockchain",
  "id" : 925787905834016770,
  "created_at" : "2017-11-01 18:13:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/GNdcJtEZDF",
      "expanded_url" : "http:\/\/depot.ly\/VrbW30ggPOJ",
      "display_url" : "depot.ly\/VrbW30ggPOJ"
    } ]
  },
  "geo" : { },
  "id_str" : "925729216544505856",
  "text" : "RT @DesignerDepot: UI\/UX: \"Realistic\" 3D Weather App https:\/\/t.co\/GNdcJtEZDF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/GNdcJtEZDF",
        "expanded_url" : "http:\/\/depot.ly\/VrbW30ggPOJ",
        "display_url" : "depot.ly\/VrbW30ggPOJ"
      } ]
    },
    "geo" : { },
    "id_str" : "925683891964391425",
    "text" : "UI\/UX: \"Realistic\" 3D Weather App https:\/\/t.co\/GNdcJtEZDF",
    "id" : 925683891964391425,
    "created_at" : "2017-11-01 11:20:12 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709570614307069952\/b0L1KWrC_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 925729216544505856,
  "created_at" : "2017-11-01 14:20:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "indices" : [ 3, 18 ],
      "id_str" : "26250872",
      "id" : 26250872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925728631879593984",
  "text" : "RT @ChemistryWorld: Ink that can be chemically switched to reveal or hide messages could improve encryption of confidential documents https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/neUTaADHFR",
        "expanded_url" : "https:\/\/www.chemistryworld.com\/matter\/next-generation-invisible-ink-revealed\/3008215.article",
        "display_url" : "chemistryworld.com\/matter\/next-ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925718067191140352",
    "text" : "Ink that can be chemically switched to reveal or hide messages could improve encryption of confidential documents https:\/\/t.co\/neUTaADHFR",
    "id" : 925718067191140352,
    "created_at" : "2017-11-01 13:36:00 +0000",
    "user" : {
      "name" : "Chemistry World",
      "screen_name" : "ChemistryWorld",
      "protected" : false,
      "id_str" : "26250872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875365794745638919\/he2breqo_normal.jpg",
      "id" : 26250872,
      "verified" : true
    }
  },
  "id" : 925728631879593984,
  "created_at" : "2017-11-01 14:17:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "arXiv.org",
      "screen_name" : "arxiv",
      "indices" : [ 124, 130 ],
      "id_str" : "808633423300624384",
      "id" : 808633423300624384
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kepler",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "data",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/XKkOECWGFu",
      "expanded_url" : "http:\/\/phy.so\/428744412",
      "display_url" : "phy.so\/428744412"
    } ]
  },
  "geo" : { },
  "id_str" : "925728520411795457",
  "text" : "RT @physorg_com: #Kepler #data reveals existence of 20 promising exoplanets 'hiding in plain sight' https:\/\/t.co\/XKkOECWGFu @arxiv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "arXiv.org",
        "screen_name" : "arxiv",
        "indices" : [ 107, 113 ],
        "id_str" : "808633423300624384",
        "id" : 808633423300624384
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kepler",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "data",
        "indices" : [ 8, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/XKkOECWGFu",
        "expanded_url" : "http:\/\/phy.so\/428744412",
        "display_url" : "phy.so\/428744412"
      } ]
    },
    "geo" : { },
    "id_str" : "925706495882399744",
    "text" : "#Kepler #data reveals existence of 20 promising exoplanets 'hiding in plain sight' https:\/\/t.co\/XKkOECWGFu @arxiv",
    "id" : 925706495882399744,
    "created_at" : "2017-11-01 12:50:02 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 925728520411795457,
  "created_at" : "2017-11-01 14:17:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Butcher",
      "screen_name" : "DaniSButcher",
      "indices" : [ 3, 16 ],
      "id_str" : "400599700",
      "id" : 400599700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925728002306199552",
  "text" : "RT @DaniSButcher: My phone is at 12% at 10 AM what is happening",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925380225562808320",
    "text" : "My phone is at 12% at 10 AM what is happening",
    "id" : 925380225562808320,
    "created_at" : "2017-10-31 15:13:33 +0000",
    "user" : {
      "name" : "Danielle Butcher",
      "screen_name" : "DaniSButcher",
      "protected" : false,
      "id_str" : "400599700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925575178842726400\/fsRaiTpW_normal.jpg",
      "id" : 400599700,
      "verified" : false
    }
  },
  "id" : 925728002306199552,
  "created_at" : "2017-11-01 14:15:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/YUsUMNXqIc",
      "expanded_url" : "https:\/\/petapixel.com\/2017\/10\/31\/review-polaroid-originals-onestep-2-familiar-exciting\/",
      "display_url" : "petapixel.com\/2017\/10\/31\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925727946563866625",
  "text" : "RT @JayHoque: Review: Polaroid Originals\u2019 OneStep 2 is Familiar and Exciting: https:\/\/t.co\/YUsUMNXqIc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/YUsUMNXqIc",
        "expanded_url" : "https:\/\/petapixel.com\/2017\/10\/31\/review-polaroid-originals-onestep-2-familiar-exciting\/",
        "display_url" : "petapixel.com\/2017\/10\/31\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925389193974513664",
    "text" : "Review: Polaroid Originals\u2019 OneStep 2 is Familiar and Exciting: https:\/\/t.co\/YUsUMNXqIc",
    "id" : 925389193974513664,
    "created_at" : "2017-10-31 15:49:11 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908224428173139970\/i9Ef8YYo_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 925727946563866625,
  "created_at" : "2017-11-01 14:15:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925727910308261888",
  "text" : "RT @lorenridinger: \"Formal education will make you a living; self-education will make you a fortune.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925301610267512833",
    "text" : "\"Formal education will make you a living; self-education will make you a fortune.\"",
    "id" : 925301610267512833,
    "created_at" : "2017-10-31 10:01:09 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 925727910308261888,
  "created_at" : "2017-11-01 14:15:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Blurt Foundation",
      "screen_name" : "BlurtAlerts",
      "indices" : [ 3, 15 ],
      "id_str" : "276911876",
      "id" : 276911876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925727826455814144",
  "text" : "RT @BlurtAlerts: \u201CI know who I am, I know what I believe, and that\u2019s all I need to know\u201D \u2013 Will Smith",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925724491212312577",
    "text" : "\u201CI know who I am, I know what I believe, and that\u2019s all I need to know\u201D \u2013 Will Smith",
    "id" : 925724491212312577,
    "created_at" : "2017-11-01 14:01:32 +0000",
    "user" : {
      "name" : "The Blurt Foundation",
      "screen_name" : "BlurtAlerts",
      "protected" : false,
      "id_str" : "276911876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785743040250019840\/Z09zY21J_normal.jpg",
      "id" : 276911876,
      "verified" : true
    }
  },
  "id" : 925727826455814144,
  "created_at" : "2017-11-01 14:14:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "indices" : [ 3, 14 ],
      "id_str" : "36912323",
      "id" : 36912323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/a1VZYbpe7e",
      "expanded_url" : "http:\/\/feeds.reuters.com\/~r\/reuters\/UKVideoTechnology\/~3\/VNY7LyO5rzM\/electric-flight",
      "display_url" : "feeds.reuters.com\/~r\/reuters\/UKV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925727654191489024",
  "text" : "RT @grattonboy: Electric flight https:\/\/t.co\/a1VZYbpe7e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/a1VZYbpe7e",
        "expanded_url" : "http:\/\/feeds.reuters.com\/~r\/reuters\/UKVideoTechnology\/~3\/VNY7LyO5rzM\/electric-flight",
        "display_url" : "feeds.reuters.com\/~r\/reuters\/UKV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925724781160423424",
    "text" : "Electric flight https:\/\/t.co\/a1VZYbpe7e",
    "id" : 925724781160423424,
    "created_at" : "2017-11-01 14:02:41 +0000",
    "user" : {
      "name" : "Dean Anthony Gratton",
      "screen_name" : "grattonboy",
      "protected" : false,
      "id_str" : "36912323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819521494371934208\/8cPchIQ-_normal.jpg",
      "id" : 36912323,
      "verified" : true
    }
  },
  "id" : 925727654191489024,
  "created_at" : "2017-11-01 14:14:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925727553406595073",
  "text" : "RT @buysellshort: $HMNY alert bottom yesterday ran to $11+, $LBIX alert under $1.50 ran to $2.15, $WPCS alert run to....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "925725042763169798",
    "text" : "$HMNY alert bottom yesterday ran to $11+, $LBIX alert under $1.50 ran to $2.15, $WPCS alert run to....",
    "id" : 925725042763169798,
    "created_at" : "2017-11-01 14:03:43 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : false,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 925727553406595073,
  "created_at" : "2017-11-01 14:13:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/sGKHevMRgd",
      "expanded_url" : "http:\/\/engt.co\/2z4Absm",
      "display_url" : "engt.co\/2z4Absm"
    } ]
  },
  "geo" : { },
  "id_str" : "925727480887078912",
  "text" : "RT @engadget: 'Concrete Genie' is a game about bullying and street art https:\/\/t.co\/sGKHevMRgd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/sGKHevMRgd",
        "expanded_url" : "http:\/\/engt.co\/2z4Absm",
        "display_url" : "engt.co\/2z4Absm"
      } ]
    },
    "geo" : { },
    "id_str" : "925725683602554886",
    "text" : "'Concrete Genie' is a game about bullying and street art https:\/\/t.co\/sGKHevMRgd",
    "id" : 925725683602554886,
    "created_at" : "2017-11-01 14:06:16 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 925727480887078912,
  "created_at" : "2017-11-01 14:13:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/WH1Nglqwk0",
      "expanded_url" : "https:\/\/twitter.com\/LaggingCentral\/status\/925619035227684864",
      "display_url" : "twitter.com\/LaggingCentral\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925727198396534785",
  "text" : "It is unless you were talking about mining Bytecoin or am Asic based crypto. Then having multiple CPU cores can perform really well. https:\/\/t.co\/WH1Nglqwk0",
  "id" : 925727198396534785,
  "created_at" : "2017-11-01 14:12:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Peters",
      "screen_name" : "StandardofTrust",
      "indices" : [ 3, 19 ],
      "id_str" : "15734989",
      "id" : 15734989
    }, {
      "name" : "AMD1\u2022ILLUMINATED",
      "screen_name" : "AMD1_CEO",
      "indices" : [ 49, 58 ],
      "id_str" : "80413939",
      "id" : 80413939
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 60, 72 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "kiddle",
      "screen_name" : "WorldBambino",
      "indices" : [ 74, 87 ],
      "id_str" : "4828257199",
      "id" : 4828257199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/t3aIuaQJIu",
      "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=004baa309cf42874982ae6a0",
      "display_url" : "sumall.com\/thankyou?utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925726930372124673",
  "text" : "RT @StandardofTrust: Our biggest fans this week: @AMD1_CEO, @gamer456148, @WorldBambino. Thank you! via https:\/\/t.co\/t3aIuaQJIu https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sumall.com\/\" rel=\"nofollow\"\u003ESumAll Authentication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMD1\u2022ILLUMINATED",
        "screen_name" : "AMD1_CEO",
        "indices" : [ 28, 37 ],
        "id_str" : "80413939",
        "id" : 80413939
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 39, 51 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "kiddle",
        "screen_name" : "WorldBambino",
        "indices" : [ 53, 66 ],
        "id_str" : "4828257199",
        "id" : 4828257199
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StandardofTrust\/status\/925724174127190016\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/MNyFrrsLf1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNjVOnWXkAEpN3Y.jpg",
        "id_str" : "925724170482323457",
        "id" : 925724170482323457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNjVOnWXkAEpN3Y.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/MNyFrrsLf1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/t3aIuaQJIu",
        "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=004baa309cf42874982ae6a0",
        "display_url" : "sumall.com\/thankyou?utm_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925724174127190016",
    "text" : "Our biggest fans this week: @AMD1_CEO, @gamer456148, @WorldBambino. Thank you! via https:\/\/t.co\/t3aIuaQJIu https:\/\/t.co\/MNyFrrsLf1",
    "id" : 925724174127190016,
    "created_at" : "2017-11-01 14:00:16 +0000",
    "user" : {
      "name" : "Rob Peters",
      "screen_name" : "StandardofTrust",
      "protected" : false,
      "id_str" : "15734989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506409104865124352\/T7bUV46l_normal.jpeg",
      "id" : 15734989,
      "verified" : false
    }
  },
  "id" : 925726930372124673,
  "created_at" : "2017-11-01 14:11:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "indices" : [ 3, 13 ],
      "id_str" : "289140913",
      "id" : 289140913
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 43, 55 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Kent Lee Platte",
      "screen_name" : "MathBomb",
      "indices" : [ 57, 66 ],
      "id_str" : "306261708",
      "id" : 306261708
    }, {
      "name" : "PFF DET Lions",
      "screen_name" : "PFF_Detroit",
      "indices" : [ 68, 80 ],
      "id_str" : "901501523267551234",
      "id" : 901501523267551234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/KQSub7DMfE",
      "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=49d7a0aded1e25c4d2f3ac42",
      "display_url" : "sumall.com\/thankyou?utm_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925726903939497984",
  "text" : "RT @PFF_Brett: Our biggest fans this week: @gamer456148, @MathBomb, @PFF_Detroit. Thank you! via https:\/\/t.co\/KQSub7DMfE https:\/\/t.co\/hVzkQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sumall.com\/\" rel=\"nofollow\"\u003ESumAll Authentication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 28, 40 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Kent Lee Platte",
        "screen_name" : "MathBomb",
        "indices" : [ 42, 51 ],
        "id_str" : "306261708",
        "id" : 306261708
      }, {
        "name" : "PFF DET Lions",
        "screen_name" : "PFF_Detroit",
        "indices" : [ 53, 65 ],
        "id_str" : "901501523267551234",
        "id" : 901501523267551234
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PFF_Brett\/status\/925709069285036032\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/hVzkQBwJJS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNjHfcUV4AAce5i.jpg",
        "id_str" : "925709066416021504",
        "id" : 925709066416021504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNjHfcUV4AAce5i.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 756
        } ],
        "display_url" : "pic.twitter.com\/hVzkQBwJJS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/KQSub7DMfE",
        "expanded_url" : "https:\/\/sumall.com\/thankyou?utm_source=twitter&utm_medium=publishing&utm_campaign=thank_you_tweet&utm_content=text_and_media&utm_term=49d7a0aded1e25c4d2f3ac42",
        "display_url" : "sumall.com\/thankyou?utm_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925709069285036032",
    "text" : "Our biggest fans this week: @gamer456148, @MathBomb, @PFF_Detroit. Thank you! via https:\/\/t.co\/KQSub7DMfE https:\/\/t.co\/hVzkQBwJJS",
    "id" : 925709069285036032,
    "created_at" : "2017-11-01 13:00:15 +0000",
    "user" : {
      "name" : "Brett Whitefield",
      "screen_name" : "PFF_Brett",
      "protected" : false,
      "id_str" : "289140913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920477903309230081\/lu_lxlxH_normal.jpg",
      "id" : 289140913,
      "verified" : false
    }
  },
  "id" : 925726903939497984,
  "created_at" : "2017-11-01 14:11:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]