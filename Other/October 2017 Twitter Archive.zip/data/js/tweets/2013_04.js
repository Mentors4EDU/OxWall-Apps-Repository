Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328631147393318913",
  "text" : "Talked to Jenna B. Been long time since I heard her voice and she is just amazing!!!! LOL",
  "id" : 328631147393318913,
  "created_at" : "2013-04-28 22:05:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/NnPj4mGJ2A",
      "expanded_url" : "http:\/\/youtu.be\/4DqbUygITBU?a",
      "display_url" : "youtu.be\/4DqbUygITBU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "328346511136145408",
  "text" : "However I don't think it is right to call a catholic priest gay, or satanic. I thinks it was (@YouTube http:\/\/t.co\/NnPj4mGJ2A)",
  "id" : 328346511136145408,
  "created_at" : "2013-04-28 03:14:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/NnPj4mGJ2A",
      "expanded_url" : "http:\/\/youtu.be\/4DqbUygITBU?a",
      "display_url" : "youtu.be\/4DqbUygITBU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "328346092129382400",
  "text" : "What I found interesting is that the first jesuits said that Jews can't be christians and if (@YouTube http:\/\/t.co\/NnPj4mGJ2A)",
  "id" : 328346092129382400,
  "created_at" : "2013-04-28 03:13:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/gODxbZPmi7",
      "expanded_url" : "http:\/\/youtu.be\/ncPLnmIMsCs?a",
      "display_url" : "youtu.be\/ncPLnmIMsCs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "327495357779046401",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/gODxbZPmi7 Amazing Miracle, Face Appears Next to Image of Jesus",
  "id" : 327495357779046401,
  "created_at" : "2013-04-25 18:52:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327412371083624449",
  "text" : "I love being Coptic",
  "id" : 327412371083624449,
  "created_at" : "2013-04-25 13:22:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327412296202743808",
  "text" : "I deleted that Disgusting and Evil Liberal Media playlist, I think I already made my point, that Liberals disgust me LOL",
  "id" : 327412296202743808,
  "created_at" : "2013-04-25 13:22:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327192112066093056",
  "text" : "Hmf",
  "id" : 327192112066093056,
  "created_at" : "2013-04-24 22:47:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327190670345371649",
  "text" : "I miss Jenna B so much last time I talked to her was a week ago to say happy Easter. Lol",
  "id" : 327190670345371649,
  "created_at" : "2013-04-24 22:41:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/T87NQqsvw3",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/make-my-book-into-a-movie\/x\/3066576?c=gallery",
      "display_url" : "indiegogo.com\/projects\/make-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327169722573520897",
  "text" : "Please Help\nhttp:\/\/t.co\/T87NQqsvw3",
  "id" : 327169722573520897,
  "created_at" : "2013-04-24 21:18:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/DqmRBoFzMO",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/help-me-promote-my-book",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327108867437756417",
  "text" : "Help me\nhttp:\/\/t.co\/DqmRBoFzMO",
  "id" : 327108867437756417,
  "created_at" : "2013-04-24 17:16:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/DqmRBoFzMO",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/help-me-promote-my-book",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327108835485552640",
  "text" : "Check out my funding \nhttp:\/\/t.co\/DqmRBoFzMO",
  "id" : 327108835485552640,
  "created_at" : "2013-04-24 17:16:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seoclerks",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/UWSWcas79r",
      "expanded_url" : "http:\/\/x.co\/ysVQ",
      "display_url" : "x.co\/ysVQ"
    } ]
  },
  "geo" : { },
  "id_str" : "326148123925819393",
  "text" : "The only affordable SEO solution http:\/\/t.co\/UWSWcas79r #seoclerks",
  "id" : 326148123925819393,
  "created_at" : "2013-04-22 01:39:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "seoclerks",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/5JFnA1ToSP",
      "expanded_url" : "http:\/\/www.seoclerks.com\/reviews",
      "display_url" : "seoclerks.com\/reviews"
    } ]
  },
  "geo" : { },
  "id_str" : "326147816307167232",
  "text" : "Blog reviews are the best way to dominate google and get traffic - http:\/\/t.co\/5JFnA1ToSP #seoclerks",
  "id" : 326147816307167232,
  "created_at" : "2013-04-22 01:37:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325425691652935680",
  "text" : "Lol Taliban's pissed, finally the suspect been caught",
  "id" : 325425691652935680,
  "created_at" : "2013-04-20 01:48:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325420616310206464",
  "text" : "God bless conservatives",
  "id" : 325420616310206464,
  "created_at" : "2013-04-20 01:28:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325420529496498176",
  "text" : "I am so happy",
  "id" : 325420529496498176,
  "created_at" : "2013-04-20 01:27:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325420475054448640",
  "text" : "Finally the criminal is caught",
  "id" : 325420475054448640,
  "created_at" : "2013-04-20 01:27:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZDDgey2Ca3",
      "expanded_url" : "http:\/\/youtu.be\/0lgTvAMP2Ak?a",
      "display_url" : "youtu.be\/0lgTvAMP2Ak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "325289537200869376",
  "text" : "Yes but this is the Youtube Channel of the guy, it doesn't matter, his brother is on it right (@YouTube http:\/\/t.co\/ZDDgey2Ca3)",
  "id" : 325289537200869376,
  "created_at" : "2013-04-19 16:47:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shauna Case",
      "screen_name" : "ShaunaCase",
      "indices" : [ 0, 11 ],
      "id_str" : "354589747",
      "id" : 354589747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325076717775511553",
  "in_reply_to_user_id" : 354589747,
  "text" : "@ShaunaCase Need help with Youtube, I offer Youtube Partnerships to people",
  "id" : 325076717775511553,
  "created_at" : "2013-04-19 02:41:43 +0000",
  "in_reply_to_screen_name" : "ShaunaCase",
  "in_reply_to_user_id_str" : "354589747",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 47, 55 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/kqoTZec54k",
      "expanded_url" : "http:\/\/youtu.be\/kMDj7mM3qso?a",
      "display_url" : "youtu.be\/kMDj7mM3qso?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324868159872069632",
  "text" : "Yesterday was the real date for Easter LOL!!! (@YouTube http:\/\/t.co\/kqoTZec54k)",
  "id" : 324868159872069632,
  "created_at" : "2013-04-18 12:52:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/kqoTZec54k",
      "expanded_url" : "http:\/\/youtu.be\/kMDj7mM3qso?a",
      "display_url" : "youtu.be\/kMDj7mM3qso?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324868115378864128",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/kqoTZec54k Happy Easter",
  "id" : 324868115378864128,
  "created_at" : "2013-04-18 12:52:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324720298081521664",
  "text" : "I love Yeshua",
  "id" : 324720298081521664,
  "created_at" : "2013-04-18 03:05:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324720172197875712",
  "text" : "Hmm",
  "id" : 324720172197875712,
  "created_at" : "2013-04-18 03:04:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324720147128520705",
  "text" : "Illuminati is creepy people who are responsible with 9\/11, Boston Attacks, and Liberal media according to some sources, what do you think?",
  "id" : 324720147128520705,
  "created_at" : "2013-04-18 03:04:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 15, 23 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/KflDkFWFT8",
      "expanded_url" : "http:\/\/youtu.be\/xo_MYmA-O0M?a",
      "display_url" : "youtu.be\/xo_MYmA-O0M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324700132945825794",
  "text" : "God bless you (@YouTube http:\/\/t.co\/KflDkFWFT8)",
  "id" : 324700132945825794,
  "created_at" : "2013-04-18 01:45:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 24, 32 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/KgfW2qrS8J",
      "expanded_url" : "http:\/\/youtu.be\/Q6jX5XKb2Y8?a",
      "display_url" : "youtu.be\/Q6jX5XKb2Y8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324699905534857217",
  "text" : "God bless fellow Copts (@YouTube http:\/\/t.co\/KgfW2qrS8J)",
  "id" : 324699905534857217,
  "created_at" : "2013-04-18 01:44:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/5oRQohFCoP",
      "expanded_url" : "http:\/\/youtu.be\/9WigVkLCtts?a",
      "display_url" : "youtu.be\/9WigVkLCtts?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324699279165898752",
  "text" : "sorry libe was cut short but you get the point police and people are brutal sometimes and i (@YouTube http:\/\/t.co\/5oRQohFCoP)",
  "id" : 324699279165898752,
  "created_at" : "2013-04-18 01:41:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5oRQohFCoP",
      "expanded_url" : "http:\/\/youtu.be\/9WigVkLCtts?a",
      "display_url" : "youtu.be\/9WigVkLCtts?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324698815800160257",
  "text" : "one time a school called the cops on my for bieng egyption, they called the sherrif. I think (@YouTube http:\/\/t.co\/5oRQohFCoP)",
  "id" : 324698815800160257,
  "created_at" : "2013-04-18 01:40:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/kqoTZec54k",
      "expanded_url" : "http:\/\/youtu.be\/kMDj7mM3qso?a",
      "display_url" : "youtu.be\/kMDj7mM3qso?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324518425420505088",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/kqoTZec54k Happy Easter",
  "id" : 324518425420505088,
  "created_at" : "2013-04-17 13:43:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/kqoTZec54k",
      "expanded_url" : "http:\/\/youtu.be\/kMDj7mM3qso?a",
      "display_url" : "youtu.be\/kMDj7mM3qso?a"
    } ]
  },
  "geo" : { },
  "id_str" : "324517463981182976",
  "text" : "Happy Easter: http:\/\/t.co\/kqoTZec54k via @YouTube",
  "id" : 324517463981182976,
  "created_at" : "2013-04-17 13:39:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/dqlTFveiQV",
      "expanded_url" : "http:\/\/youtu.be\/bxWkZr78Ez0?a",
      "display_url" : "youtu.be\/bxWkZr78Ez0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322910170621558785",
  "text" : "Channel Triller: http:\/\/t.co\/dqlTFveiQV via @YouTube",
  "id" : 322910170621558785,
  "created_at" : "2013-04-13 03:12:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 54, 62 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/7XUvkH4hNm",
      "expanded_url" : "http:\/\/youtu.be\/lB1IaqjIGJE?a",
      "display_url" : "youtu.be\/lB1IaqjIGJE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322801985143324672",
  "text" : "Homosexuality is a choice, and a huge and wicked sin (@YouTube http:\/\/t.co\/7XUvkH4hNm)",
  "id" : 322801985143324672,
  "created_at" : "2013-04-12 20:02:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StMary&StShenouda",
      "screen_name" : "SMASSUK",
      "indices" : [ 0, 8 ],
      "id_str" : "1198621040",
      "id" : 1198621040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322789318550753280",
  "in_reply_to_user_id" : 1198621040,
  "text" : "@SMASSUK St.Mary and St.Shenouda is now part of the coptic broadcasting network on youtube, welcome",
  "id" : 322789318550753280,
  "created_at" : "2013-04-12 19:12:25 +0000",
  "in_reply_to_screen_name" : "SMASSUK",
  "in_reply_to_user_id_str" : "1198621040",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/nMCVDYBl9D",
      "expanded_url" : "http:\/\/youtu.be\/q_3ZvFCJPtg?a",
      "display_url" : "youtu.be\/q_3ZvFCJPtg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322783728122343425",
  "text" : "Beautiful message (@YouTube http:\/\/t.co\/nMCVDYBl9D)",
  "id" : 322783728122343425,
  "created_at" : "2013-04-12 18:50:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "StMary&StShenouda",
      "screen_name" : "SMASSUK",
      "indices" : [ 30, 38 ],
      "id_str" : "1198621040",
      "id" : 1198621040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nMCVDYBl9D",
      "expanded_url" : "http:\/\/youtu.be\/q_3ZvFCJPtg?a",
      "display_url" : "youtu.be\/q_3ZvFCJPtg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322782335152046080",
  "text" : "I liked a @YouTube video from @smassuk http:\/\/t.co\/nMCVDYBl9D Fr. Anthony Messeh | Why Mission?",
  "id" : 322782335152046080,
  "created_at" : "2013-04-12 18:44:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nMCVDYBl9D",
      "expanded_url" : "http:\/\/youtu.be\/q_3ZvFCJPtg?a",
      "display_url" : "youtu.be\/q_3ZvFCJPtg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322780914130239489",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/nMCVDYBl9D Fr. Anthony Messeh | Why Mission?",
  "id" : 322780914130239489,
  "created_at" : "2013-04-12 18:39:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/OKmm8OXC9k",
      "expanded_url" : "http:\/\/sdrv.ms\/14hojOV",
      "display_url" : "sdrv.ms\/14hojOV"
    } ]
  },
  "geo" : { },
  "id_str" : "322713532716179456",
  "text" : "My anger look, LOL http:\/\/t.co\/OKmm8OXC9k",
  "id" : 322713532716179456,
  "created_at" : "2013-04-12 14:11:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WiansSalbR",
      "expanded_url" : "http:\/\/www.appbrain.com\/browse\/dev\/Andrew+Magdy+Kamal",
      "display_url" : "appbrain.com\/browse\/dev\/And\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322445501909856256",
  "text" : "Download my apps:\nhttp:\/\/t.co\/WiansSalbR",
  "id" : 322445501909856256,
  "created_at" : "2013-04-11 20:26:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322219284552118272",
  "text" : "Rock on",
  "id" : 322219284552118272,
  "created_at" : "2013-04-11 05:27:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322059583063474177",
  "text" : "LOL",
  "id" : 322059583063474177,
  "created_at" : "2013-04-10 18:52:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322059528877268992",
  "text" : "Just had a tray smoked salmon flavored sushi, chinese horse radish hurts so bad",
  "id" : 322059528877268992,
  "created_at" : "2013-04-10 18:52:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/sxtq6jb1Ix",
      "expanded_url" : "http:\/\/sdrv.ms\/YkTyEY",
      "display_url" : "sdrv.ms\/YkTyEY"
    } ]
  },
  "geo" : { },
  "id_str" : "322036618007552000",
  "text" : "Just got an encyclopedia of space and a planitarium set, costed less then 9 bucks. http:\/\/t.co\/sxtq6jb1Ix",
  "id" : 322036618007552000,
  "created_at" : "2013-04-10 17:21:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/censeoirt.jill\/\" rel=\"nofollow\"\u003Ecenstjff \u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/OW4TjFrbkW",
      "expanded_url" : "http:\/\/is.gd\/6fEMKc",
      "display_url" : "is.gd\/6fEMKc"
    } ]
  },
  "geo" : { },
  "id_str" : "322013516196376576",
  "in_reply_to_user_id" : 1339897808,
  "text" : "@OliviaJAbello @Payzer_Infinity @AN_DR_EA_S_96  GET MORE FOLLOWERS ? VISIT  - http:\/\/t.co\/OW4TjFrbkW",
  "id" : 322013516196376576,
  "created_at" : "2013-04-10 15:49:39 +0000",
  "in_reply_to_screen_name" : "QUEENOFPAYPIGS_",
  "in_reply_to_user_id_str" : "1339897808",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/censeoirt.jill\/\" rel=\"nofollow\"\u003Ecenstjff \u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ana",
      "screen_name" : "ana_michan",
      "indices" : [ 0, 11 ],
      "id_str" : "2321350053",
      "id" : 2321350053
    }, {
      "name" : "Snapchat famous",
      "screen_name" : "ravens6576",
      "indices" : [ 12, 23 ],
      "id_str" : "1036231855",
      "id" : 1036231855
    }, {
      "name" : "converse.",
      "screen_name" : "sonounelfo",
      "indices" : [ 24, 35 ],
      "id_str" : "595661503",
      "id" : 595661503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/7NYfIC4UC5",
      "expanded_url" : "http:\/\/is.gd\/j3VRmz",
      "display_url" : "is.gd\/j3VRmz"
    } ]
  },
  "geo" : { },
  "id_str" : "322004683981979649",
  "in_reply_to_user_id" : 1220209064,
  "text" : "@ana_michan @ravens6576 @sonounelfo  - EASY WAY TO GET FREE FOLLOWERS  http:\/\/t.co\/7NYfIC4UC5",
  "id" : 322004683981979649,
  "created_at" : "2013-04-10 15:14:33 +0000",
  "in_reply_to_screen_name" : "ObscureDVSN",
  "in_reply_to_user_id_str" : "1220209064",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased858998.com\" rel=\"nofollow\"\u003Eerased858998\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auction Essistance",
      "screen_name" : "Auction_E",
      "indices" : [ 3, 13 ],
      "id_str" : "898888112",
      "id" : 898888112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321996031938134016",
  "text" : "RT @Auction_E: Suspended on eBay, Amazon or Paypal!? At Auction Essistance, we can help!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased858998.com\" rel=\"nofollow\"\u003Eerased858998\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300297455768068097",
    "text" : "Suspended on eBay, Amazon or Paypal!? At Auction Essistance, we can help!",
    "id" : 300297455768068097,
    "created_at" : "2013-02-09 17:37:47 +0000",
    "user" : {
      "name" : "Auction Essistance",
      "screen_name" : "Auction_E",
      "protected" : false,
      "id_str" : "898888112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660902391017934848\/1q4bd_Xh_normal.png",
      "id" : 898888112,
      "verified" : false
    }
  },
  "id" : 321996031938134016,
  "created_at" : "2013-04-10 14:40:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321992483955429377",
  "text" : "I miss Jenna B. so much, LOL",
  "id" : 321992483955429377,
  "created_at" : "2013-04-10 14:26:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321992414497759233",
  "text" : "Guess what Obama's going to give us 15 trillion more debt, and 1 billion more stress, thanks dumb liberal party",
  "id" : 321992414497759233,
  "created_at" : "2013-04-10 14:25:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321992114407886849",
  "text" : "Tax days, oh the stress",
  "id" : 321992114407886849,
  "created_at" : "2013-04-10 14:24:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321854097085038593",
  "text" : "Tweeting is better then facebook",
  "id" : 321854097085038593,
  "created_at" : "2013-04-10 05:16:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321851514282979328",
  "text" : "Wasn't able to go to planet fitness yesterday, but I did get to go grocery shopping with mom",
  "id" : 321851514282979328,
  "created_at" : "2013-04-10 05:05:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321813869720920064",
  "text" : "Live well and prosper",
  "id" : 321813869720920064,
  "created_at" : "2013-04-10 02:36:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321813759041630208",
  "text" : "I miss Jenna :()",
  "id" : 321813759041630208,
  "created_at" : "2013-04-10 02:35:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321813647406034946",
  "text" : "Benjamin Carson is awesome",
  "id" : 321813647406034946,
  "created_at" : "2013-04-10 02:35:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321764957563785216",
  "text" : "Feeling Depressed :(",
  "id" : 321764957563785216,
  "created_at" : "2013-04-09 23:21:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321764876647272448",
  "text" : "Going to Planet Fitness for an hour",
  "id" : 321764876647272448,
  "created_at" : "2013-04-09 23:21:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321462703749226496",
  "text" : "The only way is Jesus Christ if you want to get to heaven",
  "id" : 321462703749226496,
  "created_at" : "2013-04-09 03:20:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/AewrSZWqt1",
      "expanded_url" : "http:\/\/sdrv.ms\/14SQLFQ",
      "display_url" : "sdrv.ms\/14SQLFQ"
    } ]
  },
  "geo" : { },
  "id_str" : "321422540402733057",
  "text" : "Just joined planet fitness with my mom, no more lifetime fitness anymore http:\/\/t.co\/AewrSZWqt1",
  "id" : 321422540402733057,
  "created_at" : "2013-04-09 00:41:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Qw7P0Sd8RU",
      "expanded_url" : "http:\/\/youtu.be\/9ylxRvS8-UY?a",
      "display_url" : "youtu.be\/9ylxRvS8-UY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321327527475953665",
  "text" : "I am Andrew Magdy Kamal, and I am your biggest fan for Man vs. Ball\nCan you mention me in (@YouTube http:\/\/t.co\/Qw7P0Sd8RU)",
  "id" : 321327527475953665,
  "created_at" : "2013-04-08 18:23:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 26, 34 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/tjgRTAFXge",
      "expanded_url" : "http:\/\/youtu.be\/fIdrnbg4P5w?a",
      "display_url" : "youtu.be\/fIdrnbg4P5w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321260916014452737",
  "text" : "Robosapien wins, what!!! (@YouTube http:\/\/t.co\/tjgRTAFXge)",
  "id" : 321260916014452737,
  "created_at" : "2013-04-08 13:59:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 25, 33 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/eixfTJl79m",
      "expanded_url" : "http:\/\/youtu.be\/5BUkBEkLlZc?a",
      "display_url" : "youtu.be\/5BUkBEkLlZc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321260219655131136",
  "text" : "Is this show still live (@YouTube http:\/\/t.co\/eixfTJl79m)",
  "id" : 321260219655131136,
  "created_at" : "2013-04-08 13:56:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 9, 17 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/w9NSLoM3Dy",
      "expanded_url" : "http:\/\/youtu.be\/rCzrBR3cyCg?a",
      "display_url" : "youtu.be\/rCzrBR3cyCg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321259974107996160",
  "text" : "Oh YEAH (@YouTube http:\/\/t.co\/w9NSLoM3Dy)",
  "id" : 321259974107996160,
  "created_at" : "2013-04-08 13:55:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/w9NSLoM3Dy",
      "expanded_url" : "http:\/\/youtu.be\/rCzrBR3cyCg?a",
      "display_url" : "youtu.be\/rCzrBR3cyCg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321258722053738496",
  "text" : "Oh what fun (@YouTube http:\/\/t.co\/w9NSLoM3Dy)",
  "id" : 321258722053738496,
  "created_at" : "2013-04-08 13:50:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/nRBlAL2gSg",
      "expanded_url" : "http:\/\/youtu.be\/9J1nU6Ih1EU?a",
      "display_url" : "youtu.be\/9J1nU6Ih1EU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321258561298628609",
  "text" : "Fight, fight, fight (@YouTube http:\/\/t.co\/nRBlAL2gSg)",
  "id" : 321258561298628609,
  "created_at" : "2013-04-08 13:49:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/DuljzsYOsa",
      "expanded_url" : "http:\/\/youtu.be\/UuB3PyjHQFE?a",
      "display_url" : "youtu.be\/UuB3PyjHQFE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321257630490304512",
  "text" : "I want to participate in this, give me info on how I can, PLEASE (@YouTube http:\/\/t.co\/DuljzsYOsa)",
  "id" : 321257630490304512,
  "created_at" : "2013-04-08 13:46:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/TPqREyio3s",
      "expanded_url" : "http:\/\/youtu.be\/8f7wj_RcqYk?a",
      "display_url" : "youtu.be\/8f7wj_RcqYk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321256867194081282",
  "text" : "This is so stupid (@YouTube http:\/\/t.co\/TPqREyio3s)",
  "id" : 321256867194081282,
  "created_at" : "2013-04-08 13:43:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/VrWXuKl2jO",
      "expanded_url" : "http:\/\/youtu.be\/F7h26wzYOLs?a",
      "display_url" : "youtu.be\/F7h26wzYOLs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321256390477877248",
  "text" : "Evil, repent or they shall burn in a lake of fire for all eternity (@YouTube http:\/\/t.co\/VrWXuKl2jO)",
  "id" : 321256390477877248,
  "created_at" : "2013-04-08 13:41:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VrWXuKl2jO",
      "expanded_url" : "http:\/\/youtu.be\/F7h26wzYOLs?a",
      "display_url" : "youtu.be\/F7h26wzYOLs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321256153512280064",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/VrWXuKl2jO Girls Kissing",
  "id" : 321256153512280064,
  "created_at" : "2013-04-08 13:40:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/szPx1SGbyn",
      "expanded_url" : "http:\/\/youtu.be\/-2EA5tb7Hq0?a",
      "display_url" : "youtu.be\/-2EA5tb7Hq0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321255709352275968",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/szPx1SGbyn Hot lesbian Girls kissing!",
  "id" : 321255709352275968,
  "created_at" : "2013-04-08 13:38:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/5wCSwP0QY7",
      "expanded_url" : "http:\/\/youtu.be\/-ZIxXnlZuk8?a",
      "display_url" : "youtu.be\/-ZIxXnlZuk8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321119247487098881",
  "text" : "Oh what fun (@YouTube http:\/\/t.co\/5wCSwP0QY7)",
  "id" : 321119247487098881,
  "created_at" : "2013-04-08 04:36:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 51, 59 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/FgLEv3Z410",
      "expanded_url" : "http:\/\/youtu.be\/KWm9kqNEOpA?a",
      "display_url" : "youtu.be\/KWm9kqNEOpA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321119094164295683",
  "text" : "I ment William Sidis, sorry for the spelling flaw (@YouTube http:\/\/t.co\/FgLEv3Z410)",
  "id" : 321119094164295683,
  "created_at" : "2013-04-08 04:35:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FgLEv3Z410",
      "expanded_url" : "http:\/\/youtu.be\/KWm9kqNEOpA?a",
      "display_url" : "youtu.be\/KWm9kqNEOpA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321118291366125570",
  "text" : "Ever herd of Andrew Magdy Kamal, or William James Sardis, or Jacob Barnett, or even Daniel (@YouTube http:\/\/t.co\/FgLEv3Z410)",
  "id" : 321118291366125570,
  "created_at" : "2013-04-08 04:32:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/9PfB2eeikF",
      "expanded_url" : "http:\/\/youtu.be\/PYrgjMubh-c?a",
      "display_url" : "youtu.be\/PYrgjMubh-c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321117743174782976",
  "text" : "Oh what fun (@YouTube http:\/\/t.co\/9PfB2eeikF)",
  "id" : 321117743174782976,
  "created_at" : "2013-04-08 04:30:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 25, 33 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/kTcIz0LK47",
      "expanded_url" : "http:\/\/youtu.be\/219YybX66MY?a",
      "display_url" : "youtu.be\/219YybX66MY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321117412198064128",
  "text" : "If we make it till then (@YouTube http:\/\/t.co\/kTcIz0LK47)",
  "id" : 321117412198064128,
  "created_at" : "2013-04-08 04:28:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/MQhnUrRxGP",
      "expanded_url" : "http:\/\/youtu.be\/rUWfod_8JsM?a",
      "display_url" : "youtu.be\/rUWfod_8JsM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321117300495351809",
  "text" : "Interesting indeed (@YouTube http:\/\/t.co\/MQhnUrRxGP)",
  "id" : 321117300495351809,
  "created_at" : "2013-04-08 04:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/2idJseKxHY",
      "expanded_url" : "http:\/\/youtu.be\/NK0Y9j_CGgM?a",
      "display_url" : "youtu.be\/NK0Y9j_CGgM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321117192932446208",
  "text" : "Oh really (@YouTube http:\/\/t.co\/2idJseKxHY)",
  "id" : 321117192932446208,
  "created_at" : "2013-04-08 04:27:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/WEBhFROz78",
      "expanded_url" : "http:\/\/youtu.be\/6AZwqcweX7g?a",
      "display_url" : "youtu.be\/6AZwqcweX7g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321116289814917120",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/WEBhFROz78 ''Out of Mind'' - episode 2x12: Out With Dad",
  "id" : 321116289814917120,
  "created_at" : "2013-04-08 04:24:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/RHqeh66Fsy",
      "expanded_url" : "http:\/\/youtu.be\/uBDxZ9PnDCo?a",
      "display_url" : "youtu.be\/uBDxZ9PnDCo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321116220743106560",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/RHqeh66Fsy ''Chemistry with Vanessa'' - episode 1x07: Out With Dad",
  "id" : 321116220743106560,
  "created_at" : "2013-04-08 04:24:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Pa93D8knSn",
      "expanded_url" : "http:\/\/youtu.be\/d4OdATe76q4?a",
      "display_url" : "youtu.be\/d4OdATe76q4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321116110999138304",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Pa93D8knSn ''Rose with Vanessa'' - episode 1x01: Out With Dad",
  "id" : 321116110999138304,
  "created_at" : "2013-04-08 04:23:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/v6sNBHpJP7",
      "expanded_url" : "http:\/\/youtu.be\/1ZcWMBNtS9M?a",
      "display_url" : "youtu.be\/1ZcWMBNtS9M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321115746761584640",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/v6sNBHpJP7 lady gaga besa a marge simpson lesbianas",
  "id" : 321115746761584640,
  "created_at" : "2013-04-08 04:22:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/bHDSli2m6A",
      "expanded_url" : "http:\/\/youtu.be\/nZJiOD7oaK4?a",
      "display_url" : "youtu.be\/nZJiOD7oaK4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321115607842033664",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/bHDSli2m6A Lesben \/ Lesbian - Simpsons",
  "id" : 321115607842033664,
  "created_at" : "2013-04-08 04:21:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/jEpe4M31Zp",
      "expanded_url" : "http:\/\/youtu.be\/aXZ-IQmDALI?a",
      "display_url" : "youtu.be\/aXZ-IQmDALI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321115180673155072",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/jEpe4M31Zp Simpsons Marge kisses Lindsey Naegle?",
  "id" : 321115180673155072,
  "created_at" : "2013-04-08 04:19:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/RGYLwyxhRM",
      "expanded_url" : "http:\/\/youtu.be\/wGrm4Tarj9A?a",
      "display_url" : "youtu.be\/wGrm4Tarj9A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321115005816823808",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/RGYLwyxhRM American Dad! - Ladybugs - Asian woman \u2777",
  "id" : 321115005816823808,
  "created_at" : "2013-04-08 04:19:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/dHvZkzLYzt",
      "expanded_url" : "http:\/\/youtu.be\/rw-_IMngGq4?a",
      "display_url" : "youtu.be\/rw-_IMngGq4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321112904818630659",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/dHvZkzLYzt American Dad - Francine Girl on Girl",
  "id" : 321112904818630659,
  "created_at" : "2013-04-08 04:10:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4WQ1yGLDoe",
      "expanded_url" : "http:\/\/youtu.be\/OakegeyOYp4?a",
      "display_url" : "youtu.be\/OakegeyOYp4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321112227660849152",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/4WQ1yGLDoe Lois and Bonnie kiss! -Family Guy",
  "id" : 321112227660849152,
  "created_at" : "2013-04-08 04:08:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/pB5sQj6a2z",
      "expanded_url" : "http:\/\/youtu.be\/_vniI2_nyCc?a",
      "display_url" : "youtu.be\/_vniI2_nyCc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321112144504582144",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/pB5sQj6a2z Lesbian Sims: Lois and Leela",
  "id" : 321112144504582144,
  "created_at" : "2013-04-08 04:07:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VhhHzObtI5",
      "expanded_url" : "http:\/\/youtu.be\/PZ-nGu90kH0?a",
      "display_url" : "youtu.be\/PZ-nGu90kH0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321111793999175681",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/VhhHzObtI5 Family guy Lesbian Kissing MEG",
  "id" : 321111793999175681,
  "created_at" : "2013-04-08 04:06:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/3t0BHbSrqf",
      "expanded_url" : "http:\/\/youtu.be\/fIWCPX3AS6U?a",
      "display_url" : "youtu.be\/fIWCPX3AS6U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "321111688340455425",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/3t0BHbSrqf family guy lesbian kiss",
  "id" : 321111688340455425,
  "created_at" : "2013-04-08 04:06:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/lZ6ls4xa61",
      "expanded_url" : "http:\/\/youtu.be\/VFuz0aT30TM?a",
      "display_url" : "youtu.be\/VFuz0aT30TM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "320915117594275840",
  "text" : "Celine is so pretty (@YouTube http:\/\/t.co\/lZ6ls4xa61)",
  "id" : 320915117594275840,
  "created_at" : "2013-04-07 15:05:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/zN9OFkvWNw",
      "expanded_url" : "http:\/\/youtu.be\/QMQLtyDgFIc?a",
      "display_url" : "youtu.be\/QMQLtyDgFIc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "320913374101790721",
  "text" : "sweet (@YouTube http:\/\/t.co\/zN9OFkvWNw)",
  "id" : 320913374101790721,
  "created_at" : "2013-04-07 14:58:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 27, 35 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/sapVSGUVa2",
      "expanded_url" : "http:\/\/youtu.be\/2STTNYNF4lk?a",
      "display_url" : "youtu.be\/2STTNYNF4lk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "320913105309818881",
  "text" : "I want a cheaper one, LOL (@YouTube http:\/\/t.co\/sapVSGUVa2)",
  "id" : 320913105309818881,
  "created_at" : "2013-04-07 14:57:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 9, 17 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/2OpKsOo42T",
      "expanded_url" : "http:\/\/youtu.be\/Ez4Lrxh4Gqo?a",
      "display_url" : "youtu.be\/Ez4Lrxh4Gqo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "320912862769991680",
  "text" : "awesome (@YouTube http:\/\/t.co\/2OpKsOo42T)",
  "id" : 320912862769991680,
  "created_at" : "2013-04-07 14:56:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320912229883064322",
  "text" : "You haven't seen rudeness tell you met my sister Tina. My other sister Grace used to be an angel, but since she hung out with Tina. Ugh",
  "id" : 320912229883064322,
  "created_at" : "2013-04-07 14:53:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320908450441875456",
  "text" : "She took my frosted marshmallows when I was asleep and refused to say thank you, then threatened me",
  "id" : 320908450441875456,
  "created_at" : "2013-04-07 14:38:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320908270325874689",
  "text" : "My sister Yostina is extremely rude but I still love her",
  "id" : 320908270325874689,
  "created_at" : "2013-04-07 14:37:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320589254969393152",
  "text" : "At nikkos birthday party",
  "id" : 320589254969393152,
  "created_at" : "2013-04-06 17:30:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4J49dExz3U",
      "expanded_url" : "http:\/\/sdrv.ms\/12sYqqv",
      "display_url" : "sdrv.ms\/12sYqqv"
    } ]
  },
  "geo" : { },
  "id_str" : "320417745772609537",
  "text" : "Physics book came http:\/\/t.co\/4J49dExz3U",
  "id" : 320417745772609537,
  "created_at" : "2013-04-06 06:08:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/A1jvBGoabv",
      "expanded_url" : "http:\/\/sdrv.ms\/XtW5xl",
      "display_url" : "sdrv.ms\/XtW5xl"
    } ]
  },
  "geo" : { },
  "id_str" : "320232040899416064",
  "text" : "great deal http:\/\/t.co\/A1jvBGoabv",
  "id" : 320232040899416064,
  "created_at" : "2013-04-05 17:50:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Zc8JsqfRDT",
      "expanded_url" : "http:\/\/sdrv.ms\/YXQqhc",
      "display_url" : "sdrv.ms\/YXQqhc"
    } ]
  },
  "geo" : { },
  "id_str" : "320227449000574977",
  "text" : "Good mood, love KY, but sadly going back to MI today http:\/\/t.co\/Zc8JsqfRDT",
  "id" : 320227449000574977,
  "created_at" : "2013-04-05 17:32:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319566140953227264",
  "text" : "Just rode my bike on a highly inclined ramp (huge driveway) last time I did it was twice to years ago, they both ended well, Im stunt master",
  "id" : 319566140953227264,
  "created_at" : "2013-04-03 21:44:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319449788993110016",
  "text" : "Just talked to Jen.B",
  "id" : 319449788993110016,
  "created_at" : "2013-04-03 14:02:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/FmEVnqCo5i",
      "expanded_url" : "http:\/\/youtu.be\/0b0kKro76NE?a",
      "display_url" : "youtu.be\/0b0kKro76NE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318819093044137985",
  "text" : "I liked a @YouTube video http:\/\/t.co\/FmEVnqCo5i K-391 feat. Gjermund Olstad - Hang Loose",
  "id" : 318819093044137985,
  "created_at" : "2013-04-01 20:16:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/G0ge99z3aZ",
      "expanded_url" : "http:\/\/youtu.be\/vf9C0aqD1Zw?a",
      "display_url" : "youtu.be\/vf9C0aqD1Zw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318818714856325120",
  "text" : "I liked a @YouTube video http:\/\/t.co\/G0ge99z3aZ \u042F\u043DdeXe\u0440\u043D\u044F \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E - \u0411 - - - - ! :D",
  "id" : 318818714856325120,
  "created_at" : "2013-04-01 20:14:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/rUOA5FvaDf",
      "expanded_url" : "http:\/\/youtu.be\/0c2aOI5UAJQ?a",
      "display_url" : "youtu.be\/0c2aOI5UAJQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318818432810381312",
  "text" : "I liked a @YouTube video http:\/\/t.co\/rUOA5FvaDf Michael Jackson 2013 Mix",
  "id" : 318818432810381312,
  "created_at" : "2013-04-01 20:13:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "AmizuTweets",
      "screen_name" : "AmizuTweets",
      "indices" : [ 30, 42 ],
      "id_str" : "1000013041",
      "id" : 1000013041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Birthday",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/5oFdx8giZC",
      "expanded_url" : "http:\/\/youtu.be\/zqCA7s3QCQY?a",
      "display_url" : "youtu.be\/zqCA7s3QCQY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318818061425717248",
  "text" : "I liked a @YouTube video from @amizutweets http:\/\/t.co\/5oFdx8giZC DUBSTEP MASHUP | Zedd, Razihel, Skrillex, and more | #Birthday",
  "id" : 318818061425717248,
  "created_at" : "2013-04-01 20:12:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "BITCH BROS \uD83C\uDF9A\uFE0F",
      "screen_name" : "BitchBros",
      "indices" : [ 30, 40 ],
      "id_str" : "72881679",
      "id" : 72881679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/B76bCZdlPV",
      "expanded_url" : "http:\/\/youtu.be\/KJ0XWQLFBgo?a",
      "display_url" : "youtu.be\/KJ0XWQLFBgo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318817799797620736",
  "text" : "I liked a @YouTube video from @bitchbros http:\/\/t.co\/B76bCZdlPV Drunk Sessions Volume 3 - Mermaid Music Radio Show Part 1",
  "id" : 318817799797620736,
  "created_at" : "2013-04-01 20:11:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "The Unleet Gamer",
      "screen_name" : "TheUnleetGamer",
      "indices" : [ 30, 45 ],
      "id_str" : "1244726413",
      "id" : 1244726413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/gYqL3FZudm",
      "expanded_url" : "http:\/\/youtu.be\/1LdnMW8ShpU?a",
      "display_url" : "youtu.be\/1LdnMW8ShpU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "318817392304197632",
  "text" : "I liked a @YouTube video from @theunleetgamer http:\/\/t.co\/gYqL3FZudm Speed Unboxing with TheUnleetGamer - Gears Of War: Judgement -",
  "id" : 318817392304197632,
  "created_at" : "2013-04-01 20:09:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318785942271959040",
  "text" : "Just reached 3,480,000 total views!!!!!!!",
  "id" : 318785942271959040,
  "created_at" : "2013-04-01 18:04:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]