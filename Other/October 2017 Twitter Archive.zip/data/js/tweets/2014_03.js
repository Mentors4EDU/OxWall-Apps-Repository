Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450068676642107393",
  "text" : "Went to a birthday party, played with the kids, was fun",
  "id" : 450068676642107393,
  "created_at" : "2014-03-30 00:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 40, 54 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449264465142243329",
  "text" : "I love the children of Egypt, God Bless @CopticOrphans",
  "id" : 449264465142243329,
  "created_at" : "2014-03-27 19:19:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u043B\u0430\u0434\u0438\u043C\u0438\u0440 \u041F\u0443\u0442\u0438\u043D",
      "screen_name" : "PutinRF",
      "indices" : [ 31, 39 ],
      "id_str" : "438133358",
      "id" : 438133358
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 44, 56 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449263818632597504",
  "text" : "I think the difference between @PutinRF and @BarackObama, is Putin actually knows how to run a country rather then look like a total moron",
  "id" : 449263818632597504,
  "created_at" : "2014-03-27 19:16:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic News",
      "screen_name" : "CopticNews",
      "indices" : [ 3, 14 ],
      "id_str" : "45778908",
      "id" : 45778908
    }, {
      "name" : "Ann Coulter",
      "screen_name" : "AnnCoulter",
      "indices" : [ 16, 27 ],
      "id_str" : "196168350",
      "id" : 196168350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448583271782559744",
  "text" : "RT @CopticNews: @AnnCoulter Ann please comment on media totally ignoring the systematic attack on Coptic churches today while painting MB s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ann Coulter",
        "screen_name" : "AnnCoulter",
        "indices" : [ 0, 11 ],
        "id_str" : "196168350",
        "id" : 196168350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367770790663446528",
    "in_reply_to_user_id" : 196168350,
    "text" : "@AnnCoulter Ann please comment on media totally ignoring the systematic attack on Coptic churches today while painting MB sit-in as innocent",
    "id" : 367770790663446528,
    "created_at" : "2013-08-14 22:12:44 +0000",
    "in_reply_to_screen_name" : "AnnCoulter",
    "in_reply_to_user_id_str" : "196168350",
    "user" : {
      "name" : "Coptic News",
      "screen_name" : "CopticNews",
      "protected" : false,
      "id_str" : "45778908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3561361152\/9c778561e9fce8f5a9f0fe302a80577e_normal.jpeg",
      "id" : 45778908,
      "verified" : false
    }
  },
  "id" : 448583271782559744,
  "created_at" : "2014-03-25 22:12:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 24, 38 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/448582521941266432\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/RfgXm55cW8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjmvbVFCEAAqoSh.jpg",
      "id_str" : "448582521949655040",
      "id" : 448582521949655040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjmvbVFCEAAqoSh.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 1059
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1059
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1059
      } ],
      "display_url" : "pic.twitter.com\/RfgXm55cW8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448582521941266432",
  "text" : "150k people referred to @CopticOrphans website thanks to an effort put by all the most popular Coptic YT channels http:\/\/t.co\/RfgXm55cW8",
  "id" : 448582521941266432,
  "created_at" : "2014-03-25 22:09:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448239702110240768",
  "text" : "Had some nice food at the Sahara Grill, can you guess, lol",
  "id" : 448239702110240768,
  "created_at" : "2014-03-24 23:27:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askij",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447852365287555072",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine Have you ever tried computer programming like Javascript or HTML 5 #askij",
  "id" : 447852365287555072,
  "created_at" : "2014-03-23 21:48:19 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 19, 28 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447851954770038784",
  "text" : "I am so happy that @MarkDice had his channel restored, awesome, even though I don't agree with all he says, it is still a great victory",
  "id" : 447851954770038784,
  "created_at" : "2014-03-23 21:46:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atmel",
      "screen_name" : "atmel",
      "indices" : [ 3, 9 ],
      "id_str" : "814572110358188034",
      "id" : 814572110358188034
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Atmel",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "MakerMonday",
      "indices" : [ 97, 109 ]
    }, {
      "text" : "Gamebuino",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/EF4ChJxBaq",
      "expanded_url" : "http:\/\/buzz.mw\/bpfus_l",
      "display_url" : "buzz.mw\/bpfus_l"
    } ]
  },
  "geo" : { },
  "id_str" : "447614937402077184",
  "text" : "RT @Atmel: Gamebuino is cooler than any Game Boy you used to have! http:\/\/t.co\/EF4ChJxBaq #Atmel #MakerMonday #Gamebuino http:\/\/t.co\/dHT44t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Atmel",
        "indices" : [ 79, 85 ]
      }, {
        "text" : "MakerMonday",
        "indices" : [ 86, 98 ]
      }, {
        "text" : "Gamebuino",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/EF4ChJxBaq",
        "expanded_url" : "http:\/\/buzz.mw\/bpfus_l",
        "display_url" : "buzz.mw\/bpfus_l"
      }, {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/dHT44tzhYH",
        "expanded_url" : "https:\/\/twitter.com\/AtmelUniversity\/status\/439464555735834625\/photo\/1",
        "display_url" : "pic.twitter.com\/dHT44tzhYH"
      } ]
    },
    "geo" : { },
    "id_str" : "440491017146732544",
    "text" : "Gamebuino is cooler than any Game Boy you used to have! http:\/\/t.co\/EF4ChJxBaq #Atmel #MakerMonday #Gamebuino http:\/\/t.co\/dHT44tzhYH",
    "id" : 440491017146732544,
    "created_at" : "2014-03-03 14:16:57 +0000",
    "user" : {
      "name" : "Microchip Makes",
      "screen_name" : "MicrochipMakes",
      "protected" : false,
      "id_str" : "138475538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829007132800344064\/JsGG9E-1_normal.jpg",
      "id" : 138475538,
      "verified" : false
    }
  },
  "id" : 447614937402077184,
  "created_at" : "2014-03-23 06:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/447511813257981952\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/JZ98aKFN6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjXhn4DIAAAGVEQ.jpg",
      "id_str" : "447511813169872896",
      "id" : 447511813169872896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjXhn4DIAAAGVEQ.jpg",
      "sizes" : [ {
        "h" : 457,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 660
      } ],
      "display_url" : "pic.twitter.com\/JZ98aKFN6a"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QAygtJwJBw",
      "expanded_url" : "http:\/\/wrd.cm\/1kR0cLU",
      "display_url" : "wrd.cm\/1kR0cLU"
    } ]
  },
  "geo" : { },
  "id_str" : "447613696529797120",
  "text" : "RT @WIRED: Yup, the Germans have figured out how to 3-D print cars http:\/\/t.co\/QAygtJwJBw http:\/\/t.co\/JZ98aKFN6a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/447511813257981952\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/JZ98aKFN6a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjXhn4DIAAAGVEQ.jpg",
        "id_str" : "447511813169872896",
        "id" : 447511813169872896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjXhn4DIAAAGVEQ.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 660
        } ],
        "display_url" : "pic.twitter.com\/JZ98aKFN6a"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/QAygtJwJBw",
        "expanded_url" : "http:\/\/wrd.cm\/1kR0cLU",
        "display_url" : "wrd.cm\/1kR0cLU"
      } ]
    },
    "geo" : { },
    "id_str" : "447511813257981952",
    "text" : "Yup, the Germans have figured out how to 3-D print cars http:\/\/t.co\/QAygtJwJBw http:\/\/t.co\/JZ98aKFN6a",
    "id" : 447511813257981952,
    "created_at" : "2014-03-22 23:15:05 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 447613696529797120,
  "created_at" : "2014-03-23 05:59:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 18, 26 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "YouTube Creators",
      "screen_name" : "YTCreators",
      "indices" : [ 27, 38 ],
      "id_str" : "239760107",
      "id" : 239760107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447612675241934848",
  "text" : "RT @MarkDice: Hey @YouTube @YTCreators why'd you DELETE MY CHANNEL!! 60 milliion views, 265,000 subs? No way to file counter claim? #Censor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 4, 12 ],
        "id_str" : "10228272",
        "id" : 10228272
      }, {
        "name" : "YouTube Creators",
        "screen_name" : "YTCreators",
        "indices" : [ 13, 24 ],
        "id_str" : "239760107",
        "id" : 239760107
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Censorship",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "447418348599402496",
    "text" : "Hey @YouTube @YTCreators why'd you DELETE MY CHANNEL!! 60 milliion views, 265,000 subs? No way to file counter claim? #Censorship!!!",
    "id" : 447418348599402496,
    "created_at" : "2014-03-22 17:03:41 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 447612675241934848,
  "created_at" : "2014-03-23 05:55:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Wx9BNcB8jF",
      "expanded_url" : "http:\/\/1drv.ms\/NbBTvI",
      "display_url" : "1drv.ms\/NbBTvI"
    } ]
  },
  "geo" : { },
  "id_str" : "444270529424273409",
  "text" : "Falafel Sandwich http:\/\/t.co\/Wx9BNcB8jF",
  "id" : 444270529424273409,
  "created_at" : "2014-03-14 00:35:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/V4VLf1H09G",
      "expanded_url" : "http:\/\/1drv.ms\/1g94HQA",
      "display_url" : "1drv.ms\/1g94HQA"
    } ]
  },
  "geo" : { },
  "id_str" : "442356073136390145",
  "text" : "Potato Pie http:\/\/t.co\/V4VLf1H09G",
  "id" : 442356073136390145,
  "created_at" : "2014-03-08 17:48:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/VLZLEysxfr",
      "expanded_url" : "http:\/\/1drv.ms\/MOqJww",
      "display_url" : "1drv.ms\/MOqJww"
    } ]
  },
  "geo" : { },
  "id_str" : "441329848938946560",
  "text" : "Yummy http:\/\/t.co\/VLZLEysxfr",
  "id" : 441329848938946560,
  "created_at" : "2014-03-05 21:50:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SuzieQ",
      "screen_name" : "Shesoshysti",
      "indices" : [ 3, 15 ],
      "id_str" : "185750158",
      "id" : 185750158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441092813514489856",
  "text" : "RT @shesoshysti: I hate how these conversations end.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441092609126055937",
    "text" : "I hate how these conversations end.",
    "id" : 441092609126055937,
    "created_at" : "2014-03-05 06:07:27 +0000",
    "user" : {
      "name" : "yonce duh",
      "screen_name" : "deanzaarmy",
      "protected" : false,
      "id_str" : "44673841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/834250659385847808\/_OchgMGs_normal.jpg",
      "id" : 44673841,
      "verified" : false
    }
  },
  "id" : 441092813514489856,
  "created_at" : "2014-03-05 06:08:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441092726423953408",
  "text" : "Life is a pain sometimes",
  "id" : 441092726423953408,
  "created_at" : "2014-03-05 06:07:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/ta6lzJ3por",
      "expanded_url" : "http:\/\/1drv.ms\/1lrwQ9a",
      "display_url" : "1drv.ms\/1lrwQ9a"
    } ]
  },
  "geo" : { },
  "id_str" : "439863090079731712",
  "text" : "Went to Dimitris http:\/\/t.co\/ta6lzJ3por",
  "id" : 439863090079731712,
  "created_at" : "2014-03-01 20:41:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ZcLdxjl5To",
      "expanded_url" : "http:\/\/1drv.ms\/1i2pTeu",
      "display_url" : "1drv.ms\/1i2pTeu"
    } ]
  },
  "geo" : { },
  "id_str" : "439862986891853824",
  "text" : "French onion soup http:\/\/t.co\/ZcLdxjl5To",
  "id" : 439862986891853824,
  "created_at" : "2014-03-01 20:41:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]