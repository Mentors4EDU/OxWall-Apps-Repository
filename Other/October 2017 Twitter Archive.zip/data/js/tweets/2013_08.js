Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373928514481057792",
  "text" : "LOL, fake diet",
  "id" : 373928514481057792,
  "created_at" : "2013-08-31 22:01:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373906280781725697",
  "text" : "Had subway, was naughty against my diet",
  "id" : 373906280781725697,
  "created_at" : "2013-08-31 20:32:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373590854817968128",
  "text" : "I am on Reddit, lol",
  "id" : 373590854817968128,
  "created_at" : "2013-08-30 23:39:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372770524365357056",
  "text" : "Lol",
  "id" : 372770524365357056,
  "created_at" : "2013-08-28 17:19:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372770461622738945",
  "text" : "Been invited by the people to people program again, so not going",
  "id" : 372770461622738945,
  "created_at" : "2013-08-28 17:19:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372506689809174528",
  "text" : "Lol",
  "id" : 372506689809174528,
  "created_at" : "2013-08-27 23:51:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372506653469728768",
  "text" : "Watched with my little sis, sorry",
  "id" : 372506653469728768,
  "created_at" : "2013-08-27 23:51:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372506529624489984",
  "text" : "Because I wanted the lights turned on",
  "id" : 372506529624489984,
  "created_at" : "2013-08-27 23:50:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372506446275309568",
  "text" : "Watched the first 1hr 5min of dady day care on Netflix for 3DS, then she ditched me",
  "id" : 372506446275309568,
  "created_at" : "2013-08-27 23:50:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372466288255180800",
  "text" : "Wow, like really?",
  "id" : 372466288255180800,
  "created_at" : "2013-08-27 21:10:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372466244529557504",
  "text" : "My dad insulted me for 10 minutes, because I drank a whole bottle of soda, lol, he said he lost all hope and respect for me",
  "id" : 372466244529557504,
  "created_at" : "2013-08-27 21:10:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372386980069253121",
  "text" : "LOL",
  "id" : 372386980069253121,
  "created_at" : "2013-08-27 15:55:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372386956795076608",
  "text" : "My sister opened up one of the demo apps on my Nintendo 3DS, oh I was supper pissed, she opened up the Marvels Pinball one",
  "id" : 372386956795076608,
  "created_at" : "2013-08-27 15:55:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372190768254836736",
  "text" : "SO was the guy for figuring everything out, lol",
  "id" : 372190768254836736,
  "created_at" : "2013-08-27 02:56:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372190709484232704",
  "text" : "BTW that woman was a mastermind",
  "id" : 372190709484232704,
  "created_at" : "2013-08-27 02:55:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372190651623825408",
  "text" : "Watched Flypaper on Netflix for Nintendo 3DS, such a messed up movie, lol",
  "id" : 372190651623825408,
  "created_at" : "2013-08-27 02:55:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/372155645971017728\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/3EQuTnfi9D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSoplpeCMAA4z2M.png",
      "id_str" : "372155645975212032",
      "id" : 372155645975212032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSoplpeCMAA4z2M.png",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/3EQuTnfi9D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372155645971017728",
  "text" : "Another dang it moment http:\/\/t.co\/3EQuTnfi9D",
  "id" : 372155645971017728,
  "created_at" : "2013-08-27 00:36:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372147685660184576",
  "text" : "A dang it moment with my 3DS",
  "id" : 372147685660184576,
  "created_at" : "2013-08-27 00:04:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372147185304883202",
  "text" : "In splinter cell 3D, I saved the engineer, killed the bad guys, and was going to win, tell I accidentally jumped off a cliff, killed us both",
  "id" : 372147185304883202,
  "created_at" : "2013-08-27 00:02:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/DqQwt2KRhc",
      "expanded_url" : "http:\/\/youtu.be\/NGvv_gKZaMs?a",
      "display_url" : "youtu.be\/NGvv_gKZaMs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "372096050841927680",
  "text" : "I liked a @YouTube video http:\/\/t.co\/DqQwt2KRhc Paper Bag (One Direction Parody)",
  "id" : 372096050841927680,
  "created_at" : "2013-08-26 20:39:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372095512612061184",
  "text" : "Why in every race car movie, every superhero movie, their is always some pretty love interest in it, it adds more tension, but less action",
  "id" : 372095512612061184,
  "created_at" : "2013-08-26 20:37:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372084099550171136",
  "text" : "LOL",
  "id" : 372084099550171136,
  "created_at" : "2013-08-26 19:52:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372084076628307968",
  "text" : "Will give up for NOW",
  "id" : 372084076628307968,
  "created_at" : "2013-08-26 19:52:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372084033062047744",
  "text" : "Killed two people in Splinter Cell 3D for Nintendo 3DS, but as soon as I opened the door I got shot, see couldn't save the engineer",
  "id" : 372084033062047744,
  "created_at" : "2013-08-26 19:52:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372076576784912384",
  "text" : "Especially difficult",
  "id" : 372076576784912384,
  "created_at" : "2013-08-26 19:22:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372076509969674240",
  "text" : "It is hard to get recognition in this world though",
  "id" : 372076509969674240,
  "created_at" : "2013-08-26 19:22:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372076452910338048",
  "text" : "Man I wish I was as famous as Jacob Barnett, my ideas are just as good or better",
  "id" : 372076452910338048,
  "created_at" : "2013-08-26 19:21:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372076369250758657",
  "text" : "I miss Jenna B.",
  "id" : 372076369250758657,
  "created_at" : "2013-08-26 19:21:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372064079621263360",
  "text" : "Watched Death Race 3: Inferno on Netflix for 3DS, first death race ever watched, even though it had to much profanity, it was still good",
  "id" : 372064079621263360,
  "created_at" : "2013-08-26 18:32:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371847858149797888",
  "text" : "You know how many times I tweeted LOL???",
  "id" : 371847858149797888,
  "created_at" : "2013-08-26 04:13:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371847773315792897",
  "text" : "LOL, :P",
  "id" : 371847773315792897,
  "created_at" : "2013-08-26 04:13:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/371847478024224769\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Ks0pC0MOLf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSkRT6bCQAAQ2Br.jpg",
      "id_str" : "371847478032613376",
      "id" : 371847478032613376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSkRT6bCQAAQ2Br.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Ks0pC0MOLf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371847478024224769",
  "text" : "Stopped when I saw the moon this bright http:\/\/t.co\/Ks0pC0MOLf",
  "id" : 371847478024224769,
  "created_at" : "2013-08-26 04:12:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371847398877700096",
  "text" : "Watched the first 52 minutes of Captain America: The First Avenger on Netflix for Nintendo 3DS",
  "id" : 371847398877700096,
  "created_at" : "2013-08-26 04:11:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371820308954497025",
  "text" : "I mean seriously though",
  "id" : 371820308954497025,
  "created_at" : "2013-08-26 02:24:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371820256987078656",
  "text" : "And why do so many idiots support Obama that is what I want to know",
  "id" : 371820256987078656,
  "created_at" : "2013-08-26 02:23:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371820118726025216",
  "text" : "Why are hollywood such gay liberals, its a waste on their talent and riches, and turns their society and cities to a social wasteland",
  "id" : 371820118726025216,
  "created_at" : "2013-08-26 02:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371818671514976256",
  "text" : "I mean Finalcutking himself makes better videos then these amateurs",
  "id" : 371818671514976256,
  "created_at" : "2013-08-26 02:17:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371818453088223232",
  "text" : "Watched the first 10 minutes of Halo 4: Forward Unto Dawn in Netflix for 3DS, didn't like it, the animation was to dull",
  "id" : 371818453088223232,
  "created_at" : "2013-08-26 02:16:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371812530026323968",
  "text" : "But who am I to judge",
  "id" : 371812530026323968,
  "created_at" : "2013-08-26 01:53:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371812491270955008",
  "text" : "Just watched Thor on Netflix for Nintendo 3DS, the actors were good in the movie, although they aren't good people in real life, lol",
  "id" : 371812491270955008,
  "created_at" : "2013-08-26 01:53:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371775069132836865",
  "text" : "LOL",
  "id" : 371775069132836865,
  "created_at" : "2013-08-25 23:24:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/371775044256415744\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LEszMPkc6v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSjPbtmCQAAszmj.jpg",
      "id_str" : "371775044260610048",
      "id" : 371775044260610048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSjPbtmCQAAszmj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LEszMPkc6v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371775044256415744",
  "text" : "Just watched these three messed up things, very messed up, wow, really messed up http:\/\/t.co\/LEszMPkc6v",
  "id" : 371775044256415744,
  "created_at" : "2013-08-25 23:24:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371751090238128128",
  "text" : "Watching TV episodes on Netflix for Nintendo 3DS",
  "id" : 371751090238128128,
  "created_at" : "2013-08-25 21:49:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/eCXmTIreoe",
      "expanded_url" : "http:\/\/youtu.be\/xttNbYnBkgQ?a",
      "display_url" : "youtu.be\/xttNbYnBkgQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "371719881760051200",
  "text" : "I liked a @YouTube video http:\/\/t.co\/eCXmTIreoe Annoying Orange - Monster Burger!",
  "id" : 371719881760051200,
  "created_at" : "2013-08-25 19:45:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/V9CsbUbJns",
      "expanded_url" : "http:\/\/youtu.be\/gvjbLYXnQmE?a",
      "display_url" : "youtu.be\/gvjbLYXnQmE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "371718978399240193",
  "text" : "This is so offensive (@YouTube http:\/\/t.co\/V9CsbUbJns)",
  "id" : 371718978399240193,
  "created_at" : "2013-08-25 19:41:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371495808279269376",
  "text" : "Play**",
  "id" : 371495808279269376,
  "created_at" : "2013-08-25 04:54:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371495732949577728",
  "text" : "Will pay later",
  "id" : 371495732949577728,
  "created_at" : "2013-08-25 04:54:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/1c4d4tsRzF",
      "expanded_url" : "http:\/\/sdrv.ms\/17dhjj0",
      "display_url" : "sdrv.ms\/17dhjj0"
    } ]
  },
  "geo" : { },
  "id_str" : "371495461330636801",
  "text" : "Playing a different game, can't get past this http:\/\/t.co\/1c4d4tsRzF",
  "id" : 371495461330636801,
  "created_at" : "2013-08-25 04:53:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371493016059789312",
  "text" : "On 3DS ofcourse",
  "id" : 371493016059789312,
  "created_at" : "2013-08-25 04:43:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371492934002413568",
  "text" : "Going to play mutant mudds demo",
  "id" : 371492934002413568,
  "created_at" : "2013-08-25 04:43:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371492474340261888",
  "text" : "Another game",
  "id" : 371492474340261888,
  "created_at" : "2013-08-25 04:41:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/MM3RuHrPO3",
      "expanded_url" : "http:\/\/sdrv.ms\/19S6Xea",
      "display_url" : "sdrv.ms\/19S6Xea"
    } ]
  },
  "geo" : { },
  "id_str" : "371492426164473856",
  "text" : "I used a boomerang now to play another gamer http:\/\/t.co\/MM3RuHrPO3",
  "id" : 371492426164473856,
  "created_at" : "2013-08-25 04:41:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/CVnjBytlOw",
      "expanded_url" : "http:\/\/sdrv.ms\/17bTDh5",
      "display_url" : "sdrv.ms\/17bTDh5"
    } ]
  },
  "geo" : { },
  "id_str" : "371485123990265857",
  "text" : "Gonna play this game demo now http:\/\/t.co\/CVnjBytlOw",
  "id" : 371485123990265857,
  "created_at" : "2013-08-25 04:12:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/g3xOk0oBlu",
      "expanded_url" : "http:\/\/sdrv.ms\/1de7BmH",
      "display_url" : "sdrv.ms\/1de7BmH"
    } ]
  },
  "geo" : { },
  "id_str" : "371480749155049472",
  "text" : "Unlocked level three, caught an 8 founder, www hopping for a thirty, but a man can dream http:\/\/t.co\/g3xOk0oBlu",
  "id" : 371480749155049472,
  "created_at" : "2013-08-25 03:54:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371474652935499777",
  "text" : "Well actual its called: Professional Fisherman's Tour Northern Hemisphere",
  "id" : 371474652935499777,
  "created_at" : "2013-08-25 03:30:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371473490601607168",
  "text" : "killed another man in the game but I give up now, will play extreme fishing for the DS now",
  "id" : 371473490601607168,
  "created_at" : "2013-08-25 03:25:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371461479410987010",
  "text" : "But I ain't gonna quite yet",
  "id" : 371461479410987010,
  "created_at" : "2013-08-25 02:38:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371461415741431808",
  "text" : "Splinter cell 3D is hard I killed like 5 people, still didn't save the engineer and died",
  "id" : 371461415741431808,
  "created_at" : "2013-08-25 02:37:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/62BGG0FJZD",
      "expanded_url" : "http:\/\/sdrv.ms\/18bUET6",
      "display_url" : "sdrv.ms\/18bUET6"
    } ]
  },
  "geo" : { },
  "id_str" : "371442224774778880",
  "text" : "Got a powerpack and splinter cell 3D, gonna be a gaming, lol http:\/\/t.co\/62BGG0FJZD",
  "id" : 371442224774778880,
  "created_at" : "2013-08-25 01:21:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371391990413688832",
  "text" : "Now to try out a new game",
  "id" : 371391990413688832,
  "created_at" : "2013-08-24 22:02:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/DdCybCPD9W",
      "expanded_url" : "http:\/\/sdrv.ms\/157uEXn",
      "display_url" : "sdrv.ms\/157uEXn"
    } ]
  },
  "geo" : { },
  "id_str" : "371385271738433536",
  "text" : "Made 8 bronze metals and 2 silver metals and over 31,000 geoms, and 84 level UPS, my own work record http:\/\/t.co\/DdCybCPD9W",
  "id" : 371385271738433536,
  "created_at" : "2013-08-24 21:35:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ijXfXAHwoi",
      "expanded_url" : "http:\/\/youtu.be\/T2XcA6NBKrg?a",
      "display_url" : "youtu.be\/T2XcA6NBKrg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "371341318795960320",
  "text" : "First of all it is the term Y'israel and secondly it came off of the term in exodus, and (@YouTube http:\/\/t.co\/ijXfXAHwoi)",
  "id" : 371341318795960320,
  "created_at" : "2013-08-24 18:40:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371326531312046080",
  "text" : "now 11720 geoms",
  "id" : 371326531312046080,
  "created_at" : "2013-08-24 17:41:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370991489113149440",
  "text" : "Got 660 Geoms, the snipe feature, and a bronze metal",
  "id" : 370991489113149440,
  "created_at" : "2013-08-23 19:30:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370768438035505152",
  "text" : "Brownee, dang spell check",
  "id" : 370768438035505152,
  "created_at" : "2013-08-23 04:44:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370768355902652416",
  "text" : "Making hazel nut, browner, and white chocolate gonochi, will taste exceptional",
  "id" : 370768355902652416,
  "created_at" : "2013-08-23 04:43:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370757887079239680",
  "text" : "4180 &amp; a shield now, lol",
  "id" : 370757887079239680,
  "created_at" : "2013-08-23 04:02:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370742023995006976",
  "text" : "I use Egyptian pita ofcourse",
  "id" : 370742023995006976,
  "created_at" : "2013-08-23 02:59:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370741887625605120",
  "text" : "Melted goat cheese + pita equals awesomeness",
  "id" : 370741887625605120,
  "created_at" : "2013-08-23 02:58:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370739535770308608",
  "text" : "Collected 4290 Geoms in geometry wars, 600k more and I win the world record",
  "id" : 370739535770308608,
  "created_at" : "2013-08-23 02:49:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/wBHtK2HxNH",
      "expanded_url" : "http:\/\/sdrv.ms\/16kMx5m",
      "display_url" : "sdrv.ms\/16kMx5m"
    } ]
  },
  "geo" : { },
  "id_str" : "370737511775363072",
  "text" : "Freaking awesome supermoon http:\/\/t.co\/wBHtK2HxNH",
  "id" : 370737511775363072,
  "created_at" : "2013-08-23 02:41:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370249278775914496",
  "text" : "Lol",
  "id" : 370249278775914496,
  "created_at" : "2013-08-21 18:21:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370249256340578304",
  "text" : "I should so be a chef",
  "id" : 370249256340578304,
  "created_at" : "2013-08-21 18:21:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370249157342003200",
  "text" : "Just ate melted blue cheese and goat cheese on pita, it was magical",
  "id" : 370249157342003200,
  "created_at" : "2013-08-21 18:20:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 39, 47 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/Oe3VRZyxue",
      "expanded_url" : "http:\/\/youtu.be\/LGb6YR7sSow?a",
      "display_url" : "youtu.be\/LGb6YR7sSow?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369989794417217536",
  "text" : "AMKTrailer: http:\/\/t.co\/Oe3VRZyxue via @YouTube",
  "id" : 369989794417217536,
  "created_at" : "2013-08-21 01:10:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/rJAvRHffz9",
      "expanded_url" : "http:\/\/sdrv.ms\/12nngKw",
      "display_url" : "sdrv.ms\/12nngKw"
    } ]
  },
  "geo" : { },
  "id_str" : "369980258142793728",
  "text" : "Haircut, uncle style, LOL http:\/\/t.co\/rJAvRHffz9",
  "id" : 369980258142793728,
  "created_at" : "2013-08-21 00:32:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369733123073785856",
  "text" : "Men I should be a chef, lol",
  "id" : 369733123073785856,
  "created_at" : "2013-08-20 08:10:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369733080136687616",
  "text" : "Gibna baid",
  "id" : 369733080136687616,
  "created_at" : "2013-08-20 08:10:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369733006652477440",
  "text" : "I also made a 6 cheese pitta pizza  including two types of cream cheeses, white cheese with chives, hard lemon roman, mozerella cheese, &amp; gb",
  "id" : 369733006652477440,
  "created_at" : "2013-08-20 08:09:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369732356124327936",
  "text" : "Earlier I made a white chocolate and dark chocolate and milk into a fudge like substance.",
  "id" : 369732356124327936,
  "created_at" : "2013-08-20 08:07:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/DqQwt2KRhc",
      "expanded_url" : "http:\/\/youtu.be\/NGvv_gKZaMs?a",
      "display_url" : "youtu.be\/NGvv_gKZaMs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369626076244242432",
  "text" : "She is very pretty, gorgeous infact, that's why I didn't get it, lol (@YouTube http:\/\/t.co\/DqQwt2KRhc)",
  "id" : 369626076244242432,
  "created_at" : "2013-08-20 01:04:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/H1AsNTQtPR",
      "expanded_url" : "http:\/\/youtu.be\/ODMhpdGoX9s?a",
      "display_url" : "youtu.be\/ODMhpdGoX9s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369625011247521793",
  "text" : "Geekslayer73 parody, Finalcutking parody, NighHawkinlight Parody, Howtobasic Parody, do either (@YouTube http:\/\/t.co\/H1AsNTQtPR)",
  "id" : 369625011247521793,
  "created_at" : "2013-08-20 01:00:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PLRAD4m9jd",
      "expanded_url" : "http:\/\/youtu.be\/tQblb4FnrW8?a",
      "display_url" : "youtu.be\/tQblb4FnrW8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369600540574875648",
  "text" : "His Holiness Pope Tawadros II on Coptic Orphans: http:\/\/t.co\/PLRAD4m9jd via @YouTube",
  "id" : 369600540574875648,
  "created_at" : "2013-08-19 23:23:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/v1u7NFjNMz",
      "expanded_url" : "http:\/\/youtu.be\/UqNrPm5CQuU?a",
      "display_url" : "youtu.be\/UqNrPm5CQuU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369598130137726976",
  "text" : "No Limits Beyond a Genius Book Trailer (Coptic Prodigy): http:\/\/t.co\/v1u7NFjNMz via @YouTube",
  "id" : 369598130137726976,
  "created_at" : "2013-08-19 23:13:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/v1u7NFjNMz",
      "expanded_url" : "http:\/\/youtu.be\/UqNrPm5CQuU?a",
      "display_url" : "youtu.be\/UqNrPm5CQuU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369597848003686400",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/v1u7NFjNMz No Limits Beyond a Genius Book Trailer (Coptic Prodigy)",
  "id" : 369597848003686400,
  "created_at" : "2013-08-19 23:12:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/jBoAbmiP1W",
      "expanded_url" : "http:\/\/youtu.be\/h9-VXrL76Y4?a",
      "display_url" : "youtu.be\/h9-VXrL76Y4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "369527786802651136",
  "text" : "Your words of pain and despise don't hurt me at all, I hope God brings the truth into your (@YouTube http:\/\/t.co\/jBoAbmiP1W)",
  "id" : 369527786802651136,
  "created_at" : "2013-08-19 18:34:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369328626958757888",
  "text" : "Celebrities are so disgusting these days",
  "id" : 369328626958757888,
  "created_at" : "2013-08-19 05:23:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368549816604717056",
  "text" : "LOLOLOL LOL",
  "id" : 368549816604717056,
  "created_at" : "2013-08-17 01:48:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368549782953816065",
  "text" : "Got take out from chop fusion with my mom, lol, it was delicious shared with my sis, got the atomic fusion version, but they didn't like it.",
  "id" : 368549782953816065,
  "created_at" : "2013-08-17 01:48:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jBoAbmiP1W",
      "expanded_url" : "http:\/\/youtu.be\/h9-VXrL76Y4?a",
      "display_url" : "youtu.be\/h9-VXrL76Y4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "368466543044083714",
  "text" : "You know that is one of the best things someone told me in my life, thank you (@YouTube http:\/\/t.co\/jBoAbmiP1W)",
  "id" : 368466543044083714,
  "created_at" : "2013-08-16 20:17:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/jBoAbmiP1W",
      "expanded_url" : "http:\/\/youtu.be\/h9-VXrL76Y4?a",
      "display_url" : "youtu.be\/h9-VXrL76Y4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "368466413733691392",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/jBoAbmiP1W Radical Islamic Attacks on Coptic, Evangelic, Catholic, and Jesuit",
  "id" : 368466413733691392,
  "created_at" : "2013-08-16 20:16:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368197875224018944",
  "text" : "Made my mom's cooking taste twice better with all the added spices and peppers",
  "id" : 368197875224018944,
  "created_at" : "2013-08-16 02:29:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/R6pVzCGHbb",
      "expanded_url" : "http:\/\/sdrv.ms\/14QlFxJ",
      "display_url" : "sdrv.ms\/14QlFxJ"
    } ]
  },
  "geo" : { },
  "id_str" : "368196462670524416",
  "text" : "Eating like Indians, lol http:\/\/t.co\/R6pVzCGHbb",
  "id" : 368196462670524416,
  "created_at" : "2013-08-16 02:24:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 113, 121 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jBoAbmiP1W",
      "expanded_url" : "http:\/\/youtu.be\/h9-VXrL76Y4?a",
      "display_url" : "youtu.be\/h9-VXrL76Y4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "368027872956383233",
  "text" : "Radical Islamic Attacks on Coptic, Evangelic, Catholic, and Jesuit Churches in Egypt: http:\/\/t.co\/jBoAbmiP1W via @YouTube",
  "id" : 368027872956383233,
  "created_at" : "2013-08-15 15:14:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WLKJo3gF2A",
      "expanded_url" : "http:\/\/www.sbwire.com\/press-releases\/teenager-gets-in-the-world-record-book-and-plans-to-make-inventions-public-302979.htm",
      "display_url" : "sbwire.com\/press-releases\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367673603493744640",
  "text" : "http:\/\/t.co\/WLKJo3gF2A",
  "id" : 367673603493744640,
  "created_at" : "2013-08-14 15:46:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/JR1HRSjm9d",
      "expanded_url" : "http:\/\/sdrv.ms\/14EbxI5",
      "display_url" : "sdrv.ms\/14EbxI5"
    } ]
  },
  "geo" : { },
  "id_str" : "366971480522760192",
  "text" : "What is it, LOL http:\/\/t.co\/JR1HRSjm9d",
  "id" : 366971480522760192,
  "created_at" : "2013-08-12 17:16:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ypgBwoGXkq",
      "expanded_url" : "http:\/\/youtu.be\/BBcYG_J3O2Q?a",
      "display_url" : "youtu.be\/BBcYG_J3O2Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "366782099484704769",
  "text" : "NDS-Design electric violins, are so expensive, I wish I had one (@YouTube http:\/\/t.co\/ypgBwoGXkq)",
  "id" : 366782099484704769,
  "created_at" : "2013-08-12 04:44:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/23RImhi5kc",
      "expanded_url" : "http:\/\/youtu.be\/JYRhd71dPRs?a",
      "display_url" : "youtu.be\/JYRhd71dPRs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "366781755304325121",
  "text" : "LOL, you ignored the fact that out of my 10 partnered youtube channels, 600+ videos, and the (@YouTube http:\/\/t.co\/23RImhi5kc)",
  "id" : 366781755304325121,
  "created_at" : "2013-08-12 04:42:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366739783919210497",
  "text" : "Rank 24, is enough, I deleted the game",
  "id" : 366739783919210497,
  "created_at" : "2013-08-12 01:55:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366728800572157953",
  "text" : "Now rank 23!!!",
  "id" : 366728800572157953,
  "created_at" : "2013-08-12 01:12:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366727325565456387",
  "text" : "Fast and furious is way too inappropriate and confusing",
  "id" : 366727325565456387,
  "created_at" : "2013-08-12 01:06:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366684361132740609",
  "text" : "Watching Fast and Furious movies, and just finished a research report",
  "id" : 366684361132740609,
  "created_at" : "2013-08-11 22:15:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366266787928621057",
  "text" : "Rank 22 :)",
  "id" : 366266787928621057,
  "created_at" : "2013-08-10 18:36:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365898287976427521",
  "text" : "Rank 21 right now",
  "id" : 365898287976427521,
  "created_at" : "2013-08-09 18:12:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365640330848108545",
  "text" : "Rank 20 now",
  "id" : 365640330848108545,
  "created_at" : "2013-08-09 01:07:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365591982577418242",
  "text" : "My dad sometimes can be really aggressive, lol",
  "id" : 365591982577418242,
  "created_at" : "2013-08-08 21:54:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365591818345250816",
  "text" : "So wanting to return that rc copter right now",
  "id" : 365591818345250816,
  "created_at" : "2013-08-08 21:54:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/3cXltMkKPj",
      "expanded_url" : "http:\/\/sdrv.ms\/15fZih5",
      "display_url" : "sdrv.ms\/15fZih5"
    } ]
  },
  "geo" : { },
  "id_str" : "365552012022120448",
  "text" : "It came http:\/\/t.co\/3cXltMkKPj",
  "id" : 365552012022120448,
  "created_at" : "2013-08-08 19:16:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365541828012945409",
  "text" : "Now it's 19",
  "id" : 365541828012945409,
  "created_at" : "2013-08-08 18:35:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365516871082049536",
  "text" : "Made it to rank 18",
  "id" : 365516871082049536,
  "created_at" : "2013-08-08 16:56:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365199418842021889",
  "text" : "Made it to rank 17",
  "id" : 365199418842021889,
  "created_at" : "2013-08-07 19:55:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 54, 62 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/pf6hAWNEPf",
      "expanded_url" : "http:\/\/youtu.be\/WwdQAJHnk-4?a",
      "display_url" : "youtu.be\/WwdQAJHnk-4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "365180714062323712",
  "text" : "Convert a Jew into Coptic: http:\/\/t.co\/pf6hAWNEPf via @YouTube",
  "id" : 365180714062323712,
  "created_at" : "2013-08-07 18:40:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365162880645087233",
  "text" : "540.779.385 alliance code",
  "id" : 365162880645087233,
  "created_at" : "2013-08-07 17:29:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365160617365086210",
  "text" : "Made it to rank 16 in that game",
  "id" : 365160617365086210,
  "created_at" : "2013-08-07 17:20:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364923699129880577",
  "text" : "Happy birthday myself",
  "id" : 364923699129880577,
  "created_at" : "2013-08-07 01:39:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/23RImhi5kc",
      "expanded_url" : "http:\/\/youtu.be\/JYRhd71dPRs?a",
      "display_url" : "youtu.be\/JYRhd71dPRs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364852629689479169",
  "text" : "Just get someone to hold the phone for you, lol (@YouTube http:\/\/t.co\/23RImhi5kc)",
  "id" : 364852629689479169,
  "created_at" : "2013-08-06 20:57:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 30, 38 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/2GWSeew5gL",
      "expanded_url" : "http:\/\/youtu.be\/9oFVh0gQAs4?a",
      "display_url" : "youtu.be\/9oFVh0gQAs4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364851855165104128",
  "text" : "It is a fairly expensive dvd (@YouTube http:\/\/t.co\/2GWSeew5gL)",
  "id" : 364851855165104128,
  "created_at" : "2013-08-06 20:53:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 29, 37 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/zbvSw6KK5q",
      "expanded_url" : "http:\/\/youtu.be\/YIu1DhkP5FU?a",
      "display_url" : "youtu.be\/YIu1DhkP5FU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364850905209778176",
  "text" : "This was absolutely amazing (@YouTube http:\/\/t.co\/zbvSw6KK5q)",
  "id" : 364850905209778176,
  "created_at" : "2013-08-06 20:50:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Bs31X0fSZF",
      "expanded_url" : "http:\/\/youtu.be\/ww57cyhTIEs?a",
      "display_url" : "youtu.be\/ww57cyhTIEs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364849989270249473",
  "text" : "Like this if your watching this in 2013 (@YouTube http:\/\/t.co\/Bs31X0fSZF)",
  "id" : 364849989270249473,
  "created_at" : "2013-08-06 20:46:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/23RImhi5kc",
      "expanded_url" : "http:\/\/youtu.be\/JYRhd71dPRs?a",
      "display_url" : "youtu.be\/JYRhd71dPRs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364849690870685697",
  "text" : "Nice demo but you need a better camera man, lol (@YouTube http:\/\/t.co\/23RImhi5kc)",
  "id" : 364849690870685697,
  "created_at" : "2013-08-06 20:45:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 23, 31 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/7Vk10A6TKU",
      "expanded_url" : "http:\/\/youtu.be\/yoiT3hAo1_s?a",
      "display_url" : "youtu.be\/yoiT3hAo1_s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364849398640943104",
  "text" : "Very expensive though (@YouTube http:\/\/t.co\/7Vk10A6TKU)",
  "id" : 364849398640943104,
  "created_at" : "2013-08-06 20:44:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/T9HudS89F2",
      "expanded_url" : "http:\/\/youtu.be\/h9zDzQTwJ70?a",
      "display_url" : "youtu.be\/h9zDzQTwJ70?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364848586166513664",
  "text" : "Cecillio Electric Violin is a third the price and sounds the same (@YouTube http:\/\/t.co\/T9HudS89F2)",
  "id" : 364848586166513664,
  "created_at" : "2013-08-06 20:40:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/u8400domsy",
      "expanded_url" : "http:\/\/youtu.be\/FqvaJ0Tnr5E?a",
      "display_url" : "youtu.be\/FqvaJ0Tnr5E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "364847063692873729",
  "text" : "Do you have a cover up done with a Cecillio electric violin model, any ways you are so (@YouTube http:\/\/t.co\/u8400domsy)",
  "id" : 364847063692873729,
  "created_at" : "2013-08-06 20:34:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/8E0CXNEbra",
      "expanded_url" : "http:\/\/sdrv.ms\/13hY0CP",
      "display_url" : "sdrv.ms\/13hY0CP"
    } ]
  },
  "geo" : { },
  "id_str" : "364810988479979520",
  "text" : "Closeup http:\/\/t.co\/8E0CXNEbra",
  "id" : 364810988479979520,
  "created_at" : "2013-08-06 18:11:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/cpkou0r08U",
      "expanded_url" : "http:\/\/sdrv.ms\/172epx9",
      "display_url" : "sdrv.ms\/172epx9"
    } ]
  },
  "geo" : { },
  "id_str" : "364810621658726400",
  "text" : "Got myself a sterling silver messianic Jewish necklace http:\/\/t.co\/cpkou0r08U",
  "id" : 364810621658726400,
  "created_at" : "2013-08-06 18:10:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364119753058955264",
  "text" : "Made it to rank 15 in that Nokia war game",
  "id" : 364119753058955264,
  "created_at" : "2013-08-04 20:24:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364118464450924546",
  "text" : "Hard on the inside",
  "id" : 364118464450924546,
  "created_at" : "2013-08-04 20:19:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364118393504268288",
  "text" : "I am so soft on the outside, lol",
  "id" : 364118393504268288,
  "created_at" : "2013-08-04 20:19:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/UxWUkEPXdK",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363907994435584000",
  "text" : "Why do you think I made a video saying what the bible says about the name of the antichrist? (@YouTube http:\/\/t.co\/UxWUkEPXdK)",
  "id" : 363907994435584000,
  "created_at" : "2013-08-04 06:23:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 15, 23 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/O8Q9DqzQ38",
      "expanded_url" : "http:\/\/youtu.be\/j8W2OHm7Sn0?a",
      "display_url" : "youtu.be\/j8W2OHm7Sn0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363906483269808128",
  "text" : "Nice Job Luke (@YouTube http:\/\/t.co\/O8Q9DqzQ38)",
  "id" : 363906483269808128,
  "created_at" : "2013-08-04 06:17:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/FDswz9ZJa4",
      "expanded_url" : "http:\/\/youtu.be\/oTu7qzyjPwg?a",
      "display_url" : "youtu.be\/oTu7qzyjPwg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363906001126162432",
  "text" : "This is cool (@YouTube http:\/\/t.co\/FDswz9ZJa4)",
  "id" : 363906001126162432,
  "created_at" : "2013-08-04 06:15:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 9, 17 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/PGl5rHLx7Y",
      "expanded_url" : "http:\/\/youtu.be\/75I0kIPmGnM?a",
      "display_url" : "youtu.be\/75I0kIPmGnM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363904796819849216",
  "text" : "AMAZING (@YouTube http:\/\/t.co\/PGl5rHLx7Y)",
  "id" : 363904796819849216,
  "created_at" : "2013-08-04 06:10:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/S7YFNfsHh2",
      "expanded_url" : "http:\/\/youtu.be\/5bW3TM2kSsk?a",
      "display_url" : "youtu.be\/5bW3TM2kSsk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363904591428976643",
  "text" : "Definitely a Brass by the way, but that was flippin awesome (@YouTube http:\/\/t.co\/S7YFNfsHh2)",
  "id" : 363904591428976643,
  "created_at" : "2013-08-04 06:09:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/S7YFNfsHh2",
      "expanded_url" : "http:\/\/youtu.be\/5bW3TM2kSsk?a",
      "display_url" : "youtu.be\/5bW3TM2kSsk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363904048656695296",
  "text" : "Troll (@YouTube http:\/\/t.co\/S7YFNfsHh2)",
  "id" : 363904048656695296,
  "created_at" : "2013-08-04 06:07:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/S7YFNfsHh2",
      "expanded_url" : "http:\/\/youtu.be\/5bW3TM2kSsk?a",
      "display_url" : "youtu.be\/5bW3TM2kSsk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363904036862296064",
  "text" : "I think this is pretty good, I used to be a shredder on the guitar, but now I have interest in (@YouTube http:\/\/t.co\/S7YFNfsHh2)",
  "id" : 363904036862296064,
  "created_at" : "2013-08-04 06:07:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Gs0q4dqXya",
      "expanded_url" : "http:\/\/youtu.be\/h6-DTLLUB9g?a",
      "display_url" : "youtu.be\/h6-DTLLUB9g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363902070736171009",
  "text" : "Homosexuality and abortion is against God (@YouTube http:\/\/t.co\/Gs0q4dqXya)",
  "id" : 363902070736171009,
  "created_at" : "2013-08-04 05:59:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 29, 37 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/0oPuAOz5Ko",
      "expanded_url" : "http:\/\/youtu.be\/0UuiPDWfvAo?a",
      "display_url" : "youtu.be\/0UuiPDWfvAo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "363901930558328833",
  "text" : "Homosexuals do burn in hell (@YouTube http:\/\/t.co\/0oPuAOz5Ko)",
  "id" : 363901930558328833,
  "created_at" : "2013-08-04 05:59:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363017088538910720",
  "text" : "Little kids=cuteness lol",
  "id" : 363017088538910720,
  "created_at" : "2013-08-01 19:23:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]