Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CopticOrphans\/status\/472109267689144321\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/XOoSE7QM0e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo1E4G9CcAAgq9r.png",
      "id_str" : "472109266673758208",
      "id" : 472109266673758208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo1E4G9CcAAgq9r.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/XOoSE7QM0e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472829483284566017",
  "text" : "RT @CopticOrphans: Wishing you and your loved ones a blessed and happy Feast of the Ascension! http:\/\/t.co\/XOoSE7QM0e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CopticOrphans\/status\/472109267689144321\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/XOoSE7QM0e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo1E4G9CcAAgq9r.png",
        "id_str" : "472109266673758208",
        "id" : 472109266673758208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo1E4G9CcAAgq9r.png",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/XOoSE7QM0e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472109267689144321",
    "text" : "Wishing you and your loved ones a blessed and happy Feast of the Ascension! http:\/\/t.co\/XOoSE7QM0e",
    "id" : 472109267689144321,
    "created_at" : "2014-05-29 20:16:35 +0000",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 472829483284566017,
  "created_at" : "2014-05-31 19:58:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 65, 79 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/472829318318403584\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IrE81IkMuT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo_TwfZIAAA2bgz.jpg",
      "id_str" : "472829315911254016",
      "id" : 472829315911254016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo_TwfZIAAA2bgz.jpg",
      "sizes" : [ {
        "h" : 476,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 793
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 793
      } ],
      "display_url" : "pic.twitter.com\/IrE81IkMuT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472829318318403584",
  "text" : "I approve my running world record to be on behalf of the beloved @CopticOrphans I urge you to check out their charity http:\/\/t.co\/IrE81IkMuT",
  "id" : 472829318318403584,
  "created_at" : "2014-05-31 19:57:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/jWwSzw1iXu",
      "expanded_url" : "http:\/\/1drv.ms\/1nDx53q",
      "display_url" : "1drv.ms\/1nDx53q"
    } ]
  },
  "geo" : { },
  "id_str" : "472783007783219201",
  "text" : "From chop fusion, also ran twelve miles today (race)!!!! http:\/\/t.co\/jWwSzw1iXu",
  "id" : 472783007783219201,
  "created_at" : "2014-05-31 16:53:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Fox News Politics",
      "screen_name" : "foxnewspolitics",
      "indices" : [ 110, 126 ],
      "id_str" : "16032925",
      "id" : 16032925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9tuF3AWtCE",
      "expanded_url" : "http:\/\/fxn.ws\/1wmL7rE",
      "display_url" : "fxn.ws\/1wmL7rE"
    } ]
  },
  "geo" : { },
  "id_str" : "471755037266280449",
  "text" : "RT @FoxNews: National Organization for Marriage sued by Maine over 2009 referendum http:\/\/t.co\/9tuF3AWtCE via @foxnewspolitics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fox News Politics",
        "screen_name" : "foxnewspolitics",
        "indices" : [ 97, 113 ],
        "id_str" : "16032925",
        "id" : 16032925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/9tuF3AWtCE",
        "expanded_url" : "http:\/\/fxn.ws\/1wmL7rE",
        "display_url" : "fxn.ws\/1wmL7rE"
      } ]
    },
    "geo" : { },
    "id_str" : "471735980823937025",
    "text" : "National Organization for Marriage sued by Maine over 2009 referendum http:\/\/t.co\/9tuF3AWtCE via @foxnewspolitics",
    "id" : 471735980823937025,
    "created_at" : "2014-05-28 19:33:16 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 471755037266280449,
  "created_at" : "2014-05-28 20:49:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/2UABRIpZ4x",
      "expanded_url" : "http:\/\/1drv.ms\/1oH2m2u",
      "display_url" : "1drv.ms\/1oH2m2u"
    } ]
  },
  "geo" : { },
  "id_str" : "471422094396235777",
  "text" : "Had bucemi's pizza, 3.9\/5 http:\/\/t.co\/2UABRIpZ4x",
  "id" : 471422094396235777,
  "created_at" : "2014-05-27 22:46:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Churchill Downs",
      "screen_name" : "ChurchillDowns",
      "indices" : [ 3, 18 ],
      "id_str" : "19338246",
      "id" : 19338246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KyOaks",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ZG8ADtn7Fv",
      "expanded_url" : "http:\/\/goo.gl\/sdVntC",
      "display_url" : "goo.gl\/sdVntC"
    } ]
  },
  "geo" : { },
  "id_str" : "471058390890737665",
  "text" : "RT @ChurchillDowns: Race Day Notes (5\/26) - #KyOaks winner Untapable works, eyes Mother Goose (Reed Palmer photo) http:\/\/t.co\/ZG8ADtn7Fv ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChurchillDowns\/status\/471025090227105792\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/GyAcDLL4ST",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bolq0qbCQAApF7S.jpg",
        "id_str" : "471025089010352128",
        "id" : 471025089010352128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bolq0qbCQAApF7S.jpg",
        "sizes" : [ {
          "h" : 1638,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1638,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/GyAcDLL4ST"
      } ],
      "hashtags" : [ {
        "text" : "KyOaks",
        "indices" : [ 24, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ZG8ADtn7Fv",
        "expanded_url" : "http:\/\/goo.gl\/sdVntC",
        "display_url" : "goo.gl\/sdVntC"
      } ]
    },
    "geo" : { },
    "id_str" : "471025090227105792",
    "text" : "Race Day Notes (5\/26) - #KyOaks winner Untapable works, eyes Mother Goose (Reed Palmer photo) http:\/\/t.co\/ZG8ADtn7Fv http:\/\/t.co\/GyAcDLL4ST",
    "id" : 471025090227105792,
    "created_at" : "2014-05-26 20:28:27 +0000",
    "user" : {
      "name" : "Churchill Downs",
      "screen_name" : "ChurchillDowns",
      "protected" : false,
      "id_str" : "19338246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459057872102375424\/30kw_rn7_normal.jpeg",
      "id" : 19338246,
      "verified" : true
    }
  },
  "id" : 471058390890737665,
  "created_at" : "2014-05-26 22:40:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/YfxELnqlcR",
      "expanded_url" : "http:\/\/tiramisuofnorthville.com\/",
      "display_url" : "tiramisuofnorthville.com"
    } ]
  },
  "in_reply_to_status_id_str" : "469608208722436096",
  "geo" : { },
  "id_str" : "471057923506860032",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 Tiramisu http:\/\/t.co\/YfxELnqlcR, lol",
  "id" : 471057923506860032,
  "in_reply_to_status_id" : 469608208722436096,
  "created_at" : "2014-05-26 22:38:55 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 3, 14 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teaparty",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/545bbCTzlF",
      "expanded_url" : "http:\/\/bddy.me\/1mseNhI",
      "display_url" : "bddy.me\/1mseNhI"
    } ]
  },
  "geo" : { },
  "id_str" : "471057389852954624",
  "text" : "RT @TPPatriots: Obama Admin Preparing For Unlawful Bailout of Insurance Industry http:\/\/t.co\/545bbCTzlF #teaparty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.buddymedia.com\" rel=\"nofollow\"\u003EStream Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teaparty",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/545bbCTzlF",
        "expanded_url" : "http:\/\/bddy.me\/1mseNhI",
        "display_url" : "bddy.me\/1mseNhI"
      } ]
    },
    "geo" : { },
    "id_str" : "470919037678260224",
    "text" : "Obama Admin Preparing For Unlawful Bailout of Insurance Industry http:\/\/t.co\/545bbCTzlF #teaparty",
    "id" : 470919037678260224,
    "created_at" : "2014-05-26 13:27:02 +0000",
    "user" : {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "protected" : false,
      "id_str" : "86177206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892758166307524608\/npw0LhCp_normal.jpg",
      "id" : 86177206,
      "verified" : true
    }
  },
  "id" : 471057389852954624,
  "created_at" : "2014-05-26 22:36:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 0, 11 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471057349424066562",
  "in_reply_to_user_id" : 86177206,
  "text" : "@TPPatriots Obama should rename his position to lair in chief",
  "id" : 471057349424066562,
  "created_at" : "2014-05-26 22:36:38 +0000",
  "in_reply_to_screen_name" : "TPPatriots",
  "in_reply_to_user_id_str" : "86177206",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u043B\u0430\u0434\u0438\u043C\u0438\u0440 \u041F\u0443\u0442\u0438\u043D",
      "screen_name" : "PutinRF",
      "indices" : [ 0, 8 ],
      "id_str" : "438133358",
      "id" : 438133358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471057047136399360",
  "in_reply_to_user_id" : 438133358,
  "text" : "@PutinRF Putin is my type of president, brilliant, courageous, and strong",
  "id" : 471057047136399360,
  "created_at" : "2014-05-26 22:35:26 +0000",
  "in_reply_to_screen_name" : "PutinRF",
  "in_reply_to_user_id_str" : "438133358",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "App Annie",
      "screen_name" : "appannie",
      "indices" : [ 3, 12 ],
      "id_str" : "99905991",
      "id" : 99905991
    }, {
      "name" : "AppOnboard Founder",
      "screen_name" : "bruinengineer",
      "indices" : [ 44, 58 ],
      "id_str" : "946709881",
      "id" : 946709881
    }, {
      "name" : "David Iwanow",
      "screen_name" : "davidiwanow",
      "indices" : [ 59, 71 ],
      "id_str" : "18958504",
      "id" : 18958504
    }, {
      "name" : "Matthew Ho",
      "screen_name" : "inspiredworlds",
      "indices" : [ 72, 87 ],
      "id_str" : "18015731",
      "id" : 18015731
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 88, 100 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "AdColony",
      "screen_name" : "AdColony",
      "indices" : [ 101, 110 ],
      "id_str" : "129003530",
      "id" : 129003530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/6Up8Qbnnie",
      "expanded_url" : "http:\/\/sumall.com\/thankyou",
      "display_url" : "sumall.com\/thankyou"
    } ]
  },
  "geo" : { },
  "id_str" : "470721387942776832",
  "text" : "RT @appannie: Thanks for the RTs this week! @bruinengineer @davidiwanow @inspiredworlds @gamer456148 @AdColony via http:\/\/t.co\/6Up8Qbnnie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sumall.com\/\" rel=\"nofollow\"\u003ESumAll\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AppOnboard Founder",
        "screen_name" : "bruinengineer",
        "indices" : [ 30, 44 ],
        "id_str" : "946709881",
        "id" : 946709881
      }, {
        "name" : "David Iwanow",
        "screen_name" : "davidiwanow",
        "indices" : [ 45, 57 ],
        "id_str" : "18958504",
        "id" : 18958504
      }, {
        "name" : "Matthew Ho",
        "screen_name" : "inspiredworlds",
        "indices" : [ 58, 73 ],
        "id_str" : "18015731",
        "id" : 18015731
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 74, 86 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "AdColony",
        "screen_name" : "AdColony",
        "indices" : [ 87, 96 ],
        "id_str" : "129003530",
        "id" : 129003530
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/6Up8Qbnnie",
        "expanded_url" : "http:\/\/sumall.com\/thankyou",
        "display_url" : "sumall.com\/thankyou"
      } ]
    },
    "geo" : { },
    "id_str" : "470621891523538945",
    "text" : "Thanks for the RTs this week! @bruinengineer @davidiwanow @inspiredworlds @gamer456148 @AdColony via http:\/\/t.co\/6Up8Qbnnie",
    "id" : 470621891523538945,
    "created_at" : "2014-05-25 17:46:17 +0000",
    "user" : {
      "name" : "App Annie",
      "screen_name" : "appannie",
      "protected" : false,
      "id_str" : "99905991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654474835238645761\/6royFP5C_normal.png",
      "id" : 99905991,
      "verified" : true
    }
  },
  "id" : 470721387942776832,
  "created_at" : "2014-05-26 00:21:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469608208722436096",
  "text" : "Went to Turmisu, had the lasgna and mozzarella chicken 7\/10",
  "id" : 469608208722436096,
  "created_at" : "2014-05-22 22:38:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sethabovealltherest",
      "screen_name" : "SethCanoy",
      "indices" : [ 3, 13 ],
      "id_str" : "1596221142",
      "id" : 1596221142
    }, {
      "name" : "JC Worley",
      "screen_name" : "JCWorley",
      "indices" : [ 15, 24 ],
      "id_str" : "41160359",
      "id" : 41160359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469560738218913792",
  "text" : "RT @SethCanoy: @JCWorley could you come down to Kentucky and see some awesome students graduate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JC Worley",
        "screen_name" : "JCWorley",
        "indices" : [ 0, 9 ],
        "id_str" : "41160359",
        "id" : 41160359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "469316552488402944",
    "geo" : { },
    "id_str" : "469330954423504896",
    "in_reply_to_user_id" : 41160359,
    "text" : "@JCWorley could you come down to Kentucky and see some awesome students graduate",
    "id" : 469330954423504896,
    "in_reply_to_status_id" : 469316552488402944,
    "created_at" : "2014-05-22 04:16:33 +0000",
    "in_reply_to_screen_name" : "JCWorley",
    "in_reply_to_user_id_str" : "41160359",
    "user" : {
      "name" : "Sethabovealltherest",
      "screen_name" : "SethCanoy",
      "protected" : false,
      "id_str" : "1596221142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806274825966747648\/sQNZY8kz_normal.jpg",
      "id" : 1596221142,
      "verified" : false
    }
  },
  "id" : 469560738218913792,
  "created_at" : "2014-05-22 19:29:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469560334789771264",
  "text" : "For my two thousandth tweet I want to talk about how much I love the Coptic Orthodox Church",
  "id" : 469560334789771264,
  "created_at" : "2014-05-22 19:28:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Sethabovealltherest",
      "screen_name" : "SethCanoy",
      "indices" : [ 14, 24 ],
      "id_str" : "1596221142",
      "id" : 1596221142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469559996103929856",
  "text" : "RT @MarkDice: @SethCanoy she is an abomination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sethabovealltherest",
        "screen_name" : "SethCanoy",
        "indices" : [ 0, 10 ],
        "id_str" : "1596221142",
        "id" : 1596221142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "469513859376881664",
    "geo" : { },
    "id_str" : "469514758312718336",
    "in_reply_to_user_id" : 1596221142,
    "text" : "@SethCanoy she is an abomination.",
    "id" : 469514758312718336,
    "in_reply_to_status_id" : 469513859376881664,
    "created_at" : "2014-05-22 16:26:56 +0000",
    "in_reply_to_screen_name" : "SethCanoy",
    "in_reply_to_user_id_str" : "1596221142",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 469559996103929856,
  "created_at" : "2014-05-22 19:26:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/lWLXdSGdYj",
      "expanded_url" : "http:\/\/1drv.ms\/TyRdXj",
      "display_url" : "1drv.ms\/TyRdXj"
    } ]
  },
  "geo" : { },
  "id_str" : "469559666293219328",
  "text" : "Strawberry Ice cream pop, yum http:\/\/t.co\/lWLXdSGdYj",
  "id" : 469559666293219328,
  "created_at" : "2014-05-22 19:25:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 0, 8 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Twitter Verified",
      "screen_name" : "verified",
      "indices" : [ 9, 18 ],
      "id_str" : "63796828",
      "id" : 63796828
    }, {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 76, 89 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469281384205266944",
  "in_reply_to_user_id" : 783214,
  "text" : "@twitter @verified @Support Can you please verify the Coptic Pope's Account @PopeTawadros, it would be highly appreciated",
  "id" : 469281384205266944,
  "created_at" : "2014-05-22 00:59:35 +0000",
  "in_reply_to_screen_name" : "Twitter",
  "in_reply_to_user_id_str" : "783214",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 0, 12 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469216456933003264",
  "geo" : { },
  "id_str" : "469280887259951104",
  "in_reply_to_user_id" : 813286,
  "text" : "@BarackObama Good now can you take it away from us who don't want this crap?",
  "id" : 469280887259951104,
  "in_reply_to_status_id" : 469216456933003264,
  "created_at" : "2014-05-22 00:57:37 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/XXeZteiZO5",
      "expanded_url" : "http:\/\/youtu.be\/hcsBXJv2hB4",
      "display_url" : "youtu.be\/hcsBXJv2hB4"
    } ]
  },
  "geo" : { },
  "id_str" : "469279877862924288",
  "text" : "RT @MarkDice: The Statue of Liberty will be Destroyed....by Global Warming, Claims New Report!!! Hahah    http:\/\/t.co\/XXeZteiZO5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/XXeZteiZO5",
        "expanded_url" : "http:\/\/youtu.be\/hcsBXJv2hB4",
        "display_url" : "youtu.be\/hcsBXJv2hB4"
      } ]
    },
    "geo" : { },
    "id_str" : "469151900395663360",
    "text" : "The Statue of Liberty will be Destroyed....by Global Warming, Claims New Report!!! Hahah    http:\/\/t.co\/XXeZteiZO5",
    "id" : 469151900395663360,
    "created_at" : "2014-05-21 16:25:04 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 469279877862924288,
  "created_at" : "2014-05-22 00:53:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469279742424666112",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze I have a challenge for you and a design, are you in?",
  "id" : 469279742424666112,
  "created_at" : "2014-05-22 00:53:04 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "App Annie",
      "screen_name" : "appannie",
      "indices" : [ 3, 12 ],
      "id_str" : "99905991",
      "id" : 99905991
    }, {
      "name" : "Mayank Dhingra",
      "screen_name" : "mayankdhingra",
      "indices" : [ 14, 28 ],
      "id_str" : "7815702",
      "id" : 7815702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468823047214866432",
  "text" : "RT @appannie: @mayankdhingra Soon! More countries are coming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayank Dhingra",
        "screen_name" : "mayankdhingra",
        "indices" : [ 0, 14 ],
        "id_str" : "7815702",
        "id" : 7815702
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "468636657348902912",
    "geo" : { },
    "id_str" : "468783777750458370",
    "in_reply_to_user_id" : 7815702,
    "text" : "@mayankdhingra Soon! More countries are coming.",
    "id" : 468783777750458370,
    "in_reply_to_status_id" : 468636657348902912,
    "created_at" : "2014-05-20 16:02:16 +0000",
    "in_reply_to_screen_name" : "mayankdhingra",
    "in_reply_to_user_id_str" : "7815702",
    "user" : {
      "name" : "App Annie",
      "screen_name" : "appannie",
      "protected" : false,
      "id_str" : "99905991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654474835238645761\/6royFP5C_normal.png",
      "id" : 99905991,
      "verified" : true
    }
  },
  "id" : 468823047214866432,
  "created_at" : "2014-05-20 18:38:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/ujCCLpzDMw",
      "expanded_url" : "http:\/\/1drv.ms\/1o5rmjH",
      "display_url" : "1drv.ms\/1o5rmjH"
    } ]
  },
  "geo" : { },
  "id_str" : "468238508725768193",
  "text" : "My roast beef creation got onion chips, mustard, honey mustard, and Dijon mustard http:\/\/t.co\/ujCCLpzDMw",
  "id" : 468238508725768193,
  "created_at" : "2014-05-19 03:55:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468133942923522049",
  "text" : "I don't care what anyone says frozen yogurt and fruit sherbets taste better then ice cream",
  "id" : 468133942923522049,
  "created_at" : "2014-05-18 21:00:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468078948107026432",
  "text" : "Seen little ones today at church",
  "id" : 468078948107026432,
  "created_at" : "2014-05-18 17:21:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bishop Angaelos \u0646",
      "screen_name" : "BishopAngaelos",
      "indices" : [ 3, 18 ],
      "id_str" : "137353605",
      "id" : 137353605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Religious",
      "indices" : [ 48, 58 ]
    }, {
      "text" : "Freedom",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "FreedomOfFaith",
      "indices" : [ 68, 83 ]
    }, {
      "text" : "Sudan",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "BringBackOurGirls",
      "indices" : [ 114, 132 ]
    }, {
      "text" : "Iran",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/npLcLGwmf9",
      "expanded_url" : "http:\/\/bit.ly\/1mB5BbC",
      "display_url" : "bit.ly\/1mB5BbC"
    } ]
  },
  "geo" : { },
  "id_str" : "467847471368912896",
  "text" : "RT @BishopAngaelos: My comment on International #Religious #Freedom #FreedomOfFaith http:\/\/t.co\/npLcLGwmf9 #Sudan #BringBackOurGirls #Iran \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CopticMediaUK",
        "screen_name" : "CopticMediaUK",
        "indices" : [ 126, 140 ],
        "id_str" : "245131304",
        "id" : 245131304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Religious",
        "indices" : [ 28, 38 ]
      }, {
        "text" : "Freedom",
        "indices" : [ 39, 47 ]
      }, {
        "text" : "FreedomOfFaith",
        "indices" : [ 48, 63 ]
      }, {
        "text" : "Sudan",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "BringBackOurGirls",
        "indices" : [ 94, 112 ]
      }, {
        "text" : "Iran",
        "indices" : [ 113, 118 ]
      }, {
        "text" : "Egypt",
        "indices" : [ 119, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/npLcLGwmf9",
        "expanded_url" : "http:\/\/bit.ly\/1mB5BbC",
        "display_url" : "bit.ly\/1mB5BbC"
      } ]
    },
    "geo" : { },
    "id_str" : "467386298379296769",
    "text" : "My comment on International #Religious #Freedom #FreedomOfFaith http:\/\/t.co\/npLcLGwmf9 #Sudan #BringBackOurGirls #Iran #Egypt @CopticMediaUK",
    "id" : 467386298379296769,
    "created_at" : "2014-05-16 19:29:11 +0000",
    "user" : {
      "name" : "Bishop Angaelos \u0646",
      "screen_name" : "BishopAngaelos",
      "protected" : false,
      "id_str" : "137353605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855041352668762113\/UVnjSd-f_normal.jpg",
      "id" : 137353605,
      "verified" : true
    }
  },
  "id" : 467847471368912896,
  "created_at" : "2014-05-18 02:01:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/lywcV7WgoG",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=AmBRO92kvrw",
      "display_url" : "youtube.com\/watch?v=AmBRO9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467847285766754304",
  "text" : "New concept car https:\/\/t.co\/lywcV7WgoG",
  "id" : 467847285766754304,
  "created_at" : "2014-05-18 02:00:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bishop Angaelos \u0646",
      "screen_name" : "BishopAngaelos",
      "indices" : [ 3, 18 ],
      "id_str" : "137353605",
      "id" : 137353605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lives",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "witness",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "deeds",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467696222703071232",
  "text" : "RT @BishopAngaelos: 'There would be no need for sermons if our #lives were shining...or words if we bore #witness with our #deeds' #Chrysos\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lives",
        "indices" : [ 43, 49 ]
      }, {
        "text" : "witness",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "deeds",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "Chrysostom",
        "indices" : [ 111, 122 ]
      }, {
        "text" : "MoreThanWords",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467210958960885760",
    "text" : "'There would be no need for sermons if our #lives were shining...or words if we bore #witness with our #deeds' #Chrysostom #MoreThanWords",
    "id" : 467210958960885760,
    "created_at" : "2014-05-16 07:52:27 +0000",
    "user" : {
      "name" : "Bishop Angaelos \u0646",
      "screen_name" : "BishopAngaelos",
      "protected" : false,
      "id_str" : "137353605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855041352668762113\/UVnjSd-f_normal.jpg",
      "id" : 137353605,
      "verified" : true
    }
  },
  "id" : 467696222703071232,
  "created_at" : "2014-05-17 16:00:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467695748037873664",
  "text" : "Anyways stay tuned and be sure to checkout the links in my twitter bio and my twitter header.",
  "id" : 467695748037873664,
  "created_at" : "2014-05-17 15:58:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467695568622329856",
  "text" : "Thank you so much for helping me reach around 1.2 million downloads, and around 601,000 followers on facebook",
  "id" : 467695568622329856,
  "created_at" : "2014-05-17 15:58:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SUS Copts",
      "screen_name" : "suscopts",
      "indices" : [ 3, 12 ],
      "id_str" : "281563816",
      "id" : 281563816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/bi2QpEmb4F",
      "expanded_url" : "http:\/\/bit.ly\/1iUtV7d",
      "display_url" : "bit.ly\/1iUtV7d"
    } ]
  },
  "geo" : { },
  "id_str" : "467695364418449410",
  "text" : "RT @suscopts: New Press Release - Broadcasting: Acts 25 http:\/\/t.co\/bi2QpEmb4F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/bi2QpEmb4F",
        "expanded_url" : "http:\/\/bit.ly\/1iUtV7d",
        "display_url" : "bit.ly\/1iUtV7d"
      } ]
    },
    "geo" : { },
    "id_str" : "466688973578829824",
    "text" : "New Press Release - Broadcasting: Acts 25 http:\/\/t.co\/bi2QpEmb4F",
    "id" : 466688973578829824,
    "created_at" : "2014-05-14 21:18:16 +0000",
    "user" : {
      "name" : "SUS Copts",
      "screen_name" : "suscopts",
      "protected" : false,
      "id_str" : "281563816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473274874811523072\/3fwoHegW_normal.png",
      "id" : 281563816,
      "verified" : false
    }
  },
  "id" : 467695364418449410,
  "created_at" : "2014-05-17 15:57:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEO Dealz",
      "screen_name" : "seodealz",
      "indices" : [ 3, 12 ],
      "id_str" : "1407508130",
      "id" : 1407508130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/JTZwvw4lfm",
      "expanded_url" : "http:\/\/bit.ly\/1hZmyKJ",
      "display_url" : "bit.ly\/1hZmyKJ"
    } ]
  },
  "geo" : { },
  "id_str" : "467695308277678080",
  "text" : "RT @seodealz: http:\/\/t.co\/JTZwvw4lfm - Celebrity Video Testemonial as Andrew Magdy Kamal for $45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.seodealz.com\/twitter\" rel=\"nofollow\"\u003ESEODealz - Nextscripts\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/JTZwvw4lfm",
        "expanded_url" : "http:\/\/bit.ly\/1hZmyKJ",
        "display_url" : "bit.ly\/1hZmyKJ"
      } ]
    },
    "geo" : { },
    "id_str" : "453721662744064000",
    "text" : "http:\/\/t.co\/JTZwvw4lfm - Celebrity Video Testemonial as Andrew Magdy Kamal for $45",
    "id" : 453721662744064000,
    "created_at" : "2014-04-09 02:30:48 +0000",
    "user" : {
      "name" : "SEO Dealz",
      "screen_name" : "seodealz",
      "protected" : false,
      "id_str" : "1407508130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3621716730\/171dc7590eb7c53abde056f9ac024211_normal.jpeg",
      "id" : 1407508130,
      "verified" : false
    }
  },
  "id" : 467695308277678080,
  "created_at" : "2014-05-17 15:57:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2665RoOm\u00E3n  \u2665",
      "screen_name" : "Culona_x2",
      "indices" : [ 3, 13 ],
      "id_str" : "1956657908",
      "id" : 1956657908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467695209036255234",
  "text" : "RT @Culona_x2: Teenager Gets Patent on Hydrofuel Solar Car Design: Teenager Andrew Magdy Kamal is the co inventor of the Hydr... http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/IiXOPCFrd2",
        "expanded_url" : "http:\/\/cnn.it\/17fdJrq",
        "display_url" : "cnn.it\/17fdJrq"
      } ]
    },
    "geo" : { },
    "id_str" : "393410538996117504",
    "text" : "Teenager Gets Patent on Hydrofuel Solar Car Design: Teenager Andrew Magdy Kamal is the co inventor of the Hydr... http:\/\/t.co\/IiXOPCFrd2",
    "id" : 393410538996117504,
    "created_at" : "2013-10-24 16:15:56 +0000",
    "user" : {
      "name" : "\u2665RoOm\u00E3n  \u2665",
      "screen_name" : "Culona_x2",
      "protected" : false,
      "id_str" : "1956657908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527570439561019392\/C2Y4uKPN_normal.jpeg",
      "id" : 1956657908,
      "verified" : false
    }
  },
  "id" : 467695209036255234,
  "created_at" : "2014-05-17 15:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467695027590680576",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Has the Orwellian nightmare started to become true with robotics, bio-metric chips, spying, VR, AR, Mixed Reality, and AI?",
  "id" : 467695027590680576,
  "created_at" : "2014-05-17 15:55:58 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/fdixNAQ1Vl",
      "expanded_url" : "http:\/\/youtu.be\/Gk13sMgSbVs",
      "display_url" : "youtu.be\/Gk13sMgSbVs"
    } ]
  },
  "geo" : { },
  "id_str" : "467449653818961921",
  "text" : "RT @MarkDice: Mandatory Annual Mental Health Evaluations Under ObamaCare Coming Soon?   http:\/\/t.co\/fdixNAQ1Vl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/fdixNAQ1Vl",
        "expanded_url" : "http:\/\/youtu.be\/Gk13sMgSbVs",
        "display_url" : "youtu.be\/Gk13sMgSbVs"
      } ]
    },
    "geo" : { },
    "id_str" : "467341686931476480",
    "text" : "Mandatory Annual Mental Health Evaluations Under ObamaCare Coming Soon?   http:\/\/t.co\/fdixNAQ1Vl",
    "id" : 467341686931476480,
    "created_at" : "2014-05-16 16:31:55 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 467449653818961921,
  "created_at" : "2014-05-16 23:40:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 0, 10 ],
      "id_str" : "17454769",
      "id" : 17454769
    }, {
      "name" : "Top Secret News",
      "screen_name" : "JesseVentura_",
      "indices" : [ 15, 29 ],
      "id_str" : "836680148",
      "id" : 836680148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467449412684226560",
  "in_reply_to_user_id" : 17454769,
  "text" : "@glennbeck Now @JesseVentura_ now went to extremes by calling Jesus gay, you were right what a dirtbag he is.",
  "id" : 467449412684226560,
  "created_at" : "2014-05-16 23:39:59 +0000",
  "in_reply_to_screen_name" : "glennbeck",
  "in_reply_to_user_id_str" : "17454769",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/1NGH9j2J4e",
      "expanded_url" : "https:\/\/www.youtube.com\/playlist?list=PL_XI9KptT7lwVVmndSOWh0ECF5OrmcJ96",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467169475070947328",
  "text" : "Check out my coding portfolio at: https:\/\/t.co\/1NGH9j2J4e",
  "id" : 467169475070947328,
  "created_at" : "2014-05-16 05:07:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/LLBbnvq2q1",
      "expanded_url" : "http:\/\/fb.me\/2Av3IJ4pT",
      "display_url" : "fb.me\/2Av3IJ4pT"
    } ]
  },
  "geo" : { },
  "id_str" : "467147459441868801",
  "text" : "RT @Lukewearechange: The Dream of Change Media University\n\nNEW VIDEO -... http:\/\/t.co\/LLBbnvq2q1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/LLBbnvq2q1",
        "expanded_url" : "http:\/\/fb.me\/2Av3IJ4pT",
        "display_url" : "fb.me\/2Av3IJ4pT"
      } ]
    },
    "geo" : { },
    "id_str" : "466367294533541888",
    "text" : "The Dream of Change Media University\n\nNEW VIDEO -... http:\/\/t.co\/LLBbnvq2q1",
    "id" : 466367294533541888,
    "created_at" : "2014-05-14 00:00:02 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 467147459441868801,
  "created_at" : "2014-05-16 03:40:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467147204587573248",
  "text" : "RT @colin_furze: Youtube is getting a hammering tonight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467058043512188929",
    "text" : "Youtube is getting a hammering tonight",
    "id" : 467058043512188929,
    "created_at" : "2014-05-15 21:44:49 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 467147204587573248,
  "created_at" : "2014-05-16 03:39:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/XviUOIMD48",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=_FmKibxanrw",
      "display_url" : "youtube.com\/watch?v=_FmKib\u2026"
    }, {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/t2NfiaXrgK",
      "expanded_url" : "http:\/\/fb.me\/1hUmqoubB",
      "display_url" : "fb.me\/1hUmqoubB"
    } ]
  },
  "geo" : { },
  "id_str" : "467146487822942208",
  "text" : "Make money playing facebook games:\nhttps:\/\/t.co\/XviUOIMD48 http:\/\/t.co\/t2NfiaXrgK",
  "id" : 467146487822942208,
  "created_at" : "2014-05-16 03:36:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467030651078983681",
  "text" : "RT @MarkDice: I will on a new episode of Secret Societies of Hollywood: Lies and Scandals on E! tonight at 8pm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466992589984788480",
    "text" : "I will on a new episode of Secret Societies of Hollywood: Lies and Scandals on E! tonight at 8pm.",
    "id" : 466992589984788480,
    "created_at" : "2014-05-15 17:24:44 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 467030651078983681,
  "created_at" : "2014-05-15 19:55:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/X6RiPYnXiO",
      "expanded_url" : "https:\/\/sarniahosting.com",
      "display_url" : "sarniahosting.com"
    } ]
  },
  "geo" : { },
  "id_str" : "467030384035639296",
  "text" : "Please check out https:\/\/t.co\/X6RiPYnXiO, a really low cost hosting service, I may use it.",
  "id" : 467030384035639296,
  "created_at" : "2014-05-15 19:54:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/aspThyujtP",
      "expanded_url" : "http:\/\/fb.me\/6s6YhSsqV",
      "display_url" : "fb.me\/6s6YhSsqV"
    } ]
  },
  "geo" : { },
  "id_str" : "466738284475842560",
  "text" : "What an utter disgrace to the nation of Israel if this really happens... http:\/\/t.co\/aspThyujtP",
  "id" : 466738284475842560,
  "created_at" : "2014-05-15 00:34:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/CzFB1rqNpk",
      "expanded_url" : "http:\/\/1drv.ms\/RRhO0t",
      "display_url" : "1drv.ms\/RRhO0t"
    } ]
  },
  "geo" : { },
  "id_str" : "466642747991285760",
  "text" : "They have it, resizing icons for windows 8 http:\/\/t.co\/CzFB1rqNpk",
  "id" : 466642747991285760,
  "created_at" : "2014-05-14 18:14:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tommee profitt",
      "screen_name" : "tommeeprofitt",
      "indices" : [ 3, 17 ],
      "id_str" : "23875390",
      "id" : 23875390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466282804792135680",
  "text" : "RT @tommeeprofitt: BY THE END OF THE WEEK MANY OF MY OLD YOUTUBE VIDEOS WILL BE TAKEN DOWN FOREVER. IF YOU WANNA SEE ANY OF THEM ONE LAST T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465850086488932352",
    "text" : "BY THE END OF THE WEEK MANY OF MY OLD YOUTUBE VIDEOS WILL BE TAKEN DOWN FOREVER. IF YOU WANNA SEE ANY OF THEM ONE LAST TIME NOW IS THE TIME!",
    "id" : 465850086488932352,
    "created_at" : "2014-05-12 13:44:50 +0000",
    "user" : {
      "name" : "tommee profitt",
      "screen_name" : "tommeeprofitt",
      "protected" : false,
      "id_str" : "23875390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922586468543057923\/pSyFPcwe_normal.jpg",
      "id" : 23875390,
      "verified" : false
    }
  },
  "id" : 466282804792135680,
  "created_at" : "2014-05-13 18:24:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/StaKydF1oQ",
      "expanded_url" : "http:\/\/appsdowntown.com\/list.aspx?DevId=162231",
      "display_url" : "appsdowntown.com\/list.aspx?DevI\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/2oKNwAzfFQ",
      "expanded_url" : "http:\/\/apps.opera.com\/cs_az\/catalog.php?vendor_id=102975",
      "display_url" : "apps.opera.com\/cs_az\/catalog.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466282549514227712",
  "text" : "Android apps in appsdowntown: http:\/\/t.co\/StaKydF1oQ Android apps on Opera Mobile Store: http:\/\/t.co\/2oKNwAzfFQ",
  "id" : 466282549514227712,
  "created_at" : "2014-05-13 18:23:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkDice\/status\/466087291082268673\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/ulvZg3d6n8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnff68HIUAAFzfb.jpg",
      "id_str" : "466087290117574656",
      "id" : 466087290117574656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnff68HIUAAFzfb.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/ulvZg3d6n8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466127933417873408",
  "text" : "RT @MarkDice: http:\/\/t.co\/ulvZg3d6n8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkDice\/status\/466087291082268673\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ulvZg3d6n8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnff68HIUAAFzfb.jpg",
        "id_str" : "466087290117574656",
        "id" : 466087290117574656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnff68HIUAAFzfb.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/ulvZg3d6n8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466087291082268673",
    "text" : "http:\/\/t.co\/ulvZg3d6n8",
    "id" : 466087291082268673,
    "created_at" : "2014-05-13 05:27:24 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 466127933417873408,
  "created_at" : "2014-05-13 08:08:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/khdM49nPa9",
      "expanded_url" : "http:\/\/sea19.blogspot.com\/2014\/05\/are-you-kidding-talk-about-bad-timing.html#.U3H8VWhOJs8.twitter",
      "display_url" : "sea19.blogspot.com\/2014\/05\/are-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466127748973350913",
  "text" : "Are You Kidding?  Talk About Bad Timing.......... http:\/\/t.co\/khdM49nPa9",
  "id" : 466127748973350913,
  "created_at" : "2014-05-13 08:08:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/6DnBeXmscu",
      "expanded_url" : "http:\/\/1drv.ms\/1nCiKAM",
      "display_url" : "1drv.ms\/1nCiKAM"
    } ]
  },
  "geo" : { },
  "id_str" : "465547849371885568",
  "text" : "Ate a goat cheese pizza, was good http:\/\/t.co\/6DnBeXmscu",
  "id" : 465547849371885568,
  "created_at" : "2014-05-11 17:43:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465427265099034624",
  "text" : "RT @MarkDice: I'll be on America's Book of Secrets (the Billionaire Agenda episode) tonight on H2 (History Channel 2) at 10pm Eastern (7 pa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465175983830888448",
    "text" : "I'll be on America's Book of Secrets (the Billionaire Agenda episode) tonight on H2 (History Channel 2) at 10pm Eastern (7 pacific).",
    "id" : 465175983830888448,
    "created_at" : "2014-05-10 17:06:11 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 465427265099034624,
  "created_at" : "2014-05-11 09:44:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/P7Dtt2BZVh",
      "expanded_url" : "http:\/\/instagram.com\/p\/n1nkadBmuq\/",
      "display_url" : "instagram.com\/p\/n1nkadBmuq\/"
    } ]
  },
  "geo" : { },
  "id_str" : "465426413248450562",
  "text" : "RT @Lukewearechange: United We Stand just kicked off, lots of people are here http:\/\/t.co\/P7Dtt2BZVh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/P7Dtt2BZVh",
        "expanded_url" : "http:\/\/instagram.com\/p\/n1nkadBmuq\/",
        "display_url" : "instagram.com\/p\/n1nkadBmuq\/"
      } ]
    },
    "geo" : { },
    "id_str" : "465299477939888128",
    "text" : "United We Stand just kicked off, lots of people are here http:\/\/t.co\/P7Dtt2BZVh",
    "id" : 465299477939888128,
    "created_at" : "2014-05-11 01:16:55 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 465426413248450562,
  "created_at" : "2014-05-11 09:41:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/sKYb21XBUc",
      "expanded_url" : "http:\/\/1drv.ms\/1jMnSla",
      "display_url" : "1drv.ms\/1jMnSla"
    } ]
  },
  "geo" : { },
  "id_str" : "465218677088874496",
  "text" : "Ribs made of beef http:\/\/t.co\/sKYb21XBUc",
  "id" : 465218677088874496,
  "created_at" : "2014-05-10 19:55:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/c8A5QviIWs",
      "expanded_url" : "http:\/\/seocheckout.com",
      "display_url" : "seocheckout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "464904194973913088",
  "text" : "Nicely designed website, http:\/\/t.co\/c8A5QviIWs",
  "id" : 464904194973913088,
  "created_at" : "2014-05-09 23:06:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/7ck13Dna1C",
      "expanded_url" : "http:\/\/www.wearechange.org",
      "display_url" : "wearechange.org"
    }, {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/FuaeLi0jSm",
      "expanded_url" : "https:\/\/www.facebook.com\/WeAreChange",
      "display_url" : "facebook.com\/WeAreChange"
    }, {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/PQVTqiU1Kl",
      "expanded_url" : "http:\/\/fb.me\/2mEv42GFN",
      "display_url" : "fb.me\/2mEv42GFN"
    } ]
  },
  "geo" : { },
  "id_str" : "464636247357804544",
  "text" : "RT @Lukewearechange: Visit: http:\/\/t.co\/7ck13Dna1C \nLike: https:\/\/t.co\/FuaeLi0jSm\nSubscribe:... http:\/\/t.co\/PQVTqiU1Kl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/7ck13Dna1C",
        "expanded_url" : "http:\/\/www.wearechange.org",
        "display_url" : "wearechange.org"
      }, {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/FuaeLi0jSm",
        "expanded_url" : "https:\/\/www.facebook.com\/WeAreChange",
        "display_url" : "facebook.com\/WeAreChange"
      }, {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/PQVTqiU1Kl",
        "expanded_url" : "http:\/\/fb.me\/2mEv42GFN",
        "display_url" : "fb.me\/2mEv42GFN"
      } ]
    },
    "geo" : { },
    "id_str" : "464615748934336512",
    "text" : "Visit: http:\/\/t.co\/7ck13Dna1C \nLike: https:\/\/t.co\/FuaeLi0jSm\nSubscribe:... http:\/\/t.co\/PQVTqiU1Kl",
    "id" : 464615748934336512,
    "created_at" : "2014-05-09 04:00:01 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 464636247357804544,
  "created_at" : "2014-05-09 05:21:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464635485961596928",
  "text" : "Cheese salsa, chunky salsa, garlic goat cheese, corn bread crackers. Just some of the things I had today",
  "id" : 464635485961596928,
  "created_at" : "2014-05-09 05:18:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/qfoVyvcLjc",
      "expanded_url" : "http:\/\/1drv.ms\/1nmFgjx",
      "display_url" : "1drv.ms\/1nmFgjx"
    } ]
  },
  "geo" : { },
  "id_str" : "464575243043241984",
  "text" : "Mango popsicle http:\/\/t.co\/qfoVyvcLjc",
  "id" : 464575243043241984,
  "created_at" : "2014-05-09 01:19:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 18, 34 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464224973620408321",
  "text" : "RT @MarkDice: Now @Lukewearechange from We Are Change wants to teach you how to confront scumbag politicans yourself VIDEO: https:\/\/t.co\/GV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Rudkowski",
        "screen_name" : "Lukewearechange",
        "indices" : [ 4, 20 ],
        "id_str" : "95994080",
        "id" : 95994080
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/GVkFRKlzL0",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bXDNClOPrP8",
        "display_url" : "youtube.com\/watch?v=bXDNCl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464164804673163264",
    "text" : "Now @Lukewearechange from We Are Change wants to teach you how to confront scumbag politicans yourself VIDEO: https:\/\/t.co\/GVkFRKlzL0",
    "id" : 464164804673163264,
    "created_at" : "2014-05-07 22:08:07 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 464224973620408321,
  "created_at" : "2014-05-08 02:07:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 87, 99 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464224878120300544",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice What the hell? The maker of the gay bomb won the IG Noble Prize in 2007, and @BarackObama won the real noble peace prize in 2008",
  "id" : 464224878120300544,
  "created_at" : "2014-05-08 02:06:50 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "indices" : [ 90, 97 ],
      "id_str" : "17220934",
      "id" : 17220934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463886957408305153",
  "text" : "RT @MarkDice: Now it's \"climate disruption.\"   Haha.  Third rebrand is the charm, right?  @algore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Al Gore",
        "screen_name" : "algore",
        "indices" : [ 76, 83 ],
        "id_str" : "17220934",
        "id" : 17220934
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463848143939842048",
    "text" : "Now it's \"climate disruption.\"   Haha.  Third rebrand is the charm, right?  @algore",
    "id" : 463848143939842048,
    "created_at" : "2014-05-07 01:09:50 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 463886957408305153,
  "created_at" : "2014-05-07 03:44:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 10, 26 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/463886837157621761\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/6vdHpC1Tfe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnAOnprCYAAyJq8.jpg",
      "id_str" : "463886835983212544",
      "id" : 463886835983212544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnAOnprCYAAyJq8.jpg",
      "sizes" : [ {
        "h" : 193,
        "resize" : "fit",
        "w" : 549
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 549
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 549
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 549
      } ],
      "display_url" : "pic.twitter.com\/6vdHpC1Tfe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463886837157621761",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice @Lukewearechange I put my own personal religious beliefs on my facebook page &amp; got charged with hatespeech http:\/\/t.co\/6vdHpC1Tfe",
  "id" : 463886837157621761,
  "created_at" : "2014-05-07 03:43:35 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Caesars",
      "screen_name" : "littlecaesars",
      "indices" : [ 33, 47 ],
      "id_str" : "57824414",
      "id" : 57824414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/TtPX6etgx4",
      "expanded_url" : "http:\/\/1drv.ms\/1jy77tU",
      "display_url" : "1drv.ms\/1jy77tU"
    } ]
  },
  "geo" : { },
  "id_str" : "463810195169083393",
  "text" : "Went to a college counselor, ate @littlecaesars supreme pizza, and had a haircut. Good day http:\/\/t.co\/TtPX6etgx4",
  "id" : 463810195169083393,
  "created_at" : "2014-05-06 22:39:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/apiqwAjWMk",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZXmr_weg2ao",
      "display_url" : "youtube.com\/watch?v=ZXmr_w\u2026"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/C3F8R9CZNY",
      "expanded_url" : "http:\/\/fb.me\/2emkBwVKj",
      "display_url" : "fb.me\/2emkBwVKj"
    } ]
  },
  "geo" : { },
  "id_str" : "463539909941149697",
  "text" : "An emotionally heartfelt video, https:\/\/t.co\/apiqwAjWMk http:\/\/t.co\/C3F8R9CZNY",
  "id" : 463539909941149697,
  "created_at" : "2014-05-06 04:45:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/xsJQQYc9GF",
      "expanded_url" : "http:\/\/grantedtech.wordpress.com\/2014\/05\/05\/lets-fly-academy\/",
      "display_url" : "grantedtech.wordpress.com\/2014\/05\/05\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463446832547233792",
  "text" : "Let's fly academy review http:\/\/t.co\/xsJQQYc9GF",
  "id" : 463446832547233792,
  "created_at" : "2014-05-05 22:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463409711107149824",
  "text" : "I reached 38 android apps created and published, congrats to me.",
  "id" : 463409711107149824,
  "created_at" : "2014-05-05 20:07:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "indices" : [ 3, 19 ],
      "id_str" : "95994080",
      "id" : 95994080
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Ovk8oCCIph",
      "expanded_url" : "http:\/\/instagram.com\/p\/nmOVYeBmjE\/",
      "display_url" : "instagram.com\/p\/nmOVYeBmjE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "463401613172805632",
  "text" : "RT @Lukewearechange: With markdice who's undercover as a #Obama supporter today lol http:\/\/t.co\/Ovk8oCCIph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Ovk8oCCIph",
        "expanded_url" : "http:\/\/instagram.com\/p\/nmOVYeBmjE\/",
        "display_url" : "instagram.com\/p\/nmOVYeBmjE\/"
      } ]
    },
    "geo" : { },
    "id_str" : "463132922737074177",
    "text" : "With markdice who's undercover as a #Obama supporter today lol http:\/\/t.co\/Ovk8oCCIph",
    "id" : 463132922737074177,
    "created_at" : "2014-05-05 01:47:48 +0000",
    "user" : {
      "name" : "Luke Rudkowski",
      "screen_name" : "Lukewearechange",
      "protected" : false,
      "id_str" : "95994080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/848306522517979136\/HaZ1ocCC_normal.jpg",
      "id" : 95994080,
      "verified" : true
    }
  },
  "id" : 463401613172805632,
  "created_at" : "2014-05-05 19:35:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "App Annie",
      "screen_name" : "appannie",
      "indices" : [ 92, 101 ],
      "id_str" : "99905991",
      "id" : 99905991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/NqWxKp8jrf",
      "expanded_url" : "http:\/\/www.appannie.com\/apps\/google-play\/publisher\/20200000160098\/",
      "display_url" : "appannie.com\/apps\/google-pl\u2026"
    }, {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/yBsi6y7Lh7",
      "expanded_url" : "http:\/\/www.appannie.com\/apps\/google-play\/publisher\/20200000251198\/",
      "display_url" : "appannie.com\/apps\/google-pl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463399518042460160",
  "text" : "View my android app rankings at http:\/\/t.co\/NqWxKp8jrf and at http:\/\/t.co\/yBsi6y7Lh7 Thanks @appannie",
  "id" : 463399518042460160,
  "created_at" : "2014-05-05 19:27:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HSPHV5Wbf9",
      "expanded_url" : "http:\/\/fb.me\/6u3f0vZnt",
      "display_url" : "fb.me\/6u3f0vZnt"
    } ]
  },
  "geo" : { },
  "id_str" : "463183657268572160",
  "text" : "Let us get so many downloads for my best app ever, I took time making it and designing the graphics for it,... http:\/\/t.co\/HSPHV5Wbf9",
  "id" : 463183657268572160,
  "created_at" : "2014-05-05 05:09:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/awcD3nu7cv",
      "expanded_url" : "http:\/\/youtu.be\/r3W69Gh7Ap8",
      "display_url" : "youtu.be\/r3W69Gh7Ap8"
    } ]
  },
  "geo" : { },
  "id_str" : "463048882591522816",
  "text" : "RT @MarkDice: MSNBC: You're Racist if You Don't Support Raising Minimum Wage    http:\/\/t.co\/awcD3nu7cv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/awcD3nu7cv",
        "expanded_url" : "http:\/\/youtu.be\/r3W69Gh7Ap8",
        "display_url" : "youtu.be\/r3W69Gh7Ap8"
      } ]
    },
    "geo" : { },
    "id_str" : "463028461473251328",
    "text" : "MSNBC: You're Racist if You Don't Support Raising Minimum Wage    http:\/\/t.co\/awcD3nu7cv",
    "id" : 463028461473251328,
    "created_at" : "2014-05-04 18:52:42 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 463048882591522816,
  "created_at" : "2014-05-04 20:13:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VMwJPzJB0j",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/Go-Be-Your-Own-Boss\/dp\/1489520430",
      "display_url" : "amazon.co.uk\/Go-Be-Your-Own\u2026"
    }, {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/yt9zqP3nLv",
      "expanded_url" : "http:\/\/fb.me\/2THkt4aKs",
      "display_url" : "fb.me\/2THkt4aKs"
    } ]
  },
  "geo" : { },
  "id_str" : "463046140951158784",
  "text" : "http:\/\/t.co\/VMwJPzJB0j http:\/\/t.co\/yt9zqP3nLv",
  "id" : 463046140951158784,
  "created_at" : "2014-05-04 20:02:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/463042063320104960\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/V7W7BRJkR7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm0OTaSCQAEhFMg.png",
      "id_str" : "463042063324299265",
      "id" : 463042063324299265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm0OTaSCQAEhFMg.png",
      "sizes" : [ {
        "h" : 416,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/V7W7BRJkR7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463042063320104960",
  "text" : "Thank you so very much http:\/\/t.co\/V7W7BRJkR7",
  "id" : 463042063320104960,
  "created_at" : "2014-05-04 19:46:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhema Marvanne",
      "screen_name" : "RhemaMarvanne",
      "indices" : [ 17, 31 ],
      "id_str" : "139508290",
      "id" : 139508290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462785386809266177",
  "text" : "Just listened to @RhemaMarvanne, amazing little gift from God",
  "id" : 462785386809266177,
  "created_at" : "2014-05-04 02:46:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Verified",
      "screen_name" : "verified",
      "indices" : [ 0, 9 ],
      "id_str" : "63796828",
      "id" : 63796828
    }, {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 33, 41 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462784997469220864",
  "in_reply_to_user_id" : 63796828,
  "text" : "@verified Wouldn't it be cool if @twitter verified me?",
  "id" : 462784997469220864,
  "created_at" : "2014-05-04 02:45:16 +0000",
  "in_reply_to_screen_name" : "verified",
  "in_reply_to_user_id_str" : "63796828",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ KING ASSASSIN",
      "screen_name" : "djkingassassin",
      "indices" : [ 3, 18 ],
      "id_str" : "744150240136044544",
      "id" : 744150240136044544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/psXw54RKL1",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.wAMKAMALSciencePortfolio",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462784195497299968",
  "text" : "RT @DjKingAssassin: Teenager app developer with a special talent releases android app \u200Bhttps:\/\/t.co\/psXw54RKL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/psXw54RKL1",
        "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.wAMKAMALSciencePortfolio",
        "display_url" : "play.google.com\/store\/apps\/det\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462783872900419584",
    "text" : "Teenager app developer with a special talent releases android app \u200Bhttps:\/\/t.co\/psXw54RKL1",
    "id" : 462783872900419584,
    "created_at" : "2014-05-04 02:40:48 +0000",
    "user" : {
      "name" : "MEGAMIX CHAMPION",
      "screen_name" : "MixMastaKing",
      "protected" : false,
      "id_str" : "18548136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880084065520570369\/T79CzMvq_normal.jpg",
      "id" : 18548136,
      "verified" : false
    }
  },
  "id" : 462784195497299968,
  "created_at" : "2014-05-04 02:42:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    }, {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 88, 100 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/QVsjr5KObf",
      "expanded_url" : "http:\/\/bit.ly\/1kmeIse",
      "display_url" : "bit.ly\/1kmeIse"
    } ]
  },
  "geo" : { },
  "id_str" : "462756568220459008",
  "text" : "RT @copticworld: Egypt 'Christians Expecting Death Any Time' http:\/\/t.co\/QVsjr5KObf via @CopticWorld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CopticWorld",
        "screen_name" : "copticworld",
        "indices" : [ 71, 83 ],
        "id_str" : "136923775",
        "id" : 136923775
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/QVsjr5KObf",
        "expanded_url" : "http:\/\/bit.ly\/1kmeIse",
        "display_url" : "bit.ly\/1kmeIse"
      } ]
    },
    "geo" : { },
    "id_str" : "461853013523451904",
    "text" : "Egypt 'Christians Expecting Death Any Time' http:\/\/t.co\/QVsjr5KObf via @CopticWorld",
    "id" : 461853013523451904,
    "created_at" : "2014-05-01 13:01:53 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 462756568220459008,
  "created_at" : "2014-05-04 00:52:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mickie Kennedy",
      "screen_name" : "ereleases",
      "indices" : [ 6, 16 ],
      "id_str" : "15763379",
      "id" : 15763379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462719211110809600",
  "geo" : { },
  "id_str" : "462756305283710976",
  "in_reply_to_user_id" : 210979938,
  "text" : "Maybe @ereleases can also help as well, who knows!!!",
  "id" : 462756305283710976,
  "in_reply_to_status_id" : 462719211110809600,
  "created_at" : "2014-05-04 00:51:15 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 82, 88 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ozHKxb5hJZ",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/05\/02\/stephen_hawking_freaks_out_about_skynet\/",
      "display_url" : "salon.com\/2014\/05\/02\/ste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462755828345208833",
  "text" : "For the first time hawking might actually have a point http:\/\/t.co\/ozHKxb5hJZ via @Salon",
  "id" : 462755828345208833,
  "created_at" : "2014-05-04 00:49:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Askij",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462720117898346496",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine Do you know how to code html, javascript, or a programming language similar to that. Maybe coding sites or even atmels? #Askij",
  "id" : 462720117898346496,
  "created_at" : "2014-05-03 22:27:27 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "MakerBot",
      "screen_name" : "makerbot",
      "indices" : [ 42, 51 ],
      "id_str" : "22021097",
      "id" : 22021097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/B1lH8dw33X",
      "expanded_url" : "http:\/\/instagram.com\/p\/nbIcH5AaGQ\/",
      "display_url" : "instagram.com\/p\/nbIcH5AaGQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "462719816743124992",
  "text" : "RT @ijustine: Had so much fun shooting at @makerbot today. Now I really want a 3D printer! http:\/\/t.co\/B1lH8dw33X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MakerBot",
        "screen_name" : "makerbot",
        "indices" : [ 28, 37 ],
        "id_str" : "22021097",
        "id" : 22021097
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/B1lH8dw33X",
        "expanded_url" : "http:\/\/instagram.com\/p\/nbIcH5AaGQ\/",
        "display_url" : "instagram.com\/p\/nbIcH5AaGQ\/"
      } ]
    },
    "geo" : { },
    "id_str" : "461571847327600640",
    "text" : "Had so much fun shooting at @makerbot today. Now I really want a 3D printer! http:\/\/t.co\/B1lH8dw33X",
    "id" : 461571847327600640,
    "created_at" : "2014-04-30 18:24:38 +0000",
    "user" : {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911802990469595137\/qm4zwu1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 462719816743124992,
  "created_at" : "2014-05-03 22:26:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0435\u0434\u043E\u0442\u044B\u043A\u0438\u043D \u0413\u0435\u043D\u043D\u0430\u0434\u0438\u0439",
      "screen_name" : "vocuschairman",
      "indices" : [ 0, 14 ],
      "id_str" : "2815023090",
      "id" : 2815023090
    }, {
      "name" : "PRWeb",
      "screen_name" : "prweb",
      "indices" : [ 15, 21 ],
      "id_str" : "14124541",
      "id" : 14124541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462719211110809600",
  "in_reply_to_user_id" : 173443038,
  "text" : "@vocuschairman @PRWEB How can you help people market their android apps?",
  "id" : 462719211110809600,
  "created_at" : "2014-05-03 22:23:51 +0000",
  "in_reply_to_screen_name" : "TracxCEO",
  "in_reply_to_user_id_str" : "173443038",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAM Online",
      "screen_name" : "EssentialAppMkt",
      "indices" : [ 3, 19 ],
      "id_str" : "355602046",
      "id" : 355602046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462718757946011648",
  "text" : "RT @EssentialAppMkt: Zingb Announces One.vu \u2013 One App for Facebook, Twitter, and LinkedIn That Makes Keeping Up With Social Life Simple htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/uGbdUQ1Ndp",
        "expanded_url" : "http:\/\/ow.ly\/q6Dml",
        "display_url" : "ow.ly\/q6Dml"
      } ]
    },
    "geo" : { },
    "id_str" : "393073053003186176",
    "text" : "Zingb Announces One.vu \u2013 One App for Facebook, Twitter, and LinkedIn That Makes Keeping Up With Social Life Simple http:\/\/t.co\/uGbdUQ1Ndp",
    "id" : 393073053003186176,
    "created_at" : "2013-10-23 17:54:53 +0000",
    "user" : {
      "name" : "EAM Online",
      "screen_name" : "EssentialAppMkt",
      "protected" : false,
      "id_str" : "355602046",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3174458756\/114639cc5f17dfa33ff773e2e5688f48_normal.jpeg",
      "id" : 355602046,
      "verified" : false
    }
  },
  "id" : 462718757946011648,
  "created_at" : "2014-05-03 22:22:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CyberXCrime",
      "screen_name" : "CyberXCrime",
      "indices" : [ 0, 12 ],
      "id_str" : "358071657",
      "id" : 358071657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462718428500197376",
  "in_reply_to_user_id" : 358071657,
  "text" : "@CyberXCrime Thanks for tweeting about my app, sometimes the tweet don't show, don't know why",
  "id" : 462718428500197376,
  "created_at" : "2014-05-03 22:20:44 +0000",
  "in_reply_to_screen_name" : "CyberXCrime",
  "in_reply_to_user_id_str" : "358071657",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/SYEhHZN3e7",
      "expanded_url" : "http:\/\/1drv.ms\/1nTYI7g",
      "display_url" : "1drv.ms\/1nTYI7g"
    } ]
  },
  "geo" : { },
  "id_str" : "462703285821243392",
  "text" : "The best part was the meat http:\/\/t.co\/SYEhHZN3e7",
  "id" : 462703285821243392,
  "created_at" : "2014-05-03 21:20:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Novus Starman",
      "screen_name" : "coastx",
      "indices" : [ 14, 21 ],
      "id_str" : "59273831",
      "id" : 59273831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462700289108508672",
  "text" : "RT @MarkDice: @coastx  Obama zombies at their best",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Novus Starman",
        "screen_name" : "coastx",
        "indices" : [ 0, 7 ],
        "id_str" : "59273831",
        "id" : 59273831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "462635263408082945",
    "geo" : { },
    "id_str" : "462659125847932929",
    "in_reply_to_user_id" : 59273831,
    "text" : "@coastx  Obama zombies at their best",
    "id" : 462659125847932929,
    "in_reply_to_status_id" : 462635263408082945,
    "created_at" : "2014-05-03 18:25:06 +0000",
    "in_reply_to_screen_name" : "coastx",
    "in_reply_to_user_id_str" : "59273831",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 462700289108508672,
  "created_at" : "2014-05-03 21:08:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462426581089394688",
  "text" : "Turned out to be rotten. Probably not gonna buy from that place again",
  "id" : 462426581089394688,
  "created_at" : "2014-05-03 03:01:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/CU6GgunQ5u",
      "expanded_url" : "http:\/\/1drv.ms\/1ncwulJ",
      "display_url" : "1drv.ms\/1ncwulJ"
    } ]
  },
  "geo" : { },
  "id_str" : "462426037033639937",
  "text" : "Goodness gracious http:\/\/t.co\/CU6GgunQ5u",
  "id" : 462426037033639937,
  "created_at" : "2014-05-03 02:58:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462314870034010112",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze You are such a cool inventor. You design lots of crazy stuff man, but try making some nice gadgets once and  a while",
  "id" : 462314870034010112,
  "created_at" : "2014-05-02 19:37:09 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462314596884168704",
  "text" : "RT @colin_furze: New paint job on the Hilux is needed to hold it together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461903945162821632",
    "text" : "New paint job on the Hilux is needed to hold it together.",
    "id" : 461903945162821632,
    "created_at" : "2014-05-01 16:24:16 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 462314596884168704,
  "created_at" : "2014-05-02 19:36:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 0, 13 ],
      "id_str" : "580255414",
      "id" : 580255414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ai8pynYXuX",
      "expanded_url" : "http:\/\/existor.com",
      "display_url" : "existor.com"
    } ]
  },
  "geo" : { },
  "id_str" : "462314190225809409",
  "in_reply_to_user_id" : 580255414,
  "text" : "@RockerCyborg I don't know how many people asked you this, but you got to check out this game called evie, http:\/\/t.co\/ai8pynYXuX",
  "id" : 462314190225809409,
  "created_at" : "2014-05-02 19:34:26 +0000",
  "in_reply_to_screen_name" : "RockerCyborg",
  "in_reply_to_user_id_str" : "580255414",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5vGBqfcx5U",
      "expanded_url" : "http:\/\/fb.me\/1kcCc1kUc",
      "display_url" : "fb.me\/1kcCc1kUc"
    } ]
  },
  "geo" : { },
  "id_str" : "462300205186969600",
  "text" : "Christians Will Be Banned From NBA For Opposing Gay Marriage, Hope Liberals http:\/\/t.co\/5vGBqfcx5U",
  "id" : 462300205186969600,
  "created_at" : "2014-05-02 18:38:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/yka8MGanH1",
      "expanded_url" : "http:\/\/vixra.org\/abs\/1405.0003",
      "display_url" : "vixra.org\/abs\/1405.0003"
    } ]
  },
  "geo" : { },
  "id_str" : "461965233062289408",
  "text" : "My 59th article: http:\/\/t.co\/yka8MGanH1, please download, remember, it is just a conceptual graph. Thank You",
  "id" : 461965233062289408,
  "created_at" : "2014-05-01 20:27:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]