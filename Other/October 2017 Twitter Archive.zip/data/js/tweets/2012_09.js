Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/wEP8v4V0",
      "expanded_url" : "http:\/\/youtu.be\/KxkYpIjSw2k?a",
      "display_url" : "youtu.be\/KxkYpIjSw2k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "251681715939049472",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/wEP8v4V0 Fellow Coptics",
  "id" : 251681715939049472,
  "created_at" : "2012-09-28 13:56:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/vBOEJPFA",
      "expanded_url" : "http:\/\/youtu.be\/jI2_ADfuCyc?a",
      "display_url" : "youtu.be\/jI2_ADfuCyc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "250762300712165376",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/vBOEJPFA muhammad_full_movie_-_innocence_of_muslims_74_min 3D",
  "id" : 250762300712165376,
  "created_at" : "2012-09-26 01:02:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/JFbHqEjJ",
      "expanded_url" : "http:\/\/tinyurl.com\/8bdg9by",
      "display_url" : "tinyurl.com\/8bdg9by"
    } ]
  },
  "geo" : { },
  "id_str" : "249593041483096065",
  "text" : "The Best diet pill to lose 30 pounds in 1 month! http:\/\/t.co\/JFbHqEjJ",
  "id" : 249593041483096065,
  "created_at" : "2012-09-22 19:36:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/f6hBKaRk",
      "expanded_url" : "http:\/\/youtu.be\/mlU4h6sDV-4?a",
      "display_url" : "youtu.be\/mlU4h6sDV-4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "248938867758084097",
  "text" : "I liked a @YouTube video http:\/\/t.co\/f6hBKaRk Egyption Reaction to Muhammad Movie Trailer (Sam Bacile Trailer",
  "id" : 248938867758084097,
  "created_at" : "2012-09-21 00:17:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/i3Emk4KN",
      "expanded_url" : "http:\/\/youtu.be\/Lgx1_JVxfZE?a",
      "display_url" : "youtu.be\/Lgx1_JVxfZE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "248588617361014784",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/i3Emk4KN Muhammad full movie - Innocence of Muslims 74 Min",
  "id" : 248588617361014784,
  "created_at" : "2012-09-20 01:05:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247461749794689024",
  "text" : "see mizzux7's gigs",
  "id" : 247461749794689024,
  "created_at" : "2012-09-16 22:27:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247461691288350720",
  "text" : "mizzux7 is a great fiverr user",
  "id" : 247461691288350720,
  "created_at" : "2012-09-16 22:27:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247461634380025856",
  "text" : "Go to fiverr. com\/mizzux7 today",
  "id" : 247461634380025856,
  "created_at" : "2012-09-16 22:27:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247461604873093120",
  "text" : "Go to fiverr. com\/mizzux7",
  "id" : 247461604873093120,
  "created_at" : "2012-09-16 22:26:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/F5gLIGWY",
      "expanded_url" : "http:\/\/youtu.be\/VgtVdPyLfYw?a",
      "display_url" : "youtu.be\/VgtVdPyLfYw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "247366329923948544",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/F5gLIGWY Expansions in Physics",
  "id" : 247366329923948544,
  "created_at" : "2012-09-16 16:08:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/cGtAv0fO",
      "expanded_url" : "http:\/\/youtu.be\/6_hwtDjC9lQ?a",
      "display_url" : "youtu.be\/6_hwtDjC9lQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246993807734886402",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/cGtAv0fO Bamboorules Interview",
  "id" : 246993807734886402,
  "created_at" : "2012-09-15 15:28:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/qlhJGevU",
      "expanded_url" : "http:\/\/youtu.be\/a_Ab1wVunj0?a",
      "display_url" : "youtu.be\/a_Ab1wVunj0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246993805872619520",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/qlhJGevU Sam Bacile's The Muhammad Movie (3D)",
  "id" : 246993805872619520,
  "created_at" : "2012-09-15 15:28:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/qlhJGevU",
      "expanded_url" : "http:\/\/youtu.be\/a_Ab1wVunj0?a",
      "display_url" : "youtu.be\/a_Ab1wVunj0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246993628457738241",
  "text" : "I favorited a @YouTube video http:\/\/t.co\/qlhJGevU Sam Bacile's The Muhammad Movie (3D)",
  "id" : 246993628457738241,
  "created_at" : "2012-09-15 15:27:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/USbolPnH",
      "expanded_url" : "http:\/\/youtu.be\/vmC8CnV4OFw?a",
      "display_url" : "youtu.be\/vmC8CnV4OFw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246991069265416194",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/USbolPnH Matrix Ping Pong",
  "id" : 246991069265416194,
  "created_at" : "2012-09-15 15:17:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/x6Dxitno",
      "expanded_url" : "http:\/\/youtu.be\/4NO8qpKXqx8?a",
      "display_url" : "youtu.be\/4NO8qpKXqx8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246989486515425280",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/x6Dxitno Annoying Orange - Tough Enough (ft. Toby Turner)",
  "id" : 246989486515425280,
  "created_at" : "2012-09-15 15:10:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/f6hBKaRk",
      "expanded_url" : "http:\/\/youtu.be\/mlU4h6sDV-4?a",
      "display_url" : "youtu.be\/mlU4h6sDV-4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246975563359739906",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/f6hBKaRk Innocence of Muslim Movie Reaction",
  "id" : 246975563359739906,
  "created_at" : "2012-09-15 14:15:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Jc2AazIm",
      "expanded_url" : "http:\/\/youtu.be\/qmodVun16Q4?a",
      "display_url" : "youtu.be\/qmodVun16Q4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246425130874576896",
  "text" : "I am Andrew Magdy Kamal and the following is a message from Messiah Yeshua: If  (@YouTube http:\/\/t.co\/Jc2AazIm)",
  "id" : 246425130874576896,
  "created_at" : "2012-09-14 01:48:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Jc2AazIm",
      "expanded_url" : "http:\/\/youtu.be\/qmodVun16Q4?a",
      "display_url" : "youtu.be\/qmodVun16Q4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "246417427276132352",
  "text" : "I am Andrew Magdy Kamal a copt who loved this video!!!\n (@YouTube http:\/\/t.co\/Jc2AazIm)",
  "id" : 246417427276132352,
  "created_at" : "2012-09-14 01:17:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246357712475136000",
  "text" : "fiverr .com\/shadowdragon",
  "id" : 246357712475136000,
  "created_at" : "2012-09-13 21:20:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246357659685634048",
  "text" : "Go see shadowdragon's profile on fiverr",
  "id" : 246357659685634048,
  "created_at" : "2012-09-13 21:20:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246023520759476224",
  "text" : "check out mysticwriter on fiverr",
  "id" : 246023520759476224,
  "created_at" : "2012-09-12 23:12:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246023434386165761",
  "text" : "Buy moonland for five bucks from galaxymaker from fiverr",
  "id" : 246023434386165761,
  "created_at" : "2012-09-12 23:12:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCG",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "Diet",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/r3PpeoBv",
      "expanded_url" : "http:\/\/www.HCGDietPortal.com\/buyhcg\/homeopathichcgdrops.html",
      "display_url" : "HCGDietPortal.com\/buyhcg\/homeopa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246023342388281346",
  "text" : "ose 45 lbs in just 6 Weeks \nhttp:\/\/t.co\/r3PpeoBv #HCG #Diet",
  "id" : 246023342388281346,
  "created_at" : "2012-09-12 23:11:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/dNmFVxmn",
      "expanded_url" : "http:\/\/www.hcgdietportal.com\/buyhcg\/homeopathichcgdrops.html",
      "display_url" : "hcgdietportal.com\/buyhcg\/homeopa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246023279763148800",
  "text" : "http:\/\/t.co\/dNmFVxmn",
  "id" : 246023279763148800,
  "created_at" : "2012-09-12 23:11:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246023233147650050",
  "text" : "http:\/\/fiverr .com\/ galaxymaker",
  "id" : 246023233147650050,
  "created_at" : "2012-09-12 23:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246023060937928704",
  "text" : "go to fiverr and search mystic writer he has really cool gigs that is fiverr .com\/ mysticwritter               do it",
  "id" : 246023060937928704,
  "created_at" : "2012-09-12 23:10:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246022756360151041",
  "text" : "go to fiverr and search mystic writer he has really cool gigs that is fiverr .com\/ mysticwritter",
  "id" : 246022756360151041,
  "created_at" : "2012-09-12 23:09:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/OLPlDKPe",
      "expanded_url" : "http:\/\/youtu.be\/lc6Ox8UkKP0?a",
      "display_url" : "youtu.be\/lc6Ox8UkKP0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "244553561831243776",
  "text" : "At the end of the man vs ball 6 video can you put Andrew Magdy Kamal biggest fa (@YouTube http:\/\/t.co\/OLPlDKPe)",
  "id" : 244553561831243776,
  "created_at" : "2012-09-08 21:51:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/tAxyCPJD",
      "expanded_url" : "http:\/\/nwaanarchy.net",
      "display_url" : "nwaanarchy.net"
    } ]
  },
  "geo" : { },
  "id_str" : "242714923434668032",
  "text" : "Join TV host Tim E. D on NWA Anarchy Pro Wrestling at http:\/\/t.co\/tAxyCPJD",
  "id" : 242714923434668032,
  "created_at" : "2012-09-03 20:05:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]