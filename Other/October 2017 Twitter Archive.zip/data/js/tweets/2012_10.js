Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ZkjJF5jH",
      "expanded_url" : "http:\/\/youtu.be\/4nh59fZr_Ys?a",
      "display_url" : "youtu.be\/4nh59fZr_Ys?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263788527848927232",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ZkjJF5jH HNI 0022",
  "id" : 263788527848927232,
  "created_at" : "2012-10-31 23:44:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/k7Ql2ukY",
      "expanded_url" : "http:\/\/youtu.be\/Y2l32rrgOmo?a",
      "display_url" : "youtu.be\/Y2l32rrgOmo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263788529056890880",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/k7Ql2ukY Coolness of Lasers 1",
  "id" : 263788529056890880,
  "created_at" : "2012-10-31 23:44:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/n9cfcb0c",
      "expanded_url" : "http:\/\/youtu.be\/e5Ue7wH3XzM?a",
      "display_url" : "youtu.be\/e5Ue7wH3XzM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263778419257516032",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/n9cfcb0c Teen Version of the Next Rocky",
  "id" : 263778419257516032,
  "created_at" : "2012-10-31 23:04:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/VHQYNbV9",
      "expanded_url" : "http:\/\/youtu.be\/n51XXRAUwiM?a",
      "display_url" : "youtu.be\/n51XXRAUwiM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263736724826505216",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/VHQYNbV9 Boxing Montage in Memory of Sage Stallone",
  "id" : 263736724826505216,
  "created_at" : "2012-10-31 20:18:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/BiW34KyL",
      "expanded_url" : "http:\/\/youtu.be\/nopmoWMvABw?a",
      "display_url" : "youtu.be\/nopmoWMvABw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263708520908722176",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/BiW34KyL HNI 0092",
  "id" : 263708520908722176,
  "created_at" : "2012-10-31 18:26:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/3tOjcAwu",
      "expanded_url" : "http:\/\/youtu.be\/s00Rj5a8rqk?a",
      "display_url" : "youtu.be\/s00Rj5a8rqk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263708522443862018",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/3tOjcAwu Stop Motion 1",
  "id" : 263708522443862018,
  "created_at" : "2012-10-31 18:26:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XGcHvzg4",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263374292216074241",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XGcHvzg4 Undeniable Proof that Obama is the AntiChrist",
  "id" : 263374292216074241,
  "created_at" : "2012-10-30 20:18:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/XGcHvzg4",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "263353257102028800",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/XGcHvzg4 Undeniable Proof that Obama is the AntiChrist",
  "id" : 263353257102028800,
  "created_at" : "2012-10-30 18:54:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/rVYEUO33",
      "expanded_url" : "http:\/\/youtu.be\/eWNz41BhKqA?a",
      "display_url" : "youtu.be\/eWNz41BhKqA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262758381201281024",
  "text" : "Why are you posting bad comments, what did I do, stop bullying me (@YouTube http:\/\/t.co\/rVYEUO33)",
  "id" : 262758381201281024,
  "created_at" : "2012-10-29 03:30:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/jJuK4qOW",
      "expanded_url" : "http:\/\/youtu.be\/gYl_X3qT8wI?a",
      "display_url" : "youtu.be\/gYl_X3qT8wI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262731499630116865",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/jJuK4qOW Me Singing Karyoke",
  "id" : 262731499630116865,
  "created_at" : "2012-10-29 01:44:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Qvk5QgcB",
      "expanded_url" : "http:\/\/youtu.be\/i5g39aj0Rpo?a",
      "display_url" : "youtu.be\/i5g39aj0Rpo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262731460883144704",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Qvk5QgcB Items for Sale",
  "id" : 262731460883144704,
  "created_at" : "2012-10-29 01:43:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/nBTS9VA2",
      "expanded_url" : "http:\/\/youtu.be\/DetYqpaoHak?a",
      "display_url" : "youtu.be\/DetYqpaoHak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262695895185883136",
  "text" : "I liked a @YouTube video http:\/\/t.co\/nBTS9VA2 Strange Dream About Barack Obama",
  "id" : 262695895185883136,
  "created_at" : "2012-10-28 23:22:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/IpsKpd79",
      "expanded_url" : "http:\/\/youtu.be\/rnMwrUQade8?a",
      "display_url" : "youtu.be\/rnMwrUQade8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262695748272021505",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/IpsKpd79 Miracle: A Face Sponataneously Appears next to the Image of God",
  "id" : 262695748272021505,
  "created_at" : "2012-10-28 23:22:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/IpsKpd79",
      "expanded_url" : "http:\/\/youtu.be\/rnMwrUQade8?a",
      "display_url" : "youtu.be\/rnMwrUQade8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262695313352040449",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/IpsKpd79 Miracle: A Face Sponataneously Appears next to the Image of God",
  "id" : 262695313352040449,
  "created_at" : "2012-10-28 23:20:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/z4cZmVwt",
      "expanded_url" : "http:\/\/youtu.be\/nT7hxOa64Zo?a",
      "display_url" : "youtu.be\/nT7hxOa64Zo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262636612972847107",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/z4cZmVwt Relaxing Music",
  "id" : 262636612972847107,
  "created_at" : "2012-10-28 19:27:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/9JiROfNX",
      "expanded_url" : "http:\/\/youtu.be\/upRMT270ED8?a",
      "display_url" : "youtu.be\/upRMT270ED8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262628250432438273",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/9JiROfNX Concerto of the Piano Ballad 01",
  "id" : 262628250432438273,
  "created_at" : "2012-10-28 18:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/nBTS9VA2",
      "expanded_url" : "http:\/\/youtu.be\/DetYqpaoHak?a",
      "display_url" : "youtu.be\/DetYqpaoHak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262593585873055744",
  "text" : "I favorited a @YouTube video http:\/\/t.co\/nBTS9VA2 Strange Dream About Barack Obama",
  "id" : 262593585873055744,
  "created_at" : "2012-10-28 16:36:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/rVYEUO33",
      "expanded_url" : "http:\/\/youtu.be\/eWNz41BhKqA?a",
      "display_url" : "youtu.be\/eWNz41BhKqA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262593317999632384",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/rVYEUO33 Me Singing Karyoke Part II",
  "id" : 262593317999632384,
  "created_at" : "2012-10-28 16:35:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/j7H0w5gA",
      "expanded_url" : "http:\/\/youtu.be\/D_FyWlq579Y?a",
      "display_url" : "youtu.be\/D_FyWlq579Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262589505561829376",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/j7H0w5gA Capture 20121028 4",
  "id" : 262589505561829376,
  "created_at" : "2012-10-28 16:19:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/XcixLaOM",
      "expanded_url" : "http:\/\/youtu.be\/HdnzT4sITyU?a",
      "display_url" : "youtu.be\/HdnzT4sITyU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262449814694936577",
  "text" : "I favorited a @YouTube video http:\/\/t.co\/XcixLaOM Rev. 13, Future Antichrist 666 Barack Obama &amp; UN. #8",
  "id" : 262449814694936577,
  "created_at" : "2012-10-28 07:04:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/FDTAhILS",
      "expanded_url" : "http:\/\/youtu.be\/KskYpOB_3xY?a",
      "display_url" : "youtu.be\/KskYpOB_3xY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262444029080375296",
  "text" : "I new that Obama was the Antichrist many years before he became president (@YouTube http:\/\/t.co\/FDTAhILS)",
  "id" : 262444029080375296,
  "created_at" : "2012-10-28 06:41:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/rGaGNsyb",
      "expanded_url" : "http:\/\/youtu.be\/x7LzOcrloKY?a",
      "display_url" : "youtu.be\/x7LzOcrloKY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262440079270748160",
  "text" : "OBAMA IS THE ANTICHRIST AND HIS REAL NAME IS BARACK HUSSEI NOBAMA (@YouTube http:\/\/t.co\/rGaGNsyb)",
  "id" : 262440079270748160,
  "created_at" : "2012-10-28 06:26:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/fCsO8zsv",
      "expanded_url" : "http:\/\/youtu.be\/U2VbX-DbLrY?a",
      "display_url" : "youtu.be\/U2VbX-DbLrY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262438206719545344",
  "text" : "I liked a @YouTube video http:\/\/t.co\/fCsO8zsv C.W. McCall - The Silverton",
  "id" : 262438206719545344,
  "created_at" : "2012-10-28 06:18:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/JKvlo6dG",
      "expanded_url" : "http:\/\/youtu.be\/qDID_E0FDUU?a",
      "display_url" : "youtu.be\/qDID_E0FDUU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262423616052940800",
  "text" : "I liked a @YouTube video http:\/\/t.co\/JKvlo6dG Elvis Presley - Jailhouse Rock (HD Music Video)",
  "id" : 262423616052940800,
  "created_at" : "2012-10-28 05:20:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/MikGekFa",
      "expanded_url" : "http:\/\/youtu.be\/SN6UmSoN_EE?a",
      "display_url" : "youtu.be\/SN6UmSoN_EE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262419724946796544",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/MikGekFa HeartBreak Hotel by Elvis Presley",
  "id" : 262419724946796544,
  "created_at" : "2012-10-28 05:05:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/cvPizfgp",
      "expanded_url" : "http:\/\/youtu.be\/1fKTocypr3o?a",
      "display_url" : "youtu.be\/1fKTocypr3o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262417968397418496",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/cvPizfgp HeartBreak Hotel AMKAMAL COVERUP",
  "id" : 262417968397418496,
  "created_at" : "2012-10-28 04:58:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/MikGekFa",
      "expanded_url" : "http:\/\/youtu.be\/SN6UmSoN_EE?a",
      "display_url" : "youtu.be\/SN6UmSoN_EE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262415038214709248",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/MikGekFa HeartBreak Hotel by Elvis Presley",
  "id" : 262415038214709248,
  "created_at" : "2012-10-28 04:46:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/A1gaYspM",
      "expanded_url" : "http:\/\/youtu.be\/42WZU2WvLPI?a",
      "display_url" : "youtu.be\/42WZU2WvLPI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262412634970808321",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/A1gaYspM Touchable Holograph",
  "id" : 262412634970808321,
  "created_at" : "2012-10-28 04:37:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/y1dSCQ2h",
      "expanded_url" : "http:\/\/youtu.be\/dwXL5JouPqY?a",
      "display_url" : "youtu.be\/dwXL5JouPqY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262407443005456384",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/y1dSCQ2h Seen on Fox News, FHB Galaxies",
  "id" : 262407443005456384,
  "created_at" : "2012-10-28 04:16:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/jJuK4qOW",
      "expanded_url" : "http:\/\/youtu.be\/gYl_X3qT8wI?a",
      "display_url" : "youtu.be\/gYl_X3qT8wI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262401957778558979",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/jJuK4qOW Me Singing Karyoke",
  "id" : 262401957778558979,
  "created_at" : "2012-10-28 03:54:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/32tefSJn",
      "expanded_url" : "http:\/\/youtu.be\/JeuiF8n7Ytw?a",
      "display_url" : "youtu.be\/JeuiF8n7Ytw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262388243083972610",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/32tefSJn Johnny B. Goode Marty McFly 1955",
  "id" : 262388243083972610,
  "created_at" : "2012-10-28 03:00:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6oeXa8mG",
      "expanded_url" : "http:\/\/youtu.be\/di-CH5Tq_Oc?a",
      "display_url" : "youtu.be\/di-CH5Tq_Oc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262388142559068160",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6oeXa8mG AcDc TNT Impersonation",
  "id" : 262388142559068160,
  "created_at" : "2012-10-28 02:59:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/BwGGMGVZ",
      "expanded_url" : "http:\/\/youtu.be\/6LMp98b_IvU?a",
      "display_url" : "youtu.be\/6LMp98b_IvU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262338266362150912",
  "text" : "I liked a @YouTube video http:\/\/t.co\/BwGGMGVZ \u041A\u0440\u0438\u0448\u0442\u0438\u0430\u043D\u0443 \u0420\u043E\u043D\u0430\u043B\u0434\u0443 \u0438 \u041C\u0430\u0440\u0441\u0435\u043B\u043E \u0442\u0430\u043D\u0446\u0443\u044E\u0442",
  "id" : 262338266362150912,
  "created_at" : "2012-10-27 23:41:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/eBUZOOUx",
      "expanded_url" : "http:\/\/youtu.be\/QoVovzj73wk?a",
      "display_url" : "youtu.be\/QoVovzj73wk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262337916745961473",
  "text" : "I liked a @YouTube video http:\/\/t.co\/eBUZOOUx Never let you girlfriend play your xbox Nek Minute",
  "id" : 262337916745961473,
  "created_at" : "2012-10-27 23:40:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/0hzjaROS",
      "expanded_url" : "http:\/\/youtu.be\/OhCwyZb16eY?a",
      "display_url" : "youtu.be\/OhCwyZb16eY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262335167882993664",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/0hzjaROS A Message to The Nation Of Islam",
  "id" : 262335167882993664,
  "created_at" : "2012-10-27 23:29:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/8jD5pOSm",
      "expanded_url" : "http:\/\/youtu.be\/L5bKISETkJo?a",
      "display_url" : "youtu.be\/L5bKISETkJo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "262306097006788608",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/8jD5pOSm Teen Celeb Zendaya Might Promote Scientific Research",
  "id" : 262306097006788608,
  "created_at" : "2012-10-27 21:33:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/TiQPk7Dk",
      "expanded_url" : "http:\/\/youtu.be\/Of2ExR3NfZY?a",
      "display_url" : "youtu.be\/Of2ExR3NfZY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261930370889576448",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/TiQPk7Dk All You Gave me Was Pain",
  "id" : 261930370889576448,
  "created_at" : "2012-10-26 20:40:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/L7yFpBjb",
      "expanded_url" : "http:\/\/youtu.be\/yrDwKJY_Tgg?a",
      "display_url" : "youtu.be\/yrDwKJY_Tgg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261921668799295488",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/L7yFpBjb Van Halen Starter",
  "id" : 261921668799295488,
  "created_at" : "2012-10-26 20:06:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/VJZ6cahO",
      "expanded_url" : "http:\/\/youtu.be\/2-D9yDvauO4?a",
      "display_url" : "youtu.be\/2-D9yDvauO4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261640754852687872",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/VJZ6cahO MR PART II",
  "id" : 261640754852687872,
  "created_at" : "2012-10-26 01:29:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/VJZ6cahO",
      "expanded_url" : "http:\/\/youtu.be\/2-D9yDvauO4?a",
      "display_url" : "youtu.be\/2-D9yDvauO4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261640563823087616",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/VJZ6cahO MR PART II",
  "id" : 261640563823087616,
  "created_at" : "2012-10-26 01:29:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/avcmdbLh",
      "expanded_url" : "http:\/\/youtu.be\/Hr_mwqkt2Jw?a",
      "display_url" : "youtu.be\/Hr_mwqkt2Jw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261551773754470400",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/avcmdbLh Part II",
  "id" : 261551773754470400,
  "created_at" : "2012-10-25 19:36:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/avcmdbLh",
      "expanded_url" : "http:\/\/youtu.be\/Hr_mwqkt2Jw?a",
      "display_url" : "youtu.be\/Hr_mwqkt2Jw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261551688090005504",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/avcmdbLh Part II",
  "id" : 261551688090005504,
  "created_at" : "2012-10-25 19:35:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/3Dtx6CrS",
      "expanded_url" : "http:\/\/youtu.be\/qzMQhEbeFzE?a",
      "display_url" : "youtu.be\/qzMQhEbeFzE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "261292544443428864",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/3Dtx6CrS What happens when Country and Medal Shredding are Mixed",
  "id" : 261292544443428864,
  "created_at" : "2012-10-25 02:26:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/32tefSJn",
      "expanded_url" : "http:\/\/youtu.be\/JeuiF8n7Ytw?a",
      "display_url" : "youtu.be\/JeuiF8n7Ytw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "256757732420513792",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/32tefSJn Johnny B. Goode Marty McFly 1955",
  "id" : 256757732420513792,
  "created_at" : "2012-10-12 14:06:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/DTTaqcBM",
      "expanded_url" : "http:\/\/youtu.be\/3kBFYwxdBio?a",
      "display_url" : "youtu.be\/3kBFYwxdBio?a"
    } ]
  },
  "geo" : { },
  "id_str" : "256409119890735104",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/DTTaqcBM Rick Santorum vs Hillary Clinton",
  "id" : 256409119890735104,
  "created_at" : "2012-10-11 15:01:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/h6U6Hgs6",
      "expanded_url" : "http:\/\/youtu.be\/XjnWJ3uMSNM?a",
      "display_url" : "youtu.be\/XjnWJ3uMSNM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "256159824394481665",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/h6U6Hgs6 My Talking Gremlin Video",
  "id" : 256159824394481665,
  "created_at" : "2012-10-10 22:30:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/pnsnWuT1",
      "expanded_url" : "http:\/\/youtu.be\/6GtO9wX1QzY?a",
      "display_url" : "youtu.be\/6GtO9wX1QzY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "255656931140698112",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/pnsnWuT1 Great Expectations Movie Review 3D",
  "id" : 255656931140698112,
  "created_at" : "2012-10-09 13:12:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/pnsnWuT1",
      "expanded_url" : "http:\/\/youtu.be\/6GtO9wX1QzY?a",
      "display_url" : "youtu.be\/6GtO9wX1QzY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "255656635186413568",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/pnsnWuT1 Great Expectations Movie Review 3D",
  "id" : 255656635186413568,
  "created_at" : "2012-10-09 13:11:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Qb1F9kQq",
      "expanded_url" : "http:\/\/youtu.be\/3GC6XWwjaVg?a",
      "display_url" : "youtu.be\/3GC6XWwjaVg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "255500396762656768",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Qb1F9kQq Great-Expectations-13-20th-December-1981).mp4",
  "id" : 255500396762656768,
  "created_at" : "2012-10-09 02:50:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/VS4DTAT0",
      "expanded_url" : "http:\/\/youtu.be\/2k7Xu1EQClk?a",
      "display_url" : "youtu.be\/2k7Xu1EQClk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "255495041584345088",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/VS4DTAT0 Great-Expectations-13-13-(20th-December-1981)",
  "id" : 255495041584345088,
  "created_at" : "2012-10-09 02:28:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/VS4DTAT0",
      "expanded_url" : "http:\/\/youtu.be\/2k7Xu1EQClk?a",
      "display_url" : "youtu.be\/2k7Xu1EQClk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "255495023645310976",
  "text" : "I favorited a @YouTube video from @gamer456148 http:\/\/t.co\/VS4DTAT0 Great-Expectations-13-13-(20th-December-1981)",
  "id" : 255495023645310976,
  "created_at" : "2012-10-09 02:28:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Gf47tyAO",
      "expanded_url" : "http:\/\/bit.ly\/POerzz",
      "display_url" : "bit.ly\/POerzz"
    } ]
  },
  "geo" : { },
  "id_str" : "255432986860863488",
  "text" : "Ever since I started this new diet I lost 30 pounds with no exercise and boosted my energy, I feel much better overall http:\/\/t.co\/Gf47tyAO",
  "id" : 255432986860863488,
  "created_at" : "2012-10-08 22:22:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/IspGBnYF",
      "expanded_url" : "http:\/\/bit.ly\/VLFAc0",
      "display_url" : "bit.ly\/VLFAc0"
    } ]
  },
  "geo" : { },
  "id_str" : "255034375253684226",
  "text" : "New diet product I'm trying has very good results, I've gotten thinner. More energy, I highly recommend this to anyone http:\/\/t.co\/IspGBnYF",
  "id" : 255034375253684226,
  "created_at" : "2012-10-07 19:58:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/Ooj2AGpA",
      "expanded_url" : "http:\/\/www.seoclerks.com\/freemoney",
      "display_url" : "seoclerks.com\/freemoney"
    } ]
  },
  "geo" : { },
  "id_str" : "254352516538580992",
  "text" : "http:\/\/t.co\/Ooj2AGpA",
  "id" : 254352516538580992,
  "created_at" : "2012-10-05 22:49:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/X5UhhuWB",
      "expanded_url" : "http:\/\/seoclerks.com",
      "display_url" : "seoclerks.com"
    } ]
  },
  "geo" : { },
  "id_str" : "254307767534362626",
  "text" : "Visit http:\/\/t.co\/X5UhhuWB, best site ever",
  "id" : 254307767534362626,
  "created_at" : "2012-10-05 19:51:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 3, 13 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/yjG1gWMV",
      "expanded_url" : "http:\/\/ow.ly\/e98Ek",
      "display_url" : "ow.ly\/e98Ek"
    } ]
  },
  "geo" : { },
  "id_str" : "254307576458670080",
  "text" : "RT @SEOClerks: Buy and Sell PHP Scripts, ASP, C#, Javascript, Java, CSS and more  http:\/\/t.co\/yjG1gWMV New Clerks Member. ^JV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/yjG1gWMV",
        "expanded_url" : "http:\/\/ow.ly\/e98Ek",
        "display_url" : "ow.ly\/e98Ek"
      } ]
    },
    "geo" : { },
    "id_str" : "253049673034629120",
    "text" : "Buy and Sell PHP Scripts, ASP, C#, Javascript, Java, CSS and more  http:\/\/t.co\/yjG1gWMV New Clerks Member. ^JV",
    "id" : 253049673034629120,
    "created_at" : "2012-10-02 08:31:58 +0000",
    "user" : {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "protected" : false,
      "id_str" : "386131152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798958307520217105\/F7-js85H_normal.jpg",
      "id" : 386131152,
      "verified" : false
    }
  },
  "id" : 254307576458670080,
  "created_at" : "2012-10-05 19:50:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 3, 13 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/3Q6roWvp",
      "expanded_url" : "http:\/\/ow.ly\/e98IC",
      "display_url" : "ow.ly\/e98IC"
    } ]
  },
  "geo" : { },
  "id_str" : "254307560239292416",
  "text" : "RT @SEOClerks: ThemeClerks - Premium WordPress Themes, Site Templates, XenForo Styles and More!  http:\/\/t.co\/3Q6roWvp ^JV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/3Q6roWvp",
        "expanded_url" : "http:\/\/ow.ly\/e98IC",
        "display_url" : "ow.ly\/e98IC"
      } ]
    },
    "geo" : { },
    "id_str" : "253050150291902464",
    "text" : "ThemeClerks - Premium WordPress Themes, Site Templates, XenForo Styles and More!  http:\/\/t.co\/3Q6roWvp ^JV",
    "id" : 253050150291902464,
    "created_at" : "2012-10-02 08:33:51 +0000",
    "user" : {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "protected" : false,
      "id_str" : "386131152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798958307520217105\/F7-js85H_normal.jpg",
      "id" : 386131152,
      "verified" : false
    }
  },
  "id" : 254307560239292416,
  "created_at" : "2012-10-05 19:50:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 3, 13 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/SteLQtbm",
      "expanded_url" : "http:\/\/ow.ly\/e98T1",
      "display_url" : "ow.ly\/e98T1"
    } ]
  },
  "geo" : { },
  "id_str" : "254307529755090944",
  "text" : "RT @SEOClerks: AudioClerks - Royalty-Free Music, Sounds Effects, Music Loops and More!  http:\/\/t.co\/SteLQtbm A new clerks network member ^JV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/SteLQtbm",
        "expanded_url" : "http:\/\/ow.ly\/e98T1",
        "display_url" : "ow.ly\/e98T1"
      } ]
    },
    "geo" : { },
    "id_str" : "253050525216563200",
    "text" : "AudioClerks - Royalty-Free Music, Sounds Effects, Music Loops and More!  http:\/\/t.co\/SteLQtbm A new clerks network member ^JV",
    "id" : 253050525216563200,
    "created_at" : "2012-10-02 08:35:21 +0000",
    "user" : {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "protected" : false,
      "id_str" : "386131152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798958307520217105\/F7-js85H_normal.jpg",
      "id" : 386131152,
      "verified" : false
    }
  },
  "id" : 254307529755090944,
  "created_at" : "2012-10-05 19:50:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]