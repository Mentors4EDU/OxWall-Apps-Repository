Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QAyjJXzQOd",
      "expanded_url" : "http:\/\/youtu.be\/HkkBta3ukbQ?a",
      "display_url" : "youtu.be\/HkkBta3ukbQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "538187276652511233",
  "text" : "RT @VigilantChrist: THE ILLUMINATI REVEALED! PewDiePie EXPOSED !!! http:\/\/t.co\/QAyjJXzQOd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/QAyjJXzQOd",
        "expanded_url" : "http:\/\/youtu.be\/HkkBta3ukbQ?a",
        "display_url" : "youtu.be\/HkkBta3ukbQ?a"
      } ]
    },
    "geo" : { },
    "id_str" : "537991411740590081",
    "text" : "THE ILLUMINATI REVEALED! PewDiePie EXPOSED !!! http:\/\/t.co\/QAyjJXzQOd",
    "id" : 537991411740590081,
    "created_at" : "2014-11-27 15:28:42 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 538187276652511233,
  "created_at" : "2014-11-28 04:27:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/DJ2MRA0vtg",
      "expanded_url" : "http:\/\/youtu.be\/srEfNQf1ISI?a",
      "display_url" : "youtu.be\/srEfNQf1ISI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "538187228703252480",
  "text" : "RT @VigilantChrist: Proving the Illuminati is Real!  Nigahiga DEBUNKED !!!  http:\/\/t.co\/DJ2MRA0vtg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/DJ2MRA0vtg",
        "expanded_url" : "http:\/\/youtu.be\/srEfNQf1ISI?a",
        "display_url" : "youtu.be\/srEfNQf1ISI?a"
      } ]
    },
    "geo" : { },
    "id_str" : "537971624029335554",
    "text" : "Proving the Illuminati is Real!  Nigahiga DEBUNKED !!!  http:\/\/t.co\/DJ2MRA0vtg",
    "id" : 537971624029335554,
    "created_at" : "2014-11-27 14:10:04 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 538187228703252480,
  "created_at" : "2014-11-28 04:26:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538187077020430336",
  "text" : "I had a nice family reunion this Thanksgiving",
  "id" : 538187077020430336,
  "created_at" : "2014-11-28 04:26:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537856724250554368",
  "text" : "A good story sometimes comes from a bad one",
  "id" : 537856724250554368,
  "created_at" : "2014-11-27 06:33:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hardline Stance",
      "screen_name" : "Hardline_Stance",
      "indices" : [ 3, 19 ],
      "id_str" : "22253744",
      "id" : 22253744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537856494876631040",
  "text" : "RT @Hardline_Stance: Natalie Dubose saved up whole life to open #Ferguson bakery; was in tears. People from her own neighborhood destroyed \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537842026784755712",
    "text" : "Natalie Dubose saved up whole life to open #Ferguson bakery; was in tears. People from her own neighborhood destroyed her life's work..-Rush",
    "id" : 537842026784755712,
    "created_at" : "2014-11-27 05:35:06 +0000",
    "user" : {
      "name" : "Hardline Stance",
      "screen_name" : "Hardline_Stance",
      "protected" : false,
      "id_str" : "22253744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816015607090941952\/lpEHI3NY_normal.jpg",
      "id" : 22253744,
      "verified" : false
    }
  },
  "id" : 537856494876631040,
  "created_at" : "2014-11-27 06:32:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yote Killer",
      "screen_name" : "BoneCollector29",
      "indices" : [ 3, 19 ],
      "id_str" : "381745887",
      "id" : 381745887
    }, {
      "name" : "jordan rose",
      "screen_name" : "maliagif",
      "indices" : [ 21, 30 ],
      "id_str" : "2294806837",
      "id" : 2294806837
    }, {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 31, 40 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Michelle Ye Hee Lee",
      "screen_name" : "myhlee",
      "indices" : [ 41, 48 ],
      "id_str" : "17066022",
      "id" : 17066022
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BoneCollector29\/status\/537755370404720640\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/9NNBOhPv4T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Z9qNJIgAAYsRo.jpg",
      "id_str" : "537755369553297408",
      "id" : 537755369553297408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Z9qNJIgAAYsRo.jpg",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/9NNBOhPv4T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537855557592285185",
  "text" : "RT @BoneCollector29: @maliagif @MarkDice @myhlee  Allow me ..... http:\/\/t.co\/9NNBOhPv4T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jordan rose",
        "screen_name" : "maliagif",
        "indices" : [ 0, 9 ],
        "id_str" : "2294806837",
        "id" : 2294806837
      }, {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 10, 19 ],
        "id_str" : "35039490",
        "id" : 35039490
      }, {
        "name" : "Michelle Ye Hee Lee",
        "screen_name" : "myhlee",
        "indices" : [ 20, 27 ],
        "id_str" : "17066022",
        "id" : 17066022
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoneCollector29\/status\/537755370404720640\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/9NNBOhPv4T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Z9qNJIgAAYsRo.jpg",
        "id_str" : "537755369553297408",
        "id" : 537755369553297408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Z9qNJIgAAYsRo.jpg",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/9NNBOhPv4T"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "537753435081555969",
    "geo" : { },
    "id_str" : "537755370404720640",
    "in_reply_to_user_id" : 2294806837,
    "text" : "@maliagif @MarkDice @myhlee  Allow me ..... http:\/\/t.co\/9NNBOhPv4T",
    "id" : 537755370404720640,
    "in_reply_to_status_id" : 537753435081555969,
    "created_at" : "2014-11-26 23:50:45 +0000",
    "in_reply_to_screen_name" : "maliagif",
    "in_reply_to_user_id_str" : "2294806837",
    "user" : {
      "name" : "Yote Killer",
      "screen_name" : "BoneCollector29",
      "protected" : false,
      "id_str" : "381745887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564462224\/image_normal.jpg",
      "id" : 381745887,
      "verified" : false
    }
  },
  "id" : 537855557592285185,
  "created_at" : "2014-11-27 06:28:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkDice\/status\/537846750242172928\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/dGSd4Tb5ZW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3bQxNpIEAAAYyf.png",
      "id_str" : "537846749411676160",
      "id" : 537846749411676160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3bQxNpIEAAAYyf.png",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 634
      } ],
      "display_url" : "pic.twitter.com\/dGSd4Tb5ZW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537855391338475520",
  "text" : "RT @MarkDice: http:\/\/t.co\/dGSd4Tb5ZW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkDice\/status\/537846750242172928\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/dGSd4Tb5ZW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3bQxNpIEAAAYyf.png",
        "id_str" : "537846749411676160",
        "id" : 537846749411676160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3bQxNpIEAAAYyf.png",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 634
        } ],
        "display_url" : "pic.twitter.com\/dGSd4Tb5ZW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537846750242172928",
    "text" : "http:\/\/t.co\/dGSd4Tb5ZW",
    "id" : 537846750242172928,
    "created_at" : "2014-11-27 05:53:52 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 537855391338475520,
  "created_at" : "2014-11-27 06:28:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537854654416035840",
  "text" : "I hope that coworker and all of you have a blessed Thanksgiving",
  "id" : 537854654416035840,
  "created_at" : "2014-11-27 06:25:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537854553454956544",
  "text" : "I just had homemade Romanian Cozonac bread with I believe cinnamon in it, made by my dad's nice coworker, who he trained, tasted great",
  "id" : 537854553454956544,
  "created_at" : "2014-11-27 06:24:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534886927892099072",
  "text" : "RT @colin_furze: Tuk Tuk with guns,flames,drifting donuts wheeliesThe ULTIMATE Tuk Tuk Unleashed the TUK600 (Far Cry 4): http:\/\/t.co\/VSpsgv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 131, 139 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/VSpsgvT88E",
        "expanded_url" : "http:\/\/youtu.be\/7y93MYaTx6M",
        "display_url" : "youtu.be\/7y93MYaTx6M"
      } ]
    },
    "geo" : { },
    "id_str" : "534778162727510016",
    "text" : "Tuk Tuk with guns,flames,drifting donuts wheeliesThe ULTIMATE Tuk Tuk Unleashed the TUK600 (Far Cry 4): http:\/\/t.co\/VSpsgvT88E via @YouTube",
    "id" : 534778162727510016,
    "created_at" : "2014-11-18 18:40:24 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 534886927892099072,
  "created_at" : "2014-11-19 01:52:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534886646198435841",
  "text" : "Had Chinese at the Oriental Express in Shelby, tasted nice 4.1\/5 stars",
  "id" : 534886646198435841,
  "created_at" : "2014-11-19 01:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/MdBxPJRSwr",
      "expanded_url" : "http:\/\/1drv.ms\/1uHKDMS",
      "display_url" : "1drv.ms\/1uHKDMS"
    } ]
  },
  "geo" : { },
  "id_str" : "534543109133045760",
  "text" : "You know exactly what this is http:\/\/t.co\/MdBxPJRSwr",
  "id" : 534543109133045760,
  "created_at" : "2014-11-18 03:06:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533684593107693568",
  "text" : "Wasn't able to go to Startup Weekend Detroit (Got Lost)",
  "id" : 533684593107693568,
  "created_at" : "2014-11-15 18:14:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup Lansing",
      "screen_name" : "StartupLansing",
      "indices" : [ 3, 18 ],
      "id_str" : "2271099156",
      "id" : 2271099156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yhqTROKRJn",
      "expanded_url" : "http:\/\/hubs.ly\/y0hMy90",
      "display_url" : "hubs.ly\/y0hMy90"
    } ]
  },
  "geo" : { },
  "id_str" : "532832997884428288",
  "text" : "RT @StartupLansing: This weekend is Detroit's Startup Weekend! Pitch an idea, launch a product, in a weekend! \n\nhttp:\/\/t.co\/yhqTROKRJn http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StartupLansing\/status\/532573402754981888\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/r4XXUksKQr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QUsBzIMAAGjl3.png",
        "id_str" : "532573402566242304",
        "id" : 532573402566242304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QUsBzIMAAGjl3.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/r4XXUksKQr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/yhqTROKRJn",
        "expanded_url" : "http:\/\/hubs.ly\/y0hMy90",
        "display_url" : "hubs.ly\/y0hMy90"
      } ]
    },
    "geo" : { },
    "id_str" : "532573402754981888",
    "text" : "This weekend is Detroit's Startup Weekend! Pitch an idea, launch a product, in a weekend! \n\nhttp:\/\/t.co\/yhqTROKRJn http:\/\/t.co\/r4XXUksKQr",
    "id" : 532573402754981888,
    "created_at" : "2014-11-12 16:39:28 +0000",
    "user" : {
      "name" : "Startup Lansing",
      "screen_name" : "StartupLansing",
      "protected" : false,
      "id_str" : "2271099156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434431424733528065\/aaPaOKEm_normal.png",
      "id" : 2271099156,
      "verified" : false
    }
  },
  "id" : 532832997884428288,
  "created_at" : "2014-11-13 09:51:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koding",
      "screen_name" : "koding",
      "indices" : [ 94, 101 ],
      "id_str" : "42704386",
      "id" : 42704386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackathon",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/sDX0V9fscX",
      "expanded_url" : "https:\/\/koding.com\/Hackathon#.VGR9sOZzBus.twitter",
      "display_url" : "koding.com\/Hackathon#.VGR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532831656663453696",
  "text" : "Hopefully I will be accepted!\nI've applied for the world's first global virtual #hackathon by @koding. Join my team! https:\/\/t.co\/sDX0V9fscX",
  "id" : 532831656663453696,
  "created_at" : "2014-11-13 09:45:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hackathon",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532830397466304512",
  "text" : "Gonna go to StartupWeekend Detroit this Friday #Hackathon",
  "id" : 532830397466304512,
  "created_at" : "2014-11-13 09:40:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 123, 131 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/wcn2PZvXWz",
      "expanded_url" : "http:\/\/youtu.be\/0d5ntPLnn78",
      "display_url" : "youtu.be\/0d5ntPLnn78"
    } ]
  },
  "geo" : { },
  "id_str" : "530541517828792321",
  "text" : "RT @colin_furze: This is going to be EPIC Squeezing a 600cc engine in to a Tuk Tuk (Far Cry 4): http:\/\/t.co\/wcn2PZvXWz via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 106, 114 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/wcn2PZvXWz",
        "expanded_url" : "http:\/\/youtu.be\/0d5ntPLnn78",
        "display_url" : "youtu.be\/0d5ntPLnn78"
      } ]
    },
    "geo" : { },
    "id_str" : "530427900789411840",
    "text" : "This is going to be EPIC Squeezing a 600cc engine in to a Tuk Tuk (Far Cry 4): http:\/\/t.co\/wcn2PZvXWz via @YouTube",
    "id" : 530427900789411840,
    "created_at" : "2014-11-06 18:34:01 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 530541517828792321,
  "created_at" : "2014-11-07 02:05:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530541266095079424",
  "text" : "First day of diet, and I had burger king, figures",
  "id" : 530541266095079424,
  "created_at" : "2014-11-07 02:04:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/529944065089888256\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/IcAe18pgW4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1q9UWQCAAAAjjp.jpg",
      "id_str" : "529944063437307904",
      "id" : 529944063437307904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1q9UWQCAAAAjjp.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/IcAe18pgW4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529944065089888256",
  "text" : "Republicans won the senate!!! http:\/\/t.co\/IcAe18pgW4",
  "id" : 529944065089888256,
  "created_at" : "2014-11-05 10:31:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zoltan Istvan",
      "screen_name" : "zoltan_istvan",
      "indices" : [ 0, 14 ],
      "id_str" : "1562177648",
      "id" : 1562177648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529733362316238848",
  "in_reply_to_user_id" : 1562177648,
  "text" : "@zoltan_istvan Mr.Istvan trans-humanism isn't the answer, the human body is unique on its own, you shouldn't try changing it.",
  "id" : 529733362316238848,
  "created_at" : "2014-11-04 20:34:10 +0000",
  "in_reply_to_screen_name" : "zoltan_istvan",
  "in_reply_to_user_id_str" : "1562177648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/BxsxQfQCFj",
      "expanded_url" : "http:\/\/www.truthrevolt.org\/commentary\/lena-dunham-threatens-sue-truth-revolt-quoting-her",
      "display_url" : "truthrevolt.org\/commentary\/len\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529732939299696640",
  "text" : "RT @MarkDice: Lena Dunham allegedly admitted molesting her younger sister in her new memoir http:\/\/t.co\/BxsxQfQCFj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/BxsxQfQCFj",
        "expanded_url" : "http:\/\/www.truthrevolt.org\/commentary\/lena-dunham-threatens-sue-truth-revolt-quoting-her",
        "display_url" : "truthrevolt.org\/commentary\/len\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529392605365149696",
    "text" : "Lena Dunham allegedly admitted molesting her younger sister in her new memoir http:\/\/t.co\/BxsxQfQCFj",
    "id" : 529392605365149696,
    "created_at" : "2014-11-03 22:00:07 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 529732939299696640,
  "created_at" : "2014-11-04 20:32:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/qFuvGDYtFs",
      "expanded_url" : "http:\/\/youtu.be\/pFR5igb28ZE?a",
      "display_url" : "youtu.be\/pFR5igb28ZE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "529732359453958145",
  "text" : "RT @VigilantChrist: WARNING !!! Pope Calls Jesus and the Bible a LIE !!! False Prophet EXPOSED !!! http:\/\/t.co\/qFuvGDYtFs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/qFuvGDYtFs",
        "expanded_url" : "http:\/\/youtu.be\/pFR5igb28ZE?a",
        "display_url" : "youtu.be\/pFR5igb28ZE?a"
      } ]
    },
    "geo" : { },
    "id_str" : "529472254401208320",
    "text" : "WARNING !!! Pope Calls Jesus and the Bible a LIE !!! False Prophet EXPOSED !!! http:\/\/t.co\/qFuvGDYtFs",
    "id" : 529472254401208320,
    "created_at" : "2014-11-04 03:16:37 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 529732359453958145,
  "created_at" : "2014-11-04 20:30:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/529731802341322752\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zhZ0y9x4Wp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1n8RBDCIAA0CmK.jpg",
      "id_str" : "529731800461877248",
      "id" : 529731800461877248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1n8RBDCIAA0CmK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 410
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 410
      } ],
      "display_url" : "pic.twitter.com\/zhZ0y9x4Wp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529731802341322752",
  "text" : "Went to Menchie's to have a frozen yogurt dessert. This in the same week I had burgers, and  Bucemi's, need to diet. http:\/\/t.co\/zhZ0y9x4Wp",
  "id" : 529731802341322752,
  "created_at" : "2014-11-04 20:27:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DarthReptile",
      "screen_name" : "MrRepzion",
      "indices" : [ 0, 10 ],
      "id_str" : "346062069",
      "id" : 346062069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528762182184349696",
  "in_reply_to_user_id" : 346062069,
  "text" : "@MrRepzion Theoretical physics can prove the existence of God, may I recommend you some resources.",
  "id" : 528762182184349696,
  "created_at" : "2014-11-02 04:15:02 +0000",
  "in_reply_to_screen_name" : "MrRepzion",
  "in_reply_to_user_id_str" : "346062069",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528757384500371456",
  "in_reply_to_user_id" : 2353321925,
  "text" : "@cobainkink A man and woman are different biologically, so they will be treated different, the thing you are looking for is equal respect",
  "id" : 528757384500371456,
  "created_at" : "2014-11-02 03:55:58 +0000",
  "in_reply_to_screen_name" : "siIveras",
  "in_reply_to_user_id_str" : "2353321925",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528756565130502145",
  "in_reply_to_user_id" : 2353321925,
  "text" : "@cobainkink A man does need to respect woman but feminism isn't the answer, the answer is an equal partnership and trust in God.",
  "id" : 528756565130502145,
  "created_at" : "2014-11-02 03:52:43 +0000",
  "in_reply_to_screen_name" : "siIveras",
  "in_reply_to_user_id_str" : "2353321925",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feminist",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528755730749218816",
  "text" : "The real war on woman is the #feminist movement",
  "id" : 528755730749218816,
  "created_at" : "2014-11-02 03:49:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528755617393958913",
  "text" : "Had a drink at Ice age lakeside mall, tasted nice, but my parents make better:P",
  "id" : 528755617393958913,
  "created_at" : "2014-11-02 03:48:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/z50biZijw8",
      "expanded_url" : "http:\/\/youtu.be\/5iA5mbNOats",
      "display_url" : "youtu.be\/5iA5mbNOats"
    } ]
  },
  "geo" : { },
  "id_str" : "528593925414477825",
  "text" : "RT @colin_furze: ICE BIKE The worlds first bike with wheels made of ICE ICE! For making wheels??? Good idea or not? http:\/\/t.co\/z50biZijw8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube\/id544007664?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube on iOS_\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/z50biZijw8",
        "expanded_url" : "http:\/\/youtu.be\/5iA5mbNOats",
        "display_url" : "youtu.be\/5iA5mbNOats"
      } ]
    },
    "geo" : { },
    "id_str" : "528077776428228609",
    "text" : "ICE BIKE The worlds first bike with wheels made of ICE ICE! For making wheels??? Good idea or not? http:\/\/t.co\/z50biZijw8",
    "id" : 528077776428228609,
    "created_at" : "2014-10-31 06:55:27 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 528593925414477825,
  "created_at" : "2014-11-01 17:06:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Apple Bagels",
      "screen_name" : "BigAppleBagels",
      "indices" : [ 0, 15 ],
      "id_str" : "48104702",
      "id" : 48104702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528593723882344448",
  "in_reply_to_user_id" : 48104702,
  "text" : "@BigAppleBagels Just had some of your bagels, they were good",
  "id" : 528593723882344448,
  "created_at" : "2014-11-01 17:05:39 +0000",
  "in_reply_to_screen_name" : "BigAppleBagels",
  "in_reply_to_user_id_str" : "48104702",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]