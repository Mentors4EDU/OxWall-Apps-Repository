Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/RvSH56Nrdd",
      "expanded_url" : "http:\/\/youtu.be\/T6igSbzywcw?a",
      "display_url" : "youtu.be\/T6igSbzywcw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "351484993555533825",
  "text" : "Please comment (@YouTube http:\/\/t.co\/RvSH56Nrdd)",
  "id" : 351484993555533825,
  "created_at" : "2013-06-30 23:38:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/RvSH56Nrdd",
      "expanded_url" : "http:\/\/youtu.be\/T6igSbzywcw?a",
      "display_url" : "youtu.be\/T6igSbzywcw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "351478497195212800",
  "text" : "Webcam video from June 30, 2013 7:09 PM: http:\/\/t.co\/RvSH56Nrdd via @YouTube",
  "id" : 351478497195212800,
  "created_at" : "2013-06-30 23:12:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351066441082089472",
  "text" : "Got 12,081m in ultimate car crasher game from addicting games, man dave is a fast stunt driver",
  "id" : 351066441082089472,
  "created_at" : "2013-06-29 19:55:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351030009982488579",
  "text" : "I have 5 friends :p",
  "id" : 351030009982488579,
  "created_at" : "2013-06-29 17:30:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351029373073231872",
  "text" : "Talked to Jenna B. for a minute, btw incidious is a horror film.",
  "id" : 351029373073231872,
  "created_at" : "2013-06-29 17:28:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350942671017218048",
  "text" : "Made it to level 10 in wheelchairs flash game, 48 seconds, wow",
  "id" : 350942671017218048,
  "created_at" : "2013-06-29 11:43:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350938658167197697",
  "text" : "Got to level 20, and a score of 34,000 on Codename Ballistic, this included bonus levels",
  "id" : 350938658167197697,
  "created_at" : "2013-06-29 11:27:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350903576459083776",
  "text" : "Talked to Jenna B. on Thursday she is so polite.....",
  "id" : 350903576459083776,
  "created_at" : "2013-06-29 09:08:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Fellowship",
      "screen_name" : "TheFellowship",
      "indices" : [ 92, 106 ],
      "id_str" : "18339390",
      "id" : 18339390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3vSmrVPJz2",
      "expanded_url" : "http:\/\/www.ifcj.org\/site\/PageNavigator\/BAI_FLG117SFIIranThreat\/BAI_FLG117IranThreatPetitionLandingV2.html#.Uc0UltbNGRg.twitter",
      "display_url" : "ifcj.org\/site\/PageNavig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350474758934118400",
  "text" : "Help Stop Iran's Nuclear Ambitions! Join us in voicing your support by signing the petition @TheFellowship - http:\/\/t.co\/3vSmrVPJz2",
  "id" : 350474758934118400,
  "created_at" : "2013-06-28 04:44:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "StMary&StShenouda",
      "screen_name" : "SMASSUK",
      "indices" : [ 30, 38 ],
      "id_str" : "1198621040",
      "id" : 1198621040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/tOGHzBCpeg",
      "expanded_url" : "http:\/\/youtu.be\/8eRV0G4Ar40?a",
      "display_url" : "youtu.be\/8eRV0G4Ar40?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350474161841373184",
  "text" : "I liked a @YouTube video from @smassuk http:\/\/t.co\/tOGHzBCpeg BEFALLING (A test of faith)- Award Winning Student Film",
  "id" : 350474161841373184,
  "created_at" : "2013-06-28 04:42:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/fgT090gT3u",
      "expanded_url" : "http:\/\/youtu.be\/p7fB06S8Bq8?a",
      "display_url" : "youtu.be\/p7fB06S8Bq8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350318332546793473",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/fgT090gT3u ISRAEL - Hava Nagila",
  "id" : 350318332546793473,
  "created_at" : "2013-06-27 18:22:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Nlk1cfgL3Q",
      "expanded_url" : "http:\/\/youtu.be\/f20KJgAT520?a",
      "display_url" : "youtu.be\/f20KJgAT520?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350309414860886016",
  "text" : "\"cool\" video (@YouTube http:\/\/t.co\/Nlk1cfgL3Q)",
  "id" : 350309414860886016,
  "created_at" : "2013-06-27 17:47:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 18, 26 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/Nlk1cfgL3Q",
      "expanded_url" : "http:\/\/youtu.be\/f20KJgAT520?a",
      "display_url" : "youtu.be\/f20KJgAT520?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350306773015597056",
  "text" : "Thank You friend (@YouTube http:\/\/t.co\/Nlk1cfgL3Q)",
  "id" : 350306773015597056,
  "created_at" : "2013-06-27 17:36:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/Nlk1cfgL3Q",
      "expanded_url" : "http:\/\/youtu.be\/f20KJgAT520?a",
      "display_url" : "youtu.be\/f20KJgAT520?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350306423126769665",
  "text" : "Okay???? (@YouTube http:\/\/t.co\/Nlk1cfgL3Q)",
  "id" : 350306423126769665,
  "created_at" : "2013-06-27 17:35:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Nlk1cfgL3Q",
      "expanded_url" : "http:\/\/youtu.be\/f20KJgAT520?a",
      "display_url" : "youtu.be\/f20KJgAT520?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350306387357745152",
  "text" : "Thanks, God Bless (@YouTube http:\/\/t.co\/Nlk1cfgL3Q)",
  "id" : 350306387357745152,
  "created_at" : "2013-06-27 17:35:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Nlk1cfgL3Q",
      "expanded_url" : "http:\/\/youtu.be\/f20KJgAT520?a",
      "display_url" : "youtu.be\/f20KJgAT520?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350306339223900160",
  "text" : "Thank You (@YouTube http:\/\/t.co\/Nlk1cfgL3Q)",
  "id" : 350306339223900160,
  "created_at" : "2013-06-27 17:35:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/B7Vj9P4T85",
      "expanded_url" : "http:\/\/youtu.be\/xi3YBX5My8g?a",
      "display_url" : "youtu.be\/xi3YBX5My8g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350304974800044032",
  "text" : "I liked a @YouTube video http:\/\/t.co\/B7Vj9P4T85 FataL_TreV TreV is your father episode 2",
  "id" : 350304974800044032,
  "created_at" : "2013-06-27 17:29:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/B7Vj9P4T85",
      "expanded_url" : "http:\/\/youtu.be\/xi3YBX5My8g?a",
      "display_url" : "youtu.be\/xi3YBX5My8g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350304977874452480",
  "text" : "Coll 3D gaming mods, thanks for the comment (@YouTube http:\/\/t.co\/B7Vj9P4T85)",
  "id" : 350304977874452480,
  "created_at" : "2013-06-27 17:29:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 12, 20 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/qzfJPpsCe4",
      "expanded_url" : "http:\/\/youtu.be\/aUdtH3pCiuk?a",
      "display_url" : "youtu.be\/aUdtH3pCiuk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350302880034598912",
  "text" : "Super cool (@YouTube http:\/\/t.co\/qzfJPpsCe4)",
  "id" : 350302880034598912,
  "created_at" : "2013-06-27 17:21:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/qzfJPpsCe4",
      "expanded_url" : "http:\/\/youtu.be\/aUdtH3pCiuk?a",
      "display_url" : "youtu.be\/aUdtH3pCiuk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350302822300004353",
  "text" : "I liked a @YouTube video from @pabloxcreed http:\/\/t.co\/qzfJPpsCe4 Trailer de entrada",
  "id" : 350302822300004353,
  "created_at" : "2013-06-27 17:21:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0oJXDyUWjU",
      "expanded_url" : "http:\/\/youtu.be\/Bo1bjTOFbZA?a",
      "display_url" : "youtu.be\/Bo1bjTOFbZA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350295577298345986",
  "text" : "Denying God is the one sin that can't be forgiven....Also God is a just God meaning he judges (@YouTube http:\/\/t.co\/0oJXDyUWjU)",
  "id" : 350295577298345986,
  "created_at" : "2013-06-27 16:52:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/obUF7BLOD5",
      "expanded_url" : "http:\/\/youtu.be\/0eSSll9jfos?a",
      "display_url" : "youtu.be\/0eSSll9jfos?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350219341553352705",
  "text" : "Just wonderful (@YouTube http:\/\/t.co\/obUF7BLOD5)",
  "id" : 350219341553352705,
  "created_at" : "2013-06-27 11:49:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/eGAgUMvEEJ",
      "expanded_url" : "http:\/\/youtu.be\/SElmovOs04o?a",
      "display_url" : "youtu.be\/SElmovOs04o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350219143305375744",
  "text" : "Coptic hymns are wonderful and fill me with joy (@YouTube http:\/\/t.co\/eGAgUMvEEJ)",
  "id" : 350219143305375744,
  "created_at" : "2013-06-27 11:48:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "StMary&StShenouda",
      "screen_name" : "SMASSUK",
      "indices" : [ 30, 38 ],
      "id_str" : "1198621040",
      "id" : 1198621040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/eGAgUMvEEJ",
      "expanded_url" : "http:\/\/youtu.be\/SElmovOs04o?a",
      "display_url" : "youtu.be\/SElmovOs04o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350219118512844800",
  "text" : "I liked a @YouTube video from @smassuk http:\/\/t.co\/eGAgUMvEEJ E Aghapi | Gregorian Liturgy (Easter 2013) (Coptic Hymns)",
  "id" : 350219118512844800,
  "created_at" : "2013-06-27 11:48:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/LwAnkQ4CmP",
      "expanded_url" : "http:\/\/youtu.be\/mv2T5xm423w?a",
      "display_url" : "youtu.be\/mv2T5xm423w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350218876472147969",
  "text" : "Upload more videos, why were you active 6 month ago, we miss you, your voice is wonderful, and (@YouTube http:\/\/t.co\/LwAnkQ4CmP)",
  "id" : 350218876472147969,
  "created_at" : "2013-06-27 11:47:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 16, 24 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/iUlUIerpxx",
      "expanded_url" : "http:\/\/youtu.be\/tqrWbPkUiag?a",
      "display_url" : "youtu.be\/tqrWbPkUiag?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350218247947296768",
  "text" : "Beautiful song (@YouTube http:\/\/t.co\/iUlUIerpxx)",
  "id" : 350218247947296768,
  "created_at" : "2013-06-27 11:45:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/66MrRNWCIc",
      "expanded_url" : "http:\/\/youtu.be\/q5NQt_Ly-UE?a",
      "display_url" : "youtu.be\/q5NQt_Ly-UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350217357383303168",
  "text" : "People should never study witchcraft, it brings bad images and dreams into one's mind, if you (@YouTube http:\/\/t.co\/66MrRNWCIc)",
  "id" : 350217357383303168,
  "created_at" : "2013-06-27 11:41:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/66MrRNWCIc",
      "expanded_url" : "http:\/\/youtu.be\/q5NQt_Ly-UE?a",
      "display_url" : "youtu.be\/q5NQt_Ly-UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350216862774202369",
  "text" : "The video wasn't a blessing to you but the word of God was a blessing to you... (@YouTube http:\/\/t.co\/66MrRNWCIc)",
  "id" : 350216862774202369,
  "created_at" : "2013-06-27 11:39:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 88, 96 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/66MrRNWCIc",
      "expanded_url" : "http:\/\/youtu.be\/q5NQt_Ly-UE?a",
      "display_url" : "youtu.be\/q5NQt_Ly-UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350216669077057536",
  "text" : "Just follow him, spread his word. He is your master, your rabbi, and even your father. (@YouTube http:\/\/t.co\/66MrRNWCIc)",
  "id" : 350216669077057536,
  "created_at" : "2013-06-27 11:38:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/66MrRNWCIc",
      "expanded_url" : "http:\/\/youtu.be\/q5NQt_Ly-UE?a",
      "display_url" : "youtu.be\/q5NQt_Ly-UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350216432597991426",
  "text" : "He is not a man of God, he is a follower of God, and a child of God, their is a difference (@YouTube http:\/\/t.co\/66MrRNWCIc)",
  "id" : 350216432597991426,
  "created_at" : "2013-06-27 11:37:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/66MrRNWCIc",
      "expanded_url" : "http:\/\/youtu.be\/q5NQt_Ly-UE?a",
      "display_url" : "youtu.be\/q5NQt_Ly-UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350216270769160192",
  "text" : "I am affiliated with the Jews for Jesus Program and the Coptic Orthodox Messianicans Program, (@YouTube http:\/\/t.co\/66MrRNWCIc)",
  "id" : 350216270769160192,
  "created_at" : "2013-06-27 11:37:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/1CrvVQFHS5",
      "expanded_url" : "http:\/\/youtu.be\/2FX7xbUwjnE?a",
      "display_url" : "youtu.be\/2FX7xbUwjnE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350215141742227456",
  "text" : "Keep ISRAEL UNITED (@YouTube http:\/\/t.co\/1CrvVQFHS5)",
  "id" : 350215141742227456,
  "created_at" : "2013-06-27 11:32:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/J48zAPQK0B",
      "expanded_url" : "http:\/\/youtu.be\/uSph9HW8kq0?a",
      "display_url" : "youtu.be\/uSph9HW8kq0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350214918210990080",
  "text" : "I was hoping that this would actually be in hebrew (@YouTube http:\/\/t.co\/J48zAPQK0B)",
  "id" : 350214918210990080,
  "created_at" : "2013-06-27 11:31:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Y4T9MnJhyu",
      "expanded_url" : "http:\/\/youtu.be\/jdZP0UPoFVo?a",
      "display_url" : "youtu.be\/jdZP0UPoFVo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350213997955514368",
  "text" : "God Bless You All (@YouTube http:\/\/t.co\/Y4T9MnJhyu)",
  "id" : 350213997955514368,
  "created_at" : "2013-06-27 11:28:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/JBDoiDVBBl",
      "expanded_url" : "http:\/\/youtu.be\/fpzgkr9mbq0?a",
      "display_url" : "youtu.be\/fpzgkr9mbq0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350213841260523520",
  "text" : "Mishnah Yeshu (Messiah Yeshua) is our father. WE ARE HIS BLESSED CHILDREN. God bless the (@YouTube http:\/\/t.co\/JBDoiDVBBl)",
  "id" : 350213841260523520,
  "created_at" : "2013-06-27 11:27:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/EHHBGOZ2KU",
      "expanded_url" : "http:\/\/youtu.be\/jJOI0i1aXVY?a",
      "display_url" : "youtu.be\/jJOI0i1aXVY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350213147350671360",
  "text" : "SODOM &amp; GOMORRAH were the first satanist and pegans, but they were also the first gays and God (@YouTube http:\/\/t.co\/EHHBGOZ2KU)",
  "id" : 350213147350671360,
  "created_at" : "2013-06-27 11:24:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Ea8M7rdmea",
      "expanded_url" : "http:\/\/youtu.be\/KkB2WZ2O4Js?a",
      "display_url" : "youtu.be\/KkB2WZ2O4Js?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350212251954839552",
  "text" : "I think the two witnesses are Elijah and the Last Prophet in the Book of Issiah. I also belief (@YouTube http:\/\/t.co\/Ea8M7rdmea)",
  "id" : 350212251954839552,
  "created_at" : "2013-06-27 11:21:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 15, 23 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/UxWUkEPXdK",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "350210824528338945",
  "text" : "I believe you (@YouTube http:\/\/t.co\/UxWUkEPXdK)",
  "id" : 350210824528338945,
  "created_at" : "2013-06-27 11:15:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 12, 20 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/0dLZvG0CDL",
      "expanded_url" : "http:\/\/youtu.be\/cx6Ptw2gnEI?a",
      "display_url" : "youtu.be\/cx6Ptw2gnEI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349929867372019712",
  "text" : "Ted Nugent (@YouTube http:\/\/t.co\/0dLZvG0CDL)",
  "id" : 349929867372019712,
  "created_at" : "2013-06-26 16:39:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349387289455116288\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/BZqmLdrN15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNlF431CQAA7Xe8.png",
      "id_str" : "349387289459310592",
      "id" : 349387289459310592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNlF431CQAA7Xe8.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BZqmLdrN15"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349387289455116288",
  "text" : "Haha vikings http:\/\/t.co\/BZqmLdrN15",
  "id" : 349387289455116288,
  "created_at" : "2013-06-25 04:43:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349382656150097920\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/chVT3E9bcK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNlBrLbCUAA1KEC.png",
      "id_str" : "349382656154292224",
      "id" : 349382656154292224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNlBrLbCUAA1KEC.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/chVT3E9bcK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349382656150097920",
  "text" : "All Right http:\/\/t.co\/chVT3E9bcK",
  "id" : 349382656150097920,
  "created_at" : "2013-06-25 04:24:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349381900219080704\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/8gty5iBXyb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNlA_LYCYAEari8.png",
      "id_str" : "349381900227469313",
      "id" : 349381900227469313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNlA_LYCYAEari8.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8gty5iBXyb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349381900219080704",
  "text" : "Burn!!!!!!! http:\/\/t.co\/8gty5iBXyb",
  "id" : 349381900219080704,
  "created_at" : "2013-06-25 04:21:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349380779157114880\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/uOauQciSwK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNk_97GCUAA1ZIX.png",
      "id_str" : "349380779165503488",
      "id" : 349380779165503488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNk_97GCUAA1ZIX.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      } ],
      "display_url" : "pic.twitter.com\/uOauQciSwK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349380779157114880",
  "text" : "Most be my personal record http:\/\/t.co\/uOauQciSwK",
  "id" : 349380779157114880,
  "created_at" : "2013-06-25 04:17:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349355677531115521\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/xjdLrKcRGy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNkpI0PCEAIvFe2.png",
      "id_str" : "349355677535309826",
      "id" : 349355677535309826,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNkpI0PCEAIvFe2.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xjdLrKcRGy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349355677531115521",
  "text" : "Oh Yeah http:\/\/t.co\/xjdLrKcRGy",
  "id" : 349355677531115521,
  "created_at" : "2013-06-25 02:37:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349354585162399744\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/fOO4xwPwpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNkoJO2CQAEOtnP.png",
      "id_str" : "349354585166594049",
      "id" : 349354585166594049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNkoJO2CQAEOtnP.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      } ],
      "display_url" : "pic.twitter.com\/fOO4xwPwpA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349354585162399744",
  "text" : "Survived http:\/\/t.co\/fOO4xwPwpA",
  "id" : 349354585162399744,
  "created_at" : "2013-06-25 02:33:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/L0HDonTn6v",
      "expanded_url" : "http:\/\/youtu.be\/9DfVM5OIZ4I?a",
      "display_url" : "youtu.be\/9DfVM5OIZ4I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349354183687802882",
  "text" : "I liked a @YouTube video http:\/\/t.co\/L0HDonTn6v Rage MiniTeamtage - Black Ops II",
  "id" : 349354183687802882,
  "created_at" : "2013-06-25 02:31:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/eHWWGSM8Yv",
      "expanded_url" : "http:\/\/youtu.be\/78_RXwqWj9w?a",
      "display_url" : "youtu.be\/78_RXwqWj9w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349331735420485634",
  "text" : "Very nice (@YouTube http:\/\/t.co\/eHWWGSM8Yv)",
  "id" : 349331735420485634,
  "created_at" : "2013-06-25 01:02:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349317640860348417",
  "text" : "God Bless (@YouTube http:\/\/t.co\/vI8kfZYaU9)",
  "id" : 349317640860348417,
  "created_at" : "2013-06-25 00:06:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349317566335959040",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/vI8kfZYaU9 Does God Exist?",
  "id" : 349317566335959040,
  "created_at" : "2013-06-25 00:06:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 40, 48 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ijXfXAHwoi",
      "expanded_url" : "http:\/\/youtu.be\/T2XcA6NBKrg?a",
      "display_url" : "youtu.be\/T2XcA6NBKrg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "349281853410263040",
  "text" : "OK??? Anyways I subbed to your channel (@YouTube http:\/\/t.co\/ijXfXAHwoi)",
  "id" : 349281853410263040,
  "created_at" : "2013-06-24 21:44:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349246498212548609\/photo\/1",
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/4NzJRFAuJ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNjF1vmCEAExzhA.png",
      "id_str" : "349246498220937217",
      "id" : 349246498220937217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNjF1vmCEAExzhA.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      } ],
      "display_url" : "pic.twitter.com\/4NzJRFAuJ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349246498212548609",
  "text" : "OUCH http:\/\/t.co\/4NzJRFAuJ8",
  "id" : 349246498212548609,
  "created_at" : "2013-06-24 19:23:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349244632846188545\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/8XkUwpebZ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNjEJKjCQAAhTmV.png",
      "id_str" : "349244632850382848",
      "id" : 349244632850382848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNjEJKjCQAAhTmV.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8XkUwpebZ4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349244632846188545",
  "text" : "YES!!!! http:\/\/t.co\/8XkUwpebZ4",
  "id" : 349244632846188545,
  "created_at" : "2013-06-24 19:16:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/349239500385435648\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/7n2pDakn1q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNi_eapCQAAMD0V.png",
      "id_str" : "349239500389629952",
      "id" : 349239500389629952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNi_eapCQAAMD0V.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      } ],
      "display_url" : "pic.twitter.com\/7n2pDakn1q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349239500385435648",
  "text" : "That's right http:\/\/t.co\/7n2pDakn1q",
  "id" : 349239500385435648,
  "created_at" : "2013-06-24 18:56:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348988649200824322",
  "text" : "New world record for Renaissance Happy Wheels Level",
  "id" : 348988649200824322,
  "created_at" : "2013-06-24 02:19:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348988492199624704",
  "text" : "Took 31 sec to beat the office level in happy wheels",
  "id" : 348988492199624704,
  "created_at" : "2013-06-24 02:18:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/348987481653403648\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/bRLuPsJ1AJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNfaQ_tCYAEU7YL.png",
      "id_str" : "348987481657597953",
      "id" : 348987481657597953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNfaQ_tCYAEU7YL.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bRLuPsJ1AJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348987481653403648",
  "text" : "Temple run or temple cripple? http:\/\/t.co\/bRLuPsJ1AJ",
  "id" : 348987481653403648,
  "created_at" : "2013-06-24 02:14:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/348986779325583360\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/4Iu8JtyW1M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNfZoHVCUAA2rJD.png",
      "id_str" : "348986779329777664",
      "id" : 348986779329777664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNfZoHVCUAA2rJD.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4Iu8JtyW1M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348986779325583360",
  "text" : "Victory is painful http:\/\/t.co\/4Iu8JtyW1M",
  "id" : 348986779325583360,
  "created_at" : "2013-06-24 02:11:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/348981868160483328\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/5zXRpbPabF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNfVKP1CAAAewww.png",
      "id_str" : "348981868168871936",
      "id" : 348981868168871936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNfVKP1CAAAewww.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/5zXRpbPabF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348981868160483328",
  "text" : "The Big Payback http:\/\/t.co\/5zXRpbPabF",
  "id" : 348981868160483328,
  "created_at" : "2013-06-24 01:52:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/348980791608475649\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/T5NDc0x1L3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNfULlWCAAIH6XC.png",
      "id_str" : "348980791612669954",
      "id" : 348980791612669954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNfULlWCAAIH6XC.png",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/T5NDc0x1L3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348980791608475649",
  "text" : "Finally http:\/\/t.co\/T5NDc0x1L3",
  "id" : 348980791608475649,
  "created_at" : "2013-06-24 01:47:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/348979722719490051\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/rkpgFM0srO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNfTNXbCcAAPYNC.png",
      "id_str" : "348979722723684352",
      "id" : 348979722723684352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNfTNXbCcAAPYNC.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1376
      } ],
      "display_url" : "pic.twitter.com\/rkpgFM0srO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348979722719490051",
  "text" : "Oh Right http:\/\/t.co\/rkpgFM0srO",
  "id" : 348979722719490051,
  "created_at" : "2013-06-24 01:43:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348932488074240001",
  "text" : "Just talked to Jenna B. Most conservative girl I know",
  "id" : 348932488074240001,
  "created_at" : "2013-06-23 22:36:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/UxWUkEPXdK",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "346732246096543744",
  "text" : "What? (@YouTube http:\/\/t.co\/UxWUkEPXdK)",
  "id" : 346732246096543744,
  "created_at" : "2013-06-17 20:53:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/x94vpD7NZm",
      "expanded_url" : "http:\/\/youtu.be\/3JWi78hk8oQ?a",
      "display_url" : "youtu.be\/3JWi78hk8oQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "346619136304099329",
  "text" : "I liked a @YouTube video http:\/\/t.co\/x94vpD7NZm extreme snowkite by Christophe Grange",
  "id" : 346619136304099329,
  "created_at" : "2013-06-17 13:23:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "346007229280952324",
  "text" : "I am sorry for my breathing problems and that I am ill, I can't control it. Also the sound (@YouTube http:\/\/t.co\/vI8kfZYaU9)",
  "id" : 346007229280952324,
  "created_at" : "2013-06-15 20:52:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345788739127234560",
  "text" : "Thanks, GOD bless (@YouTube http:\/\/t.co\/vI8kfZYaU9)",
  "id" : 345788739127234560,
  "created_at" : "2013-06-15 06:23:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345788702091513856",
  "text" : "Did you watch the video I was using both circular logic, theoretical physics, and the Bible to (@YouTube http:\/\/t.co\/vI8kfZYaU9)",
  "id" : 345788702091513856,
  "created_at" : "2013-06-15 06:23:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 66, 74 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/LzYZCTC6L9",
      "expanded_url" : "http:\/\/youtu.be\/dkHCwa4D5Wo?a",
      "display_url" : "youtu.be\/dkHCwa4D5Wo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345786604650106880",
  "text" : "Epouro (O King of Peace Coptic Hymns): http:\/\/t.co\/LzYZCTC6L9 via @YouTube",
  "id" : 345786604650106880,
  "created_at" : "2013-06-15 06:15:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/vI8kfZYaU9",
      "expanded_url" : "http:\/\/youtu.be\/CipLEPQlpCQ?a",
      "display_url" : "youtu.be\/CipLEPQlpCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345765534777896960",
  "text" : "Does God Exist?: http:\/\/t.co\/vI8kfZYaU9 via @YouTube",
  "id" : 345765534777896960,
  "created_at" : "2013-06-15 04:51:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EJBv74B5MK",
      "expanded_url" : "http:\/\/youtu.be\/_cmOmHINsS4?a",
      "display_url" : "youtu.be\/_cmOmHINsS4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345761207183093760",
  "text" : "A Message from the Host: http:\/\/t.co\/EJBv74B5MK via @YouTube",
  "id" : 345761207183093760,
  "created_at" : "2013-06-15 04:34:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/zAMfRZ9hSG",
      "expanded_url" : "http:\/\/youtu.be\/ZBKMyC69At0?a",
      "display_url" : "youtu.be\/ZBKMyC69At0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345743458578870273",
  "text" : "A large pen? (@YouTube http:\/\/t.co\/zAMfRZ9hSG)",
  "id" : 345743458578870273,
  "created_at" : "2013-06-15 03:23:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/f7tQwpwrAJ",
      "expanded_url" : "http:\/\/youtu.be\/zD5lMSFqpfQ?a",
      "display_url" : "youtu.be\/zD5lMSFqpfQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345740179065163776",
  "text" : "I liked a @YouTube video from @nighthawkil http:\/\/t.co\/f7tQwpwrAJ Raising Pheasant (Day 1)",
  "id" : 345740179065163776,
  "created_at" : "2013-06-15 03:10:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/b4NcAe4ajV",
      "expanded_url" : "http:\/\/youtu.be\/dkI8YUjVK4c?a",
      "display_url" : "youtu.be\/dkI8YUjVK4c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345707548835454976",
  "text" : "Miracle Appearance on Image, Viewed through Different Camera Phases: http:\/\/t.co\/b4NcAe4ajV via @YouTube",
  "id" : 345707548835454976,
  "created_at" : "2013-06-15 01:01:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/b4NcAe4ajV",
      "expanded_url" : "http:\/\/youtu.be\/dkI8YUjVK4c?a",
      "display_url" : "youtu.be\/dkI8YUjVK4c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345706881840451584",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/b4NcAe4ajV Miracle Appearance on Image, Viewed through Different Camera Phases",
  "id" : 345706881840451584,
  "created_at" : "2013-06-15 00:58:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345606195308003332",
  "text" : "Had a quick conversation with Jen.",
  "id" : 345606195308003332,
  "created_at" : "2013-06-14 18:18:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/iuVCSpLBFh",
      "expanded_url" : "http:\/\/youtu.be\/BVfbbvK-uGs?a",
      "display_url" : "youtu.be\/BVfbbvK-uGs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345071237510361090",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/iuVCSpLBFh What the Bible Says about Suicide",
  "id" : 345071237510361090,
  "created_at" : "2013-06-13 06:52:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 50, 58 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Q483IEi8ZW",
      "expanded_url" : "http:\/\/youtu.be\/2b0QBJo3PV4?a",
      "display_url" : "youtu.be\/2b0QBJo3PV4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345070856814333953",
  "text" : "God Bless you, brother in Christ, I pray for you (@YouTube http:\/\/t.co\/Q483IEi8ZW)",
  "id" : 345070856814333953,
  "created_at" : "2013-06-13 06:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Q483IEi8ZW",
      "expanded_url" : "http:\/\/youtu.be\/2b0QBJo3PV4?a",
      "display_url" : "youtu.be\/2b0QBJo3PV4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345070621648121856",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/Q483IEi8ZW What the Bible Says About Teen Dating",
  "id" : 345070621648121856,
  "created_at" : "2013-06-13 06:50:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/iuVCSpLBFh",
      "expanded_url" : "http:\/\/youtu.be\/BVfbbvK-uGs?a",
      "display_url" : "youtu.be\/BVfbbvK-uGs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345068911655538688",
  "text" : "Webcam video from June 13, 2013 2:40 AM: http:\/\/t.co\/iuVCSpLBFh via @YouTube",
  "id" : 345068911655538688,
  "created_at" : "2013-06-13 06:43:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Q483IEi8ZW",
      "expanded_url" : "http:\/\/youtu.be\/2b0QBJo3PV4?a",
      "display_url" : "youtu.be\/2b0QBJo3PV4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345064504259928065",
  "text" : "Webcam video from June 13, 2013 2:19 AM: http:\/\/t.co\/Q483IEi8ZW via @YouTube",
  "id" : 345064504259928065,
  "created_at" : "2013-06-13 06:26:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/wM1Ybfh0mA",
      "expanded_url" : "http:\/\/youtu.be\/Rs2hjF-lYGM?a",
      "display_url" : "youtu.be\/Rs2hjF-lYGM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345060211695960064",
  "text" : "Webcam video from June 13, 2013 2:05 AM: http:\/\/t.co\/wM1Ybfh0mA via @YouTube",
  "id" : 345060211695960064,
  "created_at" : "2013-06-13 06:09:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/jJgAu4FT9T",
      "expanded_url" : "http:\/\/youtu.be\/SWVKEBcKSig?a",
      "display_url" : "youtu.be\/SWVKEBcKSig?a"
    } ]
  },
  "geo" : { },
  "id_str" : "345033531854036993",
  "text" : "Coptic Broadcasting Network Sponsored App Review: http:\/\/t.co\/jJgAu4FT9T via @YouTube",
  "id" : 345033531854036993,
  "created_at" : "2013-06-13 04:22:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344883410721964032",
  "text" : "Lol",
  "id" : 344883410721964032,
  "created_at" : "2013-06-12 18:26:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344883385115746305",
  "text" : "Watch me tweet",
  "id" : 344883385115746305,
  "created_at" : "2013-06-12 18:26:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344883348746940416",
  "text" : "I love tweeting",
  "id" : 344883348746940416,
  "created_at" : "2013-06-12 18:26:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344883308645191681",
  "text" : "Just talked to Jenna B., a nice lady.",
  "id" : 344883308645191681,
  "created_at" : "2013-06-12 18:26:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/dnkqRykLTo",
      "expanded_url" : "http:\/\/youtu.be\/g8YwpqEk7U0?a",
      "display_url" : "youtu.be\/g8YwpqEk7U0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344246164473917440",
  "text" : "I liked a @YouTube video http:\/\/t.co\/dnkqRykLTo AKE Game Demo",
  "id" : 344246164473917440,
  "created_at" : "2013-06-11 00:14:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/UBWyNXTmfe",
      "expanded_url" : "http:\/\/youtu.be\/HrCUKnpvpi0?a",
      "display_url" : "youtu.be\/HrCUKnpvpi0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344244078722048001",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/UBWyNXTmfe A New Miracle - Israel's Ethiopian Messianic Jews",
  "id" : 344244078722048001,
  "created_at" : "2013-06-11 00:05:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/RVyYCjpN2g",
      "expanded_url" : "http:\/\/youtu.be\/XeXZh9F7JmI?a",
      "display_url" : "youtu.be\/XeXZh9F7JmI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243989903470592",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/RVyYCjpN2g Israel's Messianic Jews",
  "id" : 344243989903470592,
  "created_at" : "2013-06-11 00:05:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Y4T9MnJhyu",
      "expanded_url" : "http:\/\/youtu.be\/jdZP0UPoFVo?a",
      "display_url" : "youtu.be\/jdZP0UPoFVo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243969275883520",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Y4T9MnJhyu Messianic Rabbi shares how he accepted Yeshua as Messiah",
  "id" : 344243969275883520,
  "created_at" : "2013-06-11 00:05:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/WZrfDuslhj",
      "expanded_url" : "http:\/\/youtu.be\/OkUxwVlZ2CQ?a",
      "display_url" : "youtu.be\/OkUxwVlZ2CQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243799020679168",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/WZrfDuslhj Yeshua - Bethel Church - Friday Night Worship April 12, 2013",
  "id" : 344243799020679168,
  "created_at" : "2013-06-11 00:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/g1oqsRukcB",
      "expanded_url" : "http:\/\/youtu.be\/CWZeEnuHHPQ?a",
      "display_url" : "youtu.be\/CWZeEnuHHPQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243758449176576",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/g1oqsRukcB The Name of the True GOD - Part 1 of 2 - By Michael Rood",
  "id" : 344243758449176576,
  "created_at" : "2013-06-11 00:04:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/QWvhPek3PB",
      "expanded_url" : "http:\/\/youtu.be\/aFysYErsgGA?a",
      "display_url" : "youtu.be\/aFysYErsgGA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243531893854208",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/QWvhPek3PB Joshua at the Battle of Jericho",
  "id" : 344243531893854208,
  "created_at" : "2013-06-11 00:03:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/dZrGyQVVKo",
      "expanded_url" : "http:\/\/youtu.be\/gmBj9Jpojf4?a",
      "display_url" : "youtu.be\/gmBj9Jpojf4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243462968856576",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/dZrGyQVVKo Moses - [full movie]",
  "id" : 344243462968856576,
  "created_at" : "2013-06-11 00:03:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/wuhCpyyWmK",
      "expanded_url" : "http:\/\/youtu.be\/4yGH-GmwEDg?a",
      "display_url" : "youtu.be\/4yGH-GmwEDg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243399467089920",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/wuhCpyyWmK Life Of Jesus Christ ( Full Movie )",
  "id" : 344243399467089920,
  "created_at" : "2013-06-11 00:03:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/pEK0xGQ5dM",
      "expanded_url" : "http:\/\/youtu.be\/WNJPJ4JwHeE?a",
      "display_url" : "youtu.be\/WNJPJ4JwHeE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243371470098434",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/pEK0xGQ5dM The Real Face of Jesus From the Shroud of Turin",
  "id" : 344243371470098434,
  "created_at" : "2013-06-11 00:03:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/MSzJ3CAITv",
      "expanded_url" : "http:\/\/youtu.be\/sIIaobr9CFk?a",
      "display_url" : "youtu.be\/sIIaobr9CFk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243162136596480",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/MSzJ3CAITv Christianity, the first 1000 years",
  "id" : 344243162136596480,
  "created_at" : "2013-06-11 00:02:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VCK55gjcMK",
      "expanded_url" : "http:\/\/youtu.be\/9UZeR3yV_Z8?a",
      "display_url" : "youtu.be\/9UZeR3yV_Z8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344243082700660736",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/VCK55gjcMK A RABBI CROSS-EXAMINES CHRISTIANITY (Re: Jews for Jesus, Messianic",
  "id" : 344243082700660736,
  "created_at" : "2013-06-11 00:02:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/l9NNEeXR6p",
      "expanded_url" : "http:\/\/youtu.be\/EONudR_1ngE?a",
      "display_url" : "youtu.be\/EONudR_1ngE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344242732862152705",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/l9NNEeXR6p Rabbi Kirt Schneider on \"It's Supernatural\" With Sid Roth 1\/2",
  "id" : 344242732862152705,
  "created_at" : "2013-06-11 00:00:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Y0BDx3c5jZ",
      "expanded_url" : "http:\/\/youtu.be\/rtCnouwqQXA?a",
      "display_url" : "youtu.be\/rtCnouwqQXA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344242674200633345",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Y0BDx3c5jZ A Messianic Jewish Rabbi Connects Isiah Verses to the US Being Under",
  "id" : 344242674200633345,
  "created_at" : "2013-06-11 00:00:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/zXXm8ZsQKp",
      "expanded_url" : "http:\/\/youtu.be\/vHSNZK4Je-Y?a",
      "display_url" : "youtu.be\/vHSNZK4Je-Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "344242553756975104",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/zXXm8ZsQKp Hava Nagila Original",
  "id" : 344242553756975104,
  "created_at" : "2013-06-10 23:59:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Wjq64PBX6G",
      "expanded_url" : "https:\/\/www.facebook.com\/groups\/118815156662\/",
      "display_url" : "facebook.com\/groups\/1188151\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344235956146159617",
  "text" : "Just been added to another FB Group, yeah\nhttps:\/\/t.co\/Wjq64PBX6G",
  "id" : 344235956146159617,
  "created_at" : "2013-06-10 23:33:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/Qiv75f4PDE",
      "expanded_url" : "http:\/\/sdrv.ms\/13Szh8P",
      "display_url" : "sdrv.ms\/13Szh8P"
    } ]
  },
  "geo" : { },
  "id_str" : "344208220149121025",
  "text" : "My poor beard, it was mowed, I liked that beard http:\/\/t.co\/Qiv75f4PDE",
  "id" : 344208220149121025,
  "created_at" : "2013-06-10 21:43:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344157552839360512",
  "text" : "Mission Improbable's released",
  "id" : 344157552839360512,
  "created_at" : "2013-06-10 18:22:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344157397058727937",
  "text" : "Talked to Jenna B. Just now, she's really a nice friend and one that stays.",
  "id" : 344157397058727937,
  "created_at" : "2013-06-10 18:21:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 76, 86 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Yyybi8tmA7",
      "expanded_url" : "http:\/\/igg.me\/p\/433511\/twtr\/3066576",
      "display_url" : "igg.me\/p\/433511\/twtr\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343769971739983875",
  "text" : "Help make it happen for Need Help Fundraising for Video Game Documentary on @indiegogo http:\/\/t.co\/Yyybi8tmA7",
  "id" : 343769971739983875,
  "created_at" : "2013-06-09 16:42:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343408269370486785",
  "text" : "Just talked to Jenna Briney, she is wonderful",
  "id" : 343408269370486785,
  "created_at" : "2013-06-08 16:44:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342518320551043072",
  "text" : "I meant meets, dang spell check",
  "id" : 342518320551043072,
  "created_at" : "2013-06-06 05:48:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Ka6RiD2Zxk",
      "expanded_url" : "http:\/\/youtu.be\/R5k23e6Vct0?a",
      "display_url" : "youtu.be\/R5k23e6Vct0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "342488952239951872",
  "text" : "What the heck would make him think this? His blindness really is said, I pray he meats Yeshua, (@YouTube http:\/\/t.co\/Ka6RiD2Zxk)",
  "id" : 342488952239951872,
  "created_at" : "2013-06-06 03:51:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342050429338808321",
  "text" : "I memorized how to spell over 432,000 words in the English Dictionary",
  "id" : 342050429338808321,
  "created_at" : "2013-06-04 22:49:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341587317460443136",
  "text" : "Lol",
  "id" : 341587317460443136,
  "created_at" : "2013-06-03 16:08:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341587272027754496",
  "text" : "TGIF got way smaller portions, dissatisfied, and very disappointed",
  "id" : 341587272027754496,
  "created_at" : "2013-06-03 16:08:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341580482183569408",
  "text" : "I like spicy foods",
  "id" : 341580482183569408,
  "created_at" : "2013-06-03 15:41:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338903659444334592",
  "geo" : { },
  "id_str" : "341580416760836096",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 eating \"scorching\" wings at TGIF",
  "id" : 341580416760836096,
  "in_reply_to_status_id" : 338903659444334592,
  "created_at" : "2013-06-03 15:41:32 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/DdInc5HtbO",
      "expanded_url" : "http:\/\/youtu.be\/z714RiXsAKQ?a",
      "display_url" : "youtu.be\/z714RiXsAKQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341563689050206209",
  "text" : "Messianic Jews aren't pagan, and really you need to stop. Please really research your topic (@YouTube http:\/\/t.co\/DdInc5HtbO)",
  "id" : 341563689050206209,
  "created_at" : "2013-06-03 14:35:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 9, 17 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/h1qQqK57Ph",
      "expanded_url" : "http:\/\/youtu.be\/S8aeUE89cT8?a",
      "display_url" : "youtu.be\/S8aeUE89cT8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341321222187008000",
  "text" : "Not was (@YouTube http:\/\/t.co\/h1qQqK57Ph)",
  "id" : 341321222187008000,
  "created_at" : "2013-06-02 22:31:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 71, 79 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/h1qQqK57Ph",
      "expanded_url" : "http:\/\/youtu.be\/S8aeUE89cT8?a",
      "display_url" : "youtu.be\/S8aeUE89cT8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341321190385778688",
  "text" : "He was amazing, wasn't he. Oh wait sorry for the error, he IS amazing (@YouTube http:\/\/t.co\/h1qQqK57Ph)",
  "id" : 341321190385778688,
  "created_at" : "2013-06-02 22:31:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/h1qQqK57Ph",
      "expanded_url" : "http:\/\/youtu.be\/S8aeUE89cT8?a",
      "display_url" : "youtu.be\/S8aeUE89cT8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341321003307237376",
  "text" : "I liked a @YouTube video http:\/\/t.co\/h1qQqK57Ph Luciano Pavarotti - Ave Maria Best Performance",
  "id" : 341321003307237376,
  "created_at" : "2013-06-02 22:30:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/5xg687WeOy",
      "expanded_url" : "http:\/\/youtu.be\/BDGOCblJDYs?a",
      "display_url" : "youtu.be\/BDGOCblJDYs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320616533716992",
  "text" : "I liked a @YouTube video http:\/\/t.co\/5xg687WeOy SHALOM ALEICHEM with Lyrics by Susana Allen",
  "id" : 341320616533716992,
  "created_at" : "2013-06-02 22:29:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/U7pOP3M3F2",
      "expanded_url" : "http:\/\/youtu.be\/uSTOcyevIOE?a",
      "display_url" : "youtu.be\/uSTOcyevIOE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320588209569793",
  "text" : "Yeshua be with you (@YouTube http:\/\/t.co\/U7pOP3M3F2)",
  "id" : 341320588209569793,
  "created_at" : "2013-06-02 22:29:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/U7pOP3M3F2",
      "expanded_url" : "http:\/\/youtu.be\/uSTOcyevIOE?a",
      "display_url" : "youtu.be\/uSTOcyevIOE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320405635710976",
  "text" : "I liked a @YouTube video http:\/\/t.co\/U7pOP3M3F2 hava nagila",
  "id" : 341320405635710976,
  "created_at" : "2013-06-02 22:28:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/1fAmQtx8i2",
      "expanded_url" : "http:\/\/youtu.be\/HbBFE2YKCTA?a",
      "display_url" : "youtu.be\/HbBFE2YKCTA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320358311362560",
  "text" : "I liked a @YouTube video from @cinabahia http:\/\/t.co\/1fAmQtx8i2 Shaalu Shelom Yerushalayim - \u05D3\u05D5\u05D3 \u05D1\u05DF \u05D9\u05D4\u05D5\u05D3\u05D4",
  "id" : 341320358311362560,
  "created_at" : "2013-06-02 22:28:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/c4YfzP43R9",
      "expanded_url" : "http:\/\/youtu.be\/e2mDP-p3qvY?a",
      "display_url" : "youtu.be\/e2mDP-p3qvY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320131043020800",
  "text" : "I liked a @YouTube video http:\/\/t.co\/c4YfzP43R9 Shalom Aleichem - Shabbat Song",
  "id" : 341320131043020800,
  "created_at" : "2013-06-02 22:27:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/5Ej6nX2e46",
      "expanded_url" : "http:\/\/youtu.be\/AYuUxIm-jFw?a",
      "display_url" : "youtu.be\/AYuUxIm-jFw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341320084523991040",
  "text" : "I liked a @YouTube video http:\/\/t.co\/5Ej6nX2e46 Graal - Blessed be The Name",
  "id" : 341320084523991040,
  "created_at" : "2013-06-02 22:27:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341319979272126464",
  "text" : "Sorry for the spelling errors. Jews didn't murder Jesus, Sin did, don't be like the Pharisees (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341319979272126464,
  "created_at" : "2013-06-02 22:26:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/FYmnuCC0rJ",
      "expanded_url" : "http:\/\/youtu.be\/6vRtnE6UBBg?a",
      "display_url" : "youtu.be\/6vRtnE6UBBg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341319977548255232",
  "text" : "I liked a @YouTube video http:\/\/t.co\/FYmnuCC0rJ \u05DE\u05D5\u05D6\u05D9\u05E7\u05D4 \u05D0\u05E0\u05D3\u05DC\u05D5\u05E1\u05D9\u05EA \u05D9\u05D4\u05D5\u05D3\u05D9\u05EA \u064A\u0647\u0648\u062F \u0627\u0644\u0623\u0646\u062F\u0644\u0633 Andalusian Jewish",
  "id" : 341319977548255232,
  "created_at" : "2013-06-02 22:26:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341318842015940610",
  "text" : "Go ahead let them see my comments and see how they react to yours my brother (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341318842015940610,
  "created_at" : "2013-06-02 22:22:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341318735841353728",
  "text" : "Jews did murder Jesus sin did, you pharisee, what man can understand what he doesn't know. (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341318735841353728,
  "created_at" : "2013-06-02 22:21:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/tirPISyBW3",
      "expanded_url" : "http:\/\/youtu.be\/VoBW57t1Mvs?a",
      "display_url" : "youtu.be\/VoBW57t1Mvs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341288484314689537",
  "text" : "She isn't Texas's sweetheart, she's america's sweetheart, God Bless Children like these (@YouTube http:\/\/t.co\/tirPISyBW3)",
  "id" : 341288484314689537,
  "created_at" : "2013-06-02 20:21:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341054967622299648",
  "text" : "I am a Messianic Jewish Teacher then in action seeing blasphamy in which I must leave this (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341054967622299648,
  "created_at" : "2013-06-02 04:53:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 26, 34 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/4lVRhkEnJe",
      "expanded_url" : "http:\/\/youtu.be\/4mzn-LMr_CY?a",
      "display_url" : "youtu.be\/4mzn-LMr_CY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341051886830497793",
  "text" : "I love messianic Judaism (@YouTube http:\/\/t.co\/4lVRhkEnJe)",
  "id" : 341051886830497793,
  "created_at" : "2013-06-02 04:41:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341051008488706048",
  "text" : "Yeshua died for us, his life was taken for our life, that is why it is not a law no more. Also (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341051008488706048,
  "created_at" : "2013-06-02 04:37:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341048869045542914",
  "text" : "If you have the holy ghost on your side why do you need to censor people? (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341048869045542914,
  "created_at" : "2013-06-02 04:29:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341048601662861312",
  "text" : "The gospel we are saved are by all of them, we are completely saved by the word of God and (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341048601662861312,
  "created_at" : "2013-06-02 04:28:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341048008982528000",
  "text" : "Who are you to speak in the position of the Lord, yet you say I am rebukes? How arragant is (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341048008982528000,
  "created_at" : "2013-06-02 04:25:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 30, 38 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341046928273973248",
  "text" : "Life is life God died for us (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341046928273973248,
  "created_at" : "2013-06-02 04:21:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341046798481252352",
  "text" : "The new testament was written in koine Greek (which most was) then why do you incest on using (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341046798481252352,
  "created_at" : "2013-06-02 04:21:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 69, 77 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/hZxFZBXIh4",
      "expanded_url" : "http:\/\/youtu.be\/2T3i9KCH3oU?a",
      "display_url" : "youtu.be\/2T3i9KCH3oU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341046023898136576",
  "text" : "She should dress more appropiate when she sings a holy song as this (@YouTube http:\/\/t.co\/hZxFZBXIh4)",
  "id" : 341046023898136576,
  "created_at" : "2013-06-02 04:18:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XOAT5Hv16A",
      "expanded_url" : "http:\/\/youtu.be\/ZjAwZbGTBcc?a",
      "display_url" : "youtu.be\/ZjAwZbGTBcc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341045555952226307",
  "text" : "Shabbat Shelom, Shabbat, Shabbat Shelom, Pray for peace upon Juraselm, Pray for peace upon (@YouTube http:\/\/t.co\/XOAT5Hv16A)",
  "id" : 341045555952226307,
  "created_at" : "2013-06-02 04:16:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/arMAMdKeix",
      "expanded_url" : "http:\/\/youtu.be\/6inhysVfvgI?a",
      "display_url" : "youtu.be\/6inhysVfvgI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341044265184534528",
  "text" : "His name is Yeshua, the one who saves, Jesus is just a translation that has been rendered (@YouTube http:\/\/t.co\/arMAMdKeix)",
  "id" : 341044265184534528,
  "created_at" : "2013-06-02 04:11:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341043428441878529",
  "text" : "I am one of the head leaders in this group today, and it is not a cult, but we agree to (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341043428441878529,
  "created_at" : "2013-06-02 04:07:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341042178702848001",
  "text" : "The words Theos, Kurios, and Lesous came after the word Messiah Yeshua, these are modern (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341042178702848001,
  "created_at" : "2013-06-02 04:02:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341041242337054720",
  "text" : "I am one of those teachers, God Bless You Brother, and I do not wish hate upon you, but God (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341041242337054720,
  "created_at" : "2013-06-02 03:59:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341040877281611776",
  "text" : "We keep sabbath and food laws, as well as circumcision (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341040877281611776,
  "created_at" : "2013-06-02 03:57:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 71, 79 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341037236160176128",
  "text" : "Why do you comment to yourself 45 times, and block those who disagree (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341037236160176128,
  "created_at" : "2013-06-02 03:43:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341021387525349376",
  "text" : "I love messianic Judaism",
  "id" : 341021387525349376,
  "created_at" : "2013-06-02 02:40:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "341020565097836544",
  "text" : "Stop insulting my religion sir, are you saying one who is willing to die for the name of God (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 341020565097836544,
  "created_at" : "2013-06-02 02:36:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/XszdTQcbGt",
      "expanded_url" : "http:\/\/youtu.be\/B7qpC6rLY8s?a",
      "display_url" : "youtu.be\/B7qpC6rLY8s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340943365883445248",
  "text" : "A messianic Jew is someone who follows traditions of the jewish community today but still (@YouTube http:\/\/t.co\/XszdTQcbGt)",
  "id" : 340943365883445248,
  "created_at" : "2013-06-01 21:30:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]