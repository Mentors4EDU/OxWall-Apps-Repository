Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShadowNoses",
      "screen_name" : "NosesOfShadows",
      "indices" : [ 3, 18 ],
      "id_str" : "3082119530",
      "id" : 3082119530
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsteadOfHate",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770419225483698176",
  "text" : "RT @NosesOfShadows: #InsteadOfHate You could stop being an SJW Hashtag warrior doing nothing of consequence as you complain about oppressio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsteadOfHate",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770418340422574081",
    "text" : "#InsteadOfHate You could stop being an SJW Hashtag warrior doing nothing of consequence as you complain about oppression that doesn't exist",
    "id" : 770418340422574081,
    "created_at" : "2016-08-30 00:30:20 +0000",
    "user" : {
      "name" : "ShadowNoses",
      "screen_name" : "NosesOfShadows",
      "protected" : false,
      "id_str" : "3082119530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823386525144494080\/JUxY3QDG_normal.jpg",
      "id" : 3082119530,
      "verified" : false
    }
  },
  "id" : 770419225483698176,
  "created_at" : "2016-08-30 00:33:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rogelio Barreiro",
      "screen_name" : "OhNoItsRoy",
      "indices" : [ 3, 14 ],
      "id_str" : "1669655593",
      "id" : 1669655593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsteadOfHate",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770419033497804800",
  "text" : "RT @OhNoItsRoy: Love #InsteadOfHate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsteadOfHate",
        "indices" : [ 5, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770418716555091968",
    "text" : "Love #InsteadOfHate",
    "id" : 770418716555091968,
    "created_at" : "2016-08-30 00:31:50 +0000",
    "user" : {
      "name" : "Rogelio Barreiro",
      "screen_name" : "OhNoItsRoy",
      "protected" : false,
      "id_str" : "1669655593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000293526285\/d1da25367f898a1a09e528e462e20754_normal.jpeg",
      "id" : 1669655593,
      "verified" : false
    }
  },
  "id" : 770419033497804800,
  "created_at" : "2016-08-30 00:33:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ugene's Politics",
      "screen_name" : "UgenesPolitics",
      "indices" : [ 3, 18 ],
      "id_str" : "3594364096",
      "id" : 3594364096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsteadOfHate",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770418729930883072",
  "text" : "RT @UgenesPolitics: Choose to love #InsteadOfHate. Love is the most beautiful thing humans do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsteadOfHate",
        "indices" : [ 15, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770416757848801280",
    "text" : "Choose to love #InsteadOfHate. Love is the most beautiful thing humans do.",
    "id" : 770416757848801280,
    "created_at" : "2016-08-30 00:24:03 +0000",
    "user" : {
      "name" : "Ugene's Politics",
      "screen_name" : "UgenesPolitics",
      "protected" : false,
      "id_str" : "3594364096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849305543919448064\/Nv7Hwio7_normal.jpg",
      "id" : 3594364096,
      "verified" : false
    }
  },
  "id" : 770418729930883072,
  "created_at" : "2016-08-30 00:31:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Titan O'Hearn",
      "screen_name" : "MikeOHearn",
      "indices" : [ 3, 14 ],
      "id_str" : "284281579",
      "id" : 284281579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsteadOfHate",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770418695394955264",
  "text" : "RT @MikeOHearn: #InsteadOfHate give someone a compliment. You may change their whole day for the better.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsteadOfHate",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770351728952619008",
    "text" : "#InsteadOfHate give someone a compliment. You may change their whole day for the better.",
    "id" : 770351728952619008,
    "created_at" : "2016-08-29 20:05:39 +0000",
    "user" : {
      "name" : "Mike Titan O'Hearn",
      "screen_name" : "MikeOHearn",
      "protected" : false,
      "id_str" : "284281579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/833119257164537856\/5JNdS9YX_normal.jpg",
      "id" : 284281579,
      "verified" : true
    }
  },
  "id" : 770418695394955264,
  "created_at" : "2016-08-30 00:31:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770284799848316928",
  "text" : "RT @RandiAthenas: Whoever is in charge of making sure I don't do dumb stuff is fired.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770180216010399744",
    "text" : "Whoever is in charge of making sure I don't do dumb stuff is fired.",
    "id" : 770180216010399744,
    "created_at" : "2016-08-29 08:44:07 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 770284799848316928,
  "created_at" : "2016-08-29 15:39:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bongino",
      "screen_name" : "dbongino",
      "indices" : [ 3, 12 ],
      "id_str" : "232901331",
      "id" : 232901331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/T9aaIPK7ST",
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/770276903773011968",
      "display_url" : "twitter.com\/tedcruz\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770284513729585154",
  "text" : "RT @dbongino: Thanks very much for your support.  https:\/\/t.co\/T9aaIPK7ST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/T9aaIPK7ST",
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/770276903773011968",
        "display_url" : "twitter.com\/tedcruz\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770278954238373888",
    "text" : "Thanks very much for your support.  https:\/\/t.co\/T9aaIPK7ST",
    "id" : 770278954238373888,
    "created_at" : "2016-08-29 15:16:28 +0000",
    "user" : {
      "name" : "Dan Bongino",
      "screen_name" : "dbongino",
      "protected" : false,
      "id_str" : "232901331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770990998117687296\/APIk_xWp_normal.jpg",
      "id" : 232901331,
      "verified" : true
    }
  },
  "id" : 770284513729585154,
  "created_at" : "2016-08-29 15:38:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 0, 15 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770284402815434752",
  "in_reply_to_user_id" : 2575373509,
  "text" : "@AvalloneHunter That set I am un-subbing you just so I can have the satisfaction of subscribing to you again",
  "id" : 770284402815434752,
  "created_at" : "2016-08-29 15:38:07 +0000",
  "in_reply_to_screen_name" : "AvalloneHunter",
  "in_reply_to_user_id_str" : "2575373509",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GypsyDanger \uD83D\uDC51",
      "screen_name" : "GypsyDanger1013",
      "indices" : [ 3, 19 ],
      "id_str" : "3732994399",
      "id" : 3732994399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mDZUJEieuU",
      "expanded_url" : "https:\/\/youtu.be\/97jvT5NLlPQ",
      "display_url" : "youtu.be\/97jvT5NLlPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "770283785619406848",
  "text" : "RT @GypsyDanger1013: Women who belong in the kitchen. That would be me fam. Thanks for watching and I'm sorry lol\nhttps:\/\/t.co\/mDZUJEieuU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/mDZUJEieuU",
        "expanded_url" : "https:\/\/youtu.be\/97jvT5NLlPQ",
        "display_url" : "youtu.be\/97jvT5NLlPQ"
      } ]
    },
    "geo" : { },
    "id_str" : "770110209565995008",
    "text" : "Women who belong in the kitchen. That would be me fam. Thanks for watching and I'm sorry lol\nhttps:\/\/t.co\/mDZUJEieuU",
    "id" : 770110209565995008,
    "created_at" : "2016-08-29 04:05:56 +0000",
    "user" : {
      "name" : "GypsyDanger \uD83D\uDC51",
      "screen_name" : "GypsyDanger1013",
      "protected" : false,
      "id_str" : "3732994399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858008717127798784\/0W1OqYvT_normal.jpg",
      "id" : 3732994399,
      "verified" : false
    }
  },
  "id" : 770283785619406848,
  "created_at" : "2016-08-29 15:35:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770283750714404864",
  "text" : "RT @realDonaldTrump: I think that both candidates, Crooked Hillary and myself, should release detailed medical records. I have no problem i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770039317142069248",
    "text" : "I think that both candidates, Crooked Hillary and myself, should release detailed medical records. I have no problem in doing so! Hillary?",
    "id" : 770039317142069248,
    "created_at" : "2016-08-28 23:24:14 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874276197357596672\/kUuht00m_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 770283750714404864,
  "created_at" : "2016-08-29 15:35:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bagel Gabe",
      "screen_name" : "WeirdNameProd",
      "indices" : [ 3, 17 ],
      "id_str" : "3449407654",
      "id" : 3449407654
    }, {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 58, 73 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770119449424883712",
  "text" : "RT @WeirdNameProd: How did I only just now find out about @AvalloneHunter? Apparently people I know watch his videos. Why did they not tell\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hunter Avallone",
        "screen_name" : "AvalloneHunter",
        "indices" : [ 39, 54 ],
        "id_str" : "2575373509",
        "id" : 2575373509
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769646016811397120",
    "text" : "How did I only just now find out about @AvalloneHunter? Apparently people I know watch his videos. Why did they not tell me. He's amazing",
    "id" : 769646016811397120,
    "created_at" : "2016-08-27 21:21:24 +0000",
    "user" : {
      "name" : "Bagel Gabe",
      "screen_name" : "WeirdNameProd",
      "protected" : false,
      "id_str" : "3449407654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927292772461301760\/ZqGTlQGv_normal.jpg",
      "id" : 3449407654,
      "verified" : false
    }
  },
  "id" : 770119449424883712,
  "created_at" : "2016-08-29 04:42:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Bates",
      "screen_name" : "levly_love",
      "indices" : [ 3, 14 ],
      "id_str" : "21748502",
      "id" : 21748502
    }, {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 16, 31 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/levly_love\/status\/769318400250159104\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/FIuSWHdNtf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0q_ubUAAAA51I.jpg",
      "id_str" : "769318385632935936",
      "id" : 769318385632935936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0q_ubUAAAA51I.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FIuSWHdNtf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770119080602923008",
  "text" : "RT @levly_love: @AvalloneHunter This is glorious. https:\/\/t.co\/FIuSWHdNtf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hunter Avallone",
        "screen_name" : "AvalloneHunter",
        "indices" : [ 0, 15 ],
        "id_str" : "2575373509",
        "id" : 2575373509
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/levly_love\/status\/769318400250159104\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/FIuSWHdNtf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0q_ubUAAAA51I.jpg",
        "id_str" : "769318385632935936",
        "id" : 769318385632935936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0q_ubUAAAA51I.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FIuSWHdNtf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769318400250159104",
    "in_reply_to_user_id" : 2575373509,
    "text" : "@AvalloneHunter This is glorious. https:\/\/t.co\/FIuSWHdNtf",
    "id" : 769318400250159104,
    "created_at" : "2016-08-26 23:39:34 +0000",
    "in_reply_to_screen_name" : "AvalloneHunter",
    "in_reply_to_user_id_str" : "2575373509",
    "user" : {
      "name" : "Phil Bates",
      "screen_name" : "levly_love",
      "protected" : false,
      "id_str" : "21748502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456988876595134464\/NukLZP25_normal.jpeg",
      "id" : 21748502,
      "verified" : false
    }
  },
  "id" : 770119080602923008,
  "created_at" : "2016-08-29 04:41:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DanielB",
      "screen_name" : "Danielbis2cool",
      "indices" : [ 3, 18 ],
      "id_str" : "766679179152752640",
      "id" : 766679179152752640
    }, {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 20, 35 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Danielbis2cool\/status\/768645607758172161\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/IeOoBTzch2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqrGjV4WEAEJ2gY.jpg",
      "id_str" : "768644996891283457",
      "id" : 768644996891283457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqrGjV4WEAEJ2gY.jpg",
      "sizes" : [ {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1084
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 1084
      } ],
      "display_url" : "pic.twitter.com\/IeOoBTzch2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770118961128177664",
  "text" : "RT @Danielbis2cool: @AvalloneHunter Some fan art that I made during the stream today, So yeah! https:\/\/t.co\/IeOoBTzch2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hunter Avallone",
        "screen_name" : "AvalloneHunter",
        "indices" : [ 0, 15 ],
        "id_str" : "2575373509",
        "id" : 2575373509
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Danielbis2cool\/status\/768645607758172161\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/IeOoBTzch2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqrGjV4WEAEJ2gY.jpg",
        "id_str" : "768644996891283457",
        "id" : 768644996891283457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqrGjV4WEAEJ2gY.jpg",
        "sizes" : [ {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1084
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1084
        } ],
        "display_url" : "pic.twitter.com\/IeOoBTzch2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768645607758172161",
    "in_reply_to_user_id" : 2575373509,
    "text" : "@AvalloneHunter Some fan art that I made during the stream today, So yeah! https:\/\/t.co\/IeOoBTzch2",
    "id" : 768645607758172161,
    "created_at" : "2016-08-25 03:06:08 +0000",
    "in_reply_to_screen_name" : "AvalloneHunter",
    "in_reply_to_user_id_str" : "2575373509",
    "user" : {
      "name" : "DanielB",
      "screen_name" : "Danielbis2cool",
      "protected" : false,
      "id_str" : "766679179152752640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766681350099394560\/mLrfA7gA_normal.jpg",
      "id" : 766679179152752640,
      "verified" : false
    }
  },
  "id" : 770118961128177664,
  "created_at" : "2016-08-29 04:40:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 0, 15 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768270707956391940",
  "geo" : { },
  "id_str" : "770118865607135232",
  "in_reply_to_user_id" : 2575373509,
  "text" : "@AvalloneHunter lol, I looked at your Insta and half the comments are from girls either calling you an angel or saying you're hot, Hahaha",
  "id" : 770118865607135232,
  "in_reply_to_status_id" : 768270707956391940,
  "created_at" : "2016-08-29 04:40:20 +0000",
  "in_reply_to_screen_name" : "AvalloneHunter",
  "in_reply_to_user_id_str" : "2575373509",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizette\uD83D\uDC95",
      "screen_name" : "LizetteVanessa_",
      "indices" : [ 3, 19 ],
      "id_str" : "411997862",
      "id" : 411997862
    }, {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 35, 47 ],
      "id_str" : "44184316",
      "id" : 44184316
    }, {
      "name" : "BRyAN",
      "screen_name" : "TheCrazieCrew",
      "indices" : [ 52, 66 ],
      "id_str" : "3154352245",
      "id" : 3154352245
    }, {
      "name" : "J-Fred",
      "screen_name" : "JFRED1991",
      "indices" : [ 107, 117 ],
      "id_str" : "599050581",
      "id" : 599050581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945654361780224",
  "text" : "RT @LizetteVanessa_: When you meet @Matthiasiam and @TheCrazieCrew but you forget to ask them to say Hi to @JFRED1991 for you. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias",
        "screen_name" : "Matthiasiam",
        "indices" : [ 14, 26 ],
        "id_str" : "44184316",
        "id" : 44184316
      }, {
        "name" : "BRyAN",
        "screen_name" : "TheCrazieCrew",
        "indices" : [ 31, 45 ],
        "id_str" : "3154352245",
        "id" : 3154352245
      }, {
        "name" : "J-Fred",
        "screen_name" : "JFRED1991",
        "indices" : [ 86, 96 ],
        "id_str" : "599050581",
        "id" : 599050581
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LizetteVanessa_\/status\/769619720047689728\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/7C7Dz8sJqZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq49DIeVYAASz_X.jpg",
        "id_str" : "769619710350548992",
        "id" : 769619710350548992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq49DIeVYAASz_X.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 872
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 872
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 872
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/7C7Dz8sJqZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769619720047689728",
    "text" : "When you meet @Matthiasiam and @TheCrazieCrew but you forget to ask them to say Hi to @JFRED1991 for you. https:\/\/t.co\/7C7Dz8sJqZ",
    "id" : 769619720047689728,
    "created_at" : "2016-08-27 19:36:54 +0000",
    "user" : {
      "name" : "Lizette\uD83D\uDC95",
      "screen_name" : "LizetteVanessa_",
      "protected" : false,
      "id_str" : "411997862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906343310905585664\/tPD_XOYt_normal.jpg",
      "id" : 411997862,
      "verified" : false
    }
  },
  "id" : 769945654361780224,
  "created_at" : "2016-08-28 17:12:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945606978756608",
  "text" : "RT @Matthiasiam: I get you, but it's actually not going to be treated as behind the scenes. It's it's own thing. \u2764\uFE0F\uD83D\uDC4D\uD83C\uDFFB https:\/\/t.co\/fL8VNbHz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/fL8VNbHzbb",
        "expanded_url" : "https:\/\/twitter.com\/jskorzec\/status\/769918273324449792",
        "display_url" : "twitter.com\/jskorzec\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769918483182202880",
    "text" : "I get you, but it's actually not going to be treated as behind the scenes. It's it's own thing. \u2764\uFE0F\uD83D\uDC4D\uD83C\uDFFB https:\/\/t.co\/fL8VNbHzbb",
    "id" : 769918483182202880,
    "created_at" : "2016-08-28 15:24:05 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 769945606978756608,
  "created_at" : "2016-08-28 17:11:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945548212301824",
  "text" : "RT @scrowder: Over a dozen leftists have called me out on here. Over a dozen have declined to subsequently debate. My only trash talk is \"I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769912046045528068",
    "text" : "Over a dozen leftists have called me out on here. Over a dozen have declined to subsequently debate. My only trash talk is \"I accept.\"",
    "id" : 769912046045528068,
    "created_at" : "2016-08-28 14:58:30 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 769945548212301824,
  "created_at" : "2016-08-28 17:11:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hi Rello",
      "screen_name" : "MichaelRello",
      "indices" : [ 3, 16 ],
      "id_str" : "77080603",
      "id" : 77080603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945524153774080",
  "text" : "RT @MichaelRello: I be having dreams I'm flying",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769944968911851520",
    "text" : "I be having dreams I'm flying",
    "id" : 769944968911851520,
    "created_at" : "2016-08-28 17:09:20 +0000",
    "user" : {
      "name" : "Hi Rello",
      "screen_name" : "MichaelRello",
      "protected" : false,
      "id_str" : "77080603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/907397407767441408\/dramr8X-_normal.jpg",
      "id" : 77080603,
      "verified" : false
    }
  },
  "id" : 769945524153774080,
  "created_at" : "2016-08-28 17:11:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945408458125313",
  "text" : "RT @KassyDillon: The best thing about the Kaepernick situation is he did it for weeks and nobody noticed. He had to ask for media coverage.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769898158985998336",
    "text" : "The best thing about the Kaepernick situation is he did it for weeks and nobody noticed. He had to ask for media coverage.",
    "id" : 769898158985998336,
    "created_at" : "2016-08-28 14:03:19 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924765802456408064\/-jL6Yg2a_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 769945408458125313,
  "created_at" : "2016-08-28 17:11:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945377684488192",
  "text" : "RT @BarbaraCorcoran: My mom and dad had 10 kids and slept on the living room sofa. You don't need luxury for romance!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769882671619141632",
    "text" : "My mom and dad had 10 kids and slept on the living room sofa. You don't need luxury for romance!",
    "id" : 769882671619141632,
    "created_at" : "2016-08-28 13:01:47 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 769945377684488192,
  "created_at" : "2016-08-28 17:10:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillaryClintonSearchTerms",
      "indices" : [ 107, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945340036386816",
  "text" : "RT @hannahbleau_: What's the longest a presidential candidate has gone without holding a press conference? #HillaryClintonSearchTerms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillaryClintonSearchTerms",
        "indices" : [ 89, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769596961745883136",
    "text" : "What's the longest a presidential candidate has gone without holding a press conference? #HillaryClintonSearchTerms",
    "id" : 769596961745883136,
    "created_at" : "2016-08-27 18:06:28 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 769945340036386816,
  "created_at" : "2016-08-28 17:10:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/769945206015787008\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/sOid5AwArZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9lEwXWIAAKIPo.jpg",
      "id_str" : "769945193680347136",
      "id" : 769945193680347136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9lEwXWIAAKIPo.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/sOid5AwArZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769945206015787008",
  "text" : "The crazy bites are good, just over priced https:\/\/t.co\/sOid5AwArZ",
  "id" : 769945206015787008,
  "created_at" : "2016-08-28 17:10:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768124814074769409",
  "text" : "RT @hannahbleau_: Matt Lauer acts like Lotche put national security at risk by transmitting classified info on a private email server or so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767194649932943361",
    "text" : "Matt Lauer acts like Lotche put national security at risk by transmitting classified info on a private email server or something.",
    "id" : 767194649932943361,
    "created_at" : "2016-08-21 03:00:32 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 768124814074769409,
  "created_at" : "2016-08-23 16:36:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/768124783292715008\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/JIBJ23AhBN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqjtaZ-VUAAZQMC.jpg",
      "id_str" : "768124774371381248",
      "id" : 768124774371381248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqjtaZ-VUAAZQMC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/JIBJ23AhBN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/768124783292715008\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/JIBJ23AhBN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqjtaeDUMAAqdkc.jpg",
      "id_str" : "768124775466020864",
      "id" : 768124775466020864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqjtaeDUMAAqdkc.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/JIBJ23AhBN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768124783292715008",
  "text" : "These were delicious buys https:\/\/t.co\/JIBJ23AhBN",
  "id" : 768124783292715008,
  "created_at" : "2016-08-23 16:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/766458476834983939\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Xbq52AC1j1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMB69_WEAAPWoP.jpg",
      "id_str" : "766458474167406592",
      "id" : 766458474167406592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMB69_WEAAPWoP.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Xbq52AC1j1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/pwgE1Y8dOq",
      "expanded_url" : "http:\/\/ow.ly\/Oqen303l6vP",
      "display_url" : "ow.ly\/Oqen303l6vP"
    } ]
  },
  "geo" : { },
  "id_str" : "766458639980855296",
  "text" : "RT @hootsuite: 10 social media benefits, and how they help grow your business: https:\/\/t.co\/pwgE1Y8dOq https:\/\/t.co\/Xbq52AC1j1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/766458476834983939\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Xbq52AC1j1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMB69_WEAAPWoP.jpg",
        "id_str" : "766458474167406592",
        "id" : 766458474167406592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMB69_WEAAPWoP.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Xbq52AC1j1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/pwgE1Y8dOq",
        "expanded_url" : "http:\/\/ow.ly\/Oqen303l6vP",
        "display_url" : "ow.ly\/Oqen303l6vP"
      } ]
    },
    "geo" : { },
    "id_str" : "766458476834983939",
    "text" : "10 social media benefits, and how they help grow your business: https:\/\/t.co\/pwgE1Y8dOq https:\/\/t.co\/Xbq52AC1j1",
    "id" : 766458476834983939,
    "created_at" : "2016-08-19 02:15:15 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 766458639980855296,
  "created_at" : "2016-08-19 02:15:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/QtFZrIyzyX",
      "expanded_url" : "http:\/\/bit.ly\/2bxg5rX",
      "display_url" : "bit.ly\/2bxg5rX"
    } ]
  },
  "geo" : { },
  "id_str" : "766458378361208833",
  "text" : "RT @seanhannity: Bombshell: Clinton Foundation witnesses coming forward in pay-for-play investigation https:\/\/t.co\/QtFZrIyzyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/QtFZrIyzyX",
        "expanded_url" : "http:\/\/bit.ly\/2bxg5rX",
        "display_url" : "bit.ly\/2bxg5rX"
      } ]
    },
    "geo" : { },
    "id_str" : "766428769443774464",
    "text" : "Bombshell: Clinton Foundation witnesses coming forward in pay-for-play investigation https:\/\/t.co\/QtFZrIyzyX",
    "id" : 766428769443774464,
    "created_at" : "2016-08-19 00:17:12 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 766458378361208833,
  "created_at" : "2016-08-19 02:14:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766458052295979008",
  "text" : "RT @tedcruz: Did Iran's Revolutionary Guard Corps seize Obama's potentially illegal $400M payment to Iran? We don't know: https:\/\/t.co\/0pZj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/0pZj2xIfeI",
        "expanded_url" : "http:\/\/on.wsj.com\/2blbclv",
        "display_url" : "on.wsj.com\/2blbclv"
      } ]
    },
    "geo" : { },
    "id_str" : "766378647095619584",
    "text" : "Did Iran's Revolutionary Guard Corps seize Obama's potentially illegal $400M payment to Iran? We don't know: https:\/\/t.co\/0pZj2xIfeI",
    "id" : 766378647095619584,
    "created_at" : "2016-08-18 20:58:02 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 766458052295979008,
  "created_at" : "2016-08-19 02:13:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Newt Gingrich",
      "screen_name" : "newtgingrich",
      "indices" : [ 34, 47 ],
      "id_str" : "20713061",
      "id" : 20713061
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 62, 72 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766458019760701445",
  "text" : "RT @seanhannity: NOW on #Hannity: @newtgingrich reacts to the @StateDept's admittance that the $400 billion to Iran was in exchange for pri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newt Gingrich",
        "screen_name" : "newtgingrich",
        "indices" : [ 17, 30 ],
        "id_str" : "20713061",
        "id" : 20713061
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 45, 55 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 7, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766455148377800704",
    "text" : "NOW on #Hannity: @newtgingrich reacts to the @StateDept's admittance that the $400 billion to Iran was in exchange for prisoners &amp; more.",
    "id" : 766455148377800704,
    "created_at" : "2016-08-19 02:02:02 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 766458019760701445,
  "created_at" : "2016-08-19 02:13:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766457992531369984",
  "text" : "RT @hannahbleau_: The same people mad at Ryan Lochte for lying are the same people who think Hillary Clinton would make a good president. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LochteGate",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766421808174108672",
    "text" : "The same people mad at Ryan Lochte for lying are the same people who think Hillary Clinton would make a good president. #LochteGate",
    "id" : 766421808174108672,
    "created_at" : "2016-08-18 23:49:33 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 766457992531369984,
  "created_at" : "2016-08-19 02:13:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/766457619527639040\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ybx8WwwMIW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMBGXrXEAAoeZd.jpg",
      "id_str" : "766457570529841152",
      "id" : 766457570529841152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMBGXrXEAAoeZd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/ybx8WwwMIW"
    } ],
    "hashtags" : [ {
      "text" : "HillarysStools",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766457943868997632",
  "text" : "RT @KassyDillon: #HillarysStools https:\/\/t.co\/ybx8WwwMIW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/766457619527639040\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/ybx8WwwMIW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMBGXrXEAAoeZd.jpg",
        "id_str" : "766457570529841152",
        "id" : 766457570529841152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMBGXrXEAAoeZd.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/ybx8WwwMIW"
      } ],
      "hashtags" : [ {
        "text" : "HillarysStools",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766457619527639040",
    "text" : "#HillarysStools https:\/\/t.co\/ybx8WwwMIW",
    "id" : 766457619527639040,
    "created_at" : "2016-08-19 02:11:51 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924765802456408064\/-jL6Yg2a_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 766457943868997632,
  "created_at" : "2016-08-19 02:13:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/l7vjpcaclI",
      "expanded_url" : "http:\/\/fb.me\/7GIsas83t",
      "display_url" : "fb.me\/7GIsas83t"
    } ]
  },
  "geo" : { },
  "id_str" : "766457613403947008",
  "text" : "RT @EmperorDarroux: The next version of Android could be coming a lot sooner than you think https:\/\/t.co\/l7vjpcaclI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/l7vjpcaclI",
        "expanded_url" : "http:\/\/fb.me\/7GIsas83t",
        "display_url" : "fb.me\/7GIsas83t"
      } ]
    },
    "geo" : { },
    "id_str" : "766356608225992704",
    "text" : "The next version of Android could be coming a lot sooner than you think https:\/\/t.co\/l7vjpcaclI",
    "id" : 766356608225992704,
    "created_at" : "2016-08-18 19:30:28 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 766457613403947008,
  "created_at" : "2016-08-19 02:11:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/766457597109166081\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/umVqyNnUsT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMBGQjWYAAr1kU.jpg",
      "id_str" : "766457568617193472",
      "id" : 766457568617193472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMBGQjWYAAr1kU.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/umVqyNnUsT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766457597109166081",
  "text" : "Are Ghost Pepper wings even that spicy??? Lol https:\/\/t.co\/umVqyNnUsT",
  "id" : 766457597109166081,
  "created_at" : "2016-08-19 02:11:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/766202172413452288\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/e2BUCb53J5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqIY0HHXYAAOGlF.jpg",
      "id_str" : "766202170148610048",
      "id" : 766202170148610048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqIY0HHXYAAOGlF.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/e2BUCb53J5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766356911260311552",
  "text" : "RT @rockindigo: Gentlemen, I present to you : The women repeller. https:\/\/t.co\/e2BUCb53J5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/766202172413452288\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/e2BUCb53J5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqIY0HHXYAAOGlF.jpg",
        "id_str" : "766202170148610048",
        "id" : 766202170148610048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqIY0HHXYAAOGlF.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/e2BUCb53J5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766202172413452288",
    "text" : "Gentlemen, I present to you : The women repeller. https:\/\/t.co\/e2BUCb53J5",
    "id" : 766202172413452288,
    "created_at" : "2016-08-18 09:16:47 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 766356911260311552,
  "created_at" : "2016-08-18 19:31:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/766356705756184576\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/nKqicFkFLM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKlW9XXYAAFM0E.jpg",
      "id_str" : "766356700454674432",
      "id" : 766356700454674432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKlW9XXYAAFM0E.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/nKqicFkFLM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766356705756184576",
  "text" : "Had this Detroit drink!!! https:\/\/t.co\/nKqicFkFLM",
  "id" : 766356705756184576,
  "created_at" : "2016-08-18 19:30:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/765606585804742656\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/bg1IbAg5JW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp_7IJmXEAAEpdr.jpg",
      "id_str" : "765606579110612992",
      "id" : 765606579110612992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp_7IJmXEAAEpdr.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/bg1IbAg5JW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765606585804742656",
  "text" : "Tried Tokyo Sushi, 3.78\/5 stars, not the best but not bad https:\/\/t.co\/bg1IbAg5JW",
  "id" : 765606585804742656,
  "created_at" : "2016-08-16 17:50:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764299802624557056",
  "text" : "I am a sinner worse than many, my past shows darkness, through repentance and grace God have saved me from the very evils of myself.",
  "id" : 764299802624557056,
  "created_at" : "2016-08-13 03:17:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764299414525579264",
  "text" : "RT @Matthiasiam: Going to be changing up the Matthias channel a lot over the next month. Not happy with the content I'm making. I can do be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764230011880546304",
    "text" : "Going to be changing up the Matthias channel a lot over the next month. Not happy with the content I'm making. I can do better.",
    "id" : 764230011880546304,
    "created_at" : "2016-08-12 22:40:08 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 764299414525579264,
  "created_at" : "2016-08-13 03:15:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764299209050841088",
  "text" : "I used to be such a sinner and my past tells a story of dark times. We all have fell short and walked in darkness but God heals.",
  "id" : 764299209050841088,
  "created_at" : "2016-08-13 03:15:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beverlicious \uD83D\uDD25",
      "screen_name" : "blade_funner",
      "indices" : [ 3, 16 ],
      "id_str" : "174406574",
      "id" : 174406574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763935896479539200",
  "text" : "RT @blade_funner: Everytime spell check asks if I want add something to the dictionary, I say yes and now icsbtfjklfccvnnjkn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763894699551780864",
    "text" : "Everytime spell check asks if I want add something to the dictionary, I say yes and now icsbtfjklfccvnnjkn.",
    "id" : 763894699551780864,
    "created_at" : "2016-08-12 00:27:43 +0000",
    "user" : {
      "name" : "Beverlicious \uD83D\uDD25",
      "screen_name" : "blade_funner",
      "protected" : false,
      "id_str" : "174406574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885902962459017217\/XgrnRxxZ_normal.jpg",
      "id" : 174406574,
      "verified" : false
    }
  },
  "id" : 763935896479539200,
  "created_at" : "2016-08-12 03:11:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 3, 19 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/cAjUYHkbzc",
      "expanded_url" : "http:\/\/ow.ly\/3Vrf30398tL",
      "display_url" : "ow.ly\/3Vrf30398tL"
    } ]
  },
  "geo" : { },
  "id_str" : "763935577603387392",
  "text" : "RT @DataScienceCtrl: Supervised Learning - Comprehensive Tutorial (Python-based) https:\/\/t.co\/cAjUYHkbzc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/cAjUYHkbzc",
        "expanded_url" : "http:\/\/ow.ly\/3Vrf30398tL",
        "display_url" : "ow.ly\/3Vrf30398tL"
      } ]
    },
    "geo" : { },
    "id_str" : "763780807089586176",
    "text" : "Supervised Learning - Comprehensive Tutorial (Python-based) https:\/\/t.co\/cAjUYHkbzc",
    "id" : 763780807089586176,
    "created_at" : "2016-08-11 16:55:09 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "protected" : false,
      "id_str" : "393033324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989084699836416\/HLeb5i56_normal.jpg",
      "id" : 393033324,
      "verified" : false
    }
  },
  "id" : 763935577603387392,
  "created_at" : "2016-08-12 03:10:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 3, 19 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763935538445324288",
  "text" : "RT @DataScienceCtrl: Paxata Ecosystem Delivers Data-Lake-in-the-Cloud Solution Powered by AWS to Enable Faster Information Insights https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/z8IvNstJiM",
        "expanded_url" : "http:\/\/ow.ly\/hZqE30398sf",
        "display_url" : "ow.ly\/hZqE30398sf"
      } ]
    },
    "geo" : { },
    "id_str" : "763931787659575298",
    "text" : "Paxata Ecosystem Delivers Data-Lake-in-the-Cloud Solution Powered by AWS to Enable Faster Information Insights https:\/\/t.co\/z8IvNstJiM",
    "id" : 763931787659575298,
    "created_at" : "2016-08-12 02:55:06 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "protected" : false,
      "id_str" : "393033324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989084699836416\/HLeb5i56_normal.jpg",
      "id" : 393033324,
      "verified" : false
    }
  },
  "id" : 763935538445324288,
  "created_at" : "2016-08-12 03:10:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 13, 18 ]
    }, {
      "text" : "EXCEL",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/oPE2C4SS9x",
      "expanded_url" : "http:\/\/bit.ly\/1QqnUQP",
      "display_url" : "bit.ly\/1QqnUQP"
    } ]
  },
  "geo" : { },
  "id_str" : "763935372006993921",
  "text" : "Check out my #FREE #EXCEL Course https:\/\/t.co\/oPE2C4SS9x",
  "id" : 763935372006993921,
  "created_at" : "2016-08-12 03:09:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/2lv1eMG8fe",
      "expanded_url" : "http:\/\/klou.tt\/1xxpaoc1p412w",
      "display_url" : "klou.tt\/1xxpaoc1p412w"
    } ]
  },
  "geo" : { },
  "id_str" : "763935118247403521",
  "text" : "New compromises won't end the fight between LTE-U and Wi-Fi - https:\/\/t.co\/2lv1eMG8fe",
  "id" : 763935118247403521,
  "created_at" : "2016-08-12 03:08:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Ul90zENopO",
      "expanded_url" : "http:\/\/klou.tt\/1ckj5c8b2gd7z",
      "display_url" : "klou.tt\/1ckj5c8b2gd7z"
    } ]
  },
  "geo" : { },
  "id_str" : "763934866106781700",
  "text" : "Something's got to change at Tesla, analyst says - https:\/\/t.co\/Ul90zENopO",
  "id" : 763934866106781700,
  "created_at" : "2016-08-12 03:07:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/LO5POqxepn",
      "expanded_url" : "http:\/\/klou.tt\/mh68vvt8jqht",
      "display_url" : "klou.tt\/mh68vvt8jqht"
    } ]
  },
  "geo" : { },
  "id_str" : "763934824058933251",
  "text" : "Check Out Tesla's New San Francisco Store - https:\/\/t.co\/LO5POqxepn",
  "id" : 763934824058933251,
  "created_at" : "2016-08-12 03:07:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/UYiwN4djNZ",
      "expanded_url" : "http:\/\/klou.tt\/343x1fxqfsjv",
      "display_url" : "klou.tt\/343x1fxqfsjv"
    } ]
  },
  "geo" : { },
  "id_str" : "763934740051210241",
  "text" : "AMD turns back to x86 for server reboot as it downgrades ARM - https:\/\/t.co\/UYiwN4djNZ",
  "id" : 763934740051210241,
  "created_at" : "2016-08-12 03:06:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean May",
      "screen_name" : "BigMay42",
      "indices" : [ 3, 12 ],
      "id_str" : "32775428",
      "id" : 32775428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MichaelPhelps",
      "indices" : [ 52, 66 ]
    }, {
      "text" : "USA",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763933678888112128",
  "text" : "RT @BigMay42: Wow! That's all you can say is WOW!!! #MichaelPhelps #USA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MichaelPhelps",
        "indices" : [ 38, 52 ]
      }, {
        "text" : "USA",
        "indices" : [ 53, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763921069417779201",
    "text" : "Wow! That's all you can say is WOW!!! #MichaelPhelps #USA",
    "id" : 763921069417779201,
    "created_at" : "2016-08-12 02:12:30 +0000",
    "user" : {
      "name" : "Sean May",
      "screen_name" : "BigMay42",
      "protected" : false,
      "id_str" : "32775428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708926382538100736\/vME-6rKr_normal.jpg",
      "id" : 32775428,
      "verified" : true
    }
  },
  "id" : 763933678888112128,
  "created_at" : "2016-08-12 03:02:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sorority South",
      "screen_name" : "SororitySouth",
      "indices" : [ 3, 17 ],
      "id_str" : "48857252",
      "id" : 48857252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MichaelPhelps",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763933631442104320",
  "text" : "RT @SororitySouth: What a time. To be alive. #MichaelPhelps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MichaelPhelps",
        "indices" : [ 26, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763921554870644736",
    "text" : "What a time. To be alive. #MichaelPhelps",
    "id" : 763921554870644736,
    "created_at" : "2016-08-12 02:14:26 +0000",
    "user" : {
      "name" : "Sorority South",
      "screen_name" : "SororitySouth",
      "protected" : false,
      "id_str" : "48857252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/863485047181115399\/WCYcCmP0_normal.jpg",
      "id" : 48857252,
      "verified" : false
    }
  },
  "id" : 763933631442104320,
  "created_at" : "2016-08-12 03:02:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jenkins",
      "screen_name" : "sallyjenx",
      "indices" : [ 3, 13 ],
      "id_str" : "47622780",
      "id" : 47622780
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MichaelPhelps",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763933579973758976",
  "text" : "RT @sallyjenx: We\u2019re gonna need a bigger boat. #MichaelPhelps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MichaelPhelps",
        "indices" : [ 32, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763922018576142336",
    "text" : "We\u2019re gonna need a bigger boat. #MichaelPhelps",
    "id" : 763922018576142336,
    "created_at" : "2016-08-12 02:16:16 +0000",
    "user" : {
      "name" : "Sally Jenkins",
      "screen_name" : "sallyjenx",
      "protected" : false,
      "id_str" : "47622780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1448560837\/sjenkins.jpg.axd_normal.jpeg",
      "id" : 47622780,
      "verified" : true
    }
  },
  "id" : 763933579973758976,
  "created_at" : "2016-08-12 03:02:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MichaelPhelps",
      "indices" : [ 13, 27 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763933538517344257",
  "text" : "RT @FoxNews: #MichaelPhelps earns his 22nd Olympic gold medal, winning the 200-meter individual medley for the 4th time. #Rio2016 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/763923758096666624\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/EF9kpvkHXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpoAirTVMAEDDgX.jpg",
        "id_str" : "763923682532077569",
        "id" : 763923682532077569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpoAirTVMAEDDgX.jpg",
        "sizes" : [ {
          "h" : 460,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 855,
          "resize" : "fit",
          "w" : 1264
        }, {
          "h" : 812,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 855,
          "resize" : "fit",
          "w" : 1264
        } ],
        "display_url" : "pic.twitter.com\/EF9kpvkHXv"
      } ],
      "hashtags" : [ {
        "text" : "MichaelPhelps",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763923758096666624",
    "text" : "#MichaelPhelps earns his 22nd Olympic gold medal, winning the 200-meter individual medley for the 4th time. #Rio2016 https:\/\/t.co\/EF9kpvkHXv",
    "id" : 763923758096666624,
    "created_at" : "2016-08-12 02:23:11 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 763933538517344257,
  "created_at" : "2016-08-12 03:02:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763933042339524608",
  "text" : "RT @HitsBelowBelt: Just when I think I've lost all hope for humanity, someone goes and does something so selfless it brings a tear to my ey\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763874026099970049",
    "text" : "Just when I think I've lost all hope for humanity, someone goes and does something so selfless it brings a tear to my eye. Damn do gooders.",
    "id" : 763874026099970049,
    "created_at" : "2016-08-11 23:05:34 +0000",
    "user" : {
      "name" : "Ginga Snappa",
      "screen_name" : "GingaSnapppa",
      "protected" : false,
      "id_str" : "3959932041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655751500472393729\/AxTfMYwG_normal.jpg",
      "id" : 3959932041,
      "verified" : false
    }
  },
  "id" : 763933042339524608,
  "created_at" : "2016-08-12 03:00:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate \uD83E\uDD84",
      "screen_name" : "AlwaysJLover",
      "indices" : [ 3, 16 ],
      "id_str" : "962141971",
      "id" : 962141971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763932897610870784",
  "text" : "RT @AlwaysJLover: I'm still really shaken up about it that I'm still awake at 5:48am making typos in my tweets....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763930007009763328",
    "text" : "I'm still really shaken up about it that I'm still awake at 5:48am making typos in my tweets....",
    "id" : 763930007009763328,
    "created_at" : "2016-08-12 02:48:01 +0000",
    "user" : {
      "name" : "\uD835\uDCA6\uD835\uDCB6\uD835\uDCC9\uD835\uDC52",
      "screen_name" : "hereforparrilla",
      "protected" : false,
      "id_str" : "150060272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924022670919979011\/3DMa17an_normal.jpg",
      "id" : 150060272,
      "verified" : false
    }
  },
  "id" : 763932897610870784,
  "created_at" : "2016-08-12 02:59:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 44, 54 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/uVWSQrG2np",
      "expanded_url" : "http:\/\/bit.ly\/2aX9xox",
      "display_url" : "bit.ly\/2aX9xox"
    } ]
  },
  "geo" : { },
  "id_str" : "763932434832384000",
  "text" : "Get my list of 44 alternative app stores on @SEOClerks https:\/\/t.co\/uVWSQrG2np",
  "id" : 763932434832384000,
  "created_at" : "2016-08-12 02:57:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Innovate",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "IT",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/oPE2C4SS9x",
      "expanded_url" : "http:\/\/bit.ly\/1QqnUQP",
      "display_url" : "bit.ly\/1QqnUQP"
    } ]
  },
  "geo" : { },
  "id_str" : "763931405583659009",
  "text" : "Check my free MS Excel course #Innovate https:\/\/t.co\/oPE2C4SS9x #IT",
  "id" : 763931405583659009,
  "created_at" : "2016-08-12 02:53:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "indices" : [ 3, 14 ],
      "id_str" : "386316230",
      "id" : 386316230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/BUIJtFFaIb",
      "expanded_url" : "http:\/\/bit.ly\/2bk7Qkj",
      "display_url" : "bit.ly\/2bk7Qkj"
    } ]
  },
  "geo" : { },
  "id_str" : "763931244421799937",
  "text" : "RT @Tearieeror: Dragan Djukanovic Waspadai Kebangkitan PS TNI https:\/\/t.co\/BUIJtFFaIb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/BUIJtFFaIb",
        "expanded_url" : "http:\/\/bit.ly\/2bk7Qkj",
        "display_url" : "bit.ly\/2bk7Qkj"
      } ]
    },
    "geo" : { },
    "id_str" : "763931101630824448",
    "text" : "Dragan Djukanovic Waspadai Kebangkitan PS TNI https:\/\/t.co\/BUIJtFFaIb",
    "id" : 763931101630824448,
    "created_at" : "2016-08-12 02:52:22 +0000",
    "user" : {
      "name" : "Syahriel Apriyanto Z",
      "screen_name" : "Tearieeror",
      "protected" : false,
      "id_str" : "386316230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3041526706\/e073537c1dd0892e4bd637a97216ac2e_normal.png",
      "id" : 386316230,
      "verified" : false
    }
  },
  "id" : 763931244421799937,
  "created_at" : "2016-08-12 02:52:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynzee \u0950 Vision",
      "screen_name" : "LynzeeBewcyk",
      "indices" : [ 3, 16 ],
      "id_str" : "227502600",
      "id" : 227502600
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LynzeeBewcyk\/status\/763930492915757057\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Mm8uI4HnOS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpoGq__VMAAVdHp.jpg",
      "id_str" : "763930422594056192",
      "id" : 763930422594056192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpoGq__VMAAVdHp.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/Mm8uI4HnOS"
    } ],
    "hashtags" : [ {
      "text" : "hike",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "glacier",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "canada",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "EnergyLivesHere",
      "indices" : [ 75, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763930953945260032",
  "text" : "RT @LynzeeBewcyk: Blissed out from my hike today. \uD83C\uDF43 #hike #glacier #canada #EnergyLivesHere https:\/\/t.co\/Mm8uI4HnOS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LynzeeBewcyk\/status\/763930492915757057\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/Mm8uI4HnOS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpoGq__VMAAVdHp.jpg",
        "id_str" : "763930422594056192",
        "id" : 763930422594056192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpoGq__VMAAVdHp.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/Mm8uI4HnOS"
      } ],
      "hashtags" : [ {
        "text" : "hike",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "glacier",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "canada",
        "indices" : [ 49, 56 ]
      }, {
        "text" : "EnergyLivesHere",
        "indices" : [ 57, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763930492915757057",
    "text" : "Blissed out from my hike today. \uD83C\uDF43 #hike #glacier #canada #EnergyLivesHere https:\/\/t.co\/Mm8uI4HnOS",
    "id" : 763930492915757057,
    "created_at" : "2016-08-12 02:49:57 +0000",
    "user" : {
      "name" : "Lynzee \u0950 Vision",
      "screen_name" : "LynzeeBewcyk",
      "protected" : false,
      "id_str" : "227502600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1561939040\/76540_730937919111_172006110_42508618_7651433_n_normal.jpg",
      "id" : 227502600,
      "verified" : false
    }
  },
  "id" : 763930953945260032,
  "created_at" : "2016-08-12 02:51:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renew Oregon",
      "screen_name" : "RenewOregon",
      "indices" : [ 3, 15 ],
      "id_str" : "2835498119",
      "id" : 2835498119
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RenewOregon\/status\/763854523584557057\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/hhCAdxhS9w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpnBlYOVIAAWhIr.jpg",
      "id_str" : "763854459717885952",
      "id" : 763854459717885952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpnBlYOVIAAWhIr.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/hhCAdxhS9w"
    } ],
    "hashtags" : [ {
      "text" : "EnergyLivesHere",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763930763389603840",
  "text" : "RT @RenewOregon: Mayflower folks know too well how #EnergyLivesHere and they probably wish it didn\u2019t. https:\/\/t.co\/hhCAdxhS9w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RenewOregon\/status\/763854523584557057\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/hhCAdxhS9w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpnBlYOVIAAWhIr.jpg",
        "id_str" : "763854459717885952",
        "id" : 763854459717885952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpnBlYOVIAAWhIr.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/hhCAdxhS9w"
      } ],
      "hashtags" : [ {
        "text" : "EnergyLivesHere",
        "indices" : [ 34, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763854523584557057",
    "text" : "Mayflower folks know too well how #EnergyLivesHere and they probably wish it didn\u2019t. https:\/\/t.co\/hhCAdxhS9w",
    "id" : 763854523584557057,
    "created_at" : "2016-08-11 21:48:04 +0000",
    "user" : {
      "name" : "Renew Oregon",
      "screen_name" : "RenewOregon",
      "protected" : false,
      "id_str" : "2835498119",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875463036068274177\/ydm4i0O6_normal.jpg",
      "id" : 2835498119,
      "verified" : false
    }
  },
  "id" : 763930763389603840,
  "created_at" : "2016-08-12 02:51:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tylerlindell",
      "screen_name" : "Tylerlindell",
      "indices" : [ 3, 16 ],
      "id_str" : "18483608",
      "id" : 18483608
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Tylerlindell\/status\/762994849788338176\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Yl5VlhZJ3M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpazxW7WgAAQn6K.jpg",
      "id_str" : "762994847435358208",
      "id" : 762994847435358208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpazxW7WgAAQn6K.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      } ],
      "display_url" : "pic.twitter.com\/Yl5VlhZJ3M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Tsep0dVA2v",
      "expanded_url" : "http:\/\/buff.ly\/2aVxtaG",
      "display_url" : "buff.ly\/2aVxtaG"
    } ]
  },
  "geo" : { },
  "id_str" : "763930483495272448",
  "text" : "RT @Tylerlindell: 5 Tech Predictions for 2017 https:\/\/t.co\/Tsep0dVA2v https:\/\/t.co\/Yl5VlhZJ3M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Tylerlindell\/status\/762994849788338176\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/Yl5VlhZJ3M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpazxW7WgAAQn6K.jpg",
        "id_str" : "762994847435358208",
        "id" : 762994847435358208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpazxW7WgAAQn6K.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        } ],
        "display_url" : "pic.twitter.com\/Yl5VlhZJ3M"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/Tsep0dVA2v",
        "expanded_url" : "http:\/\/buff.ly\/2aVxtaG",
        "display_url" : "buff.ly\/2aVxtaG"
      } ]
    },
    "geo" : { },
    "id_str" : "762994849788338176",
    "text" : "5 Tech Predictions for 2017 https:\/\/t.co\/Tsep0dVA2v https:\/\/t.co\/Yl5VlhZJ3M",
    "id" : 762994849788338176,
    "created_at" : "2016-08-09 12:52:02 +0000",
    "user" : {
      "name" : "Tylerlindell",
      "screen_name" : "Tylerlindell",
      "protected" : false,
      "id_str" : "18483608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732355849381777409\/k7gLxe5p_normal.jpg",
      "id" : 18483608,
      "verified" : false
    }
  },
  "id" : 763930483495272448,
  "created_at" : "2016-08-12 02:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Jeanine Pirro",
      "screen_name" : "JudgeJeanine",
      "indices" : [ 18, 31 ],
      "id_str" : "29458079",
      "id" : 29458079
    }, {
      "name" : "Clinton Foundation",
      "screen_name" : "ClintonFdn",
      "indices" : [ 65, 76 ],
      "id_str" : "75069067",
      "id" : 75069067
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 94, 104 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763930260152868865",
  "text" : "RT @seanhannity: .@JudgeJeanine: \"You get 12,000 emails from the @ClintonFdn to the [Clinton] @StateDept \u2013 there should be no emails from F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeanine Pirro",
        "screen_name" : "JudgeJeanine",
        "indices" : [ 1, 14 ],
        "id_str" : "29458079",
        "id" : 29458079
      }, {
        "name" : "Clinton Foundation",
        "screen_name" : "ClintonFdn",
        "indices" : [ 48, 59 ],
        "id_str" : "75069067",
        "id" : 75069067
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 77, 87 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763929005728804866",
    "text" : ".@JudgeJeanine: \"You get 12,000 emails from the @ClintonFdn to the [Clinton] @StateDept \u2013 there should be no emails from Fdn. to State Dept\"",
    "id" : 763929005728804866,
    "created_at" : "2016-08-12 02:44:02 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 763930260152868865,
  "created_at" : "2016-08-12 02:49:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/763929962701172737\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/RcTSxenwu0",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpoGOvVVMAEtW6r.jpg",
      "id_str" : "763929937086590977",
      "id" : 763929937086590977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpoGOvVVMAEtW6r.jpg",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/RcTSxenwu0"
    } ],
    "hashtags" : [ {
      "text" : "Excel",
      "indices" : [ 5, 11 ]
    }, {
      "text" : "Learn",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/oPE2C4SS9x",
      "expanded_url" : "http:\/\/bit.ly\/1QqnUQP",
      "display_url" : "bit.ly\/1QqnUQP"
    } ]
  },
  "geo" : { },
  "id_str" : "763929962701172737",
  "text" : "Free #Excel course #Learn https:\/\/t.co\/oPE2C4SS9x https:\/\/t.co\/RcTSxenwu0",
  "id" : 763929962701172737,
  "created_at" : "2016-08-12 02:47:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rashad Houston",
      "screen_name" : "RashadHouston",
      "indices" : [ 3, 17 ],
      "id_str" : "18573674",
      "id" : 18573674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763929484567261185",
  "text" : "RT @RashadHouston: Who said we can't swim? #Gold",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763928732100812800",
    "text" : "Who said we can't swim? #Gold",
    "id" : 763928732100812800,
    "created_at" : "2016-08-12 02:42:57 +0000",
    "user" : {
      "name" : "Rashad Houston",
      "screen_name" : "RashadHouston",
      "protected" : false,
      "id_str" : "18573674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924438817901367296\/UTPuv0rQ_normal.jpg",
      "id" : 18573674,
      "verified" : false
    }
  },
  "id" : 763929484567261185,
  "created_at" : "2016-08-12 02:45:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SomaliStrong\uD83C\uDDF8\uD83C\uDDF4",
      "screen_name" : "xxsweetsamiixx",
      "indices" : [ 3, 18 ],
      "id_str" : "36204319",
      "id" : 36204319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763929298499620864",
  "text" : "RT @XxSweetSamiixX: All I want is some chick fil a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763913425697157121",
    "text" : "All I want is some chick fil a",
    "id" : 763913425697157121,
    "created_at" : "2016-08-12 01:42:08 +0000",
    "user" : {
      "name" : "SomaliStrong\uD83C\uDDF8\uD83C\uDDF4",
      "screen_name" : "xxsweetsamiixx",
      "protected" : false,
      "id_str" : "36204319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909883684878155778\/VEkYS1Z7_normal.jpg",
      "id" : 36204319,
      "verified" : false
    }
  },
  "id" : 763929298499620864,
  "created_at" : "2016-08-12 02:45:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 18, 27 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763929069876416513",
  "text" : "RT @georgiev_dan: @MarkDice The haters are triggered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 0, 9 ],
        "id_str" : "35039490",
        "id" : 35039490
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "763638775142416384",
    "geo" : { },
    "id_str" : "763642201947668480",
    "in_reply_to_user_id" : 35039490,
    "text" : "@MarkDice The haters are triggered",
    "id" : 763642201947668480,
    "in_reply_to_status_id" : 763638775142416384,
    "created_at" : "2016-08-11 07:44:23 +0000",
    "in_reply_to_screen_name" : "MarkDice",
    "in_reply_to_user_id_str" : "35039490",
    "user" : {
      "name" : "H3at",
      "screen_name" : "Lacedskiez",
      "protected" : false,
      "id_str" : "792013898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883154643307687937\/LNt0f0fS_normal.jpg",
      "id" : 792013898,
      "verified" : false
    }
  },
  "id" : 763929069876416513,
  "created_at" : "2016-08-12 02:44:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763928863789371398",
  "text" : "RT @MarkDice: Fun fact:  Hillary's senior aid is Anthony Weiner's (pretend) wife!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763853089694593024",
    "text" : "Fun fact:  Hillary's senior aid is Anthony Weiner's (pretend) wife!",
    "id" : 763853089694593024,
    "created_at" : "2016-08-11 21:42:22 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 763928863789371398,
  "created_at" : "2016-08-12 02:43:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763928737591140354",
  "text" : "RT @scrowder: Just added to tonight's #LwC line-up. The official \"Olympics Social Relations Czar\". 8PM ET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 24, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763869689126744064",
    "text" : "Just added to tonight's #LwC line-up. The official \"Olympics Social Relations Czar\". 8PM ET.",
    "id" : 763869689126744064,
    "created_at" : "2016-08-11 22:48:20 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 763928737591140354,
  "created_at" : "2016-08-12 02:42:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/BKyGrr8Hfi",
      "expanded_url" : "http:\/\/bit.ly\/2bbQ9pE",
      "display_url" : "bit.ly\/2bbQ9pE"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/v43hguO8X1",
      "expanded_url" : "http:\/\/edustudio.org",
      "display_url" : "edustudio.org"
    } ]
  },
  "geo" : { },
  "id_str" : "763928392320241664",
  "text" : "Check out my Udemy courses https:\/\/t.co\/BKyGrr8Hfi or go to https:\/\/t.co\/v43hguO8X1 to view more of my courses!!!",
  "id" : 763928392320241664,
  "created_at" : "2016-08-12 02:41:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763927607079342080",
  "text" : "RT @scrowder: That's a wrap! Podcast\/videocast up tomorrow. See you next week. #LwC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 65, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763926260460326913",
    "text" : "That's a wrap! Podcast\/videocast up tomorrow. See you next week. #LwC",
    "id" : 763926260460326913,
    "created_at" : "2016-08-12 02:33:08 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 763927607079342080,
  "created_at" : "2016-08-12 02:38:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763927566528843778",
  "text" : "RT @andikhm01: Classical Music Listings for Aug. 12-18 - New York Times: Classical Music Listings for Aug. 12-18New York Tim... https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/QOcCr2vPK3",
        "expanded_url" : "http:\/\/adf.ly\/1d6Mzl",
        "display_url" : "adf.ly\/1d6Mzl"
      } ]
    },
    "geo" : { },
    "id_str" : "763926354689536001",
    "text" : "Classical Music Listings for Aug. 12-18 - New York Times: Classical Music Listings for Aug. 12-18New York Tim... https:\/\/t.co\/QOcCr2vPK3",
    "id" : 763926354689536001,
    "created_at" : "2016-08-12 02:33:30 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 763927566528843778,
  "created_at" : "2016-08-12 02:38:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Monica Crowley",
      "screen_name" : "MonicaCrowley",
      "indices" : [ 18, 32 ],
      "id_str" : "166990746",
      "id" : 166990746
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 36, 51 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763927536258588674",
  "text" : "RT @seanhannity: .@MonicaCrowley: \"[@HillaryClinton] tells the world one thing &amp; then she does something completely different.\" #Hannity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Crowley",
        "screen_name" : "MonicaCrowley",
        "indices" : [ 1, 15 ],
        "id_str" : "166990746",
        "id" : 166990746
      }, {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 19, 34 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763926507949465600",
    "text" : ".@MonicaCrowley: \"[@HillaryClinton] tells the world one thing &amp; then she does something completely different.\" #Hannity",
    "id" : 763926507949465600,
    "created_at" : "2016-08-12 02:34:07 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 763927536258588674,
  "created_at" : "2016-08-12 02:38:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/GlkJn1phdg",
      "expanded_url" : "http:\/\/bit.ly\/2ba22LC",
      "display_url" : "bit.ly\/2ba22LC"
    } ]
  },
  "geo" : { },
  "id_str" : "763927450447323137",
  "text" : "Buy a logo or trailer design starting at $3 (Ignore Bitly warning) https:\/\/t.co\/GlkJn1phdg",
  "id" : 763927450447323137,
  "created_at" : "2016-08-12 02:37:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEOClerks",
      "screen_name" : "SEOClerks",
      "indices" : [ 34, 44 ],
      "id_str" : "386131152",
      "id" : 386131152
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/763926608814059520\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/6aqCX50DbG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpoDMfTUEAABX9P.jpg",
      "id_str" : "763926599888539648",
      "id" : 763926599888539648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpoDMfTUEAABX9P.jpg",
      "sizes" : [ {
        "h" : 976,
        "resize" : "fit",
        "w" : 1790
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 1790
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/6aqCX50DbG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/PCZNALvn5X",
      "expanded_url" : "http:\/\/a.seoclerks.com\/linkin\/13663",
      "display_url" : "a.seoclerks.com\/linkin\/13663"
    } ]
  },
  "geo" : { },
  "id_str" : "763926608814059520",
  "text" : "Buy SEO or SMM marketing services @SEOClerks https:\/\/t.co\/PCZNALvn5X https:\/\/t.co\/6aqCX50DbG",
  "id" : 763926608814059520,
  "created_at" : "2016-08-12 02:34:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNBC Now",
      "screen_name" : "CNBCnow",
      "indices" : [ 3, 11 ],
      "id_str" : "26574283",
      "id" : 26574283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763926505562906625",
  "text" : "RT @CNBCnow: BREAKING: Michael Phelps, the most decorated Olympic athlete ever, wins 22nd gold medal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763920898483036162",
    "text" : "BREAKING: Michael Phelps, the most decorated Olympic athlete ever, wins 22nd gold medal.",
    "id" : 763920898483036162,
    "created_at" : "2016-08-12 02:11:49 +0000",
    "user" : {
      "name" : "CNBC Now",
      "screen_name" : "CNBCnow",
      "protected" : false,
      "id_str" : "26574283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875401961142603776\/iTe8JObK_normal.jpg",
      "id" : 26574283,
      "verified" : true
    }
  },
  "id" : 763926505562906625,
  "created_at" : "2016-08-12 02:34:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/763812383907274753\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CQXt1EzhT9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpmbUF-XgAARznA.jpg",
      "id_str" : "763812381319462912",
      "id" : 763812381319462912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpmbUF-XgAARznA.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CQXt1EzhT9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/3c5l8VJC47",
      "expanded_url" : "http:\/\/engt.co\/2b8RpGb",
      "display_url" : "engt.co\/2b8RpGb"
    } ]
  },
  "geo" : { },
  "id_str" : "763866967916834816",
  "text" : "RT @engadget: Simit is a new language for more efficient programming https:\/\/t.co\/3c5l8VJC47 https:\/\/t.co\/CQXt1EzhT9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/763812383907274753\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/CQXt1EzhT9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpmbUF-XgAARznA.jpg",
        "id_str" : "763812381319462912",
        "id" : 763812381319462912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpmbUF-XgAARznA.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CQXt1EzhT9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/3c5l8VJC47",
        "expanded_url" : "http:\/\/engt.co\/2b8RpGb",
        "display_url" : "engt.co\/2b8RpGb"
      } ]
    },
    "geo" : { },
    "id_str" : "763812383907274753",
    "text" : "Simit is a new language for more efficient programming https:\/\/t.co\/3c5l8VJC47 https:\/\/t.co\/CQXt1EzhT9",
    "id" : 763812383907274753,
    "created_at" : "2016-08-11 19:00:37 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 763866967916834816,
  "created_at" : "2016-08-11 22:37:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/763866838417674241\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/mMM61uteMk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpnM1aKXgAAZTlV.jpg",
      "id_str" : "763866829743947776",
      "id" : 763866829743947776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpnM1aKXgAAZTlV.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/mMM61uteMk"
    } ],
    "hashtags" : [ {
      "text" : "falafel",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763866838417674241",
  "text" : "Having a sandwich @ Mediterranean Market #falafel https:\/\/t.co\/mMM61uteMk",
  "id" : 763866838417674241,
  "created_at" : "2016-08-11 22:37:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763809219976032256",
  "text" : "Had Mamba fruit chews, not my favorite candy. 3.4\/5 stars",
  "id" : 763809219976032256,
  "created_at" : "2016-08-11 18:48:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763159382817374209",
  "text" : "RT @hannahbleau_: Why do liberals assume that 2nd Amendment people are violent? There are more guns than ppl here. If we were unhinged, you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763120774727213056",
    "text" : "Why do liberals assume that 2nd Amendment people are violent? There are more guns than ppl here. If we were unhinged, you'd know about it.",
    "id" : 763120774727213056,
    "created_at" : "2016-08-09 21:12:25 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 763159382817374209,
  "created_at" : "2016-08-09 23:45:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bruce redden",
      "screen_name" : "brucereddenjr",
      "indices" : [ 3, 17 ],
      "id_str" : "480000010",
      "id" : 480000010
    }, {
      "name" : "Fort Bliss",
      "screen_name" : "armybliss",
      "indices" : [ 41, 51 ],
      "id_str" : "245425073",
      "id" : 245425073
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 55, 63 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GodBlessOurTroops",
      "indices" : [ 103, 121 ]
    }, {
      "text" : "thankful",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763159335233028096",
  "text" : "RT @brucereddenjr: It was great to visit @armybliss w\/ @tedcruz honored to see these soldiers training #GodBlessOurTroops #thankful https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fort Bliss",
        "screen_name" : "armybliss",
        "indices" : [ 22, 32 ],
        "id_str" : "245425073",
        "id" : 245425073
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 36, 44 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brucereddenjr\/status\/763122467925655552\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/9MG1e9OmLm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpcn1D4UEAAh_X0.jpg",
        "id_str" : "763122454390640640",
        "id" : 763122454390640640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpcn1D4UEAAh_X0.jpg",
        "sizes" : [ {
          "h" : 1117,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1117,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/9MG1e9OmLm"
      } ],
      "hashtags" : [ {
        "text" : "GodBlessOurTroops",
        "indices" : [ 84, 102 ]
      }, {
        "text" : "thankful",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763122467925655552",
    "text" : "It was great to visit @armybliss w\/ @tedcruz honored to see these soldiers training #GodBlessOurTroops #thankful https:\/\/t.co\/9MG1e9OmLm",
    "id" : 763122467925655552,
    "created_at" : "2016-08-09 21:19:09 +0000",
    "user" : {
      "name" : "bruce redden",
      "screen_name" : "brucereddenjr",
      "protected" : false,
      "id_str" : "480000010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727853913223790592\/Mum45xNo_normal.jpg",
      "id" : 480000010,
      "verified" : false
    }
  },
  "id" : 763159335233028096,
  "created_at" : "2016-08-09 23:45:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/PCZNALdMep",
      "expanded_url" : "http:\/\/a.seoclerks.com\/linkin\/13663",
      "display_url" : "a.seoclerks.com\/linkin\/13663"
    } ]
  },
  "geo" : { },
  "id_str" : "763159218144866304",
  "text" : "Buy cheap affiliate marketing: https:\/\/t.co\/PCZNALdMep",
  "id" : 763159218144866304,
  "created_at" : "2016-08-09 23:45:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "indices" : [ 3, 15 ],
      "id_str" : "396086694",
      "id" : 396086694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762344299560337408",
  "text" : "RT @ItsLifeFact: No matter how good or bad your life is, wake up each morning and be thankful that you still have one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762338770666553344",
    "text" : "No matter how good or bad your life is, wake up each morning and be thankful that you still have one.",
    "id" : 762338770666553344,
    "created_at" : "2016-08-07 17:25:01 +0000",
    "user" : {
      "name" : "LIFE QUOTES",
      "screen_name" : "ItsLifeFact",
      "protected" : false,
      "id_str" : "396086694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739928180492886016\/syZrDxAM_normal.jpg",
      "id" : 396086694,
      "verified" : false
    }
  },
  "id" : 762344299560337408,
  "created_at" : "2016-08-07 17:46:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/hxGAYqLtaa",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BI0PfhVA0Dy\/",
      "display_url" : "instagram.com\/p\/BI0PfhVA0Dy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "762344225904222208",
  "text" : "RT @Matthiasiam: Not sure how something this cute can exist. https:\/\/t.co\/hxGAYqLtaa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/hxGAYqLtaa",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BI0PfhVA0Dy\/",
        "display_url" : "instagram.com\/p\/BI0PfhVA0Dy\/"
      } ]
    },
    "geo" : { },
    "id_str" : "762343371000209409",
    "text" : "Not sure how something this cute can exist. https:\/\/t.co\/hxGAYqLtaa",
    "id" : 762343371000209409,
    "created_at" : "2016-08-07 17:43:17 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 762344225904222208,
  "created_at" : "2016-08-07 17:46:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All American Me\uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "scott_towel",
      "indices" : [ 3, 15 ],
      "id_str" : "428194463",
      "id" : 428194463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762344103916994560",
  "text" : "RT @scott_towel: It's like dogs don't even understand the sanctity of sleep-in Sunday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762292975351148544",
    "text" : "It's like dogs don't even understand the sanctity of sleep-in Sunday.",
    "id" : 762292975351148544,
    "created_at" : "2016-08-07 14:23:02 +0000",
    "user" : {
      "name" : "All American Me\uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "scott_towel",
      "protected" : false,
      "id_str" : "428194463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803947835930660864\/VwjSpVH6_normal.jpg",
      "id" : 428194463,
      "verified" : false
    }
  },
  "id" : 762344103916994560,
  "created_at" : "2016-08-07 17:46:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762343166263656449",
  "text" : "RT @BarbaraCorcoran: Entrepreneurs are right-brainers, they often dream better than they write business plans.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762318702188584960",
    "text" : "Entrepreneurs are right-brainers, they often dream better than they write business plans.",
    "id" : 762318702188584960,
    "created_at" : "2016-08-07 16:05:16 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 762343166263656449,
  "created_at" : "2016-08-07 17:42:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/762343137893294081\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/8GZSlEcaxo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpRjCRhUEAAEZQV.jpg",
      "id_str" : "762343127646474240",
      "id" : 762343127646474240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpRjCRhUEAAEZQV.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8GZSlEcaxo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762343137893294081",
  "text" : "Had some wings today!!! https:\/\/t.co\/8GZSlEcaxo",
  "id" : 762343137893294081,
  "created_at" : "2016-08-07 17:42:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762215070919172096",
  "text" : "RT @BONNIELYNN2015: Been a journey \uD83C\uDF40\uD83C\uDF40\uD83C\uDF40\uD83C\uDF40",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762153248891346944",
    "text" : "Been a journey \uD83C\uDF40\uD83C\uDF40\uD83C\uDF40\uD83C\uDF40",
    "id" : 762153248891346944,
    "created_at" : "2016-08-07 05:07:49 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927433831929413632\/duExUEVU_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 762215070919172096,
  "created_at" : "2016-08-07 09:13:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L\u03B9z \u0181\u2113\u03B1\u2202\u0454\uE32E\uE32E\uE32E \u0F3A\u2022\u0F3B",
      "screen_name" : "Moondance_81",
      "indices" : [ 3, 16 ],
      "id_str" : "249099666",
      "id" : 249099666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Moondance_81\/status\/761057452301312000\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ku31XNbAy4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Co_RprSUsAAr_81.jpg",
      "id_str" : "761057375973322752",
      "id" : 761057375973322752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Co_RprSUsAAr_81.jpg",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ku31XNbAy4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762214651560075264",
  "text" : "RT @Moondance_81: Clint Eastwood https:\/\/t.co\/ku31XNbAy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Moondance_81\/status\/761057452301312000\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/ku31XNbAy4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Co_RprSUsAAr_81.jpg",
        "id_str" : "761057375973322752",
        "id" : 761057375973322752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Co_RprSUsAAr_81.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 498
        } ],
        "display_url" : "pic.twitter.com\/ku31XNbAy4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761057452301312000",
    "text" : "Clint Eastwood https:\/\/t.co\/ku31XNbAy4",
    "id" : 761057452301312000,
    "created_at" : "2016-08-04 04:33:31 +0000",
    "user" : {
      "name" : "L\u03B9z \u0181\u2113\u03B1\u2202\u0454\uE32E\uE32E\uE32E \u0F3A\u2022\u0F3B",
      "screen_name" : "Moondance_81",
      "protected" : false,
      "id_str" : "249099666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927563999503200257\/UdIrOZYh_normal.jpg",
      "id" : 249099666,
      "verified" : false
    }
  },
  "id" : 762214651560075264,
  "created_at" : "2016-08-07 09:11:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "indices" : [ 3, 10 ],
      "id_str" : "558797310",
      "id" : 558797310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/762211337023913984\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/r1DWVn71lK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPq_grWYAAgDgF.jpg",
      "id_str" : "762211138780160000",
      "id" : 762211138780160000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPq_grWYAAgDgF.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/r1DWVn71lK"
    } ],
    "hashtags" : [ {
      "text" : "UNITED",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762214316338733056",
  "text" : "RT @ManUtd: Ready. #UNITED https:\/\/t.co\/r1DWVn71lK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ManUtd\/status\/762211337023913984\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/r1DWVn71lK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPq_grWYAAgDgF.jpg",
        "id_str" : "762211138780160000",
        "id" : 762211138780160000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPq_grWYAAgDgF.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/r1DWVn71lK"
      } ],
      "hashtags" : [ {
        "text" : "UNITED",
        "indices" : [ 7, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762211337023913984",
    "text" : "Ready. #UNITED https:\/\/t.co\/r1DWVn71lK",
    "id" : 762211337023913984,
    "created_at" : "2016-08-07 08:58:38 +0000",
    "user" : {
      "name" : "Manchester United",
      "screen_name" : "ManUtd",
      "protected" : false,
      "id_str" : "558797310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926389086792937474\/BS7mkHaK_normal.jpg",
      "id" : 558797310,
      "verified" : true
    }
  },
  "id" : 762214316338733056,
  "created_at" : "2016-08-07 09:10:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762212231304142848",
  "text" : "RT @martincallan: Rio Olympics 2016: Adam Peaty sets world record in 100m breaststroke heats: Great Britain's Adam Peaty sets a... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/jddvCWHub2",
        "expanded_url" : "http:\/\/bbc.in\/2aJJKgB",
        "display_url" : "bbc.in\/2aJJKgB"
      } ]
    },
    "geo" : { },
    "id_str" : "762017140035637248",
    "text" : "Rio Olympics 2016: Adam Peaty sets world record in 100m breaststroke heats: Great Britain's Adam Peaty sets a... https:\/\/t.co\/jddvCWHub2",
    "id" : 762017140035637248,
    "created_at" : "2016-08-06 20:06:58 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 762212231304142848,
  "created_at" : "2016-08-07 09:02:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "indices" : [ 3, 19 ],
      "id_str" : "18992010",
      "id" : 18992010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/vm3m5YFIQS",
      "expanded_url" : "http:\/\/www.thinkadvisor.com\/2014\/08\/25\/investor-behavior-by-the-book?t=the-client&page_all=1",
      "display_url" : "thinkadvisor.com\/2014\/08\/25\/inv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762212207492988928",
  "text" : "RT @victorricciardi: ThinkAdvisor BOOK REVIEW of Investor Behavior by Kent Baker and Victor Ricciardi\nhttps:\/\/t.co\/vm3m5YFIQS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/vm3m5YFIQS",
        "expanded_url" : "http:\/\/www.thinkadvisor.com\/2014\/08\/25\/investor-behavior-by-the-book?t=the-client&page_all=1",
        "display_url" : "thinkadvisor.com\/2014\/08\/25\/inv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762017509927190532",
    "text" : "ThinkAdvisor BOOK REVIEW of Investor Behavior by Kent Baker and Victor Ricciardi\nhttps:\/\/t.co\/vm3m5YFIQS",
    "id" : 762017509927190532,
    "created_at" : "2016-08-06 20:08:26 +0000",
    "user" : {
      "name" : "Behavioral Finance",
      "screen_name" : "victorricciardi",
      "protected" : false,
      "id_str" : "18992010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566693508296085504\/-v5kzmcw_normal.jpeg",
      "id" : 18992010,
      "verified" : false
    }
  },
  "id" : 762212207492988928,
  "created_at" : "2016-08-07 09:02:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762018587255111681\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/LEo92N1ibF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpM73YqWIAApTSd.jpg",
      "id_str" : "762018584654651392",
      "id" : 762018584654651392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpM73YqWIAApTSd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/LEo92N1ibF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762212089096273924",
  "text" : "RT @rockindigo: Too many languages in Europe https:\/\/t.co\/LEo92N1ibF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762018587255111681\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/LEo92N1ibF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpM73YqWIAApTSd.jpg",
        "id_str" : "762018584654651392",
        "id" : 762018584654651392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpM73YqWIAApTSd.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/LEo92N1ibF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762018587255111681",
    "text" : "Too many languages in Europe https:\/\/t.co\/LEo92N1ibF",
    "id" : 762018587255111681,
    "created_at" : "2016-08-06 20:12:43 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 762212089096273924,
  "created_at" : "2016-08-07 09:01:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy | Photos",
      "screen_name" : "Randallr75",
      "indices" : [ 3, 14 ],
      "id_str" : "166362490",
      "id" : 166362490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Randallr75\/status\/762211272159010816\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/5qQAv3IYYG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPrHGeW8AUGPnn.jpg",
      "id_str" : "762211269185302533",
      "id" : 762211269185302533,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPrHGeW8AUGPnn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/5qQAv3IYYG"
    } ],
    "hashtags" : [ {
      "text" : "Photography",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "PhotoOfTheDay",
      "indices" : [ 55, 69 ]
    }, {
      "text" : "Travel",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "Photo",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211968979730435",
  "text" : "RT @Randallr75: #Photography | \"Random placement...\" | #PhotoOfTheDay #Travel #Photo https:\/\/t.co\/5qQAv3IYYG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Randallr75\/status\/762211272159010816\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/5qQAv3IYYG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPrHGeW8AUGPnn.jpg",
        "id_str" : "762211269185302533",
        "id" : 762211269185302533,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPrHGeW8AUGPnn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/5qQAv3IYYG"
      } ],
      "hashtags" : [ {
        "text" : "Photography",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "PhotoOfTheDay",
        "indices" : [ 39, 53 ]
      }, {
        "text" : "Travel",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "Photo",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762211272159010816",
    "text" : "#Photography | \"Random placement...\" | #PhotoOfTheDay #Travel #Photo https:\/\/t.co\/5qQAv3IYYG",
    "id" : 762211272159010816,
    "created_at" : "2016-08-07 08:58:23 +0000",
    "user" : {
      "name" : "Randy | Photos",
      "screen_name" : "Randallr75",
      "protected" : false,
      "id_str" : "166362490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466600551434567680\/eykvk6bv_normal.png",
      "id" : 166362490,
      "verified" : false
    }
  },
  "id" : 762211968979730435,
  "created_at" : "2016-08-07 09:01:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wehnke 'Cuzzy' Botha",
      "screen_name" : "XBearer_ZA",
      "indices" : [ 3, 14 ],
      "id_str" : "101684460",
      "id" : 101684460
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/XBearer_ZA\/status\/762211314588614657\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/EFLwow8nnF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPrJoQWcAAj-qX.jpg",
      "id_str" : "762211312613093376",
      "id" : 762211312613093376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPrJoQWcAAj-qX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/EFLwow8nnF"
    } ],
    "hashtags" : [ {
      "text" : "500px",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "Photography",
      "indices" : [ 50, 62 ]
    }, {
      "text" : "Photo",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211924700434432",
  "text" : "RT @XBearer_ZA: Popular on #500px : Paragon Hotel #Photography #Photo https:\/\/t.co\/EFLwow8nnF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/XBearer_ZA\/status\/762211314588614657\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/EFLwow8nnF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPrJoQWcAAj-qX.jpg",
        "id_str" : "762211312613093376",
        "id" : 762211312613093376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPrJoQWcAAj-qX.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/EFLwow8nnF"
      } ],
      "hashtags" : [ {
        "text" : "500px",
        "indices" : [ 11, 17 ]
      }, {
        "text" : "Photography",
        "indices" : [ 34, 46 ]
      }, {
        "text" : "Photo",
        "indices" : [ 47, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762211314588614657",
    "text" : "Popular on #500px : Paragon Hotel #Photography #Photo https:\/\/t.co\/EFLwow8nnF",
    "id" : 762211314588614657,
    "created_at" : "2016-08-07 08:58:33 +0000",
    "user" : {
      "name" : "Wehnke 'Cuzzy' Botha",
      "screen_name" : "XBearer_ZA",
      "protected" : false,
      "id_str" : "101684460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806080200157044736\/_anmOPJT_normal.jpg",
      "id" : 101684460,
      "verified" : false
    }
  },
  "id" : 762211924700434432,
  "created_at" : "2016-08-07 09:00:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "landscape",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "photo",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "image",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "photography",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "nature",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "travel",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "art",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "beinspired",
      "indices" : [ 118, 129 ]
    }, {
      "text" : "sky",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211694764552192",
  "text" : "RT @Dolly_Ray_1987: The church in Hofsos by Dagur Jonsson\n\n#landscape #photo #image #photography #nature #travel #art #beinspired #sky \u2026 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dolly_Ray_1987\/status\/762211490464137216\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ADKVccMhE4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPrT4EWIAAndez.jpg",
        "id_str" : "762211488656400384",
        "id" : 762211488656400384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPrT4EWIAAndez.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/ADKVccMhE4"
      } ],
      "hashtags" : [ {
        "text" : "landscape",
        "indices" : [ 39, 49 ]
      }, {
        "text" : "photo",
        "indices" : [ 50, 56 ]
      }, {
        "text" : "image",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "photography",
        "indices" : [ 64, 76 ]
      }, {
        "text" : "nature",
        "indices" : [ 77, 84 ]
      }, {
        "text" : "travel",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "art",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "beinspired",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "sky",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762211490464137216",
    "text" : "The church in Hofsos by Dagur Jonsson\n\n#landscape #photo #image #photography #nature #travel #art #beinspired #sky \u2026 https:\/\/t.co\/ADKVccMhE4",
    "id" : 762211490464137216,
    "created_at" : "2016-08-07 08:59:15 +0000",
    "user" : {
      "name" : "Dolly Ray",
      "screen_name" : "DollyRay1987",
      "protected" : false,
      "id_str" : "199583609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744268148640096256\/NedDSN3s_normal.jpg",
      "id" : 199583609,
      "verified" : false
    }
  },
  "id" : 762211694764552192,
  "created_at" : "2016-08-07 09:00:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tripfania",
      "screen_name" : "Tripfania",
      "indices" : [ 3, 13 ],
      "id_str" : "1964217900",
      "id" : 1964217900
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Tripfania\/status\/762178814734663680\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Cl6e7WLcnl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPNl5oWgAAk-t9.jpg",
      "id_str" : "762178812964667392",
      "id" : 762178812964667392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPNl5oWgAAk-t9.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 428
      } ],
      "display_url" : "pic.twitter.com\/Cl6e7WLcnl"
    } ],
    "hashtags" : [ {
      "text" : "lp",
      "indices" : [ 65, 68 ]
    }, {
      "text" : "photography",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211656260841473",
  "text" : "RT @Tripfania: Chateau de Chillon, Switzerland (by Stefan Kemp). #lp #photography https:\/\/t.co\/Cl6e7WLcnl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Tripfania\/status\/762178814734663680\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Cl6e7WLcnl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPNl5oWgAAk-t9.jpg",
        "id_str" : "762178812964667392",
        "id" : 762178812964667392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPNl5oWgAAk-t9.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 428
        } ],
        "display_url" : "pic.twitter.com\/Cl6e7WLcnl"
      } ],
      "hashtags" : [ {
        "text" : "lp",
        "indices" : [ 50, 53 ]
      }, {
        "text" : "photography",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762178814734663680",
    "text" : "Chateau de Chillon, Switzerland (by Stefan Kemp). #lp #photography https:\/\/t.co\/Cl6e7WLcnl",
    "id" : 762178814734663680,
    "created_at" : "2016-08-07 06:49:24 +0000",
    "user" : {
      "name" : "Tripfania",
      "screen_name" : "Tripfania",
      "protected" : false,
      "id_str" : "1964217900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544951425814372352\/S302E40r_normal.jpeg",
      "id" : 1964217900,
      "verified" : false
    }
  },
  "id" : 762211656260841473,
  "created_at" : "2016-08-07 08:59:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristian Vlad",
      "screen_name" : "_Cristian_Vlad_",
      "indices" : [ 3, 19 ],
      "id_str" : "2443379798",
      "id" : 2443379798
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_Cristian_Vlad_\/status\/762189492753199104\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/qgnrxAWewX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPXRaeWgAAuKRx.jpg",
      "id_str" : "762189456120119296",
      "id" : 762189456120119296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPXRaeWgAAuKRx.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/qgnrxAWewX"
    } ],
    "hashtags" : [ {
      "text" : "goodmorning",
      "indices" : [ 53, 65 ]
    }, {
      "text" : "photography",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211597850992640",
  "text" : "RT @_Cristian_Vlad_: Good morning Twitter Friends !!\n#goodmorning #photography https:\/\/t.co\/qgnrxAWewX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_Cristian_Vlad_\/status\/762189492753199104\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/qgnrxAWewX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPXRaeWgAAuKRx.jpg",
        "id_str" : "762189456120119296",
        "id" : 762189456120119296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPXRaeWgAAuKRx.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/qgnrxAWewX"
      } ],
      "hashtags" : [ {
        "text" : "goodmorning",
        "indices" : [ 32, 44 ]
      }, {
        "text" : "photography",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762189492753199104",
    "text" : "Good morning Twitter Friends !!\n#goodmorning #photography https:\/\/t.co\/qgnrxAWewX",
    "id" : 762189492753199104,
    "created_at" : "2016-08-07 07:31:50 +0000",
    "user" : {
      "name" : "Cristian Vlad",
      "screen_name" : "_Cristian_Vlad_",
      "protected" : false,
      "id_str" : "2443379798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876094197190856704\/dD5nmW7S_normal.jpg",
      "id" : 2443379798,
      "verified" : false
    }
  },
  "id" : 762211597850992640,
  "created_at" : "2016-08-07 08:59:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tripfania",
      "screen_name" : "Tripfania",
      "indices" : [ 3, 13 ],
      "id_str" : "1964217900",
      "id" : 1964217900
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Tripfania\/status\/762194185764147200\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/og7XkO0bdG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPbknuW8AA8Hdr.jpg",
      "id_str" : "762194184140943360",
      "id" : 762194184140943360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPbknuW8AA8Hdr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 465
      } ],
      "display_url" : "pic.twitter.com\/og7XkO0bdG"
    } ],
    "hashtags" : [ {
      "text" : "lp",
      "indices" : [ 22, 25 ]
    }, {
      "text" : "photography",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211544264478720",
  "text" : "RT @Tripfania: sunset #lp #photography https:\/\/t.co\/og7XkO0bdG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Tripfania\/status\/762194185764147200\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/og7XkO0bdG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPbknuW8AA8Hdr.jpg",
        "id_str" : "762194184140943360",
        "id" : 762194184140943360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPbknuW8AA8Hdr.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 465
        } ],
        "display_url" : "pic.twitter.com\/og7XkO0bdG"
      } ],
      "hashtags" : [ {
        "text" : "lp",
        "indices" : [ 7, 10 ]
      }, {
        "text" : "photography",
        "indices" : [ 11, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762194185764147200",
    "text" : "sunset #lp #photography https:\/\/t.co\/og7XkO0bdG",
    "id" : 762194185764147200,
    "created_at" : "2016-08-07 07:50:29 +0000",
    "user" : {
      "name" : "Tripfania",
      "screen_name" : "Tripfania",
      "protected" : false,
      "id_str" : "1964217900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544951425814372352\/S302E40r_normal.jpeg",
      "id" : 1964217900,
      "verified" : false
    }
  },
  "id" : 762211544264478720,
  "created_at" : "2016-08-07 08:59:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paolo",
      "screen_name" : "Paolo1264",
      "indices" : [ 3, 13 ],
      "id_str" : "2375910678",
      "id" : 2375910678
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Paolo1264\/status\/762195831000883200\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/NBRdvvv0kq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPdD82WEAAWfMT.jpg",
      "id_str" : "762195821899157504",
      "id" : 762195821899157504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPdD82WEAAWfMT.jpg",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/NBRdvvv0kq"
    } ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211522185682945",
  "text" : "RT @Paolo1264: 'Eleanor and Barbara, Chicago, 1953', Harry Callahan #photography. https:\/\/t.co\/NBRdvvv0kq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Paolo1264\/status\/762195831000883200\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/NBRdvvv0kq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPdD82WEAAWfMT.jpg",
        "id_str" : "762195821899157504",
        "id" : 762195821899157504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPdD82WEAAWfMT.jpg",
        "sizes" : [ {
          "h" : 546,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/NBRdvvv0kq"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 53, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762195831000883200",
    "text" : "'Eleanor and Barbara, Chicago, 1953', Harry Callahan #photography. https:\/\/t.co\/NBRdvvv0kq",
    "id" : 762195831000883200,
    "created_at" : "2016-08-07 07:57:01 +0000",
    "user" : {
      "name" : "Paolo",
      "screen_name" : "Paolo1264",
      "protected" : false,
      "id_str" : "2375910678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734462827432431616\/9tuhO8KT_normal.jpg",
      "id" : 2375910678,
      "verified" : false
    }
  },
  "id" : 762211522185682945,
  "created_at" : "2016-08-07 08:59:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 66, 78 ]
    }, {
      "text" : "pod",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/T97AccOPdQ",
      "expanded_url" : "http:\/\/on.natgeo.com\/2bbICUg",
      "display_url" : "on.natgeo.com\/2bbICUg"
    } ]
  },
  "geo" : { },
  "id_str" : "762211479483510784",
  "text" : "RT @NatGeo: Photo of the Day: Night Falls https:\/\/t.co\/T97AccOPdQ #photography #pod",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 54, 66 ]
      }, {
        "text" : "pod",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/T97AccOPdQ",
        "expanded_url" : "http:\/\/on.natgeo.com\/2bbICUg",
        "display_url" : "on.natgeo.com\/2bbICUg"
      } ]
    },
    "geo" : { },
    "id_str" : "762207922382307328",
    "text" : "Photo of the Day: Night Falls https:\/\/t.co\/T97AccOPdQ #photography #pod",
    "id" : 762207922382307328,
    "created_at" : "2016-08-07 08:45:04 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921336759979597825\/VTSJ5mRt_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 762211479483510784,
  "created_at" : "2016-08-07 08:59:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donny Goines",
      "screen_name" : "DonnyGoines",
      "indices" : [ 3, 15 ],
      "id_str" : "16744854",
      "id" : 16744854
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DonnyGoines\/status\/761996004908466176\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/zBEIcvX3Sp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMnTWnXYAAZ_Ql.jpg",
      "id_str" : "761995975397433344",
      "id" : 761995975397433344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMnTWnXYAAZ_Ql.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2538,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 1269,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/zBEIcvX3Sp"
    } ],
    "hashtags" : [ {
      "text" : "Positive",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "Photography",
      "indices" : [ 41, 53 ]
    }, {
      "text" : "Art",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "Nature",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "Color",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211436135350272",
  "text" : "RT @DonnyGoines: #Positive Perspective.\n\n#Photography #Art #Nature #Color https:\/\/t.co\/zBEIcvX3Sp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DonnyGoines\/status\/761996004908466176\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/zBEIcvX3Sp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMnTWnXYAAZ_Ql.jpg",
        "id_str" : "761995975397433344",
        "id" : 761995975397433344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMnTWnXYAAZ_Ql.jpg",
        "sizes" : [ {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2538,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 1269,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/zBEIcvX3Sp"
      } ],
      "hashtags" : [ {
        "text" : "Positive",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Photography",
        "indices" : [ 24, 36 ]
      }, {
        "text" : "Art",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "Nature",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "Color",
        "indices" : [ 50, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761996004908466176",
    "text" : "#Positive Perspective.\n\n#Photography #Art #Nature #Color https:\/\/t.co\/zBEIcvX3Sp",
    "id" : 761996004908466176,
    "created_at" : "2016-08-06 18:42:59 +0000",
    "user" : {
      "name" : "Donny Goines",
      "screen_name" : "DonnyGoines",
      "protected" : false,
      "id_str" : "16744854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925332647487840256\/g4Q-bqUf_normal.jpg",
      "id" : 16744854,
      "verified" : false
    }
  },
  "id" : 762211436135350272,
  "created_at" : "2016-08-07 08:59:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762211387485593601",
  "text" : "RT @robynthe5th: You don't never come to me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762002006890442752",
    "text" : "You don't never come to me",
    "id" : 762002006890442752,
    "created_at" : "2016-08-06 19:06:50 +0000",
    "user" : {
      "name" : "Robyn \uD83C\uDD74",
      "screen_name" : "robynn470",
      "protected" : false,
      "id_str" : "156843968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920118498252161024\/4fERs5Gi_normal.jpg",
      "id" : 156843968,
      "verified" : false
    }
  },
  "id" : 762211387485593601,
  "created_at" : "2016-08-07 08:58:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "indices" : [ 3, 13 ],
      "id_str" : "395773216",
      "id" : 395773216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5okdaZvEQX",
      "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGFvD2XGtp26-k1-DV95gv-IvCuhg&clid=c3a7d30bb8a4878e06b80cf16b898331&ei=oDqmV4DGPI_OuAK9pb2gCA&url=https%3A%2F%2Fwww.washingtonpost.com%2Fsports%2Fcolleges%2Ftago-smith-is-a-jedi-but-navy-football-aims-to-get-him-to-that-yoda-status%2F2016%2F08%2F06%2F38f5e22c-5c01-11e6-9aee-8075993d73a2_story.html&utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762211330652856321",
  "text" : "RT @andikhm01: Tago Smith is a 'Jedi,' but Navy football aims 'to get him to that Yoda status' - Washington Post https:\/\/t.co\/5okdaZvEQX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/5okdaZvEQX",
        "expanded_url" : "http:\/\/news.google.com\/news\/url?sa=t&fd=R&ct2=us&usg=AFQjCNGFvD2XGtp26-k1-DV95gv-IvCuhg&clid=c3a7d30bb8a4878e06b80cf16b898331&ei=oDqmV4DGPI_OuAK9pb2gCA&url=https%3A%2F%2Fwww.washingtonpost.com%2Fsports%2Fcolleges%2Ftago-smith-is-a-jedi-but-navy-football-aims-to-get-him-to-that-yoda-status%2F2016%2F08%2F06%2F38f5e22c-5c01-11e6-9aee-8075993d73a2_story.html&utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "news.google.com\/news\/url?sa=t&\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762007866844721152",
    "text" : "Tago Smith is a 'Jedi,' but Navy football aims 'to get him to that Yoda status' - Washington Post https:\/\/t.co\/5okdaZvEQX",
    "id" : 762007866844721152,
    "created_at" : "2016-08-06 19:30:07 +0000",
    "user" : {
      "name" : "Andik Hadi Mustika",
      "screen_name" : "andikhm01",
      "protected" : false,
      "id_str" : "395773216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669886136\/ec057d1b393db3714c56f4b987e0021d_normal.jpeg",
      "id" : 395773216,
      "verified" : false
    }
  },
  "id" : 762211330652856321,
  "created_at" : "2016-08-07 08:58:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niall Ginsbourg",
      "screen_name" : "niall_bigscreen",
      "indices" : [ 3, 19 ],
      "id_str" : "118916927",
      "id" : 118916927
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 21, 30 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210948937580544",
  "text" : "RT @niall_bigscreen: @engadget .. the race is now on to develop the first autonomous ride on luggage vehicle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761993873560309761",
    "geo" : { },
    "id_str" : "762090373657141248",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget .. the race is now on to develop the first autonomous ride on luggage vehicle.",
    "id" : 762090373657141248,
    "in_reply_to_status_id" : 761993873560309761,
    "created_at" : "2016-08-07 00:57:58 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "Niall Ginsbourg",
      "screen_name" : "niall_bigscreen",
      "protected" : false,
      "id_str" : "118916927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820885860518281216\/w4puSDhO_normal.jpg",
      "id" : 118916927,
      "verified" : false
    }
  },
  "id" : 762210948937580544,
  "created_at" : "2016-08-07 08:57:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earl G Elliott III",
      "screen_name" : "egelliott3",
      "indices" : [ 3, 14 ],
      "id_str" : "449451484",
      "id" : 449451484
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 16, 25 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210904712830976",
  "text" : "RT @egelliott3: @engadget ok this is just sad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761993873560309761",
    "geo" : { },
    "id_str" : "762005891608567808",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget ok this is just sad",
    "id" : 762005891608567808,
    "in_reply_to_status_id" : 761993873560309761,
    "created_at" : "2016-08-06 19:22:16 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "Earl G Elliott III",
      "screen_name" : "egelliott3",
      "protected" : false,
      "id_str" : "449451484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672337101921251328\/L2ck_b-__normal.jpg",
      "id" : 449451484,
      "verified" : false
    }
  },
  "id" : 762210904712830976,
  "created_at" : "2016-08-07 08:56:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Carr",
      "screen_name" : "Stuey3D",
      "indices" : [ 3, 11 ],
      "id_str" : "50408475",
      "id" : 50408475
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 13, 22 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210891022606336",
  "text" : "RT @Stuey3D: @engadget guess you yanks don't have baggage weight restrictions then? I imagine motor and battery must weigh quite a bit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761993873560309761",
    "geo" : { },
    "id_str" : "762000628843446277",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget guess you yanks don't have baggage weight restrictions then? I imagine motor and battery must weigh quite a bit.",
    "id" : 762000628843446277,
    "in_reply_to_status_id" : 761993873560309761,
    "created_at" : "2016-08-06 19:01:21 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "Stuart Carr",
      "screen_name" : "Stuey3D",
      "protected" : false,
      "id_str" : "50408475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915990797664780289\/UB0Bo66Y_normal.jpg",
      "id" : 50408475,
      "verified" : false
    }
  },
  "id" : 762210891022606336,
  "created_at" : "2016-08-07 08:56:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/761993873560309761\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tM5IgQG89P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMlY4NWYAEXx51.jpg",
      "id_str" : "761993871291211777",
      "id" : 761993871291211777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMlY4NWYAEXx51.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/tM5IgQG89P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/WzZfYUMlS6",
      "expanded_url" : "http:\/\/engt.co\/2aOXHdY",
      "display_url" : "engt.co\/2aOXHdY"
    } ]
  },
  "geo" : { },
  "id_str" : "762210845887754240",
  "text" : "RT @engadget: Cruise the airport on top of a piece of motorized luggage https:\/\/t.co\/WzZfYUMlS6 https:\/\/t.co\/tM5IgQG89P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/761993873560309761\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/tM5IgQG89P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMlY4NWYAEXx51.jpg",
        "id_str" : "761993871291211777",
        "id" : 761993871291211777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMlY4NWYAEXx51.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/tM5IgQG89P"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/WzZfYUMlS6",
        "expanded_url" : "http:\/\/engt.co\/2aOXHdY",
        "display_url" : "engt.co\/2aOXHdY"
      } ]
    },
    "geo" : { },
    "id_str" : "761993873560309761",
    "text" : "Cruise the airport on top of a piece of motorized luggage https:\/\/t.co\/WzZfYUMlS6 https:\/\/t.co\/tM5IgQG89P",
    "id" : 761993873560309761,
    "created_at" : "2016-08-06 18:34:31 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 762210845887754240,
  "created_at" : "2016-08-07 08:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ianwaters",
      "screen_name" : "ianwaters",
      "indices" : [ 3, 13 ],
      "id_str" : "14991379",
      "id" : 14991379
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstsevenjobs",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210771036176384",
  "text" : "RT @ianwaters: Kitchen assistant\nCommis chef\nChef de partie\n2nd Chef\nCaterer\nArchitectural Illustrator\nAnimator\n#firstsevenjobs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762209258947698688",
    "text" : "Kitchen assistant\nCommis chef\nChef de partie\n2nd Chef\nCaterer\nArchitectural Illustrator\nAnimator\n#firstsevenjobs",
    "id" : 762209258947698688,
    "created_at" : "2016-08-07 08:50:23 +0000",
    "user" : {
      "name" : "ianwaters",
      "screen_name" : "ianwaters",
      "protected" : false,
      "id_str" : "14991379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532295785212559360\/l-2rmoVa_normal.jpeg",
      "id" : 14991379,
      "verified" : false
    }
  },
  "id" : 762210771036176384,
  "created_at" : "2016-08-07 08:56:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Appelquist",
      "screen_name" : "torgo",
      "indices" : [ 3, 9 ],
      "id_str" : "117723",
      "id" : 117723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210711913234432",
  "text" : "RT @torgo: Sure why not\u2026\n9\" tape wrangler\nLab assistant\nComputer repair\nUNIX support\nTechnical writer\nWeb developer\nDir Engineering\n#firsts\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762209350664478720",
    "text" : "Sure why not\u2026\n9\" tape wrangler\nLab assistant\nComputer repair\nUNIX support\nTechnical writer\nWeb developer\nDir Engineering\n#firstsevenjobs",
    "id" : 762209350664478720,
    "created_at" : "2016-08-07 08:50:45 +0000",
    "user" : {
      "name" : "Daniel Appelquist",
      "screen_name" : "torgo",
      "protected" : false,
      "id_str" : "117723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761221424929443842\/YI6U90tC_normal.jpg",
      "id" : 117723,
      "verified" : true
    }
  },
  "id" : 762210711913234432,
  "created_at" : "2016-08-07 08:56:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hanisha Vaswani",
      "screen_name" : "hanisha",
      "indices" : [ 3, 11 ],
      "id_str" : "14256251",
      "id" : 14256251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210584624504832",
  "text" : "RT @hanisha: Programming\nMgmt Consulting\nGeneral Startup Factotum \nProduct Management\nDigital Marketing\nDigital Strategy\nEntrepreneurship\n#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762209471565328384",
    "text" : "Programming\nMgmt Consulting\nGeneral Startup Factotum \nProduct Management\nDigital Marketing\nDigital Strategy\nEntrepreneurship\n#firstsevenjobs",
    "id" : 762209471565328384,
    "created_at" : "2016-08-07 08:51:13 +0000",
    "user" : {
      "name" : "Hanisha Vaswani",
      "screen_name" : "hanisha",
      "protected" : false,
      "id_str" : "14256251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1132779629\/02122009053_normal.jpg",
      "id" : 14256251,
      "verified" : false
    }
  },
  "id" : 762210584624504832,
  "created_at" : "2016-08-07 08:55:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mete Atature",
      "screen_name" : "MeteAtature",
      "indices" : [ 3, 15 ],
      "id_str" : "1085563848",
      "id" : 1085563848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstsevenjobs",
      "indices" : [ 17, 32 ]
    }, {
      "text" : "first7jobs",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762210341916934144",
  "text" : "RT @MeteAtature: #firstsevenjobs #first7jobs\n1) tutored\n2) mowed lawns\n3) delivered papers\n4) waited tables\n5) bartender\n6) teaching assist\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "first7jobs",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762209621138440192",
    "text" : "#firstsevenjobs #first7jobs\n1) tutored\n2) mowed lawns\n3) delivered papers\n4) waited tables\n5) bartender\n6) teaching assistant\n7) research \"",
    "id" : 762209621138440192,
    "created_at" : "2016-08-07 08:51:49 +0000",
    "user" : {
      "name" : "Mete Atature",
      "screen_name" : "MeteAtature",
      "protected" : false,
      "id_str" : "1085563848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920083869667397633\/XjF522Sb_normal.jpg",
      "id" : 1085563848,
      "verified" : false
    }
  },
  "id" : 762210341916934144,
  "created_at" : "2016-08-07 08:54:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam McCabe",
      "screen_name" : "AdamSMcCabe",
      "indices" : [ 3, 15 ],
      "id_str" : "113116266",
      "id" : 113116266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstSevenJobs",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762209976576344064",
  "text" : "RT @AdamSMcCabe: #FirstSevenJobs\nI. Kid on sand planet\nII. Apprentice\nIII. Jedi\nIV. Kid on sand planet\nV. Apprentice\nVI. Jedi\nVII. Kid on s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FirstSevenJobs",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762095011156459520",
    "text" : "#FirstSevenJobs\nI. Kid on sand planet\nII. Apprentice\nIII. Jedi\nIV. Kid on sand planet\nV. Apprentice\nVI. Jedi\nVII. Kid on sand planet",
    "id" : 762095011156459520,
    "created_at" : "2016-08-07 01:16:24 +0000",
    "user" : {
      "name" : "Adam McCabe",
      "screen_name" : "AdamSMcCabe",
      "protected" : false,
      "id_str" : "113116266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926228377962364928\/vPZgGjFq_normal.jpg",
      "id" : 113116266,
      "verified" : false
    }
  },
  "id" : 762209976576344064,
  "created_at" : "2016-08-07 08:53:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "indices" : [ 3, 17 ],
      "id_str" : "18206161",
      "id" : 18206161
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstsevenjobs",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762209912986492928",
  "text" : "RT @tristanwalker: #firstsevenjobs\n- Camp maintenance staff\uD83D\uDEAE\uD83D\uDEBE\n- Camp counselor\uD83D\uDC66\uD83C\uDFFD\n- College Library Admin\u270D\uD83C\uDFFE\n- Wall St Intern\n- Oil Trader\n-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762096840044978177",
    "text" : "#firstsevenjobs\n- Camp maintenance staff\uD83D\uDEAE\uD83D\uDEBE\n- Camp counselor\uD83D\uDC66\uD83C\uDFFD\n- College Library Admin\u270D\uD83C\uDFFE\n- Wall St Intern\n- Oil Trader\n- Biz Dev lead\n- CEO",
    "id" : 762096840044978177,
    "created_at" : "2016-08-07 01:23:40 +0000",
    "user" : {
      "name" : "tristan walker",
      "screen_name" : "tristanwalker",
      "protected" : false,
      "id_str" : "18206161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479487782075629569\/y3f1BvvV_normal.jpeg",
      "id" : 18206161,
      "verified" : true
    }
  },
  "id" : 762209912986492928,
  "created_at" : "2016-08-07 08:52:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 3, 9 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstsevenjobs",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762209439931854848",
  "text" : "RT @paulg: #firstsevenjobs \nmowing lawns\nscooping ice cream\nworking in a library\nprogrammer\nprogrammer\nprogrammer\nprogrammer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firstsevenjobs",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762196224447479808",
    "text" : "#firstsevenjobs \nmowing lawns\nscooping ice cream\nworking in a library\nprogrammer\nprogrammer\nprogrammer\nprogrammer",
    "id" : 762196224447479808,
    "created_at" : "2016-08-07 07:58:35 +0000",
    "user" : {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "protected" : false,
      "id_str" : "183749519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1824002576\/pg-railsconf_normal.jpg",
      "id" : 183749519,
      "verified" : true
    }
  },
  "id" : 762209439931854848,
  "created_at" : "2016-08-07 08:51:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laker Fan",
      "screen_name" : "erikanderson52",
      "indices" : [ 3, 18 ],
      "id_str" : "828188899",
      "id" : 828188899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762209267415998464",
  "text" : "RT @erikanderson52: USA\uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDFA\uD83C\uDDF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761971989745577984",
    "text" : "USA\uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDFA\uD83C\uDDF8",
    "id" : 761971989745577984,
    "created_at" : "2016-08-06 17:07:33 +0000",
    "user" : {
      "name" : "Laker Fan",
      "screen_name" : "erikanderson52",
      "protected" : false,
      "id_str" : "828188899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909602113243762690\/rUQTB916_normal.jpg",
      "id" : 828188899,
      "verified" : false
    }
  },
  "id" : 762209267415998464,
  "created_at" : "2016-08-07 08:50:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762208997122379776",
  "text" : "RT @BarbaraCorcoran: To build a business you have to be able to sell your idea. Beginners' passion is not enough!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761999081522757633",
    "text" : "To build a business you have to be able to sell your idea. Beginners' passion is not enough!",
    "id" : 761999081522757633,
    "created_at" : "2016-08-06 18:55:12 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 762208997122379776,
  "created_at" : "2016-08-07 08:49:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762069514729189376\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/1swofX7EIQ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpNqLv6WgAAOueA.jpg",
      "id_str" : "762069512028061696",
      "id" : 762069512028061696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpNqLv6WgAAOueA.jpg",
      "sizes" : [ {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/1swofX7EIQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762208374356336640",
  "text" : "RT @rockindigo: Why is FPS important for gaming? Which line do you like? https:\/\/t.co\/1swofX7EIQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762069514729189376\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/1swofX7EIQ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpNqLv6WgAAOueA.jpg",
        "id_str" : "762069512028061696",
        "id" : 762069512028061696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpNqLv6WgAAOueA.jpg",
        "sizes" : [ {
          "h" : 258,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/1swofX7EIQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762069514729189376",
    "text" : "Why is FPS important for gaming? Which line do you like? https:\/\/t.co\/1swofX7EIQ",
    "id" : 762069514729189376,
    "created_at" : "2016-08-06 23:35:05 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 762208374356336640,
  "created_at" : "2016-08-07 08:46:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/aJ80ddZFaY",
      "expanded_url" : "http:\/\/vine.co\/v\/MPYAHvpvjWn",
      "display_url" : "vine.co\/v\/MPYAHvpvjWn"
    } ]
  },
  "geo" : { },
  "id_str" : "762208129438416897",
  "text" : "RT @BestGamezUp: We all have that one unathletic friend https:\/\/t.co\/aJ80ddZFaY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/aJ80ddZFaY",
        "expanded_url" : "http:\/\/vine.co\/v\/MPYAHvpvjWn",
        "display_url" : "vine.co\/v\/MPYAHvpvjWn"
      } ]
    },
    "geo" : { },
    "id_str" : "762097466451890176",
    "text" : "We all have that one unathletic friend https:\/\/t.co\/aJ80ddZFaY",
    "id" : 762097466451890176,
    "created_at" : "2016-08-07 01:26:09 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 762208129438416897,
  "created_at" : "2016-08-07 08:45:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "indices" : [ 3, 16 ],
      "id_str" : "24664726",
      "id" : 24664726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762207588884832256",
  "text" : "RT @andykleinman: If it's true that Apple is getting rid of the \"gun emoji\", it's clear our society is at a very preoccupying breaking poin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762145547062956032",
    "text" : "If it's true that Apple is getting rid of the \"gun emoji\", it's clear our society is at a very preoccupying breaking point.",
    "id" : 762145547062956032,
    "created_at" : "2016-08-07 04:37:13 +0000",
    "user" : {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "protected" : false,
      "id_str" : "24664726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866530832315408384\/h0ORI03N_normal.jpg",
      "id" : 24664726,
      "verified" : true
    }
  },
  "id" : 762207588884832256,
  "created_at" : "2016-08-07 08:43:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Grace",
      "screen_name" : "AmazingiGrace",
      "indices" : [ 3, 17 ],
      "id_str" : "130682467",
      "id" : 130682467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762207540323254272",
  "text" : "RT @AmazingiGrace: Some people pass through our lives in a shorter time frame than we had hoped to teach us things they never could have ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761967569905545216",
    "text" : "Some people pass through our lives in a shorter time frame than we had hoped to teach us things they never could have taught if they stayed.",
    "id" : 761967569905545216,
    "created_at" : "2016-08-06 16:49:59 +0000",
    "user" : {
      "name" : "Amazing Grace",
      "screen_name" : "AmazingiGrace",
      "protected" : false,
      "id_str" : "130682467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534940765491695616\/KEwKXnPm_normal.jpeg",
      "id" : 130682467,
      "verified" : false
    }
  },
  "id" : 762207540323254272,
  "created_at" : "2016-08-07 08:43:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peyton Finch#\u20E31\u20E31\u20E3",
      "screen_name" : "ItsMeWesP_11",
      "indices" : [ 3, 16 ],
      "id_str" : "359492713",
      "id" : 359492713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762207383145869312",
  "text" : "RT @ItsMeWesP_11: I've been through too much in my life to be worried about any future problems that may come up",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762169283086430208",
    "text" : "I've been through too much in my life to be worried about any future problems that may come up",
    "id" : 762169283086430208,
    "created_at" : "2016-08-07 06:11:32 +0000",
    "user" : {
      "name" : "Peyton Finch#\u20E31\u20E31\u20E3",
      "screen_name" : "ItsMeWesP_11",
      "protected" : false,
      "id_str" : "359492713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808921478041370624\/9kxI4HFp_normal.jpg",
      "id" : 359492713,
      "verified" : false
    }
  },
  "id" : 762207383145869312,
  "created_at" : "2016-08-07 08:42:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762173023852105728\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/U7ffk3Tluc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPIUyjWYAA4fy4.jpg",
      "id_str" : "762173021448724480",
      "id" : 762173021448724480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPIUyjWYAA4fy4.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/U7ffk3Tluc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762207290506248192",
  "text" : "RT @rockindigo: Does anyone just loves Mechanical Keyboards? https:\/\/t.co\/U7ffk3Tluc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762173023852105728\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/U7ffk3Tluc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPIUyjWYAA4fy4.jpg",
        "id_str" : "762173021448724480",
        "id" : 762173021448724480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPIUyjWYAA4fy4.jpg",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/U7ffk3Tluc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762173023852105728",
    "text" : "Does anyone just loves Mechanical Keyboards? https:\/\/t.co\/U7ffk3Tluc",
    "id" : 762173023852105728,
    "created_at" : "2016-08-07 06:26:24 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 762207290506248192,
  "created_at" : "2016-08-07 08:42:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762173035340238848\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Xagh86Rmty",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPIVeZWIAAJz7f.jpg",
      "id_str" : "762173033217925120",
      "id" : 762173033217925120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPIVeZWIAAJz7f.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Xagh86Rmty"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762207234327777280",
  "text" : "RT @rockindigo: The Bearded Vulture, also called the Lammergeier. It feeds primarily on bones https:\/\/t.co\/Xagh86Rmty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/762173035340238848\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/Xagh86Rmty",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPIVeZWIAAJz7f.jpg",
        "id_str" : "762173033217925120",
        "id" : 762173033217925120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPIVeZWIAAJz7f.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Xagh86Rmty"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762173035340238848",
    "text" : "The Bearded Vulture, also called the Lammergeier. It feeds primarily on bones https:\/\/t.co\/Xagh86Rmty",
    "id" : 762173035340238848,
    "created_at" : "2016-08-07 06:26:26 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 762207234327777280,
  "created_at" : "2016-08-07 08:42:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 3, 19 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/R4ioipY1ML",
      "expanded_url" : "http:\/\/conservativetribune.com\/hillary-will-be-furious-kaine\/?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "conservativetribune.com\/hillary-will-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762207131365965824",
  "text" : "RT @conserv_tribune: Hillary Will Be FURIOUS With Kaine For This Brutal Slip Of The Tongue https:\/\/t.co\/R4ioipY1ML #tcot https:\/\/t.co\/8EAqg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/conserv_tribune\/status\/762039827499880449\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/8EAqgzCPnn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpNPLxWUEAAJV9I.jpg",
        "id_str" : "762039825599827968",
        "id" : 762039825599827968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpNPLxWUEAAJV9I.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/8EAqgzCPnn"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/R4ioipY1ML",
        "expanded_url" : "http:\/\/conservativetribune.com\/hillary-will-be-furious-kaine\/?utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "conservativetribune.com\/hillary-will-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762039827499880449",
    "text" : "Hillary Will Be FURIOUS With Kaine For This Brutal Slip Of The Tongue https:\/\/t.co\/R4ioipY1ML #tcot https:\/\/t.co\/8EAqgzCPnn",
    "id" : 762039827499880449,
    "created_at" : "2016-08-06 21:37:07 +0000",
    "user" : {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "protected" : false,
      "id_str" : "2217181338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675078788137488384\/b6wGb6cO_normal.jpg",
      "id" : 2217181338,
      "verified" : true
    }
  },
  "id" : 762207131365965824,
  "created_at" : "2016-08-07 08:41:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 3, 19 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/conserv_tribune\/status\/762051659199492096\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LOrTikYgaP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpNZ8eVUMAEU-nU.jpg",
      "id_str" : "762051657425235969",
      "id" : 762051657425235969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpNZ8eVUMAEU-nU.jpg",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/LOrTikYgaP"
    } ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/yBA1PbQdXb",
      "expanded_url" : "http:\/\/conservativetribune.com\/where-middle-class-hillary\/?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "conservativetribune.com\/where-middle-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762207091142656000",
  "text" : "RT @conserv_tribune: Here\u2019s Where \u201CMiddle Class\u201D Hillary Is Begging for Campaign Money https:\/\/t.co\/yBA1PbQdXb #tcot https:\/\/t.co\/LOrTikYgaP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/conserv_tribune\/status\/762051659199492096\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/LOrTikYgaP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpNZ8eVUMAEU-nU.jpg",
        "id_str" : "762051657425235969",
        "id" : 762051657425235969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpNZ8eVUMAEU-nU.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/LOrTikYgaP"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 90, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/yBA1PbQdXb",
        "expanded_url" : "http:\/\/conservativetribune.com\/where-middle-class-hillary\/?utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "conservativetribune.com\/where-middle-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762051659199492096",
    "text" : "Here\u2019s Where \u201CMiddle Class\u201D Hillary Is Begging for Campaign Money https:\/\/t.co\/yBA1PbQdXb #tcot https:\/\/t.co\/LOrTikYgaP",
    "id" : 762051659199492096,
    "created_at" : "2016-08-06 22:24:08 +0000",
    "user" : {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "protected" : false,
      "id_str" : "2217181338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675078788137488384\/b6wGb6cO_normal.jpg",
      "id" : 2217181338,
      "verified" : true
    }
  },
  "id" : 762207091142656000,
  "created_at" : "2016-08-07 08:41:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/762134375265869824\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/R5T4YhmVM4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpOlLK2WEAAMx-i.jpg",
      "id_str" : "762134373265182720",
      "id" : 762134373265182720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpOlLK2WEAAMx-i.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/R5T4YhmVM4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JtGo4pAFuG",
      "expanded_url" : "http:\/\/engt.co\/2aPUOcT",
      "display_url" : "engt.co\/2aPUOcT"
    } ]
  },
  "geo" : { },
  "id_str" : "762206812120702976",
  "text" : "RT @engadget: Fan-made 'No Man's Sky' app catalogs your interstellar journey https:\/\/t.co\/JtGo4pAFuG https:\/\/t.co\/R5T4YhmVM4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/762134375265869824\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/R5T4YhmVM4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpOlLK2WEAAMx-i.jpg",
        "id_str" : "762134373265182720",
        "id" : 762134373265182720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpOlLK2WEAAMx-i.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/R5T4YhmVM4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/JtGo4pAFuG",
        "expanded_url" : "http:\/\/engt.co\/2aPUOcT",
        "display_url" : "engt.co\/2aPUOcT"
      } ]
    },
    "geo" : { },
    "id_str" : "762134375265869824",
    "text" : "Fan-made 'No Man's Sky' app catalogs your interstellar journey https:\/\/t.co\/JtGo4pAFuG https:\/\/t.co\/R5T4YhmVM4",
    "id" : 762134375265869824,
    "created_at" : "2016-08-07 03:52:49 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 762206812120702976,
  "created_at" : "2016-08-07 08:40:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hi_hackAR\/status\/761638691328712704\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/kuHDFhCyHZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHiWigW8AAfnS9.jpg",
      "id_str" : "761638688849850368",
      "id" : 761638688849850368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHiWigW8AAfnS9.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 698
      } ],
      "display_url" : "pic.twitter.com\/kuHDFhCyHZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/HbwKyV36GU",
      "expanded_url" : "http:\/\/buff.ly\/2aVx7Ba",
      "display_url" : "buff.ly\/2aVx7Ba"
    } ]
  },
  "geo" : { },
  "id_str" : "762206450617872384",
  "text" : "RT @hi_hackAR: 5 Tech Predictions for 2017 https:\/\/t.co\/HbwKyV36GU https:\/\/t.co\/kuHDFhCyHZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hi_hackAR\/status\/761638691328712704\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/kuHDFhCyHZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHiWigW8AAfnS9.jpg",
        "id_str" : "761638688849850368",
        "id" : 761638688849850368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHiWigW8AAfnS9.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 698
        } ],
        "display_url" : "pic.twitter.com\/kuHDFhCyHZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/HbwKyV36GU",
        "expanded_url" : "http:\/\/buff.ly\/2aVx7Ba",
        "display_url" : "buff.ly\/2aVx7Ba"
      } ]
    },
    "geo" : { },
    "id_str" : "761638691328712704",
    "text" : "5 Tech Predictions for 2017 https:\/\/t.co\/HbwKyV36GU https:\/\/t.co\/kuHDFhCyHZ",
    "id" : 761638691328712704,
    "created_at" : "2016-08-05 19:03:09 +0000",
    "user" : {
      "name" : "Hi AR\/MR",
      "screen_name" : "hi_hackMR",
      "protected" : false,
      "id_str" : "734948172716380162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826785844950351873\/BvjWcSQ-_normal.jpg",
      "id" : 734948172716380162,
      "verified" : false
    }
  },
  "id" : 762206450617872384,
  "created_at" : "2016-08-07 08:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CreationResearch",
      "screen_name" : "Creation_Resear",
      "indices" : [ 3, 19 ],
      "id_str" : "328184203",
      "id" : 328184203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/fLy9oYdaWa",
      "expanded_url" : "http:\/\/fb.me\/v5r5plWm",
      "display_url" : "fb.me\/v5r5plWm"
    } ]
  },
  "geo" : { },
  "id_str" : "762206395106222080",
  "text" : "RT @Creation_Resear: Andrew Magdy Kamal: Gifted Teen, Explains Big Bang as Scientifically Incorrect....... https:\/\/t.co\/fLy9oYdaWa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/fLy9oYdaWa",
        "expanded_url" : "http:\/\/fb.me\/v5r5plWm",
        "display_url" : "fb.me\/v5r5plWm"
      } ]
    },
    "geo" : { },
    "id_str" : "744491729110315008",
    "text" : "Andrew Magdy Kamal: Gifted Teen, Explains Big Bang as Scientifically Incorrect....... https:\/\/t.co\/fLy9oYdaWa",
    "id" : 744491729110315008,
    "created_at" : "2016-06-19 11:27:14 +0000",
    "user" : {
      "name" : "CreationResearch",
      "screen_name" : "Creation_Resear",
      "protected" : false,
      "id_str" : "328184203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1440592592\/GodFinger_normal.jpg",
      "id" : 328184203,
      "verified" : false
    }
  },
  "id" : 762206395106222080,
  "created_at" : "2016-08-07 08:39:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "90s Football",
      "screen_name" : "90sfootball",
      "indices" : [ 3, 15 ],
      "id_str" : "872191892",
      "id" : 872191892
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/90sfootball\/status\/761975132990517248\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/I9Hm6yy6AD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co2fUp2WYAAR0bB.jpg",
      "id_str" : "760439089275494400",
      "id" : 760439089275494400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co2fUp2WYAAR0bB.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I9Hm6yy6AD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762019233534533633",
  "text" : "RT @90sfootball: One Picture. Three Legends. https:\/\/t.co\/I9Hm6yy6AD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/90sfootball\/status\/761975132990517248\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/I9Hm6yy6AD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co2fUp2WYAAR0bB.jpg",
        "id_str" : "760439089275494400",
        "id" : 760439089275494400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co2fUp2WYAAR0bB.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I9Hm6yy6AD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761975132990517248",
    "text" : "One Picture. Three Legends. https:\/\/t.co\/I9Hm6yy6AD",
    "id" : 761975132990517248,
    "created_at" : "2016-08-06 17:20:03 +0000",
    "user" : {
      "name" : "90s Football",
      "screen_name" : "90sfootball",
      "protected" : false,
      "id_str" : "872191892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890588569865265156\/LiHFIvju_normal.jpg",
      "id" : 872191892,
      "verified" : false
    }
  },
  "id" : 762019233534533633,
  "created_at" : "2016-08-06 20:15:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Sox",
      "screen_name" : "RedSox",
      "indices" : [ 3, 10 ],
      "id_str" : "40918816",
      "id" : 40918816
    }, {
      "name" : "Mookie Betts",
      "screen_name" : "mookiebetts",
      "indices" : [ 29, 41 ],
      "id_str" : "296630223",
      "id" : 296630223
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RedSox\/status\/761969987720507392\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qk0VWQQsRS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMPp7fW8AEsek5.jpg",
      "id_str" : "761969974974017537",
      "id" : 761969974974017537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMPp7fW8AEsek5.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qk0VWQQsRS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762019185639714817",
  "text" : "RT @RedSox: No big surprise, @mookiebetts had himself a night last night: https:\/\/t.co\/qk0VWQQsRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mookie Betts",
        "screen_name" : "mookiebetts",
        "indices" : [ 17, 29 ],
        "id_str" : "296630223",
        "id" : 296630223
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RedSox\/status\/761969987720507392\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/qk0VWQQsRS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMPp7fW8AEsek5.jpg",
        "id_str" : "761969974974017537",
        "id" : 761969974974017537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMPp7fW8AEsek5.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qk0VWQQsRS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761969987720507392",
    "text" : "No big surprise, @mookiebetts had himself a night last night: https:\/\/t.co\/qk0VWQQsRS",
    "id" : 761969987720507392,
    "created_at" : "2016-08-06 16:59:36 +0000",
    "user" : {
      "name" : "Red Sox",
      "screen_name" : "RedSox",
      "protected" : false,
      "id_str" : "40918816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/917519666981031936\/x6obTRnT_normal.jpg",
      "id" : 40918816,
      "verified" : true
    }
  },
  "id" : 762019185639714817,
  "created_at" : "2016-08-06 20:15:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/762018954495791104\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/PegVbe2NoY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpM8If8WIAAEuqQ.jpg",
      "id_str" : "762018878666973184",
      "id" : 762018878666973184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpM8If8WIAAEuqQ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PegVbe2NoY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762018954495791104",
  "text" : "Went to Isthar restaurant 4.95\/5 stars https:\/\/t.co\/PegVbe2NoY",
  "id" : 762018954495791104,
  "created_at" : "2016-08-06 20:14:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KURTH",
      "screen_name" : "KurthMusic",
      "indices" : [ 3, 14 ],
      "id_str" : "308852840",
      "id" : 308852840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761988938940633088",
  "text" : "RT @KURTHmusic: Remember how you started, you don't have to be rude with the people who are searching for your support or your comments.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761740578484686849",
    "text" : "Remember how you started, you don't have to be rude with the people who are searching for your support or your comments.",
    "id" : 761740578484686849,
    "created_at" : "2016-08-06 01:48:01 +0000",
    "user" : {
      "name" : "KURTH",
      "screen_name" : "KurthMusic",
      "protected" : false,
      "id_str" : "308852840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788140896957046784\/7BD4Q0s5_normal.jpg",
      "id" : 308852840,
      "verified" : false
    }
  },
  "id" : 761988938940633088,
  "created_at" : "2016-08-06 18:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/761773849688084480\/video\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wdU3oOqSmT",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761773795770306560\/pu\/img\/bIKC7dsJuIJYYQKo.jpg",
      "id_str" : "761773795770306560",
      "id" : 761773795770306560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761773795770306560\/pu\/img\/bIKC7dsJuIJYYQKo.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wdU3oOqSmT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/gmaPFqs3W5",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=2Uj32C20JCA",
      "display_url" : "youtube.com\/watch?v=2Uj32C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761988512665128960",
  "text" : "RT @scrowder: Why are you still awake? Get triggered and go to sleep. FULL VIDEO &gt;&gt; https:\/\/t.co\/gmaPFqs3W5 https:\/\/t.co\/wdU3oOqSmT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/761773849688084480\/video\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/wdU3oOqSmT",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761773795770306560\/pu\/img\/bIKC7dsJuIJYYQKo.jpg",
        "id_str" : "761773795770306560",
        "id" : 761773795770306560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/761773795770306560\/pu\/img\/bIKC7dsJuIJYYQKo.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wdU3oOqSmT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/gmaPFqs3W5",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=2Uj32C20JCA",
        "display_url" : "youtube.com\/watch?v=2Uj32C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761773849688084480",
    "text" : "Why are you still awake? Get triggered and go to sleep. FULL VIDEO &gt;&gt; https:\/\/t.co\/gmaPFqs3W5 https:\/\/t.co\/wdU3oOqSmT",
    "id" : 761773849688084480,
    "created_at" : "2016-08-06 04:00:13 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 761988512665128960,
  "created_at" : "2016-08-06 18:13:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/761819150935322624\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/zCI1CxCFPk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpKGetmWEAAVC3o.jpg",
      "id_str" : "761819149173657600",
      "id" : 761819149173657600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpKGetmWEAAVC3o.jpg",
      "sizes" : [ {
        "h" : 488,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/zCI1CxCFPk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761988103431000064",
  "text" : "RT @saatchi_gallery: Happy birthday to artist Richard Prince! This is 'Untitled Cowboy', 1989. https:\/\/t.co\/zCI1CxCFPk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/761819150935322624\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/zCI1CxCFPk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpKGetmWEAAVC3o.jpg",
        "id_str" : "761819149173657600",
        "id" : 761819149173657600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpKGetmWEAAVC3o.jpg",
        "sizes" : [ {
          "h" : 488,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/zCI1CxCFPk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761819150935322624",
    "text" : "Happy birthday to artist Richard Prince! This is 'Untitled Cowboy', 1989. https:\/\/t.co\/zCI1CxCFPk",
    "id" : 761819150935322624,
    "created_at" : "2016-08-06 07:00:14 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 761988103431000064,
  "created_at" : "2016-08-06 18:11:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Dean Cain",
      "screen_name" : "RealDeanCain",
      "indices" : [ 68, 81 ],
      "id_str" : "581999965",
      "id" : 581999965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761987551502540800",
  "text" : "RT @scrowder: New #LwC fan contest. Whoever designs the best Hopper\/@RealDeanCain poster gets a free custom mug when the NOTDAILY store ope\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dean Cain",
        "screen_name" : "RealDeanCain",
        "indices" : [ 54, 67 ],
        "id_str" : "581999965",
        "id" : 581999965
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 4, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761920413752492032",
    "text" : "New #LwC fan contest. Whoever designs the best Hopper\/@RealDeanCain poster gets a free custom mug when the NOTDAILY store opens.",
    "id" : 761920413752492032,
    "created_at" : "2016-08-06 13:42:37 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 761987551502540800,
  "created_at" : "2016-08-06 18:09:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/kplfMx21Wh",
      "expanded_url" : "http:\/\/www.washingtonexaminer.com\/court-finds-irs-may-still-be-targeting-conservatives\/article\/2598741",
      "display_url" : "washingtonexaminer.com\/court-finds-ir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761987290516238336",
  "text" : "RT @tedcruz: An important victory in the fight to hold the IRS to account for its targeting of conservatives https:\/\/t.co\/kplfMx21Wh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/kplfMx21Wh",
        "expanded_url" : "http:\/\/www.washingtonexaminer.com\/court-finds-irs-may-still-be-targeting-conservatives\/article\/2598741",
        "display_url" : "washingtonexaminer.com\/court-finds-ir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761737953513046016",
    "text" : "An important victory in the fight to hold the IRS to account for its targeting of conservatives https:\/\/t.co\/kplfMx21Wh",
    "id" : 761737953513046016,
    "created_at" : "2016-08-06 01:37:35 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 761987290516238336,
  "created_at" : "2016-08-06 18:08:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iv\u00E1n Belvis",
      "screen_name" : "ibnmusic",
      "indices" : [ 3, 12 ],
      "id_str" : "33083887",
      "id" : 33083887
    }, {
      "name" : "Comit\u00E9 Ol\u00EDmpico PUR",
      "screen_name" : "ComiteOlimpico",
      "indices" : [ 114, 129 ],
      "id_str" : "97253125",
      "id" : 97253125
    }, {
      "name" : "Rio 2016",
      "screen_name" : "Rio2016",
      "indices" : [ 130, 138 ],
      "id_str" : "833913874575409152",
      "id" : 833913874575409152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PUR",
      "indices" : [ 60, 64 ]
    }, {
      "text" : "NGR",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "TableTennis",
      "indices" : [ 83, 95 ]
    }, {
      "text" : "PuertoRico",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761987243598688256",
  "text" : "RT @ibnmusic: Si Adriana gana 6to el set gana el partido. \n\n#PUR\u00A0\u00A03 vs 2 #NGR\u00A0\u00A0\u00A0\u00A0\u00A0\n#TableTennis\u00A0\u00A0\u00A0\u00A0\u00A0 \n#PuertoRico\n@ComiteOlimpico\n@Rio2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Comit\u00E9 Ol\u00EDmpico PUR",
        "screen_name" : "ComiteOlimpico",
        "indices" : [ 100, 115 ],
        "id_str" : "97253125",
        "id" : 97253125
      }, {
        "name" : "Rio 2016",
        "screen_name" : "Rio2016",
        "indices" : [ 116, 124 ],
        "id_str" : "833913874575409152",
        "id" : 833913874575409152
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PUR",
        "indices" : [ 46, 50 ]
      }, {
        "text" : "NGR",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "TableTennis",
        "indices" : [ 69, 81 ]
      }, {
        "text" : "PuertoRico",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761987190511562752",
    "text" : "Si Adriana gana 6to el set gana el partido. \n\n#PUR\u00A0\u00A03 vs 2 #NGR\u00A0\u00A0\u00A0\u00A0\u00A0\n#TableTennis\u00A0\u00A0\u00A0\u00A0\u00A0 \n#PuertoRico\n@ComiteOlimpico\n@Rio2016",
    "id" : 761987190511562752,
    "created_at" : "2016-08-06 18:07:57 +0000",
    "user" : {
      "name" : "Iv\u00E1n Belvis",
      "screen_name" : "ibnmusic",
      "protected" : false,
      "id_str" : "33083887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871536484620349440\/JsRvVU6b_normal.jpg",
      "id" : 33083887,
      "verified" : false
    }
  },
  "id" : 761987243598688256,
  "created_at" : "2016-08-06 18:08:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bishop Agathon",
      "screen_name" : "BishopAgathon",
      "indices" : [ 3, 17 ],
      "id_str" : "1031313552",
      "id" : 1031313552
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BishopAgathon\/status\/761987065533829120\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/e97NzzqsNg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMfMnbXgAAqlaa.jpg",
      "id_str" : "761987063558406144",
      "id" : 761987063558406144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMfMnbXgAAqlaa.jpg",
      "sizes" : [ {
        "h" : 591,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 591
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 591
      } ],
      "display_url" : "pic.twitter.com\/e97NzzqsNg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761987214469324800",
  "text" : "RT @BishopAgathon: \u0628\u062F\u0621 \u0635\u064A\u0627\u0645 \u0627\u0644\u0633\u064A\u062F\u0629 \u0627\u0644\u0639\u0630\u0631\u0627\u0621 \u0645\u0631\u064A\u0645\n\u0643\u0644 \u0633\u0646\u0629 \u0648\u0627\u0646\u062A\u0645 \u0637\u064A\u0628\u064A\u0646 https:\/\/t.co\/e97NzzqsNg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BishopAgathon\/status\/761987065533829120\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/e97NzzqsNg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpMfMnbXgAAqlaa.jpg",
        "id_str" : "761987063558406144",
        "id" : 761987063558406144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpMfMnbXgAAqlaa.jpg",
        "sizes" : [ {
          "h" : 591,
          "resize" : "fit",
          "w" : 591
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 591
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 591
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 591
        } ],
        "display_url" : "pic.twitter.com\/e97NzzqsNg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761987065533829120",
    "text" : "\u0628\u062F\u0621 \u0635\u064A\u0627\u0645 \u0627\u0644\u0633\u064A\u062F\u0629 \u0627\u0644\u0639\u0630\u0631\u0627\u0621 \u0645\u0631\u064A\u0645\n\u0643\u0644 \u0633\u0646\u0629 \u0648\u0627\u0646\u062A\u0645 \u0637\u064A\u0628\u064A\u0646 https:\/\/t.co\/e97NzzqsNg",
    "id" : 761987065533829120,
    "created_at" : "2016-08-06 18:07:28 +0000",
    "user" : {
      "name" : "Bishop Agathon",
      "screen_name" : "BishopAgathon",
      "protected" : false,
      "id_str" : "1031313552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3172375143\/6c07509183c53eec46ea900068da6c12_normal.jpeg",
      "id" : 1031313552,
      "verified" : false
    }
  },
  "id" : 761987214469324800,
  "created_at" : "2016-08-06 18:08:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "indices" : [ 3, 18 ],
      "id_str" : "248135355",
      "id" : 248135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761987140720865280",
  "text" : "RT @BONNIELYNN2015: I forgot to mention I have a wicked Scottish temper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761986458848681984",
    "text" : "I forgot to mention I have a wicked Scottish temper",
    "id" : 761986458848681984,
    "created_at" : "2016-08-06 18:05:03 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "BONNIELYNN2015",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927433831929413632\/duExUEVU_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 761987140720865280,
  "created_at" : "2016-08-06 18:07:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/472546780136353792\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/cB0Cu3OcG1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo7SyvDIUAA_VgI.png",
      "id_str" : "472546779985367040",
      "id" : 472546779985367040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo7SyvDIUAA_VgI.png",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      } ],
      "display_url" : "pic.twitter.com\/cB0Cu3OcG1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761987113298427904",
  "text" : "RT @BestGamezUp: We now know the future of pixel art! https:\/\/t.co\/cB0Cu3OcG1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/472546780136353792\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/cB0Cu3OcG1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo7SyvDIUAA_VgI.png",
        "id_str" : "472546779985367040",
        "id" : 472546779985367040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo7SyvDIUAA_VgI.png",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        } ],
        "display_url" : "pic.twitter.com\/cB0Cu3OcG1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761986607260004352",
    "text" : "We now know the future of pixel art! https:\/\/t.co\/cB0Cu3OcG1",
    "id" : 761986607260004352,
    "created_at" : "2016-08-06 18:05:38 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 761987113298427904,
  "created_at" : "2016-08-06 18:07:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761685924094709760",
  "geo" : { },
  "id_str" : "761688463125073921",
  "in_reply_to_user_id" : 94878798,
  "text" : "@Maryamkansari Hillary and Trump, geez, ain't a fan of either. Might go for third party.",
  "id" : 761688463125073921,
  "in_reply_to_status_id" : 761685924094709760,
  "created_at" : "2016-08-05 22:20:55 +0000",
  "in_reply_to_screen_name" : "realMKAnsari",
  "in_reply_to_user_id_str" : "94878798",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G. Behn",
      "screen_name" : "gwbehn",
      "indices" : [ 3, 10 ],
      "id_str" : "841704092",
      "id" : 841704092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761687390805041152",
  "text" : "RT @gwbehn: Hillary saying she can't ID Classified material unless it's marked after Years of Handling Classified Dox indicates she's Unfit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761686903771004929",
    "text" : "Hillary saying she can't ID Classified material unless it's marked after Years of Handling Classified Dox indicates she's Unfit for WH #tcot",
    "id" : 761686903771004929,
    "created_at" : "2016-08-05 22:14:43 +0000",
    "user" : {
      "name" : "G. Behn",
      "screen_name" : "gwbehn",
      "protected" : false,
      "id_str" : "841704092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600939770647162880\/_rinSPVS_normal.jpg",
      "id" : 841704092,
      "verified" : false
    }
  },
  "id" : 761687390805041152,
  "created_at" : "2016-08-05 22:16:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Accuracy In Media",
      "screen_name" : "AccuracyInMedia",
      "indices" : [ 3, 19 ],
      "id_str" : "15256077",
      "id" : 15256077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1cVim3xfFt",
      "expanded_url" : "http:\/\/buff.ly\/2aWrJ3l",
      "display_url" : "buff.ly\/2aWrJ3l"
    } ]
  },
  "geo" : { },
  "id_str" : "761687305727815681",
  "text" : "RT @AccuracyInMedia: Muslims Stood with Christians by Attending Mass after French Priest's Murder https:\/\/t.co\/1cVim3xfFt #tcot https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AccuracyInMedia\/status\/761686998771957760\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/e7EkS4SyxQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpIOSdDWYAAj6q4.jpg",
        "id_str" : "761686997178146816",
        "id" : 761686997178146816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpIOSdDWYAAj6q4.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/e7EkS4SyxQ"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/1cVim3xfFt",
        "expanded_url" : "http:\/\/buff.ly\/2aWrJ3l",
        "display_url" : "buff.ly\/2aWrJ3l"
      } ]
    },
    "geo" : { },
    "id_str" : "761686998771957760",
    "text" : "Muslims Stood with Christians by Attending Mass after French Priest's Murder https:\/\/t.co\/1cVim3xfFt #tcot https:\/\/t.co\/e7EkS4SyxQ",
    "id" : 761686998771957760,
    "created_at" : "2016-08-05 22:15:06 +0000",
    "user" : {
      "name" : "Accuracy In Media",
      "screen_name" : "AccuracyInMedia",
      "protected" : false,
      "id_str" : "15256077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884477179341361152\/42nVspOJ_normal.jpg",
      "id" : 15256077,
      "verified" : false
    }
  },
  "id" : 761687305727815681,
  "created_at" : "2016-08-05 22:16:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 20, 36 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761687134122029060",
  "text" : "RT @dianemercado11: @conserv_tribune This took me by surprise.  They finally got something right.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Conservative Tribune",
        "screen_name" : "conserv_tribune",
        "indices" : [ 0, 16 ],
        "id_str" : "2217181338",
        "id" : 2217181338
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761348565578817538",
    "geo" : { },
    "id_str" : "761354287033249792",
    "in_reply_to_user_id" : 2217181338,
    "text" : "@conserv_tribune This took me by surprise.  They finally got something right.",
    "id" : 761354287033249792,
    "in_reply_to_status_id" : 761348565578817538,
    "created_at" : "2016-08-05 00:13:01 +0000",
    "in_reply_to_screen_name" : "conserv_tribune",
    "in_reply_to_user_id_str" : "2217181338",
    "user" : {
      "name" : "DiMe\uD83C\uDDF1\uD83C\uDDF7\uD83C\uDDF5\uD83C\uDDF7",
      "screen_name" : "Gilamanda21",
      "protected" : false,
      "id_str" : "731989974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927116186902507521\/Ubg38H9d_normal.jpg",
      "id" : 731989974,
      "verified" : false
    }
  },
  "id" : 761687134122029060,
  "created_at" : "2016-08-05 22:15:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Betts",
      "screen_name" : "JohnFromCranber",
      "indices" : [ 3, 19 ],
      "id_str" : "1065869268",
      "id" : 1065869268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761687012365651970",
  "text" : "RT @JohnFromCranber: Electing a Black Pres Shld Have Healed Racial Tensions. But Instead of 'Great Uniter' we Got a 'Great Divider' #tcot h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnFromCranber\/status\/689886257036529664\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/BPo41Fe4Uj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZL35SDWkAETNVF.jpg",
        "id_str" : "689886256411611137",
        "id" : 689886256411611137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZL35SDWkAETNVF.jpg",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 858
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 858
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 858
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/BPo41Fe4Uj"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761359423147216896",
    "text" : "Electing a Black Pres Shld Have Healed Racial Tensions. But Instead of 'Great Uniter' we Got a 'Great Divider' #tcot https:\/\/t.co\/BPo41Fe4Uj",
    "id" : 761359423147216896,
    "created_at" : "2016-08-05 00:33:26 +0000",
    "user" : {
      "name" : "John Betts",
      "screen_name" : "JohnFromCranber",
      "protected" : false,
      "id_str" : "1065869268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3273171017\/5fa5a2a5d9de3217a7610ca53c134814_normal.jpeg",
      "id" : 1065869268,
      "verified" : false
    }
  },
  "id" : 761687012365651970,
  "created_at" : "2016-08-05 22:15:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Cornyn",
      "screen_name" : "TeamCornyn",
      "indices" : [ 3, 14 ],
      "id_str" : "1648117711",
      "id" : 1648117711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/gB6vnuNQto",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7ce6731a-f3ca-406e-8440-09e001c66a69",
      "display_url" : "amp.twimg.com\/v\/7ce6731a-f3c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761686967411019777",
  "text" : "RT @TeamCornyn: WATCH: A new message from Senator Cornyn, on the future of our party &amp; nation. #tcot\nhttps:\/\/t.co\/gB6vnuNQto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 83, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/gB6vnuNQto",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/7ce6731a-f3ca-406e-8440-09e001c66a69",
        "display_url" : "amp.twimg.com\/v\/7ce6731a-f3c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761535155261480960",
    "text" : "WATCH: A new message from Senator Cornyn, on the future of our party &amp; nation. #tcot\nhttps:\/\/t.co\/gB6vnuNQto",
    "id" : 761535155261480960,
    "created_at" : "2016-08-05 12:11:44 +0000",
    "user" : {
      "name" : "Team Cornyn",
      "screen_name" : "TeamCornyn",
      "protected" : false,
      "id_str" : "1648117711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461305403368681472\/drSGiB-4_normal.png",
      "id" : 1648117711,
      "verified" : true
    }
  },
  "id" : 761686967411019777,
  "created_at" : "2016-08-05 22:14:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John K Stahl",
      "screen_name" : "JohnKStahlUSA",
      "indices" : [ 3, 17 ],
      "id_str" : "4236806414",
      "id" : 4236806414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "ccot",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "gop",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "maga",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761686535078944768",
  "text" : "RT @JohnKStahlUSA: To think America would put this pathetic dog and his pandering \"wife\" back in WH is insane. #tcot #ccot #gop #maga https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKStahlUSA\/status\/761561854774693888\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/LL55oeVCBA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpGcdpyVMAATKSs.jpg",
        "id_str" : "761561845249421312",
        "id" : 761561845249421312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpGcdpyVMAATKSs.jpg",
        "sizes" : [ {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        }, {
          "h" : 2001,
          "resize" : "fit",
          "w" : 1125
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        } ],
        "display_url" : "pic.twitter.com\/LL55oeVCBA"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "ccot",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "gop",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "maga",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761561854774693888",
    "text" : "To think America would put this pathetic dog and his pandering \"wife\" back in WH is insane. #tcot #ccot #gop #maga https:\/\/t.co\/LL55oeVCBA",
    "id" : 761561854774693888,
    "created_at" : "2016-08-05 13:57:49 +0000",
    "user" : {
      "name" : "John K Stahl",
      "screen_name" : "JohnKStahlUSA",
      "protected" : false,
      "id_str" : "4236806414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665584576161406976\/12xsTXYj_normal.jpg",
      "id" : 4236806414,
      "verified" : false
    }
  },
  "id" : 761686535078944768,
  "created_at" : "2016-08-05 22:13:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Reidy",
      "screen_name" : "dxrpi",
      "indices" : [ 0, 6 ],
      "id_str" : "1330791132",
      "id" : 1330791132
    }, {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 7, 23 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    }, {
      "name" : "Josef_Lokmani",
      "screen_name" : "LokmaniJosef",
      "indices" : [ 32, 45 ],
      "id_str" : "742738059599482884",
      "id" : 742738059599482884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761574650233040897",
  "geo" : { },
  "id_str" : "761686356640698369",
  "in_reply_to_user_id" : 1330791132,
  "text" : "@dxrpi @conserv_tribune Hahahah @LokmaniJosef",
  "id" : 761686356640698369,
  "in_reply_to_status_id" : 761574650233040897,
  "created_at" : "2016-08-05 22:12:33 +0000",
  "in_reply_to_screen_name" : "dxrpi",
  "in_reply_to_user_id_str" : "1330791132",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rico",
      "screen_name" : "tographer",
      "indices" : [ 3, 13 ],
      "id_str" : "1596223609",
      "id" : 1596223609
    }, {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 15, 31 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761686193331253249",
  "text" : "RT @tographer: @conserv_tribune bho does not respect military nor does he respect the US. How much does he have to do before ppl get it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Conservative Tribune",
        "screen_name" : "conserv_tribune",
        "indices" : [ 0, 16 ],
        "id_str" : "2217181338",
        "id" : 2217181338
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761570621222375425",
    "geo" : { },
    "id_str" : "761571029831577600",
    "in_reply_to_user_id" : 2217181338,
    "text" : "@conserv_tribune bho does not respect military nor does he respect the US. How much does he have to do before ppl get it!",
    "id" : 761571029831577600,
    "in_reply_to_status_id" : 761570621222375425,
    "created_at" : "2016-08-05 14:34:17 +0000",
    "in_reply_to_screen_name" : "conserv_tribune",
    "in_reply_to_user_id_str" : "2217181338",
    "user" : {
      "name" : "Rico",
      "screen_name" : "tographer",
      "protected" : false,
      "id_str" : "1596223609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000138384794\/bdfd211bfeb4eb2712559e52b3d0397c_normal.jpeg",
      "id" : 1596223609,
      "verified" : false
    }
  },
  "id" : 761686193331253249,
  "created_at" : "2016-08-05 22:11:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Betts",
      "screen_name" : "JohnFromCranber",
      "indices" : [ 3, 19 ],
      "id_str" : "1065869268",
      "id" : 1065869268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761686122309169152",
  "text" : "RT @JohnFromCranber: MSM Labeling Terrorism as Mental Health Issues....Allowing Yourself to be Consumed by Hatred\/Acting on it, Isn't That\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761577134133501952",
    "text" : "MSM Labeling Terrorism as Mental Health Issues....Allowing Yourself to be Consumed by Hatred\/Acting on it, Isn't That Def of Insanity? #tcot",
    "id" : 761577134133501952,
    "created_at" : "2016-08-05 14:58:32 +0000",
    "user" : {
      "name" : "John Betts",
      "screen_name" : "JohnFromCranber",
      "protected" : false,
      "id_str" : "1065869268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3273171017\/5fa5a2a5d9de3217a7610ca53c134814_normal.jpeg",
      "id" : 1065869268,
      "verified" : false
    }
  },
  "id" : 761686122309169152,
  "created_at" : "2016-08-05 22:11:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "indices" : [ 3, 19 ],
      "id_str" : "2217181338",
      "id" : 2217181338
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/conserv_tribune\/status\/761648360323289088\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/b82PWssxq8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHrJZAVYAAjoX3.jpg",
      "id_str" : "761648358565961728",
      "id" : 761648358565961728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHrJZAVYAAjoX3.jpg",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/b82PWssxq8"
    } ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/N8P8ABtnon",
      "expanded_url" : "http:\/\/conservativetribune.com\/paul-ryan-trumped-by-opponent\/?utm_source=dlvr.it&utm_medium=twitter",
      "display_url" : "conservativetribune.com\/paul-ryan-trum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761685909842518016",
  "text" : "RT @conserv_tribune: Paul Ryan Just Got \u201CTrumped\u201D by His Opponent in Stunning Fashion https:\/\/t.co\/N8P8ABtnon #tcot https:\/\/t.co\/b82PWssxq8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/conserv_tribune\/status\/761648360323289088\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/b82PWssxq8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHrJZAVYAAjoX3.jpg",
        "id_str" : "761648358565961728",
        "id" : 761648358565961728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHrJZAVYAAjoX3.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/b82PWssxq8"
      } ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/N8P8ABtnon",
        "expanded_url" : "http:\/\/conservativetribune.com\/paul-ryan-trumped-by-opponent\/?utm_source=dlvr.it&utm_medium=twitter",
        "display_url" : "conservativetribune.com\/paul-ryan-trum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761648360323289088",
    "text" : "Paul Ryan Just Got \u201CTrumped\u201D by His Opponent in Stunning Fashion https:\/\/t.co\/N8P8ABtnon #tcot https:\/\/t.co\/b82PWssxq8",
    "id" : 761648360323289088,
    "created_at" : "2016-08-05 19:41:34 +0000",
    "user" : {
      "name" : "Conservative Tribune",
      "screen_name" : "conserv_tribune",
      "protected" : false,
      "id_str" : "2217181338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675078788137488384\/b6wGb6cO_normal.jpg",
      "id" : 2217181338,
      "verified" : true
    }
  },
  "id" : 761685909842518016,
  "created_at" : "2016-08-05 22:10:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Rebel",
      "screen_name" : "TheRebelTV",
      "indices" : [ 3, 14 ],
      "id_str" : "3018960919",
      "id" : 3018960919
    }, {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "indices" : [ 40, 56 ],
      "id_str" : "164070785",
      "id" : 164070785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Belgium",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "tcot",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/EWljMSqyQz",
      "expanded_url" : "http:\/\/bit.ly\/2azTYze",
      "display_url" : "bit.ly\/2azTYze"
    } ]
  },
  "geo" : { },
  "id_str" : "761685862979481601",
  "text" : "RT @TheRebelTV: Previously unaired: Why @Lauren_Southern needed security in Molenbeek, #Belgium https:\/\/t.co\/EWljMSqyQz #tcot https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lauren Southern",
        "screen_name" : "Lauren_Southern",
        "indices" : [ 24, 40 ],
        "id_str" : "164070785",
        "id" : 164070785
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheRebelTV\/status\/761656328255180800\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/u1Ppm10zZA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHyXW3UIAACzVw.jpg",
        "id_str" : "761656295090823168",
        "id" : 761656295090823168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHyXW3UIAACzVw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/u1Ppm10zZA"
      } ],
      "hashtags" : [ {
        "text" : "Belgium",
        "indices" : [ 71, 79 ]
      }, {
        "text" : "tcot",
        "indices" : [ 104, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/EWljMSqyQz",
        "expanded_url" : "http:\/\/bit.ly\/2azTYze",
        "display_url" : "bit.ly\/2azTYze"
      } ]
    },
    "geo" : { },
    "id_str" : "761656328255180800",
    "text" : "Previously unaired: Why @Lauren_Southern needed security in Molenbeek, #Belgium https:\/\/t.co\/EWljMSqyQz #tcot https:\/\/t.co\/u1Ppm10zZA",
    "id" : 761656328255180800,
    "created_at" : "2016-08-05 20:13:14 +0000",
    "user" : {
      "name" : "The Rebel",
      "screen_name" : "TheRebelTV",
      "protected" : false,
      "id_str" : "3018960919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588028252897337347\/MxdXWJ-C_normal.png",
      "id" : 3018960919,
      "verified" : true
    }
  },
  "id" : 761685862979481601,
  "created_at" : "2016-08-05 22:10:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Hostis",
      "screen_name" : "patrick_hostis",
      "indices" : [ 3, 18 ],
      "id_str" : "3269495126",
      "id" : 3269495126
    }, {
      "name" : "Carmine Zozzora",
      "screen_name" : "CarmineZozzora",
      "indices" : [ 109, 124 ],
      "id_str" : "2167674121",
      "id" : 2167674121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/1G1ynzKb8X",
      "expanded_url" : "http:\/\/www.foxnews.com\/entertainment\/2016\/08\/05\/michael-bays-13-hours-gets-huge-sales-boost-as-election-nears.html",
      "display_url" : "foxnews.com\/entertainment\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761685815059554304",
  "text" : "RT @patrick_hostis: Michael Bay's '13 Hours' gets huge sales boost as election nears https:\/\/t.co\/1G1ynzKb8X @CarmineZozzora @Chinookpilot6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carmine Zozzora",
        "screen_name" : "CarmineZozzora",
        "indices" : [ 89, 104 ],
        "id_str" : "2167674121",
        "id" : 2167674121
      }, {
        "name" : "Paul Joseph Watson",
        "screen_name" : "PrisonPlanet",
        "indices" : [ 120, 133 ],
        "id_str" : "18643437",
        "id" : 18643437
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/1G1ynzKb8X",
        "expanded_url" : "http:\/\/www.foxnews.com\/entertainment\/2016\/08\/05\/michael-bays-13-hours-gets-huge-sales-boost-as-election-nears.html",
        "display_url" : "foxnews.com\/entertainment\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761657997458235392",
    "text" : "Michael Bay's '13 Hours' gets huge sales boost as election nears https:\/\/t.co\/1G1ynzKb8X @CarmineZozzora @Chinookpilot6 @PrisonPlanet #tcot",
    "id" : 761657997458235392,
    "created_at" : "2016-08-05 20:19:52 +0000",
    "user" : {
      "name" : "Patrick Hostis",
      "screen_name" : "patrick_hostis",
      "protected" : false,
      "id_str" : "3269495126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924081537414397952\/jKUEiKDH_normal.jpg",
      "id" : 3269495126,
      "verified" : false
    }
  },
  "id" : 761685815059554304,
  "created_at" : "2016-08-05 22:10:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Follow Conservatives",
      "screen_name" : "ConservativeFB",
      "indices" : [ 3, 18 ],
      "id_str" : "2505217933",
      "id" : 2505217933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranRansom",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "tcot",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "ObamaScandals",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3FOlCUAZPz",
      "expanded_url" : "http:\/\/www.vivaliberty.com\/iran-spending-400-million-obama-ransom-dollars-on-terror\/",
      "display_url" : "vivaliberty.com\/iran-spending-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761685710998949888",
  "text" : "RT @ConservativeFB: Iran Spending $400 Million \u2018Obama Ransom\u2019 Money on Terror - #IranRansom #tcot #ObamaScandals https:\/\/t.co\/3FOlCUAZPz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranRansom",
        "indices" : [ 60, 71 ]
      }, {
        "text" : "tcot",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "ObamaScandals",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/3FOlCUAZPz",
        "expanded_url" : "http:\/\/www.vivaliberty.com\/iran-spending-400-million-obama-ransom-dollars-on-terror\/",
        "display_url" : "vivaliberty.com\/iran-spending-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761685129060233216",
    "text" : "Iran Spending $400 Million \u2018Obama Ransom\u2019 Money on Terror - #IranRansom #tcot #ObamaScandals https:\/\/t.co\/3FOlCUAZPz",
    "id" : 761685129060233216,
    "created_at" : "2016-08-05 22:07:40 +0000",
    "user" : {
      "name" : "Follow Conservatives",
      "screen_name" : "ConservativeFB",
      "protected" : false,
      "id_str" : "2505217933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468098308758450176\/lYSIMu9V_normal.jpeg",
      "id" : 2505217933,
      "verified" : false
    }
  },
  "id" : 761685710998949888,
  "created_at" : "2016-08-05 22:09:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Arruda",
      "screen_name" : "kavina2011",
      "indices" : [ 3, 14 ],
      "id_str" : "365615067",
      "id" : 365615067
    }, {
      "name" : "The Trump Team",
      "screen_name" : "TrumpWhiteHouse",
      "indices" : [ 16, 32 ],
      "id_str" : "3386688502",
      "id" : 3386688502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761685589389250560",
  "text" : "RT @kavina2011: @TrumpWhiteHouse She is dumb plain and simple!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Trump Team",
        "screen_name" : "TrumpWhiteHouse",
        "indices" : [ 0, 16 ],
        "id_str" : "3386688502",
        "id" : 3386688502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761654443318317057",
    "geo" : { },
    "id_str" : "761654614278148096",
    "in_reply_to_user_id" : 3386688502,
    "text" : "@TrumpWhiteHouse She is dumb plain and simple!",
    "id" : 761654614278148096,
    "in_reply_to_status_id" : 761654443318317057,
    "created_at" : "2016-08-05 20:06:25 +0000",
    "in_reply_to_screen_name" : "TrumpWhiteHouse",
    "in_reply_to_user_id_str" : "3386688502",
    "user" : {
      "name" : "Linda Arruda",
      "screen_name" : "kavina2011",
      "protected" : false,
      "id_str" : "365615067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727883985666383874\/rkKNoIhx_normal.jpg",
      "id" : 365615067,
      "verified" : false
    }
  },
  "id" : 761685589389250560,
  "created_at" : "2016-08-05 22:09:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobo from Texas",
      "screen_name" : "BoboFromTexas",
      "indices" : [ 3, 17 ],
      "id_str" : "2214755390",
      "id" : 2214755390
    }, {
      "name" : "Red Nation Rising",
      "screen_name" : "RedNationRising",
      "indices" : [ 91, 107 ],
      "id_str" : "940368062",
      "id" : 940368062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverHillary",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/1YnGgSoXDo",
      "expanded_url" : "http:\/\/www.cnn.com\/videos\/politics\/2016\/08\/04\/fact-check-hillary-clinton-emails-jake-tapper-origwx-pk.cnn\/video\/playlists\/jake-tapper-factcheck-org\/",
      "display_url" : "cnn.com\/videos\/politic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761685373390946304",
  "text" : "RT @BoboFromTexas: #NeverHillary Even CNN agrees Hillary is a liar https:\/\/t.co\/1YnGgSoXDo @RedNationRising @HahnAmerica @Just_a_Texan @jja\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Nation Rising",
        "screen_name" : "RedNationRising",
        "indices" : [ 72, 88 ],
        "id_str" : "940368062",
        "id" : 940368062
      }, {
        "name" : "Ulysses",
        "screen_name" : "Just_a_Texan",
        "indices" : [ 102, 115 ],
        "id_str" : "884304968",
        "id" : 884304968
      }, {
        "name" : "Janie Johnson",
        "screen_name" : "jjauthor",
        "indices" : [ 116, 125 ],
        "id_str" : "177584156",
        "id" : 177584156
      }, {
        "name" : "PatPeters,PhD.",
        "screen_name" : "PatVPeters",
        "indices" : [ 126, 137 ],
        "id_str" : "33611715",
        "id" : 33611715
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverHillary",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/1YnGgSoXDo",
        "expanded_url" : "http:\/\/www.cnn.com\/videos\/politics\/2016\/08\/04\/fact-check-hillary-clinton-emails-jake-tapper-origwx-pk.cnn\/video\/playlists\/jake-tapper-factcheck-org\/",
        "display_url" : "cnn.com\/videos\/politic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761665844103348224",
    "text" : "#NeverHillary Even CNN agrees Hillary is a liar https:\/\/t.co\/1YnGgSoXDo @RedNationRising @HahnAmerica @Just_a_Texan @jjauthor @PatVPeters",
    "id" : 761665844103348224,
    "created_at" : "2016-08-05 20:51:02 +0000",
    "user" : {
      "name" : "Bobo from Texas",
      "screen_name" : "BoboFromTexas",
      "protected" : false,
      "id_str" : "2214755390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000790612961\/0ed6accff60a6758ca87610746577922_normal.jpeg",
      "id" : 2214755390,
      "verified" : false
    }
  },
  "id" : 761685373390946304,
  "created_at" : "2016-08-05 22:08:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761685329241710592",
  "text" : "RT @realDonaldTrump: If Michael Bloomberg ran again for Mayor of New York, he wouldn't get 10% of the vote - they would run him out of town\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverHillary",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759027356434518016",
    "text" : "If Michael Bloomberg ran again for Mayor of New York, he wouldn't get 10% of the vote - they would run him out of town!  #NeverHillary",
    "id" : 759027356434518016,
    "created_at" : "2016-07-29 14:06:38 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874276197357596672\/kUuht00m_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 761685329241710592,
  "created_at" : "2016-08-05 22:08:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761685186891255808",
  "text" : "RT @Maryamkansari: #SheBelieves that in order to understand what it takes to be great, you need to fail a few times",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761683523807817728",
    "text" : "#SheBelieves that in order to understand what it takes to be great, you need to fail a few times",
    "id" : 761683523807817728,
    "created_at" : "2016-08-05 22:01:18 +0000",
    "user" : {
      "name" : "MK Ansari",
      "screen_name" : "realMKAnsari",
      "protected" : false,
      "id_str" : "94878798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760553804286660608\/nJKJsYyX_normal.jpg",
      "id" : 94878798,
      "verified" : false
    }
  },
  "id" : 761685186891255808,
  "created_at" : "2016-08-05 22:07:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LPGA T&CP",
      "screen_name" : "LPGATeachers",
      "indices" : [ 3, 16 ],
      "id_str" : "2389197264",
      "id" : 2389197264
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lpgateachers\/status\/761683548717801472\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/nSlmSczAr1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpH5dEIXEAALoHK.jpg",
      "id_str" : "761664089722654720",
      "id" : 761664089722654720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpH5dEIXEAALoHK.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 889
      } ],
      "display_url" : "pic.twitter.com\/nSlmSczAr1"
    } ],
    "hashtags" : [ {
      "text" : "FounderFriday",
      "indices" : [ 89, 103 ]
    }, {
      "text" : "SheBelieves",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761685167350030336",
  "text" : "RT @lpgateachers: It all starts with an idea and the belief that you can make it happen. #FounderFriday #SheBelieves https:\/\/t.co\/nSlmSczAr1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lpgateachers\/status\/761683548717801472\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/nSlmSczAr1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpH5dEIXEAALoHK.jpg",
        "id_str" : "761664089722654720",
        "id" : 761664089722654720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpH5dEIXEAALoHK.jpg",
        "sizes" : [ {
          "h" : 386,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 889
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 889
        }, {
          "h" : 505,
          "resize" : "fit",
          "w" : 889
        } ],
        "display_url" : "pic.twitter.com\/nSlmSczAr1"
      } ],
      "hashtags" : [ {
        "text" : "FounderFriday",
        "indices" : [ 71, 85 ]
      }, {
        "text" : "SheBelieves",
        "indices" : [ 86, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761683548717801472",
    "text" : "It all starts with an idea and the belief that you can make it happen. #FounderFriday #SheBelieves https:\/\/t.co\/nSlmSczAr1",
    "id" : 761683548717801472,
    "created_at" : "2016-08-05 22:01:24 +0000",
    "user" : {
      "name" : "LPGA T&CP",
      "screen_name" : "LPGATeachers",
      "protected" : false,
      "id_str" : "2389197264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598210410970505216\/AlTEHq1K_normal.jpg",
      "id" : 2389197264,
      "verified" : false
    }
  },
  "id" : 761685167350030336,
  "created_at" : "2016-08-05 22:07:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Get a Life,Too!",
      "screen_name" : "GetaLifeToo",
      "indices" : [ 3, 15 ],
      "id_str" : "15076486",
      "id" : 15076486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shebelieves",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761685077860290560",
  "text" : "RT @GetaLifeToo: #Shebelieves Self love solves a lot of the worlds problems.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Shebelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761683912821047296",
    "text" : "#Shebelieves Self love solves a lot of the worlds problems.",
    "id" : 761683912821047296,
    "created_at" : "2016-08-05 22:02:50 +0000",
    "user" : {
      "name" : "Get a Life,Too!",
      "screen_name" : "GetaLifeToo",
      "protected" : false,
      "id_str" : "15076486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/824869214619987968\/BxvZoIia_normal.jpg",
      "id" : 15076486,
      "verified" : false
    }
  },
  "id" : 761685077860290560,
  "created_at" : "2016-08-05 22:07:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Swanson",
      "screen_name" : "Scott2Bfree",
      "indices" : [ 3, 15 ],
      "id_str" : "1932989486",
      "id" : 1932989486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Scott2Bfree\/status\/761594911644798976\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/cSGHLqqMZD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpG6h7YVMAImuVr.jpg",
      "id_str" : "761594904040517634",
      "id" : 761594904040517634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpG6h7YVMAImuVr.jpg",
      "sizes" : [ {
        "h" : 543,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/cSGHLqqMZD"
    } ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684902874013696",
  "text" : "RT @Scott2Bfree: #SheBelieves that nothing she says or does will stop Dumb-ocrats from voting for her. https:\/\/t.co\/cSGHLqqMZD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Scott2Bfree\/status\/761594911644798976\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/cSGHLqqMZD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpG6h7YVMAImuVr.jpg",
        "id_str" : "761594904040517634",
        "id" : 761594904040517634,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpG6h7YVMAImuVr.jpg",
        "sizes" : [ {
          "h" : 543,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/cSGHLqqMZD"
      } ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761594911644798976",
    "text" : "#SheBelieves that nothing she says or does will stop Dumb-ocrats from voting for her. https:\/\/t.co\/cSGHLqqMZD",
    "id" : 761594911644798976,
    "created_at" : "2016-08-05 16:09:11 +0000",
    "user" : {
      "name" : "Scott Swanson",
      "screen_name" : "Scott2Bfree",
      "protected" : false,
      "id_str" : "1932989486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798191179129098241\/k69jihp5_normal.jpg",
      "id" : 1932989486,
      "verified" : false
    }
  },
  "id" : 761684902874013696,
  "created_at" : "2016-08-05 22:06:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Johnson",
      "screen_name" : "CritterCreekR",
      "indices" : [ 3, 17 ],
      "id_str" : "71266596",
      "id" : 71266596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684816219676672",
  "text" : "RT @CritterCreekR: #SheBelieves That liberal women will vote for her even though she lied &amp; she &amp; her foundation is profiting from her bein\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761608583381340161",
    "text" : "#SheBelieves That liberal women will vote for her even though she lied &amp; she &amp; her foundation is profiting from her being Sec of State",
    "id" : 761608583381340161,
    "created_at" : "2016-08-05 17:03:30 +0000",
    "user" : {
      "name" : "Cindy Johnson",
      "screen_name" : "CritterCreekR",
      "protected" : false,
      "id_str" : "71266596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685236752399777792\/rDiP8hAI_normal.jpg",
      "id" : 71266596,
      "verified" : false
    }
  },
  "id" : 761684816219676672,
  "created_at" : "2016-08-05 22:06:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IAmAWhistleBlowerToo",
      "screen_name" : "laurapcd1",
      "indices" : [ 3, 13 ],
      "id_str" : "350429629",
      "id" : 350429629
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SHeBelieves",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684723244466176",
  "text" : "RT @laurapcd1: #SHeBelieves her crimes are forgivable by an ignorant electorate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SHeBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761616823360032772",
    "text" : "#SHeBelieves her crimes are forgivable by an ignorant electorate",
    "id" : 761616823360032772,
    "created_at" : "2016-08-05 17:36:15 +0000",
    "user" : {
      "name" : "IAmAWhistleBlowerToo",
      "screen_name" : "laurapcd1",
      "protected" : false,
      "id_str" : "350429629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826171482443304961\/61U058oO_normal.jpg",
      "id" : 350429629,
      "verified" : false
    }
  },
  "id" : 761684723244466176,
  "created_at" : "2016-08-05 22:06:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rothenberg4Justice",
      "screen_name" : "ReelRotation27",
      "indices" : [ 3, 18 ],
      "id_str" : "3382413989",
      "id" : 3382413989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684683025321984",
  "text" : "RT @ReelRotation27: #SheBelieves if she lies and cheats and then plays the misogynist card no one will remember her horrible decisions @Hil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 115, 130 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761623512733876224",
    "text" : "#SheBelieves if she lies and cheats and then plays the misogynist card no one will remember her horrible decisions @HillaryClinton",
    "id" : 761623512733876224,
    "created_at" : "2016-08-05 18:02:50 +0000",
    "user" : {
      "name" : "Rothenberg4Justice",
      "screen_name" : "ReelRotation27",
      "protected" : false,
      "id_str" : "3382413989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703353222061281280\/etcKxaA9_normal.jpg",
      "id" : 3382413989,
      "verified" : false
    }
  },
  "id" : 761684683025321984,
  "created_at" : "2016-08-05 22:05:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Nation Rising",
      "screen_name" : "RedNationRising",
      "indices" : [ 3, 19 ],
      "id_str" : "940368062",
      "id" : 940368062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/4y4nALoYwG",
      "expanded_url" : "http:\/\/patriotretort.com\/obama-the-feminist\/",
      "display_url" : "patriotretort.com\/obama-the-femi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761684546576224256",
  "text" : "RT @RedNationRising: #SheBelieves \"Feminism is an ideology based on fiction. Women and men are not the same\" Read https:\/\/t.co\/4y4nALoYwG h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RedNationRising\/status\/761652676081754112\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/N85j6AGksb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHu449WgAACPIj.jpg",
        "id_str" : "761652473132122112",
        "id" : 761652473132122112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHu449WgAACPIj.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/N85j6AGksb"
      } ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/4y4nALoYwG",
        "expanded_url" : "http:\/\/patriotretort.com\/obama-the-feminist\/",
        "display_url" : "patriotretort.com\/obama-the-femi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761652676081754112",
    "text" : "#SheBelieves \"Feminism is an ideology based on fiction. Women and men are not the same\" Read https:\/\/t.co\/4y4nALoYwG https:\/\/t.co\/N85j6AGksb",
    "id" : 761652676081754112,
    "created_at" : "2016-08-05 19:58:43 +0000",
    "user" : {
      "name" : "Red Nation Rising",
      "screen_name" : "RedNationRising",
      "protected" : false,
      "id_str" : "940368062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649058305072046080\/p0xwM_4E_normal.jpg",
      "id" : 940368062,
      "verified" : false
    }
  },
  "id" : 761684546576224256,
  "created_at" : "2016-08-05 22:05:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684324991115265",
  "text" : "RT @seanhannity: Peters on Iran cash: \"If it was all above board, why an unmarked cargo plane...&amp; why circumvent US law by doing it in Swis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761029674596077568",
    "text" : "Peters on Iran cash: \"If it was all above board, why an unmarked cargo plane...&amp; why circumvent US law by doing it in Swiss francs &amp; Euros?\"",
    "id" : 761029674596077568,
    "created_at" : "2016-08-04 02:43:08 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 761684324991115265,
  "created_at" : "2016-08-05 22:04:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684295580737536",
  "text" : "RT @tedcruz: The most recent piece of evidence that the so-called nuclear deal with the mullahs is fundamentally illegitimate: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/tRZzIHQmDI",
        "expanded_url" : "http:\/\/www.dallasnews.com\/news\/politics\/headlines\/20160803-texans-cruz-mccaul-lead-gop-in-blasting-cash-payments-to-iran.ece",
        "display_url" : "dallasnews.com\/news\/politics\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761010230167678984",
    "text" : "The most recent piece of evidence that the so-called nuclear deal with the mullahs is fundamentally illegitimate: https:\/\/t.co\/tRZzIHQmDI",
    "id" : 761010230167678984,
    "created_at" : "2016-08-04 01:25:52 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 761684295580737536,
  "created_at" : "2016-08-05 22:04:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684202689482752",
  "text" : "RT @BarbaraCorcoran: The worst entrepreneurs on Shark Tank were great presenters with MBAs. I never got the feeling they would be good unde\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761319598520147969",
    "text" : "The worst entrepreneurs on Shark Tank were great presenters with MBAs. I never got the feeling they would be good under real-life pressure.",
    "id" : 761319598520147969,
    "created_at" : "2016-08-04 21:55:11 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 761684202689482752,
  "created_at" : "2016-08-05 22:03:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "indices" : [ 3, 16 ],
      "id_str" : "39357604",
      "id" : 39357604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/EgRPK300wk",
      "expanded_url" : "http:\/\/nr.tn\/2aODTZQ",
      "display_url" : "nr.tn\/2aODTZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "761684145407860736",
  "text" : "RT @NortonOnline: The Future of Cybersecurity May Be with Supercomputers https:\/\/t.co\/EgRPK300wk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/EgRPK300wk",
        "expanded_url" : "http:\/\/nr.tn\/2aODTZQ",
        "display_url" : "nr.tn\/2aODTZQ"
      } ]
    },
    "geo" : { },
    "id_str" : "761683952939765761",
    "text" : "The Future of Cybersecurity May Be with Supercomputers https:\/\/t.co\/EgRPK300wk",
    "id" : 761683952939765761,
    "created_at" : "2016-08-05 22:03:00 +0000",
    "user" : {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "protected" : false,
      "id_str" : "39357604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816328497694199808\/oeI12_Ei_normal.jpg",
      "id" : 39357604,
      "verified" : true
    }
  },
  "id" : 761684145407860736,
  "created_at" : "2016-08-05 22:03:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761684080987480065",
  "text" : "Went to the Detroit Science Center today w\/ some friends. Just nearly a month after the zoo!!!",
  "id" : 761684080987480065,
  "created_at" : "2016-08-05 22:03:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/PCZNALvn5X",
      "expanded_url" : "http:\/\/a.seoclerks.com\/linkin\/13663",
      "display_url" : "a.seoclerks.com\/linkin\/13663"
    } ]
  },
  "geo" : { },
  "id_str" : "761683872614486016",
  "text" : "Check out my affiliate link https:\/\/t.co\/PCZNALvn5X",
  "id" : 761683872614486016,
  "created_at" : "2016-08-05 22:02:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/760888764751310849\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/8NHEK0H441",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co84SuvWYAAJtxd.jpg",
      "id_str" : "760888756484333568",
      "id" : 760888756484333568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co84SuvWYAAJtxd.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8NHEK0H441"
    } ],
    "hashtags" : [ {
      "text" : "Detroiter",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760888764751310849",
  "text" : "Had food from a Food Truck, officially a #Detroiter https:\/\/t.co\/8NHEK0H441",
  "id" : 760888764751310849,
  "created_at" : "2016-08-03 17:23:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/760660706240897024\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/J1vhN6nrhF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co5o4UOW8AA-JiV.jpg",
      "id_str" : "760660703783088128",
      "id" : 760660703783088128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co5o4UOW8AA-JiV.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/J1vhN6nrhF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/aLmMl9RwFq",
      "expanded_url" : "http:\/\/engt.co\/2aMaXmM",
      "display_url" : "engt.co\/2aMaXmM"
    } ]
  },
  "geo" : { },
  "id_str" : "760672759328436224",
  "text" : "RT @engadget: Windows 10 update adds AdBlock support to the Edge browser https:\/\/t.co\/aLmMl9RwFq https:\/\/t.co\/J1vhN6nrhF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/760660706240897024\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/J1vhN6nrhF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co5o4UOW8AA-JiV.jpg",
        "id_str" : "760660703783088128",
        "id" : 760660703783088128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co5o4UOW8AA-JiV.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/J1vhN6nrhF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/aLmMl9RwFq",
        "expanded_url" : "http:\/\/engt.co\/2aMaXmM",
        "display_url" : "engt.co\/2aMaXmM"
      } ]
    },
    "geo" : { },
    "id_str" : "760660706240897024",
    "text" : "Windows 10 update adds AdBlock support to the Edge browser https:\/\/t.co\/aLmMl9RwFq https:\/\/t.co\/J1vhN6nrhF",
    "id" : 760660706240897024,
    "created_at" : "2016-08-03 02:16:59 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 760672759328436224,
  "created_at" : "2016-08-03 03:04:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 14, 23 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/760563504789139457\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/EehMs3eQmm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Co4QdmcUMAA38bQ.jpg",
      "id_str" : "760563487793754112",
      "id" : 760563487793754112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Co4QdmcUMAA38bQ.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 332
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 332
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 332
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 332
      } ],
      "display_url" : "pic.twitter.com\/EehMs3eQmm"
    } ],
    "hashtags" : [ {
      "text" : "XboxOneS",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760672692446134274",
  "text" : "RT @ijustine: @ijustine #XboxOneS https:\/\/t.co\/EehMs3eQmm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justine Ezarik \uD83D\uDCF1",
        "screen_name" : "ijustine",
        "indices" : [ 0, 9 ],
        "id_str" : "7846",
        "id" : 7846
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/760563504789139457\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/EehMs3eQmm",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Co4QdmcUMAA38bQ.jpg",
        "id_str" : "760563487793754112",
        "id" : 760563487793754112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Co4QdmcUMAA38bQ.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 332
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 332
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 332
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 332
        } ],
        "display_url" : "pic.twitter.com\/EehMs3eQmm"
      } ],
      "hashtags" : [ {
        "text" : "XboxOneS",
        "indices" : [ 10, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760563433162940416",
    "geo" : { },
    "id_str" : "760563504789139457",
    "in_reply_to_user_id" : 7846,
    "text" : "@ijustine #XboxOneS https:\/\/t.co\/EehMs3eQmm",
    "id" : 760563504789139457,
    "in_reply_to_status_id" : 760563433162940416,
    "created_at" : "2016-08-02 19:50:44 +0000",
    "in_reply_to_screen_name" : "ijustine",
    "in_reply_to_user_id_str" : "7846",
    "user" : {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911802990469595137\/qm4zwu1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 760672692446134274,
  "created_at" : "2016-08-03 03:04:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/760534004957413377\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uk17VLKYVb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co31pTxXYAAIWZ8.jpg",
      "id_str" : "760534002126249984",
      "id" : 760534002126249984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co31pTxXYAAIWZ8.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/uk17VLKYVb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760672342070726656",
  "text" : "RT @rockindigo: Who else still playing the old pok\u00E9mon? https:\/\/t.co\/uk17VLKYVb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/760534004957413377\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/uk17VLKYVb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co31pTxXYAAIWZ8.jpg",
        "id_str" : "760534002126249984",
        "id" : 760534002126249984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co31pTxXYAAIWZ8.jpg",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/uk17VLKYVb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760534004957413377",
    "text" : "Who else still playing the old pok\u00E9mon? https:\/\/t.co\/uk17VLKYVb",
    "id" : 760534004957413377,
    "created_at" : "2016-08-02 17:53:31 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 760672342070726656,
  "created_at" : "2016-08-03 03:03:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760672247262609409",
  "text" : "RT @scrowder: Shooting our biggest video yet today. Hidden camera required mayor approval and police permits. Hold onto your butts...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760540478622294016",
    "text" : "Shooting our biggest video yet today. Hidden camera required mayor approval and police permits. Hold onto your butts...",
    "id" : 760540478622294016,
    "created_at" : "2016-08-02 18:19:14 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 760672247262609409,
  "created_at" : "2016-08-03 03:02:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/760581568025034752\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UBJ9wPSMjK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co4g5y_WEAAemdJ.jpg",
      "id_str" : "760581564384284672",
      "id" : 760581564384284672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co4g5y_WEAAemdJ.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/UBJ9wPSMjK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/xqsUv9llEe",
      "expanded_url" : "http:\/\/engt.co\/2aLlRJA",
      "display_url" : "engt.co\/2aLlRJA"
    } ]
  },
  "geo" : { },
  "id_str" : "760672081528889345",
  "text" : "RT @engadget: Everything you need to know about Samsung's Galaxy Note 7 event https:\/\/t.co\/xqsUv9llEe https:\/\/t.co\/UBJ9wPSMjK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/760581568025034752\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/UBJ9wPSMjK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co4g5y_WEAAemdJ.jpg",
        "id_str" : "760581564384284672",
        "id" : 760581564384284672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co4g5y_WEAAemdJ.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/UBJ9wPSMjK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/xqsUv9llEe",
        "expanded_url" : "http:\/\/engt.co\/2aLlRJA",
        "display_url" : "engt.co\/2aLlRJA"
      } ]
    },
    "geo" : { },
    "id_str" : "760581568025034752",
    "text" : "Everything you need to know about Samsung's Galaxy Note 7 event https:\/\/t.co\/xqsUv9llEe https:\/\/t.co\/UBJ9wPSMjK",
    "id" : 760581568025034752,
    "created_at" : "2016-08-02 21:02:31 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 760672081528889345,
  "created_at" : "2016-08-03 03:02:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760671689638305793",
  "text" : "RT @Matthiasiam: Seems like the only song Luna likes when I hum is the theme song from \"Gilligans Island\" Odd choice, but I won't judge you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760645133322756096",
    "text" : "Seems like the only song Luna likes when I hum is the theme song from \"Gilligans Island\" Odd choice, but I won't judge you love.",
    "id" : 760645133322756096,
    "created_at" : "2016-08-03 01:15:06 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 760671689638305793,
  "created_at" : "2016-08-03 03:00:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "djminimatt",
      "indices" : [ 3, 14 ],
      "id_str" : "3315671131",
      "id" : 3315671131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760275538535587840",
  "text" : "RT @djminimatt: I'm a dog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746718269588004864",
    "text" : "I'm a dog",
    "id" : 746718269588004864,
    "created_at" : "2016-06-25 14:54:43 +0000",
    "user" : {
      "name" : "Matt",
      "screen_name" : "djminimatt",
      "protected" : false,
      "id_str" : "3315671131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895688705335218176\/Fvt9m7z2_normal.jpg",
      "id" : 3315671131,
      "verified" : false
    }
  },
  "id" : 760275538535587840,
  "created_at" : "2016-08-02 00:46:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Steak 'n Shake",
      "screen_name" : "SteaknShake",
      "indices" : [ 73, 85 ],
      "id_str" : "567562934",
      "id" : 567562934
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/754092419986124800\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/pK35qMvraE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CncTDerWIAApNwe.jpg",
      "id_str" : "754092413103251456",
      "id" : 754092413103251456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncTDerWIAApNwe.jpg",
      "sizes" : [ {
        "h" : 1195,
        "resize" : "fit",
        "w" : 1790
      }, {
        "h" : 1195,
        "resize" : "fit",
        "w" : 1790
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/pK35qMvraE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760275331018137600",
  "text" : "RT @ijustine: In NYC making Oreo Red Velvet milkshakes (and messes) with @steaknshake \uD83D\uDE02 https:\/\/t.co\/pK35qMvraE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steak 'n Shake",
        "screen_name" : "SteaknShake",
        "indices" : [ 59, 71 ],
        "id_str" : "567562934",
        "id" : 567562934
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ijustine\/status\/754092419986124800\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/pK35qMvraE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CncTDerWIAApNwe.jpg",
        "id_str" : "754092413103251456",
        "id" : 754092413103251456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CncTDerWIAApNwe.jpg",
        "sizes" : [ {
          "h" : 1195,
          "resize" : "fit",
          "w" : 1790
        }, {
          "h" : 1195,
          "resize" : "fit",
          "w" : 1790
        }, {
          "h" : 801,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/pK35qMvraE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754092419986124800",
    "text" : "In NYC making Oreo Red Velvet milkshakes (and messes) with @steaknshake \uD83D\uDE02 https:\/\/t.co\/pK35qMvraE",
    "id" : 754092419986124800,
    "created_at" : "2016-07-15 23:16:57 +0000",
    "user" : {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911802990469595137\/qm4zwu1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 760275331018137600,
  "created_at" : "2016-08-02 00:45:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadeshot",
      "screen_name" : "Nadeshot",
      "indices" : [ 3, 12 ],
      "id_str" : "161418822",
      "id" : 161418822
    }, {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 14, 23 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760274658767675392",
  "text" : "RT @Nadeshot: @ijustine THE SKY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justine Ezarik \uD83D\uDCF1",
        "screen_name" : "ijustine",
        "indices" : [ 0, 9 ],
        "id_str" : "7846",
        "id" : 7846
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "759435736206618624",
    "geo" : { },
    "id_str" : "759436360990150658",
    "in_reply_to_user_id" : 7846,
    "text" : "@ijustine THE SKY",
    "id" : 759436360990150658,
    "in_reply_to_status_id" : 759435736206618624,
    "created_at" : "2016-07-30 17:11:52 +0000",
    "in_reply_to_screen_name" : "ijustine",
    "in_reply_to_user_id_str" : "7846",
    "user" : {
      "name" : "Nadeshot",
      "screen_name" : "Nadeshot",
      "protected" : false,
      "id_str" : "161418822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841909077726924800\/MNzQtEaz_normal.jpg",
      "id" : 161418822,
      "verified" : true
    }
  },
  "id" : 760274658767675392,
  "created_at" : "2016-08-02 00:42:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760274638010142720",
  "text" : "RT @ijustine: So, what's up?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759435736206618624",
    "text" : "So, what's up?",
    "id" : 759435736206618624,
    "created_at" : "2016-07-30 17:09:23 +0000",
    "user" : {
      "name" : "Justine Ezarik \uD83D\uDCF1",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911802990469595137\/qm4zwu1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 760274638010142720,
  "created_at" : "2016-08-02 00:42:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JW Harnisch",
      "screen_name" : "jwharnisch",
      "indices" : [ 3, 14 ],
      "id_str" : "66394878",
      "id" : 66394878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jwharnisch\/status\/760268806518214656\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Ip3TP9ikRH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co0EbSVUIAApAfW.jpg",
      "id_str" : "760268778919698432",
      "id" : 760268778919698432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co0EbSVUIAApAfW.jpg",
      "sizes" : [ {
        "h" : 373,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/Ip3TP9ikRH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760274184018677760",
  "text" : "RT @jwharnisch: Do not pray for an easy life, pray for the strength to endure a difficult one. \n-- Bruce Lee https:\/\/t.co\/Ip3TP9ikRH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jwharnisch\/status\/760268806518214656\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Ip3TP9ikRH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co0EbSVUIAApAfW.jpg",
        "id_str" : "760268778919698432",
        "id" : 760268778919698432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co0EbSVUIAApAfW.jpg",
        "sizes" : [ {
          "h" : 373,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/Ip3TP9ikRH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760268806518214656",
    "text" : "Do not pray for an easy life, pray for the strength to endure a difficult one. \n-- Bruce Lee https:\/\/t.co\/Ip3TP9ikRH",
    "id" : 760268806518214656,
    "created_at" : "2016-08-02 00:19:43 +0000",
    "user" : {
      "name" : "JW Harnisch",
      "screen_name" : "jwharnisch",
      "protected" : true,
      "id_str" : "66394878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871429779789987840\/q8rv8u85_normal.jpg",
      "id" : 66394878,
      "verified" : false
    }
  },
  "id" : 760274184018677760,
  "created_at" : "2016-08-02 00:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SjPkJzjLOk",
      "expanded_url" : "https:\/\/twitter.com\/TheJSnyder\/status\/759588052691922945",
      "display_url" : "twitter.com\/TheJSnyder\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760273361033310208",
  "text" : "RT @MarkDice: If twitter had an IQ test to have an account, you wouldn't be here. https:\/\/t.co\/SjPkJzjLOk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/SjPkJzjLOk",
        "expanded_url" : "https:\/\/twitter.com\/TheJSnyder\/status\/759588052691922945",
        "display_url" : "twitter.com\/TheJSnyder\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759649897863782400",
    "text" : "If twitter had an IQ test to have an account, you wouldn't be here. https:\/\/t.co\/SjPkJzjLOk",
    "id" : 759649897863782400,
    "created_at" : "2016-07-31 07:20:23 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 760273361033310208,
  "created_at" : "2016-08-02 00:37:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Seunagal",
      "screen_name" : "ClassySnobbb",
      "indices" : [ 3, 16 ],
      "id_str" : "2499295284",
      "id" : 2499295284
    }, {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 18, 27 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760273025413419008",
  "text" : "RT @ClassySnobbb: @MarkDice @YouTube This is so false lol. Trump is not gonna ban tampons. \uD83D\uDE02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 0, 9 ],
        "id_str" : "35039490",
        "id" : 35039490
      }, {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 10, 18 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760169233825222656",
    "geo" : { },
    "id_str" : "760169470803505152",
    "in_reply_to_user_id" : 35039490,
    "text" : "@MarkDice @YouTube This is so false lol. Trump is not gonna ban tampons. \uD83D\uDE02",
    "id" : 760169470803505152,
    "in_reply_to_status_id" : 760169233825222656,
    "created_at" : "2016-08-01 17:44:59 +0000",
    "in_reply_to_screen_name" : "MarkDice",
    "in_reply_to_user_id_str" : "35039490",
    "user" : {
      "name" : "Gabrielle Seunagal",
      "screen_name" : "ClassySnobbb",
      "protected" : false,
      "id_str" : "2499295284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925849907575033856\/WuVSzQLe_normal.jpg",
      "id" : 2499295284,
      "verified" : false
    }
  },
  "id" : 760273025413419008,
  "created_at" : "2016-08-02 00:36:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0299\u026A\u0274\u1D00\u0280\u028F \u1D00\u0262\u1D07\u0274\u1D1B",
      "screen_name" : "binaryagent",
      "indices" : [ 3, 15 ],
      "id_str" : "23186908",
      "id" : 23186908
    }, {
      "name" : "EvaC",
      "screen_name" : "1roughjourney",
      "indices" : [ 17, 31 ],
      "id_str" : "4581084917",
      "id" : 4581084917
    }, {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 32, 41 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNCleak",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760272547078283265",
  "text" : "RT @binaryagent: @1roughjourney @MarkDice You think \"real news\" is trust worthy?  #DNCleak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EvaC",
        "screen_name" : "1roughjourney",
        "indices" : [ 0, 14 ],
        "id_str" : "4581084917",
        "id" : 4581084917
      }, {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 15, 24 ],
        "id_str" : "35039490",
        "id" : 35039490
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DNCleak",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "759582280385953792",
    "geo" : { },
    "id_str" : "759667941910671364",
    "in_reply_to_user_id" : 4581084917,
    "text" : "@1roughjourney @MarkDice You think \"real news\" is trust worthy?  #DNCleak",
    "id" : 759667941910671364,
    "in_reply_to_status_id" : 759582280385953792,
    "created_at" : "2016-07-31 08:32:05 +0000",
    "in_reply_to_screen_name" : "1roughjourney",
    "in_reply_to_user_id_str" : "4581084917",
    "user" : {
      "name" : "\u0299\u026A\u0274\u1D00\u0280\u028F \u1D00\u0262\u1D07\u0274\u1D1B",
      "screen_name" : "binaryagent",
      "protected" : false,
      "id_str" : "23186908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906991940503293952\/LVjv3JqV_normal.jpg",
      "id" : 23186908,
      "verified" : false
    }
  },
  "id" : 760272547078283265,
  "created_at" : "2016-08-02 00:34:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 17, 24 ],
      "id_str" : "16228398",
      "id" : 16228398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IronyAlert",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760272278382751744",
  "text" : "RT @MarkDice: So @mcuban calls Trump a \"jagoff\" during his endorsement of Hillary Satan. #IronyAlert",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 3, 10 ],
        "id_str" : "16228398",
        "id" : 16228398
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IronyAlert",
        "indices" : [ 75, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759778059167739904",
    "text" : "So @mcuban calls Trump a \"jagoff\" during his endorsement of Hillary Satan. #IronyAlert",
    "id" : 759778059167739904,
    "created_at" : "2016-07-31 15:49:39 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 760272278382751744,
  "created_at" : "2016-08-02 00:33:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/PWqfpJz4sV",
      "expanded_url" : "https:\/\/www.facebook.com\/MarkDice\/videos\/1199180070127377\/",
      "display_url" : "facebook.com\/MarkDice\/video\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760272245465821186",
  "text" : "RT @MarkDice: Liberal Zombies Endorse Paul Ryan as Hillary's VP Running Mate!   https:\/\/t.co\/PWqfpJz4sV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/PWqfpJz4sV",
        "expanded_url" : "https:\/\/www.facebook.com\/MarkDice\/videos\/1199180070127377\/",
        "display_url" : "facebook.com\/MarkDice\/video\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759831075216433152",
    "text" : "Liberal Zombies Endorse Paul Ryan as Hillary's VP Running Mate!   https:\/\/t.co\/PWqfpJz4sV",
    "id" : 759831075216433152,
    "created_at" : "2016-07-31 19:20:19 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 760272245465821186,
  "created_at" : "2016-08-02 00:33:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/TPb5o5krFK",
      "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/760185303483187201",
      "display_url" : "twitter.com\/realDonaldTrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760249500812374016",
  "text" : "RT @hannahbleau_: I'd be lying if I said I wasn't enjoying this. https:\/\/t.co\/TPb5o5krFK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/TPb5o5krFK",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/760185303483187201",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760202414242660357",
    "text" : "I'd be lying if I said I wasn't enjoying this. https:\/\/t.co\/TPb5o5krFK",
    "id" : 760202414242660357,
    "created_at" : "2016-08-01 19:55:54 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 760249500812374016,
  "created_at" : "2016-08-01 23:03:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/760228961402097665\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/ItQzX8LhGP",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CozgNYfXEAAhQ5_.jpg",
      "id_str" : "760228957635678208",
      "id" : 760228957635678208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CozgNYfXEAAhQ5_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/ItQzX8LhGP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760249096426950656",
  "text" : "RT @rockindigo: And what can u call this https:\/\/t.co\/ItQzX8LhGP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/760228961402097665\/photo\/1",
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/ItQzX8LhGP",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CozgNYfXEAAhQ5_.jpg",
        "id_str" : "760228957635678208",
        "id" : 760228957635678208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CozgNYfXEAAhQ5_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/ItQzX8LhGP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760228961402097665",
    "text" : "And what can u call this https:\/\/t.co\/ItQzX8LhGP",
    "id" : 760228961402097665,
    "created_at" : "2016-08-01 21:41:23 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 760249096426950656,
  "created_at" : "2016-08-01 23:01:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/760233697161388032\/video\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/y6wTsIFlyz",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760233646766915588\/pu\/img\/N0Gsqa3dUP1Lj_G1.jpg",
      "id_str" : "760233646766915588",
      "id" : 760233646766915588,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760233646766915588\/pu\/img\/N0Gsqa3dUP1Lj_G1.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y6wTsIFlyz"
    } ],
    "hashtags" : [ {
      "text" : "2A",
      "indices" : [ 22, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/hfTJwJtFcI",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=MW_noXjj6w8",
      "display_url" : "youtube.com\/watch?v=MW_noX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760248894399840256",
  "text" : "RT @scrowder: Why the #2A was meant for militia only. Except it wasn't. FULL VIDEO &gt;&gt; https:\/\/t.co\/hfTJwJtFcI https:\/\/t.co\/y6wTsIFlyz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/760233697161388032\/video\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/y6wTsIFlyz",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760233646766915588\/pu\/img\/N0Gsqa3dUP1Lj_G1.jpg",
        "id_str" : "760233646766915588",
        "id" : 760233646766915588,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760233646766915588\/pu\/img\/N0Gsqa3dUP1Lj_G1.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/y6wTsIFlyz"
      } ],
      "hashtags" : [ {
        "text" : "2A",
        "indices" : [ 8, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/hfTJwJtFcI",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=MW_noXjj6w8",
        "display_url" : "youtube.com\/watch?v=MW_noX\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760233697161388032",
    "text" : "Why the #2A was meant for militia only. Except it wasn't. FULL VIDEO &gt;&gt; https:\/\/t.co\/hfTJwJtFcI https:\/\/t.co\/y6wTsIFlyz",
    "id" : 760233697161388032,
    "created_at" : "2016-08-01 22:00:12 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 760248894399840256,
  "created_at" : "2016-08-01 23:00:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FullRepeal",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/IeWvSy6rQG",
      "expanded_url" : "https:\/\/www.tedcruz.org\/l\/full-repeal-obamacare\/",
      "display_url" : "tedcruz.org\/l\/full-repeal-\u2026"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/jxIoKjlJyT",
      "expanded_url" : "http:\/\/www.houstonchronicle.com\/opinion\/outlook\/article\/Greener-Premium-hikes-under-Obamacare-9003177.php",
      "display_url" : "houstonchronicle.com\/opinion\/outloo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760248771716509697",
  "text" : "RT @tedcruz: Add your name if you agree we need a #FullRepeal of Obamacare: https:\/\/t.co\/IeWvSy6rQG\n\nhttps:\/\/t.co\/jxIoKjlJyT https:\/\/t.co\/F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/760231951773016064\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/FBA20aJp9J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cozi2XRUIAAYsPs.jpg",
        "id_str" : "760231860706222080",
        "id" : 760231860706222080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cozi2XRUIAAYsPs.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 2160
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/FBA20aJp9J"
      } ],
      "hashtags" : [ {
        "text" : "FullRepeal",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/IeWvSy6rQG",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/full-repeal-obamacare\/",
        "display_url" : "tedcruz.org\/l\/full-repeal-\u2026"
      }, {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/jxIoKjlJyT",
        "expanded_url" : "http:\/\/www.houstonchronicle.com\/opinion\/outlook\/article\/Greener-Premium-hikes-under-Obamacare-9003177.php",
        "display_url" : "houstonchronicle.com\/opinion\/outloo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760231951773016064",
    "text" : "Add your name if you agree we need a #FullRepeal of Obamacare: https:\/\/t.co\/IeWvSy6rQG\n\nhttps:\/\/t.co\/jxIoKjlJyT https:\/\/t.co\/FBA20aJp9J",
    "id" : 760231951773016064,
    "created_at" : "2016-08-01 21:53:16 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 760248771716509697,
  "created_at" : "2016-08-01 23:00:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 14, 25 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760247566776885248",
  "text" : "RT @coastpml: @jacksfilms HAHAHAH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jacksfilms",
        "screen_name" : "jacksfilms",
        "indices" : [ 0, 11 ],
        "id_str" : "9989862",
        "id" : 9989862
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760221200895266817",
    "geo" : { },
    "id_str" : "760221287381741568",
    "in_reply_to_user_id" : 9989862,
    "text" : "@jacksfilms HAHAHAH",
    "id" : 760221287381741568,
    "in_reply_to_status_id" : 760221200895266817,
    "created_at" : "2016-08-01 21:10:53 +0000",
    "in_reply_to_screen_name" : "jacksfilms",
    "in_reply_to_user_id_str" : "9989862",
    "user" : {
      "name" : "stupid eya|\uD83D\uDCCC",
      "screen_name" : "lovscki",
      "protected" : false,
      "id_str" : "3272506130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927302426050248704\/oNbSKQW9_normal.jpg",
      "id" : 3272506130,
      "verified" : false
    }
  },
  "id" : 760247566776885248,
  "created_at" : "2016-08-01 22:55:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BananaExtremeAwesome",
      "screen_name" : "BananaAwsome",
      "indices" : [ 3, 16 ],
      "id_str" : "2357547593",
      "id" : 2357547593
    }, {
      "name" : "Renee Young",
      "screen_name" : "ReneeYoungWWE",
      "indices" : [ 18, 32 ],
      "id_str" : "70725301",
      "id" : 70725301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760247296617570304",
  "text" : "RT @BananaAwsome: @ReneeYoungWWE Time traveller confirmed?  ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Renee Young",
        "screen_name" : "ReneeYoungWWE",
        "indices" : [ 0, 14 ],
        "id_str" : "70725301",
        "id" : 70725301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760243093572431872",
    "geo" : { },
    "id_str" : "760243896546918400",
    "in_reply_to_user_id" : 70725301,
    "text" : "@ReneeYoungWWE Time traveller confirmed?  ;)",
    "id" : 760243896546918400,
    "in_reply_to_status_id" : 760243093572431872,
    "created_at" : "2016-08-01 22:40:44 +0000",
    "in_reply_to_screen_name" : "ReneeYoungWWE",
    "in_reply_to_user_id_str" : "70725301",
    "user" : {
      "name" : "BananaExtremeAwesome",
      "screen_name" : "BananaAwsome",
      "protected" : false,
      "id_str" : "2357547593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885968640490819584\/xotslPF__normal.jpg",
      "id" : 2357547593,
      "verified" : false
    }
  },
  "id" : 760247296617570304,
  "created_at" : "2016-08-01 22:54:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Foster",
      "screen_name" : "JTFoster92",
      "indices" : [ 3, 14 ],
      "id_str" : "90000575",
      "id" : 90000575
    }, {
      "name" : "Renee Young",
      "screen_name" : "ReneeYoungWWE",
      "indices" : [ 16, 30 ],
      "id_str" : "70725301",
      "id" : 70725301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760247269883056128",
  "text" : "RT @JTFoster92: @ReneeYoungWWE 1985? Great Scott!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Renee Young",
        "screen_name" : "ReneeYoungWWE",
        "indices" : [ 0, 14 ],
        "id_str" : "70725301",
        "id" : 70725301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760243093572431872",
    "geo" : { },
    "id_str" : "760243840548638720",
    "in_reply_to_user_id" : 70725301,
    "text" : "@ReneeYoungWWE 1985? Great Scott!",
    "id" : 760243840548638720,
    "in_reply_to_status_id" : 760243093572431872,
    "created_at" : "2016-08-01 22:40:30 +0000",
    "in_reply_to_screen_name" : "ReneeYoungWWE",
    "in_reply_to_user_id_str" : "70725301",
    "user" : {
      "name" : "Justin Foster",
      "screen_name" : "JTFoster92",
      "protected" : false,
      "id_str" : "90000575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776099713842053124\/DU2t8b4I_normal.jpg",
      "id" : 90000575,
      "verified" : false
    }
  },
  "id" : 760247269883056128,
  "created_at" : "2016-08-01 22:54:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Int_Marketing",
      "screen_name" : "intmarketingtip",
      "indices" : [ 3, 19 ],
      "id_str" : "168872039",
      "id" : 168872039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/b7YvvdJMWt",
      "expanded_url" : "http:\/\/bit.ly\/2agJxB1",
      "display_url" : "bit.ly\/2agJxB1"
    } ]
  },
  "geo" : { },
  "id_str" : "760246596990885888",
  "text" : "RT @intmarketingtip: Sales And Support: Why Everyone On Your Team Should Have A Role In Both https:\/\/t.co\/b7YvvdJMWt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/b7YvvdJMWt",
        "expanded_url" : "http:\/\/bit.ly\/2agJxB1",
        "display_url" : "bit.ly\/2agJxB1"
      } ]
    },
    "geo" : { },
    "id_str" : "760243874707025920",
    "text" : "Sales And Support: Why Everyone On Your Team Should Have A Role In Both https:\/\/t.co\/b7YvvdJMWt",
    "id" : 760243874707025920,
    "created_at" : "2016-08-01 22:40:39 +0000",
    "user" : {
      "name" : "Int_Marketing",
      "screen_name" : "intmarketingtip",
      "protected" : false,
      "id_str" : "168872039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1082372791\/CRAZY_TWITTER_BIRDY__bigger_normal.jpg",
      "id" : 168872039,
      "verified" : false
    }
  },
  "id" : 760246596990885888,
  "created_at" : "2016-08-01 22:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 0, 12 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758418192154984448",
  "geo" : { },
  "id_str" : "760245808243539972",
  "in_reply_to_user_id" : 44184316,
  "text" : "@Matthiasiam so you want Gatorade and dessert basically?",
  "id" : 760245808243539972,
  "in_reply_to_status_id" : 758418192154984448,
  "created_at" : "2016-08-01 22:48:20 +0000",
  "in_reply_to_screen_name" : "Matthiasiam",
  "in_reply_to_user_id_str" : "44184316",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 0, 12 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/760245683119063040\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1YkJj3o4Zv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CozvZR7WEAA_hjH.jpg",
      "id_str" : "760245654706851840",
      "id" : 760245654706851840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CozvZR7WEAA_hjH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 358
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 358
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 358
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 358
      } ],
      "display_url" : "pic.twitter.com\/1YkJj3o4Zv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760245683119063040",
  "in_reply_to_user_id" : 44184316,
  "text" : "@Matthiasiam I love Mathias's sass and Amanda's cruelty, it makes the show so much more fun, lol. https:\/\/t.co\/1YkJj3o4Zv",
  "id" : 760245683119063040,
  "created_at" : "2016-08-01 22:47:50 +0000",
  "in_reply_to_screen_name" : "Matthiasiam",
  "in_reply_to_user_id_str" : "44184316",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hjpGWNsCDI",
      "expanded_url" : "https:\/\/twitter.com\/daryldixonsbabe\/status\/759885297312231424",
      "display_url" : "twitter.com\/daryldixonsbab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760245550935642112",
  "text" : "RT @Matthiasiam: It's ok. I'm happy our community is so full of love, excitement, and support for our new family. \u263A\uFE0F https:\/\/t.co\/hjpGWNsCDI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/hjpGWNsCDI",
        "expanded_url" : "https:\/\/twitter.com\/daryldixonsbabe\/status\/759885297312231424",
        "display_url" : "twitter.com\/daryldixonsbab\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759885798090997760",
    "text" : "It's ok. I'm happy our community is so full of love, excitement, and support for our new family. \u263A\uFE0F https:\/\/t.co\/hjpGWNsCDI",
    "id" : 759885798090997760,
    "created_at" : "2016-07-31 22:57:46 +0000",
    "user" : {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920451058958180352\/e5iV978B_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 760245550935642112,
  "created_at" : "2016-08-01 22:47:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoubleStandard",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760244127963447296",
  "text" : "I am waiting for the New York Times to reveal Obama's mom or Hillary's husband but no just Melania #DoubleStandard",
  "id" : 760244127963447296,
  "created_at" : "2016-08-01 22:41:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760201237711249408",
  "text" : "Man wish today was better!!! *sighs",
  "id" : 760201237711249408,
  "created_at" : "2016-08-01 19:51:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]