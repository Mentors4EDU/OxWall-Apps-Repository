Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/vixkd5gkKX",
      "expanded_url" : "http:\/\/www.teslamotors.com\/blog\/supercharging-milestone",
      "display_url" : "teslamotors.com\/blog\/superchar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "495035812744945664",
  "text" : "RT @elonmusk: Tesla Superchargers delivered over 1GWh last month. Long distance driving growing exponentially http:\/\/t.co\/vixkd5gkKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/vixkd5gkKX",
        "expanded_url" : "http:\/\/www.teslamotors.com\/blog\/supercharging-milestone",
        "display_url" : "teslamotors.com\/blog\/superchar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487279300895191041",
    "text" : "Tesla Superchargers delivered over 1GWh last month. Long distance driving growing exponentially http:\/\/t.co\/vixkd5gkKX",
    "id" : 487279300895191041,
    "created_at" : "2014-07-10 16:56:53 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 495035812744945664,
  "created_at" : "2014-08-01 02:38:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495035638593232897",
  "text" : "People can get saved, they just need a bit of faith",
  "id" : 495035638593232897,
  "created_at" : "2014-08-01 02:37:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495034252283490304",
  "text" : "RT @elonmusk: Flight 10 of Falcon 9 was good. All six ORBCOMM satellites deployed on target.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488717037674311682",
    "text" : "Flight 10 of Falcon 9 was good. All six ORBCOMM satellites deployed on target.",
    "id" : 488717037674311682,
    "created_at" : "2014-07-14 16:09:56 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 495034252283490304,
  "created_at" : "2014-08-01 02:32:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 0, 15 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495033973056106496",
  "in_reply_to_user_id" : 2687742392,
  "text" : "@VigilantChrist My sister yostina is into IHOP, christian science, and have wrong views on Christianity, make a video for people like her :\/",
  "id" : 495033973056106496,
  "created_at" : "2014-08-01 02:31:11 +0000",
  "in_reply_to_screen_name" : "VigilantChrist",
  "in_reply_to_user_id_str" : "2687742392",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "494702689624653826",
  "text" : "Going to make tons of stuff soon",
  "id" : 494702689624653826,
  "created_at" : "2014-07-31 04:34:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "indices" : [ 3, 10 ],
      "id_str" : "150248263",
      "id" : 150248263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/9rovZRs2Q3",
      "expanded_url" : "http:\/\/bit.ly\/1s4AvuK",
      "display_url" : "bit.ly\/1s4AvuK"
    } ]
  },
  "geo" : { },
  "id_str" : "494702327656226817",
  "text" : "RT @fiverr: 6 skills that every entrepreneur needs to start (and maintain) a thriving business: http:\/\/t.co\/9rovZRs2Q3 http:\/\/t.co\/yljSeXr9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fiverr\/status\/494633569629663232\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/yljSeXr9mt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt1KnCaCMAEV_N_.jpg",
        "id_str" : "494633568602042369",
        "id" : 494633568602042369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt1KnCaCMAEV_N_.jpg",
        "sizes" : [ {
          "h" : 507,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/yljSeXr9mt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9rovZRs2Q3",
        "expanded_url" : "http:\/\/bit.ly\/1s4AvuK",
        "display_url" : "bit.ly\/1s4AvuK"
      } ]
    },
    "geo" : { },
    "id_str" : "494633569629663232",
    "text" : "6 skills that every entrepreneur needs to start (and maintain) a thriving business: http:\/\/t.co\/9rovZRs2Q3 http:\/\/t.co\/yljSeXr9mt",
    "id" : 494633569629663232,
    "created_at" : "2014-07-31 00:00:07 +0000",
    "user" : {
      "name" : "Fiverr",
      "screen_name" : "fiverr",
      "protected" : false,
      "id_str" : "150248263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818489482345201665\/owRu5UmW_normal.jpg",
      "id" : 150248263,
      "verified" : true
    }
  },
  "id" : 494702327656226817,
  "created_at" : "2014-07-31 04:33:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDx",
      "screen_name" : "TEDx",
      "indices" : [ 3, 8 ],
      "id_str" : "18080969",
      "id" : 18080969
    }, {
      "name" : "TEDxAlcoi",
      "screen_name" : "TEDxAlcoi",
      "indices" : [ 46, 56 ],
      "id_str" : "2155407427",
      "id" : 2155407427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/7eN2wxTd3v",
      "expanded_url" : "http:\/\/on.ted.com\/a0KBu",
      "display_url" : "on.ted.com\/a0KBu"
    } ]
  },
  "geo" : { },
  "id_str" : "494700909503344640",
  "text" : "RT @TEDx: An iPad app makes art come alive at @TEDxAlcoi in Spain: http:\/\/t.co\/7eN2wxTd3v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDxAlcoi",
        "screen_name" : "TEDxAlcoi",
        "indices" : [ 36, 46 ],
        "id_str" : "2155407427",
        "id" : 2155407427
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/7eN2wxTd3v",
        "expanded_url" : "http:\/\/on.ted.com\/a0KBu",
        "display_url" : "on.ted.com\/a0KBu"
      } ]
    },
    "geo" : { },
    "id_str" : "491960135519313920",
    "text" : "An iPad app makes art come alive at @TEDxAlcoi in Spain: http:\/\/t.co\/7eN2wxTd3v",
    "id" : 491960135519313920,
    "created_at" : "2014-07-23 14:56:51 +0000",
    "user" : {
      "name" : "TEDx",
      "screen_name" : "TEDx",
      "protected" : false,
      "id_str" : "18080969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875374464334213120\/un2sxt2O_normal.jpg",
      "id" : 18080969,
      "verified" : true
    }
  },
  "id" : 494700909503344640,
  "created_at" : "2014-07-31 04:27:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/dv6DM5ng1P",
      "expanded_url" : "http:\/\/1drv.ms\/1kl81wU",
      "display_url" : "1drv.ms\/1kl81wU"
    } ]
  },
  "geo" : { },
  "id_str" : "494193025438867456",
  "text" : "The nice homemade dinner http:\/\/t.co\/dv6DM5ng1P",
  "id" : 494193025438867456,
  "created_at" : "2014-07-29 18:49:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493912572546920451",
  "text" : "Can't believe I missed makerfaire but when grandma comes she comes, I may present next year, not sure yet ;)",
  "id" : 493912572546920451,
  "created_at" : "2014-07-29 00:15:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Heckendorn",
      "screen_name" : "benheck",
      "indices" : [ 3, 11 ],
      "id_str" : "27889546",
      "id" : 27889546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493912075836481539",
  "text" : "RT @benheck: Maker Faire Detroit is very impressive. Wish I had more time to see everything!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "493142206769659904",
    "text" : "Maker Faire Detroit is very impressive. Wish I had more time to see everything!",
    "id" : 493142206769659904,
    "created_at" : "2014-07-26 21:13:58 +0000",
    "user" : {
      "name" : "Ben Heckendorn",
      "screen_name" : "benheck",
      "protected" : false,
      "id_str" : "27889546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832450248316301312\/pjVZ4cr3_normal.jpg",
      "id" : 27889546,
      "verified" : false
    }
  },
  "id" : 493912075836481539,
  "created_at" : "2014-07-29 00:13:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493911399114895360",
  "text" : "Although the best baker in the world would be my cousin Marvie :)",
  "id" : 493911399114895360,
  "created_at" : "2014-07-29 00:10:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/xGRujEf9US",
      "expanded_url" : "http:\/\/1drv.ms\/1uBuTfX",
      "display_url" : "1drv.ms\/1uBuTfX"
    } ]
  },
  "geo" : { },
  "id_str" : "493911112455159808",
  "text" : "Taste so nice, made by my grandma, the best cook in the world :) http:\/\/t.co\/xGRujEf9US",
  "id" : 493911112455159808,
  "created_at" : "2014-07-29 00:09:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Man Vs. Food",
      "screen_name" : "man_vs_food",
      "indices" : [ 0, 12 ],
      "id_str" : "283678841",
      "id" : 283678841
    }, {
      "name" : "Randy Santel",
      "screen_name" : "RandySantel",
      "indices" : [ 16, 28 ],
      "id_str" : "382454309",
      "id" : 382454309
    }, {
      "name" : "Furious Pete",
      "screen_name" : "FuriousPete",
      "indices" : [ 32, 44 ],
      "id_str" : "143507261",
      "id" : 143507261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493559309918167042",
  "in_reply_to_user_id" : 283678841,
  "text" : "@man_vs_food vs @RandySantel vs @FuriousPete who would eat faster?",
  "id" : 493559309918167042,
  "created_at" : "2014-07-28 00:51:24 +0000",
  "in_reply_to_screen_name" : "man_vs_food",
  "in_reply_to_user_id_str" : "283678841",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cupcake Crew",
      "screen_name" : "CupcakeCrewNYC",
      "indices" : [ 0, 15 ],
      "id_str" : "181722616",
      "id" : 181722616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492514392698019841",
  "in_reply_to_user_id" : 181722616,
  "text" : "@CupcakeCrewNYC I think you should apologize for the ignorant comments you said about Israel and Hitler. As for now I am boycotting you.",
  "id" : 492514392698019841,
  "created_at" : "2014-07-25 03:39:16 +0000",
  "in_reply_to_screen_name" : "CupcakeCrewNYC",
  "in_reply_to_user_id_str" : "181722616",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/492337208075251712\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/hTsLcHRqoT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUiFPzIEAAAsFe.jpg",
      "id_str" : "492337207802597376",
      "id" : 492337207802597376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUiFPzIEAAAsFe.jpg",
      "sizes" : [ {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1224
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1224
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/hTsLcHRqoT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492513011110649858",
  "text" : "RT @colin_furze: France we are ready to go at 6pm http:\/\/t.co\/hTsLcHRqoT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/492337208075251712\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/hTsLcHRqoT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtUiFPzIEAAAsFe.jpg",
        "id_str" : "492337207802597376",
        "id" : 492337207802597376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtUiFPzIEAAAsFe.jpg",
        "sizes" : [ {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/hTsLcHRqoT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492337208075251712",
    "text" : "France we are ready to go at 6pm http:\/\/t.co\/hTsLcHRqoT",
    "id" : 492337208075251712,
    "created_at" : "2014-07-24 15:55:12 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 492513011110649858,
  "created_at" : "2014-07-25 03:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492512917799985153",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze Can you do a draw my life, your fans would love to hear more about you!!",
  "id" : 492512917799985153,
  "created_at" : "2014-07-25 03:33:24 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/9JjuGitLVq",
      "expanded_url" : "http:\/\/1drv.ms\/1p2uVFk",
      "display_url" : "1drv.ms\/1p2uVFk"
    } ]
  },
  "geo" : { },
  "id_str" : "491269611636015106",
  "text" : "Had some yesterday, tasted so good http:\/\/t.co\/9JjuGitLVq",
  "id" : 491269611636015106,
  "created_at" : "2014-07-21 17:12:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 125, 133 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/67oao4pFEU",
      "expanded_url" : "http:\/\/youtu.be\/NrYL49FI0L0",
      "display_url" : "youtu.be\/NrYL49FI0L0"
    } ]
  },
  "geo" : { },
  "id_str" : "489932367415349248",
  "text" : "RT @colin_furze: The biggest JET ive ever made is done Fart@France Update 2 THE PULSEJET IS MADE: http:\/\/t.co\/67oao4pFEU via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 108, 116 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/67oao4pFEU",
        "expanded_url" : "http:\/\/youtu.be\/NrYL49FI0L0",
        "display_url" : "youtu.be\/NrYL49FI0L0"
      } ]
    },
    "geo" : { },
    "id_str" : "487659581980434432",
    "text" : "The biggest JET ive ever made is done Fart@France Update 2 THE PULSEJET IS MADE: http:\/\/t.co\/67oao4pFEU via @YouTube",
    "id" : 487659581980434432,
    "created_at" : "2014-07-11 18:07:59 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 489932367415349248,
  "created_at" : "2014-07-18 00:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Cauguiran",
      "screen_name" : "kidguru",
      "indices" : [ 0, 8 ],
      "id_str" : "11828962",
      "id" : 11828962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489932123239755776",
  "in_reply_to_user_id" : 11828962,
  "text" : "@kidguru Hey adrain, I have been using you for years in reviewing my windows apps and iphone apps, do you by chance also do android?",
  "id" : 489932123239755776,
  "created_at" : "2014-07-18 00:38:15 +0000",
  "in_reply_to_screen_name" : "kidguru",
  "in_reply_to_user_id_str" : "11828962",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndofAmerica",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488200931947708417",
  "text" : "RT @MarkDice: Has the government bought the illegal aliens their own iPads yet with our tax dollars?  They probably will.  #EndofAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EndofAmerica",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "487619133463224321",
    "text" : "Has the government bought the illegal aliens their own iPads yet with our tax dollars?  They probably will.  #EndofAmerica",
    "id" : 487619133463224321,
    "created_at" : "2014-07-11 15:27:15 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 488200931947708417,
  "created_at" : "2014-07-13 05:59:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LYsxkGCApG",
      "expanded_url" : "http:\/\/www.examiner.com\/article\/of-10-highest-iq-s-on-earth-at-least-8-are-theists-at-least-6-are-christians",
      "display_url" : "examiner.com\/article\/of-10-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488200288176582656",
  "text" : "http:\/\/t.co\/LYsxkGCApG",
  "id" : 488200288176582656,
  "created_at" : "2014-07-13 05:56:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/w97bhoejzD",
      "expanded_url" : "http:\/\/1drv.ms\/1nqgZrO",
      "display_url" : "1drv.ms\/1nqgZrO"
    } ]
  },
  "geo" : { },
  "id_str" : "488073257866637312",
  "text" : "Went to a party, here is some of my family members eating sushi, lol http:\/\/t.co\/w97bhoejzD",
  "id" : 488073257866637312,
  "created_at" : "2014-07-12 21:31:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/rz5o2JZY2V",
      "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/07\/08\/science\/colin-furze-self-taught-engineer-and-diy-superhero.html?_r=0",
      "display_url" : "mobile.nytimes.com\/2014\/07\/08\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487237131572891648",
  "text" : "RT @colin_furze: Yes furze is in the new york times http:\/\/t.co\/rz5o2JZY2V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/rz5o2JZY2V",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2014\/07\/08\/science\/colin-furze-self-taught-engineer-and-diy-superhero.html?_r=0",
        "display_url" : "mobile.nytimes.com\/2014\/07\/08\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486056390650511360",
    "text" : "Yes furze is in the new york times http:\/\/t.co\/rz5o2JZY2V",
    "id" : 486056390650511360,
    "created_at" : "2014-07-07 07:57:28 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 487237131572891648,
  "created_at" : "2014-07-10 14:09:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Belmont",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487236621826539520",
  "text" : "#Belmont is one of my favorite ice cream brands. I like flavors such as mango, mint chip, and cookies &amp; cream. Just thought you should know.",
  "id" : 487236621826539520,
  "created_at" : "2014-07-10 14:07:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487034220792270848",
  "text" : "RT @MarkDice: Most Americans have such poor work ethic these days and are so lazy, the only thing they can finish is a meal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486988534847655936",
    "text" : "Most Americans have such poor work ethic these days and are so lazy, the only thing they can finish is a meal.",
    "id" : 486988534847655936,
    "created_at" : "2014-07-09 21:41:29 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 487034220792270848,
  "created_at" : "2014-07-10 00:43:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Rf5nhJjI3c",
      "expanded_url" : "http:\/\/1drv.ms\/1nfJI2w",
      "display_url" : "1drv.ms\/1nfJI2w"
    } ]
  },
  "geo" : { },
  "id_str" : "487032961955397632",
  "text" : "Went paddle boating couple hours ago, so worth it!!! RT http:\/\/t.co\/Rf5nhJjI3c",
  "id" : 487032961955397632,
  "created_at" : "2014-07-10 00:38:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/qex8IceU5f",
      "expanded_url" : "http:\/\/1drv.ms\/1r9FnhH",
      "display_url" : "1drv.ms\/1r9FnhH"
    } ]
  },
  "geo" : { },
  "id_str" : "487031493907079170",
  "text" : "RT for pizza http:\/\/t.co\/qex8IceU5f",
  "id" : 487031493907079170,
  "created_at" : "2014-07-10 00:32:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peggy Sturgess",
      "screen_name" : "Pegstur1005",
      "indices" : [ 3, 15 ],
      "id_str" : "27179975",
      "id" : 27179975
    }, {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 20, 29 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/L5zynaaOVp",
      "expanded_url" : "http:\/\/youtu.be\/CCdllgcFjlY",
      "display_url" : "youtu.be\/CCdllgcFjlY"
    } ]
  },
  "geo" : { },
  "id_str" : "486925020703494146",
  "text" : "RT @Pegstur1005: RT @MarkDice  Christian Churches Accepting Bribe Money from Government To Deceive Attendees  http:\/\/t.co\/L5zynaaOVp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 3, 12 ],
        "id_str" : "35039490",
        "id" : 35039490
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/L5zynaaOVp",
        "expanded_url" : "http:\/\/youtu.be\/CCdllgcFjlY",
        "display_url" : "youtu.be\/CCdllgcFjlY"
      } ]
    },
    "geo" : { },
    "id_str" : "486843275752378368",
    "text" : "RT @MarkDice  Christian Churches Accepting Bribe Money from Government To Deceive Attendees  http:\/\/t.co\/L5zynaaOVp",
    "id" : 486843275752378368,
    "created_at" : "2014-07-09 12:04:16 +0000",
    "user" : {
      "name" : "Peggy Sturgess",
      "screen_name" : "Pegstur1005",
      "protected" : false,
      "id_str" : "27179975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523884970364788737\/gDS3JVAD_normal.jpeg",
      "id" : 27179975,
      "verified" : false
    }
  },
  "id" : 486925020703494146,
  "created_at" : "2014-07-09 17:29:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486924713424601089",
  "text" : "Have you tried Kroger's barbeque chicken? I tried it couple days ago, and it was 4.3\/5 stars, was really good though!!! JUST RANDOM THOUGHT",
  "id" : 486924713424601089,
  "created_at" : "2014-07-09 17:27:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/OGc2FrXmAJ",
      "expanded_url" : "http:\/\/1drv.ms\/1suwG1s",
      "display_url" : "1drv.ms\/1suwG1s"
    } ]
  },
  "geo" : { },
  "id_str" : "486678212575895552",
  "text" : "Had those ears from the fun fair I went to. http:\/\/t.co\/OGc2FrXmAJ",
  "id" : 486678212575895552,
  "created_at" : "2014-07-09 01:08:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kilikina",
      "screen_name" : "XtyMiller",
      "indices" : [ 3, 13 ],
      "id_str" : "18431625",
      "id" : 18431625
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 80, 88 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/249nO4Sdit",
      "expanded_url" : "http:\/\/youtu.be\/PnVAD4CBRUg",
      "display_url" : "youtu.be\/PnVAD4CBRUg"
    } ]
  },
  "geo" : { },
  "id_str" : "486223288029691904",
  "text" : "RT @XtyMiller: Know Your Enemy - Evolution EXPOSED ! http:\/\/t.co\/249nO4Sdit via @youtube TheVigilantChristian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 65, 73 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/249nO4Sdit",
        "expanded_url" : "http:\/\/youtu.be\/PnVAD4CBRUg",
        "display_url" : "youtu.be\/PnVAD4CBRUg"
      } ]
    },
    "geo" : { },
    "id_str" : "336510220689870848",
    "text" : "Know Your Enemy - Evolution EXPOSED ! http:\/\/t.co\/249nO4Sdit via @youtube TheVigilantChristian",
    "id" : 336510220689870848,
    "created_at" : "2013-05-20 15:54:23 +0000",
    "user" : {
      "name" : "Kilikina",
      "screen_name" : "XtyMiller",
      "protected" : false,
      "id_str" : "18431625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1008591535\/my_spirit_normal.jpg",
      "id" : 18431625,
      "verified" : false
    }
  },
  "id" : 486223288029691904,
  "created_at" : "2014-07-07 19:00:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486223049713528832",
  "text" : "RT @MarkDice: For every corrupt man, there is a woman willing to look the other way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486181365176483840",
    "text" : "For every corrupt man, there is a woman willing to look the other way.",
    "id" : 486181365176483840,
    "created_at" : "2014-07-07 16:14:04 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 486223049713528832,
  "created_at" : "2014-07-07 18:59:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/DGu82M91rx",
      "expanded_url" : "http:\/\/1drv.ms\/1zkqXjw",
      "display_url" : "1drv.ms\/1zkqXjw"
    } ]
  },
  "geo" : { },
  "id_str" : "486212808619458560",
  "text" : "Had Greek salad, fried kibbi and chicken at the Oasis in Kentucky. 4.3\/5 stars. http:\/\/t.co\/DGu82M91rx",
  "id" : 486212808619458560,
  "created_at" : "2014-07-07 18:19:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1lbdnZWOco",
      "expanded_url" : "http:\/\/1drv.ms\/1zkhRDB",
      "display_url" : "1drv.ms\/1zkhRDB"
    } ]
  },
  "geo" : { },
  "id_str" : "486192951828025346",
  "text" : "Got a 244 in bowling yesterday in 10 pin cross rounds, also had red pepper lebnah, so good!!! http:\/\/t.co\/1lbdnZWOco",
  "id" : 486192951828025346,
  "created_at" : "2014-07-07 17:00:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/7nhz7ipT5B",
      "expanded_url" : "http:\/\/1drv.ms\/1jTYQ0H",
      "display_url" : "1drv.ms\/1jTYQ0H"
    } ]
  },
  "geo" : { },
  "id_str" : "485494989141463041",
  "text" : "Yummy!! http:\/\/t.co\/7nhz7ipT5B",
  "id" : 485494989141463041,
  "created_at" : "2014-07-05 18:46:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BETAwards",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483977350883721216",
  "text" : "RT @MarkDice: I guess it's racist to point out facts.  #BETAwards",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BETAwards",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483685449509396480",
    "text" : "I guess it's racist to point out facts.  #BETAwards",
    "id" : 483685449509396480,
    "created_at" : "2014-06-30 18:56:12 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 483977350883721216,
  "created_at" : "2014-07-01 14:16:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NdqRXZ1Ehf",
      "expanded_url" : "http:\/\/1drv.ms\/1mgX9jo",
      "display_url" : "1drv.ms\/1mgX9jo"
    } ]
  },
  "geo" : { },
  "id_str" : "483976996158832641",
  "text" : "Had cappuccino made by my mom, now I am going to have some amazing aged cheese!! http:\/\/t.co\/NdqRXZ1Ehf",
  "id" : 483976996158832641,
  "created_at" : "2014-07-01 14:14:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]