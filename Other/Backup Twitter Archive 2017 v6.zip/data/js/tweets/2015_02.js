Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 14, 28 ],
      "id_str" : "80979832",
      "id" : 80979832
    }, {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 33, 45 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571027276373950464",
  "text" : "Please follow @CopticOrphans and @copticworld They are two awesome organizations.",
  "id" : 571027276373950464,
  "created_at" : "2015-02-26 19:21:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571026909116510208",
  "text" : "Thanks for all the shout outs everybody, I couldn't retweet and respond to all.",
  "id" : 571026909116510208,
  "created_at" : "2015-02-26 19:19:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universo Curioso",
      "screen_name" : "UniversCurioso",
      "indices" : [ 3, 18 ],
      "id_str" : "2775541771",
      "id" : 2775541771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ERM",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571026360740679680",
  "text" : "RT @UniversCurioso: Voc\u00EA sabia? O maior QI registrado at\u00E9 hoje pertence a Andrew Magdy Kamal, QI de 231.\n#ERM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ERM",
        "indices" : [ 85, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569224866718736384",
    "text" : "Voc\u00EA sabia? O maior QI registrado at\u00E9 hoje pertence a Andrew Magdy Kamal, QI de 231.\n#ERM",
    "id" : 569224866718736384,
    "created_at" : "2015-02-21 19:59:18 +0000",
    "user" : {
      "name" : "Universo Curioso",
      "screen_name" : "UniversCurioso",
      "protected" : false,
      "id_str" : "2775541771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816681174445723649\/v8uimGwF_normal.jpg",
      "id" : 2775541771,
      "verified" : false
    }
  },
  "id" : 571026360740679680,
  "created_at" : "2015-02-26 19:17:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571025687428993024",
  "text" : "Spring break is apparently here, and it doesn't even feel like spring, lol \uD83D\uDE01",
  "id" : 571025687428993024,
  "created_at" : "2015-02-26 19:15:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 65, 77 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Online",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "video",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "course",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "Udemy",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "sougofollow",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aU2hg7v84p",
      "expanded_url" : "http:\/\/coupontru.mp\/6fa93b",
      "display_url" : "coupontru.mp\/6fa93b"
    } ]
  },
  "geo" : { },
  "id_str" : "569960207238852609",
  "text" : "RT @CouponTrump: #Online #video #course IT Survival Guide #Udemy @gamer456148 #sougofollow http:\/\/t.co\/aU2hg7v84p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.coupontrump.com\" rel=\"nofollow\"\u003ECpnt_Autotweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 48, 60 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Online",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "video",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "course",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "Udemy",
        "indices" : [ 41, 47 ]
      }, {
        "text" : "sougofollow",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/aU2hg7v84p",
        "expanded_url" : "http:\/\/coupontru.mp\/6fa93b",
        "display_url" : "coupontru.mp\/6fa93b"
      } ]
    },
    "geo" : { },
    "id_str" : "569959876773851136",
    "text" : "#Online #video #course IT Survival Guide #Udemy @gamer456148 #sougofollow http:\/\/t.co\/aU2hg7v84p",
    "id" : 569959876773851136,
    "created_at" : "2015-02-23 20:39:58 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 569960207238852609,
  "created_at" : "2015-02-23 20:41:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 78, 90 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Online",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "video",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "course",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "Udemy",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "sougofollow",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ezjKQKVklc",
      "expanded_url" : "http:\/\/coupontru.mp\/dda4be",
      "display_url" : "coupontru.mp\/dda4be"
    } ]
  },
  "geo" : { },
  "id_str" : "569958485363810304",
  "text" : "RT @CouponTrump: #Online #video #course Common Core Math Concepts: K-8 #Udemy @gamer456148 #sougofollow http:\/\/t.co\/ezjKQKVklc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.coupontrump.com\" rel=\"nofollow\"\u003ECpnt_Autotweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 61, 73 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Online",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "video",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "course",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "Udemy",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "sougofollow",
        "indices" : [ 74, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ezjKQKVklc",
        "expanded_url" : "http:\/\/coupontru.mp\/dda4be",
        "display_url" : "coupontru.mp\/dda4be"
      } ]
    },
    "geo" : { },
    "id_str" : "569957852225282049",
    "text" : "#Online #video #course Common Core Math Concepts: K-8 #Udemy @gamer456148 #sougofollow http:\/\/t.co\/ezjKQKVklc",
    "id" : 569957852225282049,
    "created_at" : "2015-02-23 20:31:55 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 569958485363810304,
  "created_at" : "2015-02-23 20:34:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/569619021676433408\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uVs8E1UXJD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-exe2uCUAA0InZ.jpg",
      "id_str" : "569619021528453120",
      "id" : 569619021528453120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-exe2uCUAA0InZ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uVs8E1UXJD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569619021676433408",
  "text" : "Ate Fajitas then got silver dollars from the trade center, was out with my ma. Good day. http:\/\/t.co\/uVs8E1UXJD",
  "id" : 569619021676433408,
  "created_at" : "2015-02-22 22:05:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569163510464143360",
  "text" : "Turkish delight, so yummy, one of my favorite snacks!!!",
  "id" : 569163510464143360,
  "created_at" : "2015-02-21 15:55:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 37, 40 ]
    }, {
      "text" : "Wearthebear",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568475666846523393",
  "text" : "My life is filled with so much drama #OU #Wearthebear",
  "id" : 568475666846523393,
  "created_at" : "2015-02-19 18:22:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567790841335672832",
  "text" : "RT @elonmusk: Rocket soft landed in the ocean within 10m of target &amp; nicely vertical! High probability of good droneship landing in non-sto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565659578915115011",
    "text" : "Rocket soft landed in the ocean within 10m of target &amp; nicely vertical! High probability of good droneship landing in non-stormy weather.",
    "id" : 565659578915115011,
    "created_at" : "2015-02-11 23:52:07 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 567790841335672832,
  "created_at" : "2015-02-17 21:01:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/565716774260576262\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/7EY25g3IU5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9nUaKjIMAAPR55.jpg",
      "id_str" : "565716774185086976",
      "id" : 565716774185086976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9nUaKjIMAAPR55.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 702
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7EY25g3IU5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567790801142456320",
  "text" : "RT @elonmusk: Landing on a stormy sea http:\/\/t.co\/7EY25g3IU5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/565716774260576262\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/7EY25g3IU5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9nUaKjIMAAPR55.jpg",
        "id_str" : "565716774185086976",
        "id" : 565716774185086976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9nUaKjIMAAPR55.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 702
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7EY25g3IU5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565716774260576262",
    "text" : "Landing on a stormy sea http:\/\/t.co\/7EY25g3IU5",
    "id" : 565716774260576262,
    "created_at" : "2015-02-12 03:39:24 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 567790801142456320,
  "created_at" : "2015-02-17 21:00:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 0, 9 ],
      "id_str" : "17468189",
      "id" : 17468189
    }, {
      "name" : "Oakland Engineering",
      "screen_name" : "OUSECS",
      "indices" : [ 10, 17 ],
      "id_str" : "1911748507",
      "id" : 1911748507
    }, {
      "name" : "Cyber OU",
      "screen_name" : "CyberOU",
      "indices" : [ 18, 26 ],
      "id_str" : "1329353672",
      "id" : 1329353672
    }, {
      "name" : "General Motors",
      "screen_name" : "GM",
      "indices" : [ 27, 30 ],
      "id_str" : "10850192",
      "id" : 10850192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "567771901528137730",
  "geo" : { },
  "id_str" : "567790596078755841",
  "in_reply_to_user_id" : 17468189,
  "text" : "@oaklandu @OUSECS @CyberOU @GM That is so cool, hopefully they will talk about Open SSL Vulnerabilities, sadly can't make it to this one.",
  "id" : 567790596078755841,
  "in_reply_to_status_id" : 567771901528137730,
  "created_at" : "2015-02-17 21:00:01 +0000",
  "in_reply_to_screen_name" : "oaklandu",
  "in_reply_to_user_id_str" : "17468189",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katie stout",
      "screen_name" : "ummmsmile",
      "indices" : [ 75, 85 ],
      "id_str" : "2825743064",
      "id" : 2825743064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567769127705710593",
  "text" : "Watching Katie's quirkiness and relaxed attitude makes you want a hug, lol @ummmsmile",
  "id" : 567769127705710593,
  "created_at" : "2015-02-17 19:34:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567767266512658433",
  "text" : "Glad to see Walker's son @Walkermatt16 taking an interested in politics, like father like son.",
  "id" : 567767266512658433,
  "created_at" : "2015-02-17 19:27:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy \u30C4",
      "screen_name" : "JustOneAsian",
      "indices" : [ 3, 16 ],
      "id_str" : "263330949",
      "id" : 263330949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567746199420407808",
  "text" : "RT @JustOneAsian: i admire people who choose to smile after all the things they\u2019ve been through",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567746098094440448",
    "text" : "i admire people who choose to smile after all the things they\u2019ve been through",
    "id" : 567746098094440448,
    "created_at" : "2015-02-17 18:03:12 +0000",
    "user" : {
      "name" : "Tommy \u30C4",
      "screen_name" : "JustOneAsian",
      "protected" : false,
      "id_str" : "263330949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869483520946692097\/_MLcNlNg_normal.jpg",
      "id" : 263330949,
      "verified" : false
    }
  },
  "id" : 567746199420407808,
  "created_at" : "2015-02-17 18:03:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "indices" : [ 0, 11 ],
      "id_str" : "2876894477",
      "id" : 2876894477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567731921744961537",
  "in_reply_to_user_id" : 2876894477,
  "text" : "@Carley_IMF So upset she went home, but this is not the last you will see of her, I guarantee it. She is an amazingly talented designer.",
  "id" : 567731921744961537,
  "created_at" : "2015-02-17 17:06:52 +0000",
  "in_reply_to_screen_name" : "Carley_IMF",
  "in_reply_to_user_id_str" : "2876894477",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "indices" : [ 3, 14 ],
      "id_str" : "2876894477",
      "id" : 2876894477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EllenDesignOnHGTV",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567512092836503552",
  "text" : "RT @Carley_IMF: Look at all of those sexy couches!! #EllenDesignOnHGTV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EllenDesignOnHGTV",
        "indices" : [ 36, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567511466853810176",
    "text" : "Look at all of those sexy couches!! #EllenDesignOnHGTV",
    "id" : 567511466853810176,
    "created_at" : "2015-02-17 02:30:52 +0000",
    "user" : {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "protected" : false,
      "id_str" : "2876894477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553371133349605377\/-YUneFDz_normal.png",
      "id" : 2876894477,
      "verified" : false
    }
  },
  "id" : 567512092836503552,
  "created_at" : "2015-02-17 02:33:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567511572877033472",
  "text" : "My fellow students haven't welcomed me with open arms. Oh well. Can't wait tell the summer",
  "id" : 567511572877033472,
  "created_at" : "2015-02-17 02:31:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567511412113539074",
  "text" : "Yeah turned out that Katy person not so honest, who knows if she even was honest about her name.",
  "id" : 567511412113539074,
  "created_at" : "2015-02-17 02:30:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 3, 12 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oaklandu\/status\/567062954374610944\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5sjNX7pykp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96crr1CUAA9xFD.jpg",
      "id_str" : "567062877408743424",
      "id" : 567062877408743424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96crr1CUAA9xFD.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5sjNX7pykp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567088009728630784",
  "text" : "RT @oaklandu: Just announced: The black top court won the most votes and will be the new design for the O'rena. http:\/\/t.co\/5sjNX7pykp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oaklandu\/status\/567062954374610944\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/5sjNX7pykp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B96crr1CUAA9xFD.jpg",
        "id_str" : "567062877408743424",
        "id" : 567062877408743424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96crr1CUAA9xFD.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5sjNX7pykp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567062954374610944",
    "text" : "Just announced: The black top court won the most votes and will be the new design for the O'rena. http:\/\/t.co\/5sjNX7pykp",
    "id" : 567062954374610944,
    "created_at" : "2015-02-15 20:48:38 +0000",
    "user" : {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "protected" : false,
      "id_str" : "17468189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474898532759912448\/Dxj_fOZo_normal.jpeg",
      "id" : 17468189,
      "verified" : true
    }
  },
  "id" : 567088009728630784,
  "created_at" : "2015-02-15 22:28:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 3, 12 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567087963348013057",
  "text" : "RT @oaklandu: New attendance record at the O\u2019rena: 4,101 #ThisIsOU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThisIsOU",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567079390451097600",
    "text" : "New attendance record at the O\u2019rena: 4,101 #ThisIsOU",
    "id" : 567079390451097600,
    "created_at" : "2015-02-15 21:53:57 +0000",
    "user" : {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "protected" : false,
      "id_str" : "17468189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474898532759912448\/Dxj_fOZo_normal.jpeg",
      "id" : 17468189,
      "verified" : true
    }
  },
  "id" : 567087963348013057,
  "created_at" : "2015-02-15 22:28:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567087764017922049",
  "text" : "Then there was Ahmed Naseem which was a Junior at Oakland. Overall Oakland students always welcome each other with Open arms.",
  "id" : 567087764017922049,
  "created_at" : "2015-02-15 22:27:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567087581020438528",
  "text" : "Met a nice person named Katy that goes to OU for Industrial Engineering, but sadly got the contact details misspelled.",
  "id" : 567087581020438528,
  "created_at" : "2015-02-15 22:26:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Golden Grizzlies",
      "screen_name" : "GoldenGrizzlies",
      "indices" : [ 3, 19 ],
      "id_str" : "21891180",
      "id" : 21891180
    }, {
      "name" : "Oakland Basketball",
      "screen_name" : "OaklandMBB",
      "indices" : [ 75, 86 ],
      "id_str" : "2860750384",
      "id" : 2860750384
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoMercy",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "MetroSeries",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "WearTheBear",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567019165912170496",
  "text" : "RT @GoldenGrizzlies: It's finally here! GAME DAY! See you at the O'rena as @OaklandMBB takes on UDM! #NoMercy #MetroSeries #WearTheBear htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oakland Basketball",
        "screen_name" : "OaklandMBB",
        "indices" : [ 54, 65 ],
        "id_str" : "2860750384",
        "id" : 2860750384
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GoldenGrizzlies\/status\/566966230318583808\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/c1Qu0SuWne",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B95Ex19CAAA3HJE.jpg",
        "id_str" : "566966226182602752",
        "id" : 566966226182602752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B95Ex19CAAA3HJE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 791
        } ],
        "display_url" : "pic.twitter.com\/c1Qu0SuWne"
      } ],
      "hashtags" : [ {
        "text" : "NoMercy",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "MetroSeries",
        "indices" : [ 89, 101 ]
      }, {
        "text" : "WearTheBear",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566966230318583808",
    "text" : "It's finally here! GAME DAY! See you at the O'rena as @OaklandMBB takes on UDM! #NoMercy #MetroSeries #WearTheBear http:\/\/t.co\/c1Qu0SuWne",
    "id" : 566966230318583808,
    "created_at" : "2015-02-15 14:24:17 +0000",
    "user" : {
      "name" : "Golden Grizzlies",
      "screen_name" : "GoldenGrizzlies",
      "protected" : false,
      "id_str" : "21891180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514142431818678272\/jzMbOukt_normal.jpeg",
      "id" : 21891180,
      "verified" : true
    }
  },
  "id" : 567019165912170496,
  "created_at" : "2015-02-15 17:54:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/567018822415441922\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/eniBH1Fqf5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B950nSlIMAElO1h.jpg",
      "id_str" : "567018821446545409",
      "id" : 567018821446545409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B950nSlIMAElO1h.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/eniBH1Fqf5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567018822415441922",
  "text" : "At OU Tailgate :) http:\/\/t.co\/eniBH1Fqf5",
  "id" : 567018822415441922,
  "created_at" : "2015-02-15 17:53:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/566638717897412608\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nsWVapRR6X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B90a6V_CYAEdsWl.jpg",
      "id_str" : "566638717754826753",
      "id" : 566638717754826753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B90a6V_CYAEdsWl.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nsWVapRR6X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566638717897412608",
  "text" : "Got my drivers license certificate, then went out for dessert with my ma, then shoveled the snow, good day!!! http:\/\/t.co\/nsWVapRR6X",
  "id" : 566638717897412608,
  "created_at" : "2015-02-14 16:42:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566273066095767552",
  "text" : "Oh I ought to be......",
  "id" : 566273066095767552,
  "created_at" : "2015-02-13 16:29:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566272973565214721",
  "text" : "Colin Furze made a Microwave-Freezer Hybrid, maybe next he can make a Lightsaber-Gun Hybrid.",
  "id" : 566272973565214721,
  "created_at" : "2015-02-13 16:29:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 48, 60 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sougofollow",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/ezjKQLcVJM",
      "expanded_url" : "http:\/\/coupontru.mp\/dda4be",
      "display_url" : "coupontru.mp\/dda4be"
    } ]
  },
  "geo" : { },
  "id_str" : "566272362950045698",
  "text" : "RT @CouponTrump: Common Core Math Concepts: K-8 @gamer456148 #sougofollow http:\/\/t.co\/ezjKQLcVJM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.coupontrump.com\" rel=\"nofollow\"\u003ECpnt_Autotweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 31, 43 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sougofollow",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/ezjKQLcVJM",
        "expanded_url" : "http:\/\/coupontru.mp\/dda4be",
        "display_url" : "coupontru.mp\/dda4be"
      } ]
    },
    "geo" : { },
    "id_str" : "566218565620363264",
    "text" : "Common Core Math Concepts: K-8 @gamer456148 #sougofollow http:\/\/t.co\/ezjKQLcVJM",
    "id" : 566218565620363264,
    "created_at" : "2015-02-13 12:53:20 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 566272362950045698,
  "created_at" : "2015-02-13 16:27:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 35, 47 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sougofollow",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/aU2hg7v84p",
      "expanded_url" : "http:\/\/coupontru.mp\/6fa93b",
      "display_url" : "coupontru.mp\/6fa93b"
    } ]
  },
  "geo" : { },
  "id_str" : "566272347921842176",
  "text" : "RT @CouponTrump: IT Survival Guide @gamer456148 #sougofollow http:\/\/t.co\/aU2hg7v84p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.coupontrump.com\" rel=\"nofollow\"\u003ECpnt_Autotweeter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 18, 30 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sougofollow",
        "indices" : [ 31, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/aU2hg7v84p",
        "expanded_url" : "http:\/\/coupontru.mp\/6fa93b",
        "display_url" : "coupontru.mp\/6fa93b"
      } ]
    },
    "geo" : { },
    "id_str" : "566215291135221760",
    "text" : "IT Survival Guide @gamer456148 #sougofollow http:\/\/t.co\/aU2hg7v84p",
    "id" : 566215291135221760,
    "created_at" : "2015-02-13 12:40:19 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 566272347921842176,
  "created_at" : "2015-02-13 16:27:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 112, 120 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/SburTeuNlL",
      "expanded_url" : "http:\/\/youtu.be\/MHm3fHVZitI",
      "display_url" : "youtu.be\/MHm3fHVZitI"
    } ]
  },
  "geo" : { },
  "id_str" : "566272195270148096",
  "text" : "RT @colin_furze: A Microwave that can FREEZE? Furze's Invention show - Freezer wave: http:\/\/t.co\/SburTeuNlL via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 95, 103 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/SburTeuNlL",
        "expanded_url" : "http:\/\/youtu.be\/MHm3fHVZitI",
        "display_url" : "youtu.be\/MHm3fHVZitI"
      } ]
    },
    "geo" : { },
    "id_str" : "565941607493419008",
    "text" : "A Microwave that can FREEZE? Furze's Invention show - Freezer wave: http:\/\/t.co\/SburTeuNlL via @YouTube",
    "id" : 565941607493419008,
    "created_at" : "2015-02-12 18:32:48 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 566272195270148096,
  "created_at" : "2015-02-13 16:26:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "indices" : [ 0, 14 ],
      "id_str" : "255165682",
      "id" : 255165682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566001138709721089",
  "geo" : { },
  "id_str" : "566003177200156672",
  "in_reply_to_user_id" : 255165682,
  "text" : "@FreeTheSoulss No Problem, good luck :P",
  "id" : 566003177200156672,
  "in_reply_to_status_id" : 566001138709721089,
  "created_at" : "2015-02-12 22:37:27 +0000",
  "in_reply_to_screen_name" : "FreeTheSoulss",
  "in_reply_to_user_id_str" : "255165682",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "indices" : [ 3, 17 ],
      "id_str" : "255165682",
      "id" : 255165682
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566003076385890304",
  "text" : "RT @FreeTheSoulss: @gamer456148 That cool but I have not had a camera of any kind for years. My last one broke. But that good you making co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "565998303368605698",
    "geo" : { },
    "id_str" : "566001138709721089",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 That cool but I have not had a camera of any kind for years. My last one broke. But that good you making courses. Thx anyway.",
    "id" : 566001138709721089,
    "in_reply_to_status_id" : 565998303368605698,
    "created_at" : "2015-02-12 22:29:21 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "protected" : false,
      "id_str" : "255165682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2699343251\/9e8802d3ba276d237a2fdac50bb2ff92_normal.jpeg",
      "id" : 255165682,
      "verified" : false
    }
  },
  "id" : 566003076385890304,
  "created_at" : "2015-02-12 22:37:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 3, 16 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565999397943525377",
  "text" : "RT @PopeTawadros: I appeal to all to preserve lives of fellow Egyptians, with restraint to prevent violence and reckless attacks against an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366917636283572225",
    "text" : "I appeal to all to preserve lives of fellow Egyptians, with restraint to prevent violence and reckless attacks against any person or place.",
    "id" : 366917636283572225,
    "created_at" : "2013-08-12 13:42:36 +0000",
    "user" : {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "protected" : false,
      "id_str" : "927421452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2902297704\/8f9ea422fc9315fac166213148ab47c6_normal.jpeg",
      "id" : 927421452,
      "verified" : true
    }
  },
  "id" : 565999397943525377,
  "created_at" : "2015-02-12 22:22:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/RgTwV8KX1J",
      "expanded_url" : "http:\/\/dlvr.it\/8W1fP0",
      "display_url" : "dlvr.it\/8W1fP0"
    } ]
  },
  "geo" : { },
  "id_str" : "565999262115180544",
  "text" : "RT @copticworld: Pope Tawadros II Meets Russian Church\u2019s Delegation: Pope Tawadros II Meets Russian Church\u2019s\u2026 http:\/\/t.co\/RgTwV8KX1J via @C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CopticWorld",
        "screen_name" : "copticworld",
        "indices" : [ 120, 132 ],
        "id_str" : "136923775",
        "id" : 136923775
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/RgTwV8KX1J",
        "expanded_url" : "http:\/\/dlvr.it\/8W1fP0",
        "display_url" : "dlvr.it\/8W1fP0"
      } ]
    },
    "geo" : { },
    "id_str" : "565664366696333314",
    "text" : "Pope Tawadros II Meets Russian Church\u2019s Delegation: Pope Tawadros II Meets Russian Church\u2019s\u2026 http:\/\/t.co\/RgTwV8KX1J via @CopticWorld",
    "id" : 565664366696333314,
    "created_at" : "2015-02-12 00:11:09 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 565999262115180544,
  "created_at" : "2015-02-12 22:21:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mina sami",
      "screen_name" : "theminasami",
      "indices" : [ 0, 12 ],
      "id_str" : "1249318808",
      "id" : 1249318808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565996996033785859",
  "geo" : { },
  "id_str" : "565998817812566017",
  "in_reply_to_user_id" : 1249318808,
  "text" : "@theminasami Mina I don't know you, try connecting on my LinkedIn\/Business profile rather then my personal facebook profile",
  "id" : 565998817812566017,
  "in_reply_to_status_id" : 565996996033785859,
  "created_at" : "2015-02-12 22:20:08 +0000",
  "in_reply_to_screen_name" : "theminasami",
  "in_reply_to_user_id_str" : "1249318808",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "indices" : [ 0, 14 ],
      "id_str" : "255165682",
      "id" : 255165682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "565986118496034816",
  "geo" : { },
  "id_str" : "565998303368605698",
  "in_reply_to_user_id" : 255165682,
  "text" : "@FreeTheSoulss I have been busy making courses on Udemy, I can make a video course with you, if you have a good camera and willing to collab",
  "id" : 565998303368605698,
  "in_reply_to_status_id" : 565986118496034816,
  "created_at" : "2015-02-12 22:18:05 +0000",
  "in_reply_to_screen_name" : "FreeTheSoulss",
  "in_reply_to_user_id_str" : "255165682",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "indices" : [ 3, 17 ],
      "id_str" : "255165682",
      "id" : 255165682
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565997048185368576",
  "text" : "RT @FreeTheSoulss: @gamer456148 I am doing fine. Long time. Nice to hear from you again so what you been up too?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "565976556141436928",
    "geo" : { },
    "id_str" : "565986118496034816",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I am doing fine. Long time. Nice to hear from you again so what you been up too?",
    "id" : 565986118496034816,
    "in_reply_to_status_id" : 565976556141436928,
    "created_at" : "2015-02-12 21:29:40 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "protected" : false,
      "id_str" : "255165682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2699343251\/9e8802d3ba276d237a2fdac50bb2ff92_normal.jpeg",
      "id" : 255165682,
      "verified" : false
    }
  },
  "id" : 565997048185368576,
  "created_at" : "2015-02-12 22:13:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565978388590895104",
  "text" : "My inspiration for all the good I do comes from God, my inspiration for all the bad I do comes from my fundamentally flawed human nature...",
  "id" : 565978388590895104,
  "created_at" : "2015-02-12 20:58:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dj Quality\u00A9\u2122",
      "screen_name" : "Djquality23",
      "indices" : [ 3, 15 ],
      "id_str" : "37446613",
      "id" : 37446613
    }, {
      "name" : "\u0418\u0441\u0438\u0434\u043E\u0440",
      "screen_name" : "ErnestoTurmero",
      "indices" : [ 56, 71 ],
      "id_str" : "2982392392",
      "id" : 2982392392
    }, {
      "name" : "mar",
      "screen_name" : "mary_arndt",
      "indices" : [ 72, 83 ],
      "id_str" : "126808873",
      "id" : 126808873
    }, {
      "name" : "Meditalo",
      "screen_name" : "Meditalo",
      "indices" : [ 84, 93 ],
      "id_str" : "339939587",
      "id" : 339939587
    }, {
      "name" : "Obey Riize",
      "screen_name" : "its_iceey",
      "indices" : [ 94, 104 ],
      "id_str" : "714652061783056384",
      "id" : 714652061783056384
    }, {
      "name" : "Much recipes",
      "screen_name" : "MinimalistLifes",
      "indices" : [ 105, 121 ],
      "id_str" : "708466075",
      "id" : 708466075
    }, {
      "name" : "Simone Nash",
      "screen_name" : "SimoneNattyIcee",
      "indices" : [ 122, 138 ],
      "id_str" : "267547309",
      "id" : 267547309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565977896167014401",
  "text" : "RT @Djquality23: Shoutout To My New Followers RT 4 #fb  @ErnestoTurmero @mary_arndt @Meditalo @Its_Iceey @MinimalistLifes @SimoneNattyIcee \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/lazyshoutout.com\" rel=\"nofollow\"\u003ELazyUnfollow IPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0418\u0441\u0438\u0434\u043E\u0440",
        "screen_name" : "ErnestoTurmero",
        "indices" : [ 39, 54 ],
        "id_str" : "2982392392",
        "id" : 2982392392
      }, {
        "name" : "mar",
        "screen_name" : "mary_arndt",
        "indices" : [ 55, 66 ],
        "id_str" : "126808873",
        "id" : 126808873
      }, {
        "name" : "Meditalo",
        "screen_name" : "Meditalo",
        "indices" : [ 67, 76 ],
        "id_str" : "339939587",
        "id" : 339939587
      }, {
        "name" : "Obey Riize",
        "screen_name" : "its_iceey",
        "indices" : [ 77, 87 ],
        "id_str" : "714652061783056384",
        "id" : 714652061783056384
      }, {
        "name" : "Much recipes",
        "screen_name" : "MinimalistLifes",
        "indices" : [ 88, 104 ],
        "id_str" : "708466075",
        "id" : 708466075
      }, {
        "name" : "Simone Nash",
        "screen_name" : "SimoneNattyIcee",
        "indices" : [ 105, 121 ],
        "id_str" : "267547309",
        "id" : 267547309
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 122, 134 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 34, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227851327466770432",
    "text" : "Shoutout To My New Followers RT 4 #fb  @ErnestoTurmero @mary_arndt @Meditalo @Its_Iceey @MinimalistLifes @SimoneNattyIcee @gamer456148",
    "id" : 227851327466770432,
    "created_at" : "2012-07-24 19:42:44 +0000",
    "user" : {
      "name" : "Dj Quality\u00A9\u2122",
      "screen_name" : "Djquality23",
      "protected" : false,
      "id_str" : "37446613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000510062430\/2cb995e90bc4bc44f87a5858182b8ad4_normal.jpeg",
      "id" : 37446613,
      "verified" : false
    }
  },
  "id" : 565977896167014401,
  "created_at" : "2015-02-12 20:57:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Apple Bagels",
      "screen_name" : "BigAppleBagels",
      "indices" : [ 3, 18 ],
      "id_str" : "48104702",
      "id" : 48104702
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565976966344343552",
  "text" : "RT @BigAppleBagels: @gamer456148 Glad you enjoyed them! What kind was your favorite?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "528593723882344448",
    "geo" : { },
    "id_str" : "529319047331319808",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Glad you enjoyed them! What kind was your favorite?",
    "id" : 529319047331319808,
    "in_reply_to_status_id" : 528593723882344448,
    "created_at" : "2014-11-03 17:07:49 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Big Apple Bagels",
      "screen_name" : "BigAppleBagels",
      "protected" : false,
      "id_str" : "48104702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468403986165272576\/c9Gl8NAA_normal.jpeg",
      "id" : 48104702,
      "verified" : false
    }
  },
  "id" : 565976966344343552,
  "created_at" : "2015-02-12 20:53:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom zolotor",
      "screen_name" : "FreeTheSoulss",
      "indices" : [ 0, 14 ],
      "id_str" : "255165682",
      "id" : 255165682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565976556141436928",
  "in_reply_to_user_id" : 255165682,
  "text" : "@FreeTheSoulss Hey Thomas it is Andrew, been a long time, how are you doing buddy?",
  "id" : 565976556141436928,
  "created_at" : "2015-02-12 20:51:40 +0000",
  "in_reply_to_screen_name" : "FreeTheSoulss",
  "in_reply_to_user_id_str" : "255165682",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FullRepeal",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/yHSLGEM85l",
      "expanded_url" : "http:\/\/tedcruz.org\/repeal\/",
      "display_url" : "tedcruz.org\/repeal\/"
    } ]
  },
  "geo" : { },
  "id_str" : "565974940109664256",
  "text" : "RT @tedcruz: Show your support for a #FullRepeal. Add your name as a cosponsor of the Obamacare Repeal Act: http:\/\/t.co\/yHSLGEM85l http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/565501600408813568\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/N3RhUlQc7Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9kQpIqIcAE5dSj.jpg",
        "id_str" : "565501527096586241",
        "id" : 565501527096586241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9kQpIqIcAE5dSj.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/N3RhUlQc7Z"
      } ],
      "hashtags" : [ {
        "text" : "FullRepeal",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/yHSLGEM85l",
        "expanded_url" : "http:\/\/tedcruz.org\/repeal\/",
        "display_url" : "tedcruz.org\/repeal\/"
      } ]
    },
    "geo" : { },
    "id_str" : "565501600408813568",
    "text" : "Show your support for a #FullRepeal. Add your name as a cosponsor of the Obamacare Repeal Act: http:\/\/t.co\/yHSLGEM85l http:\/\/t.co\/N3RhUlQc7Z",
    "id" : 565501600408813568,
    "created_at" : "2015-02-11 13:24:22 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 565974940109664256,
  "created_at" : "2015-02-12 20:45:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/45yxr5C3UY",
      "expanded_url" : "http:\/\/youtu.be\/tem_Er-TIhA?a",
      "display_url" : "youtu.be\/tem_Er-TIhA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "565974835453374464",
  "text" : "RT @VigilantChrist: God Gives Those Who Follow Jesus a Mansion in The Sky! Heavenly Cribs!  http:\/\/t.co\/45yxr5C3UY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/45yxr5C3UY",
        "expanded_url" : "http:\/\/youtu.be\/tem_Er-TIhA?a",
        "display_url" : "youtu.be\/tem_Er-TIhA?a"
      } ]
    },
    "geo" : { },
    "id_str" : "565891221336227843",
    "text" : "God Gives Those Who Follow Jesus a Mansion in The Sky! Heavenly Cribs!  http:\/\/t.co\/45yxr5C3UY",
    "id" : 565891221336227843,
    "created_at" : "2015-02-12 15:12:35 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 565974835453374464,
  "created_at" : "2015-02-12 20:44:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 0, 9 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "American Airlines",
      "screen_name" : "AmericanAir",
      "indices" : [ 10, 22 ],
      "id_str" : "22536055",
      "id" : 22536055
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 23, 35 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Inventor_tom",
      "screen_name" : "inventor_tom",
      "indices" : [ 36, 49 ],
      "id_str" : "292906026",
      "id" : 292906026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ZoMhqT8dUq",
      "expanded_url" : "http:\/\/goo.gl\/4g6Yg7",
      "display_url" : "goo.gl\/4g6Yg7"
    } ]
  },
  "geo" : { },
  "id_str" : "565974270623240192",
  "in_reply_to_user_id" : 44196397,
  "text" : "@elonmusk @AmericanAir @colin_furze @inventor_tom Do you like my Flying Car Industrial Design Concept? http:\/\/t.co\/ZoMhqT8dUq #STEM",
  "id" : 565974270623240192,
  "created_at" : "2015-02-12 20:42:36 +0000",
  "in_reply_to_screen_name" : "elonmusk",
  "in_reply_to_user_id_str" : "44196397",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 0, 9 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565552779779768320",
  "in_reply_to_user_id" : 44196397,
  "text" : "@elonmusk Always surprises me to see what this technological guru comes up with next.",
  "id" : 565552779779768320,
  "created_at" : "2015-02-11 16:47:44 +0000",
  "in_reply_to_screen_name" : "elonmusk",
  "in_reply_to_user_id_str" : "44196397",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/565350545695977472\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/FmrmYs6R6V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9iHU1IIUAEKGnU.jpg",
      "id_str" : "565350545163309057",
      "id" : 565350545163309057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9iHU1IIUAEKGnU.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 936,
        "resize" : "fit",
        "w" : 1404
      } ],
      "display_url" : "pic.twitter.com\/FmrmYs6R6V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565552660393119744",
  "text" : "RT @elonmusk: Coming home http:\/\/t.co\/FmrmYs6R6V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/565350545695977472\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/FmrmYs6R6V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9iHU1IIUAEKGnU.jpg",
        "id_str" : "565350545163309057",
        "id" : 565350545163309057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9iHU1IIUAEKGnU.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 936,
          "resize" : "fit",
          "w" : 1404
        } ],
        "display_url" : "pic.twitter.com\/FmrmYs6R6V"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565350545695977472",
    "text" : "Coming home http:\/\/t.co\/FmrmYs6R6V",
    "id" : 565350545695977472,
    "created_at" : "2015-02-11 03:24:08 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 565552660393119744,
  "created_at" : "2015-02-11 16:47:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "indices" : [ 3, 14 ],
      "id_str" : "2876894477",
      "id" : 2876894477
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565197717308051456",
  "text" : "RT @Carley_IMF: @gamer456148 thanks Andrew! I really appreciate that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "565192747775037441",
    "geo" : { },
    "id_str" : "565197272078905344",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 thanks Andrew! I really appreciate that.",
    "id" : 565197272078905344,
    "in_reply_to_status_id" : 565192747775037441,
    "created_at" : "2015-02-10 17:15:05 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "protected" : false,
      "id_str" : "2876894477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553371133349605377\/-YUneFDz_normal.png",
      "id" : 2876894477,
      "verified" : false
    }
  },
  "id" : 565197717308051456,
  "created_at" : "2015-02-10 17:16:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carley Ferrara",
      "screen_name" : "Carley_IMF",
      "indices" : [ 55, 66 ],
      "id_str" : "2876894477",
      "id" : 2876894477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565192747775037441",
  "text" : "As an Industrial Design Enthusiast, I can honestly say @Carley_IMF is one impressive lady. I also love seeing other's creativity.",
  "id" : 565192747775037441,
  "created_at" : "2015-02-10 16:57:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564208655831031810",
  "text" : "Went to a family birthday party today, little nephew turned 1...",
  "id" : 564208655831031810,
  "created_at" : "2015-02-07 23:46:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562639516838526976",
  "text" : "Have hope...",
  "id" : 562639516838526976,
  "created_at" : "2015-02-03 15:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562639048959733761",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Maybe next Obama supporters will sign a petition to allow people to marry animals.",
  "id" : 562639048959733761,
  "created_at" : "2015-02-03 15:49:37 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koding",
      "screen_name" : "koding",
      "indices" : [ 3, 10 ],
      "id_str" : "42704386",
      "id" : 42704386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Github",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Z71wzzaM3Z",
      "expanded_url" : "http:\/\/j.mp\/1JwIXJM",
      "display_url" : "j.mp\/1JwIXJM"
    } ]
  },
  "geo" : { },
  "id_str" : "562287484810182656",
  "text" : "RT @koding: A #Github cheat sheet http:\/\/t.co\/Z71wzzaM3Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Github",
        "indices" : [ 2, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/Z71wzzaM3Z",
        "expanded_url" : "http:\/\/j.mp\/1JwIXJM",
        "display_url" : "j.mp\/1JwIXJM"
      } ]
    },
    "geo" : { },
    "id_str" : "561956397504798720",
    "text" : "A #Github cheat sheet http:\/\/t.co\/Z71wzzaM3Z",
    "id" : 561956397504798720,
    "created_at" : "2015-02-01 18:37:00 +0000",
    "user" : {
      "name" : "Koding",
      "screen_name" : "koding",
      "protected" : false,
      "id_str" : "42704386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735709066178105349\/r9KXykEI_normal.jpg",
      "id" : 42704386,
      "verified" : false
    }
  },
  "id" : 562287484810182656,
  "created_at" : "2015-02-02 16:32:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562287115849830400",
  "in_reply_to_user_id" : 1612670168,
  "text" : "@CodeSayaX Code for India, you can do it.",
  "id" : 562287115849830400,
  "created_at" : "2015-02-02 16:31:09 +0000",
  "in_reply_to_screen_name" : "shayla_185",
  "in_reply_to_user_id_str" : "1612670168",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 70, 82 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562286841122922496",
  "text" : "RT @CodeSayaX: Koding2an? Mo share nih, coba buka CodeSaya dot com RT @gamer456148 Hopefully I will be accepted!\nI've applied for the world\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/codesaya.com\" rel=\"nofollow\"\u003Ecodesayax\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 55, 67 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562074095747993600",
    "text" : "Koding2an? Mo share nih, coba buka CodeSaya dot com RT @gamer456148 Hopefully I will be accepted!\nI've applied for the world'..",
    "id" : 562074095747993600,
    "created_at" : "2015-02-02 02:24:41 +0000",
    "user" : {
      "name" : "Shayla",
      "screen_name" : "shayla_185",
      "protected" : false,
      "id_str" : "1612670168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732805248121774084\/eGWUc5Zh_normal.jpg",
      "id" : 1612670168,
      "verified" : false
    }
  },
  "id" : 562286841122922496,
  "created_at" : "2015-02-02 16:30:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]