Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671534254967377920",
  "geo" : { },
  "id_str" : "671534555996618753",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp Nintendo, always unique",
  "id" : 671534555996618753,
  "in_reply_to_status_id" : 671534254967377920,
  "created_at" : "2015-12-01 03:41:29 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/540705388262596608\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/mjpKTUvZZL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4D4r43IAAMtls6.jpg",
      "id_str" : "540705388166119427",
      "id" : 540705388166119427,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4D4r43IAAMtls6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 547
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 547
      } ],
      "display_url" : "pic.twitter.com\/mjpKTUvZZL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671534501797879809",
  "text" : "RT @BestGamezUp: Video Games magazine -- May 1983 issue https:\/\/t.co\/mjpKTUvZZL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/540705388262596608\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/mjpKTUvZZL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4D4r43IAAMtls6.jpg",
        "id_str" : "540705388166119427",
        "id" : 540705388166119427,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4D4r43IAAMtls6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 547
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 547
        } ],
        "display_url" : "pic.twitter.com\/mjpKTUvZZL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671534254967377920",
    "text" : "Video Games magazine -- May 1983 issue https:\/\/t.co\/mjpKTUvZZL",
    "id" : 671534254967377920,
    "created_at" : "2015-12-01 03:40:17 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 671534501797879809,
  "created_at" : "2015-12-01 03:41:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Monica Crowley",
      "screen_name" : "MonicaCrowley",
      "indices" : [ 18, 32 ],
      "id_str" : "166990746",
      "id" : 166990746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671534200596533250",
  "text" : "RT @seanhannity: .@MonicaCrowley: \u201CMrs. Clinton has been on the national scene now for 25 years &amp; for the duration she has been a serial li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Crowley",
        "screen_name" : "MonicaCrowley",
        "indices" : [ 1, 15 ],
        "id_str" : "166990746",
        "id" : 166990746
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671533448868184066",
    "text" : ".@MonicaCrowley: \u201CMrs. Clinton has been on the national scene now for 25 years &amp; for the duration she has been a serial liar.\" #Hannity",
    "id" : 671533448868184066,
    "created_at" : "2015-12-01 03:37:05 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 671534200596533250,
  "created_at" : "2015-12-01 03:40:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF08 alishia",
      "screen_name" : "Alishia_97",
      "indices" : [ 12, 23 ],
      "id_str" : "580444695",
      "id" : 580444695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671525672884510721",
  "geo" : { },
  "id_str" : "671534079636987905",
  "in_reply_to_user_id" : 1196352416,
  "text" : "@JoonTrxllo @Alishia_97 Depends on what you say, how people treat each other through a deontological perspective",
  "id" : 671534079636987905,
  "in_reply_to_status_id" : 671525672884510721,
  "created_at" : "2015-12-01 03:39:35 +0000",
  "in_reply_to_screen_name" : "Trvpjoon",
  "in_reply_to_user_id_str" : "1196352416",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Montei",
      "screen_name" : "BillMontei",
      "indices" : [ 3, 14 ],
      "id_str" : "159658784",
      "id" : 159658784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/TPxGlLPCWZ",
      "expanded_url" : "https:\/\/apple.news\/AeDYvHL1dN7iBOobKuonZDQ",
      "display_url" : "apple.news\/AeDYvHL1dN7iBO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671533880713674756",
  "text" : "RT @BillMontei: 10 photos that show off our dazzling, magical sky - Mashable https:\/\/t.co\/TPxGlLPCWZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/TPxGlLPCWZ",
        "expanded_url" : "https:\/\/apple.news\/AeDYvHL1dN7iBOobKuonZDQ",
        "display_url" : "apple.news\/AeDYvHL1dN7iBO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671533224330321920",
    "text" : "10 photos that show off our dazzling, magical sky - Mashable https:\/\/t.co\/TPxGlLPCWZ",
    "id" : 671533224330321920,
    "created_at" : "2015-12-01 03:36:11 +0000",
    "user" : {
      "name" : "Bill Montei",
      "screen_name" : "BillMontei",
      "protected" : false,
      "id_str" : "159658784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2377159536\/s15dgxtb343yurtnfwon_normal.jpeg",
      "id" : 159658784,
      "verified" : false
    }
  },
  "id" : 671533880713674756,
  "created_at" : "2015-12-01 03:38:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671533845787762688",
  "text" : "RT @JoonTrxllo: my mood can change so quick. . .",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671525672884510721",
    "text" : "my mood can change so quick. . .",
    "id" : 671525672884510721,
    "created_at" : "2015-12-01 03:06:11 +0000",
    "user" : {
      "name" : "\uD83D\uDC41\u200D\uD83D\uDDE8\uD83D\uDCAD\uD83E\uDD40\uD83D\uDC63  Joon",
      "screen_name" : "Trvpjoon",
      "protected" : false,
      "id_str" : "1196352416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867380404935905284\/rha_kioE_normal.jpg",
      "id" : 1196352416,
      "verified" : false
    }
  },
  "id" : 671533845787762688,
  "created_at" : "2015-12-01 03:38:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/671533309176901632\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/vDC67evqip",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVHD-4QUwAEMdWU.jpg",
      "id_str" : "671533304475074561",
      "id" : 671533304475074561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVHD-4QUwAEMdWU.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vDC67evqip"
    } ],
    "hashtags" : [ {
      "text" : "hunt",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671533309176901632",
  "text" : "What dears did to my dad's car, this is why we #hunt https:\/\/t.co\/vDC67evqip",
  "id" : 671533309176901632,
  "created_at" : "2015-12-01 03:36:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671401249732993030",
  "text" : "RT @God_Instagram: Don't be discouraged. God is bigger than any of your problems, and he will always show up at the right time and place.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671359141634445312",
    "text" : "Don't be discouraged. God is bigger than any of your problems, and he will always show up at the right time and place.",
    "id" : 671359141634445312,
    "created_at" : "2015-11-30 16:04:27 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 671401249732993030,
  "created_at" : "2015-11-30 18:51:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671401226613956610",
  "text" : "RT @God_Instagram: Thank you God for blessing me much more than I deserve.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671351715048755201",
    "text" : "Thank you God for blessing me much more than I deserve.",
    "id" : 671351715048755201,
    "created_at" : "2015-11-30 15:34:56 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 671401226613956610,
  "created_at" : "2015-11-30 18:51:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bryanboy",
      "screen_name" : "bryanboy",
      "indices" : [ 3, 12 ],
      "id_str" : "7092102",
      "id" : 7092102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671347600965136384",
  "text" : "RT @bryanboy: imagine the visual of me, bryanboy, on a hoverboard.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670144641342136324",
    "text" : "imagine the visual of me, bryanboy, on a hoverboard.",
    "id" : 670144641342136324,
    "created_at" : "2015-11-27 07:38:27 +0000",
    "user" : {
      "name" : "bryanboy",
      "screen_name" : "bryanboy",
      "protected" : false,
      "id_str" : "7092102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000592133132\/33f709fcd58db0b807e9ac7c0931acc1_normal.jpeg",
      "id" : 7092102,
      "verified" : true
    }
  },
  "id" : 671347600965136384,
  "created_at" : "2015-11-30 15:18:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LancsPolice",
      "screen_name" : "LancsPolice",
      "indices" : [ 3, 15 ],
      "id_str" : "79983391",
      "id" : 79983391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671347438733651969",
  "text" : "RT @LancsPolice: Thinking of giving a hoverboard as a gift at Christmas? These cannot be used on a pavement or public highway. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialsignin.co.uk\" rel=\"nofollow\"\u003ESocialSignIn Application\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LancsPolice\/status\/669663484834160640\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/1EUmWPDaBW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUsfZA1WoAAFzSF.jpg",
        "id_str" : "669663484175622144",
        "id" : 669663484175622144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUsfZA1WoAAFzSF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/1EUmWPDaBW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669663484834160640",
    "text" : "Thinking of giving a hoverboard as a gift at Christmas? These cannot be used on a pavement or public highway. https:\/\/t.co\/1EUmWPDaBW",
    "id" : 669663484834160640,
    "created_at" : "2015-11-25 23:46:31 +0000",
    "user" : {
      "name" : "LancsPolice",
      "screen_name" : "LancsPolice",
      "protected" : false,
      "id_str" : "79983391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851714800992342016\/DjvTuFS4_normal.jpg",
      "id" : 79983391,
      "verified" : true
    }
  },
  "id" : 671347438733651969,
  "created_at" : "2015-11-30 15:17:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon F Snyder Jr",
      "screen_name" : "gsnyder",
      "indices" : [ 0, 8 ],
      "id_str" : "6296992",
      "id" : 6296992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "in_reply_to_status_id_str" : "668049902136655872",
  "geo" : { },
  "id_str" : "671347241735598080",
  "in_reply_to_user_id" : 6296992,
  "text" : "@gsnyder Build one https:\/\/t.co\/HfViSZFgjj",
  "id" : 671347241735598080,
  "in_reply_to_status_id" : 668049902136655872,
  "created_at" : "2015-11-30 15:17:10 +0000",
  "in_reply_to_screen_name" : "gsnyder",
  "in_reply_to_user_id_str" : "6296992",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup L. Jackson",
      "screen_name" : "StartupLJackson",
      "indices" : [ 0, 16 ],
      "id_str" : "353789193",
      "id" : 353789193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "in_reply_to_status_id_str" : "670337816904134656",
  "geo" : { },
  "id_str" : "671346676712493056",
  "in_reply_to_user_id" : 353789193,
  "text" : "@StartupLJackson What about this Hoverboard? https:\/\/t.co\/HfViSZFgjj",
  "id" : 671346676712493056,
  "in_reply_to_status_id" : 670337816904134656,
  "created_at" : "2015-11-30 15:14:55 +0000",
  "in_reply_to_screen_name" : "StartupLJackson",
  "in_reply_to_user_id_str" : "353789193",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/jkWn9RzX2z",
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/669737360003874819",
      "display_url" : "twitter.com\/engadget\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669928711928459266",
  "text" : "Whoa https:\/\/t.co\/jkWn9RzX2z",
  "id" : 669928711928459266,
  "created_at" : "2015-11-26 17:20:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669620181199491073",
  "text" : "Thanksgiving break, an entire day off!!!",
  "id" : 669620181199491073,
  "created_at" : "2015-11-25 20:54:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Zeer Jr.",
      "screen_name" : "Sam_Zeer",
      "indices" : [ 3, 12 ],
      "id_str" : "626211593",
      "id" : 626211593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669619464271347712",
  "text" : "RT @Sam_Zeer: Don\u2019t let yourself be controlled by three things: people, money, or past experiences.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664096828514783233",
    "text" : "Don\u2019t let yourself be controlled by three things: people, money, or past experiences.",
    "id" : 664096828514783233,
    "created_at" : "2015-11-10 15:06:36 +0000",
    "user" : {
      "name" : "Sam Zeer Jr.",
      "screen_name" : "Sam_Zeer",
      "protected" : false,
      "id_str" : "626211593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803631085225709568\/g2aHj-6k_normal.jpg",
      "id" : 626211593,
      "verified" : false
    }
  },
  "id" : 669619464271347712,
  "created_at" : "2015-11-25 20:51:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Zeer Jr.",
      "screen_name" : "Sam_Zeer",
      "indices" : [ 3, 12 ],
      "id_str" : "626211593",
      "id" : 626211593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669603667251621888",
  "text" : "RT @Sam_Zeer: Philosophy is by far the worst class to study for\uD83D\uDE21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663733863072575488",
    "text" : "Philosophy is by far the worst class to study for\uD83D\uDE21",
    "id" : 663733863072575488,
    "created_at" : "2015-11-09 15:04:19 +0000",
    "user" : {
      "name" : "Sam Zeer Jr.",
      "screen_name" : "Sam_Zeer",
      "protected" : false,
      "id_str" : "626211593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803631085225709568\/g2aHj-6k_normal.jpg",
      "id" : 626211593,
      "verified" : false
    }
  },
  "id" : 669603667251621888,
  "created_at" : "2015-11-25 19:48:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669530009745367040",
  "text" : "RT @God_Instagram: God's promises are like stars. The darker the night the brighter they shine.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669336221861019648",
    "text" : "God's promises are like stars. The darker the night the brighter they shine.",
    "id" : 669336221861019648,
    "created_at" : "2015-11-25 02:06:05 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 669530009745367040,
  "created_at" : "2015-11-25 14:56:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/9xwJlZr1Vn",
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/667044599064432640",
      "display_url" : "twitter.com\/tedcruz\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669529612448346112",
  "text" : "Things just got real, not really but.... go Cruz https:\/\/t.co\/9xwJlZr1Vn",
  "id" : 669529612448346112,
  "created_at" : "2015-11-25 14:54:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668838474078953472",
  "text" : "Listening to Don Juan, vivid poetry but not my cup of tea #ThisIsOU",
  "id" : 668838474078953472,
  "created_at" : "2015-11-23 17:08:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668300905398140928",
  "text" : "I might sometimes prefer Twitter",
  "id" : 668300905398140928,
  "created_at" : "2015-11-22 05:32:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mJoose",
      "screen_name" : "mJooseTech",
      "indices" : [ 3, 14 ],
      "id_str" : "3838843890",
      "id" : 3838843890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobile",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/VjaUl0DXbq",
      "expanded_url" : "http:\/\/vytm.in\/xtwVNg",
      "display_url" : "vytm.in\/xtwVNg"
    } ]
  },
  "geo" : { },
  "id_str" : "668300695993323520",
  "text" : "RT @mJooseTech: GSMA Launches Mobile World Congress Shanghai 2016 https:\/\/t.co\/VjaUl0DXbq #mobile",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vytmn.com\/\" rel=\"nofollow\"\u003EVytmn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mobile",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/VjaUl0DXbq",
        "expanded_url" : "http:\/\/vytm.in\/xtwVNg",
        "display_url" : "vytm.in\/xtwVNg"
      } ]
    },
    "geo" : { },
    "id_str" : "667512241311346688",
    "text" : "GSMA Launches Mobile World Congress Shanghai 2016 https:\/\/t.co\/VjaUl0DXbq #mobile",
    "id" : 667512241311346688,
    "created_at" : "2015-11-20 01:18:14 +0000",
    "user" : {
      "name" : "mJoose",
      "screen_name" : "mJooseTech",
      "protected" : false,
      "id_str" : "3838843890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656219221630685184\/2jFi8OW-_normal.jpg",
      "id" : 3838843890,
      "verified" : false
    }
  },
  "id" : 668300695993323520,
  "created_at" : "2015-11-22 05:31:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/668295328756576256\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NGdzldoRxW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUZDD4cWwAA2GeT.jpg",
      "id_str" : "668295328681082880",
      "id" : 668295328681082880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUZDD4cWwAA2GeT.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/NGdzldoRxW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668299794427699200",
  "text" : "RT @rockindigo: An actual town in Mexico https:\/\/t.co\/NGdzldoRxW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/668295328756576256\/photo\/1",
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/NGdzldoRxW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUZDD4cWwAA2GeT.jpg",
        "id_str" : "668295328681082880",
        "id" : 668295328681082880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUZDD4cWwAA2GeT.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/NGdzldoRxW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668295328756576256",
    "text" : "An actual town in Mexico https:\/\/t.co\/NGdzldoRxW",
    "id" : 668295328756576256,
    "created_at" : "2015-11-22 05:09:57 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 668299794427699200,
  "created_at" : "2015-11-22 05:27:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668298997820317696",
  "text" : "RT @God_Instagram: God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668294400175267840",
    "text" : "God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
    "id" : 668294400175267840,
    "created_at" : "2015-11-22 05:06:15 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 668298997820317696,
  "created_at" : "2015-11-22 05:24:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/668294103789142017\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/NFOkFUk2Y1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUZB8c5XIAAiyYU.png",
      "id_str" : "668294101515837440",
      "id" : 668294101515837440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUZB8c5XIAAiyYU.png",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NFOkFUk2Y1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/XG7vydmAha",
      "expanded_url" : "http:\/\/engt.co\/1PH65wX",
      "display_url" : "engt.co\/1PH65wX"
    } ]
  },
  "geo" : { },
  "id_str" : "668298777535475712",
  "text" : "RT @engadget: Oddball machine makes 'analog' techno music with vinyl records https:\/\/t.co\/XG7vydmAha https:\/\/t.co\/NFOkFUk2Y1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.aol.com\" rel=\"nofollow\"\u003EAOL Blogsmith\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/668294103789142017\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/NFOkFUk2Y1",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUZB8c5XIAAiyYU.png",
        "id_str" : "668294101515837440",
        "id" : 668294101515837440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUZB8c5XIAAiyYU.png",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NFOkFUk2Y1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/XG7vydmAha",
        "expanded_url" : "http:\/\/engt.co\/1PH65wX",
        "display_url" : "engt.co\/1PH65wX"
      } ]
    },
    "geo" : { },
    "id_str" : "668294103789142017",
    "text" : "Oddball machine makes 'analog' techno music with vinyl records https:\/\/t.co\/XG7vydmAha https:\/\/t.co\/NFOkFUk2Y1",
    "id" : 668294103789142017,
    "created_at" : "2015-11-22 05:05:05 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 668298777535475712,
  "created_at" : "2015-11-22 05:23:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668298453252878336",
  "text" : "Spumoni is so good",
  "id" : 668298453252878336,
  "created_at" : "2015-11-22 05:22:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667788442181476352",
  "text" : "Had a long day but it was worth it #ThisIsOU",
  "id" : 667788442181476352,
  "created_at" : "2015-11-20 19:35:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667732695343079424",
  "text" : "I know for a fact, I did well on my math exam, I also know I am gonna get trolled",
  "id" : 667732695343079424,
  "created_at" : "2015-11-20 15:54:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/667591925982171136\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/TdmnVr9Zrn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUPDUatUYAAirCk.jpg",
      "id_str" : "667591925315166208",
      "id" : 667591925315166208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUPDUatUYAAirCk.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/TdmnVr9Zrn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/6fYzDABw0T",
      "expanded_url" : "http:\/\/engt.co\/1kHY6Df",
      "display_url" : "engt.co\/1kHY6Df"
    } ]
  },
  "geo" : { },
  "id_str" : "667594856856842240",
  "text" : "RT @engadget: YouTube foots the bill for video makers to fight copyright takedowns https:\/\/t.co\/6fYzDABw0T https:\/\/t.co\/TdmnVr9Zrn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/667591925982171136\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/TdmnVr9Zrn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUPDUatUYAAirCk.jpg",
        "id_str" : "667591925315166208",
        "id" : 667591925315166208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUPDUatUYAAirCk.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/TdmnVr9Zrn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/6fYzDABw0T",
        "expanded_url" : "http:\/\/engt.co\/1kHY6Df",
        "display_url" : "engt.co\/1kHY6Df"
      } ]
    },
    "geo" : { },
    "id_str" : "667591925982171136",
    "text" : "YouTube foots the bill for video makers to fight copyright takedowns https:\/\/t.co\/6fYzDABw0T https:\/\/t.co\/TdmnVr9Zrn",
    "id" : 667591925982171136,
    "created_at" : "2015-11-20 06:34:53 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 667594856856842240,
  "created_at" : "2015-11-20 06:46:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667594170387689472",
  "text" : "RT @God_Instagram: Don't worry everything is going to be alright. Maybe not right this second, but God makes everything beautiful in his ti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667554439176196096",
    "text" : "Don't worry everything is going to be alright. Maybe not right this second, but God makes everything beautiful in his time.",
    "id" : 667554439176196096,
    "created_at" : "2015-11-20 04:05:55 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 667594170387689472,
  "created_at" : "2015-11-20 06:43:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskSean",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667594137542070277",
  "text" : "RT @seanhannity: A viewers asked why money is being used to house refugees but not homeless veterans. Submit your questions using #AskSean.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskSean",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667552710061744129",
    "text" : "A viewers asked why money is being used to house refugees but not homeless veterans. Submit your questions using #AskSean.",
    "id" : 667552710061744129,
    "created_at" : "2015-11-20 03:59:03 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 667594137542070277,
  "created_at" : "2015-11-20 06:43:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667594102691643394",
  "text" : "\u007B How to deal with a breakup: Eggnog IceCream, milk, coffee IceCream, more milk, frozen yogurt, and most importantly a bible \u007D",
  "id" : 667594102691643394,
  "created_at" : "2015-11-20 06:43:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667464245869613056",
  "text" : "RT @God_Instagram: God is always doing a work in your life. He's always with you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667463499405070336",
    "text" : "God is always doing a work in your life. He's always with you.",
    "id" : 667463499405070336,
    "created_at" : "2015-11-19 22:04:33 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 667464245869613056,
  "created_at" : "2015-11-19 22:07:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667463940327084033",
  "text" : "Matrix Multiplication= Rows*Columns #MathTips",
  "id" : 667463940327084033,
  "created_at" : "2015-11-19 22:06:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuella Oraha",
      "screen_name" : "ManuOraha",
      "indices" : [ 0, 10 ],
      "id_str" : "211000945",
      "id" : 211000945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667458064350515200",
  "in_reply_to_user_id" : 211000945,
  "text" : "@ManuOraha It was a pleasure to meet you at AMA this week #ThisIsOU :)",
  "id" : 667458064350515200,
  "created_at" : "2015-11-19 21:42:57 +0000",
  "in_reply_to_screen_name" : "ManuOraha",
  "in_reply_to_user_id_str" : "211000945",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/473185219328360448\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/WJkvkF2FB6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpEXcyYIgAEaGUk.jpg",
      "id_str" : "473185219177381889",
      "id" : 473185219177381889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpEXcyYIgAEaGUk.jpg",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WJkvkF2FB6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667424359175348225",
  "text" : "RT @BestGamezUp: WoW 2004 vs 2014 https:\/\/t.co\/WJkvkF2FB6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/473185219328360448\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/WJkvkF2FB6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpEXcyYIgAEaGUk.jpg",
        "id_str" : "473185219177381889",
        "id" : 473185219177381889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpEXcyYIgAEaGUk.jpg",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1017
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1017
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WJkvkF2FB6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667422189516431360",
    "text" : "WoW 2004 vs 2014 https:\/\/t.co\/WJkvkF2FB6",
    "id" : 667422189516431360,
    "created_at" : "2015-11-19 19:20:24 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 667424359175348225,
  "created_at" : "2015-11-19 19:29:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/Lg6WMgGmmz",
      "expanded_url" : "https:\/\/twitter.com\/mariboros\/status\/667420893291945984",
      "display_url" : "twitter.com\/mariboros\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667424055864242176",
  "text" : "Maybe so... https:\/\/t.co\/Lg6WMgGmmz",
  "id" : 667424055864242176,
  "created_at" : "2015-11-19 19:27:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Startips",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667423922334408704",
  "text" : "I wish you can track your Social Media followers, users, and financials in one database rather than tons of accounts #Startips",
  "id" : 667423922334408704,
  "created_at" : "2015-11-19 19:27:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667021843103092736",
  "text" : "Today will be a long day, even with brownies, lol #ThisIsOU",
  "id" : 667021843103092736,
  "created_at" : "2015-11-18 16:49:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666764772692647936",
  "text" : "RT @God_Instagram: God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666655864393039872",
    "text" : "God, please take me by the hand and lead the way. I'm trusting you to lead me where you want me to be.",
    "id" : 666655864393039872,
    "created_at" : "2015-11-17 16:35:18 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 666764772692647936,
  "created_at" : "2015-11-17 23:48:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666764752945881089",
  "text" : "@TonySwish gave a really fun presentation today at #OU",
  "id" : 666764752945881089,
  "created_at" : "2015-11-17 23:47:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KK22",
      "screen_name" : "K4LEN",
      "indices" : [ 3, 9 ],
      "id_str" : "154350295",
      "id" : 154350295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MondayMotivation",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666267745789587461",
  "text" : "RT @K4LEN: ITS MONDAY MORNING! Get up! Accomplish something today. Better yourself today. Then do it again tomorrow. #MondayMotivation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 106, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666266878906503168",
    "text" : "ITS MONDAY MORNING! Get up! Accomplish something today. Better yourself today. Then do it again tomorrow. #MondayMotivation",
    "id" : 666266878906503168,
    "created_at" : "2015-11-16 14:49:37 +0000",
    "user" : {
      "name" : "KK22",
      "screen_name" : "K4LEN",
      "protected" : false,
      "id_str" : "154350295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850801148697161732\/KAZGvPJU_normal.jpg",
      "id" : 154350295,
      "verified" : true
    }
  },
  "id" : 666267745789587461,
  "created_at" : "2015-11-16 14:53:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzMyVideos",
      "screen_name" : "BuzzMyVideos",
      "indices" : [ 3, 16 ],
      "id_str" : "306937691",
      "id" : 306937691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666267727816953856",
  "text" : "RT @BuzzMyVideos: \"Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time.\"- T. Ediso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666266951501619201",
    "text" : "\"Our greatest weakness lies in giving up. The most certain way to succeed is always to try just one more time.\"- T. Edison #mondaymotivation",
    "id" : 666266951501619201,
    "created_at" : "2015-11-16 14:49:54 +0000",
    "user" : {
      "name" : "BuzzMyVideos",
      "screen_name" : "BuzzMyVideos",
      "protected" : false,
      "id_str" : "306937691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725722118588141572\/kW4w5qy5_normal.jpg",
      "id" : 306937691,
      "verified" : true
    }
  },
  "id" : 666267727816953856,
  "created_at" : "2015-11-16 14:52:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 0, 9 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666267605582389249",
  "in_reply_to_user_id" : 2425151,
  "text" : "@facebook Can you guys please  pm me, I need support",
  "id" : 666267605582389249,
  "created_at" : "2015-11-16 14:52:30 +0000",
  "in_reply_to_screen_name" : "facebook",
  "in_reply_to_user_id_str" : "2425151",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 0, 9 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666220435596566528",
  "in_reply_to_user_id" : 2425151,
  "text" : "@Facebook You can seriously ask someone to upload documents and block their profile any time you please? \uD83D\uDC7A",
  "id" : 666220435596566528,
  "created_at" : "2015-11-16 11:45:04 +0000",
  "in_reply_to_screen_name" : "facebook",
  "in_reply_to_user_id_str" : "2425151",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665991011705815040",
  "text" : "I finally creamed my dad in Fusball!!!",
  "id" : 665991011705815040,
  "created_at" : "2015-11-15 20:33:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665781617923768320",
  "text" : "Wow today was long, and it haven't even started, lol",
  "id" : 665781617923768320,
  "created_at" : "2015-11-15 06:41:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/665541415846477824\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/tpigah186P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTx6ZBDUcAAnfh1.jpg",
      "id_str" : "665541415141666816",
      "id" : 665541415141666816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTx6ZBDUcAAnfh1.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/tpigah186P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vTxX6TvSe2",
      "expanded_url" : "http:\/\/engt.co\/1kuzhKJ",
      "display_url" : "engt.co\/1kuzhKJ"
    } ]
  },
  "geo" : { },
  "id_str" : "665780807487766528",
  "text" : "RT @engadget: Gmail will soon warn you when an unencrypted message arrives https:\/\/t.co\/vTxX6TvSe2 https:\/\/t.co\/tpigah186P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/665541415846477824\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/tpigah186P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTx6ZBDUcAAnfh1.jpg",
        "id_str" : "665541415141666816",
        "id" : 665541415141666816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTx6ZBDUcAAnfh1.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/tpigah186P"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/vTxX6TvSe2",
        "expanded_url" : "http:\/\/engt.co\/1kuzhKJ",
        "display_url" : "engt.co\/1kuzhKJ"
      } ]
    },
    "geo" : { },
    "id_str" : "665541415846477824",
    "text" : "Gmail will soon warn you when an unencrypted message arrives https:\/\/t.co\/vTxX6TvSe2 https:\/\/t.co\/tpigah186P",
    "id" : 665541415846477824,
    "created_at" : "2015-11-14 14:46:53 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 665780807487766528,
  "created_at" : "2015-11-15 06:38:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@ \uD83C\uDF2E",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ryanholmestv",
      "indices" : [ 88, 101 ]
    }, {
      "text" : "tacotribe",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665780715573768193",
  "text" : "RT @HelloRyanHolmes: Working all day feels amazing.\nNeed to film a good skit though....\n#ryanholmestv #tacotribe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ryanholmestv",
        "indices" : [ 67, 80 ]
      }, {
        "text" : "tacotribe",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665611294439968768",
    "text" : "Working all day feels amazing.\nNeed to film a good skit though....\n#ryanholmestv #tacotribe",
    "id" : 665611294439968768,
    "created_at" : "2015-11-14 19:24:33 +0000",
    "user" : {
      "name" : "@ \uD83C\uDF2E",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866851965103464448\/r-66CBz0_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 665780715573768193,
  "created_at" : "2015-11-15 06:37:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joby Fawcett",
      "screen_name" : "JobyFawcett26",
      "indices" : [ 3, 17 ],
      "id_str" : "632991069",
      "id" : 632991069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665780533595516930",
  "text" : "RT @JobyFawcett26: Rhonda Rousey losing might have shocked me more than Tyson losing. But not As much as Warrior beating Hogan!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665771681978388480",
    "text" : "Rhonda Rousey losing might have shocked me more than Tyson losing. But not As much as Warrior beating Hogan!",
    "id" : 665771681978388480,
    "created_at" : "2015-11-15 06:01:53 +0000",
    "user" : {
      "name" : "Joby Fawcett",
      "screen_name" : "JobyFawcett26",
      "protected" : false,
      "id_str" : "632991069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2388151410\/PACO26_normal.jpg",
      "id" : 632991069,
      "verified" : false
    }
  },
  "id" : 665780533595516930,
  "created_at" : "2015-11-15 06:37:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe Helmy",
      "screen_name" : "GabeHelmy",
      "indices" : [ 3, 13 ],
      "id_str" : "144250313",
      "id" : 144250313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665780357933862916",
  "text" : "RT @GabeHelmy: Can't believe Rhonda Rousey actually lost. \uD83D\uDE33",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665779327171080192",
    "text" : "Can't believe Rhonda Rousey actually lost. \uD83D\uDE33",
    "id" : 665779327171080192,
    "created_at" : "2015-11-15 06:32:15 +0000",
    "user" : {
      "name" : "Gabe Helmy",
      "screen_name" : "GabeHelmy",
      "protected" : false,
      "id_str" : "144250313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856295476416716801\/CdpNdpSo_normal.jpg",
      "id" : 144250313,
      "verified" : false
    }
  },
  "id" : 665780357933862916,
  "created_at" : "2015-11-15 06:36:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665358732449193984",
  "text" : "RT @God_Instagram: You know what the sweetest time of the day is? When you pray. You want to know why? You are talking to the one who loves\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665357176873943040",
    "text" : "You know what the sweetest time of the day is? When you pray. You want to know why? You are talking to the one who loves you most.",
    "id" : 665357176873943040,
    "created_at" : "2015-11-14 02:34:47 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 665358732449193984,
  "created_at" : "2015-11-14 02:40:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AcapeIIaFunny\/status\/663863498397585408\/video\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/hhlt6wnnGu",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/663863202787303424\/pu\/img\/-zJmEPP-q3sO06kT.jpg",
      "id_str" : "663863202787303424",
      "id" : 663863202787303424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/663863202787303424\/pu\/img\/-zJmEPP-q3sO06kT.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/hhlt6wnnGu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665358410049822720",
  "text" : "RT @AcapeIIaFunny: THIS DUDE IS KILLING IT \uD83C\uDFBB https:\/\/t.co\/hhlt6wnnGu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AcapeIIaFunny\/status\/663863498397585408\/video\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/hhlt6wnnGu",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/663863202787303424\/pu\/img\/-zJmEPP-q3sO06kT.jpg",
        "id_str" : "663863202787303424",
        "id" : 663863202787303424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/663863202787303424\/pu\/img\/-zJmEPP-q3sO06kT.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/hhlt6wnnGu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663863498397585408",
    "text" : "THIS DUDE IS KILLING IT \uD83C\uDFBB https:\/\/t.co\/hhlt6wnnGu",
    "id" : 663863498397585408,
    "created_at" : "2015-11-09 23:39:26 +0000",
    "user" : {
      "name" : "Wow Your Voice",
      "screen_name" : "WowYourVoice",
      "protected" : false,
      "id_str" : "3244347322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741053525891776512\/cBAYv5vO_normal.jpg",
      "id" : 3244347322,
      "verified" : false
    }
  },
  "id" : 665358410049822720,
  "created_at" : "2015-11-14 02:39:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdist",
      "screen_name" : "nerdist",
      "indices" : [ 3, 11 ],
      "id_str" : "394216985",
      "id" : 394216985
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nerdist\/status\/665331641951236098\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/5W9er65SFF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTu7b7XUYAEUfc2.jpg",
      "id_str" : "665331458433638401",
      "id" : 665331458433638401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTu7b7XUYAEUfc2.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5W9er65SFF"
    } ],
    "hashtags" : [ {
      "text" : "Paris",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "ParisAttacks",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665357829298106369",
  "text" : "RT @nerdist: Here are several ways that you can help. Pass it on. #Paris #ParisAttacks https:\/\/t.co\/5W9er65SFF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nerdist\/status\/665331641951236098\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/5W9er65SFF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTu7b7XUYAEUfc2.jpg",
        "id_str" : "665331458433638401",
        "id" : 665331458433638401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTu7b7XUYAEUfc2.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5W9er65SFF"
      } ],
      "hashtags" : [ {
        "text" : "Paris",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "ParisAttacks",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665331641951236098",
    "text" : "Here are several ways that you can help. Pass it on. #Paris #ParisAttacks https:\/\/t.co\/5W9er65SFF",
    "id" : 665331641951236098,
    "created_at" : "2015-11-14 00:53:19 +0000",
    "user" : {
      "name" : "Nerdist",
      "screen_name" : "nerdist",
      "protected" : false,
      "id_str" : "394216985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658730129066102784\/qH6cpyVx_normal.png",
      "id" : 394216985,
      "verified" : true
    }
  },
  "id" : 665357829298106369,
  "created_at" : "2015-11-14 02:37:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben & Candy Carson",
      "screen_name" : "RealBenCarson",
      "indices" : [ 3, 17 ],
      "id_str" : "1180379185",
      "id" : 1180379185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665357308109701120",
  "text" : "RT @RealBenCarson: My thoughts and prayers are with the people in Paris tonight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665290853305483264",
    "text" : "My thoughts and prayers are with the people in Paris tonight.",
    "id" : 665290853305483264,
    "created_at" : "2015-11-13 22:11:14 +0000",
    "user" : {
      "name" : "Ben & Candy Carson",
      "screen_name" : "RealBenCarson",
      "protected" : false,
      "id_str" : "1180379185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837440614941741056\/2TF4eFG7_normal.jpg",
      "id" : 1180379185,
      "verified" : true
    }
  },
  "id" : 665357308109701120,
  "created_at" : "2015-11-14 02:35:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665357269840850949",
  "text" : "RT @tedcruz: Our deepest condolences go out to our French allies. I know the the US stands by to offer any assistance necessary: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/oM9GFyPift",
        "expanded_url" : "https:\/\/www.tedcruz.org\/news\/cruz-america-must-stand-with-our-allies-against-the-scourge-of-radical-islamic-terrorism\/",
        "display_url" : "tedcruz.org\/news\/cruz-amer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "665350801557094400",
    "text" : "Our deepest condolences go out to our French allies. I know the the US stands by to offer any assistance necessary: https:\/\/t.co\/oM9GFyPift",
    "id" : 665350801557094400,
    "created_at" : "2015-11-14 02:09:27 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 665357269840850949,
  "created_at" : "2015-11-14 02:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/oM9GFyPift",
      "expanded_url" : "https:\/\/www.tedcruz.org\/news\/cruz-america-must-stand-with-our-allies-against-the-scourge-of-radical-islamic-terrorism\/",
      "display_url" : "tedcruz.org\/news\/cruz-amer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "665357260789518336",
  "text" : "RT @tedcruz: America must stand with our allies against the scourge of radical Islamic terrorism: https:\/\/t.co\/oM9GFyPift",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/oM9GFyPift",
        "expanded_url" : "https:\/\/www.tedcruz.org\/news\/cruz-america-must-stand-with-our-allies-against-the-scourge-of-radical-islamic-terrorism\/",
        "display_url" : "tedcruz.org\/news\/cruz-amer\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "665350801557094400",
    "geo" : { },
    "id_str" : "665350955022454785",
    "in_reply_to_user_id" : 23022687,
    "text" : "America must stand with our allies against the scourge of radical Islamic terrorism: https:\/\/t.co\/oM9GFyPift",
    "id" : 665350955022454785,
    "in_reply_to_status_id" : 665350801557094400,
    "created_at" : "2015-11-14 02:10:03 +0000",
    "in_reply_to_screen_name" : "tedcruz",
    "in_reply_to_user_id_str" : "23022687",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 665357260789518336,
  "created_at" : "2015-11-14 02:35:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665357246059192320",
  "text" : "RT @tedcruz: We must make it clear that affiliation w\/ ISIS &amp; related terrorist groups brings w\/ it the undying enmity of America https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/oM9GFyPift",
        "expanded_url" : "https:\/\/www.tedcruz.org\/news\/cruz-america-must-stand-with-our-allies-against-the-scourge-of-radical-islamic-terrorism\/",
        "display_url" : "tedcruz.org\/news\/cruz-amer\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "665350955022454785",
    "geo" : { },
    "id_str" : "665351253690454016",
    "in_reply_to_user_id" : 23022687,
    "text" : "We must make it clear that affiliation w\/ ISIS &amp; related terrorist groups brings w\/ it the undying enmity of America https:\/\/t.co\/oM9GFyPift",
    "id" : 665351253690454016,
    "in_reply_to_status_id" : 665350955022454785,
    "created_at" : "2015-11-14 02:11:15 +0000",
    "in_reply_to_screen_name" : "tedcruz",
    "in_reply_to_user_id_str" : "23022687",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 665357246059192320,
  "created_at" : "2015-11-14 02:35:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kowalski the Penguin",
      "screen_name" : "RSPCTtheScience",
      "indices" : [ 3, 19 ],
      "id_str" : "117135355",
      "id" : 117135355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665356149214941186",
  "text" : "RT @RSPCTtheScience: Goodness, receiving breaking news about Paris, Japan and other places around the world. Heartbreaking...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665351730545037312",
    "text" : "Goodness, receiving breaking news about Paris, Japan and other places around the world. Heartbreaking...",
    "id" : 665351730545037312,
    "created_at" : "2015-11-14 02:13:08 +0000",
    "user" : {
      "name" : "Kowalski the Penguin",
      "screen_name" : "RSPCTtheScience",
      "protected" : false,
      "id_str" : "117135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858057010973204485\/e6pH7Dmb_normal.jpg",
      "id" : 117135355,
      "verified" : false
    }
  },
  "id" : 665356149214941186,
  "created_at" : "2015-11-14 02:30:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/665356003991490560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NyIwz3JR3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTvRwc8VEAAgRj4.jpg",
      "id_str" : "665356000300437504",
      "id" : 665356000300437504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTvRwc8VEAAgRj4.jpg",
      "sizes" : [ {
        "h" : 408,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/NyIwz3JR3m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665356003991490560",
  "text" : "Atheist logic 101: Insult people's points of views, and call everything you don't agree with crap without reading it https:\/\/t.co\/NyIwz3JR3m",
  "id" : 665356003991490560,
  "created_at" : "2015-11-14 02:30:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/665272798252818433\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/OEIi440czd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTuGE2rWEAABBXX.jpg",
      "id_str" : "665272787922194432",
      "id" : 665272787922194432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTuGE2rWEAABBXX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OEIi440czd"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665272798252818433",
  "text" : "That wasn't the best pizza #ThisIsOU https:\/\/t.co\/OEIi440czd",
  "id" : 665272798252818433,
  "created_at" : "2015-11-13 20:59:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665229105273552898",
  "geo" : { },
  "id_str" : "665229438599176192",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Self-defense isn't genocide. I am done debating as my time is more valuable.",
  "id" : 665229438599176192,
  "in_reply_to_status_id" : 665229105273552898,
  "created_at" : "2015-11-13 18:07:12 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665228860246519809",
  "geo" : { },
  "id_str" : "665229188366925824",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic The laws of thermodynamics doesn't contradict creationism, as for probability, it is another argument",
  "id" : 665229188366925824,
  "in_reply_to_status_id" : 665228860246519809,
  "created_at" : "2015-11-13 18:06:12 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665228585733521408",
  "geo" : { },
  "id_str" : "665228936587137024",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic I suggest you read Dr.Craig's or Ravi Zacharias's books and look at both sides of the argument.",
  "id" : 665228936587137024,
  "in_reply_to_status_id" : 665228585733521408,
  "created_at" : "2015-11-13 18:05:12 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665228038125187073",
  "geo" : { },
  "id_str" : "665228586769588225",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic I am shaking my head right now, did you read your tweet where you said \"by the same argument\"",
  "id" : 665228586769588225,
  "in_reply_to_status_id" : 665228038125187073,
  "created_at" : "2015-11-13 18:03:49 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665227541632815104",
  "geo" : { },
  "id_str" : "665228197081034752",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Kant himself recognized the philosophy of the bible as the most profound book of wisdom.",
  "id" : 665228197081034752,
  "in_reply_to_status_id" : 665227541632815104,
  "created_at" : "2015-11-13 18:02:16 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665227541632815104",
  "geo" : { },
  "id_str" : "665228042122473472",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic I use both, Charles Darwin's own autobiography states his aspirations fairly clearly",
  "id" : 665228042122473472,
  "in_reply_to_status_id" : 665227541632815104,
  "created_at" : "2015-11-13 18:01:39 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665054866453065728",
  "geo" : { },
  "id_str" : "665227019198820352",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic You think the laws of nature applies to the one who created nature, I conclude the argument as a fallacy.",
  "id" : 665227019198820352,
  "in_reply_to_status_id" : 665054866453065728,
  "created_at" : "2015-11-13 17:57:35 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665054258799120385",
  "geo" : { },
  "id_str" : "665226642386788352",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic God existed on his own and isn't pre-existing matter. God existed before matter itself. This is the argument.",
  "id" : 665226642386788352,
  "in_reply_to_status_id" : 665054258799120385,
  "created_at" : "2015-11-13 17:56:05 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665053110839042048",
  "geo" : { },
  "id_str" : "665226401960894464",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic This is Numbers 31:17 and that wasn't the correct translation of the verse.",
  "id" : 665226401960894464,
  "in_reply_to_status_id" : 665053110839042048,
  "created_at" : "2015-11-13 17:55:08 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665051407683223552",
  "geo" : { },
  "id_str" : "665225853098438656",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Do you even know the deontological wisdom of the bible?",
  "id" : 665225853098438656,
  "in_reply_to_status_id" : 665051407683223552,
  "created_at" : "2015-11-13 17:52:57 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665051407683223552",
  "geo" : { },
  "id_str" : "665225739097268224",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic I wanna see how you interpret secular texts before misinterpreting the bible for advocating murder.",
  "id" : 665225739097268224,
  "in_reply_to_status_id" : 665051407683223552,
  "created_at" : "2015-11-13 17:52:30 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665050179104407552",
  "geo" : { },
  "id_str" : "665225265795227648",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic You do know the Bible has a Torah don't you?",
  "id" : 665225265795227648,
  "in_reply_to_status_id" : 665050179104407552,
  "created_at" : "2015-11-13 17:50:37 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665045318803681280",
  "geo" : { },
  "id_str" : "665224942603116545",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic So the creator of nature is subject to the laws of nature. I see how it isn't an argument in its logical sense.",
  "id" : 665224942603116545,
  "in_reply_to_status_id" : 665045318803681280,
  "created_at" : "2015-11-13 17:49:20 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665045181398253568",
  "geo" : { },
  "id_str" : "665224492562649088",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic I haven't even read this tweet yet, but think of the respectful integrity of Dawkins and get back to me",
  "id" : 665224492562649088,
  "in_reply_to_status_id" : 665045181398253568,
  "created_at" : "2015-11-13 17:47:32 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665043148335222784",
  "geo" : { },
  "id_str" : "665224239503581184",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Thanks for using Wikipedia as a resource, and what is your non-bias source? Dawkins I suppose?",
  "id" : 665224239503581184,
  "in_reply_to_status_id" : 665043148335222784,
  "created_at" : "2015-11-13 17:46:32 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Harlow",
      "screen_name" : "harlowscourt",
      "indices" : [ 3, 16 ],
      "id_str" : "25908946",
      "id" : 25908946
    }, {
      "name" : "#ViralChat",
      "screen_name" : "ViralChat",
      "indices" : [ 18, 28 ],
      "id_str" : "3180306782",
      "id" : 3180306782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664993543509966849",
  "text" : "RT @harlowscourt: @ViralChat I think editing is key in video content. Also tags utilizing key words is the key to online video content. #Vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#ViralChat",
        "screen_name" : "ViralChat",
        "indices" : [ 0, 10 ],
        "id_str" : "3180306782",
        "id" : 3180306782
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ViralChat",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "664991628743024642",
    "geo" : { },
    "id_str" : "664992329011326976",
    "in_reply_to_user_id" : 3180306782,
    "text" : "@ViralChat I think editing is key in video content. Also tags utilizing key words is the key to online video content. #ViralChat",
    "id" : 664992329011326976,
    "in_reply_to_status_id" : 664991628743024642,
    "created_at" : "2015-11-13 02:25:00 +0000",
    "in_reply_to_screen_name" : "ViralChat",
    "in_reply_to_user_id_str" : "3180306782",
    "user" : {
      "name" : "Courtney Harlow",
      "screen_name" : "harlowscourt",
      "protected" : false,
      "id_str" : "25908946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727878545272414208\/_P5kv_Vu_normal.jpg",
      "id" : 25908946,
      "verified" : false
    }
  },
  "id" : 664993543509966849,
  "created_at" : "2015-11-13 02:29:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664993227125227521",
  "text" : "If increasing wages bring more qualified people, than you have no idea how competitive the job market is.",
  "id" : 664993227125227521,
  "created_at" : "2015-11-13 02:28:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 16, 25 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664971957297770497",
  "geo" : { },
  "id_str" : "664974902240395265",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @mashable The future??? \uD83D\uDE02",
  "id" : 664974902240395265,
  "in_reply_to_status_id" : 664971957297770497,
  "created_at" : "2015-11-13 01:15:45 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/0772Cp9Lg5",
      "expanded_url" : "http:\/\/mashable.com\/2015\/11\/12\/google-car-pulled-over\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2015\/11\/12\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664974785022136320",
  "text" : "RT @EmperorDarroux: A self-driving Google car was pulled over for driving too slow https:\/\/t.co\/0772Cp9Lg5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/0772Cp9Lg5",
        "expanded_url" : "http:\/\/mashable.com\/2015\/11\/12\/google-car-pulled-over\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2015\/11\/12\/goo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664972039564890112",
    "text" : "A self-driving Google car was pulled over for driving too slow https:\/\/t.co\/0772Cp9Lg5",
    "id" : 664972039564890112,
    "created_at" : "2015-11-13 01:04:23 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 664974785022136320,
  "created_at" : "2015-11-13 01:15:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664974423926169600",
  "text" : "In regards to Dr.Taub's lecture today, it was quite insightful, but I don't think increasing wages and inflation makes sense economically",
  "id" : 664974423926169600,
  "created_at" : "2015-11-13 01:13:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 0, 15 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664970837850759169",
  "in_reply_to_user_id" : 15143478,
  "text" : "@RichardDawkins I will be amazed when instead of making a documentary calling people uneducated ignoramuses, you debate respectively",
  "id" : 664970837850759169,
  "created_at" : "2015-11-13 00:59:36 +0000",
  "in_reply_to_screen_name" : "RichardDawkins",
  "in_reply_to_user_id_str" : "15143478",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikD",
      "screen_name" : "_NIKD_",
      "indices" : [ 0, 7 ],
      "id_str" : "52840292",
      "id" : 52840292
    }, {
      "name" : "Just Luca",
      "screen_name" : "Just1Luca",
      "indices" : [ 8, 18 ],
      "id_str" : "2444536352",
      "id" : 2444536352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664884573159989248",
  "geo" : { },
  "id_str" : "664968653599875072",
  "in_reply_to_user_id" : 52840292,
  "text" : "@_NIKD_ @Just1Luca All I see is two guys name calling and stating something is false without trying to prove a point respectively",
  "id" : 664968653599875072,
  "in_reply_to_status_id" : 664884573159989248,
  "created_at" : "2015-11-13 00:50:56 +0000",
  "in_reply_to_screen_name" : "_NIKD_",
  "in_reply_to_user_id_str" : "52840292",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664907627483279360",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Can you state that evolution has certainly no flaws and can't be reevaluated from time to time?",
  "id" : 664907627483279360,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:48:26 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664907410017009664",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic The problem with science is if it is a law, it can't be unchanged, or experimented with, leaving them not to call it science",
  "id" : 664907410017009664,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:47:34 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664907090448801793",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic One can simply argue that God existed before matter itself. If evolution is irrefutable and not flawed it would be a law",
  "id" : 664907090448801793,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:46:18 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664904399853080576",
  "text" : "The most ridiculous thing is to look at the beauty of the human genome, and state it was an accident. Doesn't matter the length of time.",
  "id" : 664904399853080576,
  "created_at" : "2015-11-12 20:35:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664904121217101824",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic If we are simply an evolved species and right and wrong is a state of mind, what makes us even human?",
  "id" : 664904121217101824,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:34:30 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664903932636962817",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic We have errors calculating things from 4,400 years who, but we can calculate things from billions of years ago?",
  "id" : 664903932636962817,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:33:45 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664903458030542848",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Yes the universe is constantly expanding but the matter wasn't simply already there.",
  "id" : 664903458030542848,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:31:52 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664903327537340416",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Do you know the possibility of the whole universe constantly expanding over pre-existing matter?",
  "id" : 664903327537340416,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:31:21 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664890902737911808",
  "geo" : { },
  "id_str" : "664903156464287745",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Do you know the mathematical possibility of one protein being created by chance?",
  "id" : 664903156464287745,
  "in_reply_to_status_id" : 664890902737911808,
  "created_at" : "2015-11-12 20:30:40 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/664901859455410176\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/PWnF8PZKyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTo0sEEUkAAW8js.jpg",
      "id_str" : "664901826601324544",
      "id" : 664901826601324544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTo0sEEUkAAW8js.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PWnF8PZKyI"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664901859455410176",
  "text" : "Going to a lecture by Dr.Paul Traub #ThisIsOU https:\/\/t.co\/PWnF8PZKyI",
  "id" : 664901859455410176,
  "created_at" : "2015-11-12 20:25:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664662040040988673",
  "geo" : { },
  "id_str" : "664888702447976448",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic not just a small tweet",
  "id" : 664888702447976448,
  "in_reply_to_status_id" : 664662040040988673,
  "created_at" : "2015-11-12 19:33:14 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erudite",
      "screen_name" : "thescholastic",
      "indices" : [ 0, 14 ],
      "id_str" : "179411829",
      "id" : 179411829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664662040040988673",
  "geo" : { },
  "id_str" : "664888650811899904",
  "in_reply_to_user_id" : 179411829,
  "text" : "@thescholastic Search the evolution fraud, or read the book, \"What your atheist professor doesn't know\", this would take hours to explain",
  "id" : 664888650811899904,
  "in_reply_to_status_id" : 664662040040988673,
  "created_at" : "2015-11-12 19:33:02 +0000",
  "in_reply_to_screen_name" : "thescholastic",
  "in_reply_to_user_id_str" : "179411829",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/664888390018428928\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/cTrX3tLvBk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTooc8sUEAAKhvh.jpg",
      "id_str" : "664888372784009216",
      "id" : 664888372784009216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTooc8sUEAAKhvh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cTrX3tLvBk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664888390018428928",
  "text" : "Went to the pantry, so good!!! https:\/\/t.co\/cTrX3tLvBk",
  "id" : 664888390018428928,
  "created_at" : "2015-11-12 19:31:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664546127908372481",
  "text" : "The Theory of Evolution and the Big Bang are so fundamentally flawed in its evidence, that apparently the adopters of it are confused",
  "id" : 664546127908372481,
  "created_at" : "2015-11-11 20:51:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664545864434741248",
  "text" : "Do you know half of what your beliefs stated? You learned the facts at school? Do you know all the inaccuracies behind your beliefs?",
  "id" : 664545864434741248,
  "created_at" : "2015-11-11 20:50:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664541551805247489",
  "text" : "The biggest fundamental problem in human nature is prideful ignorance",
  "id" : 664541551805247489,
  "created_at" : "2015-11-11 20:33:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 3, 16 ],
      "id_str" : "19362341",
      "id" : 19362341
    }, {
      "name" : "Jesse Itzler",
      "screen_name" : "the100MileMan",
      "indices" : [ 31, 45 ],
      "id_str" : "43122230",
      "id" : 43122230
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NavySEAL",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664527602086989824",
  "text" : "RT @mariashriver: Entrepreneur @the100MileMan invited a #NavySEAL to live with him for a month &amp; shares 5 lessons he learned from him: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Itzler",
        "screen_name" : "the100MileMan",
        "indices" : [ 13, 27 ],
        "id_str" : "43122230",
        "id" : 43122230
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NavySEAL",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/rgP8PxZBN9",
        "expanded_url" : "http:\/\/mariashriver.com\/blog\/2015\/11\/what-i-learned-from-living-with-a-navy-seal-jesse-itzler\/",
        "display_url" : "mariashriver.com\/blog\/2015\/11\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664526792989007874",
    "text" : "Entrepreneur @the100MileMan invited a #NavySEAL to live with him for a month &amp; shares 5 lessons he learned from him: https:\/\/t.co\/rgP8PxZBN9",
    "id" : 664526792989007874,
    "created_at" : "2015-11-11 19:35:08 +0000",
    "user" : {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "protected" : false,
      "id_str" : "19362341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522145107785428992\/zP6X2qUd_normal.jpeg",
      "id" : 19362341,
      "verified" : true
    }
  },
  "id" : 664527602086989824,
  "created_at" : "2015-11-11 19:38:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/664526979740381185\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Ca2zeNQn9R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTjfxGHWwAAVrJk.jpg",
      "id_str" : "664526979585196032",
      "id" : 664526979585196032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTjfxGHWwAAVrJk.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ca2zeNQn9R"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/eeGDqDfOnU",
      "expanded_url" : "http:\/\/holykaw.alltop.com\/how-to-create-homemade-whipped-cream-in-30-seconds?gk4",
      "display_url" : "holykaw.alltop.com\/how-to-create-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664527520771870720",
  "text" : "RT @GuyKawasaki: How to create homemade whipped cream in 30 seconds https:\/\/t.co\/eeGDqDfOnU https:\/\/t.co\/Ca2zeNQn9R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/alltop.com\/\" rel=\"nofollow\"\u003EAlltop Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/664526979740381185\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Ca2zeNQn9R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTjfxGHWwAAVrJk.jpg",
        "id_str" : "664526979585196032",
        "id" : 664526979585196032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTjfxGHWwAAVrJk.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ca2zeNQn9R"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/eeGDqDfOnU",
        "expanded_url" : "http:\/\/holykaw.alltop.com\/how-to-create-homemade-whipped-cream-in-30-seconds?gk4",
        "display_url" : "holykaw.alltop.com\/how-to-create-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664526979740381185",
    "text" : "How to create homemade whipped cream in 30 seconds https:\/\/t.co\/eeGDqDfOnU https:\/\/t.co\/Ca2zeNQn9R",
    "id" : 664526979740381185,
    "created_at" : "2015-11-11 19:35:52 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 664527520771870720,
  "created_at" : "2015-11-11 19:38:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/LI8JA9l5ly",
      "expanded_url" : "http:\/\/on.wsj.com\/QLl6Q5",
      "display_url" : "on.wsj.com\/QLl6Q5"
    } ]
  },
  "geo" : { },
  "id_str" : "664527436403617793",
  "text" : "Peter Schiff: The Fantasy of a 91% Top Income Tax Rate https:\/\/t.co\/LI8JA9l5ly via WSJ \nThe 91% marginal tax misrepresentation by liberals",
  "id" : 664527436403617793,
  "created_at" : "2015-11-11 19:37:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664526373827014657",
  "text" : "The fast and furious scandal isn't a conspiracy, get your facts checked",
  "id" : 664526373827014657,
  "created_at" : "2015-11-11 19:33:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664526196709957632",
  "text" : "RT @hannahbleau_: Cruz's tackle on amnesty almost made me cry. Thousand times YES. #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664272462280986624",
    "text" : "Cruz's tackle on amnesty almost made me cry. Thousand times YES. #GOPDebate",
    "id" : 664272462280986624,
    "created_at" : "2015-11-11 02:44:31 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 664526196709957632,
  "created_at" : "2015-11-11 19:32:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664526180511588352",
  "text" : "RT @hannahbleau_: \"Philosophy doesn\u2019t work when you run something.\u201D So you'd abandon principle. Good to know, Kasich. #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664290334088761344",
    "text" : "\"Philosophy doesn\u2019t work when you run something.\u201D So you'd abandon principle. Good to know, Kasich. #GOPDebate",
    "id" : 664290334088761344,
    "created_at" : "2015-11-11 03:55:32 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 664526180511588352,
  "created_at" : "2015-11-11 19:32:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664525799379378177",
  "text" : "He thinks he won the debate by calling everything I said a fallacy, using profanity, than walking out. Should have stood hours with me. Smh",
  "id" : 664525799379378177,
  "created_at" : "2015-11-11 19:31:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664525401293721602",
  "text" : "Someone said the unemployment rate went down under Obama's presidency and also said Obama is a smaller spender then Bush, is he serious?",
  "id" : 664525401293721602,
  "created_at" : "2015-11-11 19:29:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664495067793596416",
  "text" : "Happy Veteran's day to all our soldiers, do something nice. Buy a soldier a coffee, maybe bake a pie. They deserve an account of kindness :)",
  "id" : 664495067793596416,
  "created_at" : "2015-11-11 17:29:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664271124729954304",
  "text" : "Gotta sleep but I heard what I wanted!!! #GOPDebate",
  "id" : 664271124729954304,
  "created_at" : "2015-11-11 02:39:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664270916939988992",
  "text" : "Jeb is speaking, ugh!!",
  "id" : 664270916939988992,
  "created_at" : "2015-11-11 02:38:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664270175902896128",
  "text" : "Trump is destroying Kasich right now \uD83D\uDE02",
  "id" : 664270175902896128,
  "created_at" : "2015-11-11 02:35:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle\uD83C\uDF3B",
      "screen_name" : "danielleakrawi",
      "indices" : [ 0, 15 ],
      "id_str" : "1523963450",
      "id" : 1523963450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664269406243962880",
  "in_reply_to_user_id" : 1523963450,
  "text" : "@danielleakrawi haha :P",
  "id" : 664269406243962880,
  "created_at" : "2015-11-11 02:32:22 +0000",
  "in_reply_to_screen_name" : "danielleakrawi",
  "in_reply_to_user_id_str" : "1523963450",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664269314153775104",
  "text" : "Carsen is an honest person, but Cruz is still my favorite :) #GOPDebate",
  "id" : 664269314153775104,
  "created_at" : "2015-11-11 02:32:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664267728572817410",
  "text" : "Rand Paul = End the Fed or regulate them #GOPDebate",
  "id" : 664267728572817410,
  "created_at" : "2015-11-11 02:25:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664267411869298688",
  "text" : "RT @hannahbleau_: Stop Kasich. Just stop. I'm over it. #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664265247310479361",
    "text" : "Stop Kasich. Just stop. I'm over it. #GOPDebate",
    "id" : 664265247310479361,
    "created_at" : "2015-11-11 02:15:51 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 664267411869298688,
  "created_at" : "2015-11-11 02:24:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 36, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664267192331018241",
  "text" : "Ted Cruz is crushing it like always #GOP",
  "id" : 664267192331018241,
  "created_at" : "2015-11-11 02:23:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664267082679341056",
  "text" : "We had problems for a long time. This country is crushing economic growth.- Carly Fiorina #GOPDebate",
  "id" : 664267082679341056,
  "created_at" : "2015-11-11 02:23:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664266715119935488",
  "text" : "Obama's policies, not an A, may be the best Hillary can do, but not America- Jeb Bush #GOPDebate",
  "id" : 664266715119935488,
  "created_at" : "2015-11-11 02:21:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664265802682626048",
  "text" : "The Obama economy is a disaster and it doesn't have to be this way- Ted Cruz #GOPDebate",
  "id" : 664265802682626048,
  "created_at" : "2015-11-11 02:18:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664264872738299904",
  "text" : "Please lower the taxes for businesses -Kasich #GOPDebate",
  "id" : 664264872738299904,
  "created_at" : "2015-11-11 02:14:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664263902952296448",
  "text" : "People have the ability to enter the job market, and take advantage of their opportunities- Carsen #GOPDebate",
  "id" : 664263902952296448,
  "created_at" : "2015-11-11 02:10:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minimumwage",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664263427699945473",
  "text" : "We can't compete against the rest of the world like this-Trump #minimumwage",
  "id" : 664263427699945473,
  "created_at" : "2015-11-11 02:08:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/664144516316811268\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/DyO3I2sc68",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTeD6LaU8AEdY5c.jpg",
      "id_str" : "664144505579302913",
      "id" : 664144505579302913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTeD6LaU8AEdY5c.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DyO3I2sc68"
    } ],
    "hashtags" : [ {
      "text" : "Grizzcave",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664144516316811268",
  "text" : "This is what I tell my mom is eating healthy, #Grizzcave 2.85\/5 stars https:\/\/t.co\/DyO3I2sc68",
  "id" : 664144516316811268,
  "created_at" : "2015-11-10 18:16:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OU ID Card Office",
      "screen_name" : "OUGrizzCard",
      "indices" : [ 3, 15 ],
      "id_str" : "4113310475",
      "id" : 4113310475
    }, {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 46, 55 ],
      "id_str" : "17468189",
      "id" : 17468189
    }, {
      "name" : "Elliott Tower",
      "screen_name" : "OUClocktower",
      "indices" : [ 109, 122 ],
      "id_str" : "2668394219",
      "id" : 2668394219
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisisOU",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664138358050963462",
  "text" : "RT @OUGRIZZCard: It's a rainy fall morning at @oaklandu today. Make sure you bring your umbrellas! #thisisOU @OUClocktower https:\/\/t.co\/69p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oakland University",
        "screen_name" : "oaklandu",
        "indices" : [ 29, 38 ],
        "id_str" : "17468189",
        "id" : 17468189
      }, {
        "name" : "Elliott Tower",
        "screen_name" : "OUClocktower",
        "indices" : [ 92, 105 ],
        "id_str" : "2668394219",
        "id" : 2668394219
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OUGRIZZCard\/status\/664092376537911296\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/69pK0oDc9A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTdUfBzWwAQAM1v.jpg",
        "id_str" : "664092362096951300",
        "id" : 664092362096951300,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTdUfBzWwAQAM1v.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/69pK0oDc9A"
      } ],
      "hashtags" : [ {
        "text" : "thisisOU",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664092376537911296",
    "text" : "It's a rainy fall morning at @oaklandu today. Make sure you bring your umbrellas! #thisisOU @OUClocktower https:\/\/t.co\/69pK0oDc9A",
    "id" : 664092376537911296,
    "created_at" : "2015-11-10 14:48:55 +0000",
    "user" : {
      "name" : "OU ID Card Office",
      "screen_name" : "OUGrizzCard",
      "protected" : false,
      "id_str" : "4113310475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661949834010693632\/kuVAW_ez_normal.jpg",
      "id" : 4113310475,
      "verified" : false
    }
  },
  "id" : 664138358050963462,
  "created_at" : "2015-11-10 17:51:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudentsForLifeFUS",
      "screen_name" : "SFL_FUS",
      "indices" : [ 0, 8 ],
      "id_str" : "284914377",
      "id" : 284914377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657589995973296128",
  "geo" : { },
  "id_str" : "664138255818977281",
  "in_reply_to_user_id" : 284914377,
  "text" : "@SFL_FUS Defund those destroyers now!!!",
  "id" : 664138255818977281,
  "in_reply_to_status_id" : 657589995973296128,
  "created_at" : "2015-11-10 17:51:13 +0000",
  "in_reply_to_screen_name" : "SFL_FUS",
  "in_reply_to_user_id_str" : "284914377",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Students4Life",
      "indices" : [ 59, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664137869716533248",
  "text" : "Woman should never chose abortion, it is a moral injustice #Students4Life",
  "id" : 664137869716533248,
  "created_at" : "2015-11-10 17:49:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/k3UkVpUIAz",
      "expanded_url" : "https:\/\/twitter.com\/josef_lokmani\/status\/664078531366899712",
      "display_url" : "twitter.com\/josef_lokmani\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664111720483430404",
  "text" : "Oh Josef, you are thinking outside the box https:\/\/t.co\/k3UkVpUIAz",
  "id" : 664111720483430404,
  "created_at" : "2015-11-10 16:05:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#legend",
      "screen_name" : "FUBARrockchick",
      "indices" : [ 3, 18 ],
      "id_str" : "299062149",
      "id" : 299062149
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Mashable Tech",
      "screen_name" : "mashabletech",
      "indices" : [ 34, 47 ],
      "id_str" : "112243365",
      "id" : 112243365
    }, {
      "name" : "rose mcgowan",
      "screen_name" : "rosemcgowan",
      "indices" : [ 49, 61 ],
      "id_str" : "46233559",
      "id" : 46233559
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 62, 71 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664111620155703300",
  "text" : "RT @FUBARrockchick: @gamer456148\u27A1 @mashabletech  @rosemcgowan @mashable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Mashable Tech",
        "screen_name" : "mashabletech",
        "indices" : [ 14, 27 ],
        "id_str" : "112243365",
        "id" : 112243365
      }, {
        "name" : "rose mcgowan",
        "screen_name" : "rosemcgowan",
        "indices" : [ 29, 41 ],
        "id_str" : "46233559",
        "id" : 46233559
      }, {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 42, 51 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "664102439411425282",
    "geo" : { },
    "id_str" : "664106635837751296",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148\u27A1 @mashabletech  @rosemcgowan @mashable",
    "id" : 664106635837751296,
    "in_reply_to_status_id" : 664102439411425282,
    "created_at" : "2015-11-10 15:45:35 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "#legend",
      "screen_name" : "FUBARrockchick",
      "protected" : false,
      "id_str" : "299062149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844676234277765125\/s1RaZrNy_normal.jpg",
      "id" : 299062149,
      "verified" : false
    }
  },
  "id" : 664111620155703300,
  "created_at" : "2015-11-10 16:05:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#legend",
      "screen_name" : "FUBARrockchick",
      "indices" : [ 0, 15 ],
      "id_str" : "299062149",
      "id" : 299062149
    }, {
      "name" : "rose mcgowan",
      "screen_name" : "rosemcgowan",
      "indices" : [ 16, 28 ],
      "id_str" : "46233559",
      "id" : 46233559
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 29, 38 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "664101235356803072",
  "geo" : { },
  "id_str" : "664102439411425282",
  "in_reply_to_user_id" : 299062149,
  "text" : "@FUBARrockchick @rosemcgowan @mashable What does this have to do with Tech?",
  "id" : 664102439411425282,
  "in_reply_to_status_id" : 664101235356803072,
  "created_at" : "2015-11-10 15:28:54 +0000",
  "in_reply_to_screen_name" : "FUBARrockchick",
  "in_reply_to_user_id_str" : "299062149",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 4, 14 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1stworldproblems",
      "indices" : [ 62, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664101943887941632",
  "text" : "The @Starbucks at Frankie's cafe forgot the caramel, again!!! #1stworldproblems",
  "id" : 664101943887941632,
  "created_at" : "2015-11-10 15:26:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#legend",
      "screen_name" : "FUBARrockchick",
      "indices" : [ 3, 18 ],
      "id_str" : "299062149",
      "id" : 299062149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663922331866275840",
  "text" : "RT @FUBARrockchick: \"I don't care what people think or say about me, I know who I am.\" - Jonathan Davis,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663897639419813889",
    "text" : "\"I don't care what people think or say about me, I know who I am.\" - Jonathan Davis,",
    "id" : 663897639419813889,
    "created_at" : "2015-11-10 01:55:06 +0000",
    "user" : {
      "name" : "#legend",
      "screen_name" : "FUBARrockchick",
      "protected" : false,
      "id_str" : "299062149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844676234277765125\/s1RaZrNy_normal.jpg",
      "id" : 299062149,
      "verified" : false
    }
  },
  "id" : 663922331866275840,
  "created_at" : "2015-11-10 03:33:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 3, 16 ],
      "id_str" : "19362341",
      "id" : 19362341
    }, {
      "name" : "Sargent Shriver",
      "screen_name" : "RSargentShriver",
      "indices" : [ 104, 120 ],
      "id_str" : "240782721",
      "id" : 240782721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663900915678756864",
  "text" : "RT @mariashriver: One more time because I love you: Happy birthday daddy. 100 years old in heaven today @RSargentShriver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sargent Shriver",
        "screen_name" : "RSargentShriver",
        "indices" : [ 86, 102 ],
        "id_str" : "240782721",
        "id" : 240782721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663895741505495040",
    "text" : "One more time because I love you: Happy birthday daddy. 100 years old in heaven today @RSargentShriver",
    "id" : 663895741505495040,
    "created_at" : "2015-11-10 01:47:34 +0000",
    "user" : {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "protected" : false,
      "id_str" : "19362341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522145107785428992\/zP6X2qUd_normal.jpeg",
      "id" : 19362341,
      "verified" : true
    }
  },
  "id" : 663900915678756864,
  "created_at" : "2015-11-10 02:08:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 3, 16 ],
      "id_str" : "19362341",
      "id" : 19362341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/gDYUSMxIyT",
      "expanded_url" : "http:\/\/sargentshriver.org\/blog\/on-sarges-100th-birthday-he-calls-on-us-to-break-our-mirrors",
      "display_url" : "sargentshriver.org\/blog\/on-sarges\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663900759260585984",
  "text" : "RT @mariashriver: Today would have been my dad's 100th birthday. In his honor,  I hope you Break Your Mirrors: https:\/\/t.co\/gDYUSMxIyT http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mariashriver\/status\/663774176482693120\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rDW1nPVsKm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTYzGARUAAAW6cx.jpg",
        "id_str" : "663774173328572416",
        "id" : 663774173328572416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTYzGARUAAAW6cx.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 835,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rDW1nPVsKm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/gDYUSMxIyT",
        "expanded_url" : "http:\/\/sargentshriver.org\/blog\/on-sarges-100th-birthday-he-calls-on-us-to-break-our-mirrors",
        "display_url" : "sargentshriver.org\/blog\/on-sarges\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663774176482693120",
    "text" : "Today would have been my dad's 100th birthday. In his honor,  I hope you Break Your Mirrors: https:\/\/t.co\/gDYUSMxIyT https:\/\/t.co\/rDW1nPVsKm",
    "id" : 663774176482693120,
    "created_at" : "2015-11-09 17:44:30 +0000",
    "user" : {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "protected" : false,
      "id_str" : "19362341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522145107785428992\/zP6X2qUd_normal.jpeg",
      "id" : 19362341,
      "verified" : true
    }
  },
  "id" : 663900759260585984,
  "created_at" : "2015-11-10 02:07:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/520725167266611200\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Ao8CPHgKTh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzn8x5mIMAA-cqa.jpg",
      "id_str" : "520725166142533632",
      "id" : 520725166142533632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzn8x5mIMAA-cqa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ao8CPHgKTh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/mwNF4GKOjY",
      "expanded_url" : "http:\/\/goo.gl\/qBM6gu",
      "display_url" : "goo.gl\/qBM6gu"
    } ]
  },
  "geo" : { },
  "id_str" : "663900416904732672",
  "text" : "RT @BestGamezUp: Weirdest video game controllers ever conceived https:\/\/t.co\/mwNF4GKOjY https:\/\/t.co\/Ao8CPHgKTh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/520725167266611200\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Ao8CPHgKTh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzn8x5mIMAA-cqa.jpg",
        "id_str" : "520725166142533632",
        "id" : 520725166142533632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzn8x5mIMAA-cqa.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ao8CPHgKTh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/mwNF4GKOjY",
        "expanded_url" : "http:\/\/goo.gl\/qBM6gu",
        "display_url" : "goo.gl\/qBM6gu"
      } ]
    },
    "geo" : { },
    "id_str" : "663895380833214464",
    "text" : "Weirdest video game controllers ever conceived https:\/\/t.co\/mwNF4GKOjY https:\/\/t.co\/Ao8CPHgKTh",
    "id" : 663895380833214464,
    "created_at" : "2015-11-10 01:46:08 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 663900416904732672,
  "created_at" : "2015-11-10 02:06:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "dailymotion",
      "screen_name" : "dailymotion",
      "indices" : [ 32, 44 ],
      "id_str" : "90415370",
      "id" : 90415370
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/663900156849356801\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bSG1WwmNLr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTalqr2W4AAVxe3.jpg",
      "id_str" : "663900147827531776",
      "id" : 663900147827531776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTalqr2W4AAVxe3.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bSG1WwmNLr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663900156849356801",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148: Someone hacked my @dailymotion account, than deleted it. What a day!! https:\/\/t.co\/bSG1WwmNLr",
  "id" : 663900156849356801,
  "created_at" : "2015-11-10 02:05:06 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 3, 11 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YouTube\/status\/662781525205864448\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/btoPH7a1AU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTKsSPLXIAApf_L.png",
      "id_str" : "662781524488691712",
      "id" : 662781524488691712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTKsSPLXIAApf_L.png",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/btoPH7a1AU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Oa2TpWrEmb",
      "expanded_url" : "https:\/\/goo.gl\/BvaJNR",
      "display_url" : "goo.gl\/BvaJNR"
    } ]
  },
  "geo" : { },
  "id_str" : "663899919829323776",
  "text" : "RT @YouTube: This little guy\u2019s about to go HAM-ster on some carrots! https:\/\/t.co\/Oa2TpWrEmb https:\/\/t.co\/btoPH7a1AU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YouTube\/status\/662781525205864448\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/btoPH7a1AU",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTKsSPLXIAApf_L.png",
        "id_str" : "662781524488691712",
        "id" : 662781524488691712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTKsSPLXIAApf_L.png",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/btoPH7a1AU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Oa2TpWrEmb",
        "expanded_url" : "https:\/\/goo.gl\/BvaJNR",
        "display_url" : "goo.gl\/BvaJNR"
      } ]
    },
    "geo" : { },
    "id_str" : "662781525205864448",
    "text" : "This little guy\u2019s about to go HAM-ster on some carrots! https:\/\/t.co\/Oa2TpWrEmb https:\/\/t.co\/btoPH7a1AU",
    "id" : 662781525205864448,
    "created_at" : "2015-11-07 00:00:04 +0000",
    "user" : {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "protected" : false,
      "id_str" : "10228272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864134875623772160\/zASGBEvr_normal.jpg",
      "id" : 10228272,
      "verified" : true
    }
  },
  "id" : 663899919829323776,
  "created_at" : "2015-11-10 02:04:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James",
      "screen_name" : "jimmydan33",
      "indices" : [ 3, 14 ],
      "id_str" : "1662577722",
      "id" : 1662577722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663899337760616448",
  "text" : "RT @jimmydan33: Horrible ref decisions so far",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663015225952706560",
    "text" : "Horrible ref decisions so far",
    "id" : 663015225952706560,
    "created_at" : "2015-11-07 15:28:42 +0000",
    "user" : {
      "name" : "James",
      "screen_name" : "jimmydan33",
      "protected" : false,
      "id_str" : "1662577722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853608699205738496\/zgjgQGSC_normal.jpg",
      "id" : 1662577722,
      "verified" : false
    }
  },
  "id" : 663899337760616448,
  "created_at" : "2015-11-10 02:01:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "indices" : [ 3, 14 ],
      "id_str" : "1613720983",
      "id" : 1613720983
    }, {
      "name" : "Willow Bend Mortgage",
      "screen_name" : "wbmtx",
      "indices" : [ 83, 89 ],
      "id_str" : "1000634160",
      "id" : 1000634160
    }, {
      "name" : "Comergence",
      "screen_name" : "Comergence",
      "indices" : [ 90, 101 ],
      "id_str" : "863746482",
      "id" : 863746482
    }, {
      "name" : "Deborah Lamb-Naples",
      "screen_name" : "debllamb",
      "indices" : [ 102, 111 ],
      "id_str" : "1488585199",
      "id" : 1488585199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/uWvjDQgPca",
      "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=248483d0-84a6-11e5-852b-0cc47a0d15fd",
      "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663898951452663808",
  "text" : "RT @SpokeIdeas: Daily Real Estate Gems is out! https:\/\/t.co\/uWvjDQgPca Stories via @wbmtx @Comergence @debllamb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Willow Bend Mortgage",
        "screen_name" : "wbmtx",
        "indices" : [ 67, 73 ],
        "id_str" : "1000634160",
        "id" : 1000634160
      }, {
        "name" : "Comergence",
        "screen_name" : "Comergence",
        "indices" : [ 74, 85 ],
        "id_str" : "863746482",
        "id" : 863746482
      }, {
        "name" : "Deborah Lamb-Naples",
        "screen_name" : "debllamb",
        "indices" : [ 86, 95 ],
        "id_str" : "1488585199",
        "id" : 1488585199
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/uWvjDQgPca",
        "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=248483d0-84a6-11e5-852b-0cc47a0d15fd",
        "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "662672809282437120",
    "text" : "Daily Real Estate Gems is out! https:\/\/t.co\/uWvjDQgPca Stories via @wbmtx @Comergence @debllamb",
    "id" : 662672809282437120,
    "created_at" : "2015-11-06 16:48:04 +0000",
    "user" : {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "protected" : false,
      "id_str" : "1613720983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172643076\/f04a76d7a8e1ceeba77ecf1d3964c1d4_normal.jpeg",
      "id" : 1613720983,
      "verified" : false
    }
  },
  "id" : 663898951452663808,
  "created_at" : "2015-11-10 02:00:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "indices" : [ 3, 14 ],
      "id_str" : "1613720983",
      "id" : 1613720983
    }, {
      "name" : "Inlanta Mortgage",
      "screen_name" : "MadisonMortgage",
      "indices" : [ 83, 99 ],
      "id_str" : "29127216",
      "id" : 29127216
    }, {
      "name" : "Benchmark Colorado",
      "screen_name" : "BenchmarkCO",
      "indices" : [ 100, 112 ],
      "id_str" : "235671493",
      "id" : 235671493
    }, {
      "name" : "Jonathan Miller",
      "screen_name" : "jonathanmiller",
      "indices" : [ 113, 128 ],
      "id_str" : "9579652",
      "id" : 9579652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/AnTR2hAns9",
      "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=ad076c10-8701-11e5-852b-0cc47a0d15fd",
      "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663898920859377664",
  "text" : "RT @SpokeIdeas: Daily Real Estate Gems is out! https:\/\/t.co\/AnTR2hAns9 Stories via @MadisonMortgage @BenchmarkCO @jonathanmiller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inlanta Mortgage",
        "screen_name" : "MadisonMortgage",
        "indices" : [ 67, 83 ],
        "id_str" : "29127216",
        "id" : 29127216
      }, {
        "name" : "Benchmark Colorado",
        "screen_name" : "BenchmarkCO",
        "indices" : [ 84, 96 ],
        "id_str" : "235671493",
        "id" : 235671493
      }, {
        "name" : "Jonathan Miller",
        "screen_name" : "jonathanmiller",
        "indices" : [ 97, 112 ],
        "id_str" : "9579652",
        "id" : 9579652
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/AnTR2hAns9",
        "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=ad076c10-8701-11e5-852b-0cc47a0d15fd",
        "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663760040466243584",
    "text" : "Daily Real Estate Gems is out! https:\/\/t.co\/AnTR2hAns9 Stories via @MadisonMortgage @BenchmarkCO @jonathanmiller",
    "id" : 663760040466243584,
    "created_at" : "2015-11-09 16:48:20 +0000",
    "user" : {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "protected" : false,
      "id_str" : "1613720983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172643076\/f04a76d7a8e1ceeba77ecf1d3964c1d4_normal.jpeg",
      "id" : 1613720983,
      "verified" : false
    }
  },
  "id" : 663898920859377664,
  "created_at" : "2015-11-10 02:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/663898841805168640\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/mUQyhrLAB4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTakeXSUsAEAzdD.jpg",
      "id_str" : "663898836637626369",
      "id" : 663898836637626369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTakeXSUsAEAzdD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/mUQyhrLAB4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663898841805168640",
  "text" : "This is my angry face \uD83D\uDE24 https:\/\/t.co\/mUQyhrLAB4",
  "id" : 663898841805168640,
  "created_at" : "2015-11-10 01:59:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "indices" : [ 3, 14 ],
      "id_str" : "1613720983",
      "id" : 1613720983
    }, {
      "name" : "Michael R Diaz Sr.",
      "screen_name" : "RELoanDr",
      "indices" : [ 83, 92 ],
      "id_str" : "390510609",
      "id" : 390510609
    }, {
      "name" : "David Rosenfeld",
      "screen_name" : "WeAreRealEstate",
      "indices" : [ 93, 109 ],
      "id_str" : "202726343",
      "id" : 202726343
    }, {
      "name" : "BHGRE Base Camp",
      "screen_name" : "BaseCampRVA",
      "indices" : [ 110, 122 ],
      "id_str" : "518762605",
      "id" : 518762605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/zM5hNp9mVp",
      "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=772a9c80-8638-11e5-852b-0cc47a0d15fd",
      "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663470908435120128",
  "text" : "RT @SpokeIdeas: Daily Real Estate Gems is out! https:\/\/t.co\/zM5hNp9mVp Stories via @RELoanDr @WeAreRealEstate @BaseCampRVA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael R Diaz Sr.",
        "screen_name" : "RELoanDr",
        "indices" : [ 67, 76 ],
        "id_str" : "390510609",
        "id" : 390510609
      }, {
        "name" : "David Rosenfeld",
        "screen_name" : "WeAreRealEstate",
        "indices" : [ 77, 93 ],
        "id_str" : "202726343",
        "id" : 202726343
      }, {
        "name" : "BHGRE Base Camp",
        "screen_name" : "BaseCampRVA",
        "indices" : [ 94, 106 ],
        "id_str" : "518762605",
        "id" : 518762605
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/zM5hNp9mVp",
        "expanded_url" : "http:\/\/paper.li\/SpokeIdeas\/1374598051?edition_id=772a9c80-8638-11e5-852b-0cc47a0d15fd",
        "display_url" : "paper.li\/SpokeIdeas\/137\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "663397574125207552",
    "text" : "Daily Real Estate Gems is out! https:\/\/t.co\/zM5hNp9mVp Stories via @RELoanDr @WeAreRealEstate @BaseCampRVA",
    "id" : 663397574125207552,
    "created_at" : "2015-11-08 16:48:01 +0000",
    "user" : {
      "name" : "Spoke Ideas",
      "screen_name" : "SpokeIdeas",
      "protected" : false,
      "id_str" : "1613720983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172643076\/f04a76d7a8e1ceeba77ecf1d3964c1d4_normal.jpeg",
      "id" : 1613720983,
      "verified" : false
    }
  },
  "id" : 663470908435120128,
  "created_at" : "2015-11-08 21:39:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PayPal",
      "screen_name" : "PayPal",
      "indices" : [ 0, 7 ],
      "id_str" : "30018058",
      "id" : 30018058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663470610538827776",
  "in_reply_to_user_id" : 30018058,
  "text" : "@PayPal and the world record front runner for totally not annoying costumer service is...\uD83D\uDE24",
  "id" : 663470610538827776,
  "created_at" : "2015-11-08 21:38:14 +0000",
  "in_reply_to_screen_name" : "PayPal",
  "in_reply_to_user_id_str" : "30018058",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/663470384214245376\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/OTSkiEnjDQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTUeyxhUEAQDOJZ.jpg",
      "id_str" : "663470377742372868",
      "id" : 663470377742372868,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTUeyxhUEAQDOJZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OTSkiEnjDQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663470384214245376",
  "text" : "Kinda a bad photo, but who cares, selfies are dumb anyways https:\/\/t.co\/OTSkiEnjDQ",
  "id" : 663470384214245376,
  "created_at" : "2015-11-08 21:37:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/663423823954452480\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/GPTRbv7gON",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTT0cwGWUAAuiGJ.jpg",
      "id_str" : "663423819915350016",
      "id" : 663423819915350016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTT0cwGWUAAuiGJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GPTRbv7gON"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663423823954452480",
  "text" : "Mexican Squirt @ Eat Well Cafe https:\/\/t.co\/GPTRbv7gON",
  "id" : 663423823954452480,
  "created_at" : "2015-11-08 18:32:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fact",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663034006636744704",
  "text" : "Adam Smith felt under-challenged by education standards of the 18th century #Fact",
  "id" : 663034006636744704,
  "created_at" : "2015-11-07 16:43:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greensboro, NC",
      "screen_name" : "greensboro_nc",
      "indices" : [ 0, 14 ],
      "id_str" : "28918980",
      "id" : 28918980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Linkedin",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662494160293793792",
  "geo" : { },
  "id_str" : "663032431931445249",
  "in_reply_to_user_id" : 28918980,
  "text" : "@greensboro_nc I wonder how #Linkedin will do in Q4",
  "id" : 663032431931445249,
  "in_reply_to_status_id" : 662494160293793792,
  "created_at" : "2015-11-07 16:37:04 +0000",
  "in_reply_to_screen_name" : "greensboro_nc",
  "in_reply_to_user_id_str" : "28918980",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Javier Garde",
      "screen_name" : "jose_garde",
      "indices" : [ 3, 14 ],
      "id_str" : "2284237477",
      "id" : 2284237477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LinkedIn",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oRQkxC0TlR",
      "expanded_url" : "http:\/\/klou.tt\/4aodcef9y9h3",
      "display_url" : "klou.tt\/4aodcef9y9h3"
    } ]
  },
  "geo" : { },
  "id_str" : "663032136434216960",
  "text" : "RT @jose_garde: #LinkedIn Stock Near Breakout After Q3 Earnings Beat - https:\/\/t.co\/oRQkxC0TlR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LinkedIn",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/oRQkxC0TlR",
        "expanded_url" : "http:\/\/klou.tt\/4aodcef9y9h3",
        "display_url" : "klou.tt\/4aodcef9y9h3"
      } ]
    },
    "geo" : { },
    "id_str" : "662715122087956480",
    "text" : "#LinkedIn Stock Near Breakout After Q3 Earnings Beat - https:\/\/t.co\/oRQkxC0TlR",
    "id" : 662715122087956480,
    "created_at" : "2015-11-06 19:36:12 +0000",
    "user" : {
      "name" : "Jose Javier Garde",
      "screen_name" : "jose_garde",
      "protected" : false,
      "id_str" : "2284237477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471395209494802432\/vecB6zE2_normal.png",
      "id" : 2284237477,
      "verified" : false
    }
  },
  "id" : 663032136434216960,
  "created_at" : "2015-11-07 16:35:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Investors.com",
      "screen_name" : "IBDinvestors",
      "indices" : [ 0, 13 ],
      "id_str" : "21328656",
      "id" : 21328656
    }, {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 52, 61 ],
      "id_str" : "352053266",
      "id" : 352053266
    }, {
      "name" : "edX",
      "screen_name" : "edXOnline",
      "indices" : [ 63, 73 ],
      "id_str" : "567360618",
      "id" : 567360618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662828086250090496",
  "geo" : { },
  "id_str" : "663032077680414720",
  "in_reply_to_user_id" : 21328656,
  "text" : "@IBDinvestors I am still a Mentors4EDU, Amazon, and @coursera  @edXOnline  fan",
  "id" : 663032077680414720,
  "in_reply_to_status_id" : 662828086250090496,
  "created_at" : "2015-11-07 16:35:40 +0000",
  "in_reply_to_screen_name" : "IBDinvestors",
  "in_reply_to_user_id_str" : "21328656",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Investors.com",
      "screen_name" : "IBDinvestors",
      "indices" : [ 3, 16 ],
      "id_str" : "21328656",
      "id" : 21328656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/FXjxyZKEtS",
      "expanded_url" : "http:\/\/Lynda.com",
      "display_url" : "Lynda.com"
    } ]
  },
  "geo" : { },
  "id_str" : "663031878597775360",
  "text" : "RT @IBDinvestors: Weekend Watch List: LinkedIn's purchase of https:\/\/t.co\/FXjxyZKEtS could be an unexpectedly strong growth catalyst. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/FXjxyZKEtS",
        "expanded_url" : "http:\/\/Lynda.com",
        "display_url" : "Lynda.com"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4pP0jjCTwE",
        "expanded_url" : "http:\/\/ow.ly\/Um15X",
        "display_url" : "ow.ly\/Um15X"
      } ]
    },
    "geo" : { },
    "id_str" : "662828086250090496",
    "text" : "Weekend Watch List: LinkedIn's purchase of https:\/\/t.co\/FXjxyZKEtS could be an unexpectedly strong growth catalyst. https:\/\/t.co\/4pP0jjCTwE",
    "id" : 662828086250090496,
    "created_at" : "2015-11-07 03:05:05 +0000",
    "user" : {
      "name" : "Investors.com",
      "screen_name" : "IBDinvestors",
      "protected" : false,
      "id_str" : "21328656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737670199093006336\/KP_YlYFP_normal.jpg",
      "id" : 21328656,
      "verified" : true
    }
  },
  "id" : 663031878597775360,
  "created_at" : "2015-11-07 16:34:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stock Trading Picks",
      "screen_name" : "stocknerd",
      "indices" : [ 0, 10 ],
      "id_str" : "47209382",
      "id" : 47209382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "6037867625",
  "geo" : { },
  "id_str" : "663031757189464065",
  "in_reply_to_user_id" : 47209382,
  "text" : "@stocknerd Ah the old days :(",
  "id" : 663031757189464065,
  "in_reply_to_status_id" : 6037867625,
  "created_at" : "2015-11-07 16:34:24 +0000",
  "in_reply_to_screen_name" : "stocknerd",
  "in_reply_to_user_id_str" : "47209382",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Welker",
      "screen_name" : "jasonwelker",
      "indices" : [ 0, 12 ],
      "id_str" : "8876122",
      "id" : 8876122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663031069365563392",
  "in_reply_to_user_id" : 8876122,
  "text" : "@jasonwelker Your Econ lectures remind me of things I shouldn't have forgotten. Keep them going!!!",
  "id" : 663031069365563392,
  "created_at" : "2015-11-07 16:31:40 +0000",
  "in_reply_to_screen_name" : "jasonwelker",
  "in_reply_to_user_id_str" : "8876122",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662822886420430849",
  "text" : "Just watched, \"Sword and the Crescent\" by Keith Thompson, quite an interesting documentary.",
  "id" : 662822886420430849,
  "created_at" : "2015-11-07 02:44:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuySell",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662751731382661120",
  "text" : "RT @HamzeiAnalytics: BUY Programs detected at NYSE #BuySell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuySell",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662703421934333952",
    "text" : "BUY Programs detected at NYSE #BuySell",
    "id" : 662703421934333952,
    "created_at" : "2015-11-06 18:49:42 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 662751731382661120,
  "created_at" : "2015-11-06 22:01:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/662750785592233984\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/9Vf4N3652S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTKQUd4WcAAAHMe.jpg",
      "id_str" : "662750776469647360",
      "id" : 662750776469647360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTKQUd4WcAAAHMe.jpg",
      "sizes" : [ {
        "h" : 618,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 618,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9Vf4N3652S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662750785592233984",
  "text" : "That moment when Windows restarts and you are working on something \uD83D\uDE21 https:\/\/t.co\/9Vf4N3652S",
  "id" : 662750785592233984,
  "created_at" : "2015-11-06 21:57:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/ItCVQg0DC5",
      "expanded_url" : "https:\/\/twitter.com\/tsbible\/status\/662702379188527104",
      "display_url" : "twitter.com\/tsbible\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662704686831652864",
  "text" : "What?  https:\/\/t.co\/ItCVQg0DC5",
  "id" : 662704686831652864,
  "created_at" : "2015-11-06 18:54:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/662704142868156420\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/lmyerTIlpI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJl4_mU8AAl4Nc.jpg",
      "id_str" : "662704124996153344",
      "id" : 662704124996153344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJl4_mU8AAl4Nc.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lmyerTIlpI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662704142868156420",
  "text" : "Panda Express said I need to hit the gym more for little belly Jr. I don't blame them. https:\/\/t.co\/lmyerTIlpI",
  "id" : 662704142868156420,
  "created_at" : "2015-11-06 18:52:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Laura Ingraham",
      "screen_name" : "IngrahamAngle",
      "indices" : [ 18, 32 ],
      "id_str" : "50769180",
      "id" : 50769180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662651345778950144",
  "text" : "RT @seanhannity: .@IngrahamAngle: \u201CMost Americans, Latino, black, white\u2014they want laws that work for the average American.\u201D #Hannity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Ingraham",
        "screen_name" : "IngrahamAngle",
        "indices" : [ 1, 15 ],
        "id_str" : "50769180",
        "id" : 50769180
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662472755175014400",
    "text" : ".@IngrahamAngle: \u201CMost Americans, Latino, black, white\u2014they want laws that work for the average American.\u201D #Hannity",
    "id" : 662472755175014400,
    "created_at" : "2015-11-06 03:33:07 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 662651345778950144,
  "created_at" : "2015-11-06 15:22:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662651202639962112",
  "text" : "RT @seanhannity: Question of the Day: What do you think happened to the Russian plane? Weigh in using #Hannity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662479285022683136",
    "text" : "Question of the Day: What do you think happened to the Russian plane? Weigh in using #Hannity.",
    "id" : 662479285022683136,
    "created_at" : "2015-11-06 03:59:04 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 662651202639962112,
  "created_at" : "2015-11-06 15:22:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple Music",
      "screen_name" : "AppleMusic",
      "indices" : [ 30, 41 ],
      "id_str" : "74580436",
      "id" : 74580436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/NUfdUmpwod",
      "expanded_url" : "https:\/\/twitter.com\/iphonehackx\/status\/662292079717048320",
      "display_url" : "twitter.com\/iphonehackx\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662651103625019392",
  "text" : "Will this one spy on you too? @AppleMusic https:\/\/t.co\/NUfdUmpwod",
  "id" : 662651103625019392,
  "created_at" : "2015-11-06 15:21:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uC544 \uBBF8",
      "screen_name" : "___aptx",
      "indices" : [ 0, 8 ],
      "id_str" : "853261140146528258",
      "id" : 853261140146528258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662478501338066945",
  "geo" : { },
  "id_str" : "662650813186236416",
  "in_reply_to_user_id" : 102408319,
  "text" : "@___aptx So what did they write about you? ;)",
  "id" : 662650813186236416,
  "in_reply_to_status_id" : 662478501338066945,
  "created_at" : "2015-11-06 15:20:39 +0000",
  "in_reply_to_screen_name" : "fermiparadox_",
  "in_reply_to_user_id_str" : "102408319",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uC544 \uBBF8",
      "screen_name" : "___aptx",
      "indices" : [ 0, 8 ],
      "id_str" : "853261140146528258",
      "id" : 853261140146528258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662478501338066945",
  "geo" : { },
  "id_str" : "662650650686263296",
  "in_reply_to_user_id" : 102408319,
  "text" : "@___aptx Okay",
  "id" : 662650650686263296,
  "in_reply_to_status_id" : 662478501338066945,
  "created_at" : "2015-11-06 15:20:01 +0000",
  "in_reply_to_screen_name" : "fermiparadox_",
  "in_reply_to_user_id_str" : "102408319",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 0, 12 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 13, 22 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662475785849016320",
  "geo" : { },
  "id_str" : "662475936533737472",
  "in_reply_to_user_id" : 41634520,
  "text" : "@seanhannity @RandPaul Still Cruz is my favorite though :)",
  "id" : 662475936533737472,
  "in_reply_to_status_id" : 662475785849016320,
  "created_at" : "2015-11-06 03:45:46 +0000",
  "in_reply_to_screen_name" : "seanhannity",
  "in_reply_to_user_id_str" : "41634520",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 35, 44 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662475851611684864",
  "text" : "RT @seanhannity: Next on #Hannity: @RandPaul joins me to discuss Iranians burning American Flags &amp; how he would deal with Iran if he were e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Rand Paul",
        "screen_name" : "RandPaul",
        "indices" : [ 18, 27 ],
        "id_str" : "216881337",
        "id" : 216881337
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662475785849016320",
    "text" : "Next on #Hannity: @RandPaul joins me to discuss Iranians burning American Flags &amp; how he would deal with Iran if he were elected president.",
    "id" : 662475785849016320,
    "created_at" : "2015-11-06 03:45:10 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 662475851611684864,
  "created_at" : "2015-11-06 03:45:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Ciao",
      "screen_name" : "beautybabyboo",
      "indices" : [ 0, 14 ],
      "id_str" : "161846587",
      "id" : 161846587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662474414429179904",
  "geo" : { },
  "id_str" : "662474636349857792",
  "in_reply_to_user_id" : 161846587,
  "text" : "@beautybabyboo Sometimes people write illogical fallacies on Twitter",
  "id" : 662474636349857792,
  "in_reply_to_status_id" : 662474414429179904,
  "created_at" : "2015-11-06 03:40:36 +0000",
  "in_reply_to_screen_name" : "beautybabyboo",
  "in_reply_to_user_id_str" : "161846587",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mavi \uD83D\uDCAB",
      "screen_name" : "Mavicdayrit",
      "indices" : [ 3, 15 ],
      "id_str" : "347561794",
      "id" : 347561794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662473875708620800",
  "text" : "RT @Mavicdayrit: Quality time. \uD83D\uDE02\uD83D\uDE02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661867448220585984",
    "text" : "Quality time. \uD83D\uDE02\uD83D\uDE02",
    "id" : 661867448220585984,
    "created_at" : "2015-11-04 11:27:51 +0000",
    "user" : {
      "name" : "Mavi \uD83D\uDCAB",
      "screen_name" : "Mavicdayrit",
      "protected" : true,
      "id_str" : "347561794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864683473885319168\/ZPZ5OBQ0_normal.jpg",
      "id" : 347561794,
      "verified" : false
    }
  },
  "id" : 662473875708620800,
  "created_at" : "2015-11-06 03:37:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mavi \uD83D\uDCAB",
      "screen_name" : "Mavicdayrit",
      "indices" : [ 3, 15 ],
      "id_str" : "347561794",
      "id" : 347561794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662473829328035844",
  "text" : "RT @Mavicdayrit: Can't even. \uD83D\uDE02 Haha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662129396950560768",
    "text" : "Can't even. \uD83D\uDE02 Haha",
    "id" : 662129396950560768,
    "created_at" : "2015-11-05 04:48:44 +0000",
    "user" : {
      "name" : "Mavi \uD83D\uDCAB",
      "screen_name" : "Mavicdayrit",
      "protected" : true,
      "id_str" : "347561794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864683473885319168\/ZPZ5OBQ0_normal.jpg",
      "id" : 347561794,
      "verified" : false
    }
  },
  "id" : 662473829328035844,
  "created_at" : "2015-11-06 03:37:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amiey Laureen x",
      "screen_name" : "amieylaureenx",
      "indices" : [ 3, 17 ],
      "id_str" : "156699768",
      "id" : 156699768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662472825266151424",
  "text" : "RT @amieylaureenx: Can twitter stop trying to be like facebook please",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661627562645434368",
    "text" : "Can twitter stop trying to be like facebook please",
    "id" : 661627562645434368,
    "created_at" : "2015-11-03 19:34:38 +0000",
    "user" : {
      "name" : "Amiey Laureen x",
      "screen_name" : "amieylaureenx",
      "protected" : false,
      "id_str" : "156699768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862307098226569219\/TpN9B8mr_normal.jpg",
      "id" : 156699768,
      "verified" : false
    }
  },
  "id" : 662472825266151424,
  "created_at" : "2015-11-06 03:33:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uC544 \uBBF8",
      "screen_name" : "___aptx",
      "indices" : [ 0, 8 ],
      "id_str" : "853261140146528258",
      "id" : 853261140146528258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662469994387755008",
  "geo" : { },
  "id_str" : "662471871712108544",
  "in_reply_to_user_id" : 102408319,
  "text" : "@___aptx What's a yak?",
  "id" : 662471871712108544,
  "in_reply_to_status_id" : 662469994387755008,
  "created_at" : "2015-11-06 03:29:37 +0000",
  "in_reply_to_screen_name" : "fermiparadox_",
  "in_reply_to_user_id_str" : "102408319",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/KzptNCwIAS",
      "expanded_url" : "http:\/\/fb.me\/447aYKbIe",
      "display_url" : "fb.me\/447aYKbIe"
    } ]
  },
  "geo" : { },
  "id_str" : "662471732792598528",
  "text" : "RT @EmperorDarroux: New Horizons is now on track to explore the outer solar system https:\/\/t.co\/KzptNCwIAS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/KzptNCwIAS",
        "expanded_url" : "http:\/\/fb.me\/447aYKbIe",
        "display_url" : "fb.me\/447aYKbIe"
      } ]
    },
    "geo" : { },
    "id_str" : "662470048313946112",
    "text" : "New Horizons is now on track to explore the outer solar system https:\/\/t.co\/KzptNCwIAS",
    "id" : 662470048313946112,
    "created_at" : "2015-11-06 03:22:22 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 662471732792598528,
  "created_at" : "2015-11-06 03:29:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RinconVP",
      "screen_name" : "RinconVP",
      "indices" : [ 0, 9 ],
      "id_str" : "227822148",
      "id" : 227822148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "662023022941990912",
  "geo" : { },
  "id_str" : "662471304294068224",
  "in_reply_to_user_id" : 227822148,
  "text" : "@RinconVP How early, wait, no, why? \uD83D\uDE33",
  "id" : 662471304294068224,
  "in_reply_to_status_id" : 662023022941990912,
  "created_at" : "2015-11-06 03:27:21 +0000",
  "in_reply_to_screen_name" : "RinconVP",
  "in_reply_to_user_id_str" : "227822148",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RinconVP",
      "screen_name" : "RinconVP",
      "indices" : [ 3, 12 ],
      "id_str" : "227822148",
      "id" : 227822148
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RinconVP\/status\/662023022941990912\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/cskVNaGFbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_6boMXIAEc7vK.jpg",
      "id_str" : "662023022799429633",
      "id" : 662023022799429633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_6boMXIAEc7vK.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 822
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 822
      } ],
      "display_url" : "pic.twitter.com\/cskVNaGFbP"
    } ],
    "hashtags" : [ {
      "text" : "startup",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ZmLSha5FjM",
      "expanded_url" : "http:\/\/vytm.in\/kYUJcA",
      "display_url" : "vytm.in\/kYUJcA"
    } ]
  },
  "geo" : { },
  "id_str" : "662471146676310016",
  "text" : "RT @RinconVP: 10 Entrepreneurship Realities You'd Better Learn Early https:\/\/t.co\/ZmLSha5FjM #startup https:\/\/t.co\/cskVNaGFbP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vytmn.com\/\" rel=\"nofollow\"\u003EVytmn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RinconVP\/status\/662023022941990912\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/cskVNaGFbP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_6boMXIAEc7vK.jpg",
        "id_str" : "662023022799429633",
        "id" : 662023022799429633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_6boMXIAEc7vK.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 822
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 822
        } ],
        "display_url" : "pic.twitter.com\/cskVNaGFbP"
      } ],
      "hashtags" : [ {
        "text" : "startup",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/ZmLSha5FjM",
        "expanded_url" : "http:\/\/vytm.in\/kYUJcA",
        "display_url" : "vytm.in\/kYUJcA"
      } ]
    },
    "geo" : { },
    "id_str" : "662023022941990912",
    "text" : "10 Entrepreneurship Realities You'd Better Learn Early https:\/\/t.co\/ZmLSha5FjM #startup https:\/\/t.co\/cskVNaGFbP",
    "id" : 662023022941990912,
    "created_at" : "2015-11-04 21:46:03 +0000",
    "user" : {
      "name" : "RinconVP",
      "screen_name" : "RinconVP",
      "protected" : false,
      "id_str" : "227822148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585915305223823360\/3L1CyazD_normal.png",
      "id" : 227822148,
      "verified" : false
    }
  },
  "id" : 662471146676310016,
  "created_at" : "2015-11-06 03:26:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RinconVP",
      "screen_name" : "RinconVP",
      "indices" : [ 3, 12 ],
      "id_str" : "227822148",
      "id" : 227822148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saas",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/kRqSXXhLVi",
      "expanded_url" : "http:\/\/vytm.in\/ajFYDQ",
      "display_url" : "vytm.in\/ajFYDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "662471123318214656",
  "text" : "RT @RinconVP: How does an entrepreneur in residence measure their success? https:\/\/t.co\/kRqSXXhLVi #saas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vytmn.com\/\" rel=\"nofollow\"\u003EVytmn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "saas",
        "indices" : [ 85, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/kRqSXXhLVi",
        "expanded_url" : "http:\/\/vytm.in\/ajFYDQ",
        "display_url" : "vytm.in\/ajFYDQ"
      } ]
    },
    "geo" : { },
    "id_str" : "662175475888988160",
    "text" : "How does an entrepreneur in residence measure their success? https:\/\/t.co\/kRqSXXhLVi #saas",
    "id" : 662175475888988160,
    "created_at" : "2015-11-05 07:51:50 +0000",
    "user" : {
      "name" : "RinconVP",
      "screen_name" : "RinconVP",
      "protected" : false,
      "id_str" : "227822148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585915305223823360\/3L1CyazD_normal.png",
      "id" : 227822148,
      "verified" : false
    }
  },
  "id" : 662471123318214656,
  "created_at" : "2015-11-06 03:26:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael D Angelo",
      "screen_name" : "MichaelDAngelo8",
      "indices" : [ 3, 19 ],
      "id_str" : "523012933",
      "id" : 523012933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/7oc0djZvob",
      "expanded_url" : "http:\/\/bit.ly\/1SsGI0c",
      "display_url" : "bit.ly\/1SsGI0c"
    } ]
  },
  "geo" : { },
  "id_str" : "662470926722867200",
  "text" : "RT @MichaelDAngelo8: New California Law: Pregnancy Centers Must Tell Moms About Abortion https:\/\/t.co\/7oc0djZvob What if signs 'blowdown'du\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/7oc0djZvob",
        "expanded_url" : "http:\/\/bit.ly\/1SsGI0c",
        "display_url" : "bit.ly\/1SsGI0c"
      } ]
    },
    "geo" : { },
    "id_str" : "662411910755672064",
    "text" : "New California Law: Pregnancy Centers Must Tell Moms About Abortion https:\/\/t.co\/7oc0djZvob What if signs 'blowdown'during bus hours?",
    "id" : 662411910755672064,
    "created_at" : "2015-11-05 23:31:21 +0000",
    "user" : {
      "name" : "Michael D Angelo",
      "screen_name" : "MichaelDAngelo8",
      "protected" : false,
      "id_str" : "523012933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1893536014\/womans-sexy-and-weird-body-tattoo_normal.jpg",
      "id" : 523012933,
      "verified" : false
    }
  },
  "id" : 662470926722867200,
  "created_at" : "2015-11-06 03:25:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Disvet",
      "screen_name" : "watersurf58",
      "indices" : [ 3, 15 ],
      "id_str" : "154236193",
      "id" : 154236193
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/watersurf58\/status\/662455169351729152\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/kPClPedrOe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGDdmCUkAIsQnN.jpg",
      "id_str" : "662455164649902082",
      "id" : 662455164649902082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGDdmCUkAIsQnN.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/kPClPedrOe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662470361062236160",
  "text" : "RT @watersurf58: Gun control kills https:\/\/t.co\/kPClPedrOe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/watersurf58\/status\/662455169351729152\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/kPClPedrOe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGDdmCUkAIsQnN.jpg",
        "id_str" : "662455164649902082",
        "id" : 662455164649902082,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGDdmCUkAIsQnN.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/kPClPedrOe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662455169351729152",
    "text" : "Gun control kills https:\/\/t.co\/kPClPedrOe",
    "id" : 662455169351729152,
    "created_at" : "2015-11-06 02:23:14 +0000",
    "user" : {
      "name" : "American Disvet",
      "screen_name" : "watersurf58",
      "protected" : false,
      "id_str" : "154236193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841669811474178054\/rNqlAXNt_normal.jpg",
      "id" : 154236193,
      "verified" : false
    }
  },
  "id" : 662470361062236160,
  "created_at" : "2015-11-06 03:23:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris  \uD83C\uDDFA\uD83C\uDDF8 #MAGA",
      "screen_name" : "Chris_1791",
      "indices" : [ 3, 14 ],
      "id_str" : "312149882",
      "id" : 312149882
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chris_1791\/status\/662465032882663424\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/YDvhAcdtO5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGMb7VU8AAIY9j.png",
      "id_str" : "662465031611674624",
      "id" : 662465031611674624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGMb7VU8AAIY9j.png",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 655
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 655
      } ],
      "display_url" : "pic.twitter.com\/YDvhAcdtO5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/6Nrjpo6Mev",
      "expanded_url" : "http:\/\/dld.bz\/d6E47",
      "display_url" : "dld.bz\/d6E47"
    } ]
  },
  "geo" : { },
  "id_str" : "662470182460370944",
  "text" : "RT @Chris_1791: Unborn Babies Feel Anger and Joy, Psychotherapist's Study Says https:\/\/t.co\/6Nrjpo6Mev https:\/\/t.co\/YDvhAcdtO5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chris_1791\/status\/662465032882663424\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/YDvhAcdtO5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGMb7VU8AAIY9j.png",
        "id_str" : "662465031611674624",
        "id" : 662465031611674624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGMb7VU8AAIY9j.png",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 655
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 655
        } ],
        "display_url" : "pic.twitter.com\/YDvhAcdtO5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/6Nrjpo6Mev",
        "expanded_url" : "http:\/\/dld.bz\/d6E47",
        "display_url" : "dld.bz\/d6E47"
      } ]
    },
    "geo" : { },
    "id_str" : "662465032882663424",
    "text" : "Unborn Babies Feel Anger and Joy, Psychotherapist's Study Says https:\/\/t.co\/6Nrjpo6Mev https:\/\/t.co\/YDvhAcdtO5",
    "id" : 662465032882663424,
    "created_at" : "2015-11-06 03:02:26 +0000",
    "user" : {
      "name" : "Chris  \uD83C\uDDFA\uD83C\uDDF8 #MAGA",
      "screen_name" : "Chris_1791",
      "protected" : false,
      "id_str" : "312149882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855170297770758145\/0SrDPYyg_normal.jpg",
      "id" : 312149882,
      "verified" : false
    }
  },
  "id" : 662470182460370944,
  "created_at" : "2015-11-06 03:22:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OT",
      "indices" : [ 125, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662469666984562688",
  "text" : "Enoch and Elijah may be the two witnesses, these man were fairly profound in theological deontology and metaphysical wisdom- #OT",
  "id" : 662469666984562688,
  "created_at" : "2015-11-06 03:20:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/662451415638540288\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/fdh50Vzuww",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGADV_WwAADol1.jpg",
      "id_str" : "662451415131013120",
      "id" : 662451415131013120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGADV_WwAADol1.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fdh50Vzuww"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/5rYUtyljyj",
      "expanded_url" : "http:\/\/engt.co\/1kc8DX8",
      "display_url" : "engt.co\/1kc8DX8"
    } ]
  },
  "geo" : { },
  "id_str" : "662451470625873920",
  "text" : "RT @engadget: Google engineer takes on subpar USB Type-C cables https:\/\/t.co\/5rYUtyljyj https:\/\/t.co\/fdh50Vzuww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/662451415638540288\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/fdh50Vzuww",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTGADV_WwAADol1.jpg",
        "id_str" : "662451415131013120",
        "id" : 662451415131013120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTGADV_WwAADol1.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/fdh50Vzuww"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/5rYUtyljyj",
        "expanded_url" : "http:\/\/engt.co\/1kc8DX8",
        "display_url" : "engt.co\/1kc8DX8"
      } ]
    },
    "geo" : { },
    "id_str" : "662451415638540288",
    "text" : "Google engineer takes on subpar USB Type-C cables https:\/\/t.co\/5rYUtyljyj https:\/\/t.co\/fdh50Vzuww",
    "id" : 662451415638540288,
    "created_at" : "2015-11-06 02:08:19 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 662451470625873920,
  "created_at" : "2015-11-06 02:08:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZIG by Cezign",
      "screen_name" : "ZIGbyCezign",
      "indices" : [ 3, 15 ],
      "id_str" : "1531820226",
      "id" : 1531820226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "modern",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "house",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662451193965387776",
  "text" : "RT @ZIGbyCezign: A #modern floating #house you can customize to your liking that produces 80% of its energy for the year: https:\/\/t.co\/esPG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Design Milk",
        "screen_name" : "designmilk",
        "indices" : [ 129, 140 ],
        "id_str" : "15446126",
        "id" : 15446126
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "modern",
        "indices" : [ 2, 9 ]
      }, {
        "text" : "house",
        "indices" : [ 19, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/esPGGCzGab",
        "expanded_url" : "http:\/\/bit.ly\/1MeTOK7",
        "display_url" : "bit.ly\/1MeTOK7"
      } ]
    },
    "geo" : { },
    "id_str" : "662346229280595968",
    "text" : "A #modern floating #house you can customize to your liking that produces 80% of its energy for the year: https:\/\/t.co\/esPGGCzGab @DesignMilk",
    "id" : 662346229280595968,
    "created_at" : "2015-11-05 19:10:21 +0000",
    "user" : {
      "name" : "ZIG by Cezign",
      "screen_name" : "ZIGbyCezign",
      "protected" : false,
      "id_str" : "1531820226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000017261023\/db24043b0ea4b1d672c89e59154345a3_normal.jpeg",
      "id" : 1531820226,
      "verified" : false
    }
  },
  "id" : 662451193965387776,
  "created_at" : "2015-11-06 02:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NigelNicholson",
      "screen_name" : "NigelANicholson",
      "indices" : [ 3, 19 ],
      "id_str" : "357793620",
      "id" : 357793620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450978793398272",
  "text" : "RT @NigelANicholson: Old ways don't open new doors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662353339112402948",
    "text" : "Old ways don't open new doors.",
    "id" : 662353339112402948,
    "created_at" : "2015-11-05 19:38:36 +0000",
    "user" : {
      "name" : "NigelNicholson",
      "screen_name" : "NigelANicholson",
      "protected" : false,
      "id_str" : "357793620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862024334247944195\/VvpDXWHU_normal.jpg",
      "id" : 357793620,
      "verified" : false
    }
  },
  "id" : 662450978793398272,
  "created_at" : "2015-11-06 02:06:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 3, 13 ],
      "id_str" : "255245279",
      "id" : 255245279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBTTweet",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450922602283008",
  "text" : "RT @AlanFelyk: History repeats itself. That\u2019s cause the men weren\u2019t listening the first time. #TBTTweet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBTTweet",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662352944818466816",
    "text" : "History repeats itself. That\u2019s cause the men weren\u2019t listening the first time. #TBTTweet",
    "id" : 662352944818466816,
    "created_at" : "2015-11-05 19:37:02 +0000",
    "user" : {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "protected" : false,
      "id_str" : "255245279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3582417692\/d853116c99eb19f7e35d76c03540d0f7_normal.jpeg",
      "id" : 255245279,
      "verified" : false
    }
  },
  "id" : 662450922602283008,
  "created_at" : "2015-11-06 02:06:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450739663499264",
  "text" : "RT @God_Instagram: I asked God for strength, and God gave me difficulties to make me strong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662420829615992832",
    "text" : "I asked God for strength, and God gave me difficulties to make me strong.",
    "id" : 662420829615992832,
    "created_at" : "2015-11-06 00:06:47 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 662450739663499264,
  "created_at" : "2015-11-06 02:05:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450716116676608",
  "text" : "RT @God_Instagram: No one is truly alone, cause God is always walking by your side.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662435880913625089",
    "text" : "No one is truly alone, cause God is always walking by your side.",
    "id" : 662435880913625089,
    "created_at" : "2015-11-06 01:06:36 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 662450716116676608,
  "created_at" : "2015-11-06 02:05:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450705475764224",
  "text" : "RT @God_Instagram: Daily reminder that God has a plan for you \u263A\uFE0F even if you don't see it yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662428018493620224",
    "text" : "Daily reminder that God has a plan for you \u263A\uFE0F even if you don't see it yet.",
    "id" : 662428018493620224,
    "created_at" : "2015-11-06 00:35:21 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 662450705475764224,
  "created_at" : "2015-11-06 02:05:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450671413813248",
  "text" : "RT @God_Instagram: Never be afraid to trust an unknown future to a known God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662443150812672001",
    "text" : "Never be afraid to trust an unknown future to a known God.",
    "id" : 662443150812672001,
    "created_at" : "2015-11-06 01:35:29 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 662450671413813248,
  "created_at" : "2015-11-06 02:05:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Scott McQuate",
      "screen_name" : "DrScottMcQuate",
      "indices" : [ 0, 15 ],
      "id_str" : "238257726",
      "id" : 238257726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662450573854318592",
  "in_reply_to_user_id" : 238257726,
  "text" : "@DrScottMcQuate Where did you get your PhD again, so all your audience can know you are legit? Who is it accredited by? Just askin'",
  "id" : 662450573854318592,
  "created_at" : "2015-11-06 02:04:59 +0000",
  "in_reply_to_screen_name" : "DrScottMcQuate",
  "in_reply_to_user_id_str" : "238257726",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Scott McQuate",
      "screen_name" : "DrScottMcQuate",
      "indices" : [ 23, 38 ],
      "id_str" : "238257726",
      "id" : 238257726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/Qy0c4yLQxA",
      "expanded_url" : "https:\/\/goo.gl\/yH8Dbz",
      "display_url" : "goo.gl\/yH8Dbz"
    } ]
  },
  "geo" : { },
  "id_str" : "662448243478036480",
  "text" : "Great article exposing @DrScottMcQuate https:\/\/t.co\/Qy0c4yLQxA",
  "id" : 662448243478036480,
  "created_at" : "2015-11-06 01:55:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662316655171735552",
  "text" : "Out with mom. Having the Cowboy Burger and Onion Rings @ Ram's horns",
  "id" : 662316655171735552,
  "created_at" : "2015-11-05 17:12:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661639110252187648",
  "text" : "RT @God_Instagram: What God knows about me is more important than what others think about me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661635520192114688",
    "text" : "What God knows about me is more important than what others think about me.",
    "id" : 661635520192114688,
    "created_at" : "2015-11-03 20:06:15 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 661639110252187648,
  "created_at" : "2015-11-03 20:20:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661638970665734144",
  "text" : "RT @martincallan: Guy wins GB's second World Cup gold: James Guy wins his second gold as Great Britain claim six more medals on ... https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/OZcfjJYL4W",
        "expanded_url" : "http:\/\/bbc.in\/1RPm35u",
        "display_url" : "bbc.in\/1RPm35u"
      } ]
    },
    "geo" : { },
    "id_str" : "661636214135492608",
    "text" : "Guy wins GB's second World Cup gold: James Guy wins his second gold as Great Britain claim six more medals on ... https:\/\/t.co\/OZcfjJYL4W",
    "id" : 661636214135492608,
    "created_at" : "2015-11-03 20:09:00 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 661638970665734144,
  "created_at" : "2015-11-03 20:19:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Electric For Life",
      "screen_name" : "electricforlife",
      "indices" : [ 3, 19 ],
      "id_str" : "2817728443",
      "id" : 2817728443
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/electricforlife\/status\/661637313676509184\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/QchpS2V1UF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6boOXXIAAo41B.jpg",
      "id_str" : "661637310623195136",
      "id" : 661637310623195136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6boOXXIAAo41B.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1356,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QchpS2V1UF"
    } ],
    "hashtags" : [ {
      "text" : "electricforlife",
      "indices" : [ 21, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661638681929863168",
  "text" : "RT @electricforlife: #electricforlife https:\/\/t.co\/QchpS2V1UF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/electricforlife\/status\/661637313676509184\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/QchpS2V1UF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6boOXXIAAo41B.jpg",
        "id_str" : "661637310623195136",
        "id" : 661637310623195136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6boOXXIAAo41B.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1356,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QchpS2V1UF"
      } ],
      "hashtags" : [ {
        "text" : "electricforlife",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661637313676509184",
    "text" : "#electricforlife https:\/\/t.co\/QchpS2V1UF",
    "id" : 661637313676509184,
    "created_at" : "2015-11-03 20:13:22 +0000",
    "user" : {
      "name" : "Electric For Life",
      "screen_name" : "electricforlife",
      "protected" : false,
      "id_str" : "2817728443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/825040570263416833\/o6NSQgva_normal.jpg",
      "id" : 2817728443,
      "verified" : true
    }
  },
  "id" : 661638681929863168,
  "created_at" : "2015-11-03 20:18:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 12, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661616112640069632",
  "text" : "Went to the #OU bake sale today :)",
  "id" : 661616112640069632,
  "created_at" : "2015-11-03 18:49:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/661615916015333376\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/UnsHaSUGE4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6IJZdUYAAAEFI.jpg",
      "id_str" : "661615890304098304",
      "id" : 661615890304098304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6IJZdUYAAAEFI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1003
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1003
      } ],
      "display_url" : "pic.twitter.com\/UnsHaSUGE4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661615916015333376",
  "text" : "Giant cookie https:\/\/t.co\/UnsHaSUGE4",
  "id" : 661615916015333376,
  "created_at" : "2015-11-03 18:48:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Express",
      "screen_name" : "TeaPartyExpress",
      "indices" : [ 3, 19 ],
      "id_str" : "16366471",
      "id" : 16366471
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 31, 39 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeaParty",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661583085880942594",
  "text" : "RT @TeaPartyExpress: Thanks to @tedcruz for standing up for those who have been unfairly targeted and harassed by the IRS! #TeaParty https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 10, 18 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeaParty",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/E6SzM2sGIN",
        "expanded_url" : "http:\/\/thehill.com\/blogs\/floor-action\/senate\/258856-cruz-wants-doj-to-save-documents-on-irs-probe",
        "display_url" : "thehill.com\/blogs\/floor-ac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661313629032071168",
    "text" : "Thanks to @tedcruz for standing up for those who have been unfairly targeted and harassed by the IRS! #TeaParty https:\/\/t.co\/E6SzM2sGIN",
    "id" : 661313629032071168,
    "created_at" : "2015-11-02 22:47:10 +0000",
    "user" : {
      "name" : "Tea Party Express",
      "screen_name" : "TeaPartyExpress",
      "protected" : false,
      "id_str" : "16366471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000462681589\/096f0bbfb23a727c27fc4997160abaf9_normal.jpeg",
      "id" : 16366471,
      "verified" : true
    }
  },
  "id" : 661583085880942594,
  "created_at" : "2015-11-03 16:37:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/661336758798299136\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/omRoZAz9JU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2KRuGUcAAjzIv.png",
      "id_str" : "661336757330276352",
      "id" : 661336757330276352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2KRuGUcAAjzIv.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1612,
        "resize" : "fit",
        "w" : 1612
      } ],
      "display_url" : "pic.twitter.com\/omRoZAz9JU"
    } ],
    "hashtags" : [ {
      "text" : "AbolishTheIRS",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/L5m9XTho5j",
      "expanded_url" : "https:\/\/www.tedcruz.org\/tax_plan_summary\/",
      "display_url" : "tedcruz.org\/tax_plan_summa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661583055644172288",
  "text" : "RT @tedcruz: #AbolishTheIRS with my Simple Flat Tax plan: https:\/\/t.co\/L5m9XTho5j https:\/\/t.co\/omRoZAz9JU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/661336758798299136\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/omRoZAz9JU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2KRuGUcAAjzIv.png",
        "id_str" : "661336757330276352",
        "id" : 661336757330276352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2KRuGUcAAjzIv.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1612,
          "resize" : "fit",
          "w" : 1612
        } ],
        "display_url" : "pic.twitter.com\/omRoZAz9JU"
      } ],
      "hashtags" : [ {
        "text" : "AbolishTheIRS",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/L5m9XTho5j",
        "expanded_url" : "https:\/\/www.tedcruz.org\/tax_plan_summary\/",
        "display_url" : "tedcruz.org\/tax_plan_summa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661336758798299136",
    "text" : "#AbolishTheIRS with my Simple Flat Tax plan: https:\/\/t.co\/L5m9XTho5j https:\/\/t.co\/omRoZAz9JU",
    "id" : 661336758798299136,
    "created_at" : "2015-11-03 00:19:04 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 661583055644172288,
  "created_at" : "2015-11-03 16:37:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lichtenberger",
      "screen_name" : "AdvertisingLaw",
      "indices" : [ 3, 18 ],
      "id_str" : "29082715",
      "id" : 29082715
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 114, 122 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/thfK8srF8m",
      "expanded_url" : "http:\/\/bit.ly\/1Pjg4Xv",
      "display_url" : "bit.ly\/1Pjg4Xv"
    } ]
  },
  "geo" : { },
  "id_str" : "661582926254120960",
  "text" : "RT @AdvertisingLaw: Ted Cruz gains momentum after debate | Iowa State Daily https:\/\/t.co\/thfK8srF8m #GOPDebate || @tedcruz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 94, 102 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/thfK8srF8m",
        "expanded_url" : "http:\/\/bit.ly\/1Pjg4Xv",
        "display_url" : "bit.ly\/1Pjg4Xv"
      } ]
    },
    "geo" : { },
    "id_str" : "661535690245742592",
    "text" : "Ted Cruz gains momentum after debate | Iowa State Daily https:\/\/t.co\/thfK8srF8m #GOPDebate || @tedcruz",
    "id" : 661535690245742592,
    "created_at" : "2015-11-03 13:29:33 +0000",
    "user" : {
      "name" : "John Lichtenberger",
      "screen_name" : "AdvertisingLaw",
      "protected" : false,
      "id_str" : "29082715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/217569881\/ACS-LO-FF_normal.jpg",
      "id" : 29082715,
      "verified" : false
    }
  },
  "id" : 661582926254120960,
  "created_at" : "2015-11-03 16:37:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661582669243904000",
  "text" : "I know for a fact Frankie's cafe totally forgot the caramel #ThisIsOU",
  "id" : 661582669243904000,
  "created_at" : "2015-11-03 16:36:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/661273913683533824\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/7jz39ic8eo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1RHbTUwAAoy6J.jpg",
      "id_str" : "661273908323074048",
      "id" : 661273908323074048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1RHbTUwAAoy6J.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7jz39ic8eo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661273913683533824",
  "text" : "Ate at Riverside dining, 3.9\/5 stars https:\/\/t.co\/7jz39ic8eo",
  "id" : 661273913683533824,
  "created_at" : "2015-11-02 20:09:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]