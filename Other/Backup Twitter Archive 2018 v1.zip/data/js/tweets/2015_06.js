Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 3, 10 ],
      "id_str" : "24206345",
      "id" : 24206345
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 12, 24 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615589871877533697",
  "text" : "RT @Quirky: @gamer456148 Awesome idea!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "615515617035161600",
    "geo" : { },
    "id_str" : "615520578812968960",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Awesome idea!",
    "id" : 615520578812968960,
    "in_reply_to_status_id" : 615515617035161600,
    "created_at" : "2015-06-29 14:01:56 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "protected" : false,
      "id_str" : "24206345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866658132730273792\/Axe1T3mF_normal.jpg",
      "id" : 24206345,
      "verified" : true
    }
  },
  "id" : 615589871877533697,
  "created_at" : "2015-06-29 18:37:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/614066796472193024\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KFfpNQoaFE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWaf2pWoAEPpXI.jpg",
      "id_str" : "614066796241526785",
      "id" : 614066796241526785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWaf2pWoAEPpXI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KFfpNQoaFE"
    } ],
    "hashtags" : [ {
      "text" : "jokes",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "programmer",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "cloud",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615516997242253312",
  "text" : "RT @slidenerdtech: There is no cloud, its just someone else's computer :D #jokes #programmer #cloud http:\/\/t.co\/KFfpNQoaFE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/614066796472193024\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/KFfpNQoaFE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWaf2pWoAEPpXI.jpg",
        "id_str" : "614066796241526785",
        "id" : 614066796241526785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWaf2pWoAEPpXI.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/KFfpNQoaFE"
      } ],
      "hashtags" : [ {
        "text" : "jokes",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "programmer",
        "indices" : [ 62, 73 ]
      }, {
        "text" : "cloud",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614066796472193024",
    "text" : "There is no cloud, its just someone else's computer :D #jokes #programmer #cloud http:\/\/t.co\/KFfpNQoaFE",
    "id" : 614066796472193024,
    "created_at" : "2015-06-25 13:45:07 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918078120674058240\/-qudg3y2_normal.jpg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 615516997242253312,
  "created_at" : "2015-06-29 13:47:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 0, 8 ],
      "id_str" : "2890961",
      "id" : 2890961
    }, {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 40, 49 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615512318030520320",
  "geo" : { },
  "id_str" : "615515808945586176",
  "in_reply_to_user_id" : 2890961,
  "text" : "@Gizmodo You got to be kidding me, poor @elonmusk",
  "id" : 615515808945586176,
  "in_reply_to_status_id" : 615512318030520320,
  "created_at" : "2015-06-29 13:42:59 +0000",
  "in_reply_to_screen_name" : "Gizmodo",
  "in_reply_to_user_id_str" : "2890961",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/615253982462767104\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/S8IdrWEp71",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CInSPLaWIAAQo0x.jpg",
      "id_str" : "615253982315945984",
      "id" : 615253982315945984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CInSPLaWIAAQo0x.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/S8IdrWEp71"
    } ],
    "hashtags" : [ {
      "text" : "Awesome",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615253982462767104",
  "text" : "My sister made me this #Awesome frozen pizza for dinner \uD83D\uDE0B http:\/\/t.co\/S8IdrWEp71",
  "id" : 615253982462767104,
  "created_at" : "2015-06-28 20:22:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fawzy",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615176198948151297",
  "text" : "I just had awesome Turkish coffee #Fawzy",
  "id" : 615176198948151297,
  "created_at" : "2015-06-28 15:13:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/bSpYqZHys4",
      "expanded_url" : "https:\/\/youtu.be\/SkaFBkEe8ZE",
      "display_url" : "youtu.be\/SkaFBkEe8ZE"
    } ]
  },
  "geo" : { },
  "id_str" : "614937275126775808",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze decides to have more fun with a special type of \"hybrid\" vehicle https:\/\/t.co\/bSpYqZHys4",
  "id" : 614937275126775808,
  "created_at" : "2015-06-27 23:24:06 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 82, 94 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Business",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Swa9GiKIbT",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/QrVDM",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613061679404969984",
  "text" : "RT @CouponTrump: #Business Networking Basics: Successful Strategies to Connect by @gamer456148  Was $29 Now just $5 http:\/\/t.co\/Swa9GiKIbT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 65, 77 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Business",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Swa9GiKIbT",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/QrVDM",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613022518870413313",
    "text" : "#Business Networking Basics: Successful Strategies to Connect by @gamer456148  Was $29 Now just $5 http:\/\/t.co\/Swa9GiKIbT",
    "id" : 613022518870413313,
    "created_at" : "2015-06-22 16:35:32 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 613061679404969984,
  "created_at" : "2015-06-22 19:11:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisisOU",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613036459117936644",
  "text" : "Sometimes I am so random #ThisisOU",
  "id" : 613036459117936644,
  "created_at" : "2015-06-22 17:30:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoodNetwork",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612779516193157120",
  "text" : "My favorite celebrity chef contestants on #FoodNetwork are the lumberjack or the armenian mother",
  "id" : 612779516193157120,
  "created_at" : "2015-06-22 00:29:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilia Cirker",
      "screen_name" : "emiliacirker",
      "indices" : [ 0, 13 ],
      "id_str" : "296408030",
      "id" : 296408030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612778650006614016",
  "in_reply_to_user_id" : 296408030,
  "text" : "@emiliacirker You kind off remind me of Giada, I don't know why, lol",
  "id" : 612778650006614016,
  "created_at" : "2015-06-22 00:26:29 +0000",
  "in_reply_to_screen_name" : "emiliacirker",
  "in_reply_to_user_id_str" : "296408030",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxthon Browser",
      "screen_name" : "Maxthon",
      "indices" : [ 0, 8 ],
      "id_str" : "16900948",
      "id" : 16900948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612714457345568768",
  "in_reply_to_user_id" : 16900948,
  "text" : "@Maxthon Just tried your web browser, I think now I am uninstalling my other web browsers!!! The developers deserve a pat on the back :)",
  "id" : 612714457345568768,
  "created_at" : "2015-06-21 20:11:24 +0000",
  "in_reply_to_screen_name" : "Maxthon",
  "in_reply_to_user_id_str" : "16900948",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESTING",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "WHAT",
      "indices" : [ 9, 14 ]
    }, {
      "text" : "HAPPENS",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "WHEN",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "YOU",
      "indices" : [ 30, 34 ]
    }, {
      "text" : "USE",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "TOO",
      "indices" : [ 40, 44 ]
    }, {
      "text" : "MANY",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "HASHTAGS",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612691725547606016",
  "text" : "#TESTING #WHAT #HAPPENS #WHEN #YOU #USE #TOO #MANY #HASHTAGS",
  "id" : 612691725547606016,
  "created_at" : "2015-06-21 18:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/kLRjYMWCaL",
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612448834996842496",
      "display_url" : "twitter.com\/gamer456148\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612691220410855425",
  "text" : "RT @HelloRyanHolmes: Please https:\/\/t.co\/kLRjYMWCaL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 30 ],
        "url" : "https:\/\/t.co\/kLRjYMWCaL",
        "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612448834996842496",
        "display_url" : "twitter.com\/gamer456148\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612454218281132032",
    "text" : "Please https:\/\/t.co\/kLRjYMWCaL",
    "id" : 612454218281132032,
    "created_at" : "2015-06-21 02:57:19 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/981755756423737344\/APZTJDhC_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 612691220410855425,
  "created_at" : "2015-06-21 18:39:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612449208054976512",
  "text" : "RT @pluralsight: @gamer456148 Good luck!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shoutlet.com\" rel=\"nofollow\"\u003EShoutlet API\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "610517657918513152",
    "geo" : { },
    "id_str" : "610786123074433024",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Good luck!",
    "id" : 610786123074433024,
    "in_reply_to_status_id" : 610517657918513152,
    "created_at" : "2015-06-16 12:28:54 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908381030821675009\/nOwJrmgq_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 612449208054976512,
  "created_at" : "2015-06-21 02:37:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612448834996842496\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/HR3EoUj2Yp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH_a-HAWoAAoEou.jpg",
      "id_str" : "612448834912952320",
      "id" : 612448834912952320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH_a-HAWoAAoEou.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/HR3EoUj2Yp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612447933682851840",
  "geo" : { },
  "id_str" : "612448834996842496",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes This tight? http:\/\/t.co\/HR3EoUj2Yp",
  "id" : 612448834996842496,
  "in_reply_to_status_id" : 612447933682851840,
  "created_at" : "2015-06-21 02:35:55 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/yQLSD0kkBg",
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612444407997050880",
      "display_url" : "twitter.com\/gamer456148\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612448351586516993",
  "text" : "RT @HelloRyanHolmes: Idk if you understand gravity lol https:\/\/t.co\/yQLSD0kkBg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/yQLSD0kkBg",
        "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612444407997050880",
        "display_url" : "twitter.com\/gamer456148\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612445232727203840",
    "text" : "Idk if you understand gravity lol https:\/\/t.co\/yQLSD0kkBg",
    "id" : 612445232727203840,
    "created_at" : "2015-06-21 02:21:36 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/981755756423737344\/APZTJDhC_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 612448351586516993,
  "created_at" : "2015-06-21 02:34:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612445232727203840",
  "geo" : { },
  "id_str" : "612448161009913860",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes You won't be standing if you defy the laws of gravity, would you now?",
  "id" : 612448161009913860,
  "in_reply_to_status_id" : 612445232727203840,
  "created_at" : "2015-06-21 02:33:14 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612445232727203840",
  "geo" : { },
  "id_str" : "612447769467441153",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes I do, but it was kinda a joke I was aiming at :)",
  "id" : 612447769467441153,
  "in_reply_to_status_id" : 612445232727203840,
  "created_at" : "2015-06-21 02:31:41 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Scott Walker",
      "screen_name" : "ScottWalker",
      "indices" : [ 27, 39 ],
      "id_str" : "33750798",
      "id" : 33750798
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 49, 58 ],
      "id_str" : "216881337",
      "id" : 216881337
    }, {
      "name" : "Marco Rubio",
      "screen_name" : "marcorubio",
      "indices" : [ 91, 102 ],
      "id_str" : "15745368",
      "id" : 15745368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612056567484014592",
  "geo" : { },
  "id_str" : "612447440483041280",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz You for President @ScottWalker for vice @RandPaul for Secretary of Commerence and @marcorubio for Secretary of State= success",
  "id" : 612447440483041280,
  "in_reply_to_status_id" : 612056567484014592,
  "created_at" : "2015-06-21 02:30:23 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/612056567484014592\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/KI2BHQV6Qw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH52MCVVAAAEihV.jpg",
      "id_str" : "612056548525801472",
      "id" : 612056548525801472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH52MCVVAAAEihV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KI2BHQV6Qw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/612056567484014592\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/KI2BHQV6Qw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH52MCiUkAAFQ_e.jpg",
      "id_str" : "612056548580298752",
      "id" : 612056548580298752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH52MCiUkAAFQ_e.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KI2BHQV6Qw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612445581320015872",
  "text" : "RT @tedcruz: Great to spend the evening with friends at Cronk's Cafe in Denison, Iowa! http:\/\/t.co\/KI2BHQV6Qw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/612056567484014592\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/KI2BHQV6Qw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH52MCVVAAAEihV.jpg",
        "id_str" : "612056548525801472",
        "id" : 612056548525801472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH52MCVVAAAEihV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/KI2BHQV6Qw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/612056567484014592\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/KI2BHQV6Qw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH52MCiUkAAFQ_e.jpg",
        "id_str" : "612056548580298752",
        "id" : 612056548580298752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH52MCiUkAAFQ_e.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/KI2BHQV6Qw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612056567484014592",
    "text" : "Great to spend the evening with friends at Cronk's Cafe in Denison, Iowa! http:\/\/t.co\/KI2BHQV6Qw",
    "id" : 612056567484014592,
    "created_at" : "2015-06-20 00:37:11 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 612445581320015872,
  "created_at" : "2015-06-21 02:22:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 0, 9 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612077463120691200",
  "geo" : { },
  "id_str" : "612445443822325760",
  "in_reply_to_user_id" : 216881337,
  "text" : "@RandPaul The 2016 reference.",
  "id" : 612445443822325760,
  "in_reply_to_status_id" : 612077463120691200,
  "created_at" : "2015-06-21 02:22:27 +0000",
  "in_reply_to_screen_name" : "RandPaul",
  "in_reply_to_user_id_str" : "216881337",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 3, 12 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QLetgnDsD9",
      "expanded_url" : "http:\/\/randpaul.com\/f\/tax-plan-2?sr=619tw5",
      "display_url" : "randpaul.com\/f\/tax-plan-2?s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612445323462602752",
  "text" : "RT @RandPaul: Help me drive a stake through the heart of the IRS. Sign your name, then chip in $20.16 right away: http:\/\/t.co\/QLetgnDsD9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/QLetgnDsD9",
        "expanded_url" : "http:\/\/randpaul.com\/f\/tax-plan-2?sr=619tw5",
        "display_url" : "randpaul.com\/f\/tax-plan-2?s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612077463120691200",
    "text" : "Help me drive a stake through the heart of the IRS. Sign your name, then chip in $20.16 right away: http:\/\/t.co\/QLetgnDsD9",
    "id" : 612077463120691200,
    "created_at" : "2015-06-20 02:00:13 +0000",
    "user" : {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "protected" : false,
      "id_str" : "216881337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681152691461042177\/_PrgDgFA_normal.jpg",
      "id" : 216881337,
      "verified" : true
    }
  },
  "id" : 612445323462602752,
  "created_at" : "2015-06-21 02:21:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612405012187213824",
  "geo" : { },
  "id_str" : "612444407997050880",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Hope you are doing well, Ryan!!! Don't be down when gravity is trying to help you stand up \uD83D\uDE1D",
  "id" : 612444407997050880,
  "in_reply_to_status_id" : 612405012187213824,
  "created_at" : "2015-06-21 02:18:20 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gyft",
      "screen_name" : "gyft",
      "indices" : [ 0, 5 ],
      "id_str" : "492064542",
      "id" : 492064542
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/612443821398470656\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Po1wxRGmbi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH_WaR1WIAA9VTq.jpg",
      "id_str" : "612443821297770496",
      "id" : 612443821297770496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH_WaR1WIAA9VTq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 408
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 600
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Po1wxRGmbi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612443821398470656",
  "in_reply_to_user_id" : 492064542,
  "text" : "@gyft This is your process? You shouldn't need to upload an ID to make a small online purchase!!! \uD83D\uDE12 http:\/\/t.co\/Po1wxRGmbi",
  "id" : 612443821398470656,
  "created_at" : "2015-06-21 02:16:00 +0000",
  "in_reply_to_screen_name" : "gyft",
  "in_reply_to_user_id_str" : "492064542",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612441724003217408",
  "text" : "I can't stand terrible apps!!!",
  "id" : 612441724003217408,
  "created_at" : "2015-06-21 02:07:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gyft",
      "screen_name" : "gyft",
      "indices" : [ 3, 8 ],
      "id_str" : "492064542",
      "id" : 492064542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Failed",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612441599419625474",
  "text" : "So @Gyft just canceled my father's day gift to my dad then told me I need to fill out a form and give them my ID. No thank you #Failed",
  "id" : 612441599419625474,
  "created_at" : "2015-06-21 02:07:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612048020520218624",
  "text" : "Seriously JoyCamp has videos with comedic genius with bits of truth, now that is real entertainment.",
  "id" : 612048020520218624,
  "created_at" : "2015-06-20 00:03:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JoyCamp",
      "screen_name" : "TheJoyCamp",
      "indices" : [ 12, 23 ],
      "id_str" : "836656141",
      "id" : 836656141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612047828693729280",
  "text" : "I need more @TheJoyCamp videos, I want to laugh, lol :)",
  "id" : 612047828693729280,
  "created_at" : "2015-06-20 00:02:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Putin",
      "screen_name" : "PutinRF_Eng",
      "indices" : [ 3, 15 ],
      "id_str" : "932196612",
      "id" : 932196612
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/smyRqiMRK4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8NwVVAAACRI-.jpg",
      "id_str" : "611640962658402304",
      "id" : 611640962658402304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8NwVVAAACRI-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/smyRqiMRK4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/smyRqiMRK4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8Nw1VAAAzroq.jpg",
      "id_str" : "611640962792620032",
      "id" : 611640962792620032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8Nw1VAAAzroq.jpg",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/smyRqiMRK4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/smyRqiMRK4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8NxUUEAEV_WT.jpg",
      "id_str" : "611640962922582017",
      "id" : 611640962922582017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8NxUUEAEV_WT.jpg",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/smyRqiMRK4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/smyRqiMRK4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8N1XUwAAAMId.jpg",
      "id_str" : "611640964008951808",
      "id" : 611640964008951808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8N1XUwAAAMId.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/smyRqiMRK4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/eIucGpfmrJ",
      "expanded_url" : "http:\/\/en.kremlin.ru\/events\/president\/news\/49722",
      "display_url" : "en.kremlin.ru\/events\/preside\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612047133185806336",
  "text" : "RT @PutinRF_Eng: Meeting with heads of Russian industrial companies\n\nhttp:\/\/t.co\/eIucGpfmrJ http:\/\/t.co\/smyRqiMRK4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/smyRqiMRK4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8NwVVAAACRI-.jpg",
        "id_str" : "611640962658402304",
        "id" : 611640962658402304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8NwVVAAACRI-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/smyRqiMRK4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/smyRqiMRK4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8Nw1VAAAzroq.jpg",
        "id_str" : "611640962792620032",
        "id" : 611640962792620032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8Nw1VAAAzroq.jpg",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/smyRqiMRK4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/smyRqiMRK4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8NxUUEAEV_WT.jpg",
        "id_str" : "611640962922582017",
        "id" : 611640962922582017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8NxUUEAEV_WT.jpg",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/smyRqiMRK4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/PutinRF_Eng\/status\/611641059622408192\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/smyRqiMRK4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz8N1XUwAAAMId.jpg",
        "id_str" : "611640964008951808",
        "id" : 611640964008951808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz8N1XUwAAAMId.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/smyRqiMRK4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/eIucGpfmrJ",
        "expanded_url" : "http:\/\/en.kremlin.ru\/events\/president\/news\/49722",
        "display_url" : "en.kremlin.ru\/events\/preside\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611641059622408192",
    "text" : "Meeting with heads of Russian industrial companies\n\nhttp:\/\/t.co\/eIucGpfmrJ http:\/\/t.co\/smyRqiMRK4",
    "id" : 611641059622408192,
    "created_at" : "2015-06-18 21:06:07 +0000",
    "user" : {
      "name" : "Vladimir Putin",
      "screen_name" : "PutinRF_Eng",
      "protected" : false,
      "id_str" : "932196612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2821613356\/a15ac328aca48742f6fea77546671b70_normal.jpeg",
      "id" : 932196612,
      "verified" : false
    }
  },
  "id" : 612047133185806336,
  "created_at" : "2015-06-19 23:59:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611330824315600896",
  "geo" : { },
  "id_str" : "612046898472579073",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice LOL",
  "id" : 612046898472579073,
  "in_reply_to_status_id" : 611330824315600896,
  "created_at" : "2015-06-19 23:58:46 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 72, 80 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612045991273828352",
  "text" : "Hopefully there is some moral fabric left in this nation, at least some @tedcruz",
  "id" : 612045991273828352,
  "created_at" : "2015-06-19 23:55:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 9, 18 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612045627996770304",
  "text" : "Watching @RandPaul at C-SPAN, he is speaking some obvious points #tcot",
  "id" : 612045627996770304,
  "created_at" : "2015-06-19 23:53:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 18, 30 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Invent",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611973202131165184",
  "text" : "Anyone else think @colin_furze videos inspire kids to #Invent",
  "id" : 611973202131165184,
  "created_at" : "2015-06-19 19:05:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 0, 12 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611408057847971840",
  "geo" : { },
  "id_str" : "611972999760232448",
  "in_reply_to_user_id" : 2370179022,
  "text" : "@CouponTrump Awesome share",
  "id" : 611972999760232448,
  "in_reply_to_status_id" : 611408057847971840,
  "created_at" : "2015-06-19 19:05:07 +0000",
  "in_reply_to_screen_name" : "CouponTrump",
  "in_reply_to_user_id_str" : "2370179022",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 82, 94 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Business",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/1IEDyaV0ak",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/RjOC8",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611972936690454532",
  "text" : "RT @CouponTrump: #Business Networking Basics: Successful Strategies to Connect by @gamer456148  Was $9 Now just $5 http:\/\/t.co\/1IEDyaV0ak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 65, 77 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Business",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/1IEDyaV0ak",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/RjOC8",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611297351974715392",
    "text" : "#Business Networking Basics: Successful Strategies to Connect by @gamer456148  Was $9 Now just $5 http:\/\/t.co\/1IEDyaV0ak",
    "id" : 611297351974715392,
    "created_at" : "2015-06-17 22:20:20 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 611972936690454532,
  "created_at" : "2015-06-19 19:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisisOU",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611972826887753728",
  "text" : "15 pages of math notes in a single weeks worth, awesome day yesterday, reading about transitive verbs. Advising + Tutoring #ThisisOU \uD83D\uDEB6",
  "id" : 611972826887753728,
  "created_at" : "2015-06-19 19:04:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inception",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610886542261944320",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech Maybe next you will build an app that tells people how lazy they are for using that app #Inception It will be called PottyNow",
  "id" : 610886542261944320,
  "created_at" : "2015-06-16 19:07:56 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HowToEvery",
      "screen_name" : "ishay1999",
      "indices" : [ 0, 10 ],
      "id_str" : "230471671",
      "id" : 230471671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610885132644388864",
  "in_reply_to_user_id" : 230471671,
  "text" : "@ishay1999 Shalom, how are you Ishay? :P",
  "id" : 610885132644388864,
  "created_at" : "2015-06-16 19:02:19 +0000",
  "in_reply_to_screen_name" : "ishay1999",
  "in_reply_to_user_id_str" : "230471671",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610884790519205889",
  "text" : "@JosefLokmani I hope you become more successful then me :) Although not really much competition for a first year University Student :)",
  "id" : 610884790519205889,
  "created_at" : "2015-06-16 19:00:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610884188506574848",
  "text" : "@JosefLokmani :P",
  "id" : 610884188506574848,
  "created_at" : "2015-06-16 18:58:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 0, 12 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610786123074433024",
  "geo" : { },
  "id_str" : "610884096978460672",
  "in_reply_to_user_id" : 19253334,
  "text" : "@pluralsight Thanks, I may need it ;)",
  "id" : 610884096978460672,
  "in_reply_to_status_id" : 610786123074433024,
  "created_at" : "2015-06-16 18:58:13 +0000",
  "in_reply_to_screen_name" : "pluralsight",
  "in_reply_to_user_id_str" : "19253334",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610804251745472512",
  "text" : "Please help, I am addicted to Turkish Delight, lol \uD83C\uDFC1",
  "id" : 610804251745472512,
  "created_at" : "2015-06-16 13:40:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610562149123928064",
  "geo" : { },
  "id_str" : "610618506112057344",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz Why did a majority of Americans apparently elect a failed community organizer?",
  "id" : 610618506112057344,
  "in_reply_to_status_id" : 610562149123928064,
  "created_at" : "2015-06-16 01:22:51 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610618272388677632",
  "text" : "RT @tedcruz: Obama Admin refuses to supply Kurds\u2014who\u2019ve proven successful fighters\u2014w\/ resources they need to defeat ISIS in N Iraq http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VylFNy34Pb",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/06\/13\/world\/middleeast\/success-of-kurdish-forces-is-a-rare-bright-spot-for-us-policy-in-iraq.html?ref=middleeast&_r=2",
        "display_url" : "nytimes.com\/2015\/06\/13\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610562149123928064",
    "text" : "Obama Admin refuses to supply Kurds\u2014who\u2019ve proven successful fighters\u2014w\/ resources they need to defeat ISIS in N Iraq http:\/\/t.co\/VylFNy34Pb",
    "id" : 610562149123928064,
    "created_at" : "2015-06-15 21:38:54 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 610618272388677632,
  "created_at" : "2015-06-16 01:21:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610618120244473856",
  "text" : "Egyptian cheese and baked goods taste so delightful \uD83C\uDF74",
  "id" : 610618120244473856,
  "created_at" : "2015-06-16 01:21:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/610612560291872770\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ZCWDJ11Ve2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHlU42dWgAE7CHJ.jpg",
      "id_str" : "610612560153444353",
      "id" : 610612560153444353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHlU42dWgAE7CHJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ZCWDJ11Ve2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610612560291872770",
  "text" : "My grandma got cookies and sweet bread, but this is one of my favorites :) http:\/\/t.co\/ZCWDJ11Ve2",
  "id" : 610612560291872770,
  "created_at" : "2015-06-16 00:59:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 0, 12 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610424354652991488",
  "geo" : { },
  "id_str" : "610517657918513152",
  "in_reply_to_user_id" : 19253334,
  "text" : "@pluralsight Filled it out, will wait and see",
  "id" : 610517657918513152,
  "in_reply_to_status_id" : 610424354652991488,
  "created_at" : "2015-06-15 18:42:07 +0000",
  "in_reply_to_screen_name" : "pluralsight",
  "in_reply_to_user_id_str" : "19253334",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salesforce",
      "screen_name" : "salesforce",
      "indices" : [ 0, 11 ],
      "id_str" : "33612317",
      "id" : 33612317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609763081179299840",
  "in_reply_to_user_id" : 33612317,
  "text" : "@Salesforce Loving the new technology!!!",
  "id" : 609763081179299840,
  "created_at" : "2015-06-13 16:43:42 +0000",
  "in_reply_to_screen_name" : "salesforce",
  "in_reply_to_user_id_str" : "33612317",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SalesforceDevelopers",
      "screen_name" : "SalesforceDevs",
      "indices" : [ 3, 18 ],
      "id_str" : "7834512",
      "id" : 7834512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trailhead",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/2d46CQ5NyL",
      "expanded_url" : "http:\/\/sforce.co\/1KKS0bJ",
      "display_url" : "sforce.co\/1KKS0bJ"
    } ]
  },
  "geo" : { },
  "id_str" : "609762868855218176",
  "text" : "RT @SalesforceDevs: BIG news from #Trailhead!\u00A0\nDevelopers &amp; Admins, follow your very own newly paved trails: http:\/\/t.co\/2d46CQ5NyL http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SalesforceDevs\/status\/598608234820333568\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/SSwMFka5wS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE6vBJhW0AAmzv4.png",
        "id_str" : "598608234757410816",
        "id" : 598608234757410816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE6vBJhW0AAmzv4.png",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/SSwMFka5wS"
      } ],
      "hashtags" : [ {
        "text" : "Trailhead",
        "indices" : [ 14, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/2d46CQ5NyL",
        "expanded_url" : "http:\/\/sforce.co\/1KKS0bJ",
        "display_url" : "sforce.co\/1KKS0bJ"
      } ]
    },
    "geo" : { },
    "id_str" : "598608234820333568",
    "text" : "BIG news from #Trailhead!\u00A0\nDevelopers &amp; Admins, follow your very own newly paved trails: http:\/\/t.co\/2d46CQ5NyL http:\/\/t.co\/SSwMFka5wS",
    "id" : 598608234820333568,
    "created_at" : "2015-05-13 21:58:19 +0000",
    "user" : {
      "name" : "SalesforceDevelopers",
      "screen_name" : "SalesforceDevs",
      "protected" : false,
      "id_str" : "7834512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875809720266743808\/jX-q_THz_normal.jpg",
      "id" : 7834512,
      "verified" : true
    }
  },
  "id" : 609762868855218176,
  "created_at" : "2015-06-13 16:42:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 14, 26 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609762501081886720",
  "text" : "Might publish @pluralsight if they give me the chance. I love the platform.",
  "id" : 609762501081886720,
  "created_at" : "2015-06-13 16:41:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609709194967527425",
  "text" : "@JosefLokmani A bright future :)",
  "id" : 609709194967527425,
  "created_at" : "2015-06-13 13:09:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609483441655128066",
  "text" : "I just want to make it!!!",
  "id" : 609483441655128066,
  "created_at" : "2015-06-12 22:12:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 52, 64 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Udemy",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/DGlZfxVvU4",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/YJ6YC",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609482830037536770",
  "text" : "RT @CouponTrump: Create a Resume' Website #Udemy by @gamer456148  Just $9 http:\/\/t.co\/DGlZfxVvU4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 35, 47 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Udemy",
        "indices" : [ 25, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/DGlZfxVvU4",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/YJ6YC",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609267713295417344",
    "text" : "Create a Resume' Website #Udemy by @gamer456148  Just $9 http:\/\/t.co\/DGlZfxVvU4",
    "id" : 609267713295417344,
    "created_at" : "2015-06-12 07:55:17 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 609482830037536770,
  "created_at" : "2015-06-12 22:10:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609042411885572096",
  "in_reply_to_user_id" : 321610630,
  "text" : "@Colin_Furze What will you invent next, perhaps a cake mixer that makes frappe's, lol",
  "id" : 609042411885572096,
  "created_at" : "2015-06-11 17:00:01 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/607970850197913602\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/7m3UTIJ5Hu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG_yRFVW0AASZJ5.jpg",
      "id_str" : "607970850021756928",
      "id" : 607970850021756928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG_yRFVW0AASZJ5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/7m3UTIJ5Hu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607970850197913602",
  "text" : "New haircut, all 2 :) http:\/\/t.co\/7m3UTIJ5Hu",
  "id" : 607970850197913602,
  "created_at" : "2015-06-08 18:02:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607955569002061824",
  "text" : "My mom makes the best Iced Coffee",
  "id" : 607955569002061824,
  "created_at" : "2015-06-08 17:01:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/BHgInI6cBJ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=iVrJUbeuG44",
      "display_url" : "youtube.com\/watch?v=iVrJUb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607875847719124992",
  "text" : "This kid done it again!!! https:\/\/t.co\/BHgInI6cBJ",
  "id" : 607875847719124992,
  "created_at" : "2015-06-08 11:44:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Fitzgerald",
      "screen_name" : "cwmchristina",
      "indices" : [ 3, 16 ],
      "id_str" : "1633973215",
      "id" : 1633973215
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607875514339082240",
  "text" : "RT @cwmchristina: @gamer456148 thank you; ) stay tuned! !! You might see me again! !!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "607730590666911744",
    "geo" : { },
    "id_str" : "607735959099076609",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 thank you; ) stay tuned! !! You might see me again! !!!",
    "id" : 607735959099076609,
    "in_reply_to_status_id" : 607730590666911744,
    "created_at" : "2015-06-08 02:28:38 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Christina Fitzgerald",
      "screen_name" : "cwmchristina",
      "protected" : false,
      "id_str" : "1633973215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920832524590501889\/aICCk-Hw_normal.jpg",
      "id" : 1633973215,
      "verified" : false
    }
  },
  "id" : 607875514339082240,
  "created_at" : "2015-06-08 11:43:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Fitzgerald",
      "screen_name" : "cwmchristina",
      "indices" : [ 0, 13 ],
      "id_str" : "1633973215",
      "id" : 1633973215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607730590666911744",
  "in_reply_to_user_id" : 1633973215,
  "text" : "@cwmchristina Too bad Food Network left out the most beautiful and energized cook to hit TV :( Good luck, sure you'll do something amazing!!",
  "id" : 607730590666911744,
  "created_at" : "2015-06-08 02:07:18 +0000",
  "in_reply_to_screen_name" : "cwmchristina",
  "in_reply_to_user_id_str" : "1633973215",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/607660898111492096\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/MWdfl96po1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG7YXgBU8AAglvM.jpg",
      "id_str" : "607660897985687552",
      "id" : 607660897985687552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG7YXgBU8AAglvM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/MWdfl96po1"
    } ],
    "hashtags" : [ {
      "text" : "more",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607660898111492096",
  "text" : "Got a new grill, sure beats the Charcoal one we used to own. Nothing like the smokey flavor of propane burgers #more http:\/\/t.co\/MWdfl96po1",
  "id" : 607660898111492096,
  "created_at" : "2015-06-07 21:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603373442243563520",
  "geo" : { },
  "id_str" : "607660533920038912",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech 11 days, now we are talking",
  "id" : 607660533920038912,
  "in_reply_to_status_id" : 603373442243563520,
  "created_at" : "2015-06-07 21:28:55 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/YLezPiTeRH",
      "expanded_url" : "http:\/\/eib.tw\/1x21A2m",
      "display_url" : "eib.tw\/1x21A2m"
    } ]
  },
  "geo" : { },
  "id_str" : "606932044388704256",
  "text" : "RT @rushlimbaugh: \"Separation of powers is the number one safeguard the Founders built into the Constitution.\"  http:\/\/t.co\/YLezPiTeRH http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rushlimbaugh\/status\/555485843129765889\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7xtLmWTpZp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7V7bkhCAAAgT44.png",
        "id_str" : "555485842639028224",
        "id" : 555485842639028224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7V7bkhCAAAgT44.png",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 998
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/7xtLmWTpZp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/YLezPiTeRH",
        "expanded_url" : "http:\/\/eib.tw\/1x21A2m",
        "display_url" : "eib.tw\/1x21A2m"
      } ]
    },
    "geo" : { },
    "id_str" : "555485843129765889",
    "text" : "\"Separation of powers is the number one safeguard the Founders built into the Constitution.\"  http:\/\/t.co\/YLezPiTeRH http:\/\/t.co\/7xtLmWTpZp",
    "id" : 555485843129765889,
    "created_at" : "2015-01-14 22:05:20 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 606932044388704256,
  "created_at" : "2015-06-05 21:14:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rushlimbaugh\/status\/591345516358733824\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9bVhD5iVOt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDThnRmUMAEj5-s.jpg",
      "id_str" : "591345515947634689",
      "id" : 591345515947634689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDThnRmUMAEj5-s.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 585
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 585
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/9bVhD5iVOt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606931953867190273",
  "text" : "RT @rushlimbaugh: The Clinton Family Crime Foundation- You donate a dollar, we'll keep 85 cents. http:\/\/t.co\/9bVhD5iVOt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rushlimbaugh\/status\/591345516358733824\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/9bVhD5iVOt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDThnRmUMAEj5-s.jpg",
        "id_str" : "591345515947634689",
        "id" : 591345515947634689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDThnRmUMAEj5-s.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 585
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 585
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/9bVhD5iVOt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591345516358733824",
    "text" : "The Clinton Family Crime Foundation- You donate a dollar, we'll keep 85 cents. http:\/\/t.co\/9bVhD5iVOt",
    "id" : 591345516358733824,
    "created_at" : "2015-04-23 20:58:52 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 606931953867190273,
  "created_at" : "2015-06-05 21:13:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SUPERTIGER",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/xRQGWz3mTZ",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.tokmak.tiger",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606931637205659649",
  "text" : "Check out this cool app by a client #SUPERTIGER https:\/\/t.co\/xRQGWz3mTZ",
  "id" : 606931637205659649,
  "created_at" : "2015-06-05 21:12:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/606567205560578050\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/kfknsghm9U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGr1qNuWcAE4Ht1.jpg",
      "id_str" : "606567205422133249",
      "id" : 606567205422133249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGr1qNuWcAE4Ht1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/kfknsghm9U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606567205560578050",
  "text" : "Had Taco Laco :) http:\/\/t.co\/kfknsghm9U",
  "id" : 606567205560578050,
  "created_at" : "2015-06-04 21:04:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Innovation",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/4Ud2Vx2LUY",
      "expanded_url" : "http:\/\/hfht.co\/0denY",
      "display_url" : "hfht.co\/0denY"
    } ]
  },
  "geo" : { },
  "id_str" : "606490804866195456",
  "text" : "Check out the coolest #Innovation Portfolio by AndSocialREW Gaming and Publishing http:\/\/t.co\/4Ud2Vx2LUY",
  "id" : 606490804866195456,
  "created_at" : "2015-06-04 16:00:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606244117023191040",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice more man on the street bits!!!",
  "id" : 606244117023191040,
  "created_at" : "2015-06-03 23:40:35 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606243816035753984",
  "in_reply_to_user_id" : 166478326,
  "text" : "@FouseyTUBE \n\u0623\u062A\u0645\u0646\u0649 \u0644\u0643 \u064A\u0648\u0645\u0627 \u0633\u0639\u064A\u062F\u0627",
  "id" : 606243816035753984,
  "created_at" : "2015-06-03 23:39:23 +0000",
  "in_reply_to_screen_name" : "fousey",
  "in_reply_to_user_id_str" : "166478326",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]