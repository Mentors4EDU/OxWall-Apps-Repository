Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Avallone",
      "screen_name" : "AvalloneHunter",
      "indices" : [ 0, 15 ],
      "id_str" : "2575373509",
      "id" : 2575373509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781986068774002688",
  "geo" : { },
  "id_str" : "781989682183753728",
  "in_reply_to_user_id" : 2575373509,
  "text" : "@AvalloneHunter Wait so if I identified as a panda would I still have to pay taxes? \uD83D\uDE02",
  "id" : 781989682183753728,
  "in_reply_to_status_id" : 781986068774002688,
  "created_at" : "2016-09-30 22:50:43 +0000",
  "in_reply_to_screen_name" : "AvalloneHunter",
  "in_reply_to_user_id_str" : "2575373509",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debatenight",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780856515758592002",
  "text" : "RT @KassyDillon: I am a woman who thinks Hillary Clinton doesn't have the presidential look. #debatenight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debatenight",
        "indices" : [ 76, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780596406125989888",
    "text" : "I am a woman who thinks Hillary Clinton doesn't have the presidential look. #debatenight",
    "id" : 780596406125989888,
    "created_at" : "2016-09-27 02:34:20 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 780856515758592002,
  "created_at" : "2016-09-27 19:47:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780856483131121664",
  "text" : "People who charge 25 cents for an empty paper cup are criminal, thankfully a good Samaritan gave me a quarter",
  "id" : 780856483131121664,
  "created_at" : "2016-09-27 19:47:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780554188354785280",
  "text" : "RT @Gillette: What was your biggest accomplishment this past weekend? (FYI, \"World Class Nachos\" is an acceptable answer).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780437277763833856",
    "text" : "What was your biggest accomplishment this past weekend? (FYI, \"World Class Nachos\" is an acceptable answer).",
    "id" : 780437277763833856,
    "created_at" : "2016-09-26 16:02:01 +0000",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 780554188354785280,
  "created_at" : "2016-09-26 23:46:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780437637471539200",
  "geo" : { },
  "id_str" : "780554163054710785",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine None of them are promising candidates, try finding an honest politician \uD83D\uDE2D",
  "id" : 780554163054710785,
  "in_reply_to_status_id" : 780437637471539200,
  "created_at" : "2016-09-26 23:46:29 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Jared Monroe",
      "screen_name" : "NotGayJared",
      "indices" : [ 25, 37 ],
      "id_str" : "23719684",
      "id" : 23719684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553930459582464",
  "text" : "RT @scrowder: Confirmed. @NotGayJared and I will be live streaming the #debates tonight with commentary and adult beverages. 9PM ET #debate\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Monroe",
        "screen_name" : "NotGayJared",
        "indices" : [ 11, 23 ],
        "id_str" : "23719684",
        "id" : 23719684
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/780445677176233984\/photo\/1",
        "indices" : [ 131, 154 ],
        "url" : "https:\/\/t.co\/oE3Cd7JIpv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtSzEtlXYAATX0T.jpg",
        "id_str" : "780445528979103744",
        "id" : 780445528979103744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtSzEtlXYAATX0T.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/oE3Cd7JIpv"
      } ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 57, 65 ]
      }, {
        "text" : "debatenight",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780445677176233984",
    "text" : "Confirmed. @NotGayJared and I will be live streaming the #debates tonight with commentary and adult beverages. 9PM ET #debatenight https:\/\/t.co\/oE3Cd7JIpv",
    "id" : 780445677176233984,
    "created_at" : "2016-09-26 16:35:24 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 780553930459582464,
  "created_at" : "2016-09-26 23:45:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553841003462656",
  "text" : "RT @lorenridinger: \"If you want to make your dreams come true, the first thing you have to do is wake up.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780452128020103168",
    "text" : "\"If you want to make your dreams come true, the first thing you have to do is wake up.\"",
    "id" : 780452128020103168,
    "created_at" : "2016-09-26 17:01:02 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 780553841003462656,
  "created_at" : "2016-09-26 23:45:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "indices" : [ 3, 11 ],
      "id_str" : "18930003",
      "id" : 18930003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553820107517952",
  "text" : "RT @UgoUche: It's not what happens to you, but how you react to it that matters. -Epictetus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780456839150395392",
    "text" : "It's not what happens to you, but how you react to it that matters. -Epictetus",
    "id" : 780456839150395392,
    "created_at" : "2016-09-26 17:19:45 +0000",
    "user" : {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "protected" : false,
      "id_str" : "18930003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2161257485\/img_0008__427x640___214x320___120x180__normal.jpg",
      "id" : 18930003,
      "verified" : false
    }
  },
  "id" : 780553820107517952,
  "created_at" : "2016-09-26 23:45:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780461720078778368",
  "geo" : { },
  "id_str" : "780553772451844096",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Hubbgle?",
  "id" : 780553772451844096,
  "in_reply_to_status_id" : 780461720078778368,
  "created_at" : "2016-09-26 23:44:55 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553631401582592",
  "text" : "RT @rockindigo: The hubbgle telescope captured a supernova exploding within our galaxy (20k Light years away). This looks beautiful! https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/780461720078778368\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lYFJbRnTEe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtTBzB4WcAA51kJ.jpg",
        "id_str" : "780461717864214528",
        "id" : 780461717864214528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtTBzB4WcAA51kJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/lYFJbRnTEe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780461720078778368",
    "text" : "The hubbgle telescope captured a supernova exploding within our galaxy (20k Light years away). This looks beautiful! https:\/\/t.co\/lYFJbRnTEe",
    "id" : 780461720078778368,
    "created_at" : "2016-09-26 17:39:09 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 780553631401582592,
  "created_at" : "2016-09-26 23:44:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Jared Monroe",
      "screen_name" : "NotGayJared",
      "indices" : [ 49, 61 ],
      "id_str" : "23719684",
      "id" : 23719684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mondaymotivation",
      "indices" : [ 24, 41 ]
    }, {
      "text" : "debates",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553584244985856",
  "text" : "RT @scrowder: Want some #mondaymotivation? Watch @NotGayJared livestream the #debates with me tonight. If he can do it, you've all got a sh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jared Monroe",
        "screen_name" : "NotGayJared",
        "indices" : [ 35, 47 ],
        "id_str" : "23719684",
        "id" : 23719684
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mondaymotivation",
        "indices" : [ 10, 27 ]
      }, {
        "text" : "debates",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780471533491875840",
    "text" : "Want some #mondaymotivation? Watch @NotGayJared livestream the #debates with me tonight. If he can do it, you've all got a shot.",
    "id" : 780471533491875840,
    "created_at" : "2016-09-26 18:18:08 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 780553584244985856,
  "created_at" : "2016-09-26 23:44:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553423754190848",
  "text" : "RT @BarbaraCorcoran: Keeping a positive attitude no matter what life throws at you allows you to look for solutions, forge ahead + create n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780484775932993536",
    "text" : "Keeping a positive attitude no matter what life throws at you allows you to look for solutions, forge ahead + create new paths to the top!",
    "id" : 780484775932993536,
    "created_at" : "2016-09-26 19:10:45 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 780553423754190848,
  "created_at" : "2016-09-26 23:43:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/780553401868259328\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/ny8AfYo8ME",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtUVLUkW8AEFVxK.jpg",
      "id_str" : "780553394662600705",
      "id" : 780553394662600705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtUVLUkW8AEFVxK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ny8AfYo8ME"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780553401868259328",
  "text" : "5 guys and Pibb \uD83D\uDE0E 4.78\/5 stars https:\/\/t.co\/ny8AfYo8ME",
  "id" : 780553401868259328,
  "created_at" : "2016-09-26 23:43:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/780275236922994688\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/vRleyJvBkx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtQYMI4VIAAJY2N.jpg",
      "id_str" : "780275232263184384",
      "id" : 780275232263184384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtQYMI4VIAAJY2N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 1370
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 1370
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/vRleyJvBkx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780356359506186240",
  "text" : "RT @elonmusk: SpaceX propulsion just achieved first firing of the Raptor interplanetary transport engine https:\/\/t.co\/vRleyJvBkx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/780275236922994688\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/vRleyJvBkx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtQYMI4VIAAJY2N.jpg",
        "id_str" : "780275232263184384",
        "id" : 780275232263184384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtQYMI4VIAAJY2N.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1370
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1370
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/vRleyJvBkx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780275236922994688",
    "text" : "SpaceX propulsion just achieved first firing of the Raptor interplanetary transport engine https:\/\/t.co\/vRleyJvBkx",
    "id" : 780275236922994688,
    "created_at" : "2016-09-26 05:18:07 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 780356359506186240,
  "created_at" : "2016-09-26 10:40:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/780356333409218561\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/FyThIhOMto",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtRh7k2UAAAUZ9V.jpg",
      "id_str" : "780356311573594112",
      "id" : 780356311573594112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtRh7k2UAAAUZ9V.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/FyThIhOMto"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780356333409218561",
  "text" : "Starting my day https:\/\/t.co\/FyThIhOMto",
  "id" : 780356333409218561,
  "created_at" : "2016-09-26 10:40:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "780108147692343297",
  "geo" : { },
  "id_str" : "780149043854848000",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo Yes please \uD83D\uDE0E",
  "id" : 780149043854848000,
  "in_reply_to_status_id" : 780108147692343297,
  "created_at" : "2016-09-25 20:56:41 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/779180242908934144\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/94jTb0ctVY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtA0TSdWIAAkZM0.jpg",
      "id_str" : "779180241512177664",
      "id" : 779180241512177664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtA0TSdWIAAkZM0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 480
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/94jTb0ctVY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148618271465472",
  "text" : "RT @slidenerdtech: Now that is what I can beauty and the beast,,, https:\/\/t.co\/94jTb0ctVY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/779180242908934144\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/94jTb0ctVY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtA0TSdWIAAkZM0.jpg",
        "id_str" : "779180241512177664",
        "id" : 779180241512177664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtA0TSdWIAAkZM0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 480
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/94jTb0ctVY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779180242908934144",
    "text" : "Now that is what I can beauty and the beast,,, https:\/\/t.co\/94jTb0ctVY",
    "id" : 779180242908934144,
    "created_at" : "2016-09-23 04:47:01 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918078120674058240\/-qudg3y2_normal.jpg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 780148618271465472,
  "created_at" : "2016-09-25 20:54:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/780039441909944320\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/sk3MkygnsH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNBvPrXgAATekl.jpg",
      "id_str" : "780039440383311872",
      "id" : 780039440383311872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNBvPrXgAATekl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 700
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/sk3MkygnsH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148548746682369",
  "text" : "RT @slidenerdtech: When you finally try to understand how the gradle build works in Android.. https:\/\/t.co\/sk3MkygnsH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/780039441909944320\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/sk3MkygnsH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNBvPrXgAATekl.jpg",
        "id_str" : "780039440383311872",
        "id" : 780039440383311872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNBvPrXgAATekl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 700
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/sk3MkygnsH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780039441909944320",
    "text" : "When you finally try to understand how the gradle build works in Android.. https:\/\/t.co\/sk3MkygnsH",
    "id" : 780039441909944320,
    "created_at" : "2016-09-25 13:41:10 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918078120674058240\/-qudg3y2_normal.jpg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 780148548746682369,
  "created_at" : "2016-09-25 20:54:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "indices" : [ 3, 11 ],
      "id_str" : "18930003",
      "id" : 18930003
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CBT",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148125679824896",
  "text" : "RT @UgoUche: \"Let our advance worrying become advanced thinking and planning.\" -Wintson Churchill #CBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CBT",
        "indices" : [ 85, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780123614767034368",
    "text" : "\"Let our advance worrying become advanced thinking and planning.\" -Wintson Churchill #CBT",
    "id" : 780123614767034368,
    "created_at" : "2016-09-25 19:15:38 +0000",
    "user" : {
      "name" : "Ugo Uche",
      "screen_name" : "UgoUche",
      "protected" : false,
      "id_str" : "18930003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2161257485\/img_0008__427x640___214x320___120x180__normal.jpg",
      "id" : 18930003,
      "verified" : false
    }
  },
  "id" : 780148125679824896,
  "created_at" : "2016-09-25 20:53:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "indices" : [ 3, 18 ],
      "id_str" : "730204715439534080",
      "id" : 730204715439534080
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148087142559744",
  "text" : "RT @LoConservative: Welcome to America, where intellectual discourse is no longer sought. We think we've had enough. It's time to fight bac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LoConservative\/status\/780046471575982081\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/w7z4BNzyNA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNIIIQVYAA6vcu.jpg",
        "id_str" : "780046464957374464",
        "id" : 780046464957374464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNIIIQVYAA6vcu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 525,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 792
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/w7z4BNzyNA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780046471575982081",
    "text" : "Welcome to America, where intellectual discourse is no longer sought. We think we've had enough. It's time to fight back against PC culture. https:\/\/t.co\/w7z4BNzyNA",
    "id" : 780046471575982081,
    "created_at" : "2016-09-25 14:09:06 +0000",
    "user" : {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "protected" : false,
      "id_str" : "730204715439534080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993500235195404290\/u7up0dKu_normal.jpg",
      "id" : 730204715439534080,
      "verified" : false
    }
  },
  "id" : 780148087142559744,
  "created_at" : "2016-09-25 20:52:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148064556318720",
  "text" : "RT @realDonaldTrump: If dopey Mark Cuban of failed Benefactor fame wants to sit in the front row, perhaps I will put Gennifer Flowers right\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779729180334387200",
    "text" : "If dopey Mark Cuban of failed Benefactor fame wants to sit in the front row, perhaps I will put Gennifer Flowers right alongside of him!",
    "id" : 779729180334387200,
    "created_at" : "2016-09-24 17:08:17 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874276197357596672\/kUuht00m_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 780148064556318720,
  "created_at" : "2016-09-25 20:52:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780148038350151680",
  "text" : "RT @TeamMcMullin: \"Our leaders must be committed to equality. If you're not committed to equality, then you're not committed to liberty.\" @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan McMullin",
        "screen_name" : "Evan_McMullin",
        "indices" : [ 120, 134 ],
        "id_str" : "1051396218",
        "id" : 1051396218
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/780078145059762176\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/0q4sIqJgvA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtNk7x0UAAAwv5J.jpg",
        "id_str" : "780078138613039104",
        "id" : 780078138613039104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtNk7x0UAAAwv5J.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/0q4sIqJgvA"
      } ],
      "hashtags" : [ {
        "text" : "TTF",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "780078145059762176",
    "text" : "\"Our leaders must be committed to equality. If you're not committed to equality, then you're not committed to liberty.\" @Evan_McMullin #TTF https:\/\/t.co\/0q4sIqJgvA",
    "id" : 780078145059762176,
    "created_at" : "2016-09-25 16:14:57 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 780148038350151680,
  "created_at" : "2016-09-25 20:52:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780147807428628480",
  "text" : "RT @KassyDillon: But for real. I plan on running for a state gov position in the next 5-10 years. Who is working on my campaign? https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/qlbZesl2mX",
        "expanded_url" : "https:\/\/twitter.com\/co2isfood\/status\/780092154794299393",
        "display_url" : "twitter.com\/co2isfood\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "780092412383399936",
    "text" : "But for real. I plan on running for a state gov position in the next 5-10 years. Who is working on my campaign? https:\/\/t.co\/qlbZesl2mX",
    "id" : 780092412383399936,
    "created_at" : "2016-09-25 17:11:39 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 780147807428628480,
  "created_at" : "2016-09-25 20:51:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 3, 13 ],
      "id_str" : "618294231",
      "id" : 618294231
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "780147646593765380",
  "text" : "RT @_grammar_: @gamer456148, it appears to be the case that you have botched a post and could write \u201Cabs but [then] I end\u201D instead.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/Your_Grammar\" rel=\"nofollow\"\u003Emagical magic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779839037569851393",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 6.725526488036, 177.63376988224 ]
    },
    "id_str" : "779839850635595776",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148, it appears to be the case that you have botched a post and could write \u201Cabs but [then] I end\u201D instead.",
    "id" : 779839850635595776,
    "in_reply_to_status_id" : 779839037569851393,
    "created_at" : "2016-09-25 00:28:03 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "protected" : false,
      "id_str" : "618294231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785169027169521664\/j5rftldn_normal.png",
      "id" : 618294231,
      "verified" : false
    }
  },
  "id" : 780147646593765380,
  "created_at" : "2016-09-25 20:51:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779839037569851393",
  "text" : "I wanna get rock hard abs but than I end up at McDonald's",
  "id" : 779839037569851393,
  "created_at" : "2016-09-25 00:24:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sport",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/a2t947WFcJ",
      "expanded_url" : "http:\/\/es.pn\/2d7xB5U",
      "display_url" : "es.pn\/2d7xB5U"
    } ]
  },
  "geo" : { },
  "id_str" : "779759252273565697",
  "text" : "RT @FXStefan: Packers LB Matthews to miss 1st game since '13: Packers LB Matthews to miss 1st game since '13 https:\/\/t.co\/a2t947WFcJ #sport\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "nfl",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/a2t947WFcJ",
        "expanded_url" : "http:\/\/es.pn\/2d7xB5U",
        "display_url" : "es.pn\/2d7xB5U"
      } ]
    },
    "geo" : { },
    "id_str" : "779759135361372161",
    "text" : "Packers LB Matthews to miss 1st game since '13: Packers LB Matthews to miss 1st game since '13 https:\/\/t.co\/a2t947WFcJ #sport #nfl",
    "id" : 779759135361372161,
    "created_at" : "2016-09-24 19:07:19 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 779759252273565697,
  "created_at" : "2016-09-24 19:07:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 3, 16 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/779758454013517824\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/2dzCimUqL7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJCJ8PUkAEpxA9.jpg",
      "id_str" : "779758424045162497",
      "id" : 779758424045162497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJCJ8PUkAEpxA9.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/2dzCimUqL7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779758981518594048",
  "text" : "RT @TeamMcMullin: Meeting supporters - they made their own shirts! https:\/\/t.co\/2dzCimUqL7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamMcMullin\/status\/779758454013517824\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/2dzCimUqL7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtJCJ8PUkAEpxA9.jpg",
        "id_str" : "779758424045162497",
        "id" : 779758424045162497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtJCJ8PUkAEpxA9.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/2dzCimUqL7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779758454013517824",
    "text" : "Meeting supporters - they made their own shirts! https:\/\/t.co\/2dzCimUqL7",
    "id" : 779758454013517824,
    "created_at" : "2016-09-24 19:04:37 +0000",
    "user" : {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "protected" : false,
      "id_str" : "762792021492895749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762793654381604865\/vtV5Jc4c_normal.jpg",
      "id" : 762792021492895749,
      "verified" : true
    }
  },
  "id" : 779758981518594048,
  "created_at" : "2016-09-24 19:06:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Rumpf",
      "screen_name" : "rumpfshaker",
      "indices" : [ 3, 15 ],
      "id_str" : "23283299",
      "id" : 23283299
    }, {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 50, 63 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "atx",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "StandUpWithEvan",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/vtAQKtSvxm",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BKv-PlNjsJ1\/",
      "display_url" : "instagram.com\/p\/BKv-PlNjsJ1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "779758929605779456",
  "text" : "RT @rumpfshaker: Kicking off our #Texas campaign! @teammcmullin evan.mcmullin  #atx #StandUpWithEvan @ MAX's Wine\u2026 https:\/\/t.co\/vtAQKtSvxm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team McMullin",
        "screen_name" : "TeamMcMullin",
        "indices" : [ 33, 46 ],
        "id_str" : "762792021492895749",
        "id" : 762792021492895749
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "atx",
        "indices" : [ 62, 66 ]
      }, {
        "text" : "StandUpWithEvan",
        "indices" : [ 67, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/vtAQKtSvxm",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BKv-PlNjsJ1\/",
        "display_url" : "instagram.com\/p\/BKv-PlNjsJ1\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 30.264253, -97.741289 ]
    },
    "id_str" : "779756890490306560",
    "text" : "Kicking off our #Texas campaign! @teammcmullin evan.mcmullin  #atx #StandUpWithEvan @ MAX's Wine\u2026 https:\/\/t.co\/vtAQKtSvxm",
    "id" : 779756890490306560,
    "created_at" : "2016-09-24 18:58:24 +0000",
    "user" : {
      "name" : "Sarah Rumpf",
      "screen_name" : "rumpfshaker",
      "protected" : false,
      "id_str" : "23283299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948311220947423232\/EJXSvfCz_normal.jpg",
      "id" : 23283299,
      "verified" : true
    }
  },
  "id" : 779758929605779456,
  "created_at" : "2016-09-24 19:06:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dez",
      "screen_name" : "KOlusolame",
      "indices" : [ 3, 14 ],
      "id_str" : "814989073119117312",
      "id" : 814989073119117312
    }, {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 16, 27 ],
      "id_str" : "9989862",
      "id" : 9989862
    }, {
      "name" : "Captain Disillusion",
      "screen_name" : "CDisillusion",
      "indices" : [ 28, 41 ],
      "id_str" : "50084102",
      "id" : 50084102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779758779453890560",
  "text" : "RT @KOlusolame: @jacksfilms @CDisillusion okay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jacksfilms",
        "screen_name" : "jacksfilms",
        "indices" : [ 0, 11 ],
        "id_str" : "9989862",
        "id" : 9989862
      }, {
        "name" : "Captain Disillusion",
        "screen_name" : "CDisillusion",
        "indices" : [ 12, 25 ],
        "id_str" : "50084102",
        "id" : 50084102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779756270853120001",
    "geo" : { },
    "id_str" : "779756311542009857",
    "in_reply_to_user_id" : 9989862,
    "text" : "@jacksfilms @CDisillusion okay",
    "id" : 779756311542009857,
    "in_reply_to_status_id" : 779756270853120001,
    "created_at" : "2016-09-24 18:56:06 +0000",
    "in_reply_to_screen_name" : "jacksfilms",
    "in_reply_to_user_id_str" : "9989862",
    "user" : {
      "name" : "dez \u1D55\u0308",
      "screen_name" : "pepiIIon",
      "protected" : false,
      "id_str" : "3793628655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992920885056110594\/j-B61PP3_normal.jpg",
      "id" : 3793628655,
      "verified" : false
    }
  },
  "id" : 779758779453890560,
  "created_at" : "2016-09-24 19:05:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/pF3kHVbyMH",
      "expanded_url" : "http:\/\/gamezup.com\/fb-img-link\/share.php?fburl=207&edit=0&userid=1",
      "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779758721849253889",
  "text" : "RT @BestGamezUp: 10 Important First Times That Changed Gaming Forever https:\/\/t.co\/pF3kHVbyMH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/pF3kHVbyMH",
        "expanded_url" : "http:\/\/gamezup.com\/fb-img-link\/share.php?fburl=207&edit=0&userid=1",
        "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779756146433355781",
    "text" : "10 Important First Times That Changed Gaming Forever https:\/\/t.co\/pF3kHVbyMH",
    "id" : 779756146433355781,
    "created_at" : "2016-09-24 18:55:27 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 779758721849253889,
  "created_at" : "2016-09-24 19:05:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779758681403555841",
  "text" : "RT @BarbaraCorcoran: My most successful entrepreneurs all started their new businesses the very same way:  by keeping a full-time job and w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779756122752319493",
    "text" : "My most successful entrepreneurs all started their new businesses the very same way:  by keeping a full-time job and working on the side.",
    "id" : 779756122752319493,
    "created_at" : "2016-09-24 18:55:21 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 779758681403555841,
  "created_at" : "2016-09-24 19:05:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bye colonizer",
      "screen_name" : "TallGlassofStyL",
      "indices" : [ 0, 16 ],
      "id_str" : "3207680283",
      "id" : 3207680283
    }, {
      "name" : "\uD83C\uDDFF\uD83C\uDDF2",
      "screen_name" : "tizaanyimbili",
      "indices" : [ 17, 31 ],
      "id_str" : "465639089",
      "id" : 465639089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779436465885483008",
  "geo" : { },
  "id_str" : "779758586725556224",
  "in_reply_to_user_id" : 3207680283,
  "text" : "@TallGlassofStyL @tizaanyimbili Whoah, what does that mean?",
  "id" : 779758586725556224,
  "in_reply_to_status_id" : 779436465885483008,
  "created_at" : "2016-09-24 19:05:08 +0000",
  "in_reply_to_screen_name" : "TallGlassofStyL",
  "in_reply_to_user_id_str" : "3207680283",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779758195694796800",
  "text" : "I may have BJS, bad joke syndrome",
  "id" : 779758195694796800,
  "created_at" : "2016-09-24 19:03:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779758125134016512",
  "text" : "Someone said I was nice, obviously they were misinformed!!! \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02",
  "id" : 779758125134016512,
  "created_at" : "2016-09-24 19:03:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animal Vids \uD83D\uDC36",
      "screen_name" : "BBAnimaIVids",
      "indices" : [ 3, 16 ],
      "id_str" : "3827942476",
      "id" : 3827942476
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BBAnimaIVids\/status\/779166146859716608\/video\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/wxr4iA2p5t",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779165908392669184\/pu\/img\/Jkdke3dMj42kZbEf.jpg",
      "id_str" : "779165908392669184",
      "id" : 779165908392669184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779165908392669184\/pu\/img\/Jkdke3dMj42kZbEf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/wxr4iA2p5t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779754291947008000",
  "text" : "RT @BBAnimaIVids: Puppies meeting with other animals for the first time https:\/\/t.co\/wxr4iA2p5t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBAnimaIVids\/status\/779166146859716608\/video\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/wxr4iA2p5t",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779165908392669184\/pu\/img\/Jkdke3dMj42kZbEf.jpg",
        "id_str" : "779165908392669184",
        "id" : 779165908392669184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779165908392669184\/pu\/img\/Jkdke3dMj42kZbEf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/wxr4iA2p5t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779166146859716608",
    "text" : "Puppies meeting with other animals for the first time https:\/\/t.co\/wxr4iA2p5t",
    "id" : 779166146859716608,
    "created_at" : "2016-09-23 03:51:00 +0000",
    "user" : {
      "name" : "Baby Animal Vids \uD83D\uDC36",
      "screen_name" : "BBAnimaIVids",
      "protected" : false,
      "id_str" : "3827942476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364985315893248\/uxX3AcLU_normal.jpg",
      "id" : 3827942476,
      "verified" : false
    }
  },
  "id" : 779754291947008000,
  "created_at" : "2016-09-24 18:48:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Oliveira",
      "screen_name" : "meakoopa",
      "indices" : [ 3, 12 ],
      "id_str" : "130051975",
      "id" : 130051975
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/meakoopa\/status\/778993526818410496\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/XXmuHfTIoA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-KeaaXEAAw8-t.jpg",
      "id_str" : "778993515648978944",
      "id" : 778993515648978944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-KeaaXEAAw8-t.jpg",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/XXmuHfTIoA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779754246333931520",
  "text" : "RT @meakoopa: did...did he make the sign? https:\/\/t.co\/XXmuHfTIoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/meakoopa\/status\/778993526818410496\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/XXmuHfTIoA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-KeaaXEAAw8-t.jpg",
        "id_str" : "778993515648978944",
        "id" : 778993515648978944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-KeaaXEAAw8-t.jpg",
        "sizes" : [ {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/XXmuHfTIoA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778993526818410496",
    "text" : "did...did he make the sign? https:\/\/t.co\/XXmuHfTIoA",
    "id" : 778993526818410496,
    "created_at" : "2016-09-22 16:25:04 +0000",
    "user" : {
      "name" : "Anthony Oliveira",
      "screen_name" : "meakoopa",
      "protected" : false,
      "id_str" : "130051975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/966919162726461440\/jodIJpQ4_normal.jpg",
      "id" : 130051975,
      "verified" : false
    }
  },
  "id" : 779754246333931520,
  "created_at" : "2016-09-24 18:47:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/XBpNDXIYOd",
      "expanded_url" : "https:\/\/twitter.com\/corgsbot\/status\/779455317633593348",
      "display_url" : "twitter.com\/corgsbot\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779754221155577856",
  "text" : "RT @tinaisdoingokay: Pizza party https:\/\/t.co\/XBpNDXIYOd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/XBpNDXIYOd",
        "expanded_url" : "https:\/\/twitter.com\/corgsbot\/status\/779455317633593348",
        "display_url" : "twitter.com\/corgsbot\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779458228723781632",
    "text" : "Pizza party https:\/\/t.co\/XBpNDXIYOd",
    "id" : 779458228723781632,
    "created_at" : "2016-09-23 23:11:38 +0000",
    "user" : {
      "name" : "tnttina",
      "screen_name" : "tina_jaimes",
      "protected" : false,
      "id_str" : "350376847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983670874770460672\/TvpF0sY2_normal.jpg",
      "id" : 350376847,
      "verified" : false
    }
  },
  "id" : 779754221155577856,
  "created_at" : "2016-09-24 18:47:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joselit\u1DA0\u1DB8\u1D9C\u1D4F\u1D67\u2092\u1D64",
      "screen_name" : "JuniorSoButtery",
      "indices" : [ 17, 33 ],
      "id_str" : "1173785112",
      "id" : 1173785112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779739467158519808",
  "geo" : { },
  "id_str" : "779753995443339264",
  "in_reply_to_user_id" : 350376847,
  "text" : "@tinaisdoingokay @JuniorSoButtery If only I was allowed pets \uD83D\uDE22\uD83D\uDE22\uD83D\uDE22\uD83D\uDE22",
  "id" : 779753995443339264,
  "in_reply_to_status_id" : 779739467158519808,
  "created_at" : "2016-09-24 18:46:54 +0000",
  "in_reply_to_screen_name" : "tina_jaimes",
  "in_reply_to_user_id_str" : "350376847",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Himself the ExSavage",
      "screen_name" : "FuckYouBanks",
      "indices" : [ 3, 16 ],
      "id_str" : "90253087",
      "id" : 90253087
    }, {
      "name" : "NY Daily News Video",
      "screen_name" : "NYDNVideo",
      "indices" : [ 18, 28 ],
      "id_str" : "299895977",
      "id" : 299895977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779753779801497600",
  "text" : "RT @FuckYouBanks: @NYDNVideo \"Listen to the office and don't point your Power Ranger Megazord blaster at police.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NY Daily News Video",
        "screen_name" : "NYDNVideo",
        "indices" : [ 0, 10 ],
        "id_str" : "299895977",
        "id" : 299895977
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779427906682511361",
    "geo" : { },
    "id_str" : "779710845559328768",
    "in_reply_to_user_id" : 299895977,
    "text" : "@NYDNVideo \"Listen to the office and don't point your Power Ranger Megazord blaster at police.\"",
    "id" : 779710845559328768,
    "in_reply_to_status_id" : 779427906682511361,
    "created_at" : "2016-09-24 15:55:26 +0000",
    "in_reply_to_screen_name" : "NYDNVideo",
    "in_reply_to_user_id_str" : "299895977",
    "user" : {
      "name" : "Himself the ExSavage",
      "screen_name" : "FuckYouBanks",
      "protected" : false,
      "id_str" : "90253087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992550405061201920\/3eshay_a_normal.jpg",
      "id" : 90253087,
      "verified" : false
    }
  },
  "id" : 779753779801497600,
  "created_at" : "2016-09-24 18:46:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779736353353367553",
  "geo" : { },
  "id_str" : "779753484996513792",
  "in_reply_to_user_id" : 153832325,
  "text" : "@supagirlx That's not a tough standard to beat, lol",
  "id" : 779753484996513792,
  "in_reply_to_status_id" : 779736353353367553,
  "created_at" : "2016-09-24 18:44:52 +0000",
  "in_reply_to_screen_name" : "ecmorrison_",
  "in_reply_to_user_id_str" : "153832325",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/0SKljxomMG",
      "expanded_url" : "http:\/\/ow.ly\/61Qv304jQ6C",
      "display_url" : "ow.ly\/61Qv304jQ6C"
    } ]
  },
  "geo" : { },
  "id_str" : "779753234151927808",
  "text" : "RT @analyticbridge: Crime Analysis with Zeppelin, R &amp;amp; Spark https:\/\/t.co\/0SKljxomMG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/0SKljxomMG",
        "expanded_url" : "http:\/\/ow.ly\/61Qv304jQ6C",
        "display_url" : "ow.ly\/61Qv304jQ6C"
      } ]
    },
    "geo" : { },
    "id_str" : "779734926140768257",
    "text" : "Crime Analysis with Zeppelin, R &amp;amp; Spark https:\/\/t.co\/0SKljxomMG",
    "id" : 779734926140768257,
    "created_at" : "2016-09-24 17:31:07 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779753234151927808,
  "created_at" : "2016-09-24 18:43:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "indices" : [ 3, 15 ],
      "id_str" : "15231287",
      "id" : 15231287
    }, {
      "name" : "Robert H\u00E9tu",
      "screen_name" : "Bob_Hetu",
      "indices" : [ 44, 53 ],
      "id_str" : "33348029",
      "id" : 33348029
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blog",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/keBSXXZvii",
      "expanded_url" : "http:\/\/gtnr.it\/2dmkpyo",
      "display_url" : "gtnr.it\/2dmkpyo"
    } ]
  },
  "geo" : { },
  "id_str" : "779753215818629121",
  "text" : "RT @Gartner_inc: Gartner #Blog highlight by @Bob_Hetu, Using Algorithmic Retailing to Drive Competitive Advantage.\u00A0 https:\/\/t.co\/keBSXXZvii",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.engage121.com\" rel=\"nofollow\"\u003Eengage121\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert H\u00E9tu",
        "screen_name" : "Bob_Hetu",
        "indices" : [ 27, 36 ],
        "id_str" : "33348029",
        "id" : 33348029
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blog",
        "indices" : [ 8, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/keBSXXZvii",
        "expanded_url" : "http:\/\/gtnr.it\/2dmkpyo",
        "display_url" : "gtnr.it\/2dmkpyo"
      } ]
    },
    "geo" : { },
    "id_str" : "779732638399594496",
    "text" : "Gartner #Blog highlight by @Bob_Hetu, Using Algorithmic Retailing to Drive Competitive Advantage.\u00A0 https:\/\/t.co\/keBSXXZvii",
    "id" : 779732638399594496,
    "created_at" : "2016-09-24 17:22:02 +0000",
    "user" : {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "protected" : false,
      "id_str" : "15231287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479292472707649536\/HfChXWQy_normal.png",
      "id" : 15231287,
      "verified" : true
    }
  },
  "id" : 779753215818629121,
  "created_at" : "2016-09-24 18:43:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "indices" : [ 3, 19 ],
      "id_str" : "14550939",
      "id" : 14550939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Love",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "RT",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/yiN8dplVDl",
      "expanded_url" : "http:\/\/huff.to\/2dpDzAD",
      "display_url" : "huff.to\/2dpDzAD"
    } ]
  },
  "geo" : { },
  "id_str" : "779753019919466496",
  "text" : "RT @lawrence_author: These Joyful Former Lab Chimps Just Can't Get Enough Watermelon https:\/\/t.co\/yiN8dplVDl #Love #RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Love",
        "indices" : [ 88, 93 ]
      }, {
        "text" : "RT",
        "indices" : [ 94, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/yiN8dplVDl",
        "expanded_url" : "http:\/\/huff.to\/2dpDzAD",
        "display_url" : "huff.to\/2dpDzAD"
      } ]
    },
    "geo" : { },
    "id_str" : "779729640302583808",
    "text" : "These Joyful Former Lab Chimps Just Can't Get Enough Watermelon https:\/\/t.co\/yiN8dplVDl #Love #RT",
    "id" : 779729640302583808,
    "created_at" : "2016-09-24 17:10:07 +0000",
    "user" : {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "protected" : false,
      "id_str" : "14550939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878189064393863168\/0QsTPIPw_normal.jpg",
      "id" : 14550939,
      "verified" : false
    }
  },
  "id" : 779753019919466496,
  "created_at" : "2016-09-24 18:43:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peyton Finch",
      "screen_name" : "ItsMeWesP_11",
      "indices" : [ 3, 16 ],
      "id_str" : "359492713",
      "id" : 359492713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779752989917601792",
  "text" : "RT @ItsMeWesP_11: Wow... that's gonna be on sportscenter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779727794796277760",
    "text" : "Wow... that's gonna be on sportscenter",
    "id" : 779727794796277760,
    "created_at" : "2016-09-24 17:02:47 +0000",
    "user" : {
      "name" : "Peyton Finch",
      "screen_name" : "ItsMeWesP_11",
      "protected" : false,
      "id_str" : "359492713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808921478041370624\/9kxI4HFp_normal.jpg",
      "id" : 359492713,
      "verified" : false
    }
  },
  "id" : 779752989917601792,
  "created_at" : "2016-09-24 18:42:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/8REqTgYC8R",
      "expanded_url" : "http:\/\/ow.ly\/oLcP304jQ6B",
      "display_url" : "ow.ly\/oLcP304jQ6B"
    } ]
  },
  "geo" : { },
  "id_str" : "779752968891592704",
  "text" : "RT @analyticbridge: 7 Tech Skills That Could Make Or Break Your Career https:\/\/t.co\/8REqTgYC8R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/8REqTgYC8R",
        "expanded_url" : "http:\/\/ow.ly\/oLcP304jQ6B",
        "display_url" : "ow.ly\/oLcP304jQ6B"
      } ]
    },
    "geo" : { },
    "id_str" : "779727643528888320",
    "text" : "7 Tech Skills That Could Make Or Break Your Career https:\/\/t.co\/8REqTgYC8R",
    "id" : 779727643528888320,
    "created_at" : "2016-09-24 17:02:11 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779752968891592704,
  "created_at" : "2016-09-24 18:42:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PS_Beyond\/status\/410208163544039424\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/OIZt5VUZbc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFaJsBCAAAP2d9.jpg",
      "id_str" : "410208163548233728",
      "id" : 410208163548233728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFaJsBCAAAP2d9.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/OIZt5VUZbc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779752931310592001",
  "text" : "RT @BestGamezUp: Looks like we won't have much time to enjoy Half-Life 3 https:\/\/t.co\/OIZt5VUZbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PS_Beyond\/status\/410208163544039424\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/OIZt5VUZbc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFaJsBCAAAP2d9.jpg",
        "id_str" : "410208163548233728",
        "id" : 410208163548233728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFaJsBCAAAP2d9.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/OIZt5VUZbc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779752395727331330",
    "text" : "Looks like we won't have much time to enjoy Half-Life 3 https:\/\/t.co\/OIZt5VUZbc",
    "id" : 779752395727331330,
    "created_at" : "2016-09-24 18:40:32 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 779752931310592001,
  "created_at" : "2016-09-24 18:42:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsSometimesOU",
      "indices" : [ 27, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779752837253300224",
  "text" : "I love meeting nice people #ThisIsSometimesOU",
  "id" : 779752837253300224,
  "created_at" : "2016-09-24 18:42:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779727567637086208\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/O05aZWnQ4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtImD_VWIAAzl0O.jpg",
      "id_str" : "779727535470944256",
      "id" : 779727535470944256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtImD_VWIAAzl0O.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/O05aZWnQ4A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779727567637086208",
  "text" : "I don't understand this art piece https:\/\/t.co\/O05aZWnQ4A",
  "id" : 779727567637086208,
  "created_at" : "2016-09-24 17:01:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexanderoony",
      "screen_name" : "Alexanderoony",
      "indices" : [ 3, 17 ],
      "id_str" : "4804365321",
      "id" : 4804365321
    }, {
      "name" : "DeviantArt",
      "screen_name" : "DeviantArt",
      "indices" : [ 62, 73 ],
      "id_str" : "1239671",
      "id" : 1239671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qodvt9F1Un",
      "expanded_url" : "http:\/\/alexandertron.deviantart.com\/art\/Dean-Wink-and-Tongue-635845942",
      "display_url" : "alexandertron.deviantart.com\/art\/Dean-Wink-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779727569793015808",
  "text" : "RT @Alexanderoony: Dean, Wink and Tongue! by Alexandertron on @DeviantArt\nhttps:\/\/t.co\/qodvt9F1Un",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DeviantArt",
        "screen_name" : "DeviantArt",
        "indices" : [ 43, 54 ],
        "id_str" : "1239671",
        "id" : 1239671
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/qodvt9F1Un",
        "expanded_url" : "http:\/\/alexandertron.deviantart.com\/art\/Dean-Wink-and-Tongue-635845942",
        "display_url" : "alexandertron.deviantart.com\/art\/Dean-Wink-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779404624725938176",
    "text" : "Dean, Wink and Tongue! by Alexandertron on @DeviantArt\nhttps:\/\/t.co\/qodvt9F1Un",
    "id" : 779404624725938176,
    "created_at" : "2016-09-23 19:38:37 +0000",
    "user" : {
      "name" : "Alexanderoony",
      "screen_name" : "Alexanderoony",
      "protected" : false,
      "id_str" : "4804365321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/970740805899116544\/BLrWeWCo_normal.jpg",
      "id" : 4804365321,
      "verified" : false
    }
  },
  "id" : 779727569793015808,
  "created_at" : "2016-09-24 17:01:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779725923146924032",
  "text" : "RT @FXStefan: Fu\u00DFballbundesliga: HSV verliert ungl\u00FCcklich gegen die Bayern: Das ist bitter f\u00FCr HSV-Trainer Bruno Labb... https:\/\/t.co\/LV3N2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "news",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/LV3N2Z1ZzF",
        "expanded_url" : "http:\/\/bit.ly\/2cZj2EG",
        "display_url" : "bit.ly\/2cZj2EG"
      } ]
    },
    "geo" : { },
    "id_str" : "779723350390124548",
    "text" : "Fu\u00DFballbundesliga: HSV verliert ungl\u00FCcklich gegen die Bayern: Das ist bitter f\u00FCr HSV-Trainer Bruno Labb... https:\/\/t.co\/LV3N2Z1ZzF #news",
    "id" : 779723350390124548,
    "created_at" : "2016-09-24 16:45:07 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 779725923146924032,
  "created_at" : "2016-09-24 16:55:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lilfacetatt",
      "screen_name" : "lilfacetatt",
      "indices" : [ 0, 12 ],
      "id_str" : "935268302221336576",
      "id" : 935268302221336576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778760970717962240",
  "geo" : { },
  "id_str" : "779725898874511360",
  "in_reply_to_user_id" : 26300328,
  "text" : "@lilfacetatt @FUCCIDEMONICAN bad day?",
  "id" : 779725898874511360,
  "in_reply_to_status_id" : 778760970717962240,
  "created_at" : "2016-09-24 16:55:15 +0000",
  "in_reply_to_screen_name" : "ASHL3YALLDAY",
  "in_reply_to_user_id_str" : "26300328",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779725759057367040\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/n0cp4fq59z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIkblsWIAETyik.jpg",
      "id_str" : "779725741881696257",
      "id" : 779725741881696257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIkblsWIAETyik.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/n0cp4fq59z"
    } ],
    "hashtags" : [ {
      "text" : "OC",
      "indices" : [ 18, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779725759057367040",
  "text" : "Now I went to the #OC to wait for my bud bud, lol https:\/\/t.co\/n0cp4fq59z",
  "id" : 779725759057367040,
  "created_at" : "2016-09-24 16:54:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sport",
      "indices" : [ 103, 109 ]
    }, {
      "text" : "nfl",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/tYQA2NP2GQ",
      "expanded_url" : "http:\/\/es.pn\/2deegF6",
      "display_url" : "es.pn\/2deegF6"
    } ]
  },
  "geo" : { },
  "id_str" : "779717069579415552",
  "text" : "RT @FXStefan: Chris Berman's Week 3 NFL picks: Chris Berman's Week 3 NFL picks https:\/\/t.co\/tYQA2NP2GQ #sport #nfl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "nfl",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/tYQA2NP2GQ",
        "expanded_url" : "http:\/\/es.pn\/2deegF6",
        "display_url" : "es.pn\/2deegF6"
      } ]
    },
    "geo" : { },
    "id_str" : "779712286449471488",
    "text" : "Chris Berman's Week 3 NFL picks: Chris Berman's Week 3 NFL picks https:\/\/t.co\/tYQA2NP2GQ #sport #nfl",
    "id" : 779712286449471488,
    "created_at" : "2016-09-24 16:01:10 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 779717069579415552,
  "created_at" : "2016-09-24 16:20:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sport",
      "indices" : [ 129, 135 ]
    }, {
      "text" : "nfl",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/sluZvzf3Hr",
      "expanded_url" : "http:\/\/es.pn\/2cQlv3H",
      "display_url" : "es.pn\/2cQlv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "779717048758833152",
  "text" : "RT @FXStefan: Browns sign Parkey to replace injured Murray: Browns sign Parkey to replace injured Murray https:\/\/t.co\/sluZvzf3Hr #sport #nfl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 115, 121 ]
      }, {
        "text" : "nfl",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/sluZvzf3Hr",
        "expanded_url" : "http:\/\/es.pn\/2cQlv3H",
        "display_url" : "es.pn\/2cQlv3H"
      } ]
    },
    "geo" : { },
    "id_str" : "779712285048606723",
    "text" : "Browns sign Parkey to replace injured Murray: Browns sign Parkey to replace injured Murray https:\/\/t.co\/sluZvzf3Hr #sport #nfl",
    "id" : 779712285048606723,
    "created_at" : "2016-09-24 16:01:09 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 779717048758833152,
  "created_at" : "2016-09-24 16:20:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779717040219230208\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/emtu2LOUgp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIcfRZWcAAS9PJ.jpg",
      "id_str" : "779717009059770368",
      "id" : 779717009059770368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIcfRZWcAAS9PJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/emtu2LOUgp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779717040219230208",
  "text" : "That moment you make a girl laugh a few times than run out of things to say so you awkwardly walk away https:\/\/t.co\/emtu2LOUgp",
  "id" : 779717040219230208,
  "created_at" : "2016-09-24 16:20:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779712449754832896",
  "text" : "RT @BarbaraCorcoran: The second a new idea pops into my head, I immediately move on it. Start that fire and get it burning immediately, it\u2019\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779664288206229505",
    "text" : "The second a new idea pops into my head, I immediately move on it. Start that fire and get it burning immediately, it\u2019s everything!",
    "id" : 779664288206229505,
    "created_at" : "2016-09-24 12:50:26 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 779712449754832896,
  "created_at" : "2016-09-24 16:01:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779712412069064712\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/fiKc4Iukp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYR0RW8AUX1NN.jpg",
      "id_str" : "779712379856809989",
      "id" : 779712379856809989,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYR0RW8AUX1NN.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fiKc4Iukp5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779712412069064712\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/fiKc4Iukp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYR0RWcAA67ze.jpg",
      "id_str" : "779712379856777216",
      "id" : 779712379856777216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYR0RWcAA67ze.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fiKc4Iukp5"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/779712412069064712\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/fiKc4Iukp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtIYR0fXgAAqEaN.jpg",
      "id_str" : "779712379915567104",
      "id" : 779712379915567104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtIYR0fXgAAqEaN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fiKc4Iukp5"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779712412069064712",
  "text" : "OU's tailgate party is lit #ThisIsOU https:\/\/t.co\/fiKc4Iukp5",
  "id" : 779712412069064712,
  "created_at" : "2016-09-24 16:01:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779529114415955969",
  "geo" : { },
  "id_str" : "779535091135606784",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo \uD83E\uDD14\uD83D\uDE0D\uD83D\uDE0D\uD83E\uDD12 Emoticons say it all",
  "id" : 779535091135606784,
  "in_reply_to_status_id" : 779529114415955969,
  "created_at" : "2016-09-24 04:17:03 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 3, 8 ],
      "id_str" : "2557521",
      "id" : 2557521
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/espn\/status\/779533317079269376\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Pu8CFXos3o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFp1EoWgAAT--e.jpg",
      "id_str" : "779520571008778240",
      "id" : 779520571008778240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFp1EoWgAAT--e.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Pu8CFXos3o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779534745726283776",
  "text" : "RT @espn: The NBA won't be the same without these three legends this season. https:\/\/t.co\/Pu8CFXos3o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dashboard.twitter.com\" rel=\"nofollow\"\u003ETwitter Business Experience\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/espn\/status\/779533317079269376\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Pu8CFXos3o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFp1EoWgAAT--e.jpg",
        "id_str" : "779520571008778240",
        "id" : 779520571008778240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFp1EoWgAAT--e.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Pu8CFXos3o"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779533317079269376",
    "text" : "The NBA won't be the same without these three legends this season. https:\/\/t.co\/Pu8CFXos3o",
    "id" : 779533317079269376,
    "created_at" : "2016-09-24 04:10:00 +0000",
    "user" : {
      "name" : "ESPN",
      "screen_name" : "espn",
      "protected" : false,
      "id_str" : "2557521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/984280988699234304\/VYthX7o1_normal.jpg",
      "id" : 2557521,
      "verified" : true
    }
  },
  "id" : 779534745726283776,
  "created_at" : "2016-09-24 04:15:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779534671751286784",
  "text" : "RT @Shamsul1738RM: @sandmanone69 \uD83D\uDE02haha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779337660112437252",
    "geo" : { },
    "id_str" : "779416366516494336",
    "in_reply_to_user_id" : 4832379451,
    "text" : "@sandmanone69 \uD83D\uDE02haha",
    "id" : 779416366516494336,
    "in_reply_to_status_id" : 779337660112437252,
    "created_at" : "2016-09-23 20:25:17 +0000",
    "in_reply_to_screen_name" : "ShredMonkey_",
    "in_reply_to_user_id_str" : "4832379451",
    "user" : {
      "name" : "Sam",
      "screen_name" : "shamsul1738",
      "protected" : false,
      "id_str" : "723990534822498304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979694606953705472\/21ffaMdd_normal.jpg",
      "id" : 723990534822498304,
      "verified" : false
    }
  },
  "id" : 779534671751286784,
  "created_at" : "2016-09-24 04:15:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1EVBFdxrKM",
      "expanded_url" : "http:\/\/ow.ly\/FIIw304jQ6b",
      "display_url" : "ow.ly\/FIIw304jQ6b"
    } ]
  },
  "geo" : { },
  "id_str" : "779534516134248448",
  "text" : "RT @analyticbridge: Creating a Graph Application with Python, Neo4j, Gephi and Linkurious.js https:\/\/t.co\/1EVBFdxrKM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/1EVBFdxrKM",
        "expanded_url" : "http:\/\/ow.ly\/FIIw304jQ6b",
        "display_url" : "ow.ly\/FIIw304jQ6b"
      } ]
    },
    "geo" : { },
    "id_str" : "779531024661372928",
    "text" : "Creating a Graph Application with Python, Neo4j, Gephi and Linkurious.js https:\/\/t.co\/1EVBFdxrKM",
    "id" : 779531024661372928,
    "created_at" : "2016-09-24 04:00:53 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779534516134248448,
  "created_at" : "2016-09-24 04:14:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779534357639860224",
  "text" : "Failed at dieting today \uD83D\uDE14",
  "id" : 779534357639860224,
  "created_at" : "2016-09-24 04:14:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779523415774404608",
  "geo" : { },
  "id_str" : "779523824236847104",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget Wow \uD83E\uDD11\uD83D\uDE03",
  "id" : 779523824236847104,
  "in_reply_to_status_id" : 779523415774404608,
  "created_at" : "2016-09-24 03:32:17 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/n8EQcLtAH9",
      "expanded_url" : "http:\/\/engt.co\/2cJpEUS",
      "display_url" : "engt.co\/2cJpEUS"
    } ]
  },
  "geo" : { },
  "id_str" : "779523713012264960",
  "text" : "RT @engadget: Nikon's KeyMission 360 VR action camera has surprisingly good software stitching https:\/\/t.co\/n8EQcLtAH9 https:\/\/t.co\/TEN8tKb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779523415774404608\/video\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/TEN8tKbzmd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFsaNdVYAIO3DX.jpg",
        "id_str" : "779523293409710080",
        "id" : 779523293409710080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFsaNdVYAIO3DX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/TEN8tKbzmd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/n8EQcLtAH9",
        "expanded_url" : "http:\/\/engt.co\/2cJpEUS",
        "display_url" : "engt.co\/2cJpEUS"
      } ]
    },
    "geo" : { },
    "id_str" : "779523415774404608",
    "text" : "Nikon's KeyMission 360 VR action camera has surprisingly good software stitching https:\/\/t.co\/n8EQcLtAH9 https:\/\/t.co\/TEN8tKbzmd",
    "id" : 779523415774404608,
    "created_at" : "2016-09-24 03:30:39 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779523713012264960,
  "created_at" : "2016-09-24 03:31:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/40wncJi8dH",
      "expanded_url" : "http:\/\/ow.ly\/TuMl304jQ6a",
      "display_url" : "ow.ly\/TuMl304jQ6a"
    } ]
  },
  "geo" : { },
  "id_str" : "779523693357764609",
  "text" : "RT @analyticbridge: Freelance\/independent consulting career in Data Science https:\/\/t.co\/40wncJi8dH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/40wncJi8dH",
        "expanded_url" : "http:\/\/ow.ly\/TuMl304jQ6a",
        "display_url" : "ow.ly\/TuMl304jQ6a"
      } ]
    },
    "geo" : { },
    "id_str" : "779523396468109312",
    "text" : "Freelance\/independent consulting career in Data Science https:\/\/t.co\/40wncJi8dH",
    "id" : 779523396468109312,
    "created_at" : "2016-09-24 03:30:35 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779523693357764609,
  "created_at" : "2016-09-24 03:31:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/6Q8tRpwmfg",
      "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=106&edit=0&userid=1",
      "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779523587174727680",
  "text" : "RT @BestGamezUp: How Video Game Developer Have Trolled Pirates Over The Years https:\/\/t.co\/6Q8tRpwmfg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/6Q8tRpwmfg",
        "expanded_url" : "http:\/\/www.gamezup.com\/fb-img-link\/share.php?fburl=106&edit=0&userid=1",
        "display_url" : "gamezup.com\/fb-img-link\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779522235224690688",
    "text" : "How Video Game Developer Have Trolled Pirates Over The Years https:\/\/t.co\/6Q8tRpwmfg",
    "id" : 779522235224690688,
    "created_at" : "2016-09-24 03:25:58 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 779523587174727680,
  "created_at" : "2016-09-24 03:31:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael\u2122 \uD83D\uDD1C",
      "screen_name" : "Thunderclap",
      "indices" : [ 3, 15 ],
      "id_str" : "5799722",
      "id" : 5799722
    }, {
      "name" : "Jeff Dwoskin - Hashtag Roundup",
      "screen_name" : "bigmacher",
      "indices" : [ 17, 27 ],
      "id_str" : "8522892",
      "id" : 8522892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779523385973878786",
  "text" : "RT @Thunderclap: @bigmacher disagree. Its awesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Dwoskin - Hashtag Roundup",
        "screen_name" : "bigmacher",
        "indices" : [ 0, 10 ],
        "id_str" : "8522892",
        "id" : 8522892
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779471471584227328",
    "geo" : { },
    "id_str" : "779519732030529537",
    "in_reply_to_user_id" : 8522892,
    "text" : "@bigmacher disagree. Its awesome",
    "id" : 779519732030529537,
    "in_reply_to_status_id" : 779471471584227328,
    "created_at" : "2016-09-24 03:16:01 +0000",
    "in_reply_to_screen_name" : "bigmacher",
    "in_reply_to_user_id_str" : "8522892",
    "user" : {
      "name" : "Michael\u2122 \uD83D\uDD1C",
      "screen_name" : "Thunderclap",
      "protected" : false,
      "id_str" : "5799722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/953191261837565952\/rVysP5lD_normal.jpg",
      "id" : 5799722,
      "verified" : false
    }
  },
  "id" : 779523385973878786,
  "created_at" : "2016-09-24 03:30:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Regina Spacola",
      "screen_name" : "gigirules7",
      "indices" : [ 3, 14 ],
      "id_str" : "2979171304",
      "id" : 2979171304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gigirules7\/status\/779479031146242048\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/xITUkHs6gq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFD73qWAAATvFC.jpg",
      "id_str" : "779478906344701952",
      "id" : 779478906344701952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFD73qWAAATvFC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 570
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/xITUkHs6gq"
    } ],
    "hashtags" : [ {
      "text" : "NotGreatProducts",
      "indices" : [ 16, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779523196601131009",
  "text" : "RT @gigirules7: #NotGreatProducts Pickle flavored tooth paste https:\/\/t.co\/xITUkHs6gq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gigirules7\/status\/779479031146242048\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/xITUkHs6gq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFD73qWAAATvFC.jpg",
        "id_str" : "779478906344701952",
        "id" : 779478906344701952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFD73qWAAATvFC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 570
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/xITUkHs6gq"
      } ],
      "hashtags" : [ {
        "text" : "NotGreatProducts",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779479031146242048",
    "text" : "#NotGreatProducts Pickle flavored tooth paste https:\/\/t.co\/xITUkHs6gq",
    "id" : 779479031146242048,
    "created_at" : "2016-09-24 00:34:17 +0000",
    "user" : {
      "name" : "Regina Spacola",
      "screen_name" : "gigirules7",
      "protected" : false,
      "id_str" : "2979171304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/985226443696177152\/MhuMrx6Z_normal.jpg",
      "id" : 2979171304,
      "verified" : false
    }
  },
  "id" : 779523196601131009,
  "created_at" : "2016-09-24 03:29:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stargazer",
      "screen_name" : "OwensTweetie",
      "indices" : [ 3, 16 ],
      "id_str" : "3307524787",
      "id" : 3307524787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NotGreatProducts",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779523018431275009",
  "text" : "RT @OwensTweetie: #NotGreatProducts\nSkittle flavored hand sanitizer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NotGreatProducts",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779514980731236352",
    "text" : "#NotGreatProducts\nSkittle flavored hand sanitizer",
    "id" : 779514980731236352,
    "created_at" : "2016-09-24 02:57:08 +0000",
    "user" : {
      "name" : "Stargazer",
      "screen_name" : "OwensTweetie",
      "protected" : false,
      "id_str" : "3307524787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/814697100248170496\/ByX_k5x8_normal.jpg",
      "id" : 3307524787,
      "verified" : false
    }
  },
  "id" : 779523018431275009,
  "created_at" : "2016-09-24 03:29:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb",
      "screen_name" : "WhoIsThisCaleb",
      "indices" : [ 3, 18 ],
      "id_str" : "3195855170",
      "id" : 3195855170
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhoIsThisCaleb\/status\/779490499845459968\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/fwFpdJSy2p",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFOeRHVYAAygeE.jpg",
      "id_str" : "779490492409012224",
      "id" : 779490492409012224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFOeRHVYAAygeE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 250
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fwFpdJSy2p"
    } ],
    "hashtags" : [ {
      "text" : "NotGreatProducts",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779522992573452288",
  "text" : "RT @WhoIsThisCaleb: #NotGreatProducts basically anything from acme https:\/\/t.co\/fwFpdJSy2p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhoIsThisCaleb\/status\/779490499845459968\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/fwFpdJSy2p",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFOeRHVYAAygeE.jpg",
        "id_str" : "779490492409012224",
        "id" : 779490492409012224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFOeRHVYAAygeE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 250
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fwFpdJSy2p"
      } ],
      "hashtags" : [ {
        "text" : "NotGreatProducts",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779490499845459968",
    "text" : "#NotGreatProducts basically anything from acme https:\/\/t.co\/fwFpdJSy2p",
    "id" : 779490499845459968,
    "created_at" : "2016-09-24 01:19:52 +0000",
    "user" : {
      "name" : "Caleb",
      "screen_name" : "WhoIsThisCaleb",
      "protected" : false,
      "id_str" : "3195855170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758889527519752192\/8DBnoemC_normal.jpg",
      "id" : 3195855170,
      "verified" : false
    }
  },
  "id" : 779522992573452288,
  "created_at" : "2016-09-24 03:28:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sabrina \u2601",
      "screen_name" : "flyawaySabrina",
      "indices" : [ 0, 15 ],
      "id_str" : "715436056619798528",
      "id" : 715436056619798528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779520036771729408",
  "geo" : { },
  "id_str" : "779522811111038976",
  "in_reply_to_user_id" : 715436056619798528,
  "text" : "@flyawaySabrina People eat Pigeons",
  "id" : 779522811111038976,
  "in_reply_to_status_id" : 779520036771729408,
  "created_at" : "2016-09-24 03:28:15 +0000",
  "in_reply_to_screen_name" : "flyawaySabrina",
  "in_reply_to_user_id_str" : "715436056619798528",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisha Francis",
      "screen_name" : "alishamarie28",
      "indices" : [ 3, 17 ],
      "id_str" : "283915091",
      "id" : 283915091
    }, {
      "name" : "Hell's Kitchen",
      "screen_name" : "HellsKitchenFOX",
      "indices" : [ 34, 50 ],
      "id_str" : "58572077",
      "id" : 58572077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779522705989242880",
  "text" : "RT @alishamarie28: Me everytime a @HellsKitchenFOX contestant swears he\/she knows how to cook scallops, risotto &amp; beef wellingtons #HellsKi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hell's Kitchen",
        "screen_name" : "HellsKitchenFOX",
        "indices" : [ 15, 31 ],
        "id_str" : "58572077",
        "id" : 58572077
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alishamarie28\/status\/779479908426797056\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/9BvWdxQaGE",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFE0TEVUAAi24E.jpg",
        "id_str" : "779479875774140416",
        "id" : 779479875774140416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFE0TEVUAAi24E.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 498
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/9BvWdxQaGE"
      } ],
      "hashtags" : [ {
        "text" : "HellsKitchen",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779479908426797056",
    "text" : "Me everytime a @HellsKitchenFOX contestant swears he\/she knows how to cook scallops, risotto &amp; beef wellingtons #HellsKitchen https:\/\/t.co\/9BvWdxQaGE",
    "id" : 779479908426797056,
    "created_at" : "2016-09-24 00:37:46 +0000",
    "user" : {
      "name" : "Alisha Francis",
      "screen_name" : "alishamarie28",
      "protected" : false,
      "id_str" : "283915091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/975006837593473025\/TMv2tSwl_normal.jpg",
      "id" : 283915091,
      "verified" : false
    }
  },
  "id" : 779522705989242880,
  "created_at" : "2016-09-24 03:27:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dreana",
      "screen_name" : "dreanabeana",
      "indices" : [ 3, 15 ],
      "id_str" : "17261287",
      "id" : 17261287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dreanabeana\/status\/779479391617347584\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/hu7Nbi5Fyz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFEW5kWcAARA0c.jpg",
      "id_str" : "779479370712903680",
      "id" : 779479370712903680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFEW5kWcAARA0c.jpg",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 318
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 318
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 318
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 318
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hu7Nbi5Fyz"
    } ],
    "hashtags" : [ {
      "text" : "HellsKitchen",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779522652104953856",
  "text" : "RT @dreanabeana: Someone cooked scallops perfectly on the first try? Well i'll be #HellsKitchen https:\/\/t.co\/hu7Nbi5Fyz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dreanabeana\/status\/779479391617347584\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/hu7Nbi5Fyz",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFEW5kWcAARA0c.jpg",
        "id_str" : "779479370712903680",
        "id" : 779479370712903680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CtFEW5kWcAARA0c.jpg",
        "sizes" : [ {
          "h" : 176,
          "resize" : "fit",
          "w" : 318
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 318
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 318
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 318
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hu7Nbi5Fyz"
      } ],
      "hashtags" : [ {
        "text" : "HellsKitchen",
        "indices" : [ 65, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779479391617347584",
    "text" : "Someone cooked scallops perfectly on the first try? Well i'll be #HellsKitchen https:\/\/t.co\/hu7Nbi5Fyz",
    "id" : 779479391617347584,
    "created_at" : "2016-09-24 00:35:43 +0000",
    "user" : {
      "name" : "Dreana",
      "screen_name" : "dreanabeana",
      "protected" : false,
      "id_str" : "17261287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506884779535384576\/2RcjOv1C_normal.png",
      "id" : 17261287,
      "verified" : false
    }
  },
  "id" : 779522652104953856,
  "created_at" : "2016-09-24 03:27:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Jones",
      "screen_name" : "thefarmerjones",
      "indices" : [ 3, 18 ],
      "id_str" : "39801402",
      "id" : 39801402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779522552741920768",
  "text" : "RT @thefarmerjones: Did not imagine I'd spend the night tweeting about a student protest at an Eastern Michigan football game, but there yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779522097307451392",
    "text" : "Did not imagine I'd spend the night tweeting about a student protest at an Eastern Michigan football game, but there you go.",
    "id" : 779522097307451392,
    "created_at" : "2016-09-24 03:25:25 +0000",
    "user" : {
      "name" : "Farmer Jones",
      "screen_name" : "thefarmerjones",
      "protected" : false,
      "id_str" : "39801402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875743742770151424\/LFhnettB_normal.jpg",
      "id" : 39801402,
      "verified" : false
    }
  },
  "id" : 779522552741920768,
  "created_at" : "2016-09-24 03:27:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ford Motor Company",
      "screen_name" : "Ford",
      "indices" : [ 0, 5 ],
      "id_str" : "15676492",
      "id" : 15676492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779522020107227136",
  "in_reply_to_user_id" : 15676492,
  "text" : "@Ford Never forgot Ford basically came first \uD83D\uDE0F",
  "id" : 779522020107227136,
  "created_at" : "2016-09-24 03:25:07 +0000",
  "in_reply_to_screen_name" : "Ford",
  "in_reply_to_user_id_str" : "15676492",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ford Motor Company",
      "screen_name" : "Ford",
      "indices" : [ 3, 8 ],
      "id_str" : "15676492",
      "id" : 15676492
    }, {
      "name" : "INACTIVE\u2014FOLLOW @LAURENCFOX_",
      "screen_name" : "laurencfox__",
      "indices" : [ 10, 23 ],
      "id_str" : "718638572048224256",
      "id" : 718638572048224256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuiltFordTough",
      "indices" : [ 51, 66 ]
    }, {
      "text" : "FordPerformance",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779521850971942912",
  "text" : "RT @Ford: @laurencfox__ It's pretty tough choosing #BuiltFordTough or #FordPerformance for your birthday. Which colors would you want them\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/digitalroots.com\" rel=\"nofollow\"\u003EDigital Roots Engage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "INACTIVE\u2014FOLLOW @LAURENCFOX_",
        "screen_name" : "laurencfox__",
        "indices" : [ 0, 13 ],
        "id_str" : "718638572048224256",
        "id" : 718638572048224256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuiltFordTough",
        "indices" : [ 41, 56 ]
      }, {
        "text" : "FordPerformance",
        "indices" : [ 60, 76 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779382481074032640",
    "geo" : { },
    "id_str" : "779467401977032704",
    "in_reply_to_user_id" : 718638572048224256,
    "text" : "@laurencfox__ It's pretty tough choosing #BuiltFordTough or #FordPerformance for your birthday. Which colors would you want them to be?",
    "id" : 779467401977032704,
    "in_reply_to_status_id" : 779382481074032640,
    "created_at" : "2016-09-23 23:48:05 +0000",
    "in_reply_to_screen_name" : "laurencfox__",
    "in_reply_to_user_id_str" : "718638572048224256",
    "user" : {
      "name" : "Ford Motor Company",
      "screen_name" : "Ford",
      "protected" : false,
      "id_str" : "15676492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839910514289426433\/BxTIsgFj_normal.jpg",
      "id" : 15676492,
      "verified" : true
    }
  },
  "id" : 779521850971942912,
  "created_at" : "2016-09-24 03:24:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779521709284163584",
  "text" : "Well I tweet about everything, lol",
  "id" : 779521709284163584,
  "created_at" : "2016-09-24 03:23:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 19, 26 ],
      "id_str" : "16228398",
      "id" : 16228398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sharktank",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779521587506737154",
  "text" : "RT @BetchNikiBB18: @mcuban you have no idea how bad your show #Sharktank 's ratings are going to fail. Don't believe me ask CNN. #BoycottSh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 0, 7 ],
        "id_str" : "16228398",
        "id" : 16228398
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sharktank",
        "indices" : [ 43, 53 ]
      }, {
        "text" : "BoycottSharkTank",
        "indices" : [ 110, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779513365022380032",
    "in_reply_to_user_id" : 16228398,
    "text" : "@mcuban you have no idea how bad your show #Sharktank 's ratings are going to fail. Don't believe me ask CNN. #BoycottSharkTank",
    "id" : 779513365022380032,
    "created_at" : "2016-09-24 02:50:43 +0000",
    "in_reply_to_screen_name" : "mcuban",
    "in_reply_to_user_id_str" : "16228398",
    "user" : {
      "name" : "Niki",
      "screen_name" : "REALNikiandBB",
      "protected" : false,
      "id_str" : "1539949615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992966792283852800\/UoHfqKlk_normal.jpg",
      "id" : 1539949615,
      "verified" : false
    }
  },
  "id" : 779521587506737154,
  "created_at" : "2016-09-24 03:23:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/dYfFhhTvBB",
      "expanded_url" : "http:\/\/nyti.ms\/2cujwoB",
      "display_url" : "nyti.ms\/2cujwoB"
    } ]
  },
  "geo" : { },
  "id_str" : "779521320241463296",
  "text" : "RT @nytfood: Our 50 most popular recipes ev-ah. https:\/\/t.co\/dYfFhhTvBB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/dYfFhhTvBB",
        "expanded_url" : "http:\/\/nyti.ms\/2cujwoB",
        "display_url" : "nyti.ms\/2cujwoB"
      } ]
    },
    "geo" : { },
    "id_str" : "777163969127673856",
    "text" : "Our 50 most popular recipes ev-ah. https:\/\/t.co\/dYfFhhTvBB",
    "id" : 777163969127673856,
    "created_at" : "2016-09-17 15:15:03 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521320241463296,
  "created_at" : "2016-09-24 03:22:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/Oy3w8Y6H2O",
      "expanded_url" : "http:\/\/nyti.ms\/2cPe8vM",
      "display_url" : "nyti.ms\/2cPe8vM"
    } ]
  },
  "geo" : { },
  "id_str" : "779521288276672512",
  "text" : "RT @nytfood: How to make perfect biscuits https:\/\/t.co\/Oy3w8Y6H2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/Oy3w8Y6H2O",
        "expanded_url" : "http:\/\/nyti.ms\/2cPe8vM",
        "display_url" : "nyti.ms\/2cPe8vM"
      } ]
    },
    "geo" : { },
    "id_str" : "777372112461979648",
    "text" : "How to make perfect biscuits https:\/\/t.co\/Oy3w8Y6H2O",
    "id" : 777372112461979648,
    "created_at" : "2016-09-18 05:02:09 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521288276672512,
  "created_at" : "2016-09-24 03:22:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/777991360028737537\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/9Qt466yPTX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Csv7BFMWgAA-DOK.jpg",
      "id_str" : "777991356643966976",
      "id" : 777991356643966976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csv7BFMWgAA-DOK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/9Qt466yPTX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/1mrrq7c97X",
      "expanded_url" : "http:\/\/nyti.ms\/2cumZUi",
      "display_url" : "nyti.ms\/2cumZUi"
    } ]
  },
  "geo" : { },
  "id_str" : "779521251035451392",
  "text" : "RT @nytfood: A new dinner party standard https:\/\/t.co\/1mrrq7c97X https:\/\/t.co\/9Qt466yPTX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/777991360028737537\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/9Qt466yPTX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Csv7BFMWgAA-DOK.jpg",
        "id_str" : "777991356643966976",
        "id" : 777991356643966976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Csv7BFMWgAA-DOK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/9Qt466yPTX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/1mrrq7c97X",
        "expanded_url" : "http:\/\/nyti.ms\/2cumZUi",
        "display_url" : "nyti.ms\/2cumZUi"
      } ]
    },
    "geo" : { },
    "id_str" : "777991360028737537",
    "text" : "A new dinner party standard https:\/\/t.co\/1mrrq7c97X https:\/\/t.co\/9Qt466yPTX",
    "id" : 777991360028737537,
    "created_at" : "2016-09-19 22:02:49 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521251035451392,
  "created_at" : "2016-09-24 03:22:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778559678422904833\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/58EhJSDaMs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs3_5knWYAEv9BW.jpg",
      "id_str" : "778559675151310849",
      "id" : 778559675151310849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs3_5knWYAEv9BW.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/58EhJSDaMs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/3ODDrUNZha",
      "expanded_url" : "http:\/\/nyti.ms\/2d6ec6a",
      "display_url" : "nyti.ms\/2d6ec6a"
    } ]
  },
  "geo" : { },
  "id_str" : "779521215933325316",
  "text" : "RT @nytfood: A pastry chef updates Rosh Hashana classics https:\/\/t.co\/3ODDrUNZha https:\/\/t.co\/58EhJSDaMs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778559678422904833\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/58EhJSDaMs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs3_5knWYAEv9BW.jpg",
        "id_str" : "778559675151310849",
        "id" : 778559675151310849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs3_5knWYAEv9BW.jpg",
        "sizes" : [ {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/58EhJSDaMs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/3ODDrUNZha",
        "expanded_url" : "http:\/\/nyti.ms\/2d6ec6a",
        "display_url" : "nyti.ms\/2d6ec6a"
      } ]
    },
    "geo" : { },
    "id_str" : "778559678422904833",
    "text" : "A pastry chef updates Rosh Hashana classics https:\/\/t.co\/3ODDrUNZha https:\/\/t.co\/58EhJSDaMs",
    "id" : 778559678422904833,
    "created_at" : "2016-09-21 11:41:06 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521215933325316,
  "created_at" : "2016-09-24 03:21:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778644771292282880\/video\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/PnxGZCOdmc",
      "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/778644108286038016\/img\/Wlo9QCnyp_EOdGg_.jpg",
      "id_str" : "778644108286038016",
      "id" : 778644108286038016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/778644108286038016\/img\/Wlo9QCnyp_EOdGg_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PnxGZCOdmc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779521179195437056",
  "text" : "RT @nytfood: Simple and delicious https:\/\/t.co\/PnxGZCOdmc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778644771292282880\/video\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/PnxGZCOdmc",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/778644108286038016\/img\/Wlo9QCnyp_EOdGg_.jpg",
        "id_str" : "778644108286038016",
        "id" : 778644108286038016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/778644108286038016\/img\/Wlo9QCnyp_EOdGg_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/PnxGZCOdmc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778644771292282880",
    "text" : "Simple and delicious https:\/\/t.co\/PnxGZCOdmc",
    "id" : 778644771292282880,
    "created_at" : "2016-09-21 17:19:14 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521179195437056,
  "created_at" : "2016-09-24 03:21:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778984243099729920\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/phQEwPqCr8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-CCdJWEAEiRVI.jpg",
      "id_str" : "778984239253557249",
      "id" : 778984239253557249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-CCdJWEAEiRVI.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/phQEwPqCr8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/1DSbJm6Eoq",
      "expanded_url" : "http:\/\/nyti.ms\/2cr9WAD",
      "display_url" : "nyti.ms\/2cr9WAD"
    } ]
  },
  "geo" : { },
  "id_str" : "779521145607483392",
  "text" : "RT @nytfood: \"A nearly perfect recipe.\" The story behind our famous plum torte https:\/\/t.co\/1DSbJm6Eoq https:\/\/t.co\/phQEwPqCr8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/778984243099729920\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/phQEwPqCr8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-CCdJWEAEiRVI.jpg",
        "id_str" : "778984239253557249",
        "id" : 778984239253557249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-CCdJWEAEiRVI.jpg",
        "sizes" : [ {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/phQEwPqCr8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/1DSbJm6Eoq",
        "expanded_url" : "http:\/\/nyti.ms\/2cr9WAD",
        "display_url" : "nyti.ms\/2cr9WAD"
      } ]
    },
    "geo" : { },
    "id_str" : "778984243099729920",
    "text" : "\"A nearly perfect recipe.\" The story behind our famous plum torte https:\/\/t.co\/1DSbJm6Eoq https:\/\/t.co\/phQEwPqCr8",
    "id" : 778984243099729920,
    "created_at" : "2016-09-22 15:48:11 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521145607483392,
  "created_at" : "2016-09-24 03:21:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "indices" : [ 3, 11 ],
      "id_str" : "1775731",
      "id" : 1775731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/779414126460334080\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/tlm8cmDqCN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtEJBBQXYAAsNbC.jpg",
      "id_str" : "779414123633401856",
      "id" : 779414123633401856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtEJBBQXYAAsNbC.jpg",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/tlm8cmDqCN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/X1tVnmwPkw",
      "expanded_url" : "http:\/\/nyti.ms\/2dfmPM5",
      "display_url" : "nyti.ms\/2dfmPM5"
    } ]
  },
  "geo" : { },
  "id_str" : "779521008516628480",
  "text" : "RT @nytfood: What to cook this weekend https:\/\/t.co\/X1tVnmwPkw https:\/\/t.co\/tlm8cmDqCN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytfood\/status\/779414126460334080\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/tlm8cmDqCN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtEJBBQXYAAsNbC.jpg",
        "id_str" : "779414123633401856",
        "id" : 779414123633401856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtEJBBQXYAAsNbC.jpg",
        "sizes" : [ {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/tlm8cmDqCN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/X1tVnmwPkw",
        "expanded_url" : "http:\/\/nyti.ms\/2dfmPM5",
        "display_url" : "nyti.ms\/2dfmPM5"
      } ]
    },
    "geo" : { },
    "id_str" : "779414126460334080",
    "text" : "What to cook this weekend https:\/\/t.co\/X1tVnmwPkw https:\/\/t.co\/tlm8cmDqCN",
    "id" : 779414126460334080,
    "created_at" : "2016-09-23 20:16:23 +0000",
    "user" : {
      "name" : "NYT Food",
      "screen_name" : "nytfood",
      "protected" : false,
      "id_str" : "1775731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963805479708184577\/GtH18wgX_normal.jpg",
      "id" : 1775731,
      "verified" : true
    }
  },
  "id" : 779521008516628480,
  "created_at" : "2016-09-24 03:21:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodimentary \uD83D\uDC68\u200D\uD83C\uDF73",
      "screen_name" : "Foodimentary",
      "indices" : [ 3, 16 ],
      "id_str" : "17242874",
      "id" : 17242874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoodQuotes",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520875498463232",
  "text" : "RT @Foodimentary: #FoodQuotes:  \"Coffee should be black as the devil, hot as hell, pure as an angel, sweet as love.\"~ Italian Proverb #Coff\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Foodimentary\/status\/778337463035199489\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/EbVGjL9a1F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs01tCLW8AA_uKi.jpg",
        "id_str" : "778337358399860736",
        "id" : 778337358399860736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs01tCLW8AA_uKi.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 734
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/EbVGjL9a1F"
      } ],
      "hashtags" : [ {
        "text" : "FoodQuotes",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "Coffee",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778337463035199489",
    "text" : "#FoodQuotes:  \"Coffee should be black as the devil, hot as hell, pure as an angel, sweet as love.\"~ Italian Proverb #Coffee https:\/\/t.co\/EbVGjL9a1F",
    "id" : 778337463035199489,
    "created_at" : "2016-09-20 20:58:06 +0000",
    "user" : {
      "name" : "Foodimentary \uD83D\uDC68\u200D\uD83C\uDF73",
      "screen_name" : "Foodimentary",
      "protected" : false,
      "id_str" : "17242874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622893150525243392\/oAiOUaCD_normal.jpg",
      "id" : 17242874,
      "verified" : false
    }
  },
  "id" : 779520875498463232,
  "created_at" : "2016-09-24 03:20:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodimentary \uD83D\uDC68\u200D\uD83C\uDF73",
      "screen_name" : "Foodimentary",
      "indices" : [ 3, 16 ],
      "id_str" : "17242874",
      "id" : 17242874
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Foodimentary\/status\/778558137326510080\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/N3k0VVbt6w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs3-fQuWYAAajTa.jpg",
      "id_str" : "778558123623735296",
      "id" : 778558123623735296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs3-fQuWYAAajTa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 1290
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 1290
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/N3k0VVbt6w"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/qY6dbEAUKG",
      "expanded_url" : "https:\/\/foodimentary.com\/2016\/09\/21\/national-pecan-cookie-day\/",
      "display_url" : "foodimentary.com\/2016\/09\/21\/nat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779520845207207936",
  "text" : "RT @Foodimentary: September 21st is National Pecan Cookie Day! https:\/\/t.co\/qY6dbEAUKG https:\/\/t.co\/N3k0VVbt6w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Foodimentary\/status\/778558137326510080\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/N3k0VVbt6w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs3-fQuWYAAajTa.jpg",
        "id_str" : "778558123623735296",
        "id" : 778558123623735296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs3-fQuWYAAajTa.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1290
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1290
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/N3k0VVbt6w"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/qY6dbEAUKG",
        "expanded_url" : "https:\/\/foodimentary.com\/2016\/09\/21\/national-pecan-cookie-day\/",
        "display_url" : "foodimentary.com\/2016\/09\/21\/nat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778558137326510080",
    "text" : "September 21st is National Pecan Cookie Day! https:\/\/t.co\/qY6dbEAUKG https:\/\/t.co\/N3k0VVbt6w",
    "id" : 778558137326510080,
    "created_at" : "2016-09-21 11:34:59 +0000",
    "user" : {
      "name" : "Foodimentary \uD83D\uDC68\u200D\uD83C\uDF73",
      "screen_name" : "Foodimentary",
      "protected" : false,
      "id_str" : "17242874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622893150525243392\/oAiOUaCD_normal.jpg",
      "id" : 17242874,
      "verified" : false
    }
  },
  "id" : 779520845207207936,
  "created_at" : "2016-09-24 03:20:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "indices" : [ 3, 14 ],
      "id_str" : "15131310",
      "id" : 15131310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WholeFoods\/status\/779365734887616512\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/rHHNAphOgt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDdAD6WIAA54t6.jpg",
      "id_str" : "779365728654860288",
      "id" : 779365728654860288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDdAD6WIAA54t6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/rHHNAphOgt"
    } ],
    "hashtags" : [ {
      "text" : "Vegetarian",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/J2OECagmYO",
      "expanded_url" : "http:\/\/bit.ly\/2cJ1tpI",
      "display_url" : "bit.ly\/2cJ1tpI"
    } ]
  },
  "geo" : { },
  "id_str" : "779520774520598528",
  "text" : "RT @WholeFoods: Our Fave New Recipes! Fall #Vegetarian Slow Cooker Dinners: https:\/\/t.co\/J2OECagmYO. https:\/\/t.co\/rHHNAphOgt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WholeFoods\/status\/779365734887616512\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/rHHNAphOgt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDdAD6WIAA54t6.jpg",
        "id_str" : "779365728654860288",
        "id" : 779365728654860288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDdAD6WIAA54t6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/rHHNAphOgt"
      } ],
      "hashtags" : [ {
        "text" : "Vegetarian",
        "indices" : [ 27, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/J2OECagmYO",
        "expanded_url" : "http:\/\/bit.ly\/2cJ1tpI",
        "display_url" : "bit.ly\/2cJ1tpI"
      } ]
    },
    "geo" : { },
    "id_str" : "779365734887616512",
    "text" : "Our Fave New Recipes! Fall #Vegetarian Slow Cooker Dinners: https:\/\/t.co\/J2OECagmYO. https:\/\/t.co\/rHHNAphOgt",
    "id" : 779365734887616512,
    "created_at" : "2016-09-23 17:04:05 +0000",
    "user" : {
      "name" : "Whole Foods Market",
      "screen_name" : "WholeFoods",
      "protected" : false,
      "id_str" : "15131310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804367481041080320\/ljq1T2Qx_normal.jpg",
      "id" : 15131310,
      "verified" : true
    }
  },
  "id" : 779520774520598528,
  "created_at" : "2016-09-24 03:20:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779493808761401344\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/dRlBBKIXb5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFRfL9XEAA_06v.jpg",
      "id_str" : "779493806739755008",
      "id" : 779493806739755008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFRfL9XEAA_06v.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 587
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dRlBBKIXb5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520705016782848",
  "text" : "RT @ItsFoodPorn: Hot &amp; Teriyaki Wings with Fries https:\/\/t.co\/dRlBBKIXb5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779493808761401344\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/dRlBBKIXb5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFRfL9XEAA_06v.jpg",
        "id_str" : "779493806739755008",
        "id" : 779493806739755008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFRfL9XEAA_06v.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 587
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 587
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 587
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/dRlBBKIXb5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779493808761401344",
    "text" : "Hot &amp; Teriyaki Wings with Fries https:\/\/t.co\/dRlBBKIXb5",
    "id" : 779493808761401344,
    "created_at" : "2016-09-24 01:33:00 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520705016782848,
  "created_at" : "2016-09-24 03:19:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497007757025280\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/rMzWmbvPSE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUYGBXEAAkJqR.jpg",
      "id_str" : "779496983421718528",
      "id" : 779496983421718528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUYGBXEAAkJqR.jpg",
      "sizes" : [ {
        "h" : 661,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 661,
        "resize" : "fit",
        "w" : 600
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/rMzWmbvPSE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520659118493696",
  "text" : "RT @ItsFoodPorn: Apple Pie with Caramel Ice Cream  \u2764\uFE0F\uD83D\uDE4C\uD83C\uDF74 https:\/\/t.co\/rMzWmbvPSE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497007757025280\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/rMzWmbvPSE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUYGBXEAAkJqR.jpg",
        "id_str" : "779496983421718528",
        "id" : 779496983421718528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUYGBXEAAkJqR.jpg",
        "sizes" : [ {
          "h" : 661,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 661,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/rMzWmbvPSE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779497007757025280",
    "text" : "Apple Pie with Caramel Ice Cream  \u2764\uFE0F\uD83D\uDE4C\uD83C\uDF74 https:\/\/t.co\/rMzWmbvPSE",
    "id" : 779497007757025280,
    "created_at" : "2016-09-24 01:45:43 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520659118493696,
  "created_at" : "2016-09-24 03:19:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497173004214272\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/8qcMLU3GMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUiptXYAAz3fF.jpg",
      "id_str" : "779497164800221184",
      "id" : 779497164800221184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUiptXYAAz3fF.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/8qcMLU3GMI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497173004214272\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/8qcMLU3GMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUip4WYAAm-Lg.jpg",
      "id_str" : "779497164846292992",
      "id" : 779497164846292992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUip4WYAAm-Lg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 492
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/8qcMLU3GMI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520637857652736",
  "text" : "RT @ItsFoodPorn: Chinese food is just https:\/\/t.co\/8qcMLU3GMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497173004214272\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/8qcMLU3GMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUiptXYAAz3fF.jpg",
        "id_str" : "779497164800221184",
        "id" : 779497164800221184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUiptXYAAz3fF.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/8qcMLU3GMI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779497173004214272\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/8qcMLU3GMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFUip4WYAAm-Lg.jpg",
        "id_str" : "779497164846292992",
        "id" : 779497164846292992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFUip4WYAAm-Lg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 492
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 492
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 492
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 492
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/8qcMLU3GMI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779497173004214272",
    "text" : "Chinese food is just https:\/\/t.co\/8qcMLU3GMI",
    "id" : 779497173004214272,
    "created_at" : "2016-09-24 01:46:23 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520637857652736,
  "created_at" : "2016-09-24 03:19:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779498341747023872\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/60AFzoox8A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFVnAXW8AAjm-l.jpg",
      "id_str" : "779498339113037824",
      "id" : 779498339113037824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFVnAXW8AAjm-l.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 422
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/60AFzoox8A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520609361494016",
  "text" : "RT @ItsFoodPorn: Chocolate Chip Ice Cream Bars https:\/\/t.co\/60AFzoox8A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779498341747023872\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/60AFzoox8A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFVnAXW8AAjm-l.jpg",
        "id_str" : "779498339113037824",
        "id" : 779498339113037824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFVnAXW8AAjm-l.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 621,
          "resize" : "fit",
          "w" : 422
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/60AFzoox8A"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779498341747023872",
    "text" : "Chocolate Chip Ice Cream Bars https:\/\/t.co\/60AFzoox8A",
    "id" : 779498341747023872,
    "created_at" : "2016-09-24 01:51:01 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520609361494016,
  "created_at" : "2016-09-24 03:19:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779501368067387392\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/TDQbgUbOQi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFYWv0XYAQ3cAF.jpg",
      "id_str" : "779501358328274948",
      "id" : 779501358328274948,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFYWv0XYAQ3cAF.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/TDQbgUbOQi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520593494437889",
  "text" : "RT @ItsFoodPorn: Mac N Cheese \uD83D\uDE4C https:\/\/t.co\/TDQbgUbOQi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779501368067387392\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/TDQbgUbOQi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFYWv0XYAQ3cAF.jpg",
        "id_str" : "779501358328274948",
        "id" : 779501358328274948,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFYWv0XYAQ3cAF.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/TDQbgUbOQi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779501368067387392",
    "text" : "Mac N Cheese \uD83D\uDE4C https:\/\/t.co\/TDQbgUbOQi",
    "id" : 779501368067387392,
    "created_at" : "2016-09-24 02:03:03 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520593494437889,
  "created_at" : "2016-09-24 03:19:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779513439303720960\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/6sPtUwuecM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFjV1hXgAAsfBV.jpg",
      "id_str" : "779513437307240448",
      "id" : 779513437307240448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFjV1hXgAAsfBV.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 599
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/6sPtUwuecM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520547197710336",
  "text" : "RT @ItsFoodPorn: Hot Fudge Milkshakes https:\/\/t.co\/6sPtUwuecM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779513439303720960\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/6sPtUwuecM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFjV1hXgAAsfBV.jpg",
        "id_str" : "779513437307240448",
        "id" : 779513437307240448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFjV1hXgAAsfBV.jpg",
        "sizes" : [ {
          "h" : 577,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 599
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/6sPtUwuecM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779513439303720960",
    "text" : "Hot Fudge Milkshakes https:\/\/t.co\/6sPtUwuecM",
    "id" : 779513439303720960,
    "created_at" : "2016-09-24 02:51:01 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520547197710336,
  "created_at" : "2016-09-24 03:19:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779516205170319360\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/IlK9LZ58i7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFl23AWIAA7eWy.jpg",
      "id_str" : "779516203664547840",
      "id" : 779516203664547840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFl23AWIAA7eWy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 499
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/IlK9LZ58i7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779520535038427136",
  "text" : "RT @ItsFoodPorn: Skillet cookie https:\/\/t.co\/IlK9LZ58i7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/779516205170319360\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/IlK9LZ58i7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtFl23AWIAA7eWy.jpg",
        "id_str" : "779516203664547840",
        "id" : 779516203664547840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtFl23AWIAA7eWy.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 499
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/IlK9LZ58i7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779516205170319360",
    "text" : "Skillet cookie https:\/\/t.co\/IlK9LZ58i7",
    "id" : 779516205170319360,
    "created_at" : "2016-09-24 03:02:00 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 779520535038427136,
  "created_at" : "2016-09-24 03:19:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/779427052525084672\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/RDUnBihsAp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtEUw4uWYAEisE0.jpg",
      "id_str" : "779427040604872705",
      "id" : 779427040604872705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtEUw4uWYAEisE0.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1638
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1638
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 960
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/RDUnBihsAp"
    } ],
    "hashtags" : [ {
      "text" : "DreamTeam",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779519947085152256",
  "text" : "RT @KassyDillon: Sign waving with Tucker! #DreamTeam https:\/\/t.co\/RDUnBihsAp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/779427052525084672\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/RDUnBihsAp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtEUw4uWYAEisE0.jpg",
        "id_str" : "779427040604872705",
        "id" : 779427040604872705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtEUw4uWYAEisE0.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1638
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1638
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 960
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/RDUnBihsAp"
      } ],
      "hashtags" : [ {
        "text" : "DreamTeam",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779427052525084672",
    "text" : "Sign waving with Tucker! #DreamTeam https:\/\/t.co\/RDUnBihsAp",
    "id" : 779427052525084672,
    "created_at" : "2016-09-23 21:07:45 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 779519947085152256,
  "created_at" : "2016-09-24 03:16:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Burgess, MD",
      "screen_name" : "michaelcburgess",
      "indices" : [ 3, 19 ],
      "id_str" : "15751083",
      "id" : 15751083
    }, {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 35, 46 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    }, {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779519868114722816",
  "text" : "RT @michaelcburgess: Proud to join @SenTedCruz to protect our #freedom of expression &amp; enterprise by preventing @POTUS from relinquishing U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Ted Cruz",
        "screen_name" : "SenTedCruz",
        "indices" : [ 14, 25 ],
        "id_str" : "1074480192",
        "id" : 1074480192
      }, {
        "name" : "President Trump",
        "screen_name" : "POTUS",
        "indices" : [ 95, 101 ],
        "id_str" : "822215679726100480",
        "id" : 822215679726100480
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michaelcburgess\/status\/779432233241378816\/video\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/QROoDmtj05",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779431272963776514\/pu\/img\/r3HtvRreQ5sFXWcq.jpg",
        "id_str" : "779431272963776514",
        "id" : 779431272963776514,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779431272963776514\/pu\/img\/r3HtvRreQ5sFXWcq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/QROoDmtj05"
      } ],
      "hashtags" : [ {
        "text" : "freedom",
        "indices" : [ 41, 49 ]
      }, {
        "text" : "Internet",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779432233241378816",
    "text" : "Proud to join @SenTedCruz to protect our #freedom of expression &amp; enterprise by preventing @POTUS from relinquishing US #Internet oversight. https:\/\/t.co\/QROoDmtj05",
    "id" : 779432233241378816,
    "created_at" : "2016-09-23 21:28:20 +0000",
    "user" : {
      "name" : "Michael Burgess, MD",
      "screen_name" : "michaelcburgess",
      "protected" : false,
      "id_str" : "15751083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465221794\/100_0726_normal.jpg",
      "id" : 15751083,
      "verified" : true
    }
  },
  "id" : 779519868114722816,
  "created_at" : "2016-09-24 03:16:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/t2Y6LdtgUz",
      "expanded_url" : "http:\/\/ow.ly\/Mu0N304jQ69",
      "display_url" : "ow.ly\/Mu0N304jQ69"
    } ]
  },
  "geo" : { },
  "id_str" : "779519615839924224",
  "text" : "RT @analyticbridge: A methodology for solving problems with DataScience for Internet of Things -Part One https:\/\/t.co\/t2Y6LdtgUz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/t2Y6LdtgUz",
        "expanded_url" : "http:\/\/ow.ly\/Mu0N304jQ69",
        "display_url" : "ow.ly\/Mu0N304jQ69"
      } ]
    },
    "geo" : { },
    "id_str" : "779515955214970881",
    "text" : "A methodology for solving problems with DataScience for Internet of Things -Part One https:\/\/t.co\/t2Y6LdtgUz",
    "id" : 779515955214970881,
    "created_at" : "2016-09-24 03:01:01 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779519615839924224,
  "created_at" : "2016-09-24 03:15:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CopticWorld",
      "indices" : [ 104, 116 ]
    }, {
      "text" : "coptic",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pw8255bdA5",
      "expanded_url" : "http:\/\/dlvr.it\/LqvmQ0",
      "display_url" : "dlvr.it\/LqvmQ0"
    } ]
  },
  "geo" : { },
  "id_str" : "779519233088782336",
  "text" : "RT @copticworld: One dead after Muslim mob attacks Christian priests in Egypt,\u2026 https:\/\/t.co\/pw8255bdA5 #CopticWorld #coptic https:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/copticworld\/status\/755425758885982208\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/wQqu0rF21l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnvPuSiUkAE1mLG.jpg",
        "id_str" : "755425756671414273",
        "id" : 755425756671414273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnvPuSiUkAE1mLG.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/wQqu0rF21l"
      } ],
      "hashtags" : [ {
        "text" : "CopticWorld",
        "indices" : [ 87, 99 ]
      }, {
        "text" : "coptic",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/pw8255bdA5",
        "expanded_url" : "http:\/\/dlvr.it\/LqvmQ0",
        "display_url" : "dlvr.it\/LqvmQ0"
      } ]
    },
    "geo" : { },
    "id_str" : "755425758885982208",
    "text" : "One dead after Muslim mob attacks Christian priests in Egypt,\u2026 https:\/\/t.co\/pw8255bdA5 #CopticWorld #coptic https:\/\/t.co\/wQqu0rF21l",
    "id" : 755425758885982208,
    "created_at" : "2016-07-19 15:35:10 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 779519233088782336,
  "created_at" : "2016-09-24 03:14:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/z7tbs29pS9",
      "expanded_url" : "http:\/\/dlvr.it\/MGhqr2",
      "display_url" : "dlvr.it\/MGhqr2"
    } ]
  },
  "geo" : { },
  "id_str" : "779519138809118720",
  "text" : "RT @copticworld: 'Coffee with the Clerics' event geared toward Lincolnwood diversity: Lincolonwood is looking\u2026 https:\/\/t.co\/z7tbs29pS9 #Cop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CopticWorld",
        "indices" : [ 118, 130 ]
      }, {
        "text" : "coptic",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/z7tbs29pS9",
        "expanded_url" : "http:\/\/dlvr.it\/MGhqr2",
        "display_url" : "dlvr.it\/MGhqr2"
      } ]
    },
    "geo" : { },
    "id_str" : "776629471092674560",
    "text" : "'Coffee with the Clerics' event geared toward Lincolnwood diversity: Lincolonwood is looking\u2026 https:\/\/t.co\/z7tbs29pS9 #CopticWorld #coptic",
    "id" : 776629471092674560,
    "created_at" : "2016-09-16 03:51:09 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 779519138809118720,
  "created_at" : "2016-09-24 03:13:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ancient Faith",
      "screen_name" : "ancientfaith",
      "indices" : [ 3, 16 ],
      "id_str" : "17129870",
      "id" : 17129870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "ancientfaith",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/PnRAHbdVEc",
      "expanded_url" : "http:\/\/www.ancientfaith.com\/podcasts\/nootherfoundation\/can_we_know_for_sure_who_is_saved",
      "display_url" : "ancientfaith.com\/podcasts\/nooth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779519066524545025",
  "text" : "RT @ancientfaith: Can We Know For Sure Who Is Saved? https:\/\/t.co\/PnRAHbdVEc #podcast #ancientfaith",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "podcast",
        "indices" : [ 59, 67 ]
      }, {
        "text" : "ancientfaith",
        "indices" : [ 68, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/PnRAHbdVEc",
        "expanded_url" : "http:\/\/www.ancientfaith.com\/podcasts\/nootherfoundation\/can_we_know_for_sure_who_is_saved",
        "display_url" : "ancientfaith.com\/podcasts\/nooth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779005412804857857",
    "text" : "Can We Know For Sure Who Is Saved? https:\/\/t.co\/PnRAHbdVEc #podcast #ancientfaith",
    "id" : 779005412804857857,
    "created_at" : "2016-09-22 17:12:18 +0000",
    "user" : {
      "name" : "Ancient Faith",
      "screen_name" : "ancientfaith",
      "protected" : false,
      "id_str" : "17129870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/386819240\/CMM_AFR_normal.jpg",
      "id" : 17129870,
      "verified" : false
    }
  },
  "id" : 779519066524545025,
  "created_at" : "2016-09-24 03:13:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ancient Faith",
      "screen_name" : "ancientfaith",
      "indices" : [ 3, 16 ],
      "id_str" : "17129870",
      "id" : 17129870
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ancientfaith\/status\/779329730893979648\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/ALlCvGEr1c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC8QS3WcAUrpr4.jpg",
      "id_str" : "779329723663020037",
      "id" : 779329723663020037,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC8QS3WcAUrpr4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ALlCvGEr1c"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/3YVO31A510",
      "expanded_url" : "http:\/\/www.ancientfaith.com\/podcasts\/saintoftheday\/holy_martyr_iraida_of_alexandria2",
      "display_url" : "ancientfaith.com\/podcasts\/saint\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779518959708168192",
  "text" : "RT @ancientfaith: Holy Martyr Iraida of Alexandria https:\/\/t.co\/3YVO31A510 https:\/\/t.co\/ALlCvGEr1c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ancientfaith\/status\/779329730893979648\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ALlCvGEr1c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC8QS3WcAUrpr4.jpg",
        "id_str" : "779329723663020037",
        "id" : 779329723663020037,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC8QS3WcAUrpr4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ALlCvGEr1c"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/3YVO31A510",
        "expanded_url" : "http:\/\/www.ancientfaith.com\/podcasts\/saintoftheday\/holy_martyr_iraida_of_alexandria2",
        "display_url" : "ancientfaith.com\/podcasts\/saint\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779329730893979648",
    "text" : "Holy Martyr Iraida of Alexandria https:\/\/t.co\/3YVO31A510 https:\/\/t.co\/ALlCvGEr1c",
    "id" : 779329730893979648,
    "created_at" : "2016-09-23 14:41:01 +0000",
    "user" : {
      "name" : "Ancient Faith",
      "screen_name" : "ancientfaith",
      "protected" : false,
      "id_str" : "17129870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/386819240\/CMM_AFR_normal.jpg",
      "id" : 17129870,
      "verified" : false
    }
  },
  "id" : 779518959708168192,
  "created_at" : "2016-09-24 03:12:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "indices" : [ 3, 12 ],
      "id_str" : "96013710",
      "id" : 96013710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779518668510228480",
  "text" : "RT @FactSoup: Always end the day with a positive thought. No matter how hard things were, tomorrow is a fresh opportunity to make it better.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779517505547202560",
    "text" : "Always end the day with a positive thought. No matter how hard things were, tomorrow is a fresh opportunity to make it better.",
    "id" : 779517505547202560,
    "created_at" : "2016-09-24 03:07:10 +0000",
    "user" : {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "protected" : false,
      "id_str" : "96013710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956327042554896384\/xHimnR1u_normal.jpg",
      "id" : 96013710,
      "verified" : false
    }
  },
  "id" : 779518668510228480,
  "created_at" : "2016-09-24 03:11:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779518329627238400",
  "text" : "RT @OfficialWestJR: I prefer loneliness than fake company",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779499218121527297",
    "text" : "I prefer loneliness than fake company",
    "id" : 779499218121527297,
    "created_at" : "2016-09-24 01:54:30 +0000",
    "user" : {
      "name" : "\uD83C\uDDED\uD83C\uDDF9\u0627\u0644\u062D\u0645\u062F \u0644\u0644\u0647\uD83C\uDDF9\uD83C\uDDFF",
      "screen_name" : "IamWestOfficial",
      "protected" : false,
      "id_str" : "230627444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948336343091990528\/Vi1FFe9s_normal.jpg",
      "id" : 230627444,
      "verified" : false
    }
  },
  "id" : 779518329627238400,
  "created_at" : "2016-09-24 03:10:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak Santo",
      "screen_name" : "zsanto",
      "indices" : [ 3, 10 ],
      "id_str" : "15039224",
      "id" : 15039224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zsanto\/status\/779151474089664512\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/qjwyVcbBgI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtAaIb3WIAA_5Bb.jpg",
      "id_str" : "779151467756265472",
      "id" : 779151467756265472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtAaIb3WIAA_5Bb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qjwyVcbBgI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/zsanto\/status\/779151474089664512\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/qjwyVcbBgI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtAaIbxXYAAGsXA.jpg",
      "id_str" : "779151467731181568",
      "id" : 779151467731181568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtAaIbxXYAAGsXA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qjwyVcbBgI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517995601264641",
  "text" : "RT @zsanto: New iPhone 7 Plus Portrait mode. https:\/\/t.co\/qjwyVcbBgI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zsanto\/status\/779151474089664512\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/qjwyVcbBgI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtAaIb3WIAA_5Bb.jpg",
        "id_str" : "779151467756265472",
        "id" : 779151467756265472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtAaIb3WIAA_5Bb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/qjwyVcbBgI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/zsanto\/status\/779151474089664512\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/qjwyVcbBgI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtAaIbxXYAAGsXA.jpg",
        "id_str" : "779151467731181568",
        "id" : 779151467731181568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtAaIbxXYAAGsXA.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/qjwyVcbBgI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779151474089664512",
    "text" : "New iPhone 7 Plus Portrait mode. https:\/\/t.co\/qjwyVcbBgI",
    "id" : 779151474089664512,
    "created_at" : "2016-09-23 02:52:42 +0000",
    "user" : {
      "name" : "Zak Santo",
      "screen_name" : "zsanto",
      "protected" : false,
      "id_str" : "15039224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701916437460471808\/BPZONYcU_normal.jpg",
      "id" : 15039224,
      "verified" : false
    }
  },
  "id" : 779517995601264641,
  "created_at" : "2016-09-24 03:09:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Panzarino",
      "screen_name" : "panzer",
      "indices" : [ 3, 10 ],
      "id_str" : "19312115",
      "id" : 19312115
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/panzer\/status\/778664356116516866\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ZDB7WfiKgb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5fGmpUsAAFasz.jpg",
      "id_str" : "778664352639397888",
      "id" : 778664352639397888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5fGmpUsAAFasz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ZDB7WfiKgb"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/panzer\/status\/778664356116516866\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ZDB7WfiKgb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5fGn8UkAARgmP.jpg",
      "id_str" : "778664352987516928",
      "id" : 778664352987516928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5fGn8UkAARgmP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ZDB7WfiKgb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517971169439745",
  "text" : "RT @panzer: Pet shots are going to be the sleeper hit of iPhone 7 Portrait mode. https:\/\/t.co\/ZDB7WfiKgb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/panzer\/status\/778664356116516866\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/ZDB7WfiKgb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5fGmpUsAAFasz.jpg",
        "id_str" : "778664352639397888",
        "id" : 778664352639397888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5fGmpUsAAFasz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZDB7WfiKgb"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/panzer\/status\/778664356116516866\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/ZDB7WfiKgb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5fGn8UkAARgmP.jpg",
        "id_str" : "778664352987516928",
        "id" : 778664352987516928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5fGn8UkAARgmP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZDB7WfiKgb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778664356116516866",
    "text" : "Pet shots are going to be the sleeper hit of iPhone 7 Portrait mode. https:\/\/t.co\/ZDB7WfiKgb",
    "id" : 778664356116516866,
    "created_at" : "2016-09-21 18:37:04 +0000",
    "user" : {
      "name" : "Matthew Panzarino",
      "screen_name" : "panzer",
      "protected" : false,
      "id_str" : "19312115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972174840017793024\/EBlzynRx_normal.jpg",
      "id" : 19312115,
      "verified" : true
    }
  },
  "id" : 779517971169439745,
  "created_at" : "2016-09-24 03:09:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Procter",
      "screen_name" : "andrewprocter",
      "indices" : [ 3, 17 ],
      "id_str" : "14339376",
      "id" : 14339376
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andrewprocter\/status\/778680436641849344\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/fURYBtfBJ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5tuHbVMAAK8mN.jpg",
      "id_str" : "778680424616767488",
      "id" : 778680424616767488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5tuHbVMAAK8mN.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fURYBtfBJ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517952672600064",
  "text" : "RT @andrewprocter: Here\u2019s the first test shot I took using the new portrait mode on the iPhone 7 Plus https:\/\/t.co\/fURYBtfBJ8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andrewprocter\/status\/778680436641849344\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/fURYBtfBJ8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs5tuHbVMAAK8mN.jpg",
        "id_str" : "778680424616767488",
        "id" : 778680424616767488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs5tuHbVMAAK8mN.jpg",
        "sizes" : [ {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fURYBtfBJ8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778680436641849344",
    "text" : "Here\u2019s the first test shot I took using the new portrait mode on the iPhone 7 Plus https:\/\/t.co\/fURYBtfBJ8",
    "id" : 778680436641849344,
    "created_at" : "2016-09-21 19:40:57 +0000",
    "user" : {
      "name" : "Andrew Procter",
      "screen_name" : "andrewprocter",
      "protected" : false,
      "id_str" : "14339376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423924690646618112\/dx6etd2V_normal.png",
      "id" : 14339376,
      "verified" : false
    }
  },
  "id" : 779517952672600064,
  "created_at" : "2016-09-24 03:08:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Mayo",
      "screen_name" : "bzamayo",
      "indices" : [ 3, 11 ],
      "id_str" : "167398227",
      "id" : 167398227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517836712640512",
  "text" : "RT @bzamayo: Chris Ziegler wanted a new MacBook Pro so bad he got a job at Apple, stole the prototypes and rode off into the sunset.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779430152619032576",
    "text" : "Chris Ziegler wanted a new MacBook Pro so bad he got a job at Apple, stole the prototypes and rode off into the sunset.",
    "id" : 779430152619032576,
    "created_at" : "2016-09-23 21:20:04 +0000",
    "user" : {
      "name" : "Benjamin Mayo",
      "screen_name" : "bzamayo",
      "protected" : false,
      "id_str" : "167398227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792027112689590272\/YC6y24Lk_normal.jpg",
      "id" : 167398227,
      "verified" : true
    }
  },
  "id" : 779517836712640512,
  "created_at" : "2016-09-24 03:08:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Nuzzi",
      "screen_name" : "Olivianuzzi",
      "indices" : [ 3, 15 ],
      "id_str" : "21212087",
      "id" : 21212087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517752054784000",
  "text" : "RT @Olivianuzzi: the Verge\/Apple thing is not entirely dissimilar to the Lewandowski situation, though the stakes are much higher w\/ the la\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779421720428081154",
    "text" : "the Verge\/Apple thing is not entirely dissimilar to the Lewandowski situation, though the stakes are much higher w\/ the latter",
    "id" : 779421720428081154,
    "created_at" : "2016-09-23 20:46:33 +0000",
    "user" : {
      "name" : "Olivia Nuzzi",
      "screen_name" : "Olivianuzzi",
      "protected" : false,
      "id_str" : "21212087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/978923150619631617\/O8ZSm2sK_normal.jpg",
      "id" : 21212087,
      "verified" : false
    }
  },
  "id" : 779517752054784000,
  "created_at" : "2016-09-24 03:08:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doree Shafrir",
      "screen_name" : "doree",
      "indices" : [ 3, 9 ],
      "id_str" : "15129069",
      "id" : 15129069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517697411452928",
  "text" : "RT @doree: I want the confidence of a guy who takes a conflict of interest job while keeping his original job &amp; then disappears",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779421647732297728",
    "geo" : { },
    "id_str" : "779421918256435200",
    "in_reply_to_user_id" : 15129069,
    "text" : "I want the confidence of a guy who takes a conflict of interest job while keeping his original job &amp; then disappears",
    "id" : 779421918256435200,
    "in_reply_to_status_id" : 779421647732297728,
    "created_at" : "2016-09-23 20:47:20 +0000",
    "in_reply_to_screen_name" : "doree",
    "in_reply_to_user_id_str" : "15129069",
    "user" : {
      "name" : "Doree Shafrir",
      "screen_name" : "doree",
      "protected" : false,
      "id_str" : "15129069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817197818544734208\/LKZSgsD5_normal.jpg",
      "id" : 15129069,
      "verified" : true
    }
  },
  "id" : 779517697411452928,
  "created_at" : "2016-09-24 03:07:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS Food",
      "screen_name" : "PBSFood",
      "indices" : [ 3, 11 ],
      "id_str" : "104257930",
      "id" : 104257930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/kbE3VCSedy",
      "expanded_url" : "http:\/\/to.pbs.org\/1KpRMcy",
      "display_url" : "to.pbs.org\/1KpRMcy"
    } ]
  },
  "geo" : { },
  "id_str" : "779517275175018496",
  "text" : "RT @PBSFood: Use passion mango to create a tart, but sweet spread https:\/\/t.co\/kbE3VCSedy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/kbE3VCSedy",
        "expanded_url" : "http:\/\/to.pbs.org\/1KpRMcy",
        "display_url" : "to.pbs.org\/1KpRMcy"
      } ]
    },
    "geo" : { },
    "id_str" : "779516230449389569",
    "text" : "Use passion mango to create a tart, but sweet spread https:\/\/t.co\/kbE3VCSedy",
    "id" : 779516230449389569,
    "created_at" : "2016-09-24 03:02:06 +0000",
    "user" : {
      "name" : "PBS Food",
      "screen_name" : "PBSFood",
      "protected" : false,
      "id_str" : "104257930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875439483344359424\/9nx10jzb_normal.jpg",
      "id" : 104257930,
      "verified" : true
    }
  },
  "id" : 779517275175018496,
  "created_at" : "2016-09-24 03:06:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "retrapped",
      "indices" : [ 17, 27 ],
      "id_str" : "1978830270",
      "id" : 1978830270
    }, {
      "name" : "Ben",
      "screen_name" : "bleakful",
      "indices" : [ 28, 37 ],
      "id_str" : "3223196976",
      "id" : 3223196976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517111421038593",
  "text" : "RT @doniezamary: @retrapped @bleakful very true\uD83D\uDE07",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : ".",
        "screen_name" : "retrapped",
        "indices" : [ 0, 10 ],
        "id_str" : "1978830270",
        "id" : 1978830270
      }, {
        "name" : "Ben",
        "screen_name" : "bleakful",
        "indices" : [ 11, 20 ],
        "id_str" : "3223196976",
        "id" : 3223196976
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779316503275376640",
    "geo" : { },
    "id_str" : "779346441303105537",
    "in_reply_to_user_id" : 1978830270,
    "text" : "@retrapped @bleakful very true\uD83D\uDE07",
    "id" : 779346441303105537,
    "in_reply_to_status_id" : 779316503275376640,
    "created_at" : "2016-09-23 15:47:25 +0000",
    "in_reply_to_screen_name" : "retrapped",
    "in_reply_to_user_id_str" : "1978830270",
    "user" : {
      "name" : "M.",
      "screen_name" : "lovetobeluv",
      "protected" : false,
      "id_str" : "751164511751659520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/986864119478407168\/uXASBETv_normal.jpg",
      "id" : 751164511751659520,
      "verified" : false
    }
  },
  "id" : 779517111421038593,
  "created_at" : "2016-09-24 03:05:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779517004411703296",
  "text" : "RT @BONNIELYNN2015: So how are you tweets?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779340283309727744",
    "text" : "So how are you tweets?",
    "id" : 779340283309727744,
    "created_at" : "2016-09-23 15:22:57 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "Bonnielynnmarie",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993229851543949312\/JGTDc1K6_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 779517004411703296,
  "created_at" : "2016-09-24 03:05:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "indices" : [ 3, 16 ],
      "id_str" : "474231541",
      "id" : 474231541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779516610344325120",
  "text" : "RT @ImYoungChizz: How do you pick and choose which videos to release to the public?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779346245315915776",
    "text" : "How do you pick and choose which videos to release to the public?",
    "id" : 779346245315915776,
    "created_at" : "2016-09-23 15:46:39 +0000",
    "user" : {
      "name" : "Young Chizz",
      "screen_name" : "ImYoungChizz",
      "protected" : false,
      "id_str" : "474231541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915547694705324033\/shK07ykL_normal.jpg",
      "id" : 474231541,
      "verified" : true
    }
  },
  "id" : 779516610344325120,
  "created_at" : "2016-09-24 03:03:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RangerSyl",
      "screen_name" : "RangerSyl",
      "indices" : [ 3, 13 ],
      "id_str" : "8150772",
      "id" : 8150772
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 15, 27 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779516460112773120",
  "text" : "RT @RangerSyl: @KassyDillon Am I the only one seeing Hillary's (promoted) birthday card in their feed? She's paying to get people to wish h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779350847545237505",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon Am I the only one seeing Hillary's (promoted) birthday card in their feed? She's paying to get people to wish her happy b-day?",
    "id" : 779350847545237505,
    "created_at" : "2016-09-23 16:04:56 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "RangerSyl",
      "screen_name" : "RangerSyl",
      "protected" : false,
      "id_str" : "8150772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827033144268251137\/tB-QsXFg_normal.jpg",
      "id" : 8150772,
      "verified" : false
    }
  },
  "id" : 779516460112773120,
  "created_at" : "2016-09-24 03:03:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Kerry Davis",
      "screen_name" : "mskerryd",
      "indices" : [ 74, 83 ],
      "id_str" : "176605257",
      "id" : 176605257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779353534135361536\/video\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/PsLUMIk7e5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDR5yJVMAAJmQ6.jpg",
      "id_str" : "779353157809745920",
      "id" : 779353157809745920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDR5yJVMAAJmQ6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PsLUMIk7e5"
    } ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/n1XwQyFjbz",
      "expanded_url" : "http:\/\/engt.co\/2cRKhnm",
      "display_url" : "engt.co\/2cRKhnm"
    } ]
  },
  "geo" : { },
  "id_str" : "779516417767006209",
  "text" : "RT @engadget: #ICYMI: All aboard the hydrogen fuel cell train and more by @mskerryd https:\/\/t.co\/n1XwQyFjbz https:\/\/t.co\/PsLUMIk7e5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kerry Davis",
        "screen_name" : "mskerryd",
        "indices" : [ 60, 69 ],
        "id_str" : "176605257",
        "id" : 176605257
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779353534135361536\/video\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/PsLUMIk7e5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDR5yJVMAAJmQ6.jpg",
        "id_str" : "779353157809745920",
        "id" : 779353157809745920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDR5yJVMAAJmQ6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/PsLUMIk7e5"
      } ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/n1XwQyFjbz",
        "expanded_url" : "http:\/\/engt.co\/2cRKhnm",
        "display_url" : "engt.co\/2cRKhnm"
      } ]
    },
    "geo" : { },
    "id_str" : "779353534135361536",
    "text" : "#ICYMI: All aboard the hydrogen fuel cell train and more by @mskerryd https:\/\/t.co\/n1XwQyFjbz https:\/\/t.co\/PsLUMIk7e5",
    "id" : 779353534135361536,
    "created_at" : "2016-09-23 16:15:36 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779516417767006209,
  "created_at" : "2016-09-24 03:02:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "indices" : [ 3, 18 ],
      "id_str" : "78523300",
      "id" : 78523300
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScreechingHillary",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/hWj859vxeH",
      "expanded_url" : "https:\/\/twitter.com\/dbloom451\/status\/779095788626542592",
      "display_url" : "twitter.com\/dbloom451\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779516388776050688",
  "text" : "RT @RealJamesWoods: Oh, this explains it. The switch was set wrong... #ScreechingHillary https:\/\/t.co\/hWj859vxeH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScreechingHillary",
        "indices" : [ 50, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/hWj859vxeH",
        "expanded_url" : "https:\/\/twitter.com\/dbloom451\/status\/779095788626542592",
        "display_url" : "twitter.com\/dbloom451\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779142904514162688",
    "text" : "Oh, this explains it. The switch was set wrong... #ScreechingHillary https:\/\/t.co\/hWj859vxeH",
    "id" : 779142904514162688,
    "created_at" : "2016-09-23 02:18:38 +0000",
    "user" : {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "protected" : false,
      "id_str" : "78523300",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796482667340382211\/CoV8077b_normal.jpg",
      "id" : 78523300,
      "verified" : true
    }
  },
  "id" : 779516388776050688,
  "created_at" : "2016-09-24 03:02:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/779400819359752192\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/s3SOqJeQeN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtD86ekWYAQiUXf.jpg",
      "id_str" : "779400817103233028",
      "id" : 779400817103233028,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtD86ekWYAQiUXf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 700
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/s3SOqJeQeN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779516217740648448",
  "text" : "RT @rockindigo: Who else remembers this game? omg so much memories https:\/\/t.co\/s3SOqJeQeN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/779400819359752192\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/s3SOqJeQeN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtD86ekWYAQiUXf.jpg",
        "id_str" : "779400817103233028",
        "id" : 779400817103233028,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtD86ekWYAQiUXf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 700
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/s3SOqJeQeN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779400819359752192",
    "text" : "Who else remembers this game? omg so much memories https:\/\/t.co\/s3SOqJeQeN",
    "id" : 779400819359752192,
    "created_at" : "2016-09-23 19:23:30 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 779516217740648448,
  "created_at" : "2016-09-24 03:02:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "indices" : [ 3, 16 ],
      "id_str" : "65691824",
      "id" : 65691824
    }, {
      "name" : "Jenniffer Gonz\u00E1lez",
      "screen_name" : "Jenniffer2012",
      "indices" : [ 50, 64 ],
      "id_str" : "400246874",
      "id" : 400246874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779516155283247104",
  "text" : "RT @CarlyFiorina: Puerto Rico needs a leader like @Jenniffer2012 in Washington. Here's why I endorse her for Resident Commissioner: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jenniffer Gonz\u00E1lez",
        "screen_name" : "Jenniffer2012",
        "indices" : [ 32, 46 ],
        "id_str" : "400246874",
        "id" : 400246874
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CarlyFiorina\/status\/779425127393918976\/video\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Y5LBdSvdue",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/779423878942633985\/img\/dAT6j-qna8GNM2NU.jpg",
        "id_str" : "779423878942633985",
        "id" : 779423878942633985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/779423878942633985\/img\/dAT6j-qna8GNM2NU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Y5LBdSvdue"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779425127393918976",
    "text" : "Puerto Rico needs a leader like @Jenniffer2012 in Washington. Here's why I endorse her for Resident Commissioner: https:\/\/t.co\/Y5LBdSvdue",
    "id" : 779425127393918976,
    "created_at" : "2016-09-23 21:00:06 +0000",
    "user" : {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "protected" : false,
      "id_str" : "65691824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866712323465019393\/i8xgZfsF_normal.jpg",
      "id" : 65691824,
      "verified" : true
    }
  },
  "id" : 779516155283247104,
  "created_at" : "2016-09-24 03:01:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LPCO Klassic Rock",
      "screen_name" : "LPCORockRadio",
      "indices" : [ 3, 17 ],
      "id_str" : "4917336634",
      "id" : 4917336634
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classicrock",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "klassicrock",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "rocknroll",
      "indices" : [ 100, 110 ]
    }, {
      "text" : "blues",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "onlineradio",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515933429788672",
  "text" : "RT @LPCORockRadio: Lynyrd Skynyrd singin' That Smell on LPCO Klassic Rock #classicrock #klassicrock #rocknroll #blues #onlineradio https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/share.radionomy.com\" rel=\"nofollow\"\u003EShare.Radionomy.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "classicrock",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "klassicrock",
        "indices" : [ 68, 80 ]
      }, {
        "text" : "rocknroll",
        "indices" : [ 81, 91 ]
      }, {
        "text" : "blues",
        "indices" : [ 92, 98 ]
      }, {
        "text" : "onlineradio",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/9GOA4lRU04",
        "expanded_url" : "http:\/\/www.radionomy.com\/lpcoklassicrock",
        "display_url" : "radionomy.com\/lpcoklassicrock"
      } ]
    },
    "geo" : { },
    "id_str" : "775975799631511552",
    "text" : "Lynyrd Skynyrd singin' That Smell on LPCO Klassic Rock #classicrock #klassicrock #rocknroll #blues #onlineradio https:\/\/t.co\/9GOA4lRU04",
    "id" : 775975799631511552,
    "created_at" : "2016-09-14 08:33:42 +0000",
    "user" : {
      "name" : "LPCO Klassic Rock",
      "screen_name" : "LPCORockRadio",
      "protected" : false,
      "id_str" : "4917336634",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/864867913207087104\/fTz82GjA_normal.jpg",
      "id" : 4917336634,
      "verified" : false
    }
  },
  "id" : 779515933429788672,
  "created_at" : "2016-09-24 03:00:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birthday",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "70sMusic",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "classicrock",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "bands",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515830480543744",
  "text" : "RT @Wanna_B_Brit: #birthday #70sMusic #classicrock #bands. Sept 14: Happy birthday to musician Craig Montoya (Everclear) is 46yrs old. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wanna_B_Brit\/status\/775987746393427969\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/fOQfTf4ulp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsTcu2EXEAAxWlc.jpg",
        "id_str" : "775987733160464384",
        "id" : 775987733160464384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsTcu2EXEAAxWlc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 220
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fOQfTf4ulp"
      } ],
      "hashtags" : [ {
        "text" : "birthday",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "70sMusic",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "classicrock",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "bands",
        "indices" : [ 33, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775987746393427969",
    "text" : "#birthday #70sMusic #classicrock #bands. Sept 14: Happy birthday to musician Craig Montoya (Everclear) is 46yrs old. https:\/\/t.co\/fOQfTf4ulp",
    "id" : 775987746393427969,
    "created_at" : "2016-09-14 09:21:10 +0000",
    "user" : {
      "name" : "Daniel Davis",
      "screen_name" : "Music_News_Guy",
      "protected" : false,
      "id_str" : "4605409974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813344196203573248\/XUU3ysDs_normal.jpg",
      "id" : 4605409974,
      "verified" : false
    }
  },
  "id" : 779515830480543744,
  "created_at" : "2016-09-24 03:00:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THIS DAY IN METAL",
      "screen_name" : "ThisDayInMETAL",
      "indices" : [ 3, 18 ],
      "id_str" : "743472216",
      "id" : 743472216
    }, {
      "name" : "David Coverdale",
      "screen_name" : "davidcoverdale",
      "indices" : [ 35, 50 ],
      "id_str" : "166665318",
      "id" : 166665318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Whitesnake",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "HappyBirthday",
      "indices" : [ 85, 99 ]
    }, {
      "text" : "ClassicRock",
      "indices" : [ 100, 112 ]
    }, {
      "text" : "HeavyMetal",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515635781013504",
  "text" : "RT @ThisDayInMETAL: Sept 22nd 1951 @davidcoverdale singer with #Whitesnake was born! #HappyBirthday #ClassicRock #HeavyMetal https:\/\/t.co\/O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Coverdale",
        "screen_name" : "davidcoverdale",
        "indices" : [ 15, 30 ],
        "id_str" : "166665318",
        "id" : 166665318
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThisDayInMETAL\/status\/778967262380298240\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/OAPBaoJHCg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9yl57WgAANLfk.jpg",
        "id_str" : "778967256088870912",
        "id" : 778967256088870912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9yl57WgAANLfk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 243
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 243
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 243
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 243
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/OAPBaoJHCg"
      } ],
      "hashtags" : [ {
        "text" : "Whitesnake",
        "indices" : [ 43, 54 ]
      }, {
        "text" : "HappyBirthday",
        "indices" : [ 65, 79 ]
      }, {
        "text" : "ClassicRock",
        "indices" : [ 80, 92 ]
      }, {
        "text" : "HeavyMetal",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778967262380298240",
    "text" : "Sept 22nd 1951 @davidcoverdale singer with #Whitesnake was born! #HappyBirthday #ClassicRock #HeavyMetal https:\/\/t.co\/OAPBaoJHCg",
    "id" : 778967262380298240,
    "created_at" : "2016-09-22 14:40:42 +0000",
    "user" : {
      "name" : "THIS DAY IN METAL",
      "screen_name" : "ThisDayInMETAL",
      "protected" : false,
      "id_str" : "743472216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/945894126842609664\/gcaonNJf_normal.jpg",
      "id" : 743472216,
      "verified" : false
    }
  },
  "id" : 779515635781013504,
  "created_at" : "2016-09-24 02:59:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bobarev",
      "screen_name" : "michaelbobarev",
      "indices" : [ 3, 18 ],
      "id_str" : "72932077",
      "id" : 72932077
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 20, 29 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515490884546561",
  "text" : "RT @michaelbobarev: @engadget ...external monitor :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779418515799412737",
    "geo" : { },
    "id_str" : "779421407130320898",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget ...external monitor :)",
    "id" : 779421407130320898,
    "in_reply_to_status_id" : 779418515799412737,
    "created_at" : "2016-09-23 20:45:19 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "Michael Bobarev",
      "screen_name" : "michaelbobarev",
      "protected" : false,
      "id_str" : "72932077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/871728624440938496\/Hy9o4C4Y_normal.jpg",
      "id" : 72932077,
      "verified" : false
    }
  },
  "id" : 779515490884546561,
  "created_at" : "2016-09-24 02:59:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Wirecutter",
      "screen_name" : "wirecutter",
      "indices" : [ 66, 77 ],
      "id_str" : "366309158",
      "id" : 366309158
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779458960915046400\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/6pcwwEPw74",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtExyvnWgAUm9oF.jpg",
      "id_str" : "779458958356545541",
      "id" : 779458958356545541,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtExyvnWgAUm9oF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/6pcwwEPw74"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/0HBsdhF8d1",
      "expanded_url" : "http:\/\/engt.co\/2dgMRTI",
      "display_url" : "engt.co\/2dgMRTI"
    } ]
  },
  "geo" : { },
  "id_str" : "779515364703145984",
  "text" : "RT @engadget: The best laptop stands https:\/\/t.co\/0HBsdhF8d1 (via @Wirecutter) https:\/\/t.co\/6pcwwEPw74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wirecutter",
        "screen_name" : "wirecutter",
        "indices" : [ 52, 63 ],
        "id_str" : "366309158",
        "id" : 366309158
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779458960915046400\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/6pcwwEPw74",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtExyvnWgAUm9oF.jpg",
        "id_str" : "779458958356545541",
        "id" : 779458958356545541,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtExyvnWgAUm9oF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/6pcwwEPw74"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/0HBsdhF8d1",
        "expanded_url" : "http:\/\/engt.co\/2dgMRTI",
        "display_url" : "engt.co\/2dgMRTI"
      } ]
    },
    "geo" : { },
    "id_str" : "779458960915046400",
    "text" : "The best laptop stands https:\/\/t.co\/0HBsdhF8d1 (via @Wirecutter) https:\/\/t.co\/6pcwwEPw74",
    "id" : 779458960915046400,
    "created_at" : "2016-09-23 23:14:32 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779515364703145984,
  "created_at" : "2016-09-24 02:58:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 21, 30 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515282486419456",
  "text" : "RT @RefreshngClorox: @engadget Why is he filming at some little kid... I can see through the reflection",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779513025434882048",
    "geo" : { },
    "id_str" : "779513334437511168",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget Why is he filming at some little kid... I can see through the reflection",
    "id" : 779513334437511168,
    "in_reply_to_status_id" : 779513025434882048,
    "created_at" : "2016-09-24 02:50:36 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "Pizza pasta nigga",
      "screen_name" : "NeonSoakedTokyo",
      "protected" : false,
      "id_str" : "2578180728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991864061062103040\/yiqy_gpA_normal.jpg",
      "id" : 2578180728,
      "verified" : false
    }
  },
  "id" : 779515282486419456,
  "created_at" : "2016-09-24 02:58:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YAF",
      "screen_name" : "yaf",
      "indices" : [ 3, 7 ],
      "id_str" : "16148677",
      "id" : 16148677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2Nr15lyJ09",
      "expanded_url" : "http:\/\/www.yaf.org\/news\/video-leftists-invade-ku-yaf-meeting\/",
      "display_url" : "yaf.org\/news\/video-lef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779515126567305216",
  "text" : "RT @yaf: One leftist completely exploded, screaming, \u201CDo not call us guys! That is a micro aggression!\u201D https:\/\/t.co\/2Nr15lyJ09",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/2Nr15lyJ09",
        "expanded_url" : "http:\/\/www.yaf.org\/news\/video-leftists-invade-ku-yaf-meeting\/",
        "display_url" : "yaf.org\/news\/video-lef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779336316647567360",
    "text" : "One leftist completely exploded, screaming, \u201CDo not call us guys! That is a micro aggression!\u201D https:\/\/t.co\/2Nr15lyJ09",
    "id" : 779336316647567360,
    "created_at" : "2016-09-23 15:07:11 +0000",
    "user" : {
      "name" : "YAF",
      "screen_name" : "yaf",
      "protected" : false,
      "id_str" : "16148677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682327485619519488\/kjO5knmV_normal.jpg",
      "id" : 16148677,
      "verified" : true
    }
  },
  "id" : 779515126567305216,
  "created_at" : "2016-09-24 02:57:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515099514081280",
  "text" : "RT @lorenridinger: \"Sometimes the greatest thing to come out of all your hard work isn't what you get for it, but what you become for it.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779364980873363456",
    "text" : "\"Sometimes the greatest thing to come out of all your hard work isn't what you get for it, but what you become for it.\"",
    "id" : 779364980873363456,
    "created_at" : "2016-09-23 17:01:05 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 779515099514081280,
  "created_at" : "2016-09-24 02:57:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Skittles",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/qu5nlUfBRt",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
      "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779515066140033024",
  "text" : "RT @scrowder: CEO of #Skittles has finally released a statement regarding its recent scandal! FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/779371052979908608\/video\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/BKGKdpDqSa",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779371000253349888\/pu\/img\/3QdFDGoBaV_wZVGw.jpg",
        "id_str" : "779371000253349888",
        "id" : 779371000253349888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779371000253349888\/pu\/img\/3QdFDGoBaV_wZVGw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/BKGKdpDqSa"
      } ],
      "hashtags" : [ {
        "text" : "Skittles",
        "indices" : [ 7, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/qu5nlUfBRt",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
        "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779371052979908608",
    "text" : "CEO of #Skittles has finally released a statement regarding its recent scandal! FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/t.co\/BKGKdpDqSa",
    "id" : 779371052979908608,
    "created_at" : "2016-09-23 17:25:13 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 779515066140033024,
  "created_at" : "2016-09-24 02:57:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779515018316505088",
  "text" : "RT @CopticOrphans: \"And he lifted up his eyes on his disciples, and said: Blessed are you who are poor, for yours is the kingdom of God.\" h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CopticOrphans\/status\/779424013936386052\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/qSpYgJdSXu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtESABsUkAE978p.jpg",
        "id_str" : "779424002175438849",
        "id" : 779424002175438849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtESABsUkAE978p.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/qSpYgJdSXu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779424013936386052",
    "text" : "\"And he lifted up his eyes on his disciples, and said: Blessed are you who are poor, for yours is the kingdom of God.\" https:\/\/t.co\/qSpYgJdSXu",
    "id" : 779424013936386052,
    "created_at" : "2016-09-23 20:55:40 +0000",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 779515018316505088,
  "created_at" : "2016-09-24 02:57:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514909537210369",
  "text" : "RT @seanhannity: Dr. Carson on running for pres: \"I was hoping there was someone who had the same values...who could withstand terrible cor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779512444339093504",
    "text" : "Dr. Carson on running for pres: \"I was hoping there was someone who had the same values...who could withstand terrible corruption of system\"",
    "id" : 779512444339093504,
    "created_at" : "2016-09-24 02:47:04 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 779514909537210369,
  "created_at" : "2016-09-24 02:56:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514874795810816",
  "text" : "RT @BarbaraCorcoran: The worst entrepreneurs on Shark Tank were great presenters with MBAs. I never got the feeling they would be good unde\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779398898507014144",
    "text" : "The worst entrepreneurs on Shark Tank were great presenters with MBAs. I never got the feeling they would be good under real-life pressure.",
    "id" : 779398898507014144,
    "created_at" : "2016-09-23 19:15:52 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 779514874795810816,
  "created_at" : "2016-09-24 02:56:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514850481475584",
  "text" : "RT @seanhannity: Don King: \"Whatever we see, right, wrong or indifferent, If the system don't change, it's going to be the same.\" #Hannity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779507921499545603",
    "text" : "Don King: \"Whatever we see, right, wrong or indifferent, If the system don't change, it's going to be the same.\" #Hannity",
    "id" : 779507921499545603,
    "created_at" : "2016-09-24 02:29:05 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 779514850481475584,
  "created_at" : "2016-09-24 02:56:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514549280075776",
  "text" : "RT @hannahbleau_: @gamer456148 aw I'm flattered! You have a great day too! \uD83D\uDE01\uD83C\uDDFA\uD83C\uDDF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629295997781438464",
    "geo" : { },
    "id_str" : "629355497607589888",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 aw I'm flattered! You have a great day too! \uD83D\uDE01\uD83C\uDDFA\uD83C\uDDF8",
    "id" : 629355497607589888,
    "in_reply_to_status_id" : 629295997781438464,
    "created_at" : "2015-08-06 18:16:58 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 779514549280075776,
  "created_at" : "2016-09-24 02:55:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 3, 15 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 50, 62 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Adobe",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LiZjgCzHn9",
      "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/XO6xE",
      "display_url" : "ln.is\/www.coupontrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779514495110643716",
  "text" : "RT @CouponTrump: Intro to #Adobe CC 2014 Udemy by @gamer456148  Was $9 Now FREE! http:\/\/t.co\/LiZjgCzHn9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 33, 45 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Adobe",
        "indices" : [ 9, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/LiZjgCzHn9",
        "expanded_url" : "http:\/\/ln.is\/www.coupontrump.com\/XO6xE",
        "display_url" : "ln.is\/www.coupontrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643417797092057089",
    "text" : "Intro to #Adobe CC 2014 Udemy by @gamer456148  Was $9 Now FREE! http:\/\/t.co\/LiZjgCzHn9",
    "id" : 643417797092057089,
    "created_at" : "2015-09-14 13:35:31 +0000",
    "user" : {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "protected" : false,
      "id_str" : "2370179022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440431681262993408\/NQv9HIql_normal.png",
      "id" : 2370179022,
      "verified" : false
    }
  },
  "id" : 779514495110643716,
  "created_at" : "2016-09-24 02:55:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland U Student",
      "screen_name" : "An_OU_Student",
      "indices" : [ 3, 17 ],
      "id_str" : "2900716968",
      "id" : 2900716968
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514407944593408",
  "text" : "RT @An_OU_Student: @gamer456148 yes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "658835364786868224",
    "geo" : { },
    "id_str" : "659012034084909056",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 yes.",
    "id" : 659012034084909056,
    "in_reply_to_status_id" : 658835364786868224,
    "created_at" : "2015-10-27 14:21:27 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Oakland U Student",
      "screen_name" : "An_OU_Student",
      "protected" : false,
      "id_str" : "2900716968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819996902766874624\/GI1fJvEF_normal.jpg",
      "id" : 2900716968,
      "verified" : false
    }
  },
  "id" : 779514407944593408,
  "created_at" : "2016-09-24 02:54:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 3, 16 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514225987293184",
  "text" : "RT @LinkedInHelp: @gamer456148 That is definitely understandable. We'll pass this suggestion on to our team! -jlk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672147796322029570",
    "geo" : { },
    "id_str" : "672152818258702336",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 That is definitely understandable. We'll pass this suggestion on to our team! -jlk",
    "id" : 672152818258702336,
    "in_reply_to_status_id" : 672147796322029570,
    "created_at" : "2015-12-02 20:38:14 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "protected" : false,
      "id_str" : "252792134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991135365988667392\/JXDDdlqf_normal.jpg",
      "id" : 252792134,
      "verified" : true
    }
  },
  "id" : 779514225987293184,
  "created_at" : "2016-09-24 02:54:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "indices" : [ 3, 14 ],
      "id_str" : "1685698238",
      "id" : 1685698238
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514213983219712",
  "text" : "RT @PHPSimplex: @gamer456148 until you understand well the methodology. Then it's very easy (only simple operations) and doesn't waste much\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672792515981025281",
    "geo" : { },
    "id_str" : "672905659072053248",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 until you understand well the methodology. Then it's very easy (only simple operations) and doesn't waste much time.",
    "id" : 672905659072053248,
    "in_reply_to_status_id" : 672792515981025281,
    "created_at" : "2015-12-04 22:29:45 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "protected" : false,
      "id_str" : "1685698238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000328895370\/ac13e7a886c26f645af34c01324f00ab_normal.png",
      "id" : 1685698238,
      "verified" : false
    }
  },
  "id" : 779514213983219712,
  "created_at" : "2016-09-24 02:54:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UKC",
      "screen_name" : "ukchelpdesk",
      "indices" : [ 3, 15 ],
      "id_str" : "397906754",
      "id" : 397906754
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514195821854720",
  "text" : "RT @ukchelpdesk: @gamer456148 Thank you! It's looking popular, and a surprise, we (wrongly) thought the 1st option would win by a mile :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "674298996286992388",
    "geo" : { },
    "id_str" : "674299605857804288",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Thank you! It's looking popular, and a surprise, we (wrongly) thought the 1st option would win by a mile :D",
    "id" : 674299605857804288,
    "in_reply_to_status_id" : 674298996286992388,
    "created_at" : "2015-12-08 18:48:48 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "UKC",
      "screen_name" : "ukchelpdesk",
      "protected" : false,
      "id_str" : "397906754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676037588549894144\/yiEjT0oY_normal.png",
      "id" : 397906754,
      "verified" : false
    }
  },
  "id" : 779514195821854720,
  "created_at" : "2016-09-24 02:54:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514158438121472",
  "text" : "RT @hannahbleau_: @gamer456148 I'm with you on that one.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "690758328431996928",
    "geo" : { },
    "id_str" : "691010171489771520",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I'm with you on that one.",
    "id" : 691010171489771520,
    "in_reply_to_status_id" : 690758328431996928,
    "created_at" : "2016-01-23 21:30:37 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 779514158438121472,
  "created_at" : "2016-09-24 02:53:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 3, 9 ],
      "id_str" : "70266297",
      "id" : 70266297
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 11, 23 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RkNNK5Cr3E",
      "expanded_url" : "http:\/\/bit.ly\/1TQ28Xi",
      "display_url" : "bit.ly\/1TQ28Xi"
    } ]
  },
  "geo" : { },
  "id_str" : "779514142684217344",
  "text" : "RT @udemy: @gamer456148 We understand this is a big change. You can find more information on our Teach Hub here: https:\/\/t.co\/RkNNK5Cr3E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/RkNNK5Cr3E",
        "expanded_url" : "http:\/\/bit.ly\/1TQ28Xi",
        "display_url" : "bit.ly\/1TQ28Xi"
      } ]
    },
    "in_reply_to_status_id_str" : "705106037146144769",
    "geo" : { },
    "id_str" : "705107353193078785",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 We understand this is a big change. You can find more information on our Teach Hub here: https:\/\/t.co\/RkNNK5Cr3E",
    "id" : 705107353193078785,
    "in_reply_to_status_id" : 705106037146144769,
    "created_at" : "2016-03-02 19:07:47 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "protected" : false,
      "id_str" : "70266297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923671662536531969\/oXlPsa_W_normal.jpg",
      "id" : 70266297,
      "verified" : true
    }
  },
  "id" : 779514142684217344,
  "created_at" : "2016-09-24 02:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 3, 13 ],
      "id_str" : "618294231",
      "id" : 618294231
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514105996668928",
  "text" : "RT @_grammar_: @gamer456148, it might be better if you had said \u201Cmention [there] is only a\u201D instead. \u2018Their\u2019 belongs to \u2018them\u2019.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/Your_Grammar\" rel=\"nofollow\"\u003Emagical magic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "705116573816614916",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 68.417839516385, 110.270070088366 ]
    },
    "id_str" : "705117485549260800",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148, it might be better if you had said \u201Cmention [there] is only a\u201D instead. \u2018Their\u2019 belongs to \u2018them\u2019.",
    "id" : 705117485549260800,
    "in_reply_to_status_id" : 705116573816614916,
    "created_at" : "2016-03-02 19:48:03 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "protected" : false,
      "id_str" : "618294231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785169027169521664\/j5rftldn_normal.png",
      "id" : 618294231,
      "verified" : false
    }
  },
  "id" : 779514105996668928,
  "created_at" : "2016-09-24 02:53:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 3, 9 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 11, 23 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514087382278144",
  "text" : "RT @klout: @gamer456148 Hi there- thanks for reaching out. Understand your disappointment. We're investing in other areas of Klout's data a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "723237018193506304",
    "geo" : { },
    "id_str" : "723422887659499520",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Hi there- thanks for reaching out. Understand your disappointment. We're investing in other areas of Klout's data assets. Thx!",
    "id" : 723422887659499520,
    "in_reply_to_status_id" : 723237018193506304,
    "created_at" : "2016-04-22 08:07:11 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Klout",
      "screen_name" : "klout",
      "protected" : false,
      "id_str" : "15134782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475053521167847424\/ddqeQG36_normal.png",
      "id" : 15134782,
      "verified" : true
    }
  },
  "id" : 779514087382278144,
  "created_at" : "2016-09-24 02:53:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "indices" : [ 3, 12 ],
      "id_str" : "33522196",
      "id" : 33522196
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 14, 26 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514068067581952",
  "text" : "RT @Gillette: @gamer456148 We appreciate the love. Thanks for shaving with us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "725380295961223168",
    "geo" : { },
    "id_str" : "725382900401754112",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 We appreciate the love. Thanks for shaving with us.",
    "id" : 725382900401754112,
    "in_reply_to_status_id" : 725380295961223168,
    "created_at" : "2016-04-27 17:55:35 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Gillette",
      "screen_name" : "Gillette",
      "protected" : false,
      "id_str" : "33522196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2726313129\/bad2b44647d8321cd90f65ef162975a5_normal.png",
      "id" : 33522196,
      "verified" : true
    }
  },
  "id" : 779514068067581952,
  "created_at" : "2016-09-24 02:53:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 3, 16 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779514057686679552",
  "text" : "RT @LinkedInHelp: @gamer456148 Thanks for the feedback on this. We'll definitely forward it along. -jlk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "726956792874340352",
    "geo" : { },
    "id_str" : "727061389865525248",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Thanks for the feedback on this. We'll definitely forward it along. -jlk",
    "id" : 727061389865525248,
    "in_reply_to_status_id" : 726956792874340352,
    "created_at" : "2016-05-02 09:05:18 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "protected" : false,
      "id_str" : "252792134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991135365988667392\/JXDDdlqf_normal.jpg",
      "id" : 252792134,
      "verified" : true
    }
  },
  "id" : 779514057686679552,
  "created_at" : "2016-09-24 02:53:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janelle Ambrose",
      "screen_name" : "literal_janelle",
      "indices" : [ 3, 19 ],
      "id_str" : "4454704398",
      "id" : 4454704398
    }, {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 21, 31 ],
      "id_str" : "255245279",
      "id" : 255245279
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 32, 44 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "indices" : [ 121, 133 ],
      "id_str" : "713486956273991686",
      "id" : 713486956273991686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513915436851200",
  "text" : "RT @literal_janelle: @AlanFelyk @gamer456148 Yes to studded collar. Possible usage as a footstool, maybe? No one sits on @BadLitAgent , man.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alan Felyk",
        "screen_name" : "AlanFelyk",
        "indices" : [ 0, 10 ],
        "id_str" : "255245279",
        "id" : 255245279
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 11, 23 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Bad Literary Agent",
        "screen_name" : "BadLitAgent",
        "indices" : [ 100, 112 ],
        "id_str" : "713486956273991686",
        "id" : 713486956273991686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "734775393174052864",
    "geo" : { },
    "id_str" : "734776300565630980",
    "in_reply_to_user_id" : 255245279,
    "text" : "@AlanFelyk @gamer456148 Yes to studded collar. Possible usage as a footstool, maybe? No one sits on @BadLitAgent , man.",
    "id" : 734776300565630980,
    "in_reply_to_status_id" : 734775393174052864,
    "created_at" : "2016-05-23 16:01:36 +0000",
    "in_reply_to_screen_name" : "AlanFelyk",
    "in_reply_to_user_id_str" : "255245279",
    "user" : {
      "name" : "Janelle Ambrose",
      "screen_name" : "literal_janelle",
      "protected" : false,
      "id_str" : "4454704398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711524217624223745\/_DPlP_lu_normal.jpg",
      "id" : 4454704398,
      "verified" : false
    }
  },
  "id" : 779513915436851200,
  "created_at" : "2016-09-24 02:52:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Life Assistant",
      "screen_name" : "NancyJack1014",
      "indices" : [ 3, 17 ],
      "id_str" : "4905663466",
      "id" : 4905663466
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 33, 45 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Katrina McCaffery",
      "screen_name" : "KittyMcCaffery",
      "indices" : [ 46, 61 ],
      "id_str" : "27847404",
      "id" : 27847404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513702856921088",
  "text" : "RT @NancyJack1014: #FollowFriday @gamer456148 @KittyMcCaffery top Influencers this week! Have a great weekend :) (Want this \uD83C\uDD93? &gt;&gt; https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/commun.it\" rel=\"nofollow\"\u003ECommun.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 14, 26 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Katrina McCaffery",
        "screen_name" : "KittyMcCaffery",
        "indices" : [ 27, 42 ],
        "id_str" : "27847404",
        "id" : 27847404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowFriday",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/JZ2w8GhrTU",
        "expanded_url" : "http:\/\/bit.ly\/tweet_thanks_",
        "display_url" : "bit.ly\/tweet_thanks_"
      } ]
    },
    "geo" : { },
    "id_str" : "779347350716190720",
    "text" : "#FollowFriday @gamer456148 @KittyMcCaffery top Influencers this week! Have a great weekend :) (Want this \uD83C\uDD93? &gt;&gt; https:\/\/t.co\/JZ2w8GhrTU)",
    "id" : 779347350716190720,
    "created_at" : "2016-09-23 15:51:02 +0000",
    "user" : {
      "name" : "Your Life Assistant",
      "screen_name" : "NancyJack1014",
      "protected" : false,
      "id_str" : "4905663466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/811423363029680128\/y1TXCju5_normal.jpg",
      "id" : 4905663466,
      "verified" : false
    }
  },
  "id" : 779513702856921088,
  "created_at" : "2016-09-24 02:52:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "indices" : [ 3, 18 ],
      "id_str" : "730204715439534080",
      "id" : 730204715439534080
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LoConservative\/status\/779382920058470400\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/u9ziI8jAvY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDsoFhWAAA6Xns.jpg",
      "id_str" : "779382908956049408",
      "id" : 779382908956049408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDsoFhWAAA6Xns.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 838
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 838
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 838
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 584
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/u9ziI8jAvY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513616580153344",
  "text" : "RT @LoConservative: George Washington reacts to SJWs !  Needless to say, he was quite perplexed. https:\/\/t.co\/u9ziI8jAvY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LoConservative\/status\/779382920058470400\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/u9ziI8jAvY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDsoFhWAAA6Xns.jpg",
        "id_str" : "779382908956049408",
        "id" : 779382908956049408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDsoFhWAAA6Xns.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 976,
          "resize" : "fit",
          "w" : 838
        }, {
          "h" : 976,
          "resize" : "fit",
          "w" : 838
        }, {
          "h" : 976,
          "resize" : "fit",
          "w" : 838
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 584
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/u9ziI8jAvY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779382920058470400",
    "text" : "George Washington reacts to SJWs !  Needless to say, he was quite perplexed. https:\/\/t.co\/u9ziI8jAvY",
    "id" : 779382920058470400,
    "created_at" : "2016-09-23 18:12:23 +0000",
    "user" : {
      "name" : "Lone Conservative",
      "screen_name" : "LoConservative",
      "protected" : false,
      "id_str" : "730204715439534080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993500235195404290\/u7up0dKu_normal.jpg",
      "id" : 730204715439534080,
      "verified" : false
    }
  },
  "id" : 779513616580153344,
  "created_at" : "2016-09-24 02:51:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Dh7Lz7X7Ld",
      "expanded_url" : "http:\/\/louderwithcrowder.com\/free-hugs-shirt-hugs-cop\/",
      "display_url" : "louderwithcrowder.com\/free-hugs-shir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779513537890836480",
  "text" : "RT @scrowder: Of course =&gt; Man in \u2018Free Hugs\u2019 Shirt Hugs Cop. 'Peaceful' Protesters Berate Him https:\/\/t.co\/Dh7Lz7X7Ld https:\/\/t.co\/r0zf38w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/779384346960596992\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/r0zf38wNZr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDt7niWAAASxUQ.jpg",
        "id_str" : "779384344016191488",
        "id" : 779384344016191488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDt7niWAAASxUQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/r0zf38wNZr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/Dh7Lz7X7Ld",
        "expanded_url" : "http:\/\/louderwithcrowder.com\/free-hugs-shirt-hugs-cop\/",
        "display_url" : "louderwithcrowder.com\/free-hugs-shir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779384346960596992",
    "text" : "Of course =&gt; Man in \u2018Free Hugs\u2019 Shirt Hugs Cop. 'Peaceful' Protesters Berate Him https:\/\/t.co\/Dh7Lz7X7Ld https:\/\/t.co\/r0zf38wNZr",
    "id" : 779384346960596992,
    "created_at" : "2016-09-23 18:18:03 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 779513537890836480,
  "created_at" : "2016-09-24 02:51:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Automotive\/status\/453568026043232256\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/GE32q98P7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bktlt2BIEAABz03.jpg",
      "id_str" : "453568025749622784",
      "id" : 453568025749622784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bktlt2BIEAABz03.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 550
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/GE32q98P7y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513327408013312",
  "text" : "RT @BestGamezUp: Brabus Rocket 800 https:\/\/t.co\/GE32q98P7y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Automotive\/status\/453568026043232256\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/GE32q98P7y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bktlt2BIEAABz03.jpg",
        "id_str" : "453568025749622784",
        "id" : 453568025749622784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bktlt2BIEAABz03.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 550
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/GE32q98P7y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779512133964931077",
    "text" : "Brabus Rocket 800 https:\/\/t.co\/GE32q98P7y",
    "id" : 779512133964931077,
    "created_at" : "2016-09-24 02:45:50 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 779513327408013312,
  "created_at" : "2016-09-24 02:50:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madalyn Sklar \uD83D\uDE80helping people crush it on social",
      "screen_name" : "MadalynSklar",
      "indices" : [ 3, 16 ],
      "id_str" : "14164297",
      "id" : 14164297
    }, {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 49, 59 ],
      "id_str" : "17093617",
      "id" : 17093617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HootChat",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "TwitterSmarter",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513280301858816",
  "text" : "RT @MadalynSklar: Be sure to join our friends at @hootsuite for their awesome #HootChat today at 3pm ET. #TwitterSmarter https:\/\/t.co\/cbUTB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hootsuite",
        "screen_name" : "hootsuite",
        "indices" : [ 31, 41 ],
        "id_str" : "17093617",
        "id" : 17093617
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MadalynSklar\/status\/779006893729648640\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/cbUTB8OuEI",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs-Wo6MWgAAxv33.jpg",
        "id_str" : "779006890118381568",
        "id" : 779006890118381568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs-Wo6MWgAAxv33.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/cbUTB8OuEI"
      } ],
      "hashtags" : [ {
        "text" : "HootChat",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "TwitterSmarter",
        "indices" : [ 87, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779006893729648640",
    "text" : "Be sure to join our friends at @hootsuite for their awesome #HootChat today at 3pm ET. #TwitterSmarter https:\/\/t.co\/cbUTB8OuEI",
    "id" : 779006893729648640,
    "created_at" : "2016-09-22 17:18:11 +0000",
    "user" : {
      "name" : "Madalyn Sklar \uD83D\uDE80helping people crush it on social",
      "screen_name" : "MadalynSklar",
      "protected" : false,
      "id_str" : "14164297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/971518376076984320\/eQdX_nIQ_normal.jpg",
      "id" : 14164297,
      "verified" : false
    }
  },
  "id" : 779513280301858816,
  "created_at" : "2016-09-24 02:50:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Timbers",
      "screen_name" : "ameliatimbers",
      "indices" : [ 14, 28 ],
      "id_str" : "76461541",
      "id" : 76461541
    }, {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 29, 42 ],
      "id_str" : "18643437",
      "id" : 18643437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779513226677608454",
  "text" : "RT @jatauldw: @ameliatimbers @PrisonPlanet BLM funded by George Soros to cause chaos so global government can be implemented",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amelia Timbers",
        "screen_name" : "ameliatimbers",
        "indices" : [ 0, 14 ],
        "id_str" : "76461541",
        "id" : 76461541
      }, {
        "name" : "Paul Joseph Watson",
        "screen_name" : "PrisonPlanet",
        "indices" : [ 15, 28 ],
        "id_str" : "18643437",
        "id" : 18643437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778948294214979585",
    "geo" : { },
    "id_str" : "778951699792789504",
    "in_reply_to_user_id" : 76461541,
    "text" : "@ameliatimbers @PrisonPlanet BLM funded by George Soros to cause chaos so global government can be implemented",
    "id" : 778951699792789504,
    "in_reply_to_status_id" : 778948294214979585,
    "created_at" : "2016-09-22 13:38:52 +0000",
    "in_reply_to_screen_name" : "ameliatimbers",
    "in_reply_to_user_id_str" : "76461541",
    "user" : {
      "name" : "PeterFalks erranteye",
      "screen_name" : "PFerranteye",
      "protected" : false,
      "id_str" : "760814926403338240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822980368005496834\/jIx0wGYy_normal.jpg",
      "id" : 760814926403338240,
      "verified" : false
    }
  },
  "id" : 779513226677608454,
  "created_at" : "2016-09-24 02:50:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Air Photo",
      "screen_name" : "planenut27",
      "indices" : [ 3, 14 ],
      "id_str" : "396887508",
      "id" : 396887508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779512946900799489",
  "text" : "RT @planenut27: AIRCRAFT CARRIERS\nCatapult \u201CShooter\u201D signals the launch of an FA-18C Hornet off the flight deck of carrier USS Kitty Hawk C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/planenut27\/status\/779045889486618624\/photo\/1",
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/sQfDWdQ7t1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs-6E5iUIAABz5H.jpg",
        "id_str" : "779045853885374464",
        "id" : 779045853885374464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs-6E5iUIAABz5H.jpg",
        "sizes" : [ {
          "h" : 1683,
          "resize" : "fit",
          "w" : 3008
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1146,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/sQfDWdQ7t1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779045889486618624",
    "text" : "AIRCRAFT CARRIERS\nCatapult \u201CShooter\u201D signals the launch of an FA-18C Hornet off the flight deck of carrier USS Kitty Hawk CV 63 https:\/\/t.co\/sQfDWdQ7t1",
    "id" : 779045889486618624,
    "created_at" : "2016-09-22 19:53:08 +0000",
    "user" : {
      "name" : "World Air Photo",
      "screen_name" : "planenut27",
      "protected" : false,
      "id_str" : "396887508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713462927441862656\/YMGyjIWA_normal.jpg",
      "id" : 396887508,
      "verified" : false
    }
  },
  "id" : 779512946900799489,
  "created_at" : "2016-09-24 02:49:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 0, 14 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    }, {
      "name" : "Team McMullin",
      "screen_name" : "TeamMcMullin",
      "indices" : [ 25, 38 ],
      "id_str" : "762792021492895749",
      "id" : 762792021492895749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779512859210420224",
  "in_reply_to_user_id" : 1051396218,
  "text" : "@Evan_McMullin I support @TeamMcMullin because a Trump or Hillary presidency isn't America's best option.",
  "id" : 779512859210420224,
  "created_at" : "2016-09-24 02:48:42 +0000",
  "in_reply_to_screen_name" : "Evan_McMullin",
  "in_reply_to_user_id_str" : "1051396218",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "indices" : [ 3, 17 ],
      "id_str" : "1051396218",
      "id" : 1051396218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779512612165971968",
  "text" : "RT @Evan_McMullin: I love this country and will never stop fighting to protect the principles that make it a beacon of hope and freedom. Vo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779414863491760129",
    "text" : "I love this country and will never stop fighting to protect the principles that make it a beacon of hope and freedom. Vote your conscience.",
    "id" : 779414863491760129,
    "created_at" : "2016-09-23 20:19:18 +0000",
    "user" : {
      "name" : "Evan McMullin",
      "screen_name" : "Evan_McMullin",
      "protected" : false,
      "id_str" : "1051396218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771412672738955264\/sRBfBvjW_normal.jpg",
      "id" : 1051396218,
      "verified" : true
    }
  },
  "id" : 779512612165971968,
  "created_at" : "2016-09-24 02:47:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/55GvrO4laf",
      "expanded_url" : "http:\/\/bit.ly\/2dn7ARq",
      "display_url" : "bit.ly\/2dn7ARq"
    } ]
  },
  "geo" : { },
  "id_str" : "779342224232284160",
  "text" : "RT @FXStefan: Canada: Consumer Price Index, August 2016: The Consumer Price Index (CPI) rose 1.1% on a year... https:\/\/t.co\/55GvrO4laf #for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "forex",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "trading",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/55GvrO4laf",
        "expanded_url" : "http:\/\/bit.ly\/2dn7ARq",
        "display_url" : "bit.ly\/2dn7ARq"
      } ]
    },
    "geo" : { },
    "id_str" : "779341209894465536",
    "text" : "Canada: Consumer Price Index, August 2016: The Consumer Price Index (CPI) rose 1.1% on a year... https:\/\/t.co\/55GvrO4laf #forex #trading",
    "id" : 779341209894465536,
    "created_at" : "2016-09-23 15:26:38 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 779342224232284160,
  "created_at" : "2016-09-23 15:30:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 13, 19 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779304307854233600",
  "geo" : { },
  "id_str" : "779342032938504192",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki @WIRED It looks a bit to creepy for my taste",
  "id" : 779342032938504192,
  "in_reply_to_status_id" : 779304307854233600,
  "created_at" : "2016-09-23 15:29:54 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/yJxS98YO4a",
      "expanded_url" : "http:\/\/bit.ly\/2cWWx1C",
      "display_url" : "bit.ly\/2cWWx1C"
    } ]
  },
  "geo" : { },
  "id_str" : "779341935433560065",
  "text" : "RT @GuyKawasaki: This is ah-mazing!\nAmerica\u2019s most elaborate corn maze is made of GPS and math https:\/\/t.co\/yJxS98YO4a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/yJxS98YO4a",
        "expanded_url" : "http:\/\/bit.ly\/2cWWx1C",
        "display_url" : "bit.ly\/2cWWx1C"
      } ]
    },
    "geo" : { },
    "id_str" : "779304307854233600",
    "text" : "This is ah-mazing!\nAmerica\u2019s most elaborate corn maze is made of GPS and math https:\/\/t.co\/yJxS98YO4a",
    "id" : 779304307854233600,
    "created_at" : "2016-09-23 13:00:00 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 779341935433560065,
  "created_at" : "2016-09-23 15:29:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "indices" : [ 3, 14 ],
      "id_str" : "19515424",
      "id" : 19515424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779341711205994496",
  "text" : "RT @michiokaku: Ask me a question on national radio. Call 866 323 2129 and maybe you can be on 100 radio stations that carry Science Fantas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773958159329271808",
    "text" : "Ask me a question on national radio. Call 866 323 2129 and maybe you can be on 100 radio stations that carry Science Fantastic.",
    "id" : 773958159329271808,
    "created_at" : "2016-09-08 18:56:19 +0000",
    "user" : {
      "name" : "Dr. Michio Kaku",
      "screen_name" : "michiokaku",
      "protected" : false,
      "id_str" : "19515424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2477428816\/oyj5obfw5nrjiqhtylp9_normal.jpeg",
      "id" : 19515424,
      "verified" : true
    }
  },
  "id" : 779341711205994496,
  "created_at" : "2016-09-23 15:28:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/779153369814360064\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/XAL7nnCJ82",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs_OUUOWAAAZDfv.jpg",
      "id_str" : "779068108979961856",
      "id" : 779068108979961856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs_OUUOWAAAZDfv.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/XAL7nnCJ82"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/7gnMqP42PZ",
      "expanded_url" : "http:\/\/po.st\/Cd3Vx4",
      "display_url" : "po.st\/Cd3Vx4"
    } ]
  },
  "geo" : { },
  "id_str" : "779341660333277184",
  "text" : "RT @PopSci: This is how Orion astronauts might protect themselves from radiation storms https:\/\/t.co\/7gnMqP42PZ https:\/\/t.co\/XAL7nnCJ82",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/779153369814360064\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/XAL7nnCJ82",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs_OUUOWAAAZDfv.jpg",
        "id_str" : "779068108979961856",
        "id" : 779068108979961856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cs_OUUOWAAAZDfv.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/XAL7nnCJ82"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/7gnMqP42PZ",
        "expanded_url" : "http:\/\/po.st\/Cd3Vx4",
        "display_url" : "po.st\/Cd3Vx4"
      } ]
    },
    "geo" : { },
    "id_str" : "779153369814360064",
    "text" : "This is how Orion astronauts might protect themselves from radiation storms https:\/\/t.co\/7gnMqP42PZ https:\/\/t.co\/XAL7nnCJ82",
    "id" : 779153369814360064,
    "created_at" : "2016-09-23 03:00:13 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915646486381084672\/y9rvRKcy_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 779341660333277184,
  "created_at" : "2016-09-23 15:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/779320760674422784\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/1oUvIqfygS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC0GOUWIAACa7k.jpg",
      "id_str" : "779320754550743040",
      "id" : 779320754550743040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC0GOUWIAACa7k.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/1oUvIqfygS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/VSCdadDytm",
      "expanded_url" : "http:\/\/po.st\/xVuazd",
      "display_url" : "po.st\/xVuazd"
    } ]
  },
  "geo" : { },
  "id_str" : "779341548337049601",
  "text" : "RT @PopSci: This DIY fog machine fits in a mug https:\/\/t.co\/VSCdadDytm https:\/\/t.co\/1oUvIqfygS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/779320760674422784\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/1oUvIqfygS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC0GOUWIAACa7k.jpg",
        "id_str" : "779320754550743040",
        "id" : 779320754550743040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC0GOUWIAACa7k.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1oUvIqfygS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/VSCdadDytm",
        "expanded_url" : "http:\/\/po.st\/xVuazd",
        "display_url" : "po.st\/xVuazd"
      } ]
    },
    "geo" : { },
    "id_str" : "779320760674422784",
    "text" : "This DIY fog machine fits in a mug https:\/\/t.co\/VSCdadDytm https:\/\/t.co\/1oUvIqfygS",
    "id" : 779320760674422784,
    "created_at" : "2016-09-23 14:05:23 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915646486381084672\/y9rvRKcy_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 779341548337049601,
  "created_at" : "2016-09-23 15:27:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 3, 9 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779341306367610880",
  "text" : "RT @sciam: Remote towers allow for airplanes to be controlled from cheap conference rooms rather than expensive control towers https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/PjP8rYqdMi",
        "expanded_url" : "http:\/\/bit.ly\/2dnnxdd",
        "display_url" : "bit.ly\/2dnnxdd"
      } ]
    },
    "geo" : { },
    "id_str" : "779093039616786432",
    "text" : "Remote towers allow for airplanes to be controlled from cheap conference rooms rather than expensive control towers https:\/\/t.co\/PjP8rYqdMi",
    "id" : 779093039616786432,
    "created_at" : "2016-09-22 23:00:30 +0000",
    "user" : {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "protected" : false,
      "id_str" : "14647570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676776763431620608\/1eNZzxq0_normal.png",
      "id" : 14647570,
      "verified" : true
    }
  },
  "id" : 779341306367610880,
  "created_at" : "2016-09-23 15:27:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gomerni",
      "screen_name" : "gomerni",
      "indices" : [ 3, 11 ],
      "id_str" : "318641815",
      "id" : 318641815
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 13, 19 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779341245470560256",
  "text" : "RT @gomerni: @sciam What about the crop circles?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 0, 6 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "779319460956078080",
    "geo" : { },
    "id_str" : "779323452708818944",
    "in_reply_to_user_id" : 14647570,
    "text" : "@sciam What about the crop circles?",
    "id" : 779323452708818944,
    "in_reply_to_status_id" : 779319460956078080,
    "created_at" : "2016-09-23 14:16:04 +0000",
    "in_reply_to_screen_name" : "sciam",
    "in_reply_to_user_id_str" : "14647570",
    "user" : {
      "name" : "Gomerni",
      "screen_name" : "gomerni",
      "protected" : false,
      "id_str" : "318641815",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728957276220952579\/QHBVtE4E_normal.jpg",
      "id" : 318641815,
      "verified" : false
    }
  },
  "id" : 779341245470560256,
  "created_at" : "2016-09-23 15:26:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/TkeFPY6aqu",
      "expanded_url" : "https:\/\/twitter.com\/NASAJPL\/status\/776476526678126593",
      "display_url" : "twitter.com\/NASAJPL\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779341148015833088",
  "text" : "RT @MarsCuriosity: Mars: Land o' (Later) Lakes https:\/\/t.co\/TkeFPY6aqu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/TkeFPY6aqu",
        "expanded_url" : "https:\/\/twitter.com\/NASAJPL\/status\/776476526678126593",
        "display_url" : "twitter.com\/NASAJPL\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776476994791837696",
    "text" : "Mars: Land o' (Later) Lakes https:\/\/t.co\/TkeFPY6aqu",
    "id" : 776476994791837696,
    "created_at" : "2016-09-15 17:45:16 +0000",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793288186\/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 779341148015833088,
  "created_at" : "2016-09-23 15:26:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340903466930177",
  "text" : "RT @neiltyson: Odd that our measures of animal intelligence are often tests of what humans do best rather than of what they do best.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776818882732552192",
    "text" : "Odd that our measures of animal intelligence are often tests of what humans do best rather than of what they do best.",
    "id" : 776818882732552192,
    "created_at" : "2016-09-16 16:23:48 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 779340903466930177,
  "created_at" : "2016-09-23 15:25:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "45th Space Wing",
      "screen_name" : "45thSpaceWing",
      "indices" : [ 22, 36 ],
      "id_str" : "242828495",
      "id" : 242828495
    }, {
      "name" : "NASA Kennedy \/ KSC",
      "screen_name" : "NASAKennedy",
      "indices" : [ 38, 50 ],
      "id_str" : "16580226",
      "id" : 16580226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340840707629057",
  "text" : "RT @SpaceX: Thanks to @45thSpaceWing, @NASAKennedy and others for helping us respond to today's anomaly. Very grateful for your efforts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "45th Space Wing",
        "screen_name" : "45thSpaceWing",
        "indices" : [ 10, 24 ],
        "id_str" : "242828495",
        "id" : 242828495
      }, {
        "name" : "NASA Kennedy \/ KSC",
        "screen_name" : "NASAKennedy",
        "indices" : [ 26, 38 ],
        "id_str" : "16580226",
        "id" : 16580226
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771480807923781632",
    "text" : "Thanks to @45thSpaceWing, @NASAKennedy and others for helping us respond to today's anomaly. Very grateful for your efforts.",
    "id" : 771480807923781632,
    "created_at" : "2016-09-01 22:52:12 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 779340840707629057,
  "created_at" : "2016-09-23 15:25:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 40, 45 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Tsubasa (faa)",
      "screen_name" : "faa",
      "indices" : [ 47, 51 ],
      "id_str" : "5822512",
      "id" : 5822512
    }, {
      "name" : "US Air Force (USAF)",
      "screen_name" : "AFPAA",
      "indices" : [ 53, 59 ],
      "id_str" : "16630062",
      "id" : 16630062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340807572631552",
  "text" : "RT @elonmusk: Support &amp; advice from @NASA, @FAA, @AFPAA &amp; others much appreciated. Please email any recordings of the event to report@space\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 26, 31 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Tsubasa (faa)",
        "screen_name" : "faa",
        "indices" : [ 33, 37 ],
        "id_str" : "5822512",
        "id" : 5822512
      }, {
        "name" : "US Air Force (USAF)",
        "screen_name" : "AFPAA",
        "indices" : [ 39, 45 ],
        "id_str" : "16630062",
        "id" : 16630062
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774152037927792640",
    "text" : "Support &amp; advice from @NASA, @FAA, @AFPAA &amp; others much appreciated. Please email any recordings of the event to report@spacex.com.",
    "id" : 774152037927792640,
    "created_at" : "2016-09-09 07:46:43 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 779340807572631552,
  "created_at" : "2016-09-23 15:25:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "Adrian Jektvik",
      "screen_name" : "ninjas",
      "indices" : [ 14, 21 ],
      "id_str" : "43593943",
      "id" : 43593943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340745459142656",
  "text" : "RT @elonmusk: @ninjas \"smart\" preconditioning should be less dumb in 8.0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adrian Jektvik",
        "screen_name" : "ninjas",
        "indices" : [ 0, 7 ],
        "id_str" : "43593943",
        "id" : 43593943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778604705861738496",
    "geo" : { },
    "id_str" : "778624588989071360",
    "in_reply_to_user_id" : 43593943,
    "text" : "@ninjas \"smart\" preconditioning should be less dumb in 8.0",
    "id" : 778624588989071360,
    "in_reply_to_status_id" : 778604705861738496,
    "created_at" : "2016-09-21 15:59:02 +0000",
    "in_reply_to_screen_name" : "ninjas",
    "in_reply_to_user_id_str" : "43593943",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 779340745459142656,
  "created_at" : "2016-09-23 15:24:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Randall",
      "screen_name" : "tsrandall",
      "indices" : [ 122, 132 ],
      "id_str" : "40303245",
      "id" : 40303245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340705529339904",
  "text" : "RT @TeslaMotors: There are hundreds of smaller tweaks that add up to a significantly improved experience behind the wheel @tsrandall\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Randall",
        "screen_name" : "tsrandall",
        "indices" : [ 105, 115 ],
        "id_str" : "40303245",
        "id" : 40303245
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/z0IW2125rr",
        "expanded_url" : "http:\/\/www.bloomberg.com\/news\/features\/2016-09-22\/tesla-drivers-wake-up-to-a-serious-upgrade",
        "display_url" : "bloomberg.com\/news\/features\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "778959491857461248",
    "text" : "There are hundreds of smaller tweaks that add up to a significantly improved experience behind the wheel @tsrandall\nhttps:\/\/t.co\/z0IW2125rr",
    "id" : 778959491857461248,
    "created_at" : "2016-09-22 14:09:49 +0000",
    "user" : {
      "name" : "Tesla",
      "screen_name" : "Tesla",
      "protected" : false,
      "id_str" : "13298072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489192650474414080\/4RxZxsud_normal.png",
      "id" : 13298072,
      "verified" : true
    }
  },
  "id" : 779340705529339904,
  "created_at" : "2016-09-23 15:24:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340672931287040",
  "text" : "RT @elonmusk: Aiming for Oct 28 unveil in SF Bay Area of new Tesla\/SolarCity solar roof with integrated Powerwall 2.0 battery and Tesla cha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779003462742794240",
    "text" : "Aiming for Oct 28 unveil in SF Bay Area of new Tesla\/SolarCity solar roof with integrated Powerwall 2.0 battery and Tesla charger.",
    "id" : 779003462742794240,
    "created_at" : "2016-09-22 17:04:33 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 779340672931287040,
  "created_at" : "2016-09-23 15:24:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/bouUUymJdY",
      "expanded_url" : "http:\/\/ow.ly\/4Qbj304jQ5I",
      "display_url" : "ow.ly\/4Qbj304jQ5I"
    } ]
  },
  "geo" : { },
  "id_str" : "779340481968807939",
  "text" : "RT @analyticbridge: Help the Fortune 500 Solve Their Machine Learning and Big Data Challenges https:\/\/t.co\/bouUUymJdY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/bouUUymJdY",
        "expanded_url" : "http:\/\/ow.ly\/4Qbj304jQ5I",
        "display_url" : "ow.ly\/4Qbj304jQ5I"
      } ]
    },
    "geo" : { },
    "id_str" : "779312240218542080",
    "text" : "Help the Fortune 500 Solve Their Machine Learning and Big Data Challenges https:\/\/t.co\/bouUUymJdY",
    "id" : 779312240218542080,
    "created_at" : "2016-09-23 13:31:31 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779340481968807939,
  "created_at" : "2016-09-23 15:23:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779316189159952384\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/3YTXTcoYKm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCv8W7WYAAGjvh.jpg",
      "id_str" : "779316187016617984",
      "id" : 779316187016617984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCv8W7WYAAGjvh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/3YTXTcoYKm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/0Bv6iCkkA0",
      "expanded_url" : "http:\/\/engt.co\/2dp9G6l",
      "display_url" : "engt.co\/2dp9G6l"
    } ]
  },
  "geo" : { },
  "id_str" : "779340453309132800",
  "text" : "RT @engadget: Google is reportedly interested in buying Twitter https:\/\/t.co\/0Bv6iCkkA0 https:\/\/t.co\/3YTXTcoYKm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779316189159952384\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/3YTXTcoYKm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtCv8W7WYAAGjvh.jpg",
        "id_str" : "779316187016617984",
        "id" : 779316187016617984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtCv8W7WYAAGjvh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/3YTXTcoYKm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/0Bv6iCkkA0",
        "expanded_url" : "http:\/\/engt.co\/2dp9G6l",
        "display_url" : "engt.co\/2dp9G6l"
      } ]
    },
    "geo" : { },
    "id_str" : "779316189159952384",
    "text" : "Google is reportedly interested in buying Twitter https:\/\/t.co\/0Bv6iCkkA0 https:\/\/t.co\/3YTXTcoYKm",
    "id" : 779316189159952384,
    "created_at" : "2016-09-23 13:47:13 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779340453309132800,
  "created_at" : "2016-09-23 15:23:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RY9oFTqNMg",
      "expanded_url" : "http:\/\/ow.ly\/SJ90304jQ5J",
      "display_url" : "ow.ly\/SJ90304jQ5J"
    } ]
  },
  "geo" : { },
  "id_str" : "779340374896549888",
  "text" : "RT @analyticbridge: Big data versus smart data, what is your choice? Do you think smart data willeventually win? https:\/\/t.co\/RY9oFTqNMg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/RY9oFTqNMg",
        "expanded_url" : "http:\/\/ow.ly\/SJ90304jQ5J",
        "display_url" : "ow.ly\/SJ90304jQ5J"
      } ]
    },
    "geo" : { },
    "id_str" : "779320187971575809",
    "text" : "Big data versus smart data, what is your choice? Do you think smart data willeventually win? https:\/\/t.co\/RY9oFTqNMg",
    "id" : 779320187971575809,
    "created_at" : "2016-09-23 14:03:06 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 779340374896549888,
  "created_at" : "2016-09-23 15:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779335379052814336\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/VmZcqZ52Ba",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDBZXCWgAA_mLk.jpg",
      "id_str" : "779335376959864832",
      "id" : 779335376959864832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDBZXCWgAA_mLk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/VmZcqZ52Ba"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/IwHzHFP8Lp",
      "expanded_url" : "http:\/\/engt.co\/2d3nsY9",
      "display_url" : "engt.co\/2d3nsY9"
    } ]
  },
  "geo" : { },
  "id_str" : "779340036907028480",
  "text" : "RT @engadget: A first look at Sony's full-frame A99 II https:\/\/t.co\/IwHzHFP8Lp https:\/\/t.co\/VmZcqZ52Ba",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779335379052814336\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/VmZcqZ52Ba",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDBZXCWgAA_mLk.jpg",
        "id_str" : "779335376959864832",
        "id" : 779335376959864832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDBZXCWgAA_mLk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/VmZcqZ52Ba"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/IwHzHFP8Lp",
        "expanded_url" : "http:\/\/engt.co\/2d3nsY9",
        "display_url" : "engt.co\/2d3nsY9"
      } ]
    },
    "geo" : { },
    "id_str" : "779335379052814336",
    "text" : "A first look at Sony's full-frame A99 II https:\/\/t.co\/IwHzHFP8Lp https:\/\/t.co\/VmZcqZ52Ba",
    "id" : 779335379052814336,
    "created_at" : "2016-09-23 15:03:28 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779340036907028480,
  "created_at" : "2016-09-23 15:21:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779340014643650561",
  "text" : "RT @lorenridinger: \u201CMusic always sounds better on Friday.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779320204920758272",
    "text" : "\u201CMusic always sounds better on Friday.\u201D",
    "id" : 779320204920758272,
    "created_at" : "2016-09-23 14:03:10 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 779340014643650561,
  "created_at" : "2016-09-23 15:21:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LWC",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/qu5nlUfBRt",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
      "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779339990790569984",
  "text" : "RT @scrowder: New show is up! We talk with Tommy Sotomayor and LITERALLY Hitler! #92 #LWC FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/779322847055507456\/video\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/rFVpLUrHf4",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779322525377593344\/pu\/img\/LB2ezSZyMLB7w75i.jpg",
        "id_str" : "779322525377593344",
        "id" : 779322525377593344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779322525377593344\/pu\/img\/LB2ezSZyMLB7w75i.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/rFVpLUrHf4"
      } ],
      "hashtags" : [ {
        "text" : "LWC",
        "indices" : [ 71, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/qu5nlUfBRt",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
        "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779322847055507456",
    "text" : "New show is up! We talk with Tommy Sotomayor and LITERALLY Hitler! #92 #LWC FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/t.co\/rFVpLUrHf4",
    "id" : 779322847055507456,
    "created_at" : "2016-09-23 14:13:40 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 779339990790569984,
  "created_at" : "2016-09-23 15:21:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CHELSEA SAUDI FANS\u2122",
      "screen_name" : "CFCSAUDIFANS",
      "indices" : [ 3, 16 ],
      "id_str" : "2430943130",
      "id" : 2430943130
    }, {
      "name" : "Didier Drogba",
      "screen_name" : "didierdrogba",
      "indices" : [ 50, 63 ],
      "id_str" : "219294551",
      "id" : 219294551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 18, 34 ]
    }, {
      "text" : "CFC",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "Arsenal",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779339929121722369",
  "text" : "RT @CFCSAUDIFANS: #FlashbackFriday: Who remembers @didierdrogba's stunning free-kick at Emirates Stadium back in 2009? \uD83D\uDE0D\uD83D\uDC4C#CFC #Arsenal http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Didier Drogba",
        "screen_name" : "didierdrogba",
        "indices" : [ 32, 45 ],
        "id_str" : "219294551",
        "id" : 219294551
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CFCSAUDIFANS\/status\/779336099969765376\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/fdiMOk81Dm",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334205155188736\/pu\/img\/cP9uTbtiY-B6tM-Y.jpg",
        "id_str" : "779334205155188736",
        "id" : 779334205155188736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334205155188736\/pu\/img\/cP9uTbtiY-B6tM-Y.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fdiMOk81Dm"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "CFC",
        "indices" : [ 103, 107 ]
      }, {
        "text" : "Arsenal",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779336099969765376",
    "text" : "#FlashbackFriday: Who remembers @didierdrogba's stunning free-kick at Emirates Stadium back in 2009? \uD83D\uDE0D\uD83D\uDC4C#CFC #Arsenal https:\/\/t.co\/fdiMOk81Dm",
    "id" : 779336099969765376,
    "created_at" : "2016-09-23 15:06:20 +0000",
    "user" : {
      "name" : "CHELSEA SAUDI FANS\u2122",
      "screen_name" : "CFCSAUDIFANS",
      "protected" : false,
      "id_str" : "2430943130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452901820214415360\/nvaBnZkb_normal.jpeg",
      "id" : 2430943130,
      "verified" : false
    }
  },
  "id" : 779339929121722369,
  "created_at" : "2016-09-23 15:21:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/778421219007750144\/video\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/eU2g36nl0C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs2B91PUMAADAlF.jpg",
      "id_str" : "778421027646779392",
      "id" : 778421027646779392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs2B91PUMAADAlF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/eU2g36nl0C"
    } ],
    "hashtags" : [ {
      "text" : "Photokina",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/TJE9lFFq1N",
      "expanded_url" : "http:\/\/engt.co\/2d6ApRP",
      "display_url" : "engt.co\/2d6ApRP"
    } ]
  },
  "geo" : { },
  "id_str" : "779339525243875328",
  "text" : "RT @engadget: Canon makes big strides with its fast-focusing mirrorless M5 https:\/\/t.co\/TJE9lFFq1N #Photokina https:\/\/t.co\/eU2g36nl0C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/778421219007750144\/video\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/eU2g36nl0C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs2B91PUMAADAlF.jpg",
        "id_str" : "778421027646779392",
        "id" : 778421027646779392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs2B91PUMAADAlF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/eU2g36nl0C"
      } ],
      "hashtags" : [ {
        "text" : "Photokina",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/TJE9lFFq1N",
        "expanded_url" : "http:\/\/engt.co\/2d6ApRP",
        "display_url" : "engt.co\/2d6ApRP"
      } ]
    },
    "geo" : { },
    "id_str" : "778421219007750144",
    "text" : "Canon makes big strides with its fast-focusing mirrorless M5 https:\/\/t.co\/TJE9lFFq1N #Photokina https:\/\/t.co\/eU2g36nl0C",
    "id" : 778421219007750144,
    "created_at" : "2016-09-21 02:30:55 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779339525243875328,
  "created_at" : "2016-09-23 15:19:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/778979813952397313\/video\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/E5x3Y1IjJP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9-AP2VUAE8ljE.jpg",
      "id_str" : "778979690627276800",
      "id" : 778979690627276800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9-AP2VUAE8ljE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/E5x3Y1IjJP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/TVsU2abTfH",
      "expanded_url" : "http:\/\/engt.co\/2d6x3OI",
      "display_url" : "engt.co\/2d6x3OI"
    } ]
  },
  "geo" : { },
  "id_str" : "779339471082795008",
  "text" : "RT @engadget: This is GoPro's $799, foldable Karma drone https:\/\/t.co\/TVsU2abTfH https:\/\/t.co\/E5x3Y1IjJP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/778979813952397313\/video\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/E5x3Y1IjJP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs9-AP2VUAE8ljE.jpg",
        "id_str" : "778979690627276800",
        "id" : 778979690627276800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs9-AP2VUAE8ljE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/E5x3Y1IjJP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/TVsU2abTfH",
        "expanded_url" : "http:\/\/engt.co\/2d6x3OI",
        "display_url" : "engt.co\/2d6x3OI"
      } ]
    },
    "geo" : { },
    "id_str" : "778979813952397313",
    "text" : "This is GoPro's $799, foldable Karma drone https:\/\/t.co\/TVsU2abTfH https:\/\/t.co\/E5x3Y1IjJP",
    "id" : 778979813952397313,
    "created_at" : "2016-09-22 15:30:35 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779339471082795008,
  "created_at" : "2016-09-23 15:19:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779327106576560128\/video\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/dvQTEz793G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC53Y3UsAASQlZ.jpg",
      "id_str" : "779326982366466048",
      "id" : 779326982366466048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC53Y3UsAASQlZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dvQTEz793G"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/IzyojzGZSh",
      "expanded_url" : "http:\/\/engt.co\/2cXaBYU",
      "display_url" : "engt.co\/2cXaBYU"
    } ]
  },
  "geo" : { },
  "id_str" : "779339431039741952",
  "text" : "RT @engadget: A first look at Nikon's KeyMission 360 VR action camera https:\/\/t.co\/IzyojzGZSh https:\/\/t.co\/dvQTEz793G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/779327106576560128\/video\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/dvQTEz793G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtC53Y3UsAASQlZ.jpg",
        "id_str" : "779326982366466048",
        "id" : 779326982366466048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtC53Y3UsAASQlZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/dvQTEz793G"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/IzyojzGZSh",
        "expanded_url" : "http:\/\/engt.co\/2cXaBYU",
        "display_url" : "engt.co\/2cXaBYU"
      } ]
    },
    "geo" : { },
    "id_str" : "779327106576560128",
    "text" : "A first look at Nikon's KeyMission 360 VR action camera https:\/\/t.co\/IzyojzGZSh https:\/\/t.co\/dvQTEz793G",
    "id" : 779327106576560128,
    "created_at" : "2016-09-23 14:30:36 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 779339431039741952,
  "created_at" : "2016-09-23 15:19:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Gabriel Lepinski",
      "screen_name" : "presidentgabe",
      "indices" : [ 32, 46 ],
      "id_str" : "2218496953",
      "id" : 2218496953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779339235228651520",
  "text" : "RT @KassyDillon: I have to say, @presidentgabe is probably one of the best conservatives I know. He put up with a mob of SJWs and remained\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabriel Lepinski",
        "screen_name" : "presidentgabe",
        "indices" : [ 15, 29 ],
        "id_str" : "2218496953",
        "id" : 2218496953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "779323005591810049",
    "text" : "I have to say, @presidentgabe is probably one of the best conservatives I know. He put up with a mob of SJWs and remained unfazed. Respect.",
    "id" : 779323005591810049,
    "created_at" : "2016-09-23 14:14:18 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 779339235228651520,
  "created_at" : "2016-09-23 15:18:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/779334610710913024\/video\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/UIpQTSggIJ",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334513872732164\/pu\/img\/oZTw9V__BlKoTZ2D.jpg",
      "id_str" : "779334513872732164",
      "id" : 779334513872732164,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334513872732164\/pu\/img\/oZTw9V__BlKoTZ2D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/UIpQTSggIJ"
    } ],
    "hashtags" : [ {
      "text" : "Charlotte",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "LWC",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/qu5nlUfBRt",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
      "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "779339212520685569",
  "text" : "RT @scrowder: You know who didn't Hate White People? This man. #Charlotte #LWC FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/t.co\/UIpQTSggIJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/779334610710913024\/video\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/UIpQTSggIJ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334513872732164\/pu\/img\/oZTw9V__BlKoTZ2D.jpg",
        "id_str" : "779334513872732164",
        "id" : 779334513872732164,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/779334513872732164\/pu\/img\/oZTw9V__BlKoTZ2D.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/UIpQTSggIJ"
      } ],
      "hashtags" : [ {
        "text" : "Charlotte",
        "indices" : [ 49, 59 ]
      }, {
        "text" : "LWC",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/qu5nlUfBRt",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=pAhZ0qMxF_c",
        "display_url" : "youtube.com\/watch?v=pAhZ0q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "779334610710913024",
    "text" : "You know who didn't Hate White People? This man. #Charlotte #LWC FULL SHOW &gt;&gt; https:\/\/t.co\/qu5nlUfBRt https:\/\/t.co\/UIpQTSggIJ",
    "id" : 779334610710913024,
    "created_at" : "2016-09-23 15:00:25 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 779339212520685569,
  "created_at" : "2016-09-23 15:18:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 115, 124 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChoiceContent",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/1fFRo8Qx8Q",
      "expanded_url" : "http:\/\/snip.ly\/lhvjn",
      "display_url" : "snip.ly\/lhvjn"
    } ]
  },
  "geo" : { },
  "id_str" : "779339132405358592",
  "text" : "RT @hootsuite: This Twitter update shows how fast companies respond to your complaints: https:\/\/t.co\/1fFRo8Qx8Q on @Mashable #ChoiceContent\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 100, 109 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/779338395994746880\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/i5PnFaL5HD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CtDEI8wXEAAPGwx.jpg",
        "id_str" : "779338393562058752",
        "id" : 779338393562058752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtDEI8wXEAAPGwx.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/i5PnFaL5HD"
      } ],
      "hashtags" : [ {
        "text" : "ChoiceContent",
        "indices" : [ 110, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/1fFRo8Qx8Q",
        "expanded_url" : "http:\/\/snip.ly\/lhvjn",
        "display_url" : "snip.ly\/lhvjn"
      } ]
    },
    "geo" : { },
    "id_str" : "779338395994746880",
    "text" : "This Twitter update shows how fast companies respond to your complaints: https:\/\/t.co\/1fFRo8Qx8Q on @Mashable #ChoiceContent https:\/\/t.co\/i5PnFaL5HD",
    "id" : 779338395994746880,
    "created_at" : "2016-09-23 15:15:27 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 779339132405358592,
  "created_at" : "2016-09-23 15:18:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779339006764998656",
  "geo" : { },
  "id_str" : "779339064843522048",
  "in_reply_to_user_id" : 210979938,
  "text" : "@engadget *always",
  "id" : 779339064843522048,
  "in_reply_to_status_id" : 779339006764998656,
  "created_at" : "2016-09-23 15:18:07 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "779338795162472448",
  "geo" : { },
  "id_str" : "779339006764998656",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget AI all starts small than it gets more and more extreme",
  "id" : 779339006764998656,
  "in_reply_to_status_id" : 779338795162472448,
  "created_at" : "2016-09-23 15:17:53 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779338880755523585",
  "text" : "So tired now, must rest, work never ends \uD83D\uDE35",
  "id" : 779338880755523585,
  "created_at" : "2016-09-23 15:17:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/lX5maSgxjY",
      "expanded_url" : "http:\/\/fb.me\/88OysUXPn",
      "display_url" : "fb.me\/88OysUXPn"
    } ]
  },
  "geo" : { },
  "id_str" : "779338773909741569",
  "text" : "RT @EmperorDarroux: A first look at Sony's full-frame A99 II https:\/\/t.co\/lX5maSgxjY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/lX5maSgxjY",
        "expanded_url" : "http:\/\/fb.me\/88OysUXPn",
        "display_url" : "fb.me\/88OysUXPn"
      } ]
    },
    "geo" : { },
    "id_str" : "779338359516696577",
    "text" : "A first look at Sony's full-frame A99 II https:\/\/t.co\/lX5maSgxjY",
    "id" : 779338359516696577,
    "created_at" : "2016-09-23 15:15:18 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 779338773909741569,
  "created_at" : "2016-09-23 15:16:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "App Store",
      "screen_name" : "AppStore",
      "indices" : [ 9, 18 ],
      "id_str" : "74594552",
      "id" : 74594552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779338745300393984",
  "text" : "Why does @AppStore have a $99\/year program but Google Play has a $25 lifetime program? I hate things when you have to pay yearly \uD83E\uDD14",
  "id" : 779338745300393984,
  "created_at" : "2016-09-23 15:16:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779308716629843969",
  "text" : "The carnival is at OU today but I have lots of homework and most of my friends are working, might have my 40 min of fame, #ThisIsOU",
  "id" : 779308716629843969,
  "created_at" : "2016-09-23 13:17:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levitre",
      "screen_name" : "aaronlevitreiii",
      "indices" : [ 3, 19 ],
      "id_str" : "755815205054144512",
      "id" : 755815205054144512
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 21, 33 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 34, 46 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779308491047628801",
  "text" : "RT @aaronlevitreiii: @gamer456148 @KassyDillon it's free lol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 13, 25 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778707286202003456",
    "geo" : { },
    "id_str" : "779049177883873280",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @KassyDillon it's free lol",
    "id" : 779049177883873280,
    "in_reply_to_status_id" : 778707286202003456,
    "created_at" : "2016-09-22 20:06:12 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Aaron Levitre",
      "screen_name" : "aaronlevitreiii",
      "protected" : false,
      "id_str" : "755815205054144512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755815422541332481\/nKhV8mGC_normal.jpg",
      "id" : 755815205054144512,
      "verified" : false
    }
  },
  "id" : 779308491047628801,
  "created_at" : "2016-09-23 13:16:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778989021070516224",
  "text" : "Had Sprite and sour candy in the morning, than cut someone off while driving, good start to the day. Now off to bible study!",
  "id" : 778989021070516224,
  "created_at" : "2016-09-22 16:07:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778707479232335872",
  "text" : "RT @scrowder: For crying out loud, someone take away Anthony Weiner's phone. And wiener.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778707422508490753",
    "text" : "For crying out loud, someone take away Anthony Weiner's phone. And wiener.",
    "id" : 778707422508490753,
    "created_at" : "2016-09-21 21:28:11 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 778707479232335872,
  "created_at" : "2016-09-21 21:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "778673917300998144",
  "geo" : { },
  "id_str" : "778707286202003456",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon If only I had a snapchat",
  "id" : 778707286202003456,
  "in_reply_to_status_id" : 778673917300998144,
  "created_at" : "2016-09-21 21:27:39 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778707196079058945",
  "text" : "RT @KassyDillon: Follow me on snapchat. I'll be posting many snaps of the event tonight with Shapiro. KassyDillon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778673917300998144",
    "text" : "Follow me on snapchat. I'll be posting many snaps of the event tonight with Shapiro. KassyDillon",
    "id" : 778673917300998144,
    "created_at" : "2016-09-21 19:15:03 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 778707196079058945,
  "created_at" : "2016-09-21 21:27:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/778707182992797697\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/RWnDZF3OVQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cs6GDOeVUAIakG7.jpg",
      "id_str" : "778707175564726274",
      "id" : 778707175564726274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cs6GDOeVUAIakG7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/RWnDZF3OVQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778707182992797697",
  "text" : "They didn't provide enough ranch w\/ my salad, lol https:\/\/t.co\/RWnDZF3OVQ",
  "id" : 778707182992797697,
  "created_at" : "2016-09-21 21:27:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778672714601132032",
  "text" : "I been more awkward today than usual",
  "id" : 778672714601132032,
  "created_at" : "2016-09-21 19:10:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778581696929234944",
  "text" : "RT @BarbaraCorcoran: Take some time to sit down and figure out how your big rival is promoting their brand + plan something smarter and mor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778577162152644608",
    "text" : "Take some time to sit down and figure out how your big rival is promoting their brand + plan something smarter and more creative for yours.",
    "id" : 778577162152644608,
    "created_at" : "2016-09-21 12:50:35 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 778581696929234944,
  "created_at" : "2016-09-21 13:08:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778581658882678784",
  "text" : "Andrew the funny gentle giant that isn't really a giant",
  "id" : 778581658882678784,
  "created_at" : "2016-09-21 13:08:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312545551679489",
  "text" : "RT @lorenridinger: \"Peace cannot be kept by force; it can only be achieved by understanding.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778262657258426369",
    "text" : "\"Peace cannot be kept by force; it can only be achieved by understanding.\"",
    "id" : 778262657258426369,
    "created_at" : "2016-09-20 16:00:51 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 778312545551679489,
  "created_at" : "2016-09-20 19:19:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sapphire",
      "screen_name" : "Sapphire80129",
      "indices" : [ 3, 17 ],
      "id_str" : "68889823",
      "id" : 68889823
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 19, 28 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312492833443840",
  "text" : "RT @Sapphire80129: @scrowder she needed help up 2 stairs YESTERDAY! SHE IS NOT HEALTHY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778251171039444992",
    "geo" : { },
    "id_str" : "778259662122561536",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder she needed help up 2 stairs YESTERDAY! SHE IS NOT HEALTHY",
    "id" : 778259662122561536,
    "in_reply_to_status_id" : 778251171039444992,
    "created_at" : "2016-09-20 15:48:57 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Sapphire",
      "screen_name" : "Sapphire80129",
      "protected" : false,
      "id_str" : "68889823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722858549630504962\/DbP1caVF_normal.jpg",
      "id" : 68889823,
      "verified" : false
    }
  },
  "id" : 778312492833443840,
  "created_at" : "2016-09-20 19:18:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Durso",
      "screen_name" : "LeslieDurso",
      "indices" : [ 3, 15 ],
      "id_str" : "36719407",
      "id" : 36719407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312389586481153",
  "text" : "RT @LeslieDurso: Most people give up on their goals to live what\u2019s \u201Cnormal\u201D Do not be average! You have a winner in you that only you can r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778247806272188416",
    "text" : "Most people give up on their goals to live what\u2019s \u201Cnormal\u201D Do not be average! You have a winner in you that only you can release!",
    "id" : 778247806272188416,
    "created_at" : "2016-09-20 15:01:50 +0000",
    "user" : {
      "name" : "Leslie Durso",
      "screen_name" : "LeslieDurso",
      "protected" : false,
      "id_str" : "36719407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775373897227132928\/GH09Of2W_normal.jpg",
      "id" : 36719407,
      "verified" : true
    }
  },
  "id" : 778312389586481153,
  "created_at" : "2016-09-20 19:18:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778312223445901312",
  "text" : "Pain is a part of life",
  "id" : 778312223445901312,
  "created_at" : "2016-09-20 19:17:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shark Tank",
      "screen_name" : "ABCSharkTank",
      "indices" : [ 3, 16 ],
      "id_str" : "468583731",
      "id" : 468583731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778237222181072896",
  "text" : "RT @ABCSharkTank: For the first time in #SharkTank history all 6 Sharks will be in the tank! Don't miss Friday's season premiere. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABCSharkTank\/status\/777915219062296576\/video\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/GmFhqy551F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuzZYtVYAE4CPO.jpg",
        "id_str" : "777912303152836608",
        "id" : 777912303152836608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuzZYtVYAE4CPO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 1266
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 1266
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/GmFhqy551F"
      } ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 22, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777915219062296576",
    "text" : "For the first time in #SharkTank history all 6 Sharks will be in the tank! Don't miss Friday's season premiere. https:\/\/t.co\/GmFhqy551F",
    "id" : 777915219062296576,
    "created_at" : "2016-09-19 17:00:15 +0000",
    "user" : {
      "name" : "Shark Tank",
      "screen_name" : "ABCSharkTank",
      "protected" : false,
      "id_str" : "468583731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801183221949943808\/tglqEN_Q_normal.jpg",
      "id" : 468583731,
      "verified" : true
    }
  },
  "id" : 778237222181072896,
  "created_at" : "2016-09-20 14:19:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregg\uD83D\uDC3B",
      "screen_name" : "greekkid31",
      "indices" : [ 3, 14 ],
      "id_str" : "27837503",
      "id" : 27837503
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 16, 28 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778237115284979712",
  "text" : "RT @greekkid31: @KassyDillon what is it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "778037327796985856",
    "geo" : { },
    "id_str" : "778069815080603648",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon what is it?",
    "id" : 778069815080603648,
    "in_reply_to_status_id" : 778037327796985856,
    "created_at" : "2016-09-20 03:14:34 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "Gregg\uD83D\uDC3B",
      "screen_name" : "greekkid31",
      "protected" : false,
      "id_str" : "27837503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/987481596075835392\/RCYDY64s_normal.jpg",
      "id" : 27837503,
      "verified" : false
    }
  },
  "id" : 778237115284979712,
  "created_at" : "2016-09-20 14:19:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778236763924037633",
  "text" : "Things can go from zero to one hundred real quick",
  "id" : 778236763924037633,
  "created_at" : "2016-09-20 14:17:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777864251985854464",
  "text" : "RT @BarbaraCorcoran: I look for the same 3 traits in every entrepreneur I choose to work with: good character, lots of enthusiasm, and genu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "777216933024464897",
    "text" : "I look for the same 3 traits in every entrepreneur I choose to work with: good character, lots of enthusiasm, and genuine thankfulness.",
    "id" : 777216933024464897,
    "created_at" : "2016-09-17 18:45:31 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 777864251985854464,
  "created_at" : "2016-09-19 13:37:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/777864062814355456\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/FTya6It3GI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsuHPGnWEAAgclf.jpg",
      "id_str" : "777864054194966528",
      "id" : 777864054194966528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsuHPGnWEAAgclf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/FTya6It3GI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "777864062814355456",
  "text" : "Best order ID ever!!! ~ Mr.Zekai https:\/\/t.co\/FTya6It3GI",
  "id" : 777864062814355456,
  "created_at" : "2016-09-19 13:36:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/4O6hS0uWlh",
      "expanded_url" : "http:\/\/mashable.com\/2016\/09\/16\/dyson-supersonic-review\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/09\/16\/dys\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776841895049883649",
  "text" : "RT @EmperorDarroux: Dyson Supersonic blows away the competition, but it comes with a steep price https:\/\/t.co\/4O6hS0uWlh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/4O6hS0uWlh",
        "expanded_url" : "http:\/\/mashable.com\/2016\/09\/16\/dyson-supersonic-review\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/09\/16\/dys\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776822136530833408",
    "text" : "Dyson Supersonic blows away the competition, but it comes with a steep price https:\/\/t.co\/4O6hS0uWlh",
    "id" : 776822136530833408,
    "created_at" : "2016-09-16 16:36:44 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776841895049883649,
  "created_at" : "2016-09-16 17:55:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776841869334568960",
  "text" : "Someone said I was smooth, they have absolutely no idea",
  "id" : 776841869334568960,
  "created_at" : "2016-09-16 17:55:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/776841779584888832\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/KNBtJQ8M3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsfleU1WYAAhEp1.jpg",
      "id_str" : "776841769896009728",
      "id" : 776841769896009728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsfleU1WYAAhEp1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KNBtJQ8M3m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776841779584888832",
  "text" : "These were delicious https:\/\/t.co\/KNBtJQ8M3m",
  "id" : 776841779584888832,
  "created_at" : "2016-09-16 17:54:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/776820505185779713\/video\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/bYaEOpWjYD",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776820445421170688\/pu\/img\/hL14AZokBGU4AeY2.jpg",
      "id_str" : "776820445421170688",
      "id" : 776820445421170688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776820445421170688\/pu\/img\/hL14AZokBGU4AeY2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/bYaEOpWjYD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/npBF4I38xL",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=GqfAzpTGPGo",
      "display_url" : "youtube.com\/watch?v=GqfAzp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776822593206751232",
  "text" : "RT @scrowder: A ride along in Detroit with Not Gay Jared. What could go wrong? FULL VIDEO &gt;&gt; https:\/\/t.co\/npBF4I38xL https:\/\/t.co\/bYaEOpWjYD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/776820505185779713\/video\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/bYaEOpWjYD",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776820445421170688\/pu\/img\/hL14AZokBGU4AeY2.jpg",
        "id_str" : "776820445421170688",
        "id" : 776820445421170688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776820445421170688\/pu\/img\/hL14AZokBGU4AeY2.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/bYaEOpWjYD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/npBF4I38xL",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=GqfAzpTGPGo",
        "display_url" : "youtube.com\/watch?v=GqfAzp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776820505185779713",
    "text" : "A ride along in Detroit with Not Gay Jared. What could go wrong? FULL VIDEO &gt;&gt; https:\/\/t.co\/npBF4I38xL https:\/\/t.co\/bYaEOpWjYD",
    "id" : 776820505185779713,
    "created_at" : "2016-09-16 16:30:15 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 776822593206751232,
  "created_at" : "2016-09-16 16:38:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776822326491017220",
  "text" : "RT @OfficialWestJR: I'll just get the iPhone 7 when they release the iPhone 8 \uD83D\uDC80",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776804406415065088",
    "text" : "I'll just get the iPhone 7 when they release the iPhone 8 \uD83D\uDC80",
    "id" : 776804406415065088,
    "created_at" : "2016-09-16 15:26:17 +0000",
    "user" : {
      "name" : "\uD83C\uDDED\uD83C\uDDF9\u0627\u0644\u062D\u0645\u062F \u0644\u0644\u0647\uD83C\uDDF9\uD83C\uDDFF",
      "screen_name" : "IamWestOfficial",
      "protected" : false,
      "id_str" : "230627444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948336343091990528\/Vi1FFe9s_normal.jpg",
      "id" : 230627444,
      "verified" : false
    }
  },
  "id" : 776822326491017220,
  "created_at" : "2016-09-16 16:37:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Sally Kohn",
      "screen_name" : "sallykohn",
      "indices" : [ 115, 125 ],
      "id_str" : "18978610",
      "id" : 18978610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776822263467372544",
  "text" : "RT @scrowder: Only cowards argue over social media then refuse to show up for the live debate. I very much respect @sallykohn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sally Kohn",
        "screen_name" : "sallykohn",
        "indices" : [ 101, 111 ],
        "id_str" : "18978610",
        "id" : 18978610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776781227437076480",
    "text" : "Only cowards argue over social media then refuse to show up for the live debate. I very much respect @sallykohn",
    "id" : 776781227437076480,
    "created_at" : "2016-09-16 13:54:11 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 776822263467372544,
  "created_at" : "2016-09-16 16:37:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776819520187031553",
  "text" : "Had cherry blue lenonade and now having nachos at fireside while listening about Hispanic culture and scandals #ThisIsOU",
  "id" : 776819520187031553,
  "created_at" : "2016-09-16 16:26:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMD",
      "screen_name" : "AMD",
      "indices" : [ 44, 48 ],
      "id_str" : "14861876",
      "id" : 14861876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AMDRTP",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776818698187378689",
  "text" : "RT @reviewsbygarry: I want to say thanks to @AMD &amp; the #AMDRTP, you guys have given me the ability to distract myself &amp; enjoy PC building t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMD",
        "screen_name" : "AMD",
        "indices" : [ 24, 28 ],
        "id_str" : "14861876",
        "id" : 14861876
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AMDRTP",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776670805384200192",
    "text" : "I want to say thanks to @AMD &amp; the #AMDRTP, you guys have given me the ability to distract myself &amp; enjoy PC building through hard times.",
    "id" : 776670805384200192,
    "created_at" : "2016-09-16 06:35:24 +0000",
    "user" : {
      "name" : "Kelly",
      "screen_name" : "KellyKel1983",
      "protected" : false,
      "id_str" : "229348299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992092352104796171\/SjQJ5yRX_normal.jpg",
      "id" : 229348299,
      "verified" : false
    }
  },
  "id" : 776818698187378689,
  "created_at" : "2016-09-16 16:23:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Citadel",
      "screen_name" : "CITADEL",
      "indices" : [ 3, 11 ],
      "id_str" : "3869825772",
      "id" : 3869825772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Kzws6IGYCp",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce546vqq7\/25znu",
      "display_url" : "cards.twitter.com\/cards\/18ce546v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776781084268851200",
  "text" : "RT @CITADEL: Bloomberg on Citadel Securities\u2019 \u201CLean, Mean, Derivatives Machine\u201D https:\/\/t.co\/Kzws6IGYCp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Kzws6IGYCp",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/18ce546vqq7\/25znu",
        "display_url" : "cards.twitter.com\/cards\/18ce546v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771781533061435392",
    "text" : "Bloomberg on Citadel Securities\u2019 \u201CLean, Mean, Derivatives Machine\u201D https:\/\/t.co\/Kzws6IGYCp",
    "id" : 771781533061435392,
    "created_at" : "2016-09-02 18:47:11 +0000",
    "user" : {
      "name" : "Citadel",
      "screen_name" : "CITADEL",
      "protected" : false,
      "id_str" : "3869825772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808795543321317376\/gEv6nLZV_normal.jpg",
      "id" : 3869825772,
      "verified" : false
    }
  },
  "id" : 776781084268851200,
  "created_at" : "2016-09-16 13:53:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariners",
      "screen_name" : "Mariners",
      "indices" : [ 3, 12 ],
      "id_str" : "41488578",
      "id" : 41488578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mariners",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "GoMariners",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776780958448160768",
  "text" : "RT @Mariners: Sweep! #Mariners take all three from the Angels and finish the road trip a perfect 6-0. FINAL: 2-1. #GoMariners https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mariners\/status\/776286868933488640\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/BBXTO5xJmn",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CsXsnYTVYAEPzdv.jpg",
        "id_str" : "776286672073875457",
        "id" : 776286672073875457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CsXsnYTVYAEPzdv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 400
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/BBXTO5xJmn"
      } ],
      "hashtags" : [ {
        "text" : "Mariners",
        "indices" : [ 7, 16 ]
      }, {
        "text" : "GoMariners",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776286868933488640",
    "text" : "Sweep! #Mariners take all three from the Angels and finish the road trip a perfect 6-0. FINAL: 2-1. #GoMariners https:\/\/t.co\/BBXTO5xJmn",
    "id" : 776286868933488640,
    "created_at" : "2016-09-15 05:09:46 +0000",
    "user" : {
      "name" : "Mariners",
      "screen_name" : "Mariners",
      "protected" : false,
      "id_str" : "41488578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993535992387665920\/TV9DTuis_normal.jpg",
      "id" : 41488578,
      "verified" : true
    }
  },
  "id" : 776780958448160768,
  "created_at" : "2016-09-16 13:53:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776780478661685248",
  "geo" : { },
  "id_str" : "776780888172531712",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 *apply",
  "id" : 776780888172531712,
  "in_reply_to_status_id" : 776780478661685248,
  "created_at" : "2016-09-16 13:52:50 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/fP8mDiIA6C",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=5ONb3sCqxho",
      "display_url" : "youtube.com\/watch?v=5ONb3s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776780756794224641",
  "text" : "RT @scrowder: Brand new #LwC coming your way tomorrow night! Until then catch up with last week's stream &gt; https:\/\/t.co\/fP8mDiIA6C https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/776269112523841536\/video\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/WXk66Dfthf",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776269057712615424\/pu\/img\/R7cHVyfcf_U61-fU.jpg",
        "id_str" : "776269057712615424",
        "id" : 776269057712615424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/776269057712615424\/pu\/img\/R7cHVyfcf_U61-fU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/WXk66Dfthf"
      } ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 10, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/fP8mDiIA6C",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=5ONb3sCqxho",
        "display_url" : "youtube.com\/watch?v=5ONb3s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776269112523841536",
    "text" : "Brand new #LwC coming your way tomorrow night! Until then catch up with last week's stream &gt; https:\/\/t.co\/fP8mDiIA6C https:\/\/t.co\/WXk66Dfthf",
    "id" : 776269112523841536,
    "created_at" : "2016-09-15 03:59:13 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 776780756794224641,
  "created_at" : "2016-09-16 13:52:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776780478661685248",
  "text" : "Easy come, easy go can reply to relationships to \uD83D\uDE22",
  "id" : 776780478661685248,
  "created_at" : "2016-09-16 13:51:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776244033563885568",
  "text" : "RT @JeffJPetermann: President Donald J. Trump should go YUUUGE with his presidential powers and pardon Edward Snowden. #justsayin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justsayin",
        "indices" : [ 99, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776209130180587520",
    "text" : "President Donald J. Trump should go YUUUGE with his presidential powers and pardon Edward Snowden. #justsayin",
    "id" : 776209130180587520,
    "created_at" : "2016-09-15 00:00:52 +0000",
    "user" : {
      "name" : "CMG Marketing & PR",
      "screen_name" : "URMarketingGuru",
      "protected" : false,
      "id_str" : "25062618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/966311712369627136\/IjwDPThi_normal.jpg",
      "id" : 25062618,
      "verified" : false
    }
  },
  "id" : 776244033563885568,
  "created_at" : "2016-09-15 02:19:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776187068414324739",
  "geo" : { },
  "id_str" : "776187212232814592",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget It is about time!",
  "id" : 776187212232814592,
  "in_reply_to_status_id" : 776187068414324739,
  "created_at" : "2016-09-14 22:33:46 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Dade",
      "screen_name" : "dade_paul",
      "indices" : [ 0, 10 ],
      "id_str" : "4569419053",
      "id" : 4569419053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776185239525785602",
  "geo" : { },
  "id_str" : "776187117777063937",
  "in_reply_to_user_id" : 4569419053,
  "text" : "@dade_paul I am not a fan of shortened links if it is a site used to investigate finances",
  "id" : 776187117777063937,
  "in_reply_to_status_id" : 776185239525785602,
  "created_at" : "2016-09-14 22:33:24 +0000",
  "in_reply_to_screen_name" : "dade_paul",
  "in_reply_to_user_id_str" : "4569419053",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776186963812556801",
  "text" : "RT @SpaceX: If you have audio, photos or videos of our anomaly last week, please send to report@spacex.com. Material may be useful for inve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774272189419839489",
    "text" : "If you have audio, photos or videos of our anomaly last week, please send to report@spacex.com. Material may be useful for investigation",
    "id" : 774272189419839489,
    "created_at" : "2016-09-09 15:44:09 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 776186963812556801,
  "created_at" : "2016-09-14 22:32:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/CJq5g3NIEK",
      "expanded_url" : "http:\/\/spacenews.com\/op-ed-despite-spacex-setback-future-of-private-space-exploration-is-bright\/",
      "display_url" : "spacenews.com\/op-ed-despite-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776186913749405696",
  "text" : "RT @elonmusk: Thoughtful Op-ed in Space News much appreciated https:\/\/t.co\/CJq5g3NIEK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/CJq5g3NIEK",
        "expanded_url" : "http:\/\/spacenews.com\/op-ed-despite-spacex-setback-future-of-private-space-exploration-is-bright\/",
        "display_url" : "spacenews.com\/op-ed-despite-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774337231708299264",
    "text" : "Thoughtful Op-ed in Space News much appreciated https:\/\/t.co\/CJq5g3NIEK",
    "id" : 774337231708299264,
    "created_at" : "2016-09-09 20:02:37 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 776186913749405696,
  "created_at" : "2016-09-14 22:32:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776186865598607360",
  "text" : "RT @elonmusk: Tesla Model S loses 28% after 50k miles, a Mercedes S-Class will lose 38%, a BMW 7-series will lose 40%, and an Audi A8 will\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775819887348363268",
    "geo" : { },
    "id_str" : "775820980480380928",
    "in_reply_to_user_id" : 44196397,
    "text" : "Tesla Model S loses 28% after 50k miles, a Mercedes S-Class will lose 38%, a BMW 7-series will lose 40%, and an Audi A8 will lose 41%.",
    "id" : 775820980480380928,
    "in_reply_to_status_id" : 775819887348363268,
    "created_at" : "2016-09-13 22:18:30 +0000",
    "in_reply_to_screen_name" : "elonmusk",
    "in_reply_to_user_id_str" : "44196397",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 776186865598607360,
  "created_at" : "2016-09-14 22:32:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776186781280702465",
  "text" : "Tim Cook also believes that Augmented Reality is cooler than VR",
  "id" : 776186781280702465,
  "created_at" : "2016-09-14 22:32:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProTip",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776182393153658882",
  "text" : "#ProTip Equity is better than being in debt in the very beginning of ur Startup so u can be more focused on making money than paying back",
  "id" : 776182393153658882,
  "created_at" : "2016-09-14 22:14:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776182112802185216",
  "text" : "Always pause your Forex or binary options trades when you are outside",
  "id" : 776182112802185216,
  "created_at" : "2016-09-14 22:13:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/srK5Qwd1eZ",
      "expanded_url" : "http:\/\/fb.me\/84ed0ZdMd",
      "display_url" : "fb.me\/84ed0ZdMd"
    } ]
  },
  "geo" : { },
  "id_str" : "776174971622199296",
  "text" : "RT @EmperorDarroux: 'Destiny: Rise of Iron' delivers a new challenge in Archon's Forge https:\/\/t.co\/srK5Qwd1eZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/srK5Qwd1eZ",
        "expanded_url" : "http:\/\/fb.me\/84ed0ZdMd",
        "display_url" : "fb.me\/84ed0ZdMd"
      } ]
    },
    "geo" : { },
    "id_str" : "776146253637783552",
    "text" : "'Destiny: Rise of Iron' delivers a new challenge in Archon's Forge https:\/\/t.co\/srK5Qwd1eZ",
    "id" : 776146253637783552,
    "created_at" : "2016-09-14 19:51:01 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776174971622199296,
  "created_at" : "2016-09-14 21:45:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776174865686593538",
  "text" : "Yesterday I saw a Greek Orthodox person, and today I saw a Syriac Orthodox person, and I am Coptic so I got excited",
  "id" : 776174865686593538,
  "created_at" : "2016-09-14 21:44:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/7GouSMX20v",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/google-fiber-tv-interface-update\/",
      "display_url" : "engadget.com\/2016\/09\/14\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "776145294207614976",
  "text" : "RT @EmperorDarroux: Google Fiber TV finally gets an interface overhaul https:\/\/t.co\/7GouSMX20v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/7GouSMX20v",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/google-fiber-tv-interface-update\/",
        "display_url" : "engadget.com\/2016\/09\/14\/goo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "776143770697895936",
    "text" : "Google Fiber TV finally gets an interface overhaul https:\/\/t.co\/7GouSMX20v",
    "id" : 776143770697895936,
    "created_at" : "2016-09-14 19:41:09 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776145294207614976,
  "created_at" : "2016-09-14 19:47:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kentik",
      "screen_name" : "kentikinc",
      "indices" : [ 3, 13 ],
      "id_str" : "3345651075",
      "id" : 3345651075
    }, {
      "name" : "Jim Frey",
      "screen_name" : "jfrey80",
      "indices" : [ 92, 100 ],
      "id_str" : "16812119",
      "id" : 16812119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigData",
      "indices" : [ 22, 30 ]
    }, {
      "text" : "NetworkAnalysis",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/OZI7D8dSiU",
      "expanded_url" : "http:\/\/bit.ly\/2bH5v2k",
      "display_url" : "bit.ly\/2bH5v2k"
    } ]
  },
  "geo" : { },
  "id_str" : "776145088351174657",
  "text" : "RT @kentikinc: Why is #BigData changing network management? https:\/\/t.co\/OZI7D8dSiU Our own @jfrey80 explains #NetworkAnalysis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Frey",
        "screen_name" : "jfrey80",
        "indices" : [ 77, 85 ],
        "id_str" : "16812119",
        "id" : 16812119
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigData",
        "indices" : [ 7, 15 ]
      }, {
        "text" : "NetworkAnalysis",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/OZI7D8dSiU",
        "expanded_url" : "http:\/\/bit.ly\/2bH5v2k",
        "display_url" : "bit.ly\/2bH5v2k"
      } ]
    },
    "geo" : { },
    "id_str" : "771377136196128768",
    "text" : "Why is #BigData changing network management? https:\/\/t.co\/OZI7D8dSiU Our own @jfrey80 explains #NetworkAnalysis",
    "id" : 771377136196128768,
    "created_at" : "2016-09-01 16:00:15 +0000",
    "user" : {
      "name" : "Kentik",
      "screen_name" : "kentikinc",
      "protected" : false,
      "id_str" : "3345651075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615551766319333377\/yBBFXxpG_normal.png",
      "id" : 3345651075,
      "verified" : false
    }
  },
  "id" : 776145088351174657,
  "created_at" : "2016-09-14 19:46:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kentik",
      "screen_name" : "kentikinc",
      "indices" : [ 3, 13 ],
      "id_str" : "3345651075",
      "id" : 3345651075
    }, {
      "name" : "451 Research",
      "screen_name" : "451Research",
      "indices" : [ 83, 95 ],
      "id_str" : "11064542",
      "id" : 11064542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funding",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "BigData",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/MOACWqIT4S",
      "expanded_url" : "http:\/\/bit.ly\/2csjOZt",
      "display_url" : "bit.ly\/2csjOZt"
    } ]
  },
  "geo" : { },
  "id_str" : "776145046919839744",
  "text" : "RT @kentikinc: Kentik gets big #funding round for #BigData platform, as covered by @451Research's Jim Duffy https:\/\/t.co\/MOACWqIT4S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "451 Research",
        "screen_name" : "451Research",
        "indices" : [ 68, 80 ],
        "id_str" : "11064542",
        "id" : 11064542
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funding",
        "indices" : [ 16, 24 ]
      }, {
        "text" : "BigData",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MOACWqIT4S",
        "expanded_url" : "http:\/\/bit.ly\/2csjOZt",
        "display_url" : "bit.ly\/2csjOZt"
      } ]
    },
    "geo" : { },
    "id_str" : "773921956986892288",
    "text" : "Kentik gets big #funding round for #BigData platform, as covered by @451Research's Jim Duffy https:\/\/t.co\/MOACWqIT4S",
    "id" : 773921956986892288,
    "created_at" : "2016-09-08 16:32:27 +0000",
    "user" : {
      "name" : "Kentik",
      "screen_name" : "kentikinc",
      "protected" : false,
      "id_str" : "3345651075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615551766319333377\/yBBFXxpG_normal.png",
      "id" : 3345651075,
      "verified" : false
    }
  },
  "id" : 776145046919839744,
  "created_at" : "2016-09-14 19:46:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 3, 11 ],
      "id_str" : "91220126",
      "id" : 91220126
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776144914438553600",
  "text" : "RT @adwords: @gamer456148 We're happy to help! Don't hesitate to reach out with any questions while you get started. :) -Mitch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776144393061470208",
    "geo" : { },
    "id_str" : "776144866833293312",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 We're happy to help! Don't hesitate to reach out with any questions while you get started. :) -Mitch",
    "id" : 776144866833293312,
    "in_reply_to_status_id" : 776144393061470208,
    "created_at" : "2016-09-14 19:45:30 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "protected" : false,
      "id_str" : "91220126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618952064576585733\/0XNolOAa_normal.png",
      "id" : 91220126,
      "verified" : true
    }
  },
  "id" : 776144914438553600,
  "created_at" : "2016-09-14 19:45:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zelda Game",
      "screen_name" : "Zelda_Game",
      "indices" : [ 3, 14 ],
      "id_str" : "582674507",
      "id" : 582674507
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Anuvia\/status\/435685979823673344\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/FxD1gfAguI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgveFxdCYAAkhAb.jpg",
      "id_str" : "435685979727224832",
      "id" : 435685979727224832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgveFxdCYAAkhAb.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 393
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/FxD1gfAguI"
    } ],
    "hashtags" : [ {
      "text" : "BadSonicFanArt",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776144883870527488",
  "text" : "RT @Zelda_Game: So #BadSonicFanArt reminded me that I drew this years ago and I still laugh at it https:\/\/t.co\/FxD1gfAguI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Anuvia\/status\/435685979823673344\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/FxD1gfAguI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgveFxdCYAAkhAb.jpg",
        "id_str" : "435685979727224832",
        "id" : 435685979727224832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgveFxdCYAAkhAb.jpg",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 393
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/FxD1gfAguI"
      } ],
      "hashtags" : [ {
        "text" : "BadSonicFanArt",
        "indices" : [ 3, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775910750040780800",
    "text" : "So #BadSonicFanArt reminded me that I drew this years ago and I still laugh at it https:\/\/t.co\/FxD1gfAguI",
    "id" : 775910750040780800,
    "created_at" : "2016-09-14 04:15:13 +0000",
    "user" : {
      "name" : "Zelda Game",
      "screen_name" : "Zelda_Game",
      "protected" : false,
      "id_str" : "582674507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000481837783\/4b0da63801b08f5c55a795d14a6df432_normal.jpeg",
      "id" : 582674507,
      "verified" : false
    }
  },
  "id" : 776144883870527488,
  "created_at" : "2016-09-14 19:45:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marvel Girl",
      "screen_name" : "Iona_Marvel",
      "indices" : [ 3, 15 ],
      "id_str" : "582673817",
      "id" : 582673817
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wwwwvwwwvwvwwwv\/status\/445365648374243328\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/s7UQercYtM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi5BspMCIAAbJXY.png",
      "id_str" : "445365648382631936",
      "id" : 445365648382631936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi5BspMCIAAbJXY.png",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 488
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/s7UQercYtM"
    } ],
    "hashtags" : [ {
      "text" : "BadSonicFanArt",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776144796461203457",
  "text" : "RT @Iona_Marvel: #BadSonicFanArt Sonic Adventure 2 Battle box art by the Jim Crow Fan Club https:\/\/t.co\/s7UQercYtM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wwwwvwwwvwvwwwv\/status\/445365648374243328\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/s7UQercYtM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi5BspMCIAAbJXY.png",
        "id_str" : "445365648382631936",
        "id" : 445365648382631936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi5BspMCIAAbJXY.png",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 488
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/s7UQercYtM"
      } ],
      "hashtags" : [ {
        "text" : "BadSonicFanArt",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776079589118476292",
    "text" : "#BadSonicFanArt Sonic Adventure 2 Battle box art by the Jim Crow Fan Club https:\/\/t.co\/s7UQercYtM",
    "id" : 776079589118476292,
    "created_at" : "2016-09-14 15:26:07 +0000",
    "user" : {
      "name" : "Marvel Girl",
      "screen_name" : "Iona_Marvel",
      "protected" : false,
      "id_str" : "582673817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818837225093742593\/OxqjOC5H_normal.jpg",
      "id" : 582673817,
      "verified" : false
    }
  },
  "id" : 776144796461203457,
  "created_at" : "2016-09-14 19:45:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776144527207858176",
  "text" : "I have way too much caffeine, lol",
  "id" : 776144527207858176,
  "created_at" : "2016-09-14 19:44:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 3, 11 ],
      "id_str" : "91220126",
      "id" : 91220126
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/f0IQDjSoL2",
      "expanded_url" : "https:\/\/goo.gl\/m3osbq",
      "display_url" : "goo.gl\/m3osbq"
    } ]
  },
  "geo" : { },
  "id_str" : "776144408995565568",
  "text" : "RT @adwords: @gamer456148 This article has more information on choosing a competitive bid amount: https:\/\/t.co\/f0IQDjSoL2 -Mitch (2)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/f0IQDjSoL2",
        "expanded_url" : "https:\/\/goo.gl\/m3osbq",
        "display_url" : "goo.gl\/m3osbq"
      } ]
    },
    "in_reply_to_status_id_str" : "776135843429965824",
    "geo" : { },
    "id_str" : "776144260836028416",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 This article has more information on choosing a competitive bid amount: https:\/\/t.co\/f0IQDjSoL2 -Mitch (2)",
    "id" : 776144260836028416,
    "in_reply_to_status_id" : 776135843429965824,
    "created_at" : "2016-09-14 19:43:06 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "protected" : false,
      "id_str" : "91220126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618952064576585733\/0XNolOAa_normal.png",
      "id" : 91220126,
      "verified" : true
    }
  },
  "id" : 776144408995565568,
  "created_at" : "2016-09-14 19:43:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 0, 8 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776144260836028416",
  "geo" : { },
  "id_str" : "776144393061470208",
  "in_reply_to_user_id" : 91220126,
  "text" : "@adwords Thank you for the outstanding support!!! May try it for my app startup :)",
  "id" : 776144393061470208,
  "in_reply_to_status_id" : 776144260836028416,
  "created_at" : "2016-09-14 19:43:38 +0000",
  "in_reply_to_screen_name" : "adwords",
  "in_reply_to_user_id_str" : "91220126",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 3, 11 ],
      "id_str" : "91220126",
      "id" : 91220126
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 13, 25 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776144208734420993",
  "text" : "RT @adwords: @gamer456148 Hi Andrew, there is no minimum bid, but you may need to bid higher on competitive keywords. (1)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776135843429965824",
    "geo" : { },
    "id_str" : "776144103230824448",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Hi Andrew, there is no minimum bid, but you may need to bid higher on competitive keywords. (1)",
    "id" : 776144103230824448,
    "in_reply_to_status_id" : 776135843429965824,
    "created_at" : "2016-09-14 19:42:28 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "protected" : false,
      "id_str" : "91220126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618952064576585733\/0XNolOAa_normal.png",
      "id" : 91220126,
      "verified" : true
    }
  },
  "id" : 776144208734420993,
  "created_at" : "2016-09-14 19:42:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Stacia_Takala\/status\/741226249968865281\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ZTa78DArPy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkldV-uUYAA5Flz.jpg",
      "id_str" : "741226245875064832",
      "id" : 741226245875064832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkldV-uUYAA5Flz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 768
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ZTa78DArPy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/nBvQaKWE6F",
      "expanded_url" : "http:\/\/goo.gl\/rCrIIH",
      "display_url" : "goo.gl\/rCrIIH"
    } ]
  },
  "geo" : { },
  "id_str" : "776138039466876928",
  "text" : "RT @BestGamezUp: BS Characters in Overwatch - Top 10 https:\/\/t.co\/nBvQaKWE6F https:\/\/t.co\/ZTa78DArPy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Stacia_Takala\/status\/741226249968865281\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/ZTa78DArPy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkldV-uUYAA5Flz.jpg",
        "id_str" : "741226245875064832",
        "id" : 741226245875064832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkldV-uUYAA5Flz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 768
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZTa78DArPy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/nBvQaKWE6F",
        "expanded_url" : "http:\/\/goo.gl\/rCrIIH",
        "display_url" : "goo.gl\/rCrIIH"
      } ]
    },
    "geo" : { },
    "id_str" : "776122244204560385",
    "text" : "BS Characters in Overwatch - Top 10 https:\/\/t.co\/nBvQaKWE6F https:\/\/t.co\/ZTa78DArPy",
    "id" : 776122244204560385,
    "created_at" : "2016-09-14 18:15:37 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 776138039466876928,
  "created_at" : "2016-09-14 19:18:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chick-fil-A, Inc.",
      "screen_name" : "ChickfilA",
      "indices" : [ 3, 13 ],
      "id_str" : "16043308",
      "id" : 16043308
    }, {
      "name" : "BillieJean",
      "screen_name" : "BilliejeanBrown",
      "indices" : [ 15, 31 ],
      "id_str" : "940524696",
      "id" : 940524696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776137279354073088",
  "text" : "RT @ChickfilA: @BilliejeanBrown Don't forget the Chick-fil-A Sauce! \uD83D\uDE0B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BillieJean",
        "screen_name" : "BilliejeanBrown",
        "indices" : [ 0, 16 ],
        "id_str" : "940524696",
        "id" : 940524696
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "776116159963811841",
    "geo" : { },
    "id_str" : "776136182732320769",
    "in_reply_to_user_id" : 940524696,
    "text" : "@BilliejeanBrown Don't forget the Chick-fil-A Sauce! \uD83D\uDE0B",
    "id" : 776136182732320769,
    "in_reply_to_status_id" : 776116159963811841,
    "created_at" : "2016-09-14 19:11:00 +0000",
    "in_reply_to_screen_name" : "BilliejeanBrown",
    "in_reply_to_user_id_str" : "940524696",
    "user" : {
      "name" : "Chick-fil-A, Inc.",
      "screen_name" : "ChickfilA",
      "protected" : false,
      "id_str" : "16043308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/984417024506986496\/PNkWrGYH_normal.jpg",
      "id" : 16043308,
      "verified" : true
    }
  },
  "id" : 776137279354073088,
  "created_at" : "2016-09-14 19:15:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chick-fil-A, Inc.",
      "screen_name" : "ChickfilA",
      "indices" : [ 3, 13 ],
      "id_str" : "16043308",
      "id" : 16043308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776137152396685313",
  "text" : "RT @ChickfilA: Find someone who looks at you the way you look at Waffle Fries. \uD83D\uDE0D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776110790583595008",
    "text" : "Find someone who looks at you the way you look at Waffle Fries. \uD83D\uDE0D",
    "id" : 776110790583595008,
    "created_at" : "2016-09-14 17:30:06 +0000",
    "user" : {
      "name" : "Chick-fil-A, Inc.",
      "screen_name" : "ChickfilA",
      "protected" : false,
      "id_str" : "16043308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/984417024506986496\/PNkWrGYH_normal.jpg",
      "id" : 16043308,
      "verified" : true
    }
  },
  "id" : 776137152396685313,
  "created_at" : "2016-09-14 19:14:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 3, 14 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776137112798302208",
  "text" : "RT @jacksfilms: Today is National Cream-Filled Donut Day\n\nBecause we definitely needed a holiday for those",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776124369051398144",
    "text" : "Today is National Cream-Filled Donut Day\n\nBecause we definitely needed a holiday for those",
    "id" : 776124369051398144,
    "created_at" : "2016-09-14 18:24:03 +0000",
    "user" : {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "protected" : false,
      "id_str" : "9989862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/988175463880142848\/Ozk80qgf_normal.jpg",
      "id" : 9989862,
      "verified" : true
    }
  },
  "id" : 776137112798302208,
  "created_at" : "2016-09-14 19:14:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/BJxbiITQ4x",
      "expanded_url" : "http:\/\/ow.ly\/fPuq3046on3",
      "display_url" : "ow.ly\/fPuq3046on3"
    } ]
  },
  "geo" : { },
  "id_str" : "776136862708670468",
  "text" : "RT @analyticbridge: Predicting success: How Social Physics is changing the world we live in https:\/\/t.co\/BJxbiITQ4x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/BJxbiITQ4x",
        "expanded_url" : "http:\/\/ow.ly\/fPuq3046on3",
        "display_url" : "ow.ly\/fPuq3046on3"
      } ]
    },
    "geo" : { },
    "id_str" : "776134172977004544",
    "text" : "Predicting success: How Social Physics is changing the world we live in https:\/\/t.co\/BJxbiITQ4x",
    "id" : 776134172977004544,
    "created_at" : "2016-09-14 19:03:01 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 776136862708670468,
  "created_at" : "2016-09-14 19:13:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harley-Davidson CAN",
      "screen_name" : "HarleyCanada",
      "indices" : [ 3, 16 ],
      "id_str" : "1197167990",
      "id" : 1197167990
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HarleyCanada\/status\/774638791025975296\/video\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ZjvrZGWKtI",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774638661946179585\/pu\/img\/uGb1YlawcDbky_Jj.jpg",
      "id_str" : "774638661946179585",
      "id" : 774638661946179585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774638661946179585\/pu\/img\/uGb1YlawcDbky_Jj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ZjvrZGWKtI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776136537088155648",
  "text" : "RT @HarleyCanada: Go behind the scenes to see how we crafted the Milwaukee-Eight, our ninth Big Twin. https:\/\/t.co\/ZjvrZGWKtI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HarleyCanada\/status\/774638791025975296\/video\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/ZjvrZGWKtI",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774638661946179585\/pu\/img\/uGb1YlawcDbky_Jj.jpg",
        "id_str" : "774638661946179585",
        "id" : 774638661946179585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774638661946179585\/pu\/img\/uGb1YlawcDbky_Jj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZjvrZGWKtI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774638791025975296",
    "text" : "Go behind the scenes to see how we crafted the Milwaukee-Eight, our ninth Big Twin. https:\/\/t.co\/ZjvrZGWKtI",
    "id" : 774638791025975296,
    "created_at" : "2016-09-10 16:00:54 +0000",
    "user" : {
      "name" : "Harley-Davidson CAN",
      "screen_name" : "HarleyCanada",
      "protected" : false,
      "id_str" : "1197167990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479323462071107584\/WmQp25rT_normal.jpeg",
      "id" : 1197167990,
      "verified" : true
    }
  },
  "id" : 776136537088155648,
  "created_at" : "2016-09-14 19:12:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "indices" : [ 3, 12 ],
      "id_str" : "40369362",
      "id" : 40369362
    }, {
      "name" : "Harley-Davidson CAN",
      "screen_name" : "HarleyCanada",
      "indices" : [ 111, 124 ],
      "id_str" : "1197167990",
      "id" : 1197167990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Harley",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "MilwaukeeEight",
      "indices" : [ 47, 62 ]
    }, {
      "text" : "MOTORESS",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6BoysVQMNk",
      "expanded_url" : "http:\/\/ow.ly\/OZQ1304bIlb",
      "display_url" : "ow.ly\/OZQ1304bIlb"
    } ]
  },
  "geo" : { },
  "id_str" : "776136284905627648",
  "text" : "RT @MOTORESS: Newest Big Twin #Harley-Davidson #MilwaukeeEight Delivers More #MOTORESS https:\/\/t.co\/6BoysVQMNk @HarleyCanada https:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harley-Davidson CAN",
        "screen_name" : "HarleyCanada",
        "indices" : [ 97, 110 ],
        "id_str" : "1197167990",
        "id" : 1197167990
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MOTORESS\/status\/776133953375899648\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/B1ethQDb4M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsVht04XYAAFKW0.jpg",
        "id_str" : "776133950708342784",
        "id" : 776133950708342784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsVht04XYAAFKW0.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 788
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 788
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/B1ethQDb4M"
      } ],
      "hashtags" : [ {
        "text" : "Harley",
        "indices" : [ 16, 23 ]
      }, {
        "text" : "MilwaukeeEight",
        "indices" : [ 33, 48 ]
      }, {
        "text" : "MOTORESS",
        "indices" : [ 63, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/6BoysVQMNk",
        "expanded_url" : "http:\/\/ow.ly\/OZQ1304bIlb",
        "display_url" : "ow.ly\/OZQ1304bIlb"
      } ]
    },
    "geo" : { },
    "id_str" : "776133953375899648",
    "text" : "Newest Big Twin #Harley-Davidson #MilwaukeeEight Delivers More #MOTORESS https:\/\/t.co\/6BoysVQMNk @HarleyCanada https:\/\/t.co\/B1ethQDb4M",
    "id" : 776133953375899648,
    "created_at" : "2016-09-14 19:02:09 +0000",
    "user" : {
      "name" : "Vicki Gray MOTORESS",
      "screen_name" : "MOTORESS",
      "protected" : false,
      "id_str" : "40369362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688408819496521729\/vGa13GuH_normal.jpg",
      "id" : 40369362,
      "verified" : false
    }
  },
  "id" : 776136284905627648,
  "created_at" : "2016-09-14 19:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 16, 25 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776133894542241792",
  "geo" : { },
  "id_str" : "776136253863563264",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @mashable Well ....",
  "id" : 776136253863563264,
  "in_reply_to_status_id" : 776133894542241792,
  "created_at" : "2016-09-14 19:11:17 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776136126910361601",
  "text" : "RT @_DopeFetish: You'll notice so much if you just peep and listen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776109142771638273",
    "text" : "You'll notice so much if you just peep and listen.",
    "id" : 776109142771638273,
    "created_at" : "2016-09-14 17:23:33 +0000",
    "user" : {
      "name" : "CB\uD83D\uDC73\uD83C\uDFFD\u200D\u2642\uFE0F",
      "screen_name" : "TheRealCB___954",
      "protected" : false,
      "id_str" : "3219697120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/988375540565532673\/8iMTUruT_normal.jpg",
      "id" : 3219697120,
      "verified" : false
    }
  },
  "id" : 776136126910361601,
  "created_at" : "2016-09-14 19:10:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/4Y0w6G3AzC",
      "expanded_url" : "http:\/\/bit.ly\/2crcQEy",
      "display_url" : "bit.ly\/2crcQEy"
    } ]
  },
  "geo" : { },
  "id_str" : "776136067040813056",
  "text" : "RT @GuyKawasaki: Canva just raised $15m without even touching the funds from its last round https:\/\/t.co\/4Y0w6G3AzC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/4Y0w6G3AzC",
        "expanded_url" : "http:\/\/bit.ly\/2crcQEy",
        "display_url" : "bit.ly\/2crcQEy"
      } ]
    },
    "geo" : { },
    "id_str" : "776133413908590592",
    "text" : "Canva just raised $15m without even touching the funds from its last round https:\/\/t.co\/4Y0w6G3AzC",
    "id" : 776133413908590592,
    "created_at" : "2016-09-14 19:00:00 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 776136067040813056,
  "created_at" : "2016-09-14 19:10:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ES_F",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776135913923543044",
  "text" : "RT @HamzeiAnalytics: BLOCK TRADE detected in #ES_F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ES_F",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776132389382660096",
    "text" : "BLOCK TRADE detected in #ES_F",
    "id" : 776132389382660096,
    "created_at" : "2016-09-14 18:55:56 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 776135913923543044,
  "created_at" : "2016-09-14 19:09:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sport",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/flhNrjCOsW",
      "expanded_url" : "http:\/\/es.pn\/2cu5KhD",
      "display_url" : "es.pn\/2cu5KhD"
    } ]
  },
  "geo" : { },
  "id_str" : "776135895942590465",
  "text" : "RT @FXStefan: Bosh: 'Absolutely' ready to join Heat for camp: Bosh: 'Absolutely' ready to join Heat for camp https:\/\/t.co\/flhNrjCOsW #sport\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "nba",
        "indices" : [ 126, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/flhNrjCOsW",
        "expanded_url" : "http:\/\/es.pn\/2cu5KhD",
        "display_url" : "es.pn\/2cu5KhD"
      } ]
    },
    "geo" : { },
    "id_str" : "776132243618017280",
    "text" : "Bosh: 'Absolutely' ready to join Heat for camp: Bosh: 'Absolutely' ready to join Heat for camp https:\/\/t.co\/flhNrjCOsW #sport #nba",
    "id" : 776132243618017280,
    "created_at" : "2016-09-14 18:55:21 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 776135895942590465,
  "created_at" : "2016-09-14 19:09:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 0, 8 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776132156590530560",
  "geo" : { },
  "id_str" : "776135843429965824",
  "in_reply_to_user_id" : 91220126,
  "text" : "@adwords What's the minimum bid though?",
  "id" : 776135843429965824,
  "in_reply_to_status_id" : 776132156590530560,
  "created_at" : "2016-09-14 19:09:39 +0000",
  "in_reply_to_screen_name" : "adwords",
  "in_reply_to_user_id_str" : "91220126",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776135702375464961",
  "text" : "Hate it when I give an awkward side hug",
  "id" : 776135702375464961,
  "created_at" : "2016-09-14 19:09:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776132620782559233",
  "text" : "You think GitHub might have a feature in the future where it counts how many lines of code you typed in all the repositories you contributed",
  "id" : 776132620782559233,
  "created_at" : "2016-09-14 18:56:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 34, 41 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/776132454004449281\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ErJFaxE24x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsVgWCXWIAANiey.jpg",
      "id_str" : "776132442499457024",
      "id" : 776132442499457024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsVgWCXWIAANiey.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 951,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 951,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 951,
        "resize" : "fit",
        "w" : 1180
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ErJFaxE24x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776132454004449281",
  "text" : "Not sure how I feel about the new @github UI or even twitter's purple homepage https:\/\/t.co\/ErJFaxE24x",
  "id" : 776132454004449281,
  "created_at" : "2016-09-14 18:56:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/rEEFPtuy8k",
      "expanded_url" : "http:\/\/fb.me\/8baKWMec5",
      "display_url" : "fb.me\/8baKWMec5"
    } ]
  },
  "geo" : { },
  "id_str" : "776126300956286976",
  "text" : "RT @EmperorDarroux: Our brains still light up with emotions even when we relax, study finds https:\/\/t.co\/rEEFPtuy8k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/rEEFPtuy8k",
        "expanded_url" : "http:\/\/fb.me\/8baKWMec5",
        "display_url" : "fb.me\/8baKWMec5"
      } ]
    },
    "geo" : { },
    "id_str" : "776122641329459202",
    "text" : "Our brains still light up with emotions even when we relax, study finds https:\/\/t.co\/rEEFPtuy8k",
    "id" : 776122641329459202,
    "created_at" : "2016-09-14 18:17:12 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776126300956286976,
  "created_at" : "2016-09-14 18:31:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "indices" : [ 3, 14 ],
      "id_str" : "552147406",
      "id" : 552147406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776126242005327872",
  "text" : "RT @TriviaHive: You cannot cross the U.S.-Canada boarder if you are 17 years or younger regardless of your I.D. unless you are accompanied\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "776122092710457344",
    "text" : "You cannot cross the U.S.-Canada boarder if you are 17 years or younger regardless of your I.D. unless you are accompanied by an adult",
    "id" : 776122092710457344,
    "created_at" : "2016-09-14 18:15:01 +0000",
    "user" : {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "protected" : false,
      "id_str" : "552147406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705567159968071680\/PQrm33In_normal.jpg",
      "id" : 552147406,
      "verified" : false
    }
  },
  "id" : 776126242005327872,
  "created_at" : "2016-09-14 18:31:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776126177094275073",
  "text" : "Neebo books didn't buy any of my old college textbooks, great \uD83D\uDE14",
  "id" : 776126177094275073,
  "created_at" : "2016-09-14 18:31:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Tippy",
      "screen_name" : "NathanTippy",
      "indices" : [ 3, 15 ],
      "id_str" : "20254407",
      "id" : 20254407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776121333465972736",
  "text" : "RT @NathanTippy: Just starting out? Do not be overwelmed by the modern trends. Instead focus your time on the well established fundamentals.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771884124219072512",
    "text" : "Just starting out? Do not be overwelmed by the modern trends. Instead focus your time on the well established fundamentals.",
    "id" : 771884124219072512,
    "created_at" : "2016-09-03 01:34:50 +0000",
    "user" : {
      "name" : "Nathan Tippy",
      "screen_name" : "NathanTippy",
      "protected" : false,
      "id_str" : "20254407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/80800277\/NathanBranson2008Small_normal.jpg",
      "id" : 20254407,
      "verified" : false
    }
  },
  "id" : 776121333465972736,
  "created_at" : "2016-09-14 18:12:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/XQCisvR3F9",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/behind-the-wheel-of-gms-new-bolt\/",
      "display_url" : "engadget.com\/2016\/09\/14\/beh\u2026"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/tNAP8MKLSi",
      "expanded_url" : "http:\/\/fb.me\/86xq9hgnp",
      "display_url" : "fb.me\/86xq9hgnp"
    } ]
  },
  "geo" : { },
  "id_str" : "776121274254946305",
  "text" : "RT @EmperorDarroux: Behind the wheel of GM's 238-mile range electric car https:\/\/t.co\/XQCisvR3F9 https:\/\/t.co\/tNAP8MKLSi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/XQCisvR3F9",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/behind-the-wheel-of-gms-new-bolt\/",
        "display_url" : "engadget.com\/2016\/09\/14\/beh\u2026"
      }, {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/tNAP8MKLSi",
        "expanded_url" : "http:\/\/fb.me\/86xq9hgnp",
        "display_url" : "fb.me\/86xq9hgnp"
      } ]
    },
    "geo" : { },
    "id_str" : "776060954756784128",
    "text" : "Behind the wheel of GM's 238-mile range electric car https:\/\/t.co\/XQCisvR3F9 https:\/\/t.co\/tNAP8MKLSi",
    "id" : 776060954756784128,
    "created_at" : "2016-09-14 14:12:04 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776121274254946305,
  "created_at" : "2016-09-14 18:11:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ra0Gave8AP",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/google-project-zero-contest-nexus\/",
      "display_url" : "engadget.com\/2016\/09\/14\/goo\u2026"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/c8SMSskNMg",
      "expanded_url" : "http:\/\/fb.me\/6Rkr2DtOI",
      "display_url" : "fb.me\/6Rkr2DtOI"
    } ]
  },
  "geo" : { },
  "id_str" : "776121201345388544",
  "text" : "RT @EmperorDarroux: Google offers $350,000 in prizes if you can hack a Nexus https:\/\/t.co\/ra0Gave8AP https:\/\/t.co\/c8SMSskNMg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/ra0Gave8AP",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/09\/14\/google-project-zero-contest-nexus\/",
        "display_url" : "engadget.com\/2016\/09\/14\/goo\u2026"
      }, {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/c8SMSskNMg",
        "expanded_url" : "http:\/\/fb.me\/6Rkr2DtOI",
        "display_url" : "fb.me\/6Rkr2DtOI"
      } ]
    },
    "geo" : { },
    "id_str" : "776060606092759040",
    "text" : "Google offers $350,000 in prizes if you can hack a Nexus https:\/\/t.co\/ra0Gave8AP https:\/\/t.co\/c8SMSskNMg",
    "id" : 776060606092759040,
    "created_at" : "2016-09-14 14:10:41 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776121201345388544,
  "created_at" : "2016-09-14 18:11:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776121138808315905",
  "text" : "Do you know what Pi is? 22\/7 but I don't think that was what you were looking for",
  "id" : 776121138808315905,
  "created_at" : "2016-09-14 18:11:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776062796572262400",
  "text" : "Yesterday I helped babysit the most polite children ever",
  "id" : 776062796572262400,
  "created_at" : "2016-09-14 14:19:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/640zArfQki",
      "expanded_url" : "http:\/\/fb.me\/2U1SOhbCu",
      "display_url" : "fb.me\/2U1SOhbCu"
    } ]
  },
  "geo" : { },
  "id_str" : "776062664443301889",
  "text" : "RT @EmperorDarroux: Hungry startup uses robots to grab slice of pizza https:\/\/t.co\/640zArfQki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/640zArfQki",
        "expanded_url" : "http:\/\/fb.me\/2U1SOhbCu",
        "display_url" : "fb.me\/2U1SOhbCu"
      } ]
    },
    "geo" : { },
    "id_str" : "776053003983912960",
    "text" : "Hungry startup uses robots to grab slice of pizza https:\/\/t.co\/640zArfQki",
    "id" : 776053003983912960,
    "created_at" : "2016-09-14 13:40:29 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 776062664443301889,
  "created_at" : "2016-09-14 14:18:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776062609007214593",
  "text" : "Guys love it when girls say you are so nice or act polite around you",
  "id" : 776062609007214593,
  "created_at" : "2016-09-14 14:18:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776052880373608449",
  "text" : "RT @RandiAthenas: The probability of someone watching you is proportional to the stupidity of your action.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775855858957766656",
    "text" : "The probability of someone watching you is proportional to the stupidity of your action.",
    "id" : 775855858957766656,
    "created_at" : "2016-09-14 00:37:06 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 776052880373608449,
  "created_at" : "2016-09-14 13:39:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "776052823385640960",
  "text" : "I love Chick-Fil-a's breakfast menu, especially the breading",
  "id" : 776052823385640960,
  "created_at" : "2016-09-14 13:39:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brite Kite Marketing",
      "screen_name" : "britekitesydney",
      "indices" : [ 3, 19 ],
      "id_str" : "948735090",
      "id" : 948735090
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 24, 36 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Adweek",
      "screen_name" : "Adweek",
      "indices" : [ 127, 134 ],
      "id_str" : "30205586",
      "id" : 30205586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Digital",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "Marketing",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DdA8iEFhui",
      "expanded_url" : "http:\/\/hubs.ly\/H04j4bv0",
      "display_url" : "hubs.ly\/H04j4bv0"
    } ]
  },
  "geo" : { },
  "id_str" : "775674229253611520",
  "text" : "RT @britekitesydney: RT @gamer456148: \"9 #Digital #Marketing stats from the week that you need to see\" https:\/\/t.co\/DdA8iEFhui @adweek http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 3, 15 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Adweek",
        "screen_name" : "Adweek",
        "indices" : [ 106, 113 ],
        "id_str" : "30205586",
        "id" : 30205586
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/britekitesydney\/status\/775540760313729024\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/2DFoyNshxA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsNGNfZWYAQp-3B.jpg",
        "id_str" : "775540758417924100",
        "id" : 775540758417924100,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsNGNfZWYAQp-3B.jpg",
        "sizes" : [ {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/2DFoyNshxA"
      } ],
      "hashtags" : [ {
        "text" : "Digital",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "Marketing",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/DdA8iEFhui",
        "expanded_url" : "http:\/\/hubs.ly\/H04j4bv0",
        "display_url" : "hubs.ly\/H04j4bv0"
      } ]
    },
    "geo" : { },
    "id_str" : "775540760313729024",
    "text" : "RT @gamer456148: \"9 #Digital #Marketing stats from the week that you need to see\" https:\/\/t.co\/DdA8iEFhui @adweek https:\/\/t.co\/2DFoyNshxA",
    "id" : 775540760313729024,
    "created_at" : "2016-09-13 03:45:00 +0000",
    "user" : {
      "name" : "Brite Kite Marketing",
      "screen_name" : "britekitesydney",
      "protected" : false,
      "id_str" : "948735090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752325814205632512\/Wwb-NoVH_normal.jpg",
      "id" : 948735090,
      "verified" : false
    }
  },
  "id" : 775674229253611520,
  "created_at" : "2016-09-13 12:35:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775674193434275840",
  "text" : "They charged $3.99 for a drink advertised as $2.09 but I didn't make a deal out of it cause I was too tired #OU",
  "id" : 775674193434275840,
  "created_at" : "2016-09-13 12:35:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "indices" : [ 3, 12 ],
      "id_str" : "96013710",
      "id" : 96013710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775460298123776000",
  "text" : "RT @FactSoup: Allow yourself to be a beginner. No one starts off being excellent.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775445642755842049",
    "text" : "Allow yourself to be a beginner. No one starts off being excellent.",
    "id" : 775445642755842049,
    "created_at" : "2016-09-12 21:27:02 +0000",
    "user" : {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "protected" : false,
      "id_str" : "96013710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956327042554896384\/xHimnR1u_normal.jpg",
      "id" : 96013710,
      "verified" : false
    }
  },
  "id" : 775460298123776000,
  "created_at" : "2016-09-12 22:25:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Timothy J. Seppala",
      "screen_name" : "timseppala",
      "indices" : [ 16, 27 ],
      "id_str" : "15297310",
      "id" : 15297310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775459508688564224",
  "geo" : { },
  "id_str" : "775460207552069637",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @timseppala Oh my goodness \uD83D\uDE02",
  "id" : 775460207552069637,
  "in_reply_to_status_id" : 775459508688564224,
  "created_at" : "2016-09-12 22:24:55 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ffysn3zwyh",
      "expanded_url" : "http:\/\/fb.me\/2xDzqsBZD",
      "display_url" : "fb.me\/2xDzqsBZD"
    } ]
  },
  "geo" : { },
  "id_str" : "775460006460264452",
  "text" : "RT @EmperorDarroux: Broncos player loses second endorsement after anthem protest https:\/\/t.co\/ffysn3zwyh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/ffysn3zwyh",
        "expanded_url" : "http:\/\/fb.me\/2xDzqsBZD",
        "display_url" : "fb.me\/2xDzqsBZD"
      } ]
    },
    "geo" : { },
    "id_str" : "775459081087700992",
    "text" : "Broncos player loses second endorsement after anthem protest https:\/\/t.co\/ffysn3zwyh",
    "id" : 775459081087700992,
    "created_at" : "2016-09-12 22:20:26 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 775460006460264452,
  "created_at" : "2016-09-12 22:24:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "indices" : [ 3, 13 ],
      "id_str" : "17093617",
      "id" : 17093617
    }, {
      "name" : "Adweek",
      "screen_name" : "Adweek",
      "indices" : [ 104, 111 ],
      "id_str" : "30205586",
      "id" : 30205586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChoiceContent",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ooa4iMoCqL",
      "expanded_url" : "http:\/\/ow.ly\/niJO3044I3S",
      "display_url" : "ow.ly\/niJO3044I3S"
    } ]
  },
  "geo" : { },
  "id_str" : "775459900881264641",
  "text" : "RT @hootsuite: 9 digital marketing stats from the week that you need to see https:\/\/t.co\/ooa4iMoCqL via @adweek #ChoiceContent https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adweek",
        "screen_name" : "Adweek",
        "indices" : [ 89, 96 ],
        "id_str" : "30205586",
        "id" : 30205586
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hootsuite\/status\/775442752796495872\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/1VDMrwlzBo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsLtEo8WgAAK0x9.jpg",
        "id_str" : "775442749826957312",
        "id" : 775442749826957312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsLtEo8WgAAK0x9.jpg",
        "sizes" : [ {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 652
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1VDMrwlzBo"
      } ],
      "hashtags" : [ {
        "text" : "ChoiceContent",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/ooa4iMoCqL",
        "expanded_url" : "http:\/\/ow.ly\/niJO3044I3S",
        "display_url" : "ow.ly\/niJO3044I3S"
      } ]
    },
    "geo" : { },
    "id_str" : "775442752796495872",
    "text" : "9 digital marketing stats from the week that you need to see https:\/\/t.co\/ooa4iMoCqL via @adweek #ChoiceContent https:\/\/t.co\/1VDMrwlzBo",
    "id" : 775442752796495872,
    "created_at" : "2016-09-12 21:15:33 +0000",
    "user" : {
      "name" : "Hootsuite",
      "screen_name" : "hootsuite",
      "protected" : false,
      "id_str" : "17093617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860528495843172352\/-_Qwshgh_normal.jpg",
      "id" : 17093617,
      "verified" : true
    }
  },
  "id" : 775459900881264641,
  "created_at" : "2016-09-12 22:23:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/F58AKbJWoX",
      "expanded_url" : "http:\/\/holykaw.alltop.com\/japanese-art-woodworking-using-woods-natural-grain-make-patterns?gk3",
      "display_url" : "holykaw.alltop.com\/japanese-art-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775459884208889857",
  "text" : "RT @GuyKawasaki: The Japanese art of woodworking using the wood\u2019s natural grain to make patterns https:\/\/t.co\/F58AKbJWoX https:\/\/t.co\/s0h0h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/alltop.com\/\" rel=\"nofollow\"\u003EAlltop Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/775442751798345728\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/s0h0hNd5AJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsLtEnHWEAA07mk.jpg",
        "id_str" : "775442749336195072",
        "id" : 775442749336195072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsLtEnHWEAA07mk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/s0h0hNd5AJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/F58AKbJWoX",
        "expanded_url" : "http:\/\/holykaw.alltop.com\/japanese-art-woodworking-using-woods-natural-grain-make-patterns?gk3",
        "display_url" : "holykaw.alltop.com\/japanese-art-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775442751798345728",
    "text" : "The Japanese art of woodworking using the wood\u2019s natural grain to make patterns https:\/\/t.co\/F58AKbJWoX https:\/\/t.co\/s0h0hNd5AJ",
    "id" : 775442751798345728,
    "created_at" : "2016-09-12 21:15:33 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 775459884208889857,
  "created_at" : "2016-09-12 22:23:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b.b",
      "screen_name" : "Benoo_Brown",
      "indices" : [ 12, 24 ],
      "id_str" : "361178230",
      "id" : 361178230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775065075400994816",
  "geo" : { },
  "id_str" : "775442707841847296",
  "in_reply_to_user_id" : 1955440922,
  "text" : "@SoSedusive @Benoo_Brown What's apparently a vibe?",
  "id" : 775442707841847296,
  "in_reply_to_status_id" : 775065075400994816,
  "created_at" : "2016-09-12 21:15:23 +0000",
  "in_reply_to_screen_name" : "ShawtySeducsive",
  "in_reply_to_user_id_str" : "1955440922",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/rqeS5t5XZ2",
      "expanded_url" : "http:\/\/fb.me\/13iD9MEcI",
      "display_url" : "fb.me\/13iD9MEcI"
    } ]
  },
  "geo" : { },
  "id_str" : "775442257138692096",
  "text" : "RT @EmperorDarroux: Facebook Messenger chatbots now support payments https:\/\/t.co\/rqeS5t5XZ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/rqeS5t5XZ2",
        "expanded_url" : "http:\/\/fb.me\/13iD9MEcI",
        "display_url" : "fb.me\/13iD9MEcI"
      } ]
    },
    "geo" : { },
    "id_str" : "775418036278800384",
    "text" : "Facebook Messenger chatbots now support payments https:\/\/t.co\/rqeS5t5XZ2",
    "id" : 775418036278800384,
    "created_at" : "2016-09-12 19:37:21 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 775442257138692096,
  "created_at" : "2016-09-12 21:13:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/NkEcNHJwHV",
      "expanded_url" : "http:\/\/fb.me\/17MQD6jaI",
      "display_url" : "fb.me\/17MQD6jaI"
    } ]
  },
  "geo" : { },
  "id_str" : "775442232715292672",
  "text" : "RT @EmperorDarroux: Even newspapers ads aren't declining as fast as desktop ads https:\/\/t.co\/NkEcNHJwHV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/NkEcNHJwHV",
        "expanded_url" : "http:\/\/fb.me\/17MQD6jaI",
        "display_url" : "fb.me\/17MQD6jaI"
      } ]
    },
    "geo" : { },
    "id_str" : "775418079148847104",
    "text" : "Even newspapers ads aren't declining as fast as desktop ads https:\/\/t.co\/NkEcNHJwHV",
    "id" : 775418079148847104,
    "created_at" : "2016-09-12 19:37:31 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 775442232715292672,
  "created_at" : "2016-09-12 21:13:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/775442057909313537\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/yIjNfngpYl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsLsb7aWEAAdBDE.jpg",
      "id_str" : "775442050409959424",
      "id" : 775442050409959424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsLsb7aWEAAdBDE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/yIjNfngpYl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775442057909313537",
  "text" : "Egyptian Kit Kats taste slightly different https:\/\/t.co\/yIjNfngpYl",
  "id" : 775442057909313537,
  "created_at" : "2016-09-12 21:12:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Slonaker",
      "screen_name" : "TcSlonaker",
      "indices" : [ 3, 14 ],
      "id_str" : "332519306",
      "id" : 332519306
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775441872525275136",
  "text" : "RT @TcSlonaker: @gamer456148 Ha! That makes sense.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775416808404688896",
    "geo" : { },
    "id_str" : "775419130858074112",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Ha! That makes sense.",
    "id" : 775419130858074112,
    "in_reply_to_status_id" : 775416808404688896,
    "created_at" : "2016-09-12 19:41:42 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Tracy Slonaker",
      "screen_name" : "TcSlonaker",
      "protected" : false,
      "id_str" : "332519306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1512098613\/Photo_on_2011-08-17_at_13.11__3_normal.jpg",
      "id" : 332519306,
      "verified" : false
    }
  },
  "id" : 775441872525275136,
  "created_at" : "2016-09-12 21:12:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/U3qqGgezmn",
      "expanded_url" : "http:\/\/ow.ly\/MyGG3046olw",
      "display_url" : "ow.ly\/MyGG3046olw"
    } ]
  },
  "geo" : { },
  "id_str" : "775418240805724160",
  "text" : "RT @analyticbridge: Financial Modeling Best Practices https:\/\/t.co\/U3qqGgezmn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/U3qqGgezmn",
        "expanded_url" : "http:\/\/ow.ly\/MyGG3046olw",
        "display_url" : "ow.ly\/MyGG3046olw"
      } ]
    },
    "geo" : { },
    "id_str" : "775416470654357505",
    "text" : "Financial Modeling Best Practices https:\/\/t.co\/U3qqGgezmn",
    "id" : 775416470654357505,
    "created_at" : "2016-09-12 19:31:07 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 775418240805724160,
  "created_at" : "2016-09-12 19:38:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JONATHAN M. MELLOR",
      "screen_name" : "JonathanMellor",
      "indices" : [ 3, 18 ],
      "id_str" : "32863252",
      "id" : 32863252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775418086165929984",
  "text" : "RT @JonathanMellor: Philip Green hides behind a pillar to try and avoid snappers while on holiday with his daughter in Monaco https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/YDsjITgiVm",
        "expanded_url" : "https:\/\/www.thesun.co.uk\/news\/1767250\/philip-green-hides-behind-a-pillar-to-try-and-avoid-snappers-while-on-holiday-with-his-daughter-in-monaco\/",
        "display_url" : "thesun.co.uk\/news\/1767250\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775417398740545536",
    "text" : "Philip Green hides behind a pillar to try and avoid snappers while on holiday with his daughter in Monaco https:\/\/t.co\/YDsjITgiVm",
    "id" : 775417398740545536,
    "created_at" : "2016-09-12 19:34:49 +0000",
    "user" : {
      "name" : "JONATHAN M. MELLOR",
      "screen_name" : "JonathanMellor",
      "protected" : false,
      "id_str" : "32863252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992179788130463750\/kuwgGEDw_normal.jpg",
      "id" : 32863252,
      "verified" : false
    }
  },
  "id" : 775418086165929984,
  "created_at" : "2016-09-12 19:37:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deactivate",
      "screen_name" : "baekhyunity",
      "indices" : [ 3, 15 ],
      "id_str" : "4209343820",
      "id" : 4209343820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417768778739712",
  "text" : "RT @baekhyunity: At moments like this, we shouldnt think about kpop. Kpop isn't the only thing in korea. We should support all the families\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrayForKorea",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775408325588549632",
    "text" : "At moments like this, we shouldnt think about kpop. Kpop isn't the only thing in korea. We should support all the families #PrayForKorea",
    "id" : 775408325588549632,
    "created_at" : "2016-09-12 18:58:45 +0000",
    "user" : {
      "name" : "\u3164\u4E3D\u7D72 | hiatus",
      "screen_name" : "byundus",
      "protected" : false,
      "id_str" : "4840219852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993156850999812096\/JUAVKMnu_normal.jpg",
      "id" : 4840219852,
      "verified" : false
    }
  },
  "id" : 775417768778739712,
  "created_at" : "2016-09-12 19:36:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CHRISTA \u2661 LY: TEAR\uD83D\uDCA7",
      "screen_name" : "kittyqtpie",
      "indices" : [ 3, 14 ],
      "id_str" : "181827836",
      "id" : 181827836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417554290380800",
  "text" : "RT @kittyqtpie: Please keep in mind that Korea doesn't revolve around only KPOP, but is a country full of families, children, and the elder\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrayForKorea",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775416453776470016",
    "text" : "Please keep in mind that Korea doesn't revolve around only KPOP, but is a country full of families, children, and the elderly. #PrayForKorea",
    "id" : 775416453776470016,
    "created_at" : "2016-09-12 19:31:03 +0000",
    "user" : {
      "name" : "CHRISTA \u2661 LY: TEAR\uD83D\uDCA7",
      "screen_name" : "kittyqtpie",
      "protected" : false,
      "id_str" : "181827836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/982067066176966657\/zvoKZ6vC_normal.jpg",
      "id" : 181827836,
      "verified" : false
    }
  },
  "id" : 775417554290380800,
  "created_at" : "2016-09-12 19:35:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Millar",
      "screen_name" : "mrmarkmillar",
      "indices" : [ 3, 16 ],
      "id_str" : "133404204",
      "id" : 133404204
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillarysBodyDouble",
      "indices" : [ 49, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417420370501632",
  "text" : "RT @mrmarkmillar: I hope they don't have to kill #HillarysBodyDouble after the election to keep her silent, like Capricorn One. She did a g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillarysBodyDouble",
        "indices" : [ 31, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775408700894969856",
    "text" : "I hope they don't have to kill #HillarysBodyDouble after the election to keep her silent, like Capricorn One. She did a good job today.",
    "id" : 775408700894969856,
    "created_at" : "2016-09-12 19:00:15 +0000",
    "user" : {
      "name" : "Mark Millar",
      "screen_name" : "mrmarkmillar",
      "protected" : false,
      "id_str" : "133404204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956461938569039872\/BhWY0eZx_normal.jpg",
      "id" : 133404204,
      "verified" : true
    }
  },
  "id" : 775417420370501632,
  "created_at" : "2016-09-12 19:34:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Deco",
      "screen_name" : "TessDeco",
      "indices" : [ 3, 12 ],
      "id_str" : "107939865",
      "id" : 107939865
    }, {
      "name" : "Timothy J. Trudeau",
      "screen_name" : "rocdomz",
      "indices" : [ 14, 22 ],
      "id_str" : "15326196",
      "id" : 15326196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417329786028032",
  "text" : "RT @TessDeco: @rocdomz Typical misogynist male response.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Timothy J. Trudeau",
        "screen_name" : "rocdomz",
        "indices" : [ 0, 8 ],
        "id_str" : "15326196",
        "id" : 15326196
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775251322073325568",
    "geo" : { },
    "id_str" : "775353951868694533",
    "in_reply_to_user_id" : 15326196,
    "text" : "@rocdomz Typical misogynist male response.",
    "id" : 775353951868694533,
    "in_reply_to_status_id" : 775251322073325568,
    "created_at" : "2016-09-12 15:22:42 +0000",
    "in_reply_to_screen_name" : "rocdomz",
    "in_reply_to_user_id_str" : "15326196",
    "user" : {
      "name" : "Tess Deco",
      "screen_name" : "TessDeco",
      "protected" : false,
      "id_str" : "107939865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849359820285243393\/VX0W9DjZ_normal.jpg",
      "id" : 107939865,
      "verified" : false
    }
  },
  "id" : 775417329786028032,
  "created_at" : "2016-09-12 19:34:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Common Arrow",
      "screen_name" : "commonarrow",
      "indices" : [ 3, 15 ],
      "id_str" : "758136611997573122",
      "id" : 758136611997573122
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 17, 26 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417194792390656",
  "text" : "RT @commonarrow: @scrowder Exactly. No need to invent scandal when there's one every day being served on a silver platter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775404695733039104",
    "geo" : { },
    "id_str" : "775404962922627072",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder Exactly. No need to invent scandal when there's one every day being served on a silver platter.",
    "id" : 775404962922627072,
    "in_reply_to_status_id" : 775404695733039104,
    "created_at" : "2016-09-12 18:45:24 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Common Arrow",
      "screen_name" : "commonarrow",
      "protected" : false,
      "id_str" : "758136611997573122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768101720207482880\/TBAW086y_normal.jpg",
      "id" : 758136611997573122,
      "verified" : false
    }
  },
  "id" : 775417194792390656,
  "created_at" : "2016-09-12 19:34:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minority Games",
      "screen_name" : "_Minority_Games",
      "indices" : [ 3, 19 ],
      "id_str" : "4780098915",
      "id" : 4780098915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalVideoGamesDay",
      "indices" : [ 27, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775417051477266432",
  "text" : "RT @_Minority_Games: Happy #NationalVideoGamesDay - whether you play on console, computer, mobile or anywhere else, game on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalVideoGamesDay",
        "indices" : [ 6, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775416203632181249",
    "text" : "Happy #NationalVideoGamesDay - whether you play on console, computer, mobile or anywhere else, game on.",
    "id" : 775416203632181249,
    "created_at" : "2016-09-12 19:30:04 +0000",
    "user" : {
      "name" : "Minority Games",
      "screen_name" : "_Minority_Games",
      "protected" : false,
      "id_str" : "4780098915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687006555540205568\/22fV-vXQ_normal.png",
      "id" : 4780098915,
      "verified" : false
    }
  },
  "id" : 775417051477266432,
  "created_at" : "2016-09-12 19:33:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Slonaker",
      "screen_name" : "TcSlonaker",
      "indices" : [ 0, 11 ],
      "id_str" : "332519306",
      "id" : 332519306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775416333014097921",
  "geo" : { },
  "id_str" : "775416808404688896",
  "in_reply_to_user_id" : 332519306,
  "text" : "@TcSlonaker Sims 3, lol",
  "id" : 775416808404688896,
  "in_reply_to_status_id" : 775416333014097921,
  "created_at" : "2016-09-12 19:32:28 +0000",
  "in_reply_to_screen_name" : "TcSlonaker",
  "in_reply_to_user_id_str" : "332519306",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Slonaker",
      "screen_name" : "TcSlonaker",
      "indices" : [ 3, 14 ],
      "id_str" : "332519306",
      "id" : 332519306
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalVideoGamesDay",
      "indices" : [ 16, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775416742491271168",
  "text" : "RT @TcSlonaker: #NationalVideoGamesDay What video game does your life most resemble? (Don't say Sonic. I won't believe you.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalVideoGamesDay",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775416333014097921",
    "text" : "#NationalVideoGamesDay What video game does your life most resemble? (Don't say Sonic. I won't believe you.)",
    "id" : 775416333014097921,
    "created_at" : "2016-09-12 19:30:34 +0000",
    "user" : {
      "name" : "Tracy Slonaker",
      "screen_name" : "TcSlonaker",
      "protected" : false,
      "id_str" : "332519306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1512098613\/Photo_on_2011-08-17_at_13.11__3_normal.jpg",
      "id" : 332519306,
      "verified" : false
    }
  },
  "id" : 775416742491271168,
  "created_at" : "2016-09-12 19:32:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Elin",
      "screen_name" : "innocentcrush",
      "indices" : [ 3, 17 ],
      "id_str" : "23120237",
      "id" : 23120237
    }, {
      "name" : "Carlitos Etcheverry",
      "screen_name" : "Borlocomix",
      "indices" : [ 124, 135 ],
      "id_str" : "69434960",
      "id" : 69434960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalVideoGamesDay",
      "indices" : [ 19, 41 ]
    }, {
      "text" : "borlo",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/0EEEhIXQjq",
      "expanded_url" : "http:\/\/www.borlocomix.com",
      "display_url" : "borlocomix.com"
    } ]
  },
  "geo" : { },
  "id_str" : "775416706122461184",
  "text" : "RT @innocentcrush: #NationalVideoGamesDay y'all should be checking out this #borlo dressing game!!! https:\/\/t.co\/0EEEhIXQjq @Borlocomix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carlitos Etcheverry",
        "screen_name" : "Borlocomix",
        "indices" : [ 105, 116 ],
        "id_str" : "69434960",
        "id" : 69434960
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalVideoGamesDay",
        "indices" : [ 0, 22 ]
      }, {
        "text" : "borlo",
        "indices" : [ 57, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/0EEEhIXQjq",
        "expanded_url" : "http:\/\/www.borlocomix.com",
        "display_url" : "borlocomix.com"
      } ]
    },
    "geo" : { },
    "id_str" : "775416333794095104",
    "text" : "#NationalVideoGamesDay y'all should be checking out this #borlo dressing game!!! https:\/\/t.co\/0EEEhIXQjq @Borlocomix",
    "id" : 775416333794095104,
    "created_at" : "2016-09-12 19:30:35 +0000",
    "user" : {
      "name" : "Nicole Elin",
      "screen_name" : "innocentcrush",
      "protected" : false,
      "id_str" : "23120237",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/970838563045588992\/fMoQxx_Q_normal.jpg",
      "id" : 23120237,
      "verified" : false
    }
  },
  "id" : 775416706122461184,
  "created_at" : "2016-09-12 19:32:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex \uD83D\uDC78\uD83C\uDFFE",
      "screen_name" : "_heyylex",
      "indices" : [ 3, 12 ],
      "id_str" : "228197923",
      "id" : 228197923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalVideoGamesDay",
      "indices" : [ 19, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775416579492163584",
  "text" : "RT @_heyylex: it's #NationalVideoGamesDay \uD83D\uDE0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalVideoGamesDay",
        "indices" : [ 5, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775416351162720256",
    "text" : "it's #NationalVideoGamesDay \uD83D\uDE0F",
    "id" : 775416351162720256,
    "created_at" : "2016-09-12 19:30:39 +0000",
    "user" : {
      "name" : "Lex \uD83D\uDC78\uD83C\uDFFE",
      "screen_name" : "_heyylex",
      "protected" : false,
      "id_str" : "228197923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/970693894785716229\/JaWAnwIL_normal.jpg",
      "id" : 228197923,
      "verified" : false
    }
  },
  "id" : 775416579492163584,
  "created_at" : "2016-09-12 19:31:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kenZ",
      "screen_name" : "kenzliee",
      "indices" : [ 0, 9 ],
      "id_str" : "3198555944",
      "id" : 3198555944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775407686330429445",
  "geo" : { },
  "id_str" : "775416426223898625",
  "in_reply_to_user_id" : 3198555944,
  "text" : "@kenzliee Donkey Kong from the game and watch series",
  "id" : 775416426223898625,
  "in_reply_to_status_id" : 775407686330429445,
  "created_at" : "2016-09-12 19:30:57 +0000",
  "in_reply_to_screen_name" : "kenzliee",
  "in_reply_to_user_id_str" : "3198555944",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GameBattles",
      "screen_name" : "GameBattles",
      "indices" : [ 3, 15 ],
      "id_str" : "28125177",
      "id" : 28125177
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GameBattles\/status\/775408239961780224\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/0ia2CIQmxu",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CsLNZj3XYAAUr6d.jpg",
      "id_str" : "775407924869029888",
      "id" : 775407924869029888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CsLNZj3XYAAUr6d.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 384
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 384
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/0ia2CIQmxu"
    } ],
    "hashtags" : [ {
      "text" : "NationalVideoGamesDay",
      "indices" : [ 41, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775416137332817920",
  "text" : "RT @GameBattles: We treat every day like #NationalVideoGamesDay! https:\/\/t.co\/0ia2CIQmxu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GameBattles\/status\/775408239961780224\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/0ia2CIQmxu",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CsLNZj3XYAAUr6d.jpg",
        "id_str" : "775407924869029888",
        "id" : 775407924869029888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CsLNZj3XYAAUr6d.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 384
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 384
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 384
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 384
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/0ia2CIQmxu"
      } ],
      "hashtags" : [ {
        "text" : "NationalVideoGamesDay",
        "indices" : [ 24, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775408239961780224",
    "text" : "We treat every day like #NationalVideoGamesDay! https:\/\/t.co\/0ia2CIQmxu",
    "id" : 775408239961780224,
    "created_at" : "2016-09-12 18:58:25 +0000",
    "user" : {
      "name" : "GameBattles",
      "screen_name" : "GameBattles",
      "protected" : false,
      "id_str" : "28125177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927216415484137472\/aMSIYBIn_normal.jpg",
      "id" : 28125177,
      "verified" : true
    }
  },
  "id" : 775416137332817920,
  "created_at" : "2016-09-12 19:29:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "indices" : [ 3, 18 ],
      "id_str" : "78523300",
      "id" : 78523300
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 30, 45 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HillarysHealth",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775383640943407105",
  "text" : "RT @RealJamesWoods: Of course @HillaryClinton's \"pneumonia\" will be a linchpin to avoiding the debates somehow... #HillarysHealth #Debates2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 10, 25 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HillarysHealth",
        "indices" : [ 94, 109 ]
      }, {
        "text" : "Debates2016",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775383023357341696",
    "text" : "Of course @HillaryClinton's \"pneumonia\" will be a linchpin to avoiding the debates somehow... #HillarysHealth #Debates2016",
    "id" : 775383023357341696,
    "created_at" : "2016-09-12 17:18:13 +0000",
    "user" : {
      "name" : "James Woods",
      "screen_name" : "RealJamesWoods",
      "protected" : false,
      "id_str" : "78523300",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796482667340382211\/CoV8077b_normal.jpg",
      "id" : 78523300,
      "verified" : true
    }
  },
  "id" : 775383640943407105,
  "created_at" : "2016-09-12 17:20:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ 0, 12 ],
      "id_str" : "50618718",
      "id" : 50618718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775367624678973440",
  "geo" : { },
  "id_str" : "775383487142518786",
  "in_reply_to_user_id" : 50618718,
  "text" : "@SpeakComedy That feeling is such a funny way of being represented",
  "id" : 775383487142518786,
  "in_reply_to_status_id" : 775367624678973440,
  "created_at" : "2016-09-12 17:20:03 +0000",
  "in_reply_to_screen_name" : "SpeakComedy",
  "in_reply_to_user_id_str" : "50618718",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 3, 19 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/VXsyGPOsfA",
      "expanded_url" : "http:\/\/ow.ly\/m2nL3046p95",
      "display_url" : "ow.ly\/m2nL3046p95"
    } ]
  },
  "geo" : { },
  "id_str" : "775383275866951680",
  "text" : "RT @DataScienceCtrl: 5 Free Statistics eBooks You Need to Read This Autumn https:\/\/t.co\/VXsyGPOsfA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/VXsyGPOsfA",
        "expanded_url" : "http:\/\/ow.ly\/m2nL3046p95",
        "display_url" : "ow.ly\/m2nL3046p95"
      } ]
    },
    "geo" : { },
    "id_str" : "775089079293796352",
    "text" : "5 Free Statistics eBooks You Need to Read This Autumn https:\/\/t.co\/VXsyGPOsfA",
    "id" : 775089079293796352,
    "created_at" : "2016-09-11 21:50:11 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "protected" : false,
      "id_str" : "393033324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989084699836416\/HLeb5i56_normal.jpg",
      "id" : 393033324,
      "verified" : false
    }
  },
  "id" : 775383275866951680,
  "created_at" : "2016-09-12 17:19:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 79, 95 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datascience",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/djpeIRv7i1",
      "expanded_url" : "http:\/\/ow.ly\/HWae3045CsI",
      "display_url" : "ow.ly\/HWae3045CsI"
    } ]
  },
  "geo" : { },
  "id_str" : "775383249304465408",
  "text" : "RT @S2DS_School: Looking for some #datascience challenges to test your skills? @DataScienceCtrl https:\/\/t.co\/djpeIRv7i1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Data Science Central",
        "screen_name" : "DataScienceCtrl",
        "indices" : [ 62, 78 ],
        "id_str" : "393033324",
        "id" : 393033324
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "datascience",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/djpeIRv7i1",
        "expanded_url" : "http:\/\/ow.ly\/HWae3045CsI",
        "display_url" : "ow.ly\/HWae3045CsI"
      } ]
    },
    "geo" : { },
    "id_str" : "775364041988575232",
    "text" : "Looking for some #datascience challenges to test your skills? @DataScienceCtrl https:\/\/t.co\/djpeIRv7i1",
    "id" : 775364041988575232,
    "created_at" : "2016-09-12 16:02:47 +0000",
    "user" : {
      "name" : "S2DS",
      "screen_name" : "s2ds",
      "protected" : false,
      "id_str" : "2304756668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652108031396868097\/m4GEFZ_X_normal.png",
      "id" : 2304756668,
      "verified" : false
    }
  },
  "id" : 775383249304465408,
  "created_at" : "2016-09-12 17:19:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Respect",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "NeverForget911",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775374641858744320",
  "geo" : { },
  "id_str" : "775383065300377601",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo #Respect #NeverForget911",
  "id" : 775383065300377601,
  "in_reply_to_status_id" : 775374641858744320,
  "created_at" : "2016-09-12 17:18:23 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775382821066018816",
  "text" : "Best way to impress people is learning the most from your mistakes",
  "id" : 775382821066018816,
  "created_at" : "2016-09-12 17:17:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Cadenas",
      "screen_name" : "DANIELCADENASJ",
      "indices" : [ 3, 18 ],
      "id_str" : "1612939700",
      "id" : 1612939700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381987213381632",
  "text" : "RT @DANIELCADENASJ: Checking out \"Tutorial: How to detect spurious correlations, and how to find t\" on Data Science Central: https:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/9M3S5Z3mco",
        "expanded_url" : "http:\/\/www.datasciencecentral.com\/profiles\/blogs\/tutorial-how-to-detect-spurious-correlations-and-how-to-find-the-",
        "display_url" : "datasciencecentral.com\/profiles\/blogs\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775359003656413184",
    "text" : "Checking out \"Tutorial: How to detect spurious correlations, and how to find t\" on Data Science Central: https:\/\/t.co\/9M3S5Z3mco",
    "id" : 775359003656413184,
    "created_at" : "2016-09-12 15:42:46 +0000",
    "user" : {
      "name" : "Daniel Cadenas",
      "screen_name" : "DANIELCADENASJ",
      "protected" : false,
      "id_str" : "1612939700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/896726052483067904\/xzI4HeXc_normal.jpg",
      "id" : 1612939700,
      "verified" : false
    }
  },
  "id" : 775381987213381632,
  "created_at" : "2016-09-12 17:14:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpazioDati",
      "screen_name" : "SpazioDati",
      "indices" : [ 3, 14 ],
      "id_str" : "539946626",
      "id" : 539946626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Python",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "Book",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/aykKZXc3jg",
      "expanded_url" : "http:\/\/buff.ly\/2c0ufDW",
      "display_url" : "buff.ly\/2c0ufDW"
    } ]
  },
  "geo" : { },
  "id_str" : "775381971467927552",
  "text" : "RT @SpazioDati: Checking out \"Book: Data Science Essentials in Python\" on Data Science Central: https:\/\/t.co\/aykKZXc3jg #Python #Book #Data\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Python",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "Book",
        "indices" : [ 112, 117 ]
      }, {
        "text" : "DataScience",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/aykKZXc3jg",
        "expanded_url" : "http:\/\/buff.ly\/2c0ufDW",
        "display_url" : "buff.ly\/2c0ufDW"
      } ]
    },
    "geo" : { },
    "id_str" : "775348585122725889",
    "text" : "Checking out \"Book: Data Science Essentials in Python\" on Data Science Central: https:\/\/t.co\/aykKZXc3jg #Python #Book #DataScience",
    "id" : 775348585122725889,
    "created_at" : "2016-09-12 15:01:22 +0000",
    "user" : {
      "name" : "SpazioDati",
      "screen_name" : "SpazioDati",
      "protected" : false,
      "id_str" : "539946626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919922861271379968\/jWe4szt2_normal.jpg",
      "id" : 539946626,
      "verified" : false
    }
  },
  "id" : 775381971467927552,
  "created_at" : "2016-09-12 17:14:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 3, 19 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/BTracuJmmv",
      "expanded_url" : "http:\/\/ow.ly\/jQhO3046pkh",
      "display_url" : "ow.ly\/jQhO3046pkh"
    } ]
  },
  "geo" : { },
  "id_str" : "775381950173511681",
  "text" : "RT @DataScienceCtrl: Introducing SYSTEMS Analytics https:\/\/t.co\/BTracuJmmv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/BTracuJmmv",
        "expanded_url" : "http:\/\/ow.ly\/jQhO3046pkh",
        "display_url" : "ow.ly\/jQhO3046pkh"
      } ]
    },
    "geo" : { },
    "id_str" : "775333645972336640",
    "text" : "Introducing SYSTEMS Analytics https:\/\/t.co\/BTracuJmmv",
    "id" : 775333645972336640,
    "created_at" : "2016-09-12 14:02:00 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "protected" : false,
      "id_str" : "393033324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989084699836416\/HLeb5i56_normal.jpg",
      "id" : 393033324,
      "verified" : false
    }
  },
  "id" : 775381950173511681,
  "created_at" : "2016-09-12 17:13:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "indices" : [ 3, 18 ],
      "id_str" : "20642356",
      "id" : 20642356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381919420809216",
  "text" : "RT @davidlongoria7: Analyze your mistakes. You've already paid the tuition, you might as well get the lesson. - Tim Fargo #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775368188603269120",
    "text" : "Analyze your mistakes. You've already paid the tuition, you might as well get the lesson. - Tim Fargo #quote",
    "id" : 775368188603269120,
    "created_at" : "2016-09-12 16:19:16 +0000",
    "user" : {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "protected" : false,
      "id_str" : "20642356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754888883465138176\/lvppUQYX_normal.jpg",
      "id" : 20642356,
      "verified" : true
    }
  },
  "id" : 775381919420809216,
  "created_at" : "2016-09-12 17:13:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "indices" : [ 3, 19 ],
      "id_str" : "393033324",
      "id" : 393033324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/4MUxnMqGBW",
      "expanded_url" : "http:\/\/ow.ly\/J0F93046pd6",
      "display_url" : "ow.ly\/J0F93046pd6"
    } ]
  },
  "geo" : { },
  "id_str" : "775381906481356800",
  "text" : "RT @DataScienceCtrl: Machine Learning Becomes Mainstream: How to Increase Your Competitive Advantage https:\/\/t.co\/4MUxnMqGBW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/4MUxnMqGBW",
        "expanded_url" : "http:\/\/ow.ly\/J0F93046pd6",
        "display_url" : "ow.ly\/J0F93046pd6"
      } ]
    },
    "geo" : { },
    "id_str" : "775320713834196992",
    "text" : "Machine Learning Becomes Mainstream: How to Increase Your Competitive Advantage https:\/\/t.co\/4MUxnMqGBW",
    "id" : 775320713834196992,
    "created_at" : "2016-09-12 13:10:37 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "DataScienceCtrl",
      "protected" : false,
      "id_str" : "393033324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989084699836416\/HLeb5i56_normal.jpg",
      "id" : 393033324,
      "verified" : false
    }
  },
  "id" : 775381906481356800,
  "created_at" : "2016-09-12 17:13:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hq3VkW0qS4",
      "expanded_url" : "https:\/\/twitter.com\/murraysentme\/status\/775375551422836736",
      "display_url" : "twitter.com\/murraysentme\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775381837036265473",
  "text" : "RT @BONNIELYNN2015: It's funny \uD83D\uDE00\uD83D\uDE00\uD83D\uDE00 https:\/\/t.co\/hq3VkW0qS4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/hq3VkW0qS4",
        "expanded_url" : "https:\/\/twitter.com\/murraysentme\/status\/775375551422836736",
        "display_url" : "twitter.com\/murraysentme\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775377406953533440",
    "text" : "It's funny \uD83D\uDE00\uD83D\uDE00\uD83D\uDE00 https:\/\/t.co\/hq3VkW0qS4",
    "id" : 775377406953533440,
    "created_at" : "2016-09-12 16:55:54 +0000",
    "user" : {
      "name" : "Last Pirate in LA",
      "screen_name" : "Bonnielynnmarie",
      "protected" : false,
      "id_str" : "248135355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993229851543949312\/JGTDc1K6_normal.jpg",
      "id" : 248135355,
      "verified" : false
    }
  },
  "id" : 775381837036265473,
  "created_at" : "2016-09-12 17:13:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381768102879233",
  "text" : "RT @lorenridinger: \"Use your human capacities to help empower other people to become the best versions of themselves.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775378612598009856",
    "text" : "\"Use your human capacities to help empower other people to become the best versions of themselves.\"",
    "id" : 775378612598009856,
    "created_at" : "2016-09-12 17:00:41 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 775381768102879233,
  "created_at" : "2016-09-12 17:13:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Right",
      "screen_name" : "DannyTiseo",
      "indices" : [ 3, 14 ],
      "id_str" : "276334529",
      "id" : 276334529
    }, {
      "name" : "Jim Cramer",
      "screen_name" : "jimcramer",
      "indices" : [ 16, 26 ],
      "id_str" : "14216123",
      "id" : 14216123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381675593363456",
  "text" : "RT @DannyTiseo: @jimcramer  You said it yourself. Bulls make money. Bears make money.... Time and place for everything.. Let's all go get a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Cramer",
        "screen_name" : "jimcramer",
        "indices" : [ 0, 10 ],
        "id_str" : "14216123",
        "id" : 14216123
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774381244809375744",
    "in_reply_to_user_id" : 14216123,
    "text" : "@jimcramer  You said it yourself. Bulls make money. Bears make money.... Time and place for everything.. Let's all go get a sweater...",
    "id" : 774381244809375744,
    "created_at" : "2016-09-09 22:57:30 +0000",
    "in_reply_to_screen_name" : "jimcramer",
    "in_reply_to_user_id_str" : "14216123",
    "user" : {
      "name" : "Dan Right",
      "screen_name" : "DannyTiseo",
      "protected" : false,
      "id_str" : "276334529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743435073626701824\/a1FnVru__normal.jpg",
      "id" : 276334529,
      "verified" : false
    }
  },
  "id" : 775381675593363456,
  "created_at" : "2016-09-12 17:12:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Cramer",
      "screen_name" : "jimcramer",
      "indices" : [ 3, 13 ],
      "id_str" : "14216123",
      "id" : 14216123
    }, {
      "name" : "Mark Cuban",
      "screen_name" : "mcuban",
      "indices" : [ 22, 29 ],
      "id_str" : "16228398",
      "id" : 16228398
    }, {
      "name" : "Mad Money On CNBC",
      "screen_name" : "MadMoneyOnCNBC",
      "indices" : [ 64, 79 ],
      "id_str" : "16451932",
      "id" : 16451932
    }, {
      "name" : "Dreamforce",
      "screen_name" : "Dreamforce",
      "indices" : [ 101, 112 ],
      "id_str" : "6843302",
      "id" : 6843302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Lev4HMJ41T",
      "expanded_url" : "https:\/\/twitter.com\/valaafshar\/status\/774660247310991360",
      "display_url" : "twitter.com\/valaafshar\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775381599223439361",
  "text" : "RT @jimcramer: I hope @mcuban  will sit down with me as I bring @MadMoneyOnCNBC to SF at the week of @Dreamforce ! https:\/\/t.co\/Lev4HMJ41T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Cuban",
        "screen_name" : "mcuban",
        "indices" : [ 7, 14 ],
        "id_str" : "16228398",
        "id" : 16228398
      }, {
        "name" : "Mad Money On CNBC",
        "screen_name" : "MadMoneyOnCNBC",
        "indices" : [ 49, 64 ],
        "id_str" : "16451932",
        "id" : 16451932
      }, {
        "name" : "Dreamforce",
        "screen_name" : "Dreamforce",
        "indices" : [ 86, 97 ],
        "id_str" : "6843302",
        "id" : 6843302
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Lev4HMJ41T",
        "expanded_url" : "https:\/\/twitter.com\/valaafshar\/status\/774660247310991360",
        "display_url" : "twitter.com\/valaafshar\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774700651381161984",
    "text" : "I hope @mcuban  will sit down with me as I bring @MadMoneyOnCNBC to SF at the week of @Dreamforce ! https:\/\/t.co\/Lev4HMJ41T",
    "id" : 774700651381161984,
    "created_at" : "2016-09-10 20:06:43 +0000",
    "user" : {
      "name" : "Jim Cramer",
      "screen_name" : "jimcramer",
      "protected" : false,
      "id_str" : "14216123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451344676914593792\/8lV96m2l_normal.jpeg",
      "id" : 14216123,
      "verified" : true
    }
  },
  "id" : 775381599223439361,
  "created_at" : "2016-09-12 17:12:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Cramer",
      "screen_name" : "jimcramer",
      "indices" : [ 3, 13 ],
      "id_str" : "14216123",
      "id" : 14216123
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GroundZeroRising",
      "indices" : [ 53, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381516234924037",
  "text" : "RT @jimcramer: If you missed the first go around for #GroundZeroRising please watch tonight at 10 p.m. on CNBC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GroundZeroRising",
        "indices" : [ 38, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775130626836103168",
    "text" : "If you missed the first go around for #GroundZeroRising please watch tonight at 10 p.m. on CNBC",
    "id" : 775130626836103168,
    "created_at" : "2016-09-12 00:35:17 +0000",
    "user" : {
      "name" : "Jim Cramer",
      "screen_name" : "jimcramer",
      "protected" : false,
      "id_str" : "14216123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451344676914593792\/8lV96m2l_normal.jpeg",
      "id" : 14216123,
      "verified" : true
    }
  },
  "id" : 775381516234924037,
  "created_at" : "2016-09-12 17:12:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mad Money On CNBC",
      "screen_name" : "MadMoneyOnCNBC",
      "indices" : [ 3, 18 ],
      "id_str" : "16451932",
      "id" : 16451932
    }, {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 80, 87 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MadMoneyOnCNBC\/status\/774376349725327360\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/RPt7b1EuVx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr8jL5fWgAEOw5p.jpg",
      "id_str" : "774376348248866817",
      "id" : 774376348248866817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr8jL5fWgAEOw5p.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/RPt7b1EuVx"
    } ],
    "hashtags" : [ {
      "text" : "IPO",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775381421506588672",
  "text" : "RT @MadMoneyOnCNBC: It's time to introduce yourself to top performing tech #IPO @twilio https:\/\/t.co\/RPt7b1EuVx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "twilio",
        "screen_name" : "twilio",
        "indices" : [ 60, 67 ],
        "id_str" : "15936194",
        "id" : 15936194
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MadMoneyOnCNBC\/status\/774376349725327360\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/RPt7b1EuVx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr8jL5fWgAEOw5p.jpg",
        "id_str" : "774376348248866817",
        "id" : 774376348248866817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr8jL5fWgAEOw5p.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/RPt7b1EuVx"
      } ],
      "hashtags" : [ {
        "text" : "IPO",
        "indices" : [ 55, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774376349725327360",
    "text" : "It's time to introduce yourself to top performing tech #IPO @twilio https:\/\/t.co\/RPt7b1EuVx",
    "id" : 774376349725327360,
    "created_at" : "2016-09-09 22:38:03 +0000",
    "user" : {
      "name" : "Mad Money On CNBC",
      "screen_name" : "MadMoneyOnCNBC",
      "protected" : false,
      "id_str" : "16451932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948220057896865793\/0xPs3zoV_normal.jpg",
      "id" : 16451932,
      "verified" : true
    }
  },
  "id" : 775381421506588672,
  "created_at" : "2016-09-12 17:11:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mad Money On CNBC",
      "screen_name" : "MadMoneyOnCNBC",
      "indices" : [ 3, 18 ],
      "id_str" : "16451932",
      "id" : 16451932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Booyah",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/8llJHm1jvL",
      "expanded_url" : "https:\/\/twitter.com\/KrosRhodes\/status\/774369651363045376",
      "display_url" : "twitter.com\/KrosRhodes\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775381394461687808",
  "text" : "RT @MadMoneyOnCNBC: Thanks Kros! #Booyah https:\/\/t.co\/8llJHm1jvL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Booyah",
        "indices" : [ 13, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/8llJHm1jvL",
        "expanded_url" : "https:\/\/twitter.com\/KrosRhodes\/status\/774369651363045376",
        "display_url" : "twitter.com\/KrosRhodes\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774385583196106752",
    "text" : "Thanks Kros! #Booyah https:\/\/t.co\/8llJHm1jvL",
    "id" : 774385583196106752,
    "created_at" : "2016-09-09 23:14:45 +0000",
    "user" : {
      "name" : "Mad Money On CNBC",
      "screen_name" : "MadMoneyOnCNBC",
      "protected" : false,
      "id_str" : "16451932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948220057896865793\/0xPs3zoV_normal.jpg",
      "id" : 16451932,
      "verified" : true
    }
  },
  "id" : 775381394461687808,
  "created_at" : "2016-09-12 17:11:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "indices" : [ 3, 18 ],
      "id_str" : "14174897",
      "id" : 14174897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/VUtq5sporp",
      "expanded_url" : "http:\/\/ow.ly\/82bs3046olr",
      "display_url" : "ow.ly\/82bs3046olr"
    } ]
  },
  "geo" : { },
  "id_str" : "775381178127884288",
  "text" : "RT @analyticbridge: Detecting Money Laundering with Unsupervised ML https:\/\/t.co\/VUtq5sporp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/VUtq5sporp",
        "expanded_url" : "http:\/\/ow.ly\/82bs3046olr",
        "display_url" : "ow.ly\/82bs3046olr"
      } ]
    },
    "geo" : { },
    "id_str" : "775379001766535168",
    "text" : "Detecting Money Laundering with Unsupervised ML https:\/\/t.co\/VUtq5sporp",
    "id" : 775379001766535168,
    "created_at" : "2016-09-12 17:02:14 +0000",
    "user" : {
      "name" : "Data Science Central",
      "screen_name" : "analyticbridge",
      "protected" : false,
      "id_str" : "14174897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823984252035309568\/pPt7JWhh_normal.jpg",
      "id" : 14174897,
      "verified" : false
    }
  },
  "id" : 775381178127884288,
  "created_at" : "2016-09-12 17:10:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/775380132001447937\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/4aV6CkU1rX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsK0HoYWcAA0EY4.jpg",
      "id_str" : "775380129052782592",
      "id" : 775380129052782592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsK0HoYWcAA0EY4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4aV6CkU1rX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/FQOcYdCMAT",
      "expanded_url" : "http:\/\/engt.co\/2cTPFVs",
      "display_url" : "engt.co\/2cTPFVs"
    } ]
  },
  "geo" : { },
  "id_str" : "775381078823563266",
  "text" : "RT @engadget: The solar panels and inverter we'd buy https:\/\/t.co\/FQOcYdCMAT https:\/\/t.co\/4aV6CkU1rX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/775380132001447937\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/4aV6CkU1rX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsK0HoYWcAA0EY4.jpg",
        "id_str" : "775380129052782592",
        "id" : 775380129052782592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsK0HoYWcAA0EY4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/4aV6CkU1rX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/FQOcYdCMAT",
        "expanded_url" : "http:\/\/engt.co\/2cTPFVs",
        "display_url" : "engt.co\/2cTPFVs"
      } ]
    },
    "geo" : { },
    "id_str" : "775380132001447937",
    "text" : "The solar panels and inverter we'd buy https:\/\/t.co\/FQOcYdCMAT https:\/\/t.co\/4aV6CkU1rX",
    "id" : 775380132001447937,
    "created_at" : "2016-09-12 17:06:43 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 775381078823563266,
  "created_at" : "2016-09-12 17:10:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775380893913452544",
  "text" : "RT @martincallan: Greening pledges grammar 'meritocracy': A new generation of grammar schools will improve access to good schoo... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/9MlrUyp4QB",
        "expanded_url" : "http:\/\/bbc.in\/2cpUIMd",
        "display_url" : "bbc.in\/2cpUIMd"
      } ]
    },
    "geo" : { },
    "id_str" : "775379477475897344",
    "text" : "Greening pledges grammar 'meritocracy': A new generation of grammar schools will improve access to good schoo... https:\/\/t.co\/9MlrUyp4QB",
    "id" : 775379477475897344,
    "created_at" : "2016-09-12 17:04:07 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 775380893913452544,
  "created_at" : "2016-09-12 17:09:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/PGbo9S8io1",
      "expanded_url" : "http:\/\/bit.ly\/2c4croD",
      "display_url" : "bit.ly\/2c4croD"
    } ]
  },
  "geo" : { },
  "id_str" : "775380809649979392",
  "text" : "RT @seanhannity: .@RealDonaldTrump comments on Hillary's health scare https:\/\/t.co\/PGbo9S8io1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/PGbo9S8io1",
        "expanded_url" : "http:\/\/bit.ly\/2c4croD",
        "display_url" : "bit.ly\/2c4croD"
      } ]
    },
    "geo" : { },
    "id_str" : "775378182304325633",
    "text" : ".@RealDonaldTrump comments on Hillary's health scare https:\/\/t.co\/PGbo9S8io1",
    "id" : 775378182304325633,
    "created_at" : "2016-09-12 16:58:59 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 775380809649979392,
  "created_at" : "2016-09-12 17:09:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/Vwjjlov5Aq",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-3785258\/9-11-memorial-California-college-President-Obama-attended-vandalized-thrown-trash.html",
      "display_url" : "dailymail.co.uk\/news\/article-3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775380789563387904",
  "text" : "RT @KassyDillon: This is disgusting. https:\/\/t.co\/Vwjjlov5Aq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/Vwjjlov5Aq",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-3785258\/9-11-memorial-California-college-President-Obama-attended-vandalized-thrown-trash.html",
        "display_url" : "dailymail.co.uk\/news\/article-3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775377707681079296",
    "text" : "This is disgusting. https:\/\/t.co\/Vwjjlov5Aq",
    "id" : 775377707681079296,
    "created_at" : "2016-09-12 16:57:05 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 775380789563387904,
  "created_at" : "2016-09-12 17:09:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Enlightened Women",
      "screen_name" : "NeWNetwork",
      "indices" : [ 35, 46 ],
      "id_str" : "45241685",
      "id" : 45241685
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/775375153710718976\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/iS6gQfJcSB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKvle5WAAAP1nk.jpg",
      "id_str" : "775375144344748032",
      "id" : 775375144344748032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKvle5WAAAP1nk.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/iS6gQfJcSB"
    } ],
    "hashtags" : [ {
      "text" : "ShesConservative",
      "indices" : [ 17, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775380770319892480",
  "text" : "RT @KassyDillon: #ShesConservative @NeWNetwork https:\/\/t.co\/iS6gQfJcSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Enlightened Women",
        "screen_name" : "NeWNetwork",
        "indices" : [ 18, 29 ],
        "id_str" : "45241685",
        "id" : 45241685
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/775375153710718976\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/iS6gQfJcSB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKvle5WAAAP1nk.jpg",
        "id_str" : "775375144344748032",
        "id" : 775375144344748032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKvle5WAAAP1nk.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/iS6gQfJcSB"
      } ],
      "hashtags" : [ {
        "text" : "ShesConservative",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775375153710718976",
    "text" : "#ShesConservative @NeWNetwork https:\/\/t.co\/iS6gQfJcSB",
    "id" : 775375153710718976,
    "created_at" : "2016-09-12 16:46:57 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 775380770319892480,
  "created_at" : "2016-09-12 17:09:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    }, {
      "name" : "Gavin McInnes",
      "screen_name" : "Gavin_McInnes",
      "indices" : [ 36, 50 ],
      "id_str" : "147580943",
      "id" : 147580943
    }, {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "indices" : [ 51, 67 ],
      "id_str" : "164070785",
      "id" : 164070785
    }, {
      "name" : "Sargon",
      "screen_name" : "Sargon_of_Akkad",
      "indices" : [ 79, 95 ],
      "id_str" : "2472399354",
      "id" : 2472399354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775380737604419584",
  "text" : "RT @scrowder: What project includes @Gavin_McInnes @Lauren_Southern (possibly) @Sargon_of_Akkad and@cenkuygur? Stay tuned to #LwC to find o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gavin McInnes",
        "screen_name" : "Gavin_McInnes",
        "indices" : [ 22, 36 ],
        "id_str" : "147580943",
        "id" : 147580943
      }, {
        "name" : "Lauren Southern",
        "screen_name" : "Lauren_Southern",
        "indices" : [ 37, 53 ],
        "id_str" : "164070785",
        "id" : 164070785
      }, {
        "name" : "Sargon",
        "screen_name" : "Sargon_of_Akkad",
        "indices" : [ 65, 81 ],
        "id_str" : "2472399354",
        "id" : 2472399354
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775375118721843205",
    "text" : "What project includes @Gavin_McInnes @Lauren_Southern (possibly) @Sargon_of_Akkad and@cenkuygur? Stay tuned to #LwC to find out.",
    "id" : 775375118721843205,
    "created_at" : "2016-09-12 16:46:48 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 775380737604419584,
  "created_at" : "2016-09-12 17:09:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Enlightened Women",
      "screen_name" : "NeWNetwork",
      "indices" : [ 35, 46 ],
      "id_str" : "45241685",
      "id" : 45241685
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/775372572624035840\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/HA1X5oci4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKtPdDWIAABrGO.jpg",
      "id_str" : "775372566869450752",
      "id" : 775372566869450752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKtPdDWIAABrGO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/HA1X5oci4h"
    } ],
    "hashtags" : [ {
      "text" : "ShesConservative",
      "indices" : [ 17, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775380687834800128",
  "text" : "RT @KassyDillon: #ShesConservative @NeWNetwork https:\/\/t.co\/HA1X5oci4h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Enlightened Women",
        "screen_name" : "NeWNetwork",
        "indices" : [ 18, 29 ],
        "id_str" : "45241685",
        "id" : 45241685
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KassyDillon\/status\/775372572624035840\/photo\/1",
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/HA1X5oci4h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKtPdDWIAABrGO.jpg",
        "id_str" : "775372566869450752",
        "id" : 775372566869450752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKtPdDWIAABrGO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/HA1X5oci4h"
      } ],
      "hashtags" : [ {
        "text" : "ShesConservative",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775372572624035840",
    "text" : "#ShesConservative @NeWNetwork https:\/\/t.co\/HA1X5oci4h",
    "id" : 775372572624035840,
    "created_at" : "2016-09-12 16:36:41 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 775380687834800128,
  "created_at" : "2016-09-12 17:08:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/hBEtcQyOxA",
      "expanded_url" : "http:\/\/www.wsj.com\/articles\/congress-can-save-the-internet-1473630838",
      "display_url" : "wsj.com\/articles\/congr\u2026"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/nJUL6vcmop",
      "expanded_url" : "https:\/\/www.tedcruz.org\/l\/protectthenet\/",
      "display_url" : "tedcruz.org\/l\/protectthene\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775380617957605376",
  "text" : "RT @tedcruz: Congress Can Save the Internet --&gt; https:\/\/t.co\/hBEtcQyOxA\n\nJoin the fight: https:\/\/t.co\/nJUL6vcmop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/hBEtcQyOxA",
        "expanded_url" : "http:\/\/www.wsj.com\/articles\/congress-can-save-the-internet-1473630838",
        "display_url" : "wsj.com\/articles\/congr\u2026"
      }, {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/nJUL6vcmop",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/protectthenet\/",
        "display_url" : "tedcruz.org\/l\/protectthene\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "775370544526925826",
    "text" : "Congress Can Save the Internet --&gt; https:\/\/t.co\/hBEtcQyOxA\n\nJoin the fight: https:\/\/t.co\/nJUL6vcmop",
    "id" : 775370544526925826,
    "created_at" : "2016-09-12 16:28:38 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 775380617957605376,
  "created_at" : "2016-09-12 17:08:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/5dDzQJURg8",
      "expanded_url" : "http:\/\/bit.ly\/2cI3zJR",
      "display_url" : "bit.ly\/2cI3zJR"
    } ]
  },
  "geo" : { },
  "id_str" : "775380032248250368",
  "text" : "RT @GuyKawasaki: Marine MV 22 Osprey Lands in Nashville - YouTube https:\/\/t.co\/5dDzQJURg8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/erased12043072.com\" rel=\"nofollow\"\u003Eerased12043072\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/5dDzQJURg8",
        "expanded_url" : "http:\/\/bit.ly\/2cI3zJR",
        "display_url" : "bit.ly\/2cI3zJR"
      } ]
    },
    "geo" : { },
    "id_str" : "775016262669705216",
    "text" : "Marine MV 22 Osprey Lands in Nashville - YouTube https:\/\/t.co\/5dDzQJURg8",
    "id" : 775016262669705216,
    "created_at" : "2016-09-11 17:00:50 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 775380032248250368,
  "created_at" : "2016-09-12 17:06:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/h5XYRKc3Ee",
      "expanded_url" : "http:\/\/fb.me\/2muZ4Q6u5",
      "display_url" : "fb.me\/2muZ4Q6u5"
    } ]
  },
  "geo" : { },
  "id_str" : "775379998366662658",
  "text" : "RT @EmperorDarroux: 'Rise of Iron' remixes the very first Strike in 'Destiny' https:\/\/t.co\/h5XYRKc3Ee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/h5XYRKc3Ee",
        "expanded_url" : "http:\/\/fb.me\/2muZ4Q6u5",
        "display_url" : "fb.me\/2muZ4Q6u5"
      } ]
    },
    "geo" : { },
    "id_str" : "775378603316051968",
    "text" : "'Rise of Iron' remixes the very first Strike in 'Destiny' https:\/\/t.co\/h5XYRKc3Ee",
    "id" : 775378603316051968,
    "created_at" : "2016-09-12 17:00:39 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 775379998366662658,
  "created_at" : "2016-09-12 17:06:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/775378591639035904\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/E9yGcjSrh1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKyuD6XYAABBtL.jpg",
      "id_str" : "775378590254981120",
      "id" : 775378590254981120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKyuD6XYAABBtL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/E9yGcjSrh1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775379975289593856",
  "text" : "RT @saatchi_gallery: German artist Felix Jaensch creates impressive LEGO animals. https:\/\/t.co\/E9yGcjSrh1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/775378591639035904\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/E9yGcjSrh1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKyuD6XYAABBtL.jpg",
        "id_str" : "775378590254981120",
        "id" : 775378590254981120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKyuD6XYAABBtL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/E9yGcjSrh1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775378591639035904",
    "text" : "German artist Felix Jaensch creates impressive LEGO animals. https:\/\/t.co\/E9yGcjSrh1",
    "id" : 775378591639035904,
    "created_at" : "2016-09-12 17:00:36 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 775379975289593856,
  "created_at" : "2016-09-12 17:06:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775379655767490561",
  "text" : "Go up to people and tell them batman isn't real",
  "id" : 775379655767490561,
  "created_at" : "2016-09-12 17:04:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775379546698833922",
  "text" : "Wanna see a magic trick? Will make this phone disappear? Puts phone in pocket",
  "id" : 775379546698833922,
  "created_at" : "2016-09-12 17:04:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775379425781280768",
  "text" : "Men hate mixed messages, that is a fact. They also like it when a girl doesn't wait a few hours or days to reply back.",
  "id" : 775379425781280768,
  "created_at" : "2016-09-12 17:03:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/NzhQr6j5b1",
      "expanded_url" : "http:\/\/fb.me\/8oQvoxcmU",
      "display_url" : "fb.me\/8oQvoxcmU"
    } ]
  },
  "geo" : { },
  "id_str" : "775367555905101825",
  "text" : "RT @EmperorDarroux: The RetroUSB AVS just replaced my childhood Nintendo https:\/\/t.co\/NzhQr6j5b1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/NzhQr6j5b1",
        "expanded_url" : "http:\/\/fb.me\/8oQvoxcmU",
        "display_url" : "fb.me\/8oQvoxcmU"
      } ]
    },
    "geo" : { },
    "id_str" : "775367230141923328",
    "text" : "The RetroUSB AVS just replaced my childhood Nintendo https:\/\/t.co\/NzhQr6j5b1",
    "id" : 775367230141923328,
    "created_at" : "2016-09-12 16:15:27 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 775367555905101825,
  "created_at" : "2016-09-12 16:16:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775367305178017792",
  "text" : "Gave my friend Samuel my tigers tickets, wish I could have gone to the game",
  "id" : 775367305178017792,
  "created_at" : "2016-09-12 16:15:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "d white",
      "screen_name" : "_derrickwhite",
      "indices" : [ 3, 17 ],
      "id_str" : "3442239437",
      "id" : 3442239437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775366600333615106",
  "text" : "RT @_derrickwhite: Greatness is a process.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "775365659895160833",
    "text" : "Greatness is a process.",
    "id" : 775365659895160833,
    "created_at" : "2016-09-12 16:09:13 +0000",
    "user" : {
      "name" : "d white",
      "screen_name" : "_derrickwhite",
      "protected" : false,
      "id_str" : "3442239437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983369486546989057\/BdD3b08F_normal.jpg",
      "id" : 3442239437,
      "verified" : false
    }
  },
  "id" : 775366600333615106,
  "created_at" : "2016-09-12 16:12:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775366537570095104",
  "text" : "I need to be careful on how smooth I am",
  "id" : 775366537570095104,
  "created_at" : "2016-09-12 16:12:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Pardo",
      "screen_name" : "Rob_Pardo",
      "indices" : [ 3, 13 ],
      "id_str" : "357210897",
      "id" : 357210897
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "forbiddenML",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775329347393753088",
  "text" : "RT @Rob_Pardo: But pretty ironic to be at a \"forbidden\" conference that is live streamed ;) #forbiddenML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "forbiddenML",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756240330735882240",
    "text" : "But pretty ironic to be at a \"forbidden\" conference that is live streamed ;) #forbiddenML",
    "id" : 756240330735882240,
    "created_at" : "2016-07-21 21:31:59 +0000",
    "user" : {
      "name" : "Rob Pardo",
      "screen_name" : "Rob_Pardo",
      "protected" : false,
      "id_str" : "357210897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829461947418451968\/43cCIyG7_normal.jpg",
      "id" : 357210897,
      "verified" : true
    }
  },
  "id" : 775329347393753088,
  "created_at" : "2016-09-12 13:44:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spry Fox",
      "screen_name" : "spryfox",
      "indices" : [ 3, 11 ],
      "id_str" : "188917833",
      "id" : 188917833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/yBggrefMj6",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/road-not-taken\/id1120861209?ls=1&mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/road-no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775329279559204864",
  "text" : "RT @spryfox: Road Not Taken is finally available on iOS! Get your puzzle adventure RPG fix now, people! https:\/\/t.co\/yBggrefMj6 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/spryfox\/status\/758371849054990336\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/gNjazP4p9W",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZG2BwUMAEQeMf.jpg",
        "id_str" : "758371481256472577",
        "id" : 758371481256472577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZG2BwUMAEQeMf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 650
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/gNjazP4p9W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/yBggrefMj6",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/road-not-taken\/id1120861209?ls=1&mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/road-no\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758371849054990336",
    "text" : "Road Not Taken is finally available on iOS! Get your puzzle adventure RPG fix now, people! https:\/\/t.co\/yBggrefMj6 https:\/\/t.co\/gNjazP4p9W",
    "id" : 758371849054990336,
    "created_at" : "2016-07-27 18:41:53 +0000",
    "user" : {
      "name" : "Spry Fox",
      "screen_name" : "spryfox",
      "protected" : false,
      "id_str" : "188917833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1175658738\/SpryFox-Logo-Vertical-Print_normal.png",
      "id" : 188917833,
      "verified" : false
    }
  },
  "id" : 775329279559204864,
  "created_at" : "2016-09-12 13:44:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/775328566305230848\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/3DFK3gf8lf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKFOKNWEAA4Vl_.jpg",
      "id_str" : "775328564166135808",
      "id" : 775328564166135808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKFOKNWEAA4Vl_.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/3DFK3gf8lf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/IkV3VVUY8A",
      "expanded_url" : "http:\/\/engt.co\/2cl0A7I",
      "display_url" : "engt.co\/2cl0A7I"
    } ]
  },
  "geo" : { },
  "id_str" : "775329132783800320",
  "text" : "RT @engadget: Deezer tracks now play in your Twitter timeline https:\/\/t.co\/IkV3VVUY8A https:\/\/t.co\/3DFK3gf8lf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/775328566305230848\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/3DFK3gf8lf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsKFOKNWEAA4Vl_.jpg",
        "id_str" : "775328564166135808",
        "id" : 775328564166135808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsKFOKNWEAA4Vl_.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/3DFK3gf8lf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/IkV3VVUY8A",
        "expanded_url" : "http:\/\/engt.co\/2cl0A7I",
        "display_url" : "engt.co\/2cl0A7I"
      } ]
    },
    "geo" : { },
    "id_str" : "775328566305230848",
    "text" : "Deezer tracks now play in your Twitter timeline https:\/\/t.co\/IkV3VVUY8A https:\/\/t.co\/3DFK3gf8lf",
    "id" : 775328566305230848,
    "created_at" : "2016-09-12 13:41:49 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 775329132783800320,
  "created_at" : "2016-09-12 13:44:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kael'thas",
      "screen_name" : "GeekyEmpire",
      "indices" : [ 0, 12 ],
      "id_str" : "3252472273",
      "id" : 3252472273
    }, {
      "name" : "colochita",
      "screen_name" : "sarsimel",
      "indices" : [ 13, 22 ],
      "id_str" : "102124966",
      "id" : 102124966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726479187519803392",
  "geo" : { },
  "id_str" : "775329059119198208",
  "in_reply_to_user_id" : 283068877,
  "text" : "@GeekyEmpire @sarsimel well, this is why I may be trying to learn Spanish :P",
  "id" : 775329059119198208,
  "in_reply_to_status_id" : 726479187519803392,
  "created_at" : "2016-09-12 13:43:47 +0000",
  "in_reply_to_screen_name" : "pink_dva",
  "in_reply_to_user_id_str" : "283068877",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb",
      "screen_name" : "CalebHarrison2",
      "indices" : [ 3, 18 ],
      "id_str" : "310012724",
      "id" : 310012724
    }, {
      "name" : "russophile",
      "screen_name" : "bananabanana86",
      "indices" : [ 20, 35 ],
      "id_str" : "198036830",
      "id" : 198036830
    }, {
      "name" : "Arthur C. Schaper",
      "screen_name" : "ArthurCSchaper",
      "indices" : [ 36, 51 ],
      "id_str" : "1177089950",
      "id" : 1177089950
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 52, 60 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "DeplorableBaconRose",
      "screen_name" : "RitzyBacon2",
      "indices" : [ 61, 73 ],
      "id_str" : "4884913213",
      "id" : 4884913213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775328849726992384",
  "text" : "RT @CalebHarrison2: @bananabanana86 @ArthurCSchaper @FoxNews @RitzyBacon2 Have you forgotten Obama's $10T debt, his war\/chaos in Libya\/Syri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "russophile",
        "screen_name" : "bananabanana86",
        "indices" : [ 0, 15 ],
        "id_str" : "198036830",
        "id" : 198036830
      }, {
        "name" : "Arthur C. Schaper",
        "screen_name" : "ArthurCSchaper",
        "indices" : [ 16, 31 ],
        "id_str" : "1177089950",
        "id" : 1177089950
      }, {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 32, 40 ],
        "id_str" : "1367531",
        "id" : 1367531
      }, {
        "name" : "DeplorableBaconRose",
        "screen_name" : "RitzyBacon2",
        "indices" : [ 41, 53 ],
        "id_str" : "4884913213",
        "id" : 4884913213
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "775058163460612096",
    "geo" : { },
    "id_str" : "775109022793863169",
    "in_reply_to_user_id" : 198036830,
    "text" : "@bananabanana86 @ArthurCSchaper @FoxNews @RitzyBacon2 Have you forgotten Obama's $10T debt, his war\/chaos in Libya\/Syria?",
    "id" : 775109022793863169,
    "in_reply_to_status_id" : 775058163460612096,
    "created_at" : "2016-09-11 23:09:26 +0000",
    "in_reply_to_screen_name" : "bananabanana86",
    "in_reply_to_user_id_str" : "198036830",
    "user" : {
      "name" : "Caleb",
      "screen_name" : "CalebHarrison2",
      "protected" : false,
      "id_str" : "310012724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883205044274950144\/ru_i6vf8_normal.jpg",
      "id" : 310012724,
      "verified" : false
    }
  },
  "id" : 775328849726992384,
  "created_at" : "2016-09-12 13:42:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas-Podolski.com",
      "screen_name" : "Podolski10",
      "indices" : [ 0, 11 ],
      "id_str" : "19596687",
      "id" : 19596687
    }, {
      "name" : "anjar febriantoro",
      "screen_name" : "anjarfebri",
      "indices" : [ 12, 23 ],
      "id_str" : "258697068",
      "id" : 258697068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775263257024143360",
  "geo" : { },
  "id_str" : "775328247223508992",
  "in_reply_to_user_id" : 19596687,
  "text" : "@Podolski10 @anjarfebri Yesterday was also the Coptic new year",
  "id" : 775328247223508992,
  "in_reply_to_status_id" : 775263257024143360,
  "created_at" : "2016-09-12 13:40:33 +0000",
  "in_reply_to_screen_name" : "Podolski10",
  "in_reply_to_user_id_str" : "19596687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "775327596288602112",
  "geo" : { },
  "id_str" : "775327888321220608",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 *Someone",
  "id" : 775327888321220608,
  "in_reply_to_status_id" : 775327596288602112,
  "created_at" : "2016-09-12 13:39:08 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775327596288602112",
  "text" : "Some said I am hilarious to their friend, made my day",
  "id" : 775327596288602112,
  "created_at" : "2016-09-12 13:37:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "indices" : [ 3, 15 ],
      "id_str" : "15231287",
      "id" : 15231287
    }, {
      "name" : "Andrew White",
      "screen_name" : "mdmcentral",
      "indices" : [ 34, 45 ],
      "id_str" : "135507209",
      "id" : 135507209
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blog",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775028082587545600",
  "text" : "RT @Gartner_inc: Gartner #Blog by @mdmcentral, What to do? A little ERP? A little IOT? A little big data? Who Knows\u2026.Who Cares?\u00A0https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.engage121.com\" rel=\"nofollow\"\u003Eengage121\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew White",
        "screen_name" : "mdmcentral",
        "indices" : [ 17, 28 ],
        "id_str" : "135507209",
        "id" : 135507209
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blog",
        "indices" : [ 8, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/SoScOLRzJF",
        "expanded_url" : "http:\/\/gtnr.it\/2cwweBB",
        "display_url" : "gtnr.it\/2cwweBB"
      } ]
    },
    "geo" : { },
    "id_str" : "775027633897795584",
    "text" : "Gartner #Blog by @mdmcentral, What to do? A little ERP? A little IOT? A little big data? Who Knows\u2026.Who Cares?\u00A0https:\/\/t.co\/SoScOLRzJF",
    "id" : 775027633897795584,
    "created_at" : "2016-09-11 17:46:01 +0000",
    "user" : {
      "name" : "Gartner",
      "screen_name" : "Gartner_inc",
      "protected" : false,
      "id_str" : "15231287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479292472707649536\/HfChXWQy_normal.png",
      "id" : 15231287,
      "verified" : true
    }
  },
  "id" : 775028082587545600,
  "created_at" : "2016-09-11 17:47:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/775027720300339200\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Gn6btvrNnb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsFzmRIVUAAmhNh.jpg",
      "id_str" : "775027712155013120",
      "id" : 775027712155013120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsFzmRIVUAAmhNh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Gn6btvrNnb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775027720300339200",
  "text" : "Went to Azteca: 3.58\/5 stars https:\/\/t.co\/Gn6btvrNnb",
  "id" : 775027720300339200,
  "created_at" : "2016-09-11 17:46:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDF3\uD83C\uDDEE",
      "screen_name" : "Barefootfiremen",
      "indices" : [ 3, 19 ],
      "id_str" : "409591862",
      "id" : 409591862
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 21, 30 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774798373631168512",
  "text" : "RT @Barefootfiremen: @scrowder SJW prefer \"low hanging fruit\", and not actually social problems that need actual work to solve.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774714175373225984",
    "geo" : { },
    "id_str" : "774731137927176192",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder SJW prefer \"low hanging fruit\", and not actually social problems that need actual work to solve.",
    "id" : 774731137927176192,
    "in_reply_to_status_id" : 774714175373225984,
    "created_at" : "2016-09-10 22:07:51 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "\uD83C\uDDFA\uD83C\uDDF8\uD83C\uDDF3\uD83C\uDDEE",
      "screen_name" : "Barefootfiremen",
      "protected" : false,
      "id_str" : "409591862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791074488997654528\/_PvdFxvj_normal.jpg",
      "id" : 409591862,
      "verified" : false
    }
  },
  "id" : 774798373631168512,
  "created_at" : "2016-09-11 02:35:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774704991948767232",
  "text" : "RT @BarbaraCorcoran: Always create a sense of demand for your new product, rather than waiting to have demand.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774686505478545408",
    "text" : "Always create a sense of demand for your new product, rather than waiting to have demand.",
    "id" : 774686505478545408,
    "created_at" : "2016-09-10 19:10:30 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 774704991948767232,
  "created_at" : "2016-09-10 20:23:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TruthStorm",
      "screen_name" : "dystopia47",
      "indices" : [ 0, 11 ],
      "id_str" : "237985124",
      "id" : 237985124
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 12, 24 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 25, 33 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "774538108805246977",
  "geo" : { },
  "id_str" : "774704845919887360",
  "in_reply_to_user_id" : 237985124,
  "text" : "@dystopia47 @KassyDillon @FoxNews Hell no!",
  "id" : 774704845919887360,
  "in_reply_to_status_id" : 774538108805246977,
  "created_at" : "2016-09-10 20:23:23 +0000",
  "in_reply_to_screen_name" : "dystopia47",
  "in_reply_to_user_id_str" : "237985124",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry_uzo",
      "screen_name" : "JerryUzo",
      "indices" : [ 3, 12 ],
      "id_str" : "953957729416212480",
      "id" : 953957729416212480
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 14, 26 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Duane Jr.",
      "screen_name" : "PizzaPartyBen",
      "indices" : [ 27, 41 ],
      "id_str" : "272107377",
      "id" : 272107377
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 42, 50 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774704631628767232",
  "text" : "RT @jerryuzo: @KassyDillon @PizzaPartyBen @FoxNews I still don't trust them. Will be rigged. We have to turn out d vote please!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      }, {
        "name" : "Duane Jr.",
        "screen_name" : "PizzaPartyBen",
        "indices" : [ 13, 27 ],
        "id_str" : "272107377",
        "id" : 272107377
      }, {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 28, 36 ],
        "id_str" : "1367531",
        "id" : 1367531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774399271919640576",
    "geo" : { },
    "id_str" : "774409643565035520",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon @PizzaPartyBen @FoxNews I still don't trust them. Will be rigged. We have to turn out d vote please!!",
    "id" : 774409643565035520,
    "in_reply_to_status_id" : 774399271919640576,
    "created_at" : "2016-09-10 00:50:21 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "#MAGA",
      "screen_name" : "UoKnowsBest",
      "protected" : false,
      "id_str" : "41172619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/881323016940138496\/oSSpHoXx_normal.jpg",
      "id" : 41172619,
      "verified" : false
    }
  },
  "id" : 774704631628767232,
  "created_at" : "2016-09-10 20:22:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kali",
      "screen_name" : "KaliKaler",
      "indices" : [ 3, 13 ],
      "id_str" : "1411329872",
      "id" : 1411329872
    }, {
      "name" : "Lifting Posts \uD83C\uDFCB\uFE0F\u200D\u2640\uFE0F",
      "screen_name" : "LiftingPosts",
      "indices" : [ 15, 28 ],
      "id_str" : "779159359586570240",
      "id" : 779159359586570240
    }, {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ 29, 41 ],
      "id_str" : "50618718",
      "id" : 50618718
    }, {
      "name" : "Sammy White",
      "screen_name" : "SaammyWhite",
      "indices" : [ 42, 54 ],
      "id_str" : "442466437",
      "id" : 442466437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774704440037085184",
  "text" : "RT @KaliKaler: @LiftingPosts @SpeakComedy @SaammyWhite true homie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lifting Posts \uD83C\uDFCB\uFE0F\u200D\u2640\uFE0F",
        "screen_name" : "LiftingPosts",
        "indices" : [ 0, 13 ],
        "id_str" : "779159359586570240",
        "id" : 779159359586570240
      }, {
        "name" : "SpeakComedy",
        "screen_name" : "SpeakComedy",
        "indices" : [ 14, 26 ],
        "id_str" : "50618718",
        "id" : 50618718
      }, {
        "name" : "Sammy White",
        "screen_name" : "SaammyWhite",
        "indices" : [ 27, 39 ],
        "id_str" : "442466437",
        "id" : 442466437
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "773224427878100992",
    "geo" : { },
    "id_str" : "774703095104188417",
    "in_reply_to_user_id" : 2259831996,
    "text" : "@LiftingPosts @SpeakComedy @SaammyWhite true homie",
    "id" : 774703095104188417,
    "in_reply_to_status_id" : 773224427878100992,
    "created_at" : "2016-09-10 20:16:25 +0000",
    "in_reply_to_screen_name" : "UnitedRebelsInc",
    "in_reply_to_user_id_str" : "2259831996",
    "user" : {
      "name" : "Kali",
      "screen_name" : "KaliKaler",
      "protected" : false,
      "id_str" : "1411329872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/978864128164065280\/Y0g6A2LL_normal.jpg",
      "id" : 1411329872,
      "verified" : false
    }
  },
  "id" : 774704440037085184,
  "created_at" : "2016-09-10 20:21:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lifting Posts \uD83C\uDFCB\uFE0F\u200D\u2640\uFE0F",
      "screen_name" : "LiftingPosts",
      "indices" : [ 0, 13 ],
      "id_str" : "779159359586570240",
      "id" : 779159359586570240
    }, {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ 14, 26 ],
      "id_str" : "50618718",
      "id" : 50618718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773224427878100992",
  "geo" : { },
  "id_str" : "774704423180247041",
  "in_reply_to_user_id" : 2259831996,
  "text" : "@LiftingPosts @SpeakComedy Inspire people through the gospel",
  "id" : 774704423180247041,
  "in_reply_to_status_id" : 773224427878100992,
  "created_at" : "2016-09-10 20:21:42 +0000",
  "in_reply_to_screen_name" : "UnitedRebelsInc",
  "in_reply_to_user_id_str" : "2259831996",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/774702864258203652\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/TyZdw74MNa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsBMJaqXgAAuiSY.jpg",
      "id_str" : "774702860567281664",
      "id" : 774702860567281664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsBMJaqXgAAuiSY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/TyZdw74MNa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yMIMmHHOlV",
      "expanded_url" : "http:\/\/engt.co\/2cibN7k",
      "display_url" : "engt.co\/2cibN7k"
    } ]
  },
  "geo" : { },
  "id_str" : "774704164295221252",
  "text" : "RT @engadget: Roland's System-8 synthesizer does almost everything https:\/\/t.co\/yMIMmHHOlV https:\/\/t.co\/TyZdw74MNa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/774702864258203652\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/TyZdw74MNa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CsBMJaqXgAAuiSY.jpg",
        "id_str" : "774702860567281664",
        "id" : 774702860567281664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsBMJaqXgAAuiSY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/TyZdw74MNa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/yMIMmHHOlV",
        "expanded_url" : "http:\/\/engt.co\/2cibN7k",
        "display_url" : "engt.co\/2cibN7k"
      } ]
    },
    "geo" : { },
    "id_str" : "774702864258203652",
    "text" : "Roland's System-8 synthesizer does almost everything https:\/\/t.co\/yMIMmHHOlV https:\/\/t.co\/TyZdw74MNa",
    "id" : 774702864258203652,
    "created_at" : "2016-09-10 20:15:30 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 774704164295221252,
  "created_at" : "2016-09-10 20:20:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fP8mDiIA6C",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=5ONb3sCqxho",
      "display_url" : "youtube.com\/watch?v=5ONb3s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774704137887821824",
  "text" : "RT @scrowder: Hillary makes a campaign stop in Ohio where she's bombarded with a high pollen count. &gt;&gt; https:\/\/t.co\/fP8mDiIA6C https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/774672586747834368\/video\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/dIbE05qBsy",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774672538177798144\/pu\/img\/BsNY2N4f2GJWWfjk.jpg",
        "id_str" : "774672538177798144",
        "id" : 774672538177798144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774672538177798144\/pu\/img\/BsNY2N4f2GJWWfjk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/dIbE05qBsy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/fP8mDiIA6C",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=5ONb3sCqxho",
        "display_url" : "youtube.com\/watch?v=5ONb3s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774672586747834368",
    "text" : "Hillary makes a campaign stop in Ohio where she's bombarded with a high pollen count. &gt;&gt; https:\/\/t.co\/fP8mDiIA6C https:\/\/t.co\/dIbE05qBsy",
    "id" : 774672586747834368,
    "created_at" : "2016-09-10 18:15:12 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 774704137887821824,
  "created_at" : "2016-09-10 20:20:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Men's Thoughts",
      "screen_name" : "Males_Thoughts",
      "indices" : [ 3, 18 ],
      "id_str" : "845012778",
      "id" : 845012778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NFLHumor\/status\/774701493601628160\/video\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/KdVNncrIBf",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774701147802234880\/pu\/img\/ZNC35bpLHJNC4YX3.jpg",
      "id_str" : "774701147802234880",
      "id" : 774701147802234880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774701147802234880\/pu\/img\/ZNC35bpLHJNC4YX3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KdVNncrIBf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774704030131949568",
  "text" : "RT @Males_Thoughts: If you haven't seen it yet \uD83D\uDE2E Central Michigan https:\/\/t.co\/KdVNncrIBf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NFLHumor\/status\/774701493601628160\/video\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/KdVNncrIBf",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774701147802234880\/pu\/img\/ZNC35bpLHJNC4YX3.jpg",
        "id_str" : "774701147802234880",
        "id" : 774701147802234880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/774701147802234880\/pu\/img\/ZNC35bpLHJNC4YX3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/KdVNncrIBf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774703111151624192",
    "text" : "If you haven't seen it yet \uD83D\uDE2E Central Michigan https:\/\/t.co\/KdVNncrIBf",
    "id" : 774703111151624192,
    "created_at" : "2016-09-10 20:16:29 +0000",
    "user" : {
      "name" : "Men's Thoughts",
      "screen_name" : "Males_Thoughts",
      "protected" : false,
      "id_str" : "845012778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3679252960\/38d75dcfbe830185d6807b6f929aefc2_normal.jpeg",
      "id" : 845012778,
      "verified" : false
    }
  },
  "id" : 774704030131949568,
  "created_at" : "2016-09-10 20:20:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774703770605199361",
  "text" : "If only I could comprehend people's cunningness",
  "id" : 774703770605199361,
  "created_at" : "2016-09-10 20:19:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Smith",
      "screen_name" : "poundsmith2",
      "indices" : [ 3, 15 ],
      "id_str" : "782635687",
      "id" : 782635687
    }, {
      "name" : "LincolnsLegends",
      "screen_name" : "LincolnsLegends",
      "indices" : [ 92, 108 ],
      "id_str" : "2817161266",
      "id" : 2817161266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chicago",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "favoriteshirt",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774703549049470976",
  "text" : "RT @poundsmith2: About to venture out to grab some grub in #Chicago and wanted to represent @LincolnsLegends #favoriteshirt https:\/\/t.co\/tD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LincolnsLegends",
        "screen_name" : "LincolnsLegends",
        "indices" : [ 75, 91 ],
        "id_str" : "2817161266",
        "id" : 2817161266
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/poundsmith2\/status\/769557058085609472\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/tDN81a8n9M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq4D_ATUkAEsUWa.jpg",
        "id_str" : "769556967274614785",
        "id" : 769556967274614785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq4D_ATUkAEsUWa.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/tDN81a8n9M"
      } ],
      "hashtags" : [ {
        "text" : "Chicago",
        "indices" : [ 42, 50 ]
      }, {
        "text" : "favoriteshirt",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769557058085609472",
    "text" : "About to venture out to grab some grub in #Chicago and wanted to represent @LincolnsLegends #favoriteshirt https:\/\/t.co\/tDN81a8n9M",
    "id" : 769557058085609472,
    "created_at" : "2016-08-27 15:27:54 +0000",
    "user" : {
      "name" : "Larry Smith",
      "screen_name" : "poundsmith2",
      "protected" : false,
      "id_str" : "782635687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/954361825784750081\/SLSk9ddl_normal.jpg",
      "id" : 782635687,
      "verified" : false
    }
  },
  "id" : 774703549049470976,
  "created_at" : "2016-09-10 20:18:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "indices" : [ 3, 18 ],
      "id_str" : "20642356",
      "id" : 20642356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774703230525640704",
  "text" : "RT @davidlongoria7: Believe your beliefs .. Doubt your doubts, if not you will ... Doubt your beliefs. - Rich Simmonds #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774688627108548608",
    "text" : "Believe your beliefs .. Doubt your doubts, if not you will ... Doubt your beliefs. - Rich Simmonds #quote",
    "id" : 774688627108548608,
    "created_at" : "2016-09-10 19:18:56 +0000",
    "user" : {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "protected" : false,
      "id_str" : "20642356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754888883465138176\/lvppUQYX_normal.jpg",
      "id" : 20642356,
      "verified" : true
    }
  },
  "id" : 774703230525640704,
  "created_at" : "2016-09-10 20:16:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "deepereyes",
      "indices" : [ 3, 14 ],
      "id_str" : "36772213",
      "id" : 36772213
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 17, 26 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702952636219392",
  "text" : "RT @deepereyes: .@scrowder someone in her campaign needs to be fired for not linking pollen to global warming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 1, 10 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774672586747834368",
    "geo" : { },
    "id_str" : "774678123807932416",
    "in_reply_to_user_id" : 19091173,
    "text" : ".@scrowder someone in her campaign needs to be fired for not linking pollen to global warming.",
    "id" : 774678123807932416,
    "in_reply_to_status_id" : 774672586747834368,
    "created_at" : "2016-09-10 18:37:12 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Robert",
      "screen_name" : "deepereyes",
      "protected" : false,
      "id_str" : "36772213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/966356810977378304\/Mj8Yshk8_normal.jpg",
      "id" : 36772213,
      "verified" : false
    }
  },
  "id" : 774702952636219392,
  "created_at" : "2016-09-10 20:15:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 15, 24 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702923217371136",
  "text" : "@Sergeant_Josh @scrowder Haha, definitely \uD83D\uDE02",
  "id" : 774702923217371136,
  "created_at" : "2016-09-10 20:15:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lili Moore-Coffin",
      "screen_name" : "laughrodite4u",
      "indices" : [ 3, 17 ],
      "id_str" : "2855915617",
      "id" : 2855915617
    }, {
      "name" : "TurrisFortisMihiDeus",
      "screen_name" : "ZippyYeti",
      "indices" : [ 19, 29 ],
      "id_str" : "1317736292",
      "id" : 1317736292
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 30, 42 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702725921513472",
  "text" : "RT @laughrodite4u: @ZippyYeti @KassyDillon IKR?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TurrisFortisMihiDeus",
        "screen_name" : "ZippyYeti",
        "indices" : [ 0, 10 ],
        "id_str" : "1317736292",
        "id" : 1317736292
      }, {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 11, 23 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774690095270068224",
    "geo" : { },
    "id_str" : "774690190296092672",
    "in_reply_to_user_id" : 1317736292,
    "text" : "@ZippyYeti @KassyDillon IKR?",
    "id" : 774690190296092672,
    "in_reply_to_status_id" : 774690095270068224,
    "created_at" : "2016-09-10 19:25:09 +0000",
    "in_reply_to_screen_name" : "ZippyYeti",
    "in_reply_to_user_id_str" : "1317736292",
    "user" : {
      "name" : "Lili Moore-Coffin",
      "screen_name" : "laughrodite4u",
      "protected" : false,
      "id_str" : "2855915617",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992271687482724352\/nXQZLP9x_normal.jpg",
      "id" : 2855915617,
      "verified" : false
    }
  },
  "id" : 774702725921513472,
  "created_at" : "2016-09-10 20:14:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schadenfreudelish",
      "screen_name" : "aggierican",
      "indices" : [ 3, 14 ],
      "id_str" : "2756581260",
      "id" : 2756581260
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 16, 28 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "Sarah",
      "screen_name" : "SohlerSarah",
      "indices" : [ 29, 41 ],
      "id_str" : "2160518711",
      "id" : 2160518711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702623085637632",
  "text" : "RT @aggierican: @KassyDillon @SohlerSarah A pic of Venezuela should suffice ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      }, {
        "name" : "Sarah",
        "screen_name" : "SohlerSarah",
        "indices" : [ 13, 25 ],
        "id_str" : "2160518711",
        "id" : 2160518711
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774636503486062592",
    "geo" : { },
    "id_str" : "774686409907138560",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon @SohlerSarah A pic of Venezuela should suffice ;)",
    "id" : 774686409907138560,
    "in_reply_to_status_id" : 774636503486062592,
    "created_at" : "2016-09-10 19:10:07 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "Schadenfreudelish",
      "screen_name" : "aggierican",
      "protected" : false,
      "id_str" : "2756581260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/968632522853814274\/4qDlfiEv_normal.jpg",
      "id" : 2756581260,
      "verified" : false
    }
  },
  "id" : 774702623085637632,
  "created_at" : "2016-09-10 20:14:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chairman Ka Pow",
      "screen_name" : "careful_now0",
      "indices" : [ 3, 16 ],
      "id_str" : "749392216968355840",
      "id" : 749392216968355840
    }, {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 18, 30 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702565816532992",
  "text" : "RT @careful_now0: @KassyDillon as socialism is dying in Europe is it now hopping across the pond? Have a google of Jeremy Corbyn and Labour\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kassy Dillon",
        "screen_name" : "KassyDillon",
        "indices" : [ 0, 12 ],
        "id_str" : "178999981",
        "id" : 178999981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "774636503486062592",
    "geo" : { },
    "id_str" : "774646533375614976",
    "in_reply_to_user_id" : 178999981,
    "text" : "@KassyDillon as socialism is dying in Europe is it now hopping across the pond? Have a google of Jeremy Corbyn and Labour Party and chuckle.",
    "id" : 774646533375614976,
    "in_reply_to_status_id" : 774636503486062592,
    "created_at" : "2016-09-10 16:31:40 +0000",
    "in_reply_to_screen_name" : "KassyDillon",
    "in_reply_to_user_id_str" : "178999981",
    "user" : {
      "name" : "Chairman Ka Pow",
      "screen_name" : "careful_now0",
      "protected" : false,
      "id_str" : "749392216968355840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/970706128991608834\/Y5hysbe0_normal.jpg",
      "id" : 749392216968355840,
      "verified" : false
    }
  },
  "id" : 774702565816532992,
  "created_at" : "2016-09-10 20:14:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774702035056726016",
  "text" : "Magic Trick: Gonna make this phone disappear *Puts phone in pocket",
  "id" : 774702035056726016,
  "created_at" : "2016-09-10 20:12:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774664255220117504",
  "text" : "Don't overthink it, says nobody \uD83C\uDD92\uD83C\uDD92",
  "id" : 774664255220117504,
  "created_at" : "2016-09-10 17:42:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774644924352528385",
  "text" : "Are you confused? Welcome to life!",
  "id" : 774644924352528385,
  "created_at" : "2016-09-10 16:25:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Durso",
      "screen_name" : "LeslieDurso",
      "indices" : [ 3, 15 ],
      "id_str" : "36719407",
      "id" : 36719407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getit",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774065328426848256",
  "text" : "RT @LeslieDurso: Talent you get from God, skill you get from hours and hours of training. #getit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getit",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773572120961880064",
    "text" : "Talent you get from God, skill you get from hours and hours of training. #getit",
    "id" : 773572120961880064,
    "created_at" : "2016-09-07 17:22:20 +0000",
    "user" : {
      "name" : "Leslie Durso",
      "screen_name" : "LeslieDurso",
      "protected" : false,
      "id_str" : "36719407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775373897227132928\/GH09Of2W_normal.jpg",
      "id" : 36719407,
      "verified" : true
    }
  },
  "id" : 774065328426848256,
  "created_at" : "2016-09-09 02:02:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774065210277539841",
  "text" : "RT @RandiAthenas: I bet you I could stop gambling.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774046430184910849",
    "text" : "I bet you I could stop gambling.",
    "id" : 774046430184910849,
    "created_at" : "2016-09-09 00:47:04 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 774065210277539841,
  "created_at" : "2016-09-09 02:01:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 0, 12 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774065111208124420",
  "in_reply_to_user_id" : 178999981,
  "text" : "@KassyDillon I wish there were a billion of you!!! Maybe in a parallel universe there is",
  "id" : 774065111208124420,
  "created_at" : "2016-09-09 02:01:18 +0000",
  "in_reply_to_screen_name" : "KassyDillon",
  "in_reply_to_user_id_str" : "178999981",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "indices" : [ 3, 19 ],
      "id_str" : "164070785",
      "id" : 164070785
    }, {
      "name" : "Jen Gerson",
      "screen_name" : "jengerson",
      "indices" : [ 21, 31 ],
      "id_str" : "23191561",
      "id" : 23191561
    }, {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 32, 37 ],
      "id_str" : "23818581",
      "id" : 23818581
    }, {
      "name" : "ishmael n. daro",
      "screen_name" : "iD4RO",
      "indices" : [ 119, 125 ],
      "id_str" : "16580249",
      "id" : 16580249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774064484352610304",
  "text" : "RT @Lauren_Southern: @jengerson @VICE soon, first I'm waiting for my feature in the \"Top 10 bigoted comments\" listicle @iD4RO is currently\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Gerson",
        "screen_name" : "jengerson",
        "indices" : [ 0, 10 ],
        "id_str" : "23191561",
        "id" : 23191561
      }, {
        "name" : "VICE",
        "screen_name" : "VICE",
        "indices" : [ 11, 16 ],
        "id_str" : "23818581",
        "id" : 23818581
      }, {
        "name" : "ishmael n. daro",
        "screen_name" : "iD4RO",
        "indices" : [ 98, 104 ],
        "id_str" : "16580249",
        "id" : 16580249
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "771420885106515968",
    "geo" : { },
    "id_str" : "771434979595264001",
    "in_reply_to_user_id" : 23191561,
    "text" : "@jengerson @VICE soon, first I'm waiting for my feature in the \"Top 10 bigoted comments\" listicle @iD4RO is currently working on :)",
    "id" : 771434979595264001,
    "in_reply_to_status_id" : 771420885106515968,
    "created_at" : "2016-09-01 19:50:06 +0000",
    "in_reply_to_screen_name" : "jengerson",
    "in_reply_to_user_id_str" : "23191561",
    "user" : {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "protected" : false,
      "id_str" : "164070785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992495915939368961\/hM2l6Mg2_normal.jpg",
      "id" : 164070785,
      "verified" : true
    }
  },
  "id" : 774064484352610304,
  "created_at" : "2016-09-09 01:58:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "indices" : [ 3, 19 ],
      "id_str" : "164070785",
      "id" : 164070785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774064278366064640",
  "text" : "RT @Lauren_Southern: Why don't we just devalue all words lefties - screw it! Math is genocide! Air conditioning is genocide! Bumping into m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773322249793339392",
    "text" : "Why don't we just devalue all words lefties - screw it! Math is genocide! Air conditioning is genocide! Bumping into me is legit genocide!",
    "id" : 773322249793339392,
    "created_at" : "2016-09-07 00:49:26 +0000",
    "user" : {
      "name" : "Lauren Southern",
      "screen_name" : "Lauren_Southern",
      "protected" : false,
      "id_str" : "164070785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992495915939368961\/hM2l6Mg2_normal.jpg",
      "id" : 164070785,
      "verified" : true
    }
  },
  "id" : 774064278366064640,
  "created_at" : "2016-09-09 01:58:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LwC",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/C3l95VFn9a",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/bd6ud\/1fm4k",
      "display_url" : "cards.twitter.com\/cards\/bd6ud\/1f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774063966909673472",
  "text" : "RT @scrowder: Talking Dunham\/Odell next. PLUS CLIMATE CHANGE IS RACIST! Then Larry Elder. https:\/\/t.co\/C3l95VFn9a #LwC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/C3l95VFn9a",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/bd6ud\/1fm4k",
        "display_url" : "cards.twitter.com\/cards\/bd6ud\/1f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774047991392931840",
    "text" : "Talking Dunham\/Odell next. PLUS CLIMATE CHANGE IS RACIST! Then Larry Elder. https:\/\/t.co\/C3l95VFn9a #LwC",
    "id" : 774047991392931840,
    "created_at" : "2016-09-09 00:53:16 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 774063966909673472,
  "created_at" : "2016-09-09 01:56:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rello",
      "screen_name" : "MichaelRello",
      "indices" : [ 3, 16 ],
      "id_str" : "77080603",
      "id" : 77080603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774063826266238977",
  "text" : "RT @MichaelRello: I want everyone to do good",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774060800960978944",
    "text" : "I want everyone to do good",
    "id" : 774060800960978944,
    "created_at" : "2016-09-09 01:44:10 +0000",
    "user" : {
      "name" : "Rello",
      "screen_name" : "MichaelRello",
      "protected" : false,
      "id_str" : "77080603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991872304530558976\/CwstNRl0_normal.jpg",
      "id" : 77080603,
      "verified" : false
    }
  },
  "id" : 774063826266238977,
  "created_at" : "2016-09-09 01:56:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774063710709047296",
  "text" : "I like being challenged at stuff I should know",
  "id" : 774063710709047296,
  "created_at" : "2016-09-09 01:55:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774063640458571777",
  "text" : "Some people can be sweet but hiding their true colors",
  "id" : 774063640458571777,
  "created_at" : "2016-09-09 01:55:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProFootballTalk",
      "screen_name" : "ProFootballTalk",
      "indices" : [ 3, 19 ],
      "id_str" : "16672159",
      "id" : 16672159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/I6pHSNkNT9",
      "expanded_url" : "http:\/\/wp.me\/p14QSB-a714",
      "display_url" : "wp.me\/p14QSB-a714"
    } ]
  },
  "geo" : { },
  "id_str" : "774043962940137472",
  "text" : "RT @ProFootballTalk: Marshawn Lynch may still change his mind about retirement https:\/\/t.co\/I6pHSNkNT9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/I6pHSNkNT9",
        "expanded_url" : "http:\/\/wp.me\/p14QSB-a714",
        "display_url" : "wp.me\/p14QSB-a714"
      } ]
    },
    "geo" : { },
    "id_str" : "774031434457559041",
    "text" : "Marshawn Lynch may still change his mind about retirement https:\/\/t.co\/I6pHSNkNT9",
    "id" : 774031434457559041,
    "created_at" : "2016-09-08 23:47:29 +0000",
    "user" : {
      "name" : "ProFootballTalk",
      "screen_name" : "ProFootballTalk",
      "protected" : false,
      "id_str" : "16672159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869243829047709698\/ZKPJxjyd_normal.jpg",
      "id" : 16672159,
      "verified" : true
    }
  },
  "id" : 774043962940137472,
  "created_at" : "2016-09-09 00:37:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774043440111812627",
  "text" : "RT @ijustine: APPLE AIR PODS LOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773588884760387584",
    "text" : "APPLE AIR PODS LOL",
    "id" : 773588884760387584,
    "created_at" : "2016-09-07 18:28:57 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 774043440111812627,
  "created_at" : "2016-09-09 00:35:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774043363888750592",
  "text" : "RT @ijustine: \u201COh what\u2019s this? A treat?\u201D - my dog\n\nA I R   P O D S  R I P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773591311060307968",
    "text" : "\u201COh what\u2019s this? A treat?\u201D - my dog\n\nA I R   P O D S  R I P",
    "id" : 773591311060307968,
    "created_at" : "2016-09-07 18:38:35 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 774043363888750592,
  "created_at" : "2016-09-09 00:34:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Finke",
      "screen_name" : "gailfinke",
      "indices" : [ 3, 13 ],
      "id_str" : "36699201",
      "id" : 36699201
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 15, 24 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774043081960255488",
  "text" : "RT @gailfinke: @scrowder That's why he's a science \"guy\" not a scienTIST.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "773980098684854274",
    "geo" : { },
    "id_str" : "773982896675774464",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder That's why he's a science \"guy\" not a scienTIST.",
    "id" : 773982896675774464,
    "in_reply_to_status_id" : 773980098684854274,
    "created_at" : "2016-09-08 20:34:37 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Gail Finke",
      "screen_name" : "gailfinke",
      "protected" : false,
      "id_str" : "36699201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781681060354658304\/Fq76HUjz_normal.jpg",
      "id" : 36699201,
      "verified" : false
    }
  },
  "id" : 774043081960255488,
  "created_at" : "2016-09-09 00:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/773959500558635009\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/h11DAUayOG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr2oD9pWYAQP0C-.jpg",
      "id_str" : "773959497018662916",
      "id" : 773959497018662916,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr2oD9pWYAQP0C-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/h11DAUayOG"
    } ],
    "hashtags" : [ {
      "text" : "AmySchumer",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774042831367331840",
  "text" : "RT @scrowder: I'm sure one isn't related to the other... #AmySchumer https:\/\/t.co\/h11DAUayOG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/773959500558635009\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/h11DAUayOG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr2oD9pWYAQP0C-.jpg",
        "id_str" : "773959497018662916",
        "id" : 773959497018662916,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr2oD9pWYAQP0C-.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/h11DAUayOG"
      } ],
      "hashtags" : [ {
        "text" : "AmySchumer",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773959500558635009",
    "text" : "I'm sure one isn't related to the other... #AmySchumer https:\/\/t.co\/h11DAUayOG",
    "id" : 773959500558635009,
    "created_at" : "2016-09-08 19:01:39 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 774042831367331840,
  "created_at" : "2016-09-09 00:32:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev McKevinFace",
      "screen_name" : "PalisadesKid",
      "indices" : [ 19, 32 ],
      "id_str" : "1376315006",
      "id" : 1376315006
    }, {
      "name" : "Queen Ari",
      "screen_name" : "iamqueenari",
      "indices" : [ 33, 45 ],
      "id_str" : "979148176333578240",
      "id" : 979148176333578240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774042431545376769",
  "text" : "RT @AlfonZoRachel: @PalisadesKid @IamQueenAri Ewww!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kev McKevinFace",
        "screen_name" : "PalisadesKid",
        "indices" : [ 0, 13 ],
        "id_str" : "1376315006",
        "id" : 1376315006
      }, {
        "name" : "Queen Ari",
        "screen_name" : "iamqueenari",
        "indices" : [ 14, 26 ],
        "id_str" : "979148176333578240",
        "id" : 979148176333578240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "772885082558259201",
    "geo" : { },
    "id_str" : "772893571863064576",
    "in_reply_to_user_id" : 1376315006,
    "text" : "@PalisadesKid @IamQueenAri Ewww!",
    "id" : 772893571863064576,
    "in_reply_to_status_id" : 772885082558259201,
    "created_at" : "2016-09-05 20:26:01 +0000",
    "in_reply_to_screen_name" : "PalisadesKid",
    "in_reply_to_user_id_str" : "1376315006",
    "user" : {
      "name" : "AlonZo Rachel",
      "screen_name" : "ZoWhatTheF",
      "protected" : false,
      "id_str" : "15920162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477494523728130051\/kkMes7SZ_normal.jpeg",
      "id" : 15920162,
      "verified" : false
    }
  },
  "id" : 774042431545376769,
  "created_at" : "2016-09-09 00:31:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana Loesch",
      "screen_name" : "DLoesch",
      "indices" : [ 3, 11 ],
      "id_str" : "7702542",
      "id" : 7702542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774042067718639616",
  "text" : "RT @DLoesch: Also, I don\u2019t trust Assange. It\u2019s great schadenfreude with Hillary now, but people are too eager to trust or parter with other\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773913781797650432",
    "text" : "Also, I don\u2019t trust Assange. It\u2019s great schadenfreude with Hillary now, but people are too eager to trust or parter with others.",
    "id" : 773913781797650432,
    "created_at" : "2016-09-08 15:59:58 +0000",
    "user" : {
      "name" : "Dana Loesch",
      "screen_name" : "DLoesch",
      "protected" : false,
      "id_str" : "7702542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/922292598030651393\/JKtPrRNV_normal.jpg",
      "id" : 7702542,
      "verified" : true
    }
  },
  "id" : 774042067718639616,
  "created_at" : "2016-09-09 00:29:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SJWs",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/fgcks1Rb1h",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/bd6ud\/7ulp",
      "display_url" : "cards.twitter.com\/cards\/bd6ud\/7u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774041908523913217",
  "text" : "RT @scrowder: Don't let twitter #SJWs cut you out of the loop. Sign up for the email list. It's free. And Creepy. https:\/\/t.co\/fgcks1Rb1h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SJWs",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/fgcks1Rb1h",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/bd6ud\/7ulp",
        "display_url" : "cards.twitter.com\/cards\/bd6ud\/7u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739107818960097280",
    "text" : "Don't let twitter #SJWs cut you out of the loop. Sign up for the email list. It's free. And Creepy. https:\/\/t.co\/fgcks1Rb1h",
    "id" : 739107818960097280,
    "created_at" : "2016-06-04 14:53:30 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 774041908523913217,
  "created_at" : "2016-09-09 00:29:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00E9r\u00F4me Lecat",
      "screen_name" : "jlecat",
      "indices" : [ 3, 10 ],
      "id_str" : "12515202",
      "id" : 12515202
    }, {
      "name" : "Jonathan MacDonald",
      "screen_name" : "jmacdonald",
      "indices" : [ 54, 65 ],
      "id_str" : "12427412",
      "id" : 12427412
    }, {
      "name" : "Open-Xchange",
      "screen_name" : "openexchange",
      "indices" : [ 69, 82 ],
      "id_str" : "27879588",
      "id" : 27879588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774041530554314752",
  "text" : "RT @jlecat: \"Where there is a mess there is a market\" @jmacdonald at @openexchange summit 2016 in Chicago. What mess are you solving?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan MacDonald",
        "screen_name" : "jmacdonald",
        "indices" : [ 42, 53 ],
        "id_str" : "12427412",
        "id" : 12427412
      }, {
        "name" : "Open-Xchange",
        "screen_name" : "openexchange",
        "indices" : [ 57, 70 ],
        "id_str" : "27879588",
        "id" : 27879588
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774025112638980096",
    "text" : "\"Where there is a mess there is a market\" @jmacdonald at @openexchange summit 2016 in Chicago. What mess are you solving?",
    "id" : 774025112638980096,
    "created_at" : "2016-09-08 23:22:22 +0000",
    "user" : {
      "name" : "J\u00E9r\u00F4me Lecat",
      "screen_name" : "jlecat",
      "protected" : false,
      "id_str" : "12515202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/989435757499691008\/4O7GVdYz_normal.jpg",
      "id" : 12515202,
      "verified" : true
    }
  },
  "id" : 774041530554314752,
  "created_at" : "2016-09-09 00:27:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "charlie mackesy",
      "screen_name" : "charliemackesy",
      "indices" : [ 3, 18 ],
      "id_str" : "402363096",
      "id" : 402363096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774041288588918784",
  "text" : "RT @charliemackesy: Kindness is the noblest weapon to conquer with. Thomas Fuller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774012965616058369",
    "text" : "Kindness is the noblest weapon to conquer with. Thomas Fuller",
    "id" : 774012965616058369,
    "created_at" : "2016-09-08 22:34:06 +0000",
    "user" : {
      "name" : "charlie mackesy",
      "screen_name" : "charliemackesy",
      "protected" : false,
      "id_str" : "402363096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870954578237378560\/r1Jq-S5A_normal.jpg",
      "id" : 402363096,
      "verified" : false
    }
  },
  "id" : 774041288588918784,
  "created_at" : "2016-09-09 00:26:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774041240396496897",
  "text" : "RT @scrowder: Have found a new journal entry of young Mrs. Crowder. Even at 5 she was \"afraid of the Cosby\". Racist or astute? More at 8PME\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LwC",
        "indices" : [ 127, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774012228064321536",
    "text" : "Have found a new journal entry of young Mrs. Crowder. Even at 5 she was \"afraid of the Cosby\". Racist or astute? More at 8PMET #LwC",
    "id" : 774012228064321536,
    "created_at" : "2016-09-08 22:31:10 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 774041240396496897,
  "created_at" : "2016-09-09 00:26:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/40ALx70VAS",
      "expanded_url" : "https:\/\/twitter.com\/ieatit_shemoanz\/status\/773986544923312128",
      "display_url" : "twitter.com\/ieatit_shemoan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "774041015313436672",
  "text" : "RT @YazmineJimenez: I mean damn  https:\/\/t.co\/40ALx70VAS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/40ALx70VAS",
        "expanded_url" : "https:\/\/twitter.com\/ieatit_shemoanz\/status\/773986544923312128",
        "display_url" : "twitter.com\/ieatit_shemoan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774040502542880768",
    "text" : "I mean damn  https:\/\/t.co\/40ALx70VAS",
    "id" : 774040502542880768,
    "created_at" : "2016-09-09 00:23:31 +0000",
    "user" : {
      "name" : "Y\uD83D\uDC8B",
      "screen_name" : "yazzycakes_",
      "protected" : false,
      "id_str" : "156407508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980309757096611840\/poe3KhRq_normal.jpg",
      "id" : 156407508,
      "verified" : false
    }
  },
  "id" : 774041015313436672,
  "created_at" : "2016-09-09 00:25:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774040951211843584",
  "text" : "RT @BarbaraCorcoran: You can't study to be an entrepreneur. You just have to jump.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774030929979289600",
    "text" : "You can't study to be an entrepreneur. You just have to jump.",
    "id" : 774030929979289600,
    "created_at" : "2016-09-08 23:45:29 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 774040951211843584,
  "created_at" : "2016-09-09 00:25:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774040942194098176",
  "text" : "RT @KassyDillon: \"Never Date A Feminist\" is trending... Probably why I'm single...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774030450033582080",
    "text" : "\"Never Date A Feminist\" is trending... Probably why I'm single...",
    "id" : 774030450033582080,
    "created_at" : "2016-09-08 23:43:34 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 774040942194098176,
  "created_at" : "2016-09-09 00:25:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC Nightly News with Lester Holt",
      "screen_name" : "NBCNightlyNews",
      "indices" : [ 3, 18 ],
      "id_str" : "8839632",
      "id" : 8839632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774040898996953088",
  "text" : "RT @NBCNightlyNews: JUST IN: NASA launches rocket with spacecraft headed for 7-year mission to visit an asteroid and bring back samples. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NBCNightlyNews\/status\/774021364885839873\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/udk85qbkSf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr3gQSOUEAEAUWx.jpg",
        "id_str" : "774021281351995393",
        "id" : 774021281351995393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr3gQSOUEAEAUWx.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/udk85qbkSf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "774021364885839873",
    "text" : "JUST IN: NASA launches rocket with spacecraft headed for 7-year mission to visit an asteroid and bring back samples. https:\/\/t.co\/udk85qbkSf",
    "id" : 774021364885839873,
    "created_at" : "2016-09-08 23:07:28 +0000",
    "user" : {
      "name" : "NBC Nightly News with Lester Holt",
      "screen_name" : "NBCNightlyNews",
      "protected" : false,
      "id_str" : "8839632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878311894418849792\/jlk1k6MF_normal.jpg",
      "id" : 8839632,
      "verified" : true
    }
  },
  "id" : 774040898996953088,
  "created_at" : "2016-09-09 00:25:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "indices" : [ 3, 19 ],
      "id_str" : "14550939",
      "id" : 14550939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Love",
      "indices" : [ 130, 135 ]
    }, {
      "text" : "RT",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Ti0qGSnokk",
      "expanded_url" : "http:\/\/bit.ly\/2cd3dqD",
      "display_url" : "bit.ly\/2cd3dqD"
    } ]
  },
  "geo" : { },
  "id_str" : "773985571463016448",
  "text" : "RT @lawrence_author: Beloved Town Dog Has Made 4-Mile Trek Every Day For 10 Years Just to Visit Neighbors https:\/\/t.co\/Ti0qGSnokk #Love #RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Love",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "RT",
        "indices" : [ 115, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/Ti0qGSnokk",
        "expanded_url" : "http:\/\/bit.ly\/2cd3dqD",
        "display_url" : "bit.ly\/2cd3dqD"
      } ]
    },
    "geo" : { },
    "id_str" : "773951819764539392",
    "text" : "Beloved Town Dog Has Made 4-Mile Trek Every Day For 10 Years Just to Visit Neighbors https:\/\/t.co\/Ti0qGSnokk #Love #RT",
    "id" : 773951819764539392,
    "created_at" : "2016-09-08 18:31:07 +0000",
    "user" : {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "protected" : false,
      "id_str" : "14550939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878189064393863168\/0QsTPIPw_normal.jpg",
      "id" : 14550939,
      "verified" : false
    }
  },
  "id" : 773985571463016448,
  "created_at" : "2016-09-08 20:45:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773985469491126272",
  "text" : "Realism strikes you down sometimes",
  "id" : 773985469491126272,
  "created_at" : "2016-09-08 20:44:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773952440236437505",
  "text" : "RT @lorenridinger: \u201CPeople want to change everything and, at the same time want it all to remain the same.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773929119398584321",
    "text" : "\u201CPeople want to change everything and, at the same time want it all to remain the same.\u201D",
    "id" : 773929119398584321,
    "created_at" : "2016-09-08 17:00:55 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 773952440236437505,
  "created_at" : "2016-09-08 18:33:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773952279900741633",
  "text" : "RT @RandiAthenas: Did you know: Dolphins are so smart that within captivity, they can train people to stand on the very edge of the pool an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773864477343174656",
    "text" : "Did you know: Dolphins are so smart that within captivity, they can train people to stand on the very edge of the pool and throw them fish",
    "id" : 773864477343174656,
    "created_at" : "2016-09-08 12:44:03 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 773952279900741633,
  "created_at" : "2016-09-08 18:32:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Secret Teachings",
      "screen_name" : "TheSecretForYou",
      "indices" : [ 3, 19 ],
      "id_str" : "3411516553",
      "id" : 3411516553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773952203702824960",
  "text" : "RT @TheSecretForYou: It's crazy how you can go months or years without talking to someone but they still cross your mind everyday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773874026557177857",
    "text" : "It's crazy how you can go months or years without talking to someone but they still cross your mind everyday.",
    "id" : 773874026557177857,
    "created_at" : "2016-09-08 13:22:00 +0000",
    "user" : {
      "name" : "The Secret Teachings",
      "screen_name" : "TheSecretForYou",
      "protected" : false,
      "id_str" : "3411516553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658539678086238208\/dKPetjOu_normal.png",
      "id" : 3411516553,
      "verified" : false
    }
  },
  "id" : 773952203702824960,
  "created_at" : "2016-09-08 18:32:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heritage on the Hill",
      "screen_name" : "HeritageOTH",
      "indices" : [ 3, 15 ],
      "id_str" : "3911294003",
      "id" : 3911294003
    }, {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 18, 29 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICANN",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773952169154375680",
  "text" : "RT @HeritageOTH: .@SenTedCruz is on the Senate floor expressing skepticism about the #ICANN transition. We write about it here. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Ted Cruz",
        "screen_name" : "SenTedCruz",
        "indices" : [ 1, 12 ],
        "id_str" : "1074480192",
        "id" : 1074480192
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICANN",
        "indices" : [ 68, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/bUDPqsgnzZ",
        "expanded_url" : "http:\/\/bit.ly\/2bJji99",
        "display_url" : "bit.ly\/2bJji99"
      } ]
    },
    "geo" : { },
    "id_str" : "773904332848713728",
    "text" : ".@SenTedCruz is on the Senate floor expressing skepticism about the #ICANN transition. We write about it here. https:\/\/t.co\/bUDPqsgnzZ",
    "id" : 773904332848713728,
    "created_at" : "2016-09-08 15:22:26 +0000",
    "user" : {
      "name" : "Heritage on the Hill",
      "screen_name" : "HeritageOTH",
      "protected" : false,
      "id_str" : "3911294003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664082996488613888\/Yy2Hjz8__normal.jpg",
      "id" : 3911294003,
      "verified" : false
    }
  },
  "id" : 773952169154375680,
  "created_at" : "2016-09-08 18:32:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Svitek",
      "screen_name" : "PatrickSvitek",
      "indices" : [ 3, 17 ],
      "id_str" : "280664117",
      "id" : 280664117
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 20, 28 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773952042649944065",
  "text" : "RT @PatrickSvitek: .@TedCruz: \"Who in their right mind looks at the internet and says, 'You know what we need? We need Russia to have more\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 1, 9 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773906289541865473",
    "text" : ".@TedCruz: \"Who in their right mind looks at the internet and says, 'You know what we need? We need Russia to have more control over this.'\"",
    "id" : 773906289541865473,
    "created_at" : "2016-09-08 15:30:12 +0000",
    "user" : {
      "name" : "Patrick Svitek",
      "screen_name" : "PatrickSvitek",
      "protected" : false,
      "id_str" : "280664117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932693477066006528\/lq_pZ5Gz_normal.jpg",
      "id" : 280664117,
      "verified" : true
    }
  },
  "id" : 773952042649944065,
  "created_at" : "2016-09-08 18:32:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    }, {
      "name" : "YALiberty",
      "screen_name" : "YALiberty",
      "indices" : [ 81, 91 ],
      "id_str" : "17642330",
      "id" : 17642330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773951985787740160",
  "text" : "RT @KassyDillon: I am happy to announce that I have accepted the position as the @YALiberty state chair for Massachusetts!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YALiberty",
        "screen_name" : "YALiberty",
        "indices" : [ 64, 74 ],
        "id_str" : "17642330",
        "id" : 17642330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773906607143063552",
    "text" : "I am happy to announce that I have accepted the position as the @YALiberty state chair for Massachusetts!",
    "id" : 773906607143063552,
    "created_at" : "2016-09-08 15:31:28 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 773951985787740160,
  "created_at" : "2016-09-08 18:31:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773951961473441792",
  "text" : "RT @tedcruz: Americans deserve an explanation of why the Obama Admin is using their money not to fight terrorism, but to fund it: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/br7mAT5Gwo",
        "expanded_url" : "http:\/\/freebeacon.com\/national-security\/state-department-cant-say-us-cash-payments-iran-havent-funded-terrorism\/",
        "display_url" : "freebeacon.com\/national-secur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "773896580222955520",
    "text" : "Americans deserve an explanation of why the Obama Admin is using their money not to fight terrorism, but to fund it: https:\/\/t.co\/br7mAT5Gwo",
    "id" : 773896580222955520,
    "created_at" : "2016-09-08 14:51:37 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 773951961473441792,
  "created_at" : "2016-09-08 18:31:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773951939071643648",
  "text" : "RT @KassyDillon: Hillary is better off announcing her health problems &amp; going to a panel of doctors to get evaluated if she has nothing to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773867691962662912",
    "text" : "Hillary is better off announcing her health problems &amp; going to a panel of doctors to get evaluated if she has nothing to hide. But she does",
    "id" : 773867691962662912,
    "created_at" : "2016-09-08 12:56:50 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 773951939071643648,
  "created_at" : "2016-09-08 18:31:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773951916262981632",
  "text" : "RT @BarbaraCorcoran: You're always smarter under fire than you are standing on the outside assessing a situation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773866135359983616",
    "text" : "You're always smarter under fire than you are standing on the outside assessing a situation.",
    "id" : 773866135359983616,
    "created_at" : "2016-09-08 12:50:39 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 773951916262981632,
  "created_at" : "2016-09-08 18:31:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773951880464572416",
  "text" : "Not realizing who you are, they may never call back",
  "id" : 773951880464572416,
  "created_at" : "2016-09-08 18:31:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarTrek50",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773859941295808512",
  "text" : "RT @davidschneider: In an office? Celebrate #StarTrek50 by pretending you're under attack and all falling to one side then another. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/davidschneider\/status\/773789739652673536\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/hY2kjfjOrf",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cr0Nkr5XgAE7PKE.jpg",
        "id_str" : "773789634887385089",
        "id" : 773789634887385089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cr0Nkr5XgAE7PKE.jpg",
        "sizes" : [ {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hY2kjfjOrf"
      } ],
      "hashtags" : [ {
        "text" : "StarTrek50",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773789739652673536",
    "text" : "In an office? Celebrate #StarTrek50 by pretending you're under attack and all falling to one side then another. https:\/\/t.co\/hY2kjfjOrf",
    "id" : 773789739652673536,
    "created_at" : "2016-09-08 07:47:04 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/937241076116672513\/E31_C1th_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 773859941295808512,
  "created_at" : "2016-09-08 12:26:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Davis",
      "screen_name" : "thealexdavis",
      "indices" : [ 3, 16 ],
      "id_str" : "6905342",
      "id" : 6905342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773859837893611521",
  "text" : "RT @thealexdavis: \"2 of 3 candidates don't know enough to be president.\" Mika: \"Well you have one final option.\"  Others: \"but emails and w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "morningjoe",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773859497953624065",
    "text" : "\"2 of 3 candidates don't know enough to be president.\" Mika: \"Well you have one final option.\"  Others: \"but emails and woman!\" #morningjoe",
    "id" : 773859497953624065,
    "created_at" : "2016-09-08 12:24:16 +0000",
    "user" : {
      "name" : "Alex Davis",
      "screen_name" : "thealexdavis",
      "protected" : false,
      "id_str" : "6905342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980562772219039744\/GnApTGJs_normal.jpg",
      "id" : 6905342,
      "verified" : false
    }
  },
  "id" : 773859837893611521,
  "created_at" : "2016-09-08 12:25:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Bob",
      "screen_name" : "BSil1",
      "indices" : [ 3, 9 ],
      "id_str" : "843888793",
      "id" : 843888793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MorningJoe",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773859720281092096",
  "text" : "RT @BSil1: Wow, Libertarian candidate Gary Johnson just eliminated himself for President. \"What is Aleppo?\"\n#MorningJoe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MorningJoe",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773859535442305024",
    "text" : "Wow, Libertarian candidate Gary Johnson just eliminated himself for President. \"What is Aleppo?\"\n#MorningJoe",
    "id" : 773859535442305024,
    "created_at" : "2016-09-08 12:24:25 +0000",
    "user" : {
      "name" : "Big Bob",
      "screen_name" : "BSil1",
      "protected" : false,
      "id_str" : "843888793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728339165276995586\/wbDGM-UR_normal.jpg",
      "id" : 843888793,
      "verified" : false
    }
  },
  "id" : 773859720281092096,
  "created_at" : "2016-09-08 12:25:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Pryor",
      "screen_name" : "r_d_p11",
      "indices" : [ 3, 11 ],
      "id_str" : "2497991713",
      "id" : 2497991713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773859543986106368",
  "text" : "RT @r_d_p11: Dear Lord, Thank You!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772821390286290945",
    "text" : "Dear Lord, Thank You!",
    "id" : 772821390286290945,
    "created_at" : "2016-09-05 15:39:12 +0000",
    "user" : {
      "name" : "Rodney Pryor",
      "screen_name" : "r_d_p11",
      "protected" : false,
      "id_str" : "2497991713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956903508242026502\/ff8q_opl_normal.jpg",
      "id" : 2497991713,
      "verified" : false
    }
  },
  "id" : 773859543986106368,
  "created_at" : "2016-09-08 12:24:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Kay",
      "screen_name" : "2kayzero",
      "indices" : [ 3, 12 ],
      "id_str" : "371286107",
      "id" : 371286107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blessed",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Uj1rGQqUc6",
      "expanded_url" : "https:\/\/twitter.com\/goldengrizzlies\/status\/670375006061203456",
      "display_url" : "twitter.com\/goldengrizzlie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773859448108544004",
  "text" : "RT @2kayzero: #Blessed Man Glory to God, my coaches and teammates I've had over the years, Thank you! https:\/\/t.co\/Uj1rGQqUc6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blessed",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Uj1rGQqUc6",
        "expanded_url" : "https:\/\/twitter.com\/goldengrizzlies\/status\/670375006061203456",
        "display_url" : "twitter.com\/goldengrizzlie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670407518368075776",
    "text" : "#Blessed Man Glory to God, my coaches and teammates I've had over the years, Thank you! https:\/\/t.co\/Uj1rGQqUc6",
    "id" : 670407518368075776,
    "created_at" : "2015-11-28 01:03:02 +0000",
    "user" : {
      "name" : "Uncle Kay",
      "screen_name" : "2kayzero",
      "protected" : false,
      "id_str" : "371286107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/988856638558830600\/Htc9u9Hc_normal.jpg",
      "id" : 371286107,
      "verified" : true
    }
  },
  "id" : 773859448108544004,
  "created_at" : "2016-09-08 12:24:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ecTiGVyWX8",
      "expanded_url" : "http:\/\/fb.me\/4KyZa9yN6",
      "display_url" : "fb.me\/4KyZa9yN6"
    } ]
  },
  "geo" : { },
  "id_str" : "773858949279969281",
  "text" : "RT @EmperorDarroux: This huge skyline made out of biscuits has a really moving cause https:\/\/t.co\/ecTiGVyWX8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/ecTiGVyWX8",
        "expanded_url" : "http:\/\/fb.me\/4KyZa9yN6",
        "display_url" : "fb.me\/4KyZa9yN6"
      } ]
    },
    "geo" : { },
    "id_str" : "773858695872516097",
    "text" : "This huge skyline made out of biscuits has a really moving cause https:\/\/t.co\/ecTiGVyWX8",
    "id" : 773858695872516097,
    "created_at" : "2016-09-08 12:21:05 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 773858949279969281,
  "created_at" : "2016-09-08 12:22:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773858867415486464",
  "text" : "RT @HamzeiAnalytics: Good Morning to Traders from Sunny Cape Naples, FL.... Temp is 75F, exp range is 91\/77",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773858501399425024",
    "text" : "Good Morning to Traders from Sunny Cape Naples, FL.... Temp is 75F, exp range is 91\/77",
    "id" : 773858501399425024,
    "created_at" : "2016-09-08 12:20:18 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 773858867415486464,
  "created_at" : "2016-09-08 12:21:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773781470162853888",
  "geo" : { },
  "id_str" : "773858579631726592",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo The guy at the back, lol \uD83D\uDE02",
  "id" : 773858579631726592,
  "in_reply_to_status_id" : 773781470162853888,
  "created_at" : "2016-09-08 12:20:37 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/773780321930211328\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/HRzp1hqIev",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr0FGfoWYAAJPMC.jpg",
      "id_str" : "773780320105684992",
      "id" : 773780320105684992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr0FGfoWYAAJPMC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/HRzp1hqIev"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773858449897689093",
  "text" : "RT @rockindigo: Car Industry Explained https:\/\/t.co\/HRzp1hqIev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/773780321930211328\/photo\/1",
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/HRzp1hqIev",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cr0FGfoWYAAJPMC.jpg",
        "id_str" : "773780320105684992",
        "id" : 773780320105684992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cr0FGfoWYAAJPMC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/HRzp1hqIev"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773780321930211328",
    "text" : "Car Industry Explained https:\/\/t.co\/HRzp1hqIev",
    "id" : 773780321930211328,
    "created_at" : "2016-09-08 07:09:39 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 773858449897689093,
  "created_at" : "2016-09-08 12:20:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/773766446929285120\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/3jhmEqOIqL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crz4e12WgAEWWDr.jpg",
      "id_str" : "773766444735692801",
      "id" : 773766444735692801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crz4e12WgAEWWDr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 700
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/3jhmEqOIqL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773858266640224256",
  "text" : "RT @rockindigo: I have created a monster! https:\/\/t.co\/3jhmEqOIqL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/773766446929285120\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/3jhmEqOIqL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Crz4e12WgAEWWDr.jpg",
        "id_str" : "773766444735692801",
        "id" : 773766444735692801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crz4e12WgAEWWDr.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 700
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/3jhmEqOIqL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773766446929285120",
    "text" : "I have created a monster! https:\/\/t.co\/3jhmEqOIqL",
    "id" : 773766446929285120,
    "created_at" : "2016-09-08 06:14:31 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 773858266640224256,
  "created_at" : "2016-09-08 12:19:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Dandie",
      "screen_name" : "realjimdandie",
      "indices" : [ 3, 17 ],
      "id_str" : "738888059232518147",
      "id" : 738888059232518147
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 19, 28 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773858105998372864",
  "text" : "RT @realjimdandie: @scrowder Note to self: Never ever return to Pakistan. Ever!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "773732601714573312",
    "geo" : { },
    "id_str" : "773824750015553536",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder Note to self: Never ever return to Pakistan. Ever!",
    "id" : 773824750015553536,
    "in_reply_to_status_id" : 773732601714573312,
    "created_at" : "2016-09-08 10:06:12 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Jim Dandie",
      "screen_name" : "realjimdandie",
      "protected" : false,
      "id_str" : "738888059232518147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830796732782960642\/8kqEK2tV_normal.jpg",
      "id" : 738888059232518147,
      "verified" : false
    }
  },
  "id" : 773858105998372864,
  "created_at" : "2016-09-08 12:18:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carey Casey",
      "screen_name" : "dcbdbc770706431",
      "indices" : [ 3, 19 ],
      "id_str" : "2672693279",
      "id" : 2672693279
    }, {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 21, 30 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773858061702266880",
  "text" : "RT @dcbdbc770706431: @scrowder Religion of peace?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Crowder",
        "screen_name" : "scrowder",
        "indices" : [ 0, 9 ],
        "id_str" : "19091173",
        "id" : 19091173
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "773732601714573312",
    "geo" : { },
    "id_str" : "773816806226132993",
    "in_reply_to_user_id" : 19091173,
    "text" : "@scrowder Religion of peace?",
    "id" : 773816806226132993,
    "in_reply_to_status_id" : 773732601714573312,
    "created_at" : "2016-09-08 09:34:38 +0000",
    "in_reply_to_screen_name" : "scrowder",
    "in_reply_to_user_id_str" : "19091173",
    "user" : {
      "name" : "Carey Casey",
      "screen_name" : "dcbdbc770706431",
      "protected" : false,
      "id_str" : "2672693279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485119296998084608\/tubIJXGO_normal.jpeg",
      "id" : 2672693279,
      "verified" : false
    }
  },
  "id" : 773858061702266880,
  "created_at" : "2016-09-08 12:18:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773857831275618309",
  "text" : "There are two things certain in life: Death and Taxes ~ My stats professor",
  "id" : 773857831275618309,
  "created_at" : "2016-09-08 12:17:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773857696743362560",
  "text" : "If you know what you are doing, you aren't a college student",
  "id" : 773857696743362560,
  "created_at" : "2016-09-08 12:17:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SLS Hotels",
      "screen_name" : "SLSHotels",
      "indices" : [ 3, 13 ],
      "id_str" : "501495434",
      "id" : 501495434
    }, {
      "name" : "HydeBeach",
      "screen_name" : "HydeBeach",
      "indices" : [ 80, 90 ],
      "id_str" : "389056110",
      "id" : 389056110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HungerActionMonth",
      "indices" : [ 29, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/FNPpDnciWV",
      "expanded_url" : "http:\/\/bit.ly\/CelebTaste",
      "display_url" : "bit.ly\/CelebTaste"
    } ]
  },
  "geo" : { },
  "id_str" : "773695116145889280",
  "text" : "RT @SLSHotels: In support of #HungerActionMonth join us as we TASTE celeb style @HydeBeach  on Sept 22 https:\/\/t.co\/FNPpDnciWV https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HydeBeach",
        "screen_name" : "HydeBeach",
        "indices" : [ 65, 75 ],
        "id_str" : "389056110",
        "id" : 389056110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SLSHotels\/status\/773640773153746944\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/9Xg1prOQzH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CryGLoiWEAInsL1.jpg",
        "id_str" : "773640770419036162",
        "id" : 773640770419036162,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryGLoiWEAInsL1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/9Xg1prOQzH"
      } ],
      "hashtags" : [ {
        "text" : "HungerActionMonth",
        "indices" : [ 14, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/FNPpDnciWV",
        "expanded_url" : "http:\/\/bit.ly\/CelebTaste",
        "display_url" : "bit.ly\/CelebTaste"
      } ]
    },
    "geo" : { },
    "id_str" : "773640773153746944",
    "text" : "In support of #HungerActionMonth join us as we TASTE celeb style @HydeBeach  on Sept 22 https:\/\/t.co\/FNPpDnciWV https:\/\/t.co\/9Xg1prOQzH",
    "id" : 773640773153746944,
    "created_at" : "2016-09-07 21:55:08 +0000",
    "user" : {
      "name" : "SLS Hotels",
      "screen_name" : "SLSHotels",
      "protected" : false,
      "id_str" : "501495434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2386296226\/yrzhcci7ct2kr66oiwe7_normal.jpeg",
      "id" : 501495434,
      "verified" : true
    }
  },
  "id" : 773695116145889280,
  "created_at" : "2016-09-08 01:31:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/773615646311649282\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/JZZXqgpT1P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrxvVBlWEAADtzq.jpg",
      "id_str" : "773615642993889280",
      "id" : 773615642993889280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrxvVBlWEAADtzq.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/JZZXqgpT1P"
    } ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 44, 55 ]
    }, {
      "text" : "AirPods",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773694927947468800",
  "text" : "RT @scrowder: Anti-Capitalist SJWs love the #AppleEvent and new #AirPods https:\/\/t.co\/JZZXqgpT1P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/773615646311649282\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/JZZXqgpT1P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrxvVBlWEAADtzq.jpg",
        "id_str" : "773615642993889280",
        "id" : 773615642993889280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrxvVBlWEAADtzq.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/JZZXqgpT1P"
      } ],
      "hashtags" : [ {
        "text" : "AppleEvent",
        "indices" : [ 30, 41 ]
      }, {
        "text" : "AirPods",
        "indices" : [ 50, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773615646311649282",
    "text" : "Anti-Capitalist SJWs love the #AppleEvent and new #AirPods https:\/\/t.co\/JZZXqgpT1P",
    "id" : 773615646311649282,
    "created_at" : "2016-09-07 20:15:17 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 773694927947468800,
  "created_at" : "2016-09-08 01:30:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 0, 10 ],
      "id_str" : "618294231",
      "id" : 618294231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773694361842311168",
  "geo" : { },
  "id_str" : "773694484823408641",
  "in_reply_to_user_id" : 618294231,
  "text" : "@_grammar_ Dang I got caught",
  "id" : 773694484823408641,
  "in_reply_to_status_id" : 773694361842311168,
  "created_at" : "2016-09-08 01:28:34 +0000",
  "in_reply_to_screen_name" : "_grammar_",
  "in_reply_to_user_id_str" : "618294231",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 3, 13 ],
      "id_str" : "618294231",
      "id" : 618294231
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 29, 41 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773694415130943488",
  "text" : "RT @_grammar_: It looks like @gamer456148 should have used \u201Cgiveth but [then] he may\u201D instead. \u2018Than\u2019 isn't the adverb \u2018then\u2019.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/Your_Grammar\" rel=\"nofollow\"\u003Emagical magic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 14, 26 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "773693268731191296",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ -27.470168089718, 62.343075958126 ]
    },
    "id_str" : "773694361842311168",
    "in_reply_to_user_id" : 210979938,
    "text" : "It looks like @gamer456148 should have used \u201Cgiveth but [then] he may\u201D instead. \u2018Than\u2019 isn't the adverb \u2018then\u2019.",
    "id" : 773694361842311168,
    "in_reply_to_status_id" : 773693268731191296,
    "created_at" : "2016-09-08 01:28:05 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "protected" : false,
      "id_str" : "618294231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785169027169521664\/j5rftldn_normal.png",
      "id" : 618294231,
      "verified" : false
    }
  },
  "id" : 773694415130943488,
  "created_at" : "2016-09-08 01:28:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dreana",
      "screen_name" : "dreanabeana",
      "indices" : [ 3, 15 ],
      "id_str" : "17261287",
      "id" : 17261287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773694319542669317",
  "text" : "RT @dreanabeana: From looking at it, I like Tanorria and David's dish better. Brandy and Shaun dish look like it's missing something #maste\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "masterchef",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773693220362616832",
    "text" : "From looking at it, I like Tanorria and David's dish better. Brandy and Shaun dish look like it's missing something #masterchef",
    "id" : 773693220362616832,
    "created_at" : "2016-09-08 01:23:32 +0000",
    "user" : {
      "name" : "Dreana",
      "screen_name" : "dreanabeana",
      "protected" : false,
      "id_str" : "17261287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/506884779535384576\/2RcjOv1C_normal.png",
      "id" : 17261287,
      "verified" : false
    }
  },
  "id" : 773694319542669317,
  "created_at" : "2016-09-08 01:27:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "masterchef",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773694267243933696",
  "text" : "RT @maryangeorgeblg: I love Tanorria's response to David \uD83D\uDE02 #masterchef",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "masterchef",
        "indices" : [ 38, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773693325236854784",
    "text" : "I love Tanorria's response to David \uD83D\uDE02 #masterchef",
    "id" : 773693325236854784,
    "created_at" : "2016-09-08 01:23:57 +0000",
    "user" : {
      "name" : "TJ",
      "screen_name" : "teejtweetsthngs",
      "protected" : false,
      "id_str" : "2772136940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/990035574177312768\/W6KuIeCv_normal.jpg",
      "id" : 2772136940,
      "verified" : false
    }
  },
  "id" : 773694267243933696,
  "created_at" : "2016-09-08 01:27:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MasterChef",
      "screen_name" : "MASTERCHEFonFOX",
      "indices" : [ 3, 19 ],
      "id_str" : "156733266",
      "id" : 156733266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MASTERCHEFonFOX\/status\/773685032984522752\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/kRw1WJgfsG",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CryuMKnVUAAZ7iR.jpg",
      "id_str" : "773684760031875072",
      "id" : 773684760031875072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CryuMKnVUAAZ7iR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/kRw1WJgfsG"
    } ],
    "hashtags" : [ {
      "text" : "MasterChef",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773694226106228736",
  "text" : "RT @MASTERCHEFonFOX: This is probably the best compliment a #MasterChef contestant could receive. \uD83D\uDE02 https:\/\/t.co\/kRw1WJgfsG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MASTERCHEFonFOX\/status\/773685032984522752\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/kRw1WJgfsG",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CryuMKnVUAAZ7iR.jpg",
        "id_str" : "773684760031875072",
        "id" : 773684760031875072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CryuMKnVUAAZ7iR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/kRw1WJgfsG"
      } ],
      "hashtags" : [ {
        "text" : "MasterChef",
        "indices" : [ 39, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773685032984522752",
    "text" : "This is probably the best compliment a #MasterChef contestant could receive. \uD83D\uDE02 https:\/\/t.co\/kRw1WJgfsG",
    "id" : 773685032984522752,
    "created_at" : "2016-09-08 00:51:00 +0000",
    "user" : {
      "name" : "MasterChef",
      "screen_name" : "MASTERCHEFonFOX",
      "protected" : false,
      "id_str" : "156733266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862763443975208960\/SV-aY-FZ_normal.jpg",
      "id" : 156733266,
      "verified" : true
    }
  },
  "id" : 773694226106228736,
  "created_at" : "2016-09-08 01:27:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Montfort",
      "screen_name" : "ashleytay_VH1",
      "indices" : [ 0, 14 ],
      "id_str" : "284190454",
      "id" : 284190454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773693354781442048",
  "geo" : { },
  "id_str" : "773694135421112320",
  "in_reply_to_user_id" : 284190454,
  "text" : "@ashleytay_VH1 Shows get weirder and weirder these days",
  "id" : 773694135421112320,
  "in_reply_to_status_id" : 773693354781442048,
  "created_at" : "2016-09-08 01:27:11 +0000",
  "in_reply_to_screen_name" : "ashleytay_VH1",
  "in_reply_to_user_id_str" : "284190454",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JRhyan",
      "screen_name" : "JRhyan",
      "indices" : [ 3, 10 ],
      "id_str" : "81279745",
      "id" : 81279745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773693830247821313",
  "text" : "RT @JRhyan: Goodbye to all the accidentally dropped iPhone saved by the headphones' cord.\n#AppleEvent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AppleEvent",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773647302506319873",
    "text" : "Goodbye to all the accidentally dropped iPhone saved by the headphones' cord.\n#AppleEvent",
    "id" : 773647302506319873,
    "created_at" : "2016-09-07 22:21:05 +0000",
    "user" : {
      "name" : "JRhyan",
      "screen_name" : "JRhyan",
      "protected" : false,
      "id_str" : "81279745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776068374937776128\/ycOEAYpz_normal.jpg",
      "id" : 81279745,
      "verified" : false
    }
  },
  "id" : 773693830247821313,
  "created_at" : "2016-09-08 01:25:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MOSES",
      "screen_name" : "zacknoorzay",
      "indices" : [ 3, 15 ],
      "id_str" : "256837645",
      "id" : 256837645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773693750312706048",
  "text" : "RT @zacknoorzay: Our cell phones will never again be saved by the headphones wire when we drop them #AppleEvent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AppleEvent",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773655883028967424",
    "text" : "Our cell phones will never again be saved by the headphones wire when we drop them #AppleEvent",
    "id" : 773655883028967424,
    "created_at" : "2016-09-07 22:55:11 +0000",
    "user" : {
      "name" : "MOSES",
      "screen_name" : "zacknoorzay",
      "protected" : false,
      "id_str" : "256837645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/986127391972995072\/I81WUXJ4_normal.jpg",
      "id" : 256837645,
      "verified" : false
    }
  },
  "id" : 773693750312706048,
  "created_at" : "2016-09-08 01:25:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CaptionedPhotos\/status\/773659862177837056\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pmM8xmxcG0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CryXiomWcAAUffy.jpg",
      "id_str" : "773659857270501376",
      "id" : 773659857270501376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryXiomWcAAUffy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 568
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/pmM8xmxcG0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/CaptionedPhotos\/status\/773659862177837056\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pmM8xmxcG0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CryXionWcAQ9z_R.jpg",
      "id_str" : "773659857274695684",
      "id" : 773659857274695684,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryXionWcAQ9z_R.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 1436
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 1436
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/pmM8xmxcG0"
    } ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773693700673200128",
  "text" : "RT @CaptionedPhotos: History repeats itself. #AppleEvent https:\/\/t.co\/pmM8xmxcG0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CaptionedPhotos\/status\/773659862177837056\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/pmM8xmxcG0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CryXiomWcAAUffy.jpg",
        "id_str" : "773659857270501376",
        "id" : 773659857270501376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryXiomWcAAUffy.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 542,
          "resize" : "fit",
          "w" : 568
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/pmM8xmxcG0"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CaptionedPhotos\/status\/773659862177837056\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/pmM8xmxcG0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CryXionWcAQ9z_R.jpg",
        "id_str" : "773659857274695684",
        "id" : 773659857274695684,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryXionWcAQ9z_R.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 783,
          "resize" : "fit",
          "w" : 1436
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 783,
          "resize" : "fit",
          "w" : 1436
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/pmM8xmxcG0"
      } ],
      "hashtags" : [ {
        "text" : "AppleEvent",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773659862177837056",
    "text" : "History repeats itself. #AppleEvent https:\/\/t.co\/pmM8xmxcG0",
    "id" : 773659862177837056,
    "created_at" : "2016-09-07 23:10:59 +0000",
    "user" : {
      "name" : "Carter Woolley",
      "screen_name" : "carterwoolley",
      "protected" : false,
      "id_str" : "3141603934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/973690635055194114\/72juwxyb_normal.jpg",
      "id" : 3141603934,
      "verified" : false
    }
  },
  "id" : 773693700673200128,
  "created_at" : "2016-09-08 01:25:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 3, 12 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppleEvent",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eO0jvI9fQa",
      "expanded_url" : "http:\/\/bloom.bg\/2c9R9Xc",
      "display_url" : "bloom.bg\/2c9R9Xc"
    } ]
  },
  "geo" : { },
  "id_str" : "773693502672691200",
  "text" : "RT @business: Nintendo shares soar 18% in Tokyo after Super Mario game for iPhone announced https:\/\/t.co\/eO0jvI9fQa #AppleEvent https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/business\/status\/773680628713807872\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Xw1TBQIcOw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CryqbjCWAAAwY7w.jpg",
        "id_str" : "773680626239143936",
        "id" : 773680626239143936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CryqbjCWAAAwY7w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 743,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2200
        }, {
          "h" : 1268,
          "resize" : "fit",
          "w" : 2048
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Xw1TBQIcOw"
      } ],
      "hashtags" : [ {
        "text" : "AppleEvent",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/eO0jvI9fQa",
        "expanded_url" : "http:\/\/bloom.bg\/2c9R9Xc",
        "display_url" : "bloom.bg\/2c9R9Xc"
      } ]
    },
    "geo" : { },
    "id_str" : "773680628713807872",
    "text" : "Nintendo shares soar 18% in Tokyo after Super Mario game for iPhone announced https:\/\/t.co\/eO0jvI9fQa #AppleEvent https:\/\/t.co\/Xw1TBQIcOw",
    "id" : 773680628713807872,
    "created_at" : "2016-09-08 00:33:30 +0000",
    "user" : {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "protected" : false,
      "id_str" : "34713362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991818020233404416\/alrBF_dr_normal.jpg",
      "id" : 34713362,
      "verified" : true
    }
  },
  "id" : 773693502672691200,
  "created_at" : "2016-09-08 01:24:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rennifer",
      "screen_name" : "joysusschrist",
      "indices" : [ 3, 17 ],
      "id_str" : "925603914589671424",
      "id" : 925603914589671424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone7",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773693468661067777",
  "text" : "RT @joysusschrist: BREAKING: All #iPhone7 phones will come with a pre-downloaded digital copy of Red Velvet's \"Russian Roulette\" for all us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iPhone7",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "AppleEvent",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773692523743064064",
    "text" : "BREAKING: All #iPhone7 phones will come with a pre-downloaded digital copy of Red Velvet's \"Russian Roulette\" for all users. #AppleEvent",
    "id" : 773692523743064064,
    "created_at" : "2016-09-08 01:20:46 +0000",
    "user" : {
      "name" : "ren",
      "screen_name" : "joyreneoutsold",
      "protected" : false,
      "id_str" : "2697181368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/990598801483153408\/UKCkWpfT_normal.jpg",
      "id" : 2697181368,
      "verified" : false
    }
  },
  "id" : 773693468661067777,
  "created_at" : "2016-09-08 01:24:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773693268731191296",
  "text" : "Sometimes the lord giveth but than he may taketh",
  "id" : 773693268731191296,
  "created_at" : "2016-09-08 01:23:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773631503867740166",
  "text" : "RT @_iMake_Hitz: Stop lurking &amp; say hi \uD83D\uDE43",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771226137561210880",
    "text" : "Stop lurking &amp; say hi \uD83D\uDE43",
    "id" : 771226137561210880,
    "created_at" : "2016-09-01 06:00:14 +0000",
    "user" : {
      "name" : "\uD83D\uDC51",
      "screen_name" : "iamjaysonking",
      "protected" : false,
      "id_str" : "2316343619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992602865393979398\/LMDw2ehx_normal.jpg",
      "id" : 2316343619,
      "verified" : false
    }
  },
  "id" : 773631503867740166,
  "created_at" : "2016-09-07 21:18:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PlayStation",
      "screen_name" : "PlayStation",
      "indices" : [ 0, 12 ],
      "id_str" : "10671602",
      "id" : 10671602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773623908704452608",
  "geo" : { },
  "id_str" : "773631346975600640",
  "in_reply_to_user_id" : 10671602,
  "text" : "@PlayStation Will it spy on you is the question?",
  "id" : 773631346975600640,
  "in_reply_to_status_id" : 773623908704452608,
  "created_at" : "2016-09-07 21:17:41 +0000",
  "in_reply_to_screen_name" : "PlayStation",
  "in_reply_to_user_id_str" : "10671602",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PlayStation",
      "screen_name" : "PlayStation",
      "indices" : [ 3, 15 ],
      "id_str" : "10671602",
      "id" : 10671602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/G5Q9h1fSAd",
      "expanded_url" : "http:\/\/play.st\/2cl9Z1j",
      "display_url" : "play.st\/2cl9Z1j"
    } ]
  },
  "geo" : { },
  "id_str" : "773631284526649344",
  "text" : "RT @PlayStation: All the news from PlayStation Meeting, featuring PS4 Pro and the slimmer, lighter PS4: https:\/\/t.co\/G5Q9h1fSAd https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PlayStation\/status\/773623908704452608\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/uHdwGo1Jo1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Crx212DVYAA3P7y.jpg",
        "id_str" : "773623903415525376",
        "id" : 773623903415525376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crx212DVYAA3P7y.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/uHdwGo1Jo1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/G5Q9h1fSAd",
        "expanded_url" : "http:\/\/play.st\/2cl9Z1j",
        "display_url" : "play.st\/2cl9Z1j"
      } ]
    },
    "geo" : { },
    "id_str" : "773623908704452608",
    "text" : "All the news from PlayStation Meeting, featuring PS4 Pro and the slimmer, lighter PS4: https:\/\/t.co\/G5Q9h1fSAd https:\/\/t.co\/uHdwGo1Jo1",
    "id" : 773623908704452608,
    "created_at" : "2016-09-07 20:48:07 +0000",
    "user" : {
      "name" : "PlayStation",
      "screen_name" : "PlayStation",
      "protected" : false,
      "id_str" : "10671602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/960710744219074560\/6RD7pVGF_normal.jpg",
      "id" : 10671602,
      "verified" : true
    }
  },
  "id" : 773631284526649344,
  "created_at" : "2016-09-07 21:17:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Finnegan",
      "screen_name" : "shotbyfinnegan",
      "indices" : [ 3, 18 ],
      "id_str" : "131773262",
      "id" : 131773262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773631213517017089",
  "text" : "RT @shotbyfinnegan: I'm lukewarm on PS4 Pro. The console feels like an incremental upgrade and I remain unconvinced by 4K\/HDR gaming. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ZsAeIOpgio",
        "expanded_url" : "https:\/\/twitter.com\/PlayStation\/status\/773608956375756800",
        "display_url" : "twitter.com\/PlayStation\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "773630406172094464",
    "text" : "I'm lukewarm on PS4 Pro. The console feels like an incremental upgrade and I remain unconvinced by 4K\/HDR gaming. https:\/\/t.co\/ZsAeIOpgio",
    "id" : 773630406172094464,
    "created_at" : "2016-09-07 21:13:56 +0000",
    "user" : {
      "name" : "Sean Finnegan",
      "screen_name" : "shotbyfinnegan",
      "protected" : false,
      "id_str" : "131773262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/898448818357772289\/BHJf47xa_normal.jpg",
      "id" : 131773262,
      "verified" : true
    }
  },
  "id" : 773631213517017089,
  "created_at" : "2016-09-07 21:17:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PlayStation",
      "screen_name" : "PlayStation",
      "indices" : [ 3, 15 ],
      "id_str" : "10671602",
      "id" : 10671602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773631133586165761",
  "text" : "RT @PlayStation: PS4 Pro launches November 10 for $399.99 USD.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "773607954130010112",
    "text" : "PS4 Pro launches November 10 for $399.99 USD.",
    "id" : 773607954130010112,
    "created_at" : "2016-09-07 19:44:43 +0000",
    "user" : {
      "name" : "PlayStation",
      "screen_name" : "PlayStation",
      "protected" : false,
      "id_str" : "10671602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/960710744219074560\/6RD7pVGF_normal.jpg",
      "id" : 10671602,
      "verified" : true
    }
  },
  "id" : 773631133586165761,
  "created_at" : "2016-09-07 21:16:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773631007979401216",
  "text" : "So many girls hugged me and started being very nice to me. Something is very wrong here.",
  "id" : 773631007979401216,
  "created_at" : "2016-09-07 21:16:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowToConfuseAMillennial",
      "indices" : [ 44, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772848300709912576",
  "text" : "RT @KassyDillon: The millenials raging over #HowToConfuseAMillennial are the perfect example of my coddled generation that can't take jokes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HowToConfuseAMillennial",
        "indices" : [ 27, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772543207272046592",
    "text" : "The millenials raging over #HowToConfuseAMillennial are the perfect example of my coddled generation that can't take jokes. Trigger warning?",
    "id" : 772543207272046592,
    "created_at" : "2016-09-04 21:13:48 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983314487976644608\/WDINsoqS_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 772848300709912576,
  "created_at" : "2016-09-05 17:26:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772848235119452161",
  "text" : "RT @BarbaraCorcoran: Obstacles are there to kill your spirit and take your confidence. You need to spot them coming through the door and sh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "772510896245633024",
    "text" : "Obstacles are there to kill your spirit and take your confidence. You need to spot them coming through the door and shoot them on the spot.",
    "id" : 772510896245633024,
    "created_at" : "2016-09-04 19:05:24 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 772848235119452161,
  "created_at" : "2016-09-05 17:25:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/772848146934181888\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/fb5erz8Etu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Crm1Sb5VIAAxvM3.jpg",
      "id_str" : "772848139401240576",
      "id" : 772848139401240576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Crm1Sb5VIAAxvM3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fb5erz8Etu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772848146934181888",
  "text" : "Gold star dining, 3.75\/5 stars, not bad, but not great https:\/\/t.co\/fb5erz8Etu",
  "id" : 772848146934181888,
  "created_at" : "2016-09-05 17:25:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fPb7stdLu5",
      "expanded_url" : "https:\/\/hdtk.co\/JF6gf",
      "display_url" : "hdtk.co\/JF6gf"
    } ]
  },
  "geo" : { },
  "id_str" : "771369682590892032",
  "text" : "Celebrate our Bi-Annual Anniversary Join us October 26, 2016 08:00 PST - 18:00 PST Sign-up today 30\/60 minute slots https:\/\/t.co\/fPb7stdLu5",
  "id" : 771369682590892032,
  "created_at" : "2016-09-01 15:30:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]