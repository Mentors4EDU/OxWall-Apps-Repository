Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UWM News",
      "screen_name" : "UWMNews",
      "indices" : [ 3, 11 ],
      "id_str" : "36375651",
      "id" : 36375651
    }, {
      "name" : "UW-Milwaukee",
      "screen_name" : "UWM",
      "indices" : [ 14, 18 ],
      "id_str" : "15680246",
      "id" : 15680246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/sLrdMk9bc1",
      "expanded_url" : "http:\/\/go.uwm.edu\/1gynnMa",
      "display_url" : "go.uwm.edu\/1gynnMa"
    } ]
  },
  "geo" : { },
  "id_str" : "429443957420871680",
  "text" : "RT @UWMNews: .@UWM to host high school robotics competition this weekend: http:\/\/t.co\/sLrdMk9bc1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UW-Milwaukee",
        "screen_name" : "UWM",
        "indices" : [ 1, 5 ],
        "id_str" : "15680246",
        "id" : 15680246
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/sLrdMk9bc1",
        "expanded_url" : "http:\/\/go.uwm.edu\/1gynnMa",
        "display_url" : "go.uwm.edu\/1gynnMa"
      } ]
    },
    "geo" : { },
    "id_str" : "429362968665399296",
    "text" : ".@UWM to host high school robotics competition this weekend: http:\/\/t.co\/sLrdMk9bc1",
    "id" : 429362968665399296,
    "created_at" : "2014-01-31 21:18:03 +0000",
    "user" : {
      "name" : "UWM News",
      "screen_name" : "UWMNews",
      "protected" : false,
      "id_str" : "36375651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2514974872\/qzyp3npj8rbs8q6ycrx8_normal.jpeg",
      "id" : 36375651,
      "verified" : false
    }
  },
  "id" : 429443957420871680,
  "created_at" : "2014-02-01 02:39:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429443875493515265",
  "text" : "RT @adafruit: Community Corner: Sensory Fiction, Heated Bird Bath, Modular 3D Printed Robotics, Drinkmotizer, and other Deli... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kxOtX1ax7j",
        "expanded_url" : "http:\/\/adafru.it\/b94715",
        "display_url" : "adafru.it\/b94715"
      } ]
    },
    "geo" : { },
    "id_str" : "429409909193453568",
    "text" : "Community Corner: Sensory Fiction, Heated Bird Bath, Modular 3D Printed Robotics, Drinkmotizer, and other Deli... http:\/\/t.co\/kxOtX1ax7j",
    "id" : 429409909193453568,
    "created_at" : "2014-02-01 00:24:35 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 429443875493515265,
  "created_at" : "2014-02-01 02:39:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newscenter 11",
      "screen_name" : "KTVF11",
      "indices" : [ 3, 10 ],
      "id_str" : "119871665",
      "id" : 119871665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/V5FsNzIeDC",
      "expanded_url" : "http:\/\/fb.me\/3bGm2AgiI",
      "display_url" : "fb.me\/3bGm2AgiI"
    } ]
  },
  "geo" : { },
  "id_str" : "429443820548145153",
  "text" : "RT @KTVF11: Barnette Magnet School's Lego Robotics Competition http:\/\/t.co\/V5FsNzIeDC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/V5FsNzIeDC",
        "expanded_url" : "http:\/\/fb.me\/3bGm2AgiI",
        "display_url" : "fb.me\/3bGm2AgiI"
      } ]
    },
    "geo" : { },
    "id_str" : "429417296386605057",
    "text" : "Barnette Magnet School's Lego Robotics Competition http:\/\/t.co\/V5FsNzIeDC",
    "id" : 429417296386605057,
    "created_at" : "2014-02-01 00:53:56 +0000",
    "user" : {
      "name" : "Newscenter 11",
      "screen_name" : "KTVF11",
      "protected" : false,
      "id_str" : "119871665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1165660278\/ktvf-default_normal.jpg",
      "id" : 119871665,
      "verified" : false
    }
  },
  "id" : 429443820548145153,
  "created_at" : "2014-02-01 02:39:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429443414284042240",
  "text" : "Had Turkish delight with hazlenut and it tasted good, also have you tried Damla candy? LOL",
  "id" : 429443414284042240,
  "created_at" : "2014-02-01 02:37:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/6HYuqd4mCS",
      "expanded_url" : "http:\/\/sdrv.ms\/1jQYyLY",
      "display_url" : "sdrv.ms\/1jQYyLY"
    } ]
  },
  "geo" : { },
  "id_str" : "429159113814470656",
  "text" : "Baggle burger supreme http:\/\/t.co\/6HYuqd4mCS",
  "id" : 429159113814470656,
  "created_at" : "2014-01-31 07:48:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429015702175899648",
  "text" : "Eggs with basterma taste good, lol",
  "id" : 429015702175899648,
  "created_at" : "2014-01-30 22:18:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/RmnXLuLqCn",
      "expanded_url" : "http:\/\/sdrv.ms\/1hT0Ar0",
      "display_url" : "sdrv.ms\/1hT0Ar0"
    } ]
  },
  "geo" : { },
  "id_str" : "428987565819957248",
  "text" : "Legends of Zelda sucks, won't even review it, lol :P http:\/\/t.co\/RmnXLuLqCn",
  "id" : 428987565819957248,
  "created_at" : "2014-01-30 20:26:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/5rtw1yIEzO",
      "expanded_url" : "http:\/\/sdrv.ms\/1ehMr6X",
      "display_url" : "sdrv.ms\/1ehMr6X"
    } ]
  },
  "geo" : { },
  "id_str" : "428736869845966849",
  "text" : "Portable AC for winter. http:\/\/t.co\/5rtw1yIEzO",
  "id" : 428736869845966849,
  "created_at" : "2014-01-30 03:50:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427912750011260929",
  "text" : "Pickled Shankleesh taste good but can you guess what similar cheese taste way better?",
  "id" : 427912750011260929,
  "created_at" : "2014-01-27 21:15:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427909357511380992",
  "text" : "I got skills...... :) ;) lol",
  "id" : 427909357511380992,
  "created_at" : "2014-01-27 21:01:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427151363102216192",
  "text" : "The golden bakery in Dearborn has great eats. 4.4\/5 stars....had stuff yesterday",
  "id" : 427151363102216192,
  "created_at" : "2014-01-25 18:49:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SB.TV",
      "screen_name" : "SBTVonline",
      "indices" : [ 3, 14 ],
      "id_str" : "19559692",
      "id" : 19559692
    }, {
      "name" : "ODDKA UK",
      "screen_name" : "ODDKAUK",
      "indices" : [ 30, 38 ],
      "id_str" : "1947670525",
      "id" : 1947670525
    }, {
      "name" : "J2K",
      "screen_name" : "j2klive",
      "indices" : [ 74, 82 ],
      "id_str" : "16519420",
      "id" : 16519420
    }, {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 87, 99 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OddInventionChallenge",
      "indices" : [ 39, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/LSgz5QHOiE",
      "expanded_url" : "http:\/\/bit.ly\/OddInventionChallenge",
      "display_url" : "bit.ly\/OddInventionCh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426408713612587009",
  "text" : "RT @sbtvonline: Check out the @ODDKAUK #OddInventionChallenge series with @j2klive and @colin_furze &gt; http:\/\/t.co\/LSgz5QHOiE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ODDKA UK",
        "screen_name" : "ODDKAUK",
        "indices" : [ 14, 22 ],
        "id_str" : "1947670525",
        "id" : 1947670525
      }, {
        "name" : "J2K",
        "screen_name" : "j2klive",
        "indices" : [ 58, 66 ],
        "id_str" : "16519420",
        "id" : 16519420
      }, {
        "name" : "colin furze",
        "screen_name" : "colin_furze",
        "indices" : [ 71, 83 ],
        "id_str" : "321610630",
        "id" : 321610630
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OddInventionChallenge",
        "indices" : [ 23, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/LSgz5QHOiE",
        "expanded_url" : "http:\/\/bit.ly\/OddInventionChallenge",
        "display_url" : "bit.ly\/OddInventionCh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422805613509234688",
    "text" : "Check out the @ODDKAUK #OddInventionChallenge series with @j2klive and @colin_furze &gt; http:\/\/t.co\/LSgz5QHOiE",
    "id" : 422805613509234688,
    "created_at" : "2014-01-13 19:01:28 +0000",
    "user" : {
      "name" : "SB.TV",
      "screen_name" : "SBTVonline",
      "protected" : false,
      "id_str" : "19559692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/971411537729597441\/kmyp2zZf_normal.jpg",
      "id" : 19559692,
      "verified" : true
    }
  },
  "id" : 426408713612587009,
  "created_at" : "2014-01-23 17:38:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 0, 12 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426408532963889152",
  "in_reply_to_user_id" : 321610630,
  "text" : "@colin_furze I am an industrial designer with some cool ideas.",
  "id" : 426408532963889152,
  "created_at" : "2014-01-23 17:38:11 +0000",
  "in_reply_to_screen_name" : "colin_furze",
  "in_reply_to_user_id_str" : "321610630",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManvFoodNation",
      "screen_name" : "ManvFoodNation",
      "indices" : [ 0, 15 ],
      "id_str" : "18005769",
      "id" : 18005769
    }, {
      "name" : "Epic Meal Time",
      "screen_name" : "EpicMealTime",
      "indices" : [ 45, 58 ],
      "id_str" : "209169572",
      "id" : 209169572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426407478633316352",
  "in_reply_to_user_id" : 18005769,
  "text" : "@ManvFoodNation Oh man, you should challange @EpicMealTime, that would be awesome",
  "id" : 426407478633316352,
  "created_at" : "2014-01-23 17:33:59 +0000",
  "in_reply_to_screen_name" : "ManvFoodNation",
  "in_reply_to_user_id_str" : "18005769",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/426406721515298818\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/5Ew6q2FIye",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bermp24CIAE9gwa.jpg",
      "id_str" : "426406721519493121",
      "id" : 426406721519493121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bermp24CIAE9gwa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 588
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/5Ew6q2FIye"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426406721515298818",
  "text" : "Lol Tommy http:\/\/t.co\/5Ew6q2FIye",
  "id" : 426406721515298818,
  "created_at" : "2014-01-23 17:30:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ManvsFood",
      "screen_name" : "ukmanvsfood",
      "indices" : [ 0, 12 ],
      "id_str" : "569496355",
      "id" : 569496355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426106929652301824",
  "in_reply_to_user_id" : 569496355,
  "text" : "@ukmanvsfood How do you not get heartburn or do you? LOL",
  "id" : 426106929652301824,
  "created_at" : "2014-01-22 21:39:43 +0000",
  "in_reply_to_screen_name" : "ukmanvsfood",
  "in_reply_to_user_id_str" : "569496355",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Runners",
      "screen_name" : "RunningQuotes",
      "indices" : [ 3, 17 ],
      "id_str" : "204817833",
      "id" : 204817833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426106487291645953",
  "text" : "RT @RunningQuotes: \u201CMental will is a muscle that needs exercise, just like the muscles of the body.\u201D -Lynn Jennings",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425734223740141568",
    "text" : "\u201CMental will is a muscle that needs exercise, just like the muscles of the body.\u201D -Lynn Jennings",
    "id" : 425734223740141568,
    "created_at" : "2014-01-21 20:58:43 +0000",
    "user" : {
      "name" : "Real Runners",
      "screen_name" : "RunningQuotes",
      "protected" : false,
      "id_str" : "204817833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1148077286\/image_normal.jpg",
      "id" : 204817833,
      "verified" : false
    }
  },
  "id" : 426106487291645953,
  "created_at" : "2014-01-22 21:37:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bishop Raphaeil",
      "screen_name" : "bishopraphaeil",
      "indices" : [ 3, 18 ],
      "id_str" : "315476193",
      "id" : 315476193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426106317174882304",
  "text" : "RT @bishopraphaeil: \u0639\u064A\u062F \u0639\u0631\u0633 \u0642\u0627\u0646\u0627 \u0627\u0644\u062C\u0644\u064A\u0644\n\u0646\u0642\u0631\u0623 \u064A\u0648\u062D\u0646\u0627 \u0662\n\u0647\u0630\u0650\u0647\u0650 \u0628\u062F\u0627\u064A\u064E\u0629\u064F \u0627\u0644\u0622\u064A\u0627\u062A\u0650 \u0641\u0639\u064E\u0644\u0647\u0627 \u064A\u064E\u0633\u0648\u0639\u064F \u0641\u064A \u0642\u0627\u0646\u0627 \u0627\u0644\u062C\u0644\u064A\u0644\u0650\u060C \u0648\u0623\u0638\u0647\u064E\u0631\u064E \u0645\u064E\u062C\u062F\u064E\u0647\u064F\u060C \u0641\u0622\u0645\u064E\u0646\u064E \u0628\u0647\u0650 \u062A\u0644\u0627\u0645\u064A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425499847371010048",
    "text" : "\u0639\u064A\u062F \u0639\u0631\u0633 \u0642\u0627\u0646\u0627 \u0627\u0644\u062C\u0644\u064A\u0644\n\u0646\u0642\u0631\u0623 \u064A\u0648\u062D\u0646\u0627 \u0662\n\u0647\u0630\u0650\u0647\u0650 \u0628\u062F\u0627\u064A\u064E\u0629\u064F \u0627\u0644\u0622\u064A\u0627\u062A\u0650 \u0641\u0639\u064E\u0644\u0647\u0627 \u064A\u064E\u0633\u0648\u0639\u064F \u0641\u064A \u0642\u0627\u0646\u0627 \u0627\u0644\u062C\u0644\u064A\u0644\u0650\u060C \u0648\u0623\u0638\u0647\u064E\u0631\u064E \u0645\u064E\u062C\u062F\u064E\u0647\u064F\u060C \u0641\u0622\u0645\u064E\u0646\u064E \u0628\u0647\u0650 \u062A\u0644\u0627\u0645\u064A\u0630\u064F\u0647\u064F. (\u064A\u0648\u062D\u064E\u0646\u0627 2 :11)",
    "id" : 425499847371010048,
    "created_at" : "2014-01-21 05:27:23 +0000",
    "user" : {
      "name" : "Bishop Raphaeil",
      "screen_name" : "bishopraphaeil",
      "protected" : false,
      "id_str" : "315476193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2667439275\/344e8048377aac5948e931d283b723e4_normal.jpeg",
      "id" : 315476193,
      "verified" : false
    }
  },
  "id" : 426106317174882304,
  "created_at" : "2014-01-22 21:37:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 0, 12 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426106132369649664",
  "in_reply_to_user_id" : 41634520,
  "text" : "@seanhannity How did you get so wise in politics?",
  "id" : 426106132369649664,
  "created_at" : "2014-01-22 21:36:33 +0000",
  "in_reply_to_screen_name" : "seanhannity",
  "in_reply_to_user_id_str" : "41634520",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 14, 26 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/W1uzaYqCDR",
      "expanded_url" : "http:\/\/tinyurl.com\/lrpodl9",
      "display_url" : "tinyurl.com\/lrpodl9"
    } ]
  },
  "geo" : { },
  "id_str" : "426105871286816768",
  "text" : "RT @FoxNews: .@SeanHannity's political bombshell: 'I'd consider running for office in Texas or Florida' - http:\/\/t.co\/W1uzaYqCDR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Hannity",
        "screen_name" : "seanhannity",
        "indices" : [ 1, 13 ],
        "id_str" : "41634520",
        "id" : 41634520
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/W1uzaYqCDR",
        "expanded_url" : "http:\/\/tinyurl.com\/lrpodl9",
        "display_url" : "tinyurl.com\/lrpodl9"
      } ]
    },
    "geo" : { },
    "id_str" : "426087623405207552",
    "text" : ".@SeanHannity's political bombshell: 'I'd consider running for office in Texas or Florida' - http:\/\/t.co\/W1uzaYqCDR",
    "id" : 426087623405207552,
    "created_at" : "2014-01-22 20:23:00 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 426105871286816768,
  "created_at" : "2014-01-22 21:35:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 3, 16 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426105665585545216",
  "text" : "RT @PopeTawadros: Pro 1:15 \"My son, do not walk in the way with them (the evil)\" God has given you reason to distinguish evil and not walk \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299126763898945536",
    "text" : "Pro 1:15 \"My son, do not walk in the way with them (the evil)\" God has given you reason to distinguish evil and not walk in or experience it",
    "id" : 299126763898945536,
    "created_at" : "2013-02-06 12:05:52 +0000",
    "user" : {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "protected" : false,
      "id_str" : "927421452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2902297704\/8f9ea422fc9315fac166213148ab47c6_normal.jpeg",
      "id" : 927421452,
      "verified" : true
    }
  },
  "id" : 426105665585545216,
  "created_at" : "2014-01-22 21:34:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 0, 11 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426105522853408768",
  "in_reply_to_user_id" : 9989862,
  "text" : "@jacksfilms Your Vsauce Parody was so funny",
  "id" : 426105522853408768,
  "created_at" : "2014-01-22 21:34:07 +0000",
  "in_reply_to_screen_name" : "jacksfilms",
  "in_reply_to_user_id_str" : "9989862",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u01BF\u0AEF\u03C9\u10EB\u027F\u0AEF\u01BF\u027F\u0AEF",
      "screen_name" : "pewdiepie",
      "indices" : [ 0, 10 ],
      "id_str" : "39538010",
      "id" : 39538010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426105304627949568",
  "in_reply_to_user_id" : 39538010,
  "text" : "@pewdiepie You use to much profanity in your videos, you should have an explicit video and a clean video or you should at least try sensor",
  "id" : 426105304627949568,
  "created_at" : "2014-01-22 21:33:15 +0000",
  "in_reply_to_screen_name" : "pewdiepie",
  "in_reply_to_user_id_str" : "39538010",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/dHjJnnKqWR",
      "expanded_url" : "http:\/\/news.msn.com\/offbeat\/video?videoid=1f517b5e-da82-487f-1b53-0726816925ec#tscptmt",
      "display_url" : "news.msn.com\/offbeat\/video?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426104733925769216",
  "text" : "Robotocists go ape over Charlie http:\/\/t.co\/dHjJnnKqWR",
  "id" : 426104733925769216,
  "created_at" : "2014-01-22 21:30:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Turner",
      "screen_name" : "TobyTurner",
      "indices" : [ 3, 14 ],
      "id_str" : "6054912",
      "id" : 6054912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425359787711135745",
  "text" : "RT @TobyTurner: Who is in Lake Tahoe? Show us around, quick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424474900871393280",
    "text" : "Who is in Lake Tahoe? Show us around, quick.",
    "id" : 424474900871393280,
    "created_at" : "2014-01-18 09:34:37 +0000",
    "user" : {
      "name" : "Toby Turner",
      "screen_name" : "TobyTurner",
      "protected" : false,
      "id_str" : "6054912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946295861599903744\/SE-d2NUH_normal.jpg",
      "id" : 6054912,
      "verified" : true
    }
  },
  "id" : 425359787711135745,
  "created_at" : "2014-01-20 20:10:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425359484194947072",
  "text" : "RT @ijustine: Thinking about _____________",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424936200336461824",
    "text" : "Thinking about _____________",
    "id" : 424936200336461824,
    "created_at" : "2014-01-19 16:07:39 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 425359484194947072,
  "created_at" : "2014-01-20 20:09:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Int_Marketing",
      "screen_name" : "intmarketingtip",
      "indices" : [ 3, 19 ],
      "id_str" : "168872039",
      "id" : 168872039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/2DWcZ8Cubr",
      "expanded_url" : "http:\/\/bit.ly\/1jomraY",
      "display_url" : "bit.ly\/1jomraY"
    } ]
  },
  "geo" : { },
  "id_str" : "425359085429882880",
  "text" : "RT @intmarketingtip: The Essential Elements of an Excellent Blog Post [INFOGRAPHIC] http:\/\/t.co\/2DWcZ8Cubr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/2DWcZ8Cubr",
        "expanded_url" : "http:\/\/bit.ly\/1jomraY",
        "display_url" : "bit.ly\/1jomraY"
      } ]
    },
    "geo" : { },
    "id_str" : "425314288757010432",
    "text" : "The Essential Elements of an Excellent Blog Post [INFOGRAPHIC] http:\/\/t.co\/2DWcZ8Cubr",
    "id" : 425314288757010432,
    "created_at" : "2014-01-20 17:10:03 +0000",
    "user" : {
      "name" : "Int_Marketing",
      "screen_name" : "intmarketingtip",
      "protected" : false,
      "id_str" : "168872039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1082372791\/CRAZY_TWITTER_BIRDY__bigger_normal.jpg",
      "id" : 168872039,
      "verified" : false
    }
  },
  "id" : 425359085429882880,
  "created_at" : "2014-01-20 20:08:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/NKQaAwMjPf",
      "expanded_url" : "http:\/\/pietechsolution.com\/croudfunding\/?download=the-best-tech-company-in-the-world",
      "display_url" : "pietechsolution.com\/croudfunding\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425358427359940608",
  "text" : "Check out The Best Tech Company in the World on Crowdfunding! http:\/\/t.co\/NKQaAwMjPf",
  "id" : 425358427359940608,
  "created_at" : "2014-01-20 20:05:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 3, 17 ],
      "id_str" : "80979832",
      "id" : 80979832
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424947169339011072",
  "text" : "RT @CopticOrphans: @gamer456148 thanks Andrew! God bless.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "423954129128415232",
    "geo" : { },
    "id_str" : "424751820259725312",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 thanks Andrew! God bless.",
    "id" : 424751820259725312,
    "in_reply_to_status_id" : 423954129128415232,
    "created_at" : "2014-01-19 03:55:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "protected" : false,
      "id_str" : "80979832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684002515818524672\/YpWFR6e9_normal.jpg",
      "id" : 80979832,
      "verified" : false
    }
  },
  "id" : 424947169339011072,
  "created_at" : "2014-01-19 16:51:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coptic Orphans",
      "screen_name" : "CopticOrphans",
      "indices" : [ 0, 14 ],
      "id_str" : "80979832",
      "id" : 80979832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423954129128415232",
  "in_reply_to_user_id" : 80979832,
  "text" : "@CopticOrphans I love the Coptic Orphans Program, the Bless USA Program, and the Coptic Church",
  "id" : 423954129128415232,
  "created_at" : "2014-01-16 23:05:15 +0000",
  "in_reply_to_screen_name" : "CopticOrphans",
  "in_reply_to_user_id_str" : "80979832",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    }, {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 92, 104 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/fGLmyJOTRo",
      "expanded_url" : "http:\/\/bit.ly\/1aPxmIs",
      "display_url" : "bit.ly\/1aPxmIs"
    } ]
  },
  "geo" : { },
  "id_str" : "423953937080008704",
  "text" : "RT @copticworld: Egypt\u2019s Christian minority rally behind charter http:\/\/t.co\/fGLmyJOTRo via @CopticWorld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CopticWorld",
        "screen_name" : "copticworld",
        "indices" : [ 75, 87 ],
        "id_str" : "136923775",
        "id" : 136923775
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/fGLmyJOTRo",
        "expanded_url" : "http:\/\/bit.ly\/1aPxmIs",
        "display_url" : "bit.ly\/1aPxmIs"
      } ]
    },
    "geo" : { },
    "id_str" : "423817899313082368",
    "text" : "Egypt\u2019s Christian minority rally behind charter http:\/\/t.co\/fGLmyJOTRo via @CopticWorld",
    "id" : 423817899313082368,
    "created_at" : "2014-01-16 14:03:56 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 423953937080008704,
  "created_at" : "2014-01-16 23:04:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "young gunner",
      "screen_name" : "machinegunkelly",
      "indices" : [ 0, 16 ],
      "id_str" : "17861062",
      "id" : 17861062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423950486845136896",
  "geo" : { },
  "id_str" : "423953734511517696",
  "in_reply_to_user_id" : 17861062,
  "text" : "@machinegunkelly Nope",
  "id" : 423953734511517696,
  "in_reply_to_status_id" : 423950486845136896,
  "created_at" : "2014-01-16 23:03:41 +0000",
  "in_reply_to_screen_name" : "machinegunkelly",
  "in_reply_to_user_id_str" : "17861062",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrash GAMES",
      "screen_name" : "AdrashGAMES",
      "indices" : [ 0, 12 ],
      "id_str" : "1410102265",
      "id" : 1410102265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423953505875804160",
  "in_reply_to_user_id" : 1410102265,
  "text" : "@AdrashGAMES What happened to your awesome channel",
  "id" : 423953505875804160,
  "created_at" : "2014-01-16 23:02:47 +0000",
  "in_reply_to_screen_name" : "AdrashGAMES",
  "in_reply_to_user_id_str" : "1410102265",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/q8GXhAnbtH",
      "expanded_url" : "http:\/\/start.new.toshiba.com\/news\/read\/category\/Us%20News\/article\/ap-rare_sword_dug_up_by_construction_crew_i-ap#.UtiOat_qBzQ.twitter",
      "display_url" : "start.new.toshiba.com\/news\/read\/cate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423952993344434176",
  "text" : "Rare sword dug up by construction crew in Arkansas - Toshiba: http:\/\/t.co\/q8GXhAnbtH",
  "id" : 423952993344434176,
  "created_at" : "2014-01-16 23:00:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 0, 11 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422151602426757120",
  "in_reply_to_user_id" : 9989862,
  "text" : "@jacksfilms ask Jack, lol",
  "id" : 422151602426757120,
  "created_at" : "2014-01-11 23:42:39 +0000",
  "in_reply_to_screen_name" : "jacksfilms",
  "in_reply_to_user_id_str" : "9989862",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422076815025258496",
  "text" : "Had a Dimitris Ham Onion Ring Burger 3.75\/5 stars",
  "id" : 422076815025258496,
  "created_at" : "2014-01-11 18:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u01BF\u0AEF\u03C9\u10EB\u027F\u0AEF\u01BF\u027F\u0AEF",
      "screen_name" : "pewdiepie",
      "indices" : [ 0, 10 ],
      "id_str" : "39538010",
      "id" : 39538010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421845795067805697",
  "in_reply_to_user_id" : 39538010,
  "text" : "@pewdiepie Can you play an indie game I developed, please reply, it is pretty awesome dude, lol, it's a skateboarding arcade style game",
  "id" : 421845795067805697,
  "created_at" : "2014-01-11 03:27:29 +0000",
  "in_reply_to_screen_name" : "pewdiepie",
  "in_reply_to_user_id_str" : "39538010",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 3, 16 ],
      "id_str" : "580255414",
      "id" : 580255414
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421820230684270592",
  "text" : "RT @RockerCyborg: @gamer456148 Yeah I'll have to do that eventually.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "421527874596646913",
    "geo" : { },
    "id_str" : "421819312559509504",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Yeah I'll have to do that eventually.",
    "id" : 421819312559509504,
    "in_reply_to_status_id" : 421527874596646913,
    "created_at" : "2014-01-11 01:42:15 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "protected" : false,
      "id_str" : "580255414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818919561214865408\/NAHNRL36_normal.jpg",
      "id" : 580255414,
      "verified" : false
    }
  },
  "id" : 421820230684270592,
  "created_at" : "2014-01-11 01:45:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 3, 16 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421815990872453121",
  "text" : "RT @PopeTawadros: Pro 21:3 \u201CTo do righteousness and justice is more acceptable to the Lord than sacrifice,\u201C including acts of truth, justic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305285925204787201",
    "text" : "Pro 21:3 \u201CTo do righteousness and justice is more acceptable to the Lord than sacrifice,\u201C including acts of truth, justice, mercy and love.",
    "id" : 305285925204787201,
    "created_at" : "2013-02-23 12:00:11 +0000",
    "user" : {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "protected" : false,
      "id_str" : "927421452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2902297704\/8f9ea422fc9315fac166213148ab47c6_normal.jpeg",
      "id" : 927421452,
      "verified" : true
    }
  },
  "id" : 421815990872453121,
  "created_at" : "2014-01-11 01:29:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 0, 13 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421815842121084928",
  "in_reply_to_user_id" : 927421452,
  "text" : "@PopeTawadros You haven't been on twitter for a while, we all miss you!!!",
  "id" : 421815842121084928,
  "created_at" : "2014-01-11 01:28:28 +0000",
  "in_reply_to_screen_name" : "PopeTawadros",
  "in_reply_to_user_id_str" : "927421452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill O'Reilly",
      "screen_name" : "oreillyfactor",
      "indices" : [ 3, 17 ],
      "id_str" : "50113613",
      "id" : 50113613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HTQ1OxRKAK",
      "expanded_url" : "http:\/\/bit.ly\/1lYRTMm",
      "display_url" : "bit.ly\/1lYRTMm"
    } ]
  },
  "geo" : { },
  "id_str" : "421815415481073664",
  "text" : "RT @oreillyfactor: FACTOR CLIP: Big trouble for Chris Christie -- Watch: http:\/\/t.co\/HTQ1OxRKAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/HTQ1OxRKAK",
        "expanded_url" : "http:\/\/bit.ly\/1lYRTMm",
        "display_url" : "bit.ly\/1lYRTMm"
      } ]
    },
    "geo" : { },
    "id_str" : "421684110999171072",
    "text" : "FACTOR CLIP: Big trouble for Chris Christie -- Watch: http:\/\/t.co\/HTQ1OxRKAK",
    "id" : 421684110999171072,
    "created_at" : "2014-01-10 16:45:01 +0000",
    "user" : {
      "name" : "Bill O'Reilly",
      "screen_name" : "BillOReilly",
      "protected" : false,
      "id_str" : "23970102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610858014560661504\/z9muezEN_normal.jpg",
      "id" : 23970102,
      "verified" : true
    }
  },
  "id" : 421815415481073664,
  "created_at" : "2014-01-11 01:26:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "FLIR",
      "screen_name" : "flir",
      "indices" : [ 24, 29 ],
      "id_str" : "413212483",
      "id" : 413212483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CES2014",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/R1MUisPAaF",
      "expanded_url" : "http:\/\/instagram.com\/p\/i7O-fRgaFM\/",
      "display_url" : "instagram.com\/p\/i7O-fRgaFM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "421815151915200512",
  "text" : "RT @ijustine: Found the @flir thermal case today! It\u2019s pretty sweet.. Can\u2019t wait to get one #CES2014 http:\/\/t.co\/R1MUisPAaF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FLIR",
        "screen_name" : "flir",
        "indices" : [ 10, 15 ],
        "id_str" : "413212483",
        "id" : 413212483
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CES2014",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/R1MUisPAaF",
        "expanded_url" : "http:\/\/instagram.com\/p\/i7O-fRgaFM\/",
        "display_url" : "instagram.com\/p\/i7O-fRgaFM\/"
      } ]
    },
    "geo" : { },
    "id_str" : "421054165842817025",
    "text" : "Found the @flir thermal case today! It\u2019s pretty sweet.. Can\u2019t wait to get one #CES2014 http:\/\/t.co\/R1MUisPAaF",
    "id" : 421054165842817025,
    "created_at" : "2014-01-08 23:01:50 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 421815151915200512,
  "created_at" : "2014-01-11 01:25:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421814965540896768",
  "text" : "Man my tweets are getting boring",
  "id" : 421814965540896768,
  "created_at" : "2014-01-11 01:24:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421814911652462592",
  "text" : "Had two fish, lol",
  "id" : 421814911652462592,
  "created_at" : "2014-01-11 01:24:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arby's",
      "screen_name" : "Arbys",
      "indices" : [ 3, 9 ],
      "id_str" : "155544257",
      "id" : 155544257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Arbys\/status\/419145216918966272\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Wlx0wV6Uuj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdEaWqRCUAA_kmk.jpg",
      "id_str" : "419145216927354880",
      "id" : 419145216927354880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdEaWqRCUAA_kmk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1287,
        "resize" : "fit",
        "w" : 1287
      }, {
        "h" : 1287,
        "resize" : "fit",
        "w" : 1287
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Wlx0wV6Uuj"
    } ],
    "hashtags" : [ {
      "text" : "ReelBigFillet",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421814787430162432",
  "text" : "RT @Arbys: Good news! The Arby's Fish Sandwich has returned to our menu for a limited time. #ReelBigFillet http:\/\/t.co\/Wlx0wV6Uuj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Arbys\/status\/419145216918966272\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Wlx0wV6Uuj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdEaWqRCUAA_kmk.jpg",
        "id_str" : "419145216927354880",
        "id" : 419145216927354880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdEaWqRCUAA_kmk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1287,
          "resize" : "fit",
          "w" : 1287
        }, {
          "h" : 1287,
          "resize" : "fit",
          "w" : 1287
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Wlx0wV6Uuj"
      } ],
      "hashtags" : [ {
        "text" : "ReelBigFillet",
        "indices" : [ 81, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419145216918966272",
    "text" : "Good news! The Arby's Fish Sandwich has returned to our menu for a limited time. #ReelBigFillet http:\/\/t.co\/Wlx0wV6Uuj",
    "id" : 419145216918966272,
    "created_at" : "2014-01-03 16:36:21 +0000",
    "user" : {
      "name" : "Arby's",
      "screen_name" : "Arbys",
      "protected" : false,
      "id_str" : "155544257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843137577632894976\/ouFRMmvf_normal.jpg",
      "id" : 155544257,
      "verified" : true
    }
  },
  "id" : 421814787430162432,
  "created_at" : "2014-01-11 01:24:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421530547416879104",
  "text" : "Lol I just like started using retweets",
  "id" : 421530547416879104,
  "created_at" : "2014-01-10 06:34:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeamSteamUSA",
      "screen_name" : "TeamSteam_USA",
      "indices" : [ 0, 14 ],
      "id_str" : "757681435",
      "id" : 757681435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421530346664886272",
  "in_reply_to_user_id" : 757681435,
  "text" : "@TeamSteam_USA You guys can do it, your fans believe the technology is feasible, :)",
  "id" : 421530346664886272,
  "created_at" : "2014-01-10 06:34:00 +0000",
  "in_reply_to_screen_name" : "TeamSteam_USA",
  "in_reply_to_user_id_str" : "757681435",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 0, 12 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421529011576000512",
  "in_reply_to_user_id" : 41634520,
  "text" : "@seanhannity Big Fan",
  "id" : 421529011576000512,
  "created_at" : "2014-01-10 06:28:42 +0000",
  "in_reply_to_screen_name" : "seanhannity",
  "in_reply_to_user_id_str" : "41634520",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/X7cWSzmdBd",
      "expanded_url" : "http:\/\/www.hannity.com\/pages\/conservative-solutions-term-limits",
      "display_url" : "hannity.com\/pages\/conserva\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421528823591489536",
  "text" : "RT @seanhannity: Day four of my Conservative Solutions for 2014 highlights Term Limits: http:\/\/t.co\/X7cWSzmdBd to see the rest go to http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/X7cWSzmdBd",
        "expanded_url" : "http:\/\/www.hannity.com\/pages\/conservative-solutions-term-limits",
        "display_url" : "hannity.com\/pages\/conserva\u2026"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ZnZMpoB0Br",
        "expanded_url" : "http:\/\/hannity.com",
        "display_url" : "hannity.com"
      } ]
    },
    "geo" : { },
    "id_str" : "421375998999818240",
    "text" : "Day four of my Conservative Solutions for 2014 highlights Term Limits: http:\/\/t.co\/X7cWSzmdBd to see the rest go to http:\/\/t.co\/ZnZMpoB0Br",
    "id" : 421375998999818240,
    "created_at" : "2014-01-09 20:20:41 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 421528823591489536,
  "created_at" : "2014-01-10 06:27:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Frank Yao",
      "screen_name" : "TheJetstreak",
      "indices" : [ 20, 33 ],
      "id_str" : "106938461",
      "id" : 106938461
    }, {
      "name" : "CES",
      "screen_name" : "intlCES",
      "indices" : [ 54, 62 ],
      "id_str" : "7093",
      "id" : 7093
    }, {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 69, 78 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheJetstreak\/status\/420678851820138496\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/QmGtA6Z97e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdaNL9CCAAAbNjv.jpg",
      "id_str" : "420678851706880000",
      "id" : 420678851706880000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdaNL9CCAAAbNjv.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/QmGtA6Z97e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421528704661987328",
  "text" : "RT @ijustine: Yay! \u201C@TheJetstreak: Look who\u2019s here at @intlCES! It\u2019s @ijustine! http:\/\/t.co\/QmGtA6Z97e\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frank Yao",
        "screen_name" : "TheJetstreak",
        "indices" : [ 6, 19 ],
        "id_str" : "106938461",
        "id" : 106938461
      }, {
        "name" : "CES",
        "screen_name" : "intlCES",
        "indices" : [ 40, 48 ],
        "id_str" : "7093",
        "id" : 7093
      }, {
        "name" : "Justine Ezarik",
        "screen_name" : "ijustine",
        "indices" : [ 55, 64 ],
        "id_str" : "7846",
        "id" : 7846
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheJetstreak\/status\/420678851820138496\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/QmGtA6Z97e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdaNL9CCAAAbNjv.jpg",
        "id_str" : "420678851706880000",
        "id" : 420678851706880000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdaNL9CCAAAbNjv.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/QmGtA6Z97e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420679218163236864",
    "text" : "Yay! \u201C@TheJetstreak: Look who\u2019s here at @intlCES! It\u2019s @ijustine! http:\/\/t.co\/QmGtA6Z97e\u201D",
    "id" : 420679218163236864,
    "created_at" : "2014-01-07 22:11:56 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 421528704661987328,
  "created_at" : "2014-01-10 06:27:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 33, 39 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ces2014",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/pdkGteDUfs",
      "expanded_url" : "http:\/\/instagram.com\/p\/i7cA_LAaEI\/",
      "display_url" : "instagram.com\/p\/i7cA_LAaEI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "421528629969821696",
  "text" : "RT @ijustine: Just got a demo of @intel\u2019s RealSense 3D camera - really cool! #ces2014 http:\/\/t.co\/pdkGteDUfs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 19, 25 ],
        "id_str" : "2803191",
        "id" : 2803191
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ces2014",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/pdkGteDUfs",
        "expanded_url" : "http:\/\/instagram.com\/p\/i7cA_LAaEI\/",
        "display_url" : "instagram.com\/p\/i7cA_LAaEI\/"
      } ]
    },
    "geo" : { },
    "id_str" : "421097569029062656",
    "text" : "Just got a demo of @intel\u2019s RealSense 3D camera - really cool! #ces2014 http:\/\/t.co\/pdkGteDUfs",
    "id" : 421097569029062656,
    "created_at" : "2014-01-09 01:54:18 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 421528629969821696,
  "created_at" : "2014-01-10 06:27:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 0, 13 ],
      "id_str" : "580255414",
      "id" : 580255414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421527874596646913",
  "in_reply_to_user_id" : 580255414,
  "text" : "@RockerCyborg know this is awkward but I am like the tenth guy who wants to see you play happy wheels, lol",
  "id" : 421527874596646913,
  "created_at" : "2014-01-10 06:24:11 +0000",
  "in_reply_to_screen_name" : "RockerCyborg",
  "in_reply_to_user_id_str" : "580255414",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420030000499130369",
  "text" : "Lol, I love Mr.Limbaugh's tweets.",
  "id" : 420030000499130369,
  "created_at" : "2014-01-06 03:12:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420029848120082432",
  "text" : "RT @rushlimbaugh: We Elected a Disaster and We're Living In It: RUSH: How can there be any economic growth with the policies of th... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Mv0AXHGb",
        "expanded_url" : "http:\/\/bit.ly\/zDXToL",
        "display_url" : "bit.ly\/zDXToL"
      } ]
    },
    "geo" : { },
    "id_str" : "179640770049998849",
    "text" : "We Elected a Disaster and We're Living In It: RUSH: How can there be any economic growth with the policies of th... http:\/\/t.co\/Mv0AXHGb",
    "id" : 179640770049998849,
    "created_at" : "2012-03-13 18:51:11 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 420029848120082432,
  "created_at" : "2014-01-06 03:11:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420029695199952896",
  "text" : "RT @rushlimbaugh: Rush Babes for America: Bill Maher can conduct his own War on Women, as long as it's against conservative women. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/pgBBtauh",
        "expanded_url" : "http:\/\/bit.ly\/KCZnYa",
        "display_url" : "bit.ly\/KCZnYa"
      } ]
    },
    "geo" : { },
    "id_str" : "199986945080832000",
    "text" : "Rush Babes for America: Bill Maher can conduct his own War on Women, as long as it's against conservative women. http:\/\/t.co\/pgBBtauh",
    "id" : 199986945080832000,
    "created_at" : "2012-05-08 22:19:37 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 420029695199952896,
  "created_at" : "2014-01-06 03:10:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RushCureAThon",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/tgoMx7BSMe",
      "expanded_url" : "https:\/\/rush.radiothon.org",
      "display_url" : "rush.radiothon.org"
    } ]
  },
  "geo" : { },
  "id_str" : "420029639252127746",
  "text" : "RT @rushlimbaugh: PRT Give to our Leukemia &amp; Lymphoma Cure-A-Thon. Beat blood cancers, save lives https:\/\/t.co\/tgoMx7BSMe #RushCureAThon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/accounts.vitrue.com\/\" rel=\"nofollow\"\u003EVitrue Accounts\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RushCureAThon",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/tgoMx7BSMe",
        "expanded_url" : "https:\/\/rush.radiothon.org",
        "display_url" : "rush.radiothon.org"
      } ]
    },
    "geo" : { },
    "id_str" : "322722460158025728",
    "text" : "PRT Give to our Leukemia &amp; Lymphoma Cure-A-Thon. Beat blood cancers, save lives https:\/\/t.co\/tgoMx7BSMe #RushCureAThon",
    "id" : 322722460158025728,
    "created_at" : "2013-04-12 14:46:45 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 420029639252127746,
  "created_at" : "2014-01-06 03:10:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "342887079",
      "id" : 342887079
    }, {
      "name" : "Marco Rubio",
      "screen_name" : "marcorubio",
      "indices" : [ 41, 52 ],
      "id_str" : "15745368",
      "id" : 15745368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SenatorRubio",
      "indices" : [ 77, 90 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/QvmYGAmtWL",
      "expanded_url" : "http:\/\/bit.ly\/176bWTy",
      "display_url" : "bit.ly\/176bWTy"
    } ]
  },
  "geo" : { },
  "id_str" : "420029531550801921",
  "text" : "RT @rushlimbaugh: Today's interview with @marcorubio: http:\/\/t.co\/QvmYGAmtWL #SenatorRubio #ImmigrationReform",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/accounts.vitrue.com\/\" rel=\"nofollow\"\u003EVitrue Accounts\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marco Rubio",
        "screen_name" : "marcorubio",
        "indices" : [ 23, 34 ],
        "id_str" : "15745368",
        "id" : 15745368
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SenatorRubio",
        "indices" : [ 59, 72 ]
      }, {
        "text" : "ImmigrationReform",
        "indices" : [ 73, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/QvmYGAmtWL",
        "expanded_url" : "http:\/\/bit.ly\/176bWTy",
        "display_url" : "bit.ly\/176bWTy"
      } ]
    },
    "geo" : { },
    "id_str" : "324957068211671041",
    "text" : "Today's interview with @marcorubio: http:\/\/t.co\/QvmYGAmtWL #SenatorRubio #ImmigrationReform",
    "id" : 324957068211671041,
    "created_at" : "2013-04-18 18:46:17 +0000",
    "user" : {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "protected" : false,
      "id_str" : "342887079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3502831333\/4887fae41e3681aa07276309c42ec9c9_normal.jpeg",
      "id" : 342887079,
      "verified" : true
    }
  },
  "id" : 420029531550801921,
  "created_at" : "2014-01-06 03:10:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420029024828538880",
  "text" : "What you get when you combine pita bread, pepperoni, parmesan, cheddar, ground meat, and mustard. The Ultimate sandwich that's what",
  "id" : 420029024828538880,
  "created_at" : "2014-01-06 03:08:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419968192706912256",
  "text" : "I have 4 upcoming invention design videos plus another one. So many ideas going through me head about my new companies.",
  "id" : 419968192706912256,
  "created_at" : "2014-01-05 23:06:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418585215192150017",
  "text" : "I am back from my vacation",
  "id" : 418585215192150017,
  "created_at" : "2014-01-02 03:31:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418585114784702464",
  "text" : "Had an okay day today, lol, can you guess why, lol",
  "id" : 418585114784702464,
  "created_at" : "2014-01-02 03:30:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]