Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Mike Hopkins",
      "screen_name" : "AstroIllini",
      "indices" : [ 31, 43 ],
      "id_str" : "543582293",
      "id" : 543582293
    }, {
      "name" : "Rick Mastracchio",
      "screen_name" : "AstroRM",
      "indices" : [ 50, 58 ],
      "id_str" : "541158674",
      "id" : 541158674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISS",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439427831806697472",
  "text" : "RT @NASA: Tune in at 10a ET as @AstroIllini &amp; @AstroRM chat from #ISS with students at the School of the Osage in Missouri: http:\/\/t.co\/qrm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Hopkins",
        "screen_name" : "AstroIllini",
        "indices" : [ 21, 33 ],
        "id_str" : "543582293",
        "id" : 543582293
      }, {
        "name" : "Rick Mastracchio",
        "screen_name" : "AstroRM",
        "indices" : [ 40, 48 ],
        "id_str" : "541158674",
        "id" : 541158674
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISS",
        "indices" : [ 59, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/qrm0Dzmt3M",
        "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
        "display_url" : "nasa.gov\/ntv"
      } ]
    },
    "geo" : { },
    "id_str" : "439413699531399168",
    "text" : "Tune in at 10a ET as @AstroIllini &amp; @AstroRM chat from #ISS with students at the School of the Osage in Missouri: http:\/\/t.co\/qrm0Dzmt3M",
    "id" : 439413699531399168,
    "created_at" : "2014-02-28 14:56:04 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 439427831806697472,
  "created_at" : "2014-02-28 15:52:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438823990732550145",
  "geo" : { },
  "id_str" : "439427513320628225",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 McCaf\u00E9 Shamrock Shake, lol, Sherlock?",
  "id" : 439427513320628225,
  "in_reply_to_status_id" : 438823990732550145,
  "created_at" : "2014-02-28 15:50:58 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438823990732550145",
  "text" : "Had a Sherlock shake, lol",
  "id" : 438823990732550145,
  "created_at" : "2014-02-26 23:52:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 3, 13 ],
      "id_str" : "17454769",
      "id" : 17454769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438189565665239040",
  "text" : "RT @glennbeck: When will the media wake?Is book burning far behind?Will you be able to report when the FCC monitors arrive? http:\/\/t.co\/tEY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/tEYOsaz2qn",
        "expanded_url" : "http:\/\/www.foxnews.com\/politics\/2014\/02\/24\/heating-up-climate-change-advocates-try-to-silence-krauthammer\/",
        "display_url" : "foxnews.com\/politics\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438162850033717248",
    "text" : "When will the media wake?Is book burning far behind?Will you be able to report when the FCC monitors arrive? http:\/\/t.co\/tEYOsaz2qn",
    "id" : 438162850033717248,
    "created_at" : "2014-02-25 04:05:38 +0000",
    "user" : {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "protected" : false,
      "id_str" : "17454769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535418462491791361\/NZmf8ftP_normal.jpeg",
      "id" : 17454769,
      "verified" : true
    }
  },
  "id" : 438189565665239040,
  "created_at" : "2014-02-25 05:51:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Morrison",
      "screen_name" : "jeffreymorrison",
      "indices" : [ 3, 19 ],
      "id_str" : "14287791",
      "id" : 14287791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438189426762457088",
  "text" : "RT @jeffreymorrison: The real history behind the minimum wage (HINT: It involves progressives and eugenics) \u2013 Glenn Beck http:\/\/t.co\/yJy5GY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Beck",
        "screen_name" : "glennbeck",
        "indices" : [ 127, 137 ],
        "id_str" : "17454769",
        "id" : 17454769
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/yJy5GYBvLz",
        "expanded_url" : "http:\/\/www.glennbeck.com\/2014\/02\/14\/the-real-history-behind-the-minimum-wage-hint-it-involves-progressives-and-eugenics\/",
        "display_url" : "glennbeck.com\/2014\/02\/14\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437133071247081472",
    "text" : "The real history behind the minimum wage (HINT: It involves progressives and eugenics) \u2013 Glenn Beck http:\/\/t.co\/yJy5GYBvLz via @glennbeck",
    "id" : 437133071247081472,
    "created_at" : "2014-02-22 07:53:40 +0000",
    "user" : {
      "name" : "Jeffrey Morrison",
      "screen_name" : "jeffreymorrison",
      "protected" : false,
      "id_str" : "14287791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1437062184\/DSC_0551a_normal.JPG",
      "id" : 14287791,
      "verified" : false
    }
  },
  "id" : 438189426762457088,
  "created_at" : "2014-02-25 05:51:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "David Webb",
      "screen_name" : "davidwebbshow",
      "indices" : [ 64, 78 ],
      "id_str" : "24295482",
      "id" : 24295482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438188567299252224",
  "text" : "RT @seanhannity: Next we have exclusive footage from our friend @davidwebbshow of an Alabama legislator calling Clarence Thomas an \u201CUncle T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Webb",
        "screen_name" : "davidwebbshow",
        "indices" : [ 47, 61 ],
        "id_str" : "24295482",
        "id" : 24295482
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438148969357533185",
    "text" : "Next we have exclusive footage from our friend @davidwebbshow of an Alabama legislator calling Clarence Thomas an \u201CUncle Tom\u201D",
    "id" : 438148969357533185,
    "created_at" : "2014-02-25 03:10:29 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 438188567299252224,
  "created_at" : "2014-02-25 05:47:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/UFS6kyQh9t",
      "expanded_url" : "http:\/\/www.rushlimbaugh.com\/daily\/2014\/02\/24\/uncle_rush_revere_finally_rates_with_nephew",
      "display_url" : "rushlimbaugh.com\/daily\/2014\/02\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438187878628065281",
  "text" : "Uncle Rush Revere Finally Rates with Nephew - The Rush Limbaugh Show http:\/\/t.co\/UFS6kyQh9t",
  "id" : 438187878628065281,
  "created_at" : "2014-02-25 05:45:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HtAwJ3BxPR",
      "expanded_url" : "http:\/\/1drv.ms\/1gy0bZL",
      "display_url" : "1drv.ms\/1gy0bZL"
    } ]
  },
  "geo" : { },
  "id_str" : "438115938488287232",
  "text" : "Turkish delight, had three pieces already http:\/\/t.co\/HtAwJ3BxPR",
  "id" : 438115938488287232,
  "created_at" : "2014-02-25 00:59:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elisabeth hasselbeck",
      "screen_name" : "ehasselbeck",
      "indices" : [ 3, 15 ],
      "id_str" : "23016395",
      "id" : 23016395
    }, {
      "name" : "Emi-Jay, Inc.",
      "screen_name" : "EmiJayInc",
      "indices" : [ 50, 60 ],
      "id_str" : "31646129",
      "id" : 31646129
    }, {
      "name" : "FOX & friends",
      "screen_name" : "foxandfriends",
      "indices" : [ 81, 95 ],
      "id_str" : "15513604",
      "id" : 15513604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438112767728689152",
  "text" : "RT @ehasselbeck: looking forward to visiting with @EmiJayInc tomorrow morning on @foxandfriends !  teen biz success story! my daughter and \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emi-Jay, Inc.",
        "screen_name" : "EmiJayInc",
        "indices" : [ 33, 43 ],
        "id_str" : "31646129",
        "id" : 31646129
      }, {
        "name" : "FOX & friends",
        "screen_name" : "foxandfriends",
        "indices" : [ 64, 78 ],
        "id_str" : "15513604",
        "id" : 15513604
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437775799333052416",
    "text" : "looking forward to visiting with @EmiJayInc tomorrow morning on @foxandfriends !  teen biz success story! my daughter and i share the love!",
    "id" : 437775799333052416,
    "created_at" : "2014-02-24 02:27:38 +0000",
    "user" : {
      "name" : "elisabeth hasselbeck",
      "screen_name" : "ehasselbeck",
      "protected" : false,
      "id_str" : "23016395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1408860890\/eh3_normal.jpg",
      "id" : 23016395,
      "verified" : true
    }
  },
  "id" : 438112767728689152,
  "created_at" : "2014-02-25 00:46:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Time",
      "screen_name" : "10pm",
      "indices" : [ 55, 60 ],
      "id_str" : "15494962",
      "id" : 15494962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438112602951262208",
  "text" : "RT @seanhannity: Former VP Cheney will join me tonight @10pm to discuss the Defense Department\u2019s plans to cut the U.S. Army to its smallest\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Time",
        "screen_name" : "10pm",
        "indices" : [ 38, 43 ],
        "id_str" : "15494962",
        "id" : 15494962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438061391778705410",
    "text" : "Former VP Cheney will join me tonight @10pm to discuss the Defense Department\u2019s plans to cut the U.S. Army to its smallest size since 1940.",
    "id" : 438061391778705410,
    "created_at" : "2014-02-24 21:22:29 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 438112602951262208,
  "created_at" : "2014-02-25 00:45:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438112151874838528",
  "text" : "That is how I became a conservative republican commentator. Jonathan Krohn on the other hand complete ignoramus.",
  "id" : 438112151874838528,
  "created_at" : "2014-02-25 00:44:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438111995435683840",
  "text" : "Come on you need to understand both sides and understand political ideology before you can understand full conservatism, that is what I did",
  "id" : 438111995435683840,
  "created_at" : "2014-02-25 00:43:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438111841777364992",
  "text" : "I mean come on he wasn't explaining things fully, it was obvious that when he was 13 he still didn't understand conservatism, still doesn't",
  "id" : 438111841777364992,
  "created_at" : "2014-02-25 00:42:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438111581055246337",
  "text" : "I am probably the only republican that knew that Jonathan Krohn didn't know what he was talking about during his speech at age 13.",
  "id" : 438111581055246337,
  "created_at" : "2014-02-25 00:41:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/JmkkCAvt5m",
      "expanded_url" : "http:\/\/1drv.ms\/OrKFah",
      "display_url" : "1drv.ms\/OrKFah"
    } ]
  },
  "geo" : { },
  "id_str" : "437773140245360640",
  "text" : "Made with a sandwich maker http:\/\/t.co\/JmkkCAvt5m",
  "id" : 437773140245360640,
  "created_at" : "2014-02-24 02:17:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437046992465035264",
  "text" : "Man garbage is going on in society that is corrupting our children",
  "id" : 437046992465035264,
  "created_at" : "2014-02-22 02:11:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437046909174562816",
  "text" : "Katty Perry's new video has the all seeing Eye of Horus, very creepy, she's illuminati, well I already knew that but some people don't",
  "id" : 437046909174562816,
  "created_at" : "2014-02-22 02:11:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436256041236697088",
  "text" : "Had the Chicken enchilada subway with some heavy stuff, lol, and got an arduino, good day today",
  "id" : 436256041236697088,
  "created_at" : "2014-02-19 21:48:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Ezarik",
      "screen_name" : "jennaezarik",
      "indices" : [ 3, 15 ],
      "id_str" : "6015992",
      "id" : 6015992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435262853025497088",
  "text" : "RT @jennaezarik: No one else calls the Xbox One Xbone? \n\nWell this is awkward.....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435211528115978240",
    "text" : "No one else calls the Xbox One Xbone? \n\nWell this is awkward.....",
    "id" : 435211528115978240,
    "created_at" : "2014-02-17 00:38:08 +0000",
    "user" : {
      "name" : "Jenna Ezarik",
      "screen_name" : "jennaezarik",
      "protected" : false,
      "id_str" : "6015992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/983000801902653442\/nyYgBCmn_normal.jpg",
      "id" : 6015992,
      "verified" : true
    }
  },
  "id" : 435262853025497088,
  "created_at" : "2014-02-17 04:02:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Titanfall",
      "screen_name" : "Titanfallgame",
      "indices" : [ 46, 60 ],
      "id_str" : "1360239408",
      "id" : 1360239408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435262656526577664",
  "text" : "RT @ijustine: Been having so much fun playing @Titanfallgame!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Titanfall",
        "screen_name" : "Titanfallgame",
        "indices" : [ 32, 46 ],
        "id_str" : "1360239408",
        "id" : 1360239408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435187479990132738",
    "text" : "Been having so much fun playing @Titanfallgame!",
    "id" : 435187479990132738,
    "created_at" : "2014-02-16 23:02:35 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 435262656526577664,
  "created_at" : "2014-02-17 04:01:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/435262397389893635\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dbPyS7qXU0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgpc2CUCcAECqCM.jpg",
      "id_str" : "435262397398282241",
      "id" : 435262397398282241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgpc2CUCcAECqCM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dbPyS7qXU0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435262397389893635",
  "text" : "Kabob Pizza is the best, second best is Spanish Alfredo, I wish they still made Kabob pizza at my local pizzeria. http:\/\/t.co\/dbPyS7qXU0",
  "id" : 435262397389893635,
  "created_at" : "2014-02-17 04:00:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434495310715682816",
  "text" : "Dimitris make the second best questidellas, there is this one golf club in Michigan but I forgot the name, it was epic, xd, lol",
  "id" : 434495310715682816,
  "created_at" : "2014-02-15 01:12:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/s6G7Ko4M6i",
      "expanded_url" : "http:\/\/1drv.ms\/1g5ycQW",
      "display_url" : "1drv.ms\/1g5ycQW"
    } ]
  },
  "geo" : { },
  "id_str" : "434492052689408000",
  "text" : "yummy http:\/\/t.co\/s6G7Ko4M6i",
  "id" : 434492052689408000,
  "created_at" : "2014-02-15 00:59:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XU4rnLf1fF",
      "expanded_url" : "http:\/\/sdrv.ms\/1c2JUfT",
      "display_url" : "sdrv.ms\/1c2JUfT"
    } ]
  },
  "geo" : { },
  "id_str" : "434037036991799296",
  "text" : "Dark chocolate w\/almonds http:\/\/t.co\/XU4rnLf1fF",
  "id" : 434037036991799296,
  "created_at" : "2014-02-13 18:51:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 3, 14 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teaparty",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "tcot",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ZY7bV0HZId",
      "expanded_url" : "http:\/\/bddy.me\/1eVfayH",
      "display_url" : "bddy.me\/1eVfayH"
    } ]
  },
  "geo" : { },
  "id_str" : "433825397558374401",
  "text" : "RT @TPPatriots: 1st Amendment problems: U.S. press freedom plunges under Obama to 46th in world http:\/\/t.co\/ZY7bV0HZId #teaparty #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.buddymedia.com\" rel=\"nofollow\"\u003EStream Publisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teaparty",
        "indices" : [ 103, 112 ]
      }, {
        "text" : "tcot",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ZY7bV0HZId",
        "expanded_url" : "http:\/\/bddy.me\/1eVfayH",
        "display_url" : "bddy.me\/1eVfayH"
      } ]
    },
    "geo" : { },
    "id_str" : "433752136829378560",
    "text" : "1st Amendment problems: U.S. press freedom plunges under Obama to 46th in world http:\/\/t.co\/ZY7bV0HZId #teaparty #tcot",
    "id" : 433752136829378560,
    "created_at" : "2014-02-12 23:59:02 +0000",
    "user" : {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "protected" : false,
      "id_str" : "86177206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892758166307524608\/npw0LhCp_normal.jpg",
      "id" : 86177206,
      "verified" : true
    }
  },
  "id" : 433825397558374401,
  "created_at" : "2014-02-13 04:50:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 0, 11 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433825362401697792",
  "in_reply_to_user_id" : 86177206,
  "text" : "@TPPatriots Conservatism is the answer",
  "id" : 433825362401697792,
  "created_at" : "2014-02-13 04:50:01 +0000",
  "in_reply_to_screen_name" : "TPPatriots",
  "in_reply_to_user_id_str" : "86177206",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Party Patriots",
      "screen_name" : "TPPatriots",
      "indices" : [ 0, 11 ],
      "id_str" : "86177206",
      "id" : 86177206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433825080812912640",
  "in_reply_to_user_id" : 86177206,
  "text" : "@TPPatriots We need a better solution to our country, we need conservatives",
  "id" : 433825080812912640,
  "created_at" : "2014-02-13 04:48:54 +0000",
  "in_reply_to_screen_name" : "TPPatriots",
  "in_reply_to_user_id_str" : "86177206",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 0, 12 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433824683599740928",
  "in_reply_to_user_id" : 813286,
  "text" : "@BarackObama If you keep increasing the national debt we will loose our spot on the federal reserve, btw your laws are anti-Christian morals",
  "id" : 433824683599740928,
  "created_at" : "2014-02-13 04:47:19 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 3, 16 ],
      "id_str" : "580255414",
      "id" : 580255414
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433823386821619712",
  "text" : "RT @RockerCyborg: @gamer456148 totally dewd, i'm old school.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "429804177816973312",
    "geo" : { },
    "id_str" : "433820848131039232",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 totally dewd, i'm old school.",
    "id" : 433820848131039232,
    "in_reply_to_status_id" : 429804177816973312,
    "created_at" : "2014-02-13 04:32:04 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "protected" : false,
      "id_str" : "580255414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818919561214865408\/NAHNRL36_normal.jpg",
      "id" : 580255414,
      "verified" : false
    }
  },
  "id" : 433823386821619712,
  "created_at" : "2014-02-13 04:42:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/N3waN1OnYR",
      "expanded_url" : "http:\/\/sdrv.ms\/1bYUaFV",
      "display_url" : "sdrv.ms\/1bYUaFV"
    } ]
  },
  "geo" : { },
  "id_str" : "433754000480288768",
  "text" : "Yum, lol, hotdog day http:\/\/t.co\/N3waN1OnYR",
  "id" : 433754000480288768,
  "created_at" : "2014-02-13 00:06:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433031321821380608",
  "text" : "Finished the challenge, even ate beforehand, lol",
  "id" : 433031321821380608,
  "created_at" : "2014-02-11 00:14:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/oE1oBRETao",
      "expanded_url" : "http:\/\/sdrv.ms\/1eOOXl6",
      "display_url" : "sdrv.ms\/1eOOXl6"
    } ]
  },
  "geo" : { },
  "id_str" : "433027931367948288",
  "text" : "Challenge acceptance, LOL http:\/\/t.co\/oE1oBRETao",
  "id" : 433027931367948288,
  "created_at" : "2014-02-11 00:01:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Schwertner",
      "screen_name" : "DrSchwertner",
      "indices" : [ 0, 13 ],
      "id_str" : "239930426",
      "id" : 239930426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432732781177630720",
  "in_reply_to_user_id" : 239930426,
  "text" : "@DrSchwertner We need Republicans like you.",
  "id" : 432732781177630720,
  "created_at" : "2014-02-10 04:28:29 +0000",
  "in_reply_to_screen_name" : "DrSchwertner",
  "in_reply_to_user_id_str" : "239930426",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/GMKxAcMA4P",
      "expanded_url" : "http:\/\/sdrv.ms\/1eIkCVk",
      "display_url" : "sdrv.ms\/1eIkCVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432257563066114048",
  "text" : "Yummy http:\/\/t.co\/GMKxAcMA4P",
  "id" : 432257563066114048,
  "created_at" : "2014-02-08 21:00:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431994844131504128",
  "text" : "IN dang spell check",
  "id" : 431994844131504128,
  "created_at" : "2014-02-08 03:36:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431992189682335744",
  "text" : "DIMITRIS FAMILY DINING IM CHESTERFIELD MICHIGAN IS MY FAVORITE RESTAURANT, just a random fact about me. Lol",
  "id" : 431992189682335744,
  "created_at" : "2014-02-08 03:25:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430920006952833024",
  "text" : "Thor the dark world was really bad, and cheesy as well, lol. Make better movies.",
  "id" : 430920006952833024,
  "created_at" : "2014-02-05 04:25:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/hGZG44MhhY",
      "expanded_url" : "http:\/\/sdrv.ms\/1boZt1f",
      "display_url" : "sdrv.ms\/1boZt1f"
    } ]
  },
  "geo" : { },
  "id_str" : "430522924051992576",
  "text" : "Selfie http:\/\/t.co\/hGZG44MhhY",
  "id" : 430522924051992576,
  "created_at" : "2014-02-04 02:07:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budweiser",
      "screen_name" : "Budweiser",
      "indices" : [ 3, 13 ],
      "id_str" : "2366036737",
      "id" : 2366036737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Budweiser\/status\/430171725431463936\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/3fEEv0M6hj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfhG57dCYAA5ONv.jpg",
      "id_str" : "430171725439852544",
      "id" : 430171725439852544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfhG57dCYAA5ONv.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/3fEEv0M6hj"
    } ],
    "hashtags" : [ {
      "text" : "BestBuds",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/w3ITG8WBjm",
      "expanded_url" : "http:\/\/youtu.be\/uQB7QRyF4p4",
      "display_url" : "youtu.be\/uQB7QRyF4p4"
    } ]
  },
  "geo" : { },
  "id_str" : "430201563551113216",
  "text" : "RT @Budweiser: We know, we know. Awwwwwwwwww. #BestBuds http:\/\/t.co\/w3ITG8WBjm http:\/\/t.co\/3fEEv0M6hj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Budweiser\/status\/430171725431463936\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/3fEEv0M6hj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfhG57dCYAA5ONv.jpg",
        "id_str" : "430171725439852544",
        "id" : 430171725439852544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfhG57dCYAA5ONv.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/3fEEv0M6hj"
      } ],
      "hashtags" : [ {
        "text" : "BestBuds",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/w3ITG8WBjm",
        "expanded_url" : "http:\/\/youtu.be\/uQB7QRyF4p4",
        "display_url" : "youtu.be\/uQB7QRyF4p4"
      } ]
    },
    "geo" : { },
    "id_str" : "430171725431463936",
    "text" : "We know, we know. Awwwwwwwwww. #BestBuds http:\/\/t.co\/w3ITG8WBjm http:\/\/t.co\/3fEEv0M6hj",
    "id" : 430171725431463936,
    "created_at" : "2014-02-03 02:51:46 +0000",
    "user" : {
      "name" : "BudweiserUSA",
      "screen_name" : "budweiserusa",
      "protected" : false,
      "id_str" : "870680989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930813531502587905\/k2Tj2fy-_normal.jpg",
      "id" : 870680989,
      "verified" : true
    }
  },
  "id" : 430201563551113216,
  "created_at" : "2014-02-03 04:50:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB48",
      "indices" : [ 8, 13 ]
    }, {
      "text" : "bestbuds",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "salute",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430201008837246976",
  "text" : "Watched #SB48 ads at Youtube Ad Blitz&lt; I voted for: #bestbuds , #salute they were nice family style ads. So What Was Your favorite?",
  "id" : 430201008837246976,
  "created_at" : "2014-02-03 04:48:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430172304245391361",
  "text" : "Broncos basically lost, no comment",
  "id" : 430172304245391361,
  "created_at" : "2014-02-03 02:54:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoDaddy",
      "screen_name" : "GoDaddy",
      "indices" : [ 0, 8 ],
      "id_str" : "14949454",
      "id" : 14949454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430155685246930944",
  "in_reply_to_user_id" : 14949454,
  "text" : "@GoDaddy I know you're my webhosting service but your ads are so inappropriate it makes your business look less professional then it is",
  "id" : 430155685246930944,
  "created_at" : "2014-02-03 01:48:01 +0000",
  "in_reply_to_screen_name" : "GoDaddy",
  "in_reply_to_user_id_str" : "14949454",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rush Limbaugh",
      "screen_name" : "rushlimbaugh",
      "indices" : [ 0, 13 ],
      "id_str" : "342887079",
      "id" : 342887079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430155019103379457",
  "in_reply_to_user_id" : 342887079,
  "text" : "@rushlimbaugh 41 Million+ Political idiots followed Obama on twitter, wow where's this world going.",
  "id" : 430155019103379457,
  "created_at" : "2014-02-03 01:45:23 +0000",
  "in_reply_to_screen_name" : "rushlimbaugh",
  "in_reply_to_user_id_str" : "342887079",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 3, 11 ],
      "id_str" : "18734310",
      "id" : 18734310
    }, {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 83, 92 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB48",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430153632756281344",
  "text" : "RT @Broncos: Percy Harvin opens the second half with an 87-yard kickoff-return TD. @Seahawks lead 29-0, 14:48 to play in 2nd half. #SB48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seattle Seahawks",
        "screen_name" : "Seahawks",
        "indices" : [ 70, 79 ],
        "id_str" : "23642374",
        "id" : 23642374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB48",
        "indices" : [ 118, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430151934700306433",
    "text" : "Percy Harvin opens the second half with an 87-yard kickoff-return TD. @Seahawks lead 29-0, 14:48 to play in 2nd half. #SB48",
    "id" : 430151934700306433,
    "created_at" : "2014-02-03 01:33:07 +0000",
    "user" : {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "protected" : false,
      "id_str" : "18734310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818613120075599873\/yMGvb5Cu_normal.jpg",
      "id" : 18734310,
      "verified" : true
    }
  },
  "id" : 430153632756281344,
  "created_at" : "2014-02-03 01:39:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Gun",
      "screen_name" : "MachineGunDan",
      "indices" : [ 0, 14 ],
      "id_str" : "587191286",
      "id" : 587191286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430153127560372225",
  "in_reply_to_user_id" : 587191286,
  "text" : "@MachineGunDan Why does everybody apparently like the Seahalks so much",
  "id" : 430153127560372225,
  "created_at" : "2014-02-03 01:37:52 +0000",
  "in_reply_to_screen_name" : "MachineGunDan",
  "in_reply_to_user_id_str" : "587191286",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Ezarik",
      "screen_name" : "jennaezarik",
      "indices" : [ 0, 12 ],
      "id_str" : "6015992",
      "id" : 6015992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430152700404039680",
  "in_reply_to_user_id" : 6015992,
  "text" : "@jennaezarik We should do a Youtube collab, lol",
  "id" : 430152700404039680,
  "created_at" : "2014-02-03 01:36:10 +0000",
  "in_reply_to_screen_name" : "jennaezarik",
  "in_reply_to_user_id_str" : "6015992",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budweiser Puppy",
      "screen_name" : "BudweiserPuppy",
      "indices" : [ 3, 18 ],
      "id_str" : "2313899726",
      "id" : 2313899726
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BudweiserPuppy\/status\/430004885698781185\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/v0XPWudqaA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfevKlBCIAAriAf.jpg",
      "id_str" : "430004885707169792",
      "id" : 430004885707169792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfevKlBCIAAriAf.jpg",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/v0XPWudqaA"
    } ],
    "hashtags" : [ {
      "text" : "PunxsutawneyPhil",
      "indices" : [ 32, 49 ]
    }, {
      "text" : "GroundhogDay",
      "indices" : [ 72, 85 ]
    }, {
      "text" : "PuppyDay",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "BestBuds",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430152478458257408",
  "text" : "RT @BudweiserPuppy: Don\u2019t worry #PunxsutawneyPhil! I see my shadow too. #GroundhogDay #PuppyDay #BestBuds http:\/\/t.co\/v0XPWudqaA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BudweiserPuppy\/status\/430004885698781185\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/v0XPWudqaA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfevKlBCIAAriAf.jpg",
        "id_str" : "430004885707169792",
        "id" : 430004885707169792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfevKlBCIAAriAf.jpg",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 440
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/v0XPWudqaA"
      } ],
      "hashtags" : [ {
        "text" : "PunxsutawneyPhil",
        "indices" : [ 12, 29 ]
      }, {
        "text" : "GroundhogDay",
        "indices" : [ 52, 65 ]
      }, {
        "text" : "PuppyDay",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "BestBuds",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430004885698781185",
    "text" : "Don\u2019t worry #PunxsutawneyPhil! I see my shadow too. #GroundhogDay #PuppyDay #BestBuds http:\/\/t.co\/v0XPWudqaA",
    "id" : 430004885698781185,
    "created_at" : "2014-02-02 15:48:48 +0000",
    "user" : {
      "name" : "Budweiser Puppy",
      "screen_name" : "BudweiserPuppy",
      "protected" : false,
      "id_str" : "2313899726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535524476939558912\/fpZJKPJL_normal.jpeg",
      "id" : 2313899726,
      "verified" : false
    }
  },
  "id" : 430152478458257408,
  "created_at" : "2014-02-03 01:35:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB48",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430152209968287744",
  "text" : "RT @ijustine: Wonder if Bruno will sing about loving young girls? #SB48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB48",
        "indices" : [ 52, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430146813274750976",
    "text" : "Wonder if Bruno will sing about loving young girls? #SB48",
    "id" : 430146813274750976,
    "created_at" : "2014-02-03 01:12:46 +0000",
    "user" : {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991811409292988423\/6KxQ-LoD_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 430152209968287744,
  "created_at" : "2014-02-03 01:34:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430151849027465217",
  "text" : "Reminds me of 2012 when I wanted the Patriots to win, or last year when I wanted the 49ers to win. 2006 was my favorite game result.",
  "id" : 430151849027465217,
  "created_at" : "2014-02-03 01:32:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430150142541316097",
  "text" : "Honestly I want the Denver Bruncos to win",
  "id" : 430150142541316097,
  "created_at" : "2014-02-03 01:26:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430149318310232064",
  "text" : "Watching the Superbowl, Bruno Mars just came on, lol, we want to watch football not an annoying singer.",
  "id" : 430149318310232064,
  "created_at" : "2014-02-03 01:22:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430027923223896064",
  "text" : "Saw two little cousins at the Coptic church, had nice time :)",
  "id" : 430027923223896064,
  "created_at" : "2014-02-02 17:20:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrible Tommy",
      "screen_name" : "RockerCyborg",
      "indices" : [ 0, 13 ],
      "id_str" : "580255414",
      "id" : 580255414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429804177816973312",
  "in_reply_to_user_id" : 580255414,
  "text" : "@RockerCyborg You're like back in the old day where people weren't spoiled brats, listened to real music and lived life. LOL",
  "id" : 429804177816973312,
  "created_at" : "2014-02-02 02:31:16 +0000",
  "in_reply_to_screen_name" : "RockerCyborg",
  "in_reply_to_user_id_str" : "580255414",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leticia Quinonez",
      "screen_name" : "BlessedRebecca",
      "indices" : [ 3, 18 ],
      "id_str" : "342471033",
      "id" : 342471033
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "leticia '-'",
      "screen_name" : "leticia",
      "indices" : [ 33, 41 ],
      "id_str" : "1140850806",
      "id" : 1140850806
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429802947850276864",
  "text" : "RT @BlessedRebecca: @gamer456148 @leticia @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for  Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "leticia '-'",
        "screen_name" : "leticia",
        "indices" : [ 13, 21 ],
        "id_str" : "1140850806",
        "id" : 1140850806
      }, {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 22, 30 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "302879157640130560",
    "geo" : { },
    "id_str" : "429706323660660736",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @leticia @YouTube",
    "id" : 429706323660660736,
    "in_reply_to_status_id" : 302879157640130560,
    "created_at" : "2014-02-01 20:02:25 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Leticia Quinonez",
      "screen_name" : "BlessedRebecca",
      "protected" : false,
      "id_str" : "342471033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1461218339\/star_normal.jpg",
      "id" : 342471033,
      "verified" : false
    }
  },
  "id" : 429802947850276864,
  "created_at" : "2014-02-02 02:26:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]