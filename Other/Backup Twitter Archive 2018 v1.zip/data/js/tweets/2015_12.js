Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682629706206855169",
  "text" : "I like Pumpkin Pie Ice Cream and Sweet Ice Tea, lol",
  "id" : 682629706206855169,
  "created_at" : "2015-12-31 18:29:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    }, {
      "name" : "Kevin Peterson",
      "screen_name" : "KevinP4Real",
      "indices" : [ 11, 23 ],
      "id_str" : "2319031710",
      "id" : 2319031710
    }, {
      "name" : "Shark Tank",
      "screen_name" : "ABCSharkTank",
      "indices" : [ 24, 37 ],
      "id_str" : "468583731",
      "id" : 468583731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681551222432776195",
  "text" : "RT @sacca: @KevinP4Real @ABCSharkTank You can still replay it today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Peterson",
        "screen_name" : "KevinP4Real",
        "indices" : [ 0, 12 ],
        "id_str" : "2319031710",
        "id" : 2319031710
      }, {
        "name" : "Shark Tank",
        "screen_name" : "ABCSharkTank",
        "indices" : [ 13, 26 ],
        "id_str" : "468583731",
        "id" : 468583731
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "681517182249902080",
    "geo" : { },
    "id_str" : "681517383685550081",
    "in_reply_to_user_id" : 2319031710,
    "text" : "@KevinP4Real @ABCSharkTank You can still replay it today.",
    "id" : 681517383685550081,
    "in_reply_to_status_id" : 681517182249902080,
    "created_at" : "2015-12-28 16:49:40 +0000",
    "in_reply_to_screen_name" : "KevinP4Real",
    "in_reply_to_user_id_str" : "2319031710",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668902554957316096\/IpjBGyjC_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 681551222432776195,
  "created_at" : "2015-12-28 19:04:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GMC",
      "screen_name" : "GMC",
      "indices" : [ 3, 7 ],
      "id_str" : "75016467",
      "id" : 75016467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681551088416325633",
  "text" : "RT @gmc: Watched it take 90 mins to setup a 75 year old on an iPad. Usability still has a ways to go",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680160861776941056",
    "text" : "Watched it take 90 mins to setup a 75 year old on an iPad. Usability still has a ways to go",
    "id" : 680160861776941056,
    "created_at" : "2015-12-24 22:59:20 +0000",
    "user" : {
      "name" : "Garrett Camp",
      "screen_name" : "gc",
      "protected" : false,
      "id_str" : "735983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2765883929\/59be193e66e534286bbc7f5061688a7a_normal.png",
      "id" : 735983,
      "verified" : true
    }
  },
  "id" : 681551088416325633,
  "created_at" : "2015-12-28 19:03:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/681303244656607233\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/LkHNWDbewl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXR5r0wUMAAqRqM.jpg",
      "id_str" : "681303237442416640",
      "id" : 681303237442416640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXR5r0wUMAAqRqM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/LkHNWDbewl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681303244656607233",
  "text" : "This candy is the best :) https:\/\/t.co\/LkHNWDbewl",
  "id" : 681303244656607233,
  "created_at" : "2015-12-28 02:38:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681160672760090624",
  "text" : "It is a greater then awesome feeling to have communion in the Coptic Church-",
  "id" : 681160672760090624,
  "created_at" : "2015-12-27 17:12:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 0, 12 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680931437273546752",
  "geo" : { },
  "id_str" : "680933597101047808",
  "in_reply_to_user_id" : 268556198,
  "text" : "@BestGamezUp For the Nokia N-Gage, it was golden \uD83D\uDE43",
  "id" : 680933597101047808,
  "in_reply_to_status_id" : 680931437273546752,
  "created_at" : "2015-12-27 02:09:55 +0000",
  "in_reply_to_screen_name" : "BestGamezUp",
  "in_reply_to_user_id_str" : "268556198",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Carmichael",
      "screen_name" : "EvanCarmichael",
      "indices" : [ 3, 18 ],
      "id_str" : "21771022",
      "id" : 21771022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stuntman",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "dream",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680933372919676929",
  "text" : "RT @EvanCarmichael: \u201CHe dropped out from grade school, was a #stuntman in Bruce Lee's movies, and never gave up on his #dream.\u201D \u2013 Ja ... ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.evancarmichael.com\" rel=\"nofollow\"\u003EEvan Carmichael\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EvanCarmichael\/status\/680931482043457536\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ZX23kIhlSf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXMnkzRUsAEadWn.jpg",
        "id_str" : "680931481854717953",
        "id" : 680931481854717953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXMnkzRUsAEadWn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZX23kIhlSf"
      } ],
      "hashtags" : [ {
        "text" : "stuntman",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "dream",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680931482043457536",
    "text" : "\u201CHe dropped out from grade school, was a #stuntman in Bruce Lee's movies, and never gave up on his #dream.\u201D \u2013 Ja ... https:\/\/t.co\/ZX23kIhlSf",
    "id" : 680931482043457536,
    "created_at" : "2015-12-27 02:01:31 +0000",
    "user" : {
      "name" : "Evan Carmichael",
      "screen_name" : "EvanCarmichael",
      "protected" : false,
      "id_str" : "21771022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961350615019540482\/Rn_wEtGZ_normal.jpg",
      "id" : 21771022,
      "verified" : true
    }
  },
  "id" : 680933372919676929,
  "created_at" : "2015-12-27 02:09:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/459414490808090624\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/IBQ5lrLNKg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmArC5BIQAAGb0i.jpg",
      "id_str" : "459414490657079296",
      "id" : 459414490657079296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmArC5BIQAAGb0i.jpg",
      "sizes" : [ {
        "h" : 184,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/IBQ5lrLNKg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680933154853666816",
  "text" : "RT @BestGamezUp: Awesome sonic street art. https:\/\/t.co\/IBQ5lrLNKg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/459414490808090624\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/IBQ5lrLNKg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmArC5BIQAAGb0i.jpg",
        "id_str" : "459414490657079296",
        "id" : 459414490657079296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmArC5BIQAAGb0i.jpg",
        "sizes" : [ {
          "h" : 184,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/IBQ5lrLNKg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680932417079762945",
    "text" : "Awesome sonic street art. https:\/\/t.co\/IBQ5lrLNKg",
    "id" : 680932417079762945,
    "created_at" : "2015-12-27 02:05:14 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 680933154853666816,
  "created_at" : "2015-12-27 02:08:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680933122482003968",
  "text" : "Trey Puppet Actor Growdy just endorsed baby faced establishment pumping Rubio for president",
  "id" : 680933122482003968,
  "created_at" : "2015-12-27 02:08:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680892261954138112",
  "text" : "Thank God for your blessings",
  "id" : 680892261954138112,
  "created_at" : "2015-12-26 23:25:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680450065962545152",
  "text" : "RT @BarbaraCorcoran: I didn\u2019t have a role model in business, but I was blessed with the best thing anyone could ever wish for - mother who \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679881890204106753",
    "text" : "I didn\u2019t have a role model in business, but I was blessed with the best thing anyone could ever wish for - mother who was a powerhouse.",
    "id" : 679881890204106753,
    "created_at" : "2015-12-24 04:30:48 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 680450065962545152,
  "created_at" : "2015-12-25 18:08:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 0, 16 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680449990280392704",
  "in_reply_to_user_id" : 36728196,
  "text" : "@BarbaraCorcoran There is no bigger motivation for success then failing or getting rejected, very inspiring words :)",
  "id" : 680449990280392704,
  "created_at" : "2015-12-25 18:08:14 +0000",
  "in_reply_to_screen_name" : "BarbaraCorcoran",
  "in_reply_to_user_id_str" : "36728196",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemDebate",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679419615131365376",
  "text" : "RT @hannahbleau_: My sister's reaction to seeing O'Malley during the #DemDebate : \"Who's he?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemDebate",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678404422020435969",
    "text" : "My sister's reaction to seeing O'Malley during the #DemDebate : \"Who's he?\"",
    "id" : 678404422020435969,
    "created_at" : "2015-12-20 02:39:53 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 679419615131365376,
  "created_at" : "2015-12-22 21:53:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/679419420251410432\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/UAv46ciFM8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3IVZZUYAAV3mi.jpg",
      "id_str" : "679419388722700288",
      "id" : 679419388722700288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3IVZZUYAAV3mi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/UAv46ciFM8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679419420251410432",
  "text" : "Best Meatloaf I ever had @ Old Stone Bar &amp; Grill https:\/\/t.co\/UAv46ciFM8",
  "id" : 679419420251410432,
  "created_at" : "2015-12-22 21:53:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678601141886808065",
  "text" : "Yesterday I tried real Kettle Corn, it tasted so good :) \uD83D\uDE0E",
  "id" : 678601141886808065,
  "created_at" : "2015-12-20 15:41:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemDebate",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678384845500899329",
  "text" : "RT @hannahbleau_: #DemDebate spoiler: Climate change is the biggest threat to national security, everything should be free &amp; if you disagre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemDebate",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678384600888950785",
    "text" : "#DemDebate spoiler: Climate change is the biggest threat to national security, everything should be free &amp; if you disagree, you're racist.",
    "id" : 678384600888950785,
    "created_at" : "2015-12-20 01:21:07 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 678384845500899329,
  "created_at" : "2015-12-20 01:22:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678384107076849664",
  "text" : "RT @God_Instagram: Thank you, God for everything. The big things and the small, For \"every good gift comes from God\", The Giver of them all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678169553201836033",
    "text" : "Thank you, God for everything. The big things and the small, For \"every good gift comes from God\", The Giver of them all.",
    "id" : 678169553201836033,
    "created_at" : "2015-12-19 11:06:35 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 678384107076849664,
  "created_at" : "2015-12-20 01:19:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/678383971298885632\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/rZNEhEqS8R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWoanmIUYAAR3dl.jpg",
      "id_str" : "678383961425338368",
      "id" : 678383961425338368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWoanmIUYAAR3dl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/rZNEhEqS8R"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/678383971298885632\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/rZNEhEqS8R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWoanmNUAAELcmr.jpg",
      "id_str" : "678383961446285313",
      "id" : 678383961446285313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWoanmNUAAELcmr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/rZNEhEqS8R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678383971298885632",
  "text" : "Went to a highly Inaccurate Nativity play https:\/\/t.co\/rZNEhEqS8R",
  "id" : 678383971298885632,
  "created_at" : "2015-12-20 01:18:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677991792868900864",
  "text" : "RT @HelloRyanHolmes: Don't let the evils of the world take you down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677735279063527424",
    "text" : "Don't let the evils of the world take you down.",
    "id" : 677735279063527424,
    "created_at" : "2015-12-18 06:20:56 +0000",
    "user" : {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/981755756423737344\/APZTJDhC_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 677991792868900864,
  "created_at" : "2015-12-18 23:20:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 3, 14 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/wZFMWODdoM",
      "expanded_url" : "https:\/\/vine.co\/v\/blrW6wMzEpa",
      "display_url" : "vine.co\/v\/blrW6wMzEpa"
    } ]
  },
  "geo" : { },
  "id_str" : "677306497961824256",
  "text" : "RT @WWEXStream: Playing with toy cars https:\/\/t.co\/wZFMWODdoM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/wZFMWODdoM",
        "expanded_url" : "https:\/\/vine.co\/v\/blrW6wMzEpa",
        "display_url" : "vine.co\/v\/blrW6wMzEpa"
      } ]
    },
    "geo" : { },
    "id_str" : "677300211484635136",
    "text" : "Playing with toy cars https:\/\/t.co\/wZFMWODdoM",
    "id" : 677300211484635136,
    "created_at" : "2015-12-17 01:32:08 +0000",
    "user" : {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "protected" : false,
      "id_str" : "305791165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465976113496223744\/iEGR6Kkr_normal.jpeg",
      "id" : 305791165,
      "verified" : false
    }
  },
  "id" : 677306497961824256,
  "created_at" : "2015-12-17 01:57:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyDose Of Kittens",
      "screen_name" : "TheDaiIyKitten",
      "indices" : [ 3, 18 ],
      "id_str" : "2357198672",
      "id" : 2357198672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TodaysKitten\/status\/445189018917957632\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/p98oOI1EHc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2hDdLCcAAdBCD.jpg",
      "id_str" : "445189018922151936",
      "id" : 445189018922151936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2hDdLCcAAdBCD.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/p98oOI1EHc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677306147573862400",
  "text" : "RT @TheDaiIyKitten: Wanna play!? https:\/\/t.co\/p98oOI1EHc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TodaysKitten\/status\/445189018917957632\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/p98oOI1EHc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi2hDdLCcAAdBCD.jpg",
        "id_str" : "445189018922151936",
        "id" : 445189018922151936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi2hDdLCcAAdBCD.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/p98oOI1EHc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677254938192384002",
    "text" : "Wanna play!? https:\/\/t.co\/p98oOI1EHc",
    "id" : 677254938192384002,
    "created_at" : "2015-12-16 22:32:14 +0000",
    "user" : {
      "name" : "DailyDose Of Kittens",
      "screen_name" : "TheDaiIyKitten",
      "protected" : false,
      "id_str" : "2357198672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885149516718104576\/9cohre2I_normal.jpg",
      "id" : 2357198672,
      "verified" : false
    }
  },
  "id" : 677306147573862400,
  "created_at" : "2015-12-17 01:55:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677305689287475200",
  "text" : "RT @God_Instagram: Trust God, because only He holds the key to your future",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677270620334194688",
    "text" : "Trust God, because only He holds the key to your future",
    "id" : 677270620334194688,
    "created_at" : "2015-12-16 23:34:33 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 677305689287475200,
  "created_at" : "2015-12-17 01:53:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPix",
      "indices" : [ 0, 14 ],
      "id_str" : "3095465259",
      "id" : 3095465259
    }, {
      "name" : "FlirtyNotes",
      "screen_name" : "FlirtyNotes",
      "indices" : [ 15, 27 ],
      "id_str" : "623584562",
      "id" : 623584562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677304048647806978",
  "geo" : { },
  "id_str" : "677305449511714818",
  "in_reply_to_user_id" : 3095465259,
  "text" : "@HistoricalPix @FlirtyNotes \uD83C\uDDFA\uD83C\uDDF8",
  "id" : 677305449511714818,
  "in_reply_to_status_id" : 677304048647806978,
  "created_at" : "2015-12-17 01:52:57 +0000",
  "in_reply_to_screen_name" : "HistoricalPix",
  "in_reply_to_user_id_str" : "3095465259",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677304756218429440",
  "text" : "Warren Tax-Dogging Buffet just endorsed Hillary Clinton's stance on higher taxes on the wealthy. He should be affected at full amount.",
  "id" : 677304756218429440,
  "created_at" : "2015-12-17 01:50:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/676836385119035392\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/vMJ1XT06k0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWSbGMmWoAEZSjV.jpg",
      "id_str" : "676836374776029185",
      "id" : 676836374776029185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWSbGMmWoAEZSjV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/vMJ1XT06k0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676836385119035392",
  "text" : "Pizza Nostalgia; 4.45\/5 stars https:\/\/t.co\/vMJ1XT06k0",
  "id" : 676836385119035392,
  "created_at" : "2015-12-15 18:49:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676816831747743744",
  "text" : "RT @God_Instagram: Dear God, I know you are listening please give me strength.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675073664845529089",
    "text" : "Dear God, I know you are listening please give me strength.",
    "id" : 675073664845529089,
    "created_at" : "2015-12-10 22:04:38 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 676816831747743744,
  "created_at" : "2015-12-15 17:31:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676816790912012288",
  "text" : "Everywhere you go, thank the God who made you",
  "id" : 676816790912012288,
  "created_at" : "2015-12-15 17:31:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuySell",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675068861927047169",
  "text" : "RT @HamzeiAnalytics: BUY Programs detected at NYSE #BuySell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuySell",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674971114582335490",
    "text" : "BUY Programs detected at NYSE #BuySell",
    "id" : 674971114582335490,
    "created_at" : "2015-12-10 15:17:08 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 675068861927047169,
  "created_at" : "2015-12-10 21:45:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675068844990472193",
  "text" : "Make demand and supply =, find price, plug it in #MathTips",
  "id" : 675068844990472193,
  "created_at" : "2015-12-10 21:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674298518702587905",
  "geo" : { },
  "id_str" : "675019024841900034",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 e^0 also equals 1 :) #MathTips",
  "id" : 675019024841900034,
  "in_reply_to_status_id" : 674298518702587905,
  "created_at" : "2015-12-10 18:27:31 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/SsR0KqHrwc",
      "expanded_url" : "https:\/\/twitter.com\/jorgevictoria\/status\/674381901747064832",
      "display_url" : "twitter.com\/jorgevictoria\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674971126116786177",
  "text" : "Ah the emarketer https:\/\/t.co\/SsR0KqHrwc",
  "id" : 674971126116786177,
  "created_at" : "2015-12-10 15:17:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "indices" : [ 3, 17 ],
      "id_str" : "34356320",
      "id" : 34356320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digital",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "marketing",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "ecommerce",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/6sRHMiZbAD",
      "expanded_url" : "http:\/\/ow.ly\/VkUSR",
      "display_url" : "ow.ly\/VkUSR"
    } ]
  },
  "geo" : { },
  "id_str" : "674970976162062336",
  "text" : "RT @jorgevictoria: By 2016, Most Digital Travel Bookers Will Use Mobile Devices\n\nhttps:\/\/t.co\/6sRHMiZbAD\n#digital #marketing #ecommerce #re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "digital",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "marketing",
        "indices" : [ 95, 105 ]
      }, {
        "text" : "ecommerce",
        "indices" : [ 106, 116 ]
      }, {
        "text" : "retail",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/6sRHMiZbAD",
        "expanded_url" : "http:\/\/ow.ly\/VkUSR",
        "display_url" : "ow.ly\/VkUSR"
      } ]
    },
    "geo" : { },
    "id_str" : "674744276413227012",
    "text" : "By 2016, Most Digital Travel Bookers Will Use Mobile Devices\n\nhttps:\/\/t.co\/6sRHMiZbAD\n#digital #marketing #ecommerce #retail",
    "id" : 674744276413227012,
    "created_at" : "2015-12-10 00:15:46 +0000",
    "user" : {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "protected" : false,
      "id_str" : "34356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941167491241398273\/72oSkHhB_normal.jpg",
      "id" : 34356320,
      "verified" : false
    }
  },
  "id" : 674970976162062336,
  "created_at" : "2015-12-10 15:16:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674970881614069760",
  "text" : "Log(1)=0",
  "id" : 674970881614069760,
  "created_at" : "2015-12-10 15:16:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "indices" : [ 3, 17 ],
      "id_str" : "34356320",
      "id" : 34356320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674806602063609857",
  "text" : "RT @jorgevictoria: A word of encouragement after failure is worth more than an hour of praise after success.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674804632749776896",
    "text" : "A word of encouragement after failure is worth more than an hour of praise after success.",
    "id" : 674804632749776896,
    "created_at" : "2015-12-10 04:15:36 +0000",
    "user" : {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "protected" : false,
      "id_str" : "34356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941167491241398273\/72oSkHhB_normal.jpg",
      "id" : 34356320,
      "verified" : false
    }
  },
  "id" : 674806602063609857,
  "created_at" : "2015-12-10 04:23:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 3, 7 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "LA Clippers",
      "screen_name" : "LAClippers",
      "indices" : [ 13, 24 ],
      "id_str" : "19564719",
      "id" : 19564719
    }, {
      "name" : "Milwaukee Bucks",
      "screen_name" : "Bucks",
      "indices" : [ 36, 42 ],
      "id_str" : "15900167",
      "id" : 15900167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674806470794457088",
  "text" : "RT @NBA: The @LAClippers defeat the @Bucks 109-95 led by Redick 31, Griffin 21 &amp; 14, Paul 18 &amp; 18. MCW 20 &amp; 11 for MIL. https:\/\/t.co\/YhukuA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LA Clippers",
        "screen_name" : "LAClippers",
        "indices" : [ 4, 15 ],
        "id_str" : "19564719",
        "id" : 19564719
      }, {
        "name" : "Milwaukee Bucks",
        "screen_name" : "Bucks",
        "indices" : [ 27, 33 ],
        "id_str" : "15900167",
        "id" : 15900167
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NBA\/status\/674793741950058497\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/YhukuAdjWp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV1ZVMeWoAA1Lz4.jpg",
        "id_str" : "674793739836104704",
        "id" : 674793739836104704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV1ZVMeWoAA1Lz4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 5184,
          "resize" : "fit",
          "w" : 3456
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 800
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/YhukuAdjWp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674793741950058497",
    "text" : "The @LAClippers defeat the @Bucks 109-95 led by Redick 31, Griffin 21 &amp; 14, Paul 18 &amp; 18. MCW 20 &amp; 11 for MIL. https:\/\/t.co\/YhukuAdjWp",
    "id" : 674793741950058497,
    "created_at" : "2015-12-10 03:32:19 +0000",
    "user" : {
      "name" : "NBA",
      "screen_name" : "NBA",
      "protected" : false,
      "id_str" : "19923144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921248739746033665\/cjBVcCJG_normal.jpg",
      "id" : 19923144,
      "verified" : true
    }
  },
  "id" : 674806470794457088,
  "created_at" : "2015-12-10 04:22:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 92, 104 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674806309867429890",
  "text" : "Ted Cruz called alleged Planned Parenthood shooter a 'transgendered leftist activist' # via @HuffPostPol",
  "id" : 674806309867429890,
  "created_at" : "2015-12-10 04:22:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638176942735360",
  "text" : "RT @God_Instagram: Walking with God is the best adventure, finding God is the best achievement and having God as a companion is the best so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674613132120076290",
    "text" : "Walking with God is the best adventure, finding God is the best achievement and having God as a companion is the best source of happiness.",
    "id" : 674613132120076290,
    "created_at" : "2015-12-09 15:34:39 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 674638176942735360,
  "created_at" : "2015-12-09 17:14:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Van Gogh Museum",
      "screen_name" : "vangoghmuseum",
      "indices" : [ 3, 17 ],
      "id_str" : "24691376",
      "id" : 24691376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638081522278400",
  "text" : "RT @vangoghmuseum: Munch &amp; Van Gogh both believed that the portrait was an important means of expressing the essence of the modern age http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vangoghmuseum\/status\/674629580783775744\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/ZMoxp4cAGJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVzEB0rWsAApw5J.jpg",
        "id_str" : "674629579798130688",
        "id" : 674629579798130688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVzEB0rWsAApw5J.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1005
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 1433,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1433,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ZMoxp4cAGJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674629580783775744",
    "text" : "Munch &amp; Van Gogh both believed that the portrait was an important means of expressing the essence of the modern age https:\/\/t.co\/ZMoxp4cAGJ",
    "id" : 674629580783775744,
    "created_at" : "2015-12-09 16:40:00 +0000",
    "user" : {
      "name" : "Van Gogh Museum",
      "screen_name" : "vangoghmuseum",
      "protected" : false,
      "id_str" : "24691376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492214809618677761\/5kzNWsoy_normal.jpeg",
      "id" : 24691376,
      "verified" : true
    }
  },
  "id" : 674638081522278400,
  "created_at" : "2015-12-09 17:13:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637550598955008",
  "text" : "I am more of a fan of Monetarist and Classical Macroeconomics for sustained economic growth. Stop pumping dollars like crazy!!",
  "id" : 674637550598955008,
  "created_at" : "2015-12-09 17:11:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674330531547488257",
  "text" : "First we got Hillary's campaign ad, Trump's internet comments and now Jeff Bezos, shaking my head",
  "id" : 674330531547488257,
  "created_at" : "2015-12-08 20:51:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UKC",
      "screen_name" : "ukchelpdesk",
      "indices" : [ 3, 15 ],
      "id_str" : "397906754",
      "id" : 397906754
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674299973400461316",
  "text" : "RT @ukchelpdesk: @gamer456148 Thank you! It's looking popular, and a surprise, we (wrongly) thought the 1st option would win by a mile :D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "674298996286992388",
    "geo" : { },
    "id_str" : "674299605857804288",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Thank you! It's looking popular, and a surprise, we (wrongly) thought the 1st option would win by a mile :D",
    "id" : 674299605857804288,
    "in_reply_to_status_id" : 674298996286992388,
    "created_at" : "2015-12-08 18:48:48 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "UKC",
      "screen_name" : "ukchelpdesk",
      "protected" : false,
      "id_str" : "397906754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676037588549894144\/yiEjT0oY_normal.png",
      "id" : 397906754,
      "verified" : false
    }
  },
  "id" : 674299973400461316,
  "created_at" : "2015-12-08 18:50:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuySell",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674299411351117824",
  "text" : "RT @HamzeiAnalytics: BUY Programs detected at NYSE #BuySell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuySell",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674296804859469824",
    "text" : "BUY Programs detected at NYSE #BuySell",
    "id" : 674296804859469824,
    "created_at" : "2015-12-08 18:37:40 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 674299411351117824,
  "created_at" : "2015-12-08 18:48:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "indices" : [ 3, 14 ],
      "id_str" : "552147406",
      "id" : 552147406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674299262440710144",
  "text" : "RT @TriviaHive: The full name of Captain Crunch is Horatio Magellan Crunch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674298232143519744",
    "text" : "The full name of Captain Crunch is Horatio Magellan Crunch",
    "id" : 674298232143519744,
    "created_at" : "2015-12-08 18:43:21 +0000",
    "user" : {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "protected" : false,
      "id_str" : "552147406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705567159968071680\/PQrm33In_normal.jpg",
      "id" : 552147406,
      "verified" : false
    }
  },
  "id" : 674299262440710144,
  "created_at" : "2015-12-08 18:47:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UKC",
      "screen_name" : "ukchelpdesk",
      "indices" : [ 0, 12 ],
      "id_str" : "397906754",
      "id" : 397906754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674192209130987520",
  "geo" : { },
  "id_str" : "674298996286992388",
  "in_reply_to_user_id" : 397906754,
  "text" : "@ukchelpdesk Definitely second one :)",
  "id" : 674298996286992388,
  "in_reply_to_status_id" : 674192209130987520,
  "created_at" : "2015-12-08 18:46:23 +0000",
  "in_reply_to_screen_name" : "ukchelpdesk",
  "in_reply_to_user_id_str" : "397906754",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Econ",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674298769819725826",
  "text" : "Studying m2 and the long forgotten m3 #Econ",
  "id" : 674298769819725826,
  "created_at" : "2015-12-08 18:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MathTips",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674298518702587905",
  "text" : "Natural log of e equals 1 #MathTips",
  "id" : 674298518702587905,
  "created_at" : "2015-12-08 18:44:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673885153819828224",
  "text" : "RT @buysellshort: $CBLI $15m contract from DoD for radiation sickness drug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673884404880531456",
    "text" : "$CBLI $15m contract from DoD for radiation sickness drug",
    "id" : 673884404880531456,
    "created_at" : "2015-12-07 15:18:56 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : true,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 673885153819828224,
  "created_at" : "2015-12-07 15:21:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673884894204858368",
  "text" : "Rejection can hurt but everything happens for a purpose, let God's will be done :)",
  "id" : 673884894204858368,
  "created_at" : "2015-12-07 15:20:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/bqpfGFAHGV",
      "expanded_url" : "http:\/\/www.engadget.com\/2015\/12\/07\/adobe-lightroom-mobile-android-free\/",
      "display_url" : "engadget.com\/2015\/12\/07\/ado\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673884708221132800",
  "text" : "RT @EmperorDarroux: Adobe Lightroom mobile on Android is now available for free https:\/\/t.co\/bqpfGFAHGV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/bqpfGFAHGV",
        "expanded_url" : "http:\/\/www.engadget.com\/2015\/12\/07\/adobe-lightroom-mobile-android-free\/",
        "display_url" : "engadget.com\/2015\/12\/07\/ado\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673881462156886016",
    "text" : "Adobe Lightroom mobile on Android is now available for free https:\/\/t.co\/bqpfGFAHGV",
    "id" : 673881462156886016,
    "created_at" : "2015-12-07 15:07:15 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 673884708221132800,
  "created_at" : "2015-12-07 15:20:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 0, 9 ],
      "id_str" : "17468189",
      "id" : 17468189
    }, {
      "name" : "Luvo",
      "screen_name" : "luvolearn",
      "indices" : [ 10, 20 ],
      "id_str" : "68724544",
      "id" : 68724544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/673618574448140289\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/FVD6iw9KL3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVkshhrWUAECxBy.jpg",
      "id_str" : "673618573756092417",
      "id" : 673618573756092417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVkshhrWUAECxBy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/FVD6iw9KL3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673618574448140289",
  "in_reply_to_user_id" : 17468189,
  "text" : "@Oaklandu @luvolearn Thanks for the free tutoring I guess https:\/\/t.co\/FVD6iw9KL3",
  "id" : 673618574448140289,
  "created_at" : "2015-12-06 21:42:38 +0000",
  "in_reply_to_screen_name" : "oaklandu",
  "in_reply_to_user_id_str" : "17468189",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673309226492493824",
  "text" : "RT @God_Instagram: Everyday I thank God for giving me another day to live, and another chance to make a difference.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673307336610480128",
    "text" : "Everyday I thank God for giving me another day to live, and another chance to make a difference.",
    "id" : 673307336610480128,
    "created_at" : "2015-12-06 01:05:53 +0000",
    "user" : {
      "name" : "God Almighty",
      "screen_name" : "101BibleVerses",
      "protected" : false,
      "id_str" : "144078841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691289870187114496\/TlmB9qj6_normal.jpg",
      "id" : 144078841,
      "verified" : false
    }
  },
  "id" : 673309226492493824,
  "created_at" : "2015-12-06 01:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Style Details",
      "screen_name" : "StyleDetails",
      "indices" : [ 3, 16 ],
      "id_str" : "582753822",
      "id" : 582753822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/qAU6IKcDRS",
      "expanded_url" : "https:\/\/twitter.com\/OutfitHaven\/status\/528324294531506177\/photo\/1",
      "display_url" : "pic.twitter.com\/qAU6IKcDRS"
    } ]
  },
  "geo" : { },
  "id_str" : "673309157735440384",
  "text" : "RT @StyleDetails: two kinds of people in this world https:\/\/t.co\/qAU6IKcDRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/qAU6IKcDRS",
        "expanded_url" : "https:\/\/twitter.com\/OutfitHaven\/status\/528324294531506177\/photo\/1",
        "display_url" : "pic.twitter.com\/qAU6IKcDRS"
      } ]
    },
    "geo" : { },
    "id_str" : "673308466036006912",
    "text" : "two kinds of people in this world https:\/\/t.co\/qAU6IKcDRS",
    "id" : 673308466036006912,
    "created_at" : "2015-12-06 01:10:22 +0000",
    "user" : {
      "name" : "Style Details",
      "screen_name" : "StyleDetails",
      "protected" : false,
      "id_str" : "582753822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659028387147616256\/QLCOuOTT_normal.jpg",
      "id" : 582753822,
      "verified" : false
    }
  },
  "id" : 673309157735440384,
  "created_at" : "2015-12-06 01:13:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "indices" : [ 3, 16 ],
      "id_str" : "24664726",
      "id" : 24664726
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsGoHeat",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673309089867395073",
  "text" : "RT @andykleinman: LeBron is scared #LetsGoHeat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsGoHeat",
        "indices" : [ 17, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673308938310258688",
    "text" : "LeBron is scared #LetsGoHeat",
    "id" : 673308938310258688,
    "created_at" : "2015-12-06 01:12:15 +0000",
    "user" : {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "protected" : false,
      "id_str" : "24664726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866530832315408384\/h0ORI03N_normal.jpg",
      "id" : 24664726,
      "verified" : true
    }
  },
  "id" : 673309089867395073,
  "created_at" : "2015-12-06 01:12:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/AiesPJjeU5",
      "expanded_url" : "http:\/\/klou.tt\/uivf2j9sr00i",
      "display_url" : "klou.tt\/uivf2j9sr00i"
    } ]
  },
  "geo" : { },
  "id_str" : "673308367545221120",
  "text" : "Android mastermind Andy Rubin may be starting his own smartphone company - https:\/\/t.co\/AiesPJjeU5",
  "id" : 673308367545221120,
  "created_at" : "2015-12-06 01:09:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/NBmpuoKfHY",
      "expanded_url" : "http:\/\/klou.tt\/1c3kfjx5yc782",
      "display_url" : "klou.tt\/1c3kfjx5yc782"
    } ]
  },
  "geo" : { },
  "id_str" : "673308236653531136",
  "text" : "Top 10 Ways to Browse the Web Better on Your Phone - https:\/\/t.co\/NBmpuoKfHY",
  "id" : 673308236653531136,
  "created_at" : "2015-12-06 01:09:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/OkgKWlB4dE",
      "expanded_url" : "http:\/\/klou.tt\/1wss442y5y49n",
      "display_url" : "klou.tt\/1wss442y5y49n"
    } ]
  },
  "geo" : { },
  "id_str" : "673308099986329600",
  "text" : "Edward Snowden to speak to Park City audience about cybersecurity - https:\/\/t.co\/OkgKWlB4dE",
  "id" : 673308099986329600,
  "created_at" : "2015-12-06 01:08:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/er86O45v66",
      "expanded_url" : "http:\/\/klou.tt\/19jg27e890rth",
      "display_url" : "klou.tt\/19jg27e890rth"
    } ]
  },
  "geo" : { },
  "id_str" : "673308078033408001",
  "text" : "After Apple open sources it, IBM puts Swift programming in the cloud - https:\/\/t.co\/er86O45v66",
  "id" : 673308078033408001,
  "created_at" : "2015-12-06 01:08:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/klout.com\" rel=\"nofollow\"\u003EPost with Klout\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/21FNeq3LKC",
      "expanded_url" : "http:\/\/klou.tt\/276719mx7ykh",
      "display_url" : "klou.tt\/276719mx7ykh"
    } ]
  },
  "geo" : { },
  "id_str" : "673307991358050304",
  "text" : "Square Enix Montreal's Lara Croft Go wins Best Mobile Game at 2015 Game Awards - https:\/\/t.co\/21FNeq3LKC",
  "id" : 673307991358050304,
  "created_at" : "2015-12-06 01:08:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LXRY APPVREL",
      "screen_name" : "LXRYAPPVREL_",
      "indices" : [ 3, 16 ],
      "id_str" : "2249258984",
      "id" : 2249258984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673245202828697600",
  "text" : "RT @LXRYAPPVREL_: Do it with passion or don't do it at all..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673235228513673216",
    "text" : "Do it with passion or don't do it at all..",
    "id" : 673235228513673216,
    "created_at" : "2015-12-05 20:19:21 +0000",
    "user" : {
      "name" : "LXRY APPVREL",
      "screen_name" : "LXRYAPPVREL_",
      "protected" : false,
      "id_str" : "2249258984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812085540866686976\/_fXFsKaY_normal.jpg",
      "id" : 2249258984,
      "verified" : false
    }
  },
  "id" : 673245202828697600,
  "created_at" : "2015-12-05 20:58:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "indices" : [ 3, 14 ],
      "id_str" : "1685698238",
      "id" : 1685698238
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672956204751192066",
  "text" : "RT @PHPSimplex: @gamer456148 until you understand well the methodology. Then it's very easy (only simple operations) and doesn't waste much\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672792515981025281",
    "geo" : { },
    "id_str" : "672905659072053248",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 until you understand well the methodology. Then it's very easy (only simple operations) and doesn't waste much time.",
    "id" : 672905659072053248,
    "in_reply_to_status_id" : 672792515981025281,
    "created_at" : "2015-12-04 22:29:45 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "protected" : false,
      "id_str" : "1685698238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000328895370\/ac13e7a886c26f645af34c01324f00ab_normal.png",
      "id" : 1685698238,
      "verified" : false
    }
  },
  "id" : 672956204751192066,
  "created_at" : "2015-12-05 01:50:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672792515981025281",
  "text" : "The Simplex Method is far more time consuming than some other mathematical methods I used",
  "id" : 672792515981025281,
  "created_at" : "2015-12-04 15:00:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#kindly follow back",
      "screen_name" : "hugo_glitz",
      "indices" : [ 0, 11 ],
      "id_str" : "2994197830",
      "id" : 2994197830
    }, {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 12, 23 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672227775357435905",
  "geo" : { },
  "id_str" : "672518804916871168",
  "in_reply_to_user_id" : 2994197830,
  "text" : "@hugo_glitz @Eniolasays @ForTheGist #1 It spies on you just like all computers, lol",
  "id" : 672518804916871168,
  "in_reply_to_status_id" : 672227775357435905,
  "created_at" : "2015-12-03 20:52:32 +0000",
  "in_reply_to_screen_name" : "hugo_glitz",
  "in_reply_to_user_id_str" : "2994197830",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CREATE",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672518502079725570",
  "text" : "I paid $7.30 for a wrap and it wasn't even filling, there has got to be a better way #CREATE",
  "id" : 672518502079725570,
  "created_at" : "2015-12-03 20:51:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekNation",
      "screen_name" : "GeekNation",
      "indices" : [ 0, 11 ],
      "id_str" : "15968048",
      "id" : 15968048
    }, {
      "name" : "Mark Hamill",
      "screen_name" : "HamillHimself",
      "indices" : [ 12, 26 ],
      "id_str" : "304679484",
      "id" : 304679484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672465311887523840",
  "geo" : { },
  "id_str" : "672465868710875136",
  "in_reply_to_user_id" : 15968048,
  "text" : "@GeekNation @HamillHimself Oh my goodness, he looks like Humpty Dumpty",
  "id" : 672465868710875136,
  "in_reply_to_status_id" : 672465311887523840,
  "created_at" : "2015-12-03 17:22:11 +0000",
  "in_reply_to_screen_name" : "GeekNation",
  "in_reply_to_user_id_str" : "15968048",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekNation",
      "screen_name" : "GeekNation",
      "indices" : [ 3, 14 ],
      "id_str" : "15968048",
      "id" : 15968048
    }, {
      "name" : "Mark Hamill",
      "screen_name" : "HamillHimself",
      "indices" : [ 23, 37 ],
      "id_str" : "304679484",
      "id" : 304679484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ForceForChange",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/va40XWodor",
      "expanded_url" : "http:\/\/geeknation.com\/wwwww\/",
      "display_url" : "geeknation.com\/wwwww\/"
    } ]
  },
  "geo" : { },
  "id_str" : "672465767946956800",
  "text" : "RT @GeekNation: WATCH: @HamillHimself disguises himself as a stormtrooper in new #ForceForChange video! https:\/\/t.co\/va40XWodor https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Hamill",
        "screen_name" : "HamillHimself",
        "indices" : [ 7, 21 ],
        "id_str" : "304679484",
        "id" : 304679484
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GeekNation\/status\/672465311887523840\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/xSfN8fKXfC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVUTozYUAAE1xE8.png",
        "id_str" : "672465311069634561",
        "id" : 672465311069634561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVUTozYUAAE1xE8.png",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1366
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/xSfN8fKXfC"
      } ],
      "hashtags" : [ {
        "text" : "ForceForChange",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/va40XWodor",
        "expanded_url" : "http:\/\/geeknation.com\/wwwww\/",
        "display_url" : "geeknation.com\/wwwww\/"
      } ]
    },
    "geo" : { },
    "id_str" : "672465311887523840",
    "text" : "WATCH: @HamillHimself disguises himself as a stormtrooper in new #ForceForChange video! https:\/\/t.co\/va40XWodor https:\/\/t.co\/xSfN8fKXfC",
    "id" : 672465311887523840,
    "created_at" : "2015-12-03 17:19:58 +0000",
    "user" : {
      "name" : "GeekNation",
      "screen_name" : "GeekNation",
      "protected" : false,
      "id_str" : "15968048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615677451440525312\/Z7MJwl7c_normal.png",
      "id" : 15968048,
      "verified" : false
    }
  },
  "id" : 672465767946956800,
  "created_at" : "2015-12-03 17:21:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 3, 16 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672153891920834561",
  "text" : "RT @LinkedInHelp: @gamer456148 That is definitely understandable. We'll pass this suggestion on to our team! -jlk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672147796322029570",
    "geo" : { },
    "id_str" : "672152818258702336",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 That is definitely understandable. We'll pass this suggestion on to our team! -jlk",
    "id" : 672152818258702336,
    "in_reply_to_status_id" : 672147796322029570,
    "created_at" : "2015-12-02 20:38:14 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "protected" : false,
      "id_str" : "252792134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991135365988667392\/JXDDdlqf_normal.jpg",
      "id" : 252792134,
      "verified" : true
    }
  },
  "id" : 672153891920834561,
  "created_at" : "2015-12-02 20:42:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Art",
      "screen_name" : "SaatchiArt",
      "indices" : [ 3, 14 ],
      "id_str" : "77740842",
      "id" : 77740842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiamiArtWeek",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/LoQBrwItpt",
      "expanded_url" : "http:\/\/bit.ly\/1T1e461",
      "display_url" : "bit.ly\/1T1e461"
    } ]
  },
  "geo" : { },
  "id_str" : "672149983039242240",
  "text" : "RT @SaatchiArt: Do you follow us on Instagram? Follow along to see exclusive photos from #MiamiArtWeek: https:\/\/t.co\/LoQBrwItpt https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SaatchiArt\/status\/672148664832229376\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/v1OvcwkArX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVPzpiJVEAAS7Hb.png",
        "id_str" : "672148664274456576",
        "id" : 672148664274456576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVPzpiJVEAAS7Hb.png",
        "sizes" : [ {
          "h" : 599,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/v1OvcwkArX"
      } ],
      "hashtags" : [ {
        "text" : "MiamiArtWeek",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/LoQBrwItpt",
        "expanded_url" : "http:\/\/bit.ly\/1T1e461",
        "display_url" : "bit.ly\/1T1e461"
      } ]
    },
    "geo" : { },
    "id_str" : "672148664832229376",
    "text" : "Do you follow us on Instagram? Follow along to see exclusive photos from #MiamiArtWeek: https:\/\/t.co\/LoQBrwItpt https:\/\/t.co\/v1OvcwkArX",
    "id" : 672148664832229376,
    "created_at" : "2015-12-02 20:21:44 +0000",
    "user" : {
      "name" : "Saatchi Art",
      "screen_name" : "SaatchiArt",
      "protected" : false,
      "id_str" : "77740842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617007773709041664\/OY313ZYA_normal.png",
      "id" : 77740842,
      "verified" : false
    }
  },
  "id" : 672149983039242240,
  "created_at" : "2015-12-02 20:26:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fatima Zehra",
      "screen_name" : "itsfatimazehra",
      "indices" : [ 3, 18 ],
      "id_str" : "837754526581022720",
      "id" : 837754526581022720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/uF1F2jD9Sx",
      "expanded_url" : "https:\/\/instagram.com\/p\/-SoniDEEm_\/",
      "display_url" : "instagram.com\/p\/-SoniDEEm_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "672148940930859008",
  "text" : "RT @itsfatimazehra: Bridging the gap \u2600\uFE0F\uD83D\uDCA6 @ Lagos, Portugal https:\/\/t.co\/uF1F2jD9Sx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/uF1F2jD9Sx",
        "expanded_url" : "https:\/\/instagram.com\/p\/-SoniDEEm_\/",
        "display_url" : "instagram.com\/p\/-SoniDEEm_\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.1, -8.66667 ]
    },
    "id_str" : "667541553938890752",
    "text" : "Bridging the gap \u2600\uFE0F\uD83D\uDCA6 @ Lagos, Portugal https:\/\/t.co\/uF1F2jD9Sx",
    "id" : 667541553938890752,
    "created_at" : "2015-11-20 03:14:43 +0000",
    "user" : {
      "name" : "Fatima Zehra",
      "screen_name" : "souloforion",
      "protected" : false,
      "id_str" : "580004857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852613813568495616\/-JuIilF2_normal.jpg",
      "id" : 580004857,
      "verified" : false
    }
  },
  "id" : 672148940930859008,
  "created_at" : "2015-12-02 20:22:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Conner",
      "screen_name" : "mrsajconner",
      "indices" : [ 3, 15 ],
      "id_str" : "47734480",
      "id" : 47734480
    }, {
      "name" : "BBC Radio 4",
      "screen_name" : "BBCRadio4",
      "indices" : [ 17, 27 ],
      "id_str" : "23937508",
      "id" : 23937508
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 108, 120 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672148855840985088",
  "text" : "RT @mrsajconner: @BBCRadio4 drawing for  'The Truth is a Cave in the Black Mountains' by the wonderful Neil @neilhimself https:\/\/t.co\/xS1VP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Radio 4",
        "screen_name" : "BBCRadio4",
        "indices" : [ 0, 10 ],
        "id_str" : "23937508",
        "id" : 23937508
      }, {
        "name" : "Neil Gaiman",
        "screen_name" : "neilhimself",
        "indices" : [ 91, 103 ],
        "id_str" : "18393773",
        "id" : 18393773
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mrsajconner\/status\/671710652214484993\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/xS1VPVdxQZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJlRxBWIAAv4aE.jpg",
        "id_str" : "671710650322788352",
        "id" : 671710650322788352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJlRxBWIAAv4aE.jpg",
        "sizes" : [ {
          "h" : 655,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1980
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1980
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/xS1VPVdxQZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671710652214484993",
    "in_reply_to_user_id" : 23937508,
    "text" : "@BBCRadio4 drawing for  'The Truth is a Cave in the Black Mountains' by the wonderful Neil @neilhimself https:\/\/t.co\/xS1VPVdxQZ",
    "id" : 671710652214484993,
    "created_at" : "2015-12-01 15:21:13 +0000",
    "in_reply_to_screen_name" : "BBCRadio4",
    "in_reply_to_user_id_str" : "23937508",
    "user" : {
      "name" : "Allison Conner",
      "screen_name" : "mrsajconner",
      "protected" : false,
      "id_str" : "47734480",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649638560941895680\/n_p_xKNO_normal.jpg",
      "id" : 47734480,
      "verified" : false
    }
  },
  "id" : 672148855840985088,
  "created_at" : "2015-12-02 20:22:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672147796322029570",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp The new LinkedIn redesign is good but I would want my whole profile to be mobile not some of it cut off, it makes me concerned",
  "id" : 672147796322029570,
  "created_at" : "2015-12-02 20:18:17 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672147567594049537",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp Some people list their partner companies or subsidies as orgs, so removing it from mobile didn't give me a pleasant surprise",
  "id" : 672147567594049537,
  "created_at" : "2015-12-02 20:17:22 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672147265251856384",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp The thing is organizations and causes I support were both removed from the new mobile design, those were important",
  "id" : 672147265251856384,
  "created_at" : "2015-12-02 20:16:10 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]