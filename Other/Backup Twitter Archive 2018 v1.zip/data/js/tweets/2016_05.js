Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 0, 7 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734880779214409729",
  "geo" : { },
  "id_str" : "737739814661918721",
  "in_reply_to_user_id" : 13334762,
  "text" : "@github I loved this feature for one of my Hackathon projects",
  "id" : 737739814661918721,
  "in_reply_to_status_id" : 734880779214409729,
  "created_at" : "2016-05-31 20:17:33 +0000",
  "in_reply_to_screen_name" : "github",
  "in_reply_to_user_id_str" : "13334762",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/DgaaLKfwDM",
      "expanded_url" : "https:\/\/github.com\/blog\/2170-repository-invitations",
      "display_url" : "github.com\/blog\/2170-repo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737739735418949632",
  "text" : "RT @github: Collaborate with those you trust: Repository Invites https:\/\/t.co\/DgaaLKfwDM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hubot.github.com\/\" rel=\"nofollow\"\u003EThe Danger Room\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/DgaaLKfwDM",
        "expanded_url" : "https:\/\/github.com\/blog\/2170-repository-invitations",
        "display_url" : "github.com\/blog\/2170-repo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734880779214409729",
    "text" : "Collaborate with those you trust: Repository Invites https:\/\/t.co\/DgaaLKfwDM",
    "id" : 734880779214409729,
    "created_at" : "2016-05-23 22:56:45 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616309728688238592\/pBeeJQDQ_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 737739735418949632,
  "created_at" : "2016-05-31 20:17:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 3, 10 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/3gksv0N7Yi",
      "expanded_url" : "https:\/\/github.com\/blog\/2178-multiple-assignees-on-issues-and-pull-requests?utm_source=twitter&utm_medium=social&utm_campaign=multiple-assignees",
      "display_url" : "github.com\/blog\/2178-mult\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737739696583888896",
  "text" : "RT @github: Some tasks take a team\u2014now you can assign issues and pull requests to up to ten users: https:\/\/t.co\/3gksv0N7Yi https:\/\/t.co\/FwY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/github\/status\/736245647871860736\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/FwYZaiVzWd",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjerZcDUkAA0xXf.jpg",
        "id_str" : "736245517613568000",
        "id" : 736245517613568000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjerZcDUkAA0xXf.jpg",
        "sizes" : [ {
          "h" : 610,
          "resize" : "fit",
          "w" : 1056
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 1056
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 1056
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/FwYZaiVzWd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/3gksv0N7Yi",
        "expanded_url" : "https:\/\/github.com\/blog\/2178-multiple-assignees-on-issues-and-pull-requests?utm_source=twitter&utm_medium=social&utm_campaign=multiple-assignees",
        "display_url" : "github.com\/blog\/2178-mult\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736245647871860736",
    "text" : "Some tasks take a team\u2014now you can assign issues and pull requests to up to ten users: https:\/\/t.co\/3gksv0N7Yi https:\/\/t.co\/FwYZaiVzWd",
    "id" : 736245647871860736,
    "created_at" : "2016-05-27 17:20:15 +0000",
    "user" : {
      "name" : "GitHub",
      "screen_name" : "github",
      "protected" : false,
      "id_str" : "13334762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616309728688238592\/pBeeJQDQ_normal.png",
      "id" : 13334762,
      "verified" : true
    }
  },
  "id" : 737739696583888896,
  "created_at" : "2016-05-31 20:17:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Play",
      "screen_name" : "GooglePlay",
      "indices" : [ 0, 11 ],
      "id_str" : "243381107",
      "id" : 243381107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737739593521504256",
  "in_reply_to_user_id" : 243381107,
  "text" : "@GooglePlay When will Google Play have realtime stats and be mobile optimized, that update would be awesome :P",
  "id" : 737739593521504256,
  "created_at" : "2016-05-31 20:16:40 +0000",
  "in_reply_to_screen_name" : "GooglePlay",
  "in_reply_to_user_id_str" : "243381107",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737506748899024896",
  "text" : "RT @lorenridinger: \"Leadership is an action, not a position.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737463764870664193",
    "text" : "\"Leadership is an action, not a position.\"",
    "id" : 737463764870664193,
    "created_at" : "2016-05-31 02:00:37 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 737506748899024896,
  "created_at" : "2016-05-31 04:51:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC7D\u00C3\u0144t\u00EF-\u0160\u0119pt\u00EF\u00E7-\u0119\u00FFe\uD83D\uDC7D",
      "screen_name" : "06451Emerson",
      "indices" : [ 3, 16 ],
      "id_str" : "1072015363",
      "id" : 1072015363
    }, {
      "name" : "HelloRyanHolmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 18, 34 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/06451Emerson\/status\/737456025717080064\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/YCwL8Cpy5j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjv4WF-XEAATeYF.jpg",
      "id_str" : "737456022449754112",
      "id" : 737456022449754112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjv4WF-XEAATeYF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/YCwL8Cpy5j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737506671652528128",
  "text" : "RT @06451Emerson: @HelloRyanHolmes https:\/\/t.co\/YCwL8Cpy5j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HelloRyanHolmes",
        "screen_name" : "HelloRyanHolmes",
        "indices" : [ 0, 16 ],
        "id_str" : "32809159",
        "id" : 32809159
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/06451Emerson\/status\/737456025717080064\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/YCwL8Cpy5j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjv4WF-XEAATeYF.jpg",
        "id_str" : "737456022449754112",
        "id" : 737456022449754112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjv4WF-XEAATeYF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/YCwL8Cpy5j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737456025717080064",
    "in_reply_to_user_id" : 32809159,
    "text" : "@HelloRyanHolmes https:\/\/t.co\/YCwL8Cpy5j",
    "id" : 737456025717080064,
    "created_at" : "2016-05-31 01:29:52 +0000",
    "in_reply_to_screen_name" : "HelloRyanHolmes",
    "in_reply_to_user_id_str" : "32809159",
    "user" : {
      "name" : "\uD83D\uDC7D\u00C3\u0144t\u00EF-\u0160\u0119pt\u00EF\u00E7-\u0119\u00FFe\uD83D\uDC7D",
      "screen_name" : "06451Emerson",
      "protected" : false,
      "id_str" : "1072015363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991795858407649282\/knquaQ5s_normal.jpg",
      "id" : 1072015363,
      "verified" : false
    }
  },
  "id" : 737506671652528128,
  "created_at" : "2016-05-31 04:51:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "indices" : [ 3, 17 ],
      "id_str" : "34356320",
      "id" : 34356320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737506629365551105",
  "text" : "RT @jorgevictoria: I don't regret my past because it made me stronger.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737467446978809858",
    "text" : "I don't regret my past because it made me stronger.",
    "id" : 737467446978809858,
    "created_at" : "2016-05-31 02:15:15 +0000",
    "user" : {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "protected" : false,
      "id_str" : "34356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/941167491241398273\/72oSkHhB_normal.jpg",
      "id" : 34356320,
      "verified" : false
    }
  },
  "id" : 737506629365551105,
  "created_at" : "2016-05-31 04:50:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Diggs",
      "screen_name" : "CTDGRAPHICMAN",
      "indices" : [ 3, 17 ],
      "id_str" : "88804144",
      "id" : 88804144
    }, {
      "name" : "Porsha Williams",
      "screen_name" : "Porsha4real",
      "indices" : [ 38, 50 ],
      "id_str" : "614554301",
      "id" : 614554301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CTDGRAPHICMAN\/status\/639494491574018048\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0XSgk4yZP3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_w2exUAAAgPlN.jpg",
      "id_str" : "639494490873397248",
      "id" : 639494490873397248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_w2exUAAAgPlN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/0XSgk4yZP3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737505839720730624",
  "text" : "RT @CTDGRAPHICMAN: Cartoon picture of @Porsha4real I just did what do you think??? http:\/\/t.co\/0XSgk4yZP3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Porsha Williams",
        "screen_name" : "Porsha4real",
        "indices" : [ 19, 31 ],
        "id_str" : "614554301",
        "id" : 614554301
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CTDGRAPHICMAN\/status\/639494491574018048\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/0XSgk4yZP3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN_w2exUAAAgPlN.jpg",
        "id_str" : "639494490873397248",
        "id" : 639494490873397248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN_w2exUAAAgPlN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/0XSgk4yZP3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "639494491574018048",
    "text" : "Cartoon picture of @Porsha4real I just did what do you think??? http:\/\/t.co\/0XSgk4yZP3",
    "id" : 639494491574018048,
    "created_at" : "2015-09-03 17:45:42 +0000",
    "user" : {
      "name" : "Casey Diggs",
      "screen_name" : "CTDGRAPHICMAN",
      "protected" : false,
      "id_str" : "88804144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/962898563649880064\/2UIN-uwN_normal.jpg",
      "id" : 88804144,
      "verified" : false
    }
  },
  "id" : 737505839720730624,
  "created_at" : "2016-05-31 04:47:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737480422762905600",
  "geo" : { },
  "id_str" : "737505085798780929",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo That movie though",
  "id" : 737505085798780929,
  "in_reply_to_status_id" : 737480422762905600,
  "created_at" : "2016-05-31 04:44:49 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias",
      "screen_name" : "Matthiasiam",
      "indices" : [ 0, 12 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737480471601283072",
  "geo" : { },
  "id_str" : "737504984053354496",
  "in_reply_to_user_id" : 44184316,
  "text" : "@Matthiasiam Linux or Windows?",
  "id" : 737504984053354496,
  "in_reply_to_status_id" : 737480471601283072,
  "created_at" : "2016-05-31 04:44:25 +0000",
  "in_reply_to_screen_name" : "Matthiasiam",
  "in_reply_to_user_id_str" : "44184316",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Evans",
      "screen_name" : "JustinJumpstart",
      "indices" : [ 3, 19 ],
      "id_str" : "62087551",
      "id" : 62087551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737504714263138306",
  "text" : "RT @JustinJumpstart: For God called you to do good, even if it means suffering, just as Christ suffered for you. \/\/ 1 Peter 2:21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737456468115361793",
    "text" : "For God called you to do good, even if it means suffering, just as Christ suffered for you. \/\/ 1 Peter 2:21",
    "id" : 737456468115361793,
    "created_at" : "2016-05-31 01:31:37 +0000",
    "user" : {
      "name" : "Justin Evans",
      "screen_name" : "JustinJumpstart",
      "protected" : false,
      "id_str" : "62087551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856809645918355456\/70o1LBMu_normal.jpg",
      "id" : 62087551,
      "verified" : false
    }
  },
  "id" : 737504714263138306,
  "created_at" : "2016-05-31 04:43:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737503449835671552",
  "text" : "RT @lorenridinger: \"Effective leadership is putting first things first. Effective management is discipline, carrying it out.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737493930468511745",
    "text" : "\"Effective leadership is putting first things first. Effective management is discipline, carrying it out.\"",
    "id" : 737493930468511745,
    "created_at" : "2016-05-31 04:00:29 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 737503449835671552,
  "created_at" : "2016-05-31 04:38:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skip Bayless",
      "screen_name" : "RealSkipBayless",
      "indices" : [ 3, 19 ],
      "id_str" : "43139414",
      "id" : 43139414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737503406521094145",
  "text" : "RT @RealSkipBayless: Somewhere, LeBron James is thinking, \"Oh, no.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737485811705384960",
    "text" : "Somewhere, LeBron James is thinking, \"Oh, no.\"",
    "id" : 737485811705384960,
    "created_at" : "2016-05-31 03:28:13 +0000",
    "user" : {
      "name" : "Skip Bayless",
      "screen_name" : "RealSkipBayless",
      "protected" : false,
      "id_str" : "43139414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778012625858768897\/HE2EmvNo_normal.jpg",
      "id" : 43139414,
      "verified" : true
    }
  },
  "id" : 737503406521094145,
  "created_at" : "2016-05-31 04:38:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737438426681769984",
  "text" : "RT @tedcruz: It's their sacrifice that calls us to cherish the gift of liberty. We must never take it for granted. #MemorialDay https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/737284915843063808\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/oVKNnSwQlB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjtcuFNUoAEWHGf.jpg",
        "id_str" : "737284910747000833",
        "id" : 737284910747000833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjtcuFNUoAEWHGf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/oVKNnSwQlB"
      } ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737284915843063808",
    "text" : "It's their sacrifice that calls us to cherish the gift of liberty. We must never take it for granted. #MemorialDay https:\/\/t.co\/oVKNnSwQlB",
    "id" : 737284915843063808,
    "created_at" : "2016-05-30 14:09:56 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 737438426681769984,
  "created_at" : "2016-05-31 00:19:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master INJO",
      "screen_name" : "INJO",
      "indices" : [ 3, 8 ],
      "id_str" : "752580650297880576",
      "id" : 752580650297880576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/6SA5JvY6ii",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/dd09024c-6233-4360-8c3c-59e3854621e7",
      "display_url" : "amp.twimg.com\/v\/dd09024c-623\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737438403558510592",
  "text" : "RT @INJO: On this day https:\/\/t.co\/6SA5JvY6ii",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/6SA5JvY6ii",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/dd09024c-6233-4360-8c3c-59e3854621e7",
        "display_url" : "amp.twimg.com\/v\/dd09024c-623\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737350722098892804",
    "text" : "On this day https:\/\/t.co\/6SA5JvY6ii",
    "id" : 737350722098892804,
    "created_at" : "2016-05-30 18:31:26 +0000",
    "user" : {
      "name" : "IJR",
      "screen_name" : "TheIJR",
      "protected" : false,
      "id_str" : "474464413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875405688989732870\/FEyVkYJc_normal.jpg",
      "id" : 474464413,
      "verified" : true
    }
  },
  "id" : 737438403558510592,
  "created_at" : "2016-05-31 00:19:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VISIT FLORIDA",
      "screen_name" : "VISITFLORIDA",
      "indices" : [ 0, 13 ],
      "id_str" : "14385055",
      "id" : 14385055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737335524134772736",
  "geo" : { },
  "id_str" : "737361219535798272",
  "in_reply_to_user_id" : 14385055,
  "text" : "@VISITFLORIDA For me it already started, but I think I'd rather visit Birmingham, Alabama",
  "id" : 737361219535798272,
  "in_reply_to_status_id" : 737335524134772736,
  "created_at" : "2016-05-30 19:13:08 +0000",
  "in_reply_to_screen_name" : "VISITFLORIDA",
  "in_reply_to_user_id_str" : "14385055",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VISIT FLORIDA",
      "screen_name" : "VISITFLORIDA",
      "indices" : [ 3, 16 ],
      "id_str" : "14385055",
      "id" : 14385055
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VISITFLORIDA\/status\/737335524134772736\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/oU9vNfx7l6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjexdRFWUAIsXlc.jpg",
      "id_str" : "736252180458524674",
      "id" : 736252180458524674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjexdRFWUAIsXlc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/oU9vNfx7l6"
    } ],
    "hashtags" : [ {
      "text" : "SummerStartsNow",
      "indices" : [ 55, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737361056528375810",
  "text" : "RT @VISITFLORIDA: That look you give when someone says #SummerStartsNow. https:\/\/t.co\/oU9vNfx7l6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VISITFLORIDA\/status\/737335524134772736\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/oU9vNfx7l6",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjexdRFWUAIsXlc.jpg",
        "id_str" : "736252180458524674",
        "id" : 736252180458524674,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjexdRFWUAIsXlc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/oU9vNfx7l6"
      } ],
      "hashtags" : [ {
        "text" : "SummerStartsNow",
        "indices" : [ 37, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737335524134772736",
    "text" : "That look you give when someone says #SummerStartsNow. https:\/\/t.co\/oU9vNfx7l6",
    "id" : 737335524134772736,
    "created_at" : "2016-05-30 17:31:02 +0000",
    "user" : {
      "name" : "VISIT FLORIDA",
      "screen_name" : "VISITFLORIDA",
      "protected" : false,
      "id_str" : "14385055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/985300329540579328\/wUoHuhja_normal.jpg",
      "id" : 14385055,
      "verified" : true
    }
  },
  "id" : 737361056528375810,
  "created_at" : "2016-05-30 19:12:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/PV5HDSh3I5",
      "expanded_url" : "http:\/\/engt.co\/1X1X5qb",
      "display_url" : "engt.co\/1X1X5qb"
    } ]
  },
  "geo" : { },
  "id_str" : "737343452321566721",
  "text" : "RT @engadget: Dell's 43-inch monitor is made for traders, but you can use it to play four games at once https:\/\/t.co\/PV5HDSh3I5 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/737026872702275584\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/a8I6T7vt6y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjpyCQFWkAA4NI3.jpg",
        "id_str" : "737026872031219712",
        "id" : 737026872031219712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjpyCQFWkAA4NI3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/a8I6T7vt6y"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/PV5HDSh3I5",
        "expanded_url" : "http:\/\/engt.co\/1X1X5qb",
        "display_url" : "engt.co\/1X1X5qb"
      } ]
    },
    "geo" : { },
    "id_str" : "737026872702275584",
    "text" : "Dell's 43-inch monitor is made for traders, but you can use it to play four games at once https:\/\/t.co\/PV5HDSh3I5 https:\/\/t.co\/a8I6T7vt6y",
    "id" : 737026872702275584,
    "created_at" : "2016-05-29 21:04:34 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 737343452321566721,
  "created_at" : "2016-05-30 18:02:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/737343390115889153\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/DF1TzS3Qsy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuR5-zUkAA4-ms.jpg",
      "id_str" : "737343389302034432",
      "id" : 737343389302034432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuR5-zUkAA4-ms.jpg",
      "sizes" : [ {
        "h" : 621,
        "resize" : "fit",
        "w" : 1104
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 1104
      }, {
        "h" : 621,
        "resize" : "fit",
        "w" : 1104
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/DF1TzS3Qsy"
    } ],
    "hashtags" : [ {
      "text" : "Learn",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "Business",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "Stocks",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737343390115889153",
  "text" : "Trying to learn trading and investing in the summer #Learn #Business #Stocks https:\/\/t.co\/DF1TzS3Qsy",
  "id" : 737343390115889153,
  "created_at" : "2016-05-30 18:02:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/736651135981916160\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/mZeCz1Z3Cp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkcSqpVAAAa5Pm.jpg",
      "id_str" : "736651121062641664",
      "id" : 736651121062641664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkcSqpVAAAa5Pm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/mZeCz1Z3Cp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736651135981916160",
  "text" : "Tried the Fajita Chicken at Buddy's: 3.84\/5 stars https:\/\/t.co\/mZeCz1Z3Cp",
  "id" : 736651135981916160,
  "created_at" : "2016-05-28 20:11:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736642822963646464",
  "geo" : { },
  "id_str" : "736643316129923073",
  "in_reply_to_user_id" : 102408319,
  "text" : "@___aptx That used to be me, lol",
  "id" : 736643316129923073,
  "in_reply_to_status_id" : 736642822963646464,
  "created_at" : "2016-05-28 19:40:27 +0000",
  "in_reply_to_screen_name" : "ayyydi",
  "in_reply_to_user_id_str" : "102408319",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/736643172961517570\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/udeX7qJMJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkVDO_WkAIu3sV.jpg",
      "id_str" : "736643159359393794",
      "id" : 736643159359393794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkVDO_WkAIu3sV.jpg",
      "sizes" : [ {
        "h" : 875,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 497
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/udeX7qJMJ5"
    } ],
    "hashtags" : [ {
      "text" : "Awesomeness",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736643172961517570",
  "text" : "Second time trending #Awesomeness https:\/\/t.co\/udeX7qJMJ5",
  "id" : 736643172961517570,
  "created_at" : "2016-05-28 19:39:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ajiona Alexus",
      "screen_name" : "AjionaAlexus",
      "indices" : [ 3, 16 ],
      "id_str" : "521669982",
      "id" : 521669982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736279655758462976",
  "text" : "RT @AjionaAlexus: Never trade respect for attention.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736235579772444672",
    "text" : "Never trade respect for attention.",
    "id" : 736235579772444672,
    "created_at" : "2016-05-27 16:40:15 +0000",
    "user" : {
      "name" : "Ajiona Alexus",
      "screen_name" : "AjionaAlexus",
      "protected" : false,
      "id_str" : "521669982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845195849701347328\/x2TXUOAs_normal.jpg",
      "id" : 521669982,
      "verified" : true
    }
  },
  "id" : 736279655758462976,
  "created_at" : "2016-05-27 19:35:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TF_F",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736259931561693184",
  "text" : "RT @HamzeiAnalytics: BLOCK TRADE detected in #TF_F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TF_F",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736259164532396034",
    "text" : "BLOCK TRADE detected in #TF_F",
    "id" : 736259164532396034,
    "created_at" : "2016-05-27 18:13:58 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 736259931561693184,
  "created_at" : "2016-05-27 18:17:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736258215374098432",
  "text" : "RT @RonnieMGreen: Taking a break until 2:30Pm. Looking for my next overnight strategy trade! stay tuned",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736245980731842561",
    "text" : "Taking a break until 2:30Pm. Looking for my next overnight strategy trade! stay tuned",
    "id" : 736245980731842561,
    "created_at" : "2016-05-27 17:21:35 +0000",
    "user" : {
      "name" : "Ronnie G",
      "screen_name" : "TheRonnie_G",
      "protected" : false,
      "id_str" : "4482679093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/989639069708664833\/_LmJweZj_normal.jpg",
      "id" : 4482679093,
      "verified" : false
    }
  },
  "id" : 736258215374098432,
  "created_at" : "2016-05-27 18:10:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/736243430586736641\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/7O95LCi9qP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjepf7YXAAAW7kH.jpg",
      "id_str" : "736243430079266816",
      "id" : 736243430079266816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjepf7YXAAAW7kH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/7O95LCi9qP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/b9rEz4PPAS",
      "expanded_url" : "http:\/\/engt.co\/1X0EjQ5",
      "display_url" : "engt.co\/1X0EjQ5"
    } ]
  },
  "geo" : { },
  "id_str" : "736257667916779520",
  "text" : "RT @engadget: Facebook and Microsoft are building a huge trans-Atlantic data cable https:\/\/t.co\/b9rEz4PPAS https:\/\/t.co\/7O95LCi9qP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/736243430586736641\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/7O95LCi9qP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjepf7YXAAAW7kH.jpg",
        "id_str" : "736243430079266816",
        "id" : 736243430079266816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjepf7YXAAAW7kH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/7O95LCi9qP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/b9rEz4PPAS",
        "expanded_url" : "http:\/\/engt.co\/1X0EjQ5",
        "display_url" : "engt.co\/1X0EjQ5"
      } ]
    },
    "geo" : { },
    "id_str" : "736243430586736641",
    "text" : "Facebook and Microsoft are building a huge trans-Atlantic data cable https:\/\/t.co\/b9rEz4PPAS https:\/\/t.co\/7O95LCi9qP",
    "id" : 736243430586736641,
    "created_at" : "2016-05-27 17:11:27 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 736257667916779520,
  "created_at" : "2016-05-27 18:08:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuySell",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736257301049450497",
  "text" : "RT @HamzeiAnalytics: SELL Programs detected at NYSE #BuySell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuySell",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736253338757406722",
    "text" : "SELL Programs detected at NYSE #BuySell",
    "id" : 736253338757406722,
    "created_at" : "2016-05-27 17:50:49 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 736257301049450497,
  "created_at" : "2016-05-27 18:06:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LiLICYMI",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/alfiVEZUvx",
      "expanded_url" : "http:\/\/engt.co\/1qOGNCz",
      "display_url" : "engt.co\/1qOGNCz"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0WGlJGewiA",
      "expanded_url" : "http:\/\/snpy.tv\/1TEQewy",
      "display_url" : "snpy.tv\/1TEQewy"
    } ]
  },
  "geo" : { },
  "id_str" : "736256179760992257",
  "text" : "RT @engadget: #LiLICYMI: A prototype for a fire-starting drone was deployed in Nebraska  https:\/\/t.co\/alfiVEZUvx https:\/\/t.co\/0WGlJGewiA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LiLICYMI",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/alfiVEZUvx",
        "expanded_url" : "http:\/\/engt.co\/1qOGNCz",
        "display_url" : "engt.co\/1qOGNCz"
      }, {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/0WGlJGewiA",
        "expanded_url" : "http:\/\/snpy.tv\/1TEQewy",
        "display_url" : "snpy.tv\/1TEQewy"
      } ]
    },
    "geo" : { },
    "id_str" : "736255684304457728",
    "text" : "#LiLICYMI: A prototype for a fire-starting drone was deployed in Nebraska  https:\/\/t.co\/alfiVEZUvx https:\/\/t.co\/0WGlJGewiA",
    "id" : 736255684304457728,
    "created_at" : "2016-05-27 18:00:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 736256179760992257,
  "created_at" : "2016-05-27 18:02:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgio Rahmouch",
      "screen_name" : "GeorgioRahmouch",
      "indices" : [ 3, 19 ],
      "id_str" : "637181569",
      "id" : 637181569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736249686382743554",
  "text" : "RT @GeorgioRahmouch: The worst form of inequality\u00A0is to try to make unequal things equal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736245718000664576",
    "text" : "The worst form of inequality\u00A0is to try to make unequal things equal.",
    "id" : 736245718000664576,
    "created_at" : "2016-05-27 17:20:32 +0000",
    "user" : {
      "name" : "Georgio Rahmouch",
      "screen_name" : "GeorgioRahmouch",
      "protected" : false,
      "id_str" : "637181569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836989066189078528\/YdT7itFZ_normal.jpg",
      "id" : 637181569,
      "verified" : false
    }
  },
  "id" : 736249686382743554,
  "created_at" : "2016-05-27 17:36:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/736249607206895620\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/iRmsdq7c9R",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjevEQoUkAIcTgj.jpg",
      "id_str" : "736249551816790018",
      "id" : 736249551816790018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjevEQoUkAIcTgj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 242
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 242
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 242
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 242
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/iRmsdq7c9R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736249607206895620",
  "text" : "The moment when you forgot to use your speedy rewards card to buy gas https:\/\/t.co\/iRmsdq7c9R",
  "id" : 736249607206895620,
  "created_at" : "2016-05-27 17:35:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Tiepelman",
      "screen_name" : "BillTiepelman",
      "indices" : [ 3, 17 ],
      "id_str" : "570321334",
      "id" : 570321334
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BillTiepelman\/status\/736249306751991808\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/NP22nMfSqH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjeu14vVEAE_qoe.jpg",
      "id_str" : "736249304885563393",
      "id" : 736249304885563393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjeu14vVEAE_qoe.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1203,
        "resize" : "fit",
        "w" : 859
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 857
      }, {
        "h" : 1203,
        "resize" : "fit",
        "w" : 859
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/NP22nMfSqH"
    } ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "photography",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736249602291027968",
  "text" : "RT @BillTiepelman: Woody stopped by for a quick click #birding #photography https:\/\/t.co\/NP22nMfSqH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BillTiepelman\/status\/736249306751991808\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/NP22nMfSqH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjeu14vVEAE_qoe.jpg",
        "id_str" : "736249304885563393",
        "id" : 736249304885563393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjeu14vVEAE_qoe.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 486
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1203,
          "resize" : "fit",
          "w" : 859
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 857
        }, {
          "h" : 1203,
          "resize" : "fit",
          "w" : 859
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/NP22nMfSqH"
      } ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 35, 43 ]
      }, {
        "text" : "photography",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736249306751991808",
    "text" : "Woody stopped by for a quick click #birding #photography https:\/\/t.co\/NP22nMfSqH",
    "id" : 736249306751991808,
    "created_at" : "2016-05-27 17:34:48 +0000",
    "user" : {
      "name" : "Bill Tiepelman",
      "screen_name" : "BillTiepelman",
      "protected" : false,
      "id_str" : "570321334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2188267134\/1_normal.jpg",
      "id" : 570321334,
      "verified" : false
    }
  },
  "id" : 736249602291027968,
  "created_at" : "2016-05-27 17:35:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "indices" : [ 3, 17 ],
      "id_str" : "172940468",
      "id" : 172940468
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 26, 38 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735908898545238020",
  "text" : "RT @CAPinventions: Cheers @gamer456148 for the Rt :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 7, 19 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735906230460403712",
    "text" : "Cheers @gamer456148 for the Rt :)",
    "id" : 735906230460403712,
    "created_at" : "2016-05-26 18:51:32 +0000",
    "user" : {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "protected" : false,
      "id_str" : "172940468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591514052163153920\/3KFUa10g_normal.jpg",
      "id" : 172940468,
      "verified" : false
    }
  },
  "id" : 735908898545238020,
  "created_at" : "2016-05-26 19:02:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadInspirationalQuotes",
      "indices" : [ 95, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735892153327583233",
  "text" : "RT @CnstantGardener: Life is like a box of chocolates;\nSomeone else already ate the best ones. #BadInspirationalQuotes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadInspirationalQuotes",
        "indices" : [ 74, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735879150582542336",
    "text" : "Life is like a box of chocolates;\nSomeone else already ate the best ones. #BadInspirationalQuotes",
    "id" : 735879150582542336,
    "created_at" : "2016-05-26 17:03:56 +0000",
    "user" : {
      "name" : "Mr Paul \uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F",
      "screen_name" : "CnstantPaul",
      "protected" : false,
      "id_str" : "90485020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718775214566313984\/CHlJ39DW_normal.jpg",
      "id" : 90485020,
      "verified" : false
    }
  },
  "id" : 735892153327583233,
  "created_at" : "2016-05-26 17:55:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "indices" : [ 3, 17 ],
      "id_str" : "172940468",
      "id" : 172940468
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadInspirationalQuotes",
      "indices" : [ 19, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735892052882411520",
  "text" : "RT @CAPinventions: #BadInspirationalQuotes The Skys The Limit. But that's not true when there are footprints on the moon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadInspirationalQuotes",
        "indices" : [ 0, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735885958969708545",
    "text" : "#BadInspirationalQuotes The Skys The Limit. But that's not true when there are footprints on the moon.",
    "id" : 735885958969708545,
    "created_at" : "2016-05-26 17:30:59 +0000",
    "user" : {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "protected" : false,
      "id_str" : "172940468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591514052163153920\/3KFUa10g_normal.jpg",
      "id" : 172940468,
      "verified" : false
    }
  },
  "id" : 735892052882411520,
  "created_at" : "2016-05-26 17:55:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "indices" : [ 3, 17 ],
      "id_str" : "172940468",
      "id" : 172940468
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadInspirationalQuotes",
      "indices" : [ 19, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735892017067241473",
  "text" : "RT @CAPinventions: #BadInspirationalQuotes If at first you dont succeed then dont try again",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadInspirationalQuotes",
        "indices" : [ 0, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735886120567853056",
    "text" : "#BadInspirationalQuotes If at first you dont succeed then dont try again",
    "id" : 735886120567853056,
    "created_at" : "2016-05-26 17:31:37 +0000",
    "user" : {
      "name" : "Capital - Inventions",
      "screen_name" : "CAPinventions",
      "protected" : false,
      "id_str" : "172940468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591514052163153920\/3KFUa10g_normal.jpg",
      "id" : 172940468,
      "verified" : false
    }
  },
  "id" : 735892017067241473,
  "created_at" : "2016-05-26 17:55:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lurie",
      "screen_name" : "lurie_john",
      "indices" : [ 3, 14 ],
      "id_str" : "774295855",
      "id" : 774295855
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadInspirationalQuotes",
      "indices" : [ 16, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735891993767903232",
  "text" : "RT @lurie_john: #BadInspirationalQuotes If life hands you potatoes, drink potatoade",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadInspirationalQuotes",
        "indices" : [ 0, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735886864675180545",
    "text" : "#BadInspirationalQuotes If life hands you potatoes, drink potatoade",
    "id" : 735886864675180545,
    "created_at" : "2016-05-26 17:34:35 +0000",
    "user" : {
      "name" : "John Lurie",
      "screen_name" : "lurie_john",
      "protected" : false,
      "id_str" : "774295855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657724668976062464\/0J85sg-T_normal.jpg",
      "id" : 774295855,
      "verified" : true
    }
  },
  "id" : 735891993767903232,
  "created_at" : "2016-05-26 17:54:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thunderclap",
      "screen_name" : "ThunderclapIt",
      "indices" : [ 0, 14 ],
      "id_str" : "561518048",
      "id" : 561518048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/H9PkGUourD",
      "expanded_url" : "http:\/\/bit.ly\/1sQt3ch",
      "display_url" : "bit.ly\/1sQt3ch"
    } ]
  },
  "geo" : { },
  "id_str" : "735891875056496640",
  "in_reply_to_user_id" : 561518048,
  "text" : "@ThunderclapIt Hey guys can you show some love to my ThunderClap campaign https:\/\/t.co\/H9PkGUourD",
  "id" : 735891875056496640,
  "created_at" : "2016-05-26 17:54:29 +0000",
  "in_reply_to_screen_name" : "ThunderclapIt",
  "in_reply_to_user_id_str" : "561518048",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HOPE not hate",
      "screen_name" : "hopenothate",
      "indices" : [ 0, 12 ],
      "id_str" : "46760864",
      "id" : 46760864
    }, {
      "name" : "Patric M. Abbo \u2618\uFE0F",
      "screen_name" : "PatricAbbo",
      "indices" : [ 13, 24 ],
      "id_str" : "60966290",
      "id" : 60966290
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/735891731254743041\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qEXOliPgxc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjZpgfjUoAA1Cr2.jpg",
      "id_str" : "735891596068036608",
      "id" : 735891596068036608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjZpgfjUoAA1Cr2.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qEXOliPgxc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/H9PkGUourD",
      "expanded_url" : "http:\/\/bit.ly\/1sQt3ch",
      "display_url" : "bit.ly\/1sQt3ch"
    } ]
  },
  "geo" : { },
  "id_str" : "735891731254743041",
  "in_reply_to_user_id" : 46760864,
  "text" : "@hopenothate @PatricAbbo Checkout my ThunderClap campaign https:\/\/t.co\/H9PkGUourD https:\/\/t.co\/qEXOliPgxc",
  "id" : 735891731254743041,
  "created_at" : "2016-05-26 17:53:55 +0000",
  "in_reply_to_screen_name" : "hopenothate",
  "in_reply_to_user_id_str" : "46760864",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Leslie",
      "screen_name" : "Minipop84",
      "indices" : [ 3, 13 ],
      "id_str" : "20354388",
      "id" : 20354388
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735572566736265217",
  "text" : "RT @Minipop84: @gamer456148 after a hard workout there is nothing like protein, veggies and a glass of antioxidants (wine) for proper muscl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "735569197720293377",
    "geo" : { },
    "id_str" : "735572318412378112",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 after a hard workout there is nothing like protein, veggies and a glass of antioxidants (wine) for proper muscle repair \uD83D\uDE02",
    "id" : 735572318412378112,
    "in_reply_to_status_id" : 735569197720293377,
    "created_at" : "2016-05-25 20:44:41 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Gina Leslie",
      "screen_name" : "Minipop84",
      "protected" : false,
      "id_str" : "20354388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819618339672576000\/Gx3_PcmN_normal.jpg",
      "id" : 20354388,
      "verified" : false
    }
  },
  "id" : 735572566736265217,
  "created_at" : "2016-05-25 20:45:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Words\u2122",
      "screen_name" : "Perfectllysaid",
      "indices" : [ 0, 15 ],
      "id_str" : "2789342022",
      "id" : 2789342022
    }, {
      "name" : "SpeakComedy",
      "screen_name" : "SpeakComedy",
      "indices" : [ 16, 28 ],
      "id_str" : "50618718",
      "id" : 50618718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734514261972504577",
  "geo" : { },
  "id_str" : "735570891250229248",
  "in_reply_to_user_id" : 1381707282,
  "text" : "@PerfectllySaid @SpeakComedy I could name far more better things: Salvation, the innocence of a child, inner peace, etc.",
  "id" : 735570891250229248,
  "in_reply_to_status_id" : 734514261972504577,
  "created_at" : "2016-05-25 20:39:01 +0000",
  "in_reply_to_screen_name" : "FlirtyNoteBooks",
  "in_reply_to_user_id_str" : "1381707282",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 0, 15 ],
      "id_str" : "16372759",
      "id" : 16372759
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 16, 25 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735566881365491714",
  "geo" : { },
  "id_str" : "735570644457410560",
  "in_reply_to_user_id" : 16372759,
  "text" : "@EmperorDarroux @mashable A vehicle by Apple is either brilliant or a recipe for disaster",
  "id" : 735570644457410560,
  "in_reply_to_status_id" : 735566881365491714,
  "created_at" : "2016-05-25 20:38:02 +0000",
  "in_reply_to_screen_name" : "EmperorDarroux",
  "in_reply_to_user_id_str" : "16372759",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Sullivan",
      "screen_name" : "EnjoyerPaul",
      "indices" : [ 3, 15 ],
      "id_str" : "27226724",
      "id" : 27226724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechACeleb",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735570421970538497",
  "text" : "RT @EnjoyerPaul: #TechACeleb David Emailman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TechACeleb",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735567637317619713",
    "text" : "#TechACeleb David Emailman",
    "id" : 735567637317619713,
    "created_at" : "2016-05-25 20:26:05 +0000",
    "user" : {
      "name" : "Paul Sullivan",
      "screen_name" : "EnjoyerPaul",
      "protected" : false,
      "id_str" : "27226724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487712531033911296\/IPOpKvmt_normal.jpeg",
      "id" : 27226724,
      "verified" : false
    }
  },
  "id" : 735570421970538497,
  "created_at" : "2016-05-25 20:37:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735570315779186693",
  "text" : "@CoryRKelley I am an IT consultant, send me a private message and let's  maybe go from there",
  "id" : 735570315779186693,
  "created_at" : "2016-05-25 20:36:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/HPw4vWgJDK",
      "expanded_url" : "http:\/\/goo.gl\/fb\/LTi2Vz",
      "display_url" : "goo.gl\/fb\/LTi2Vz"
    } ]
  },
  "geo" : { },
  "id_str" : "735570064422928384",
  "text" : "RT @buysellshort: 05-25-2016 Poppers For Tomorrow https:\/\/t.co\/HPw4vWgJDK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/HPw4vWgJDK",
        "expanded_url" : "http:\/\/goo.gl\/fb\/LTi2Vz",
        "display_url" : "goo.gl\/fb\/LTi2Vz"
      } ]
    },
    "geo" : { },
    "id_str" : "735569236643487746",
    "text" : "05-25-2016 Poppers For Tomorrow https:\/\/t.co\/HPw4vWgJDK",
    "id" : 735569236643487746,
    "created_at" : "2016-05-25 20:32:26 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : true,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 735570064422928384,
  "created_at" : "2016-05-25 20:35:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker Supporter",
      "screen_name" : "HT_Supporter",
      "indices" : [ 3, 16 ],
      "id_str" : "20353836",
      "id" : 20353836
    }, {
      "name" : "Silviu Facaoaru",
      "screen_name" : "amumu321",
      "indices" : [ 22, 31 ],
      "id_str" : "2387667662",
      "id" : 2387667662
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 79, 90 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1c9vArcQ6Q",
      "expanded_url" : "https:\/\/headtalker.com\/?p=63017",
      "display_url" : "headtalker.com\/?p=63017"
    } ]
  },
  "geo" : { },
  "id_str" : "735569928225443841",
  "text" : "RT @HT_Supporter: Hey @amumu321 I just supported Help Katherine beat cancer on @HeadTalker https:\/\/t.co\/1c9vArcQ6Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Silviu Facaoaru",
        "screen_name" : "amumu321",
        "indices" : [ 4, 13 ],
        "id_str" : "2387667662",
        "id" : 2387667662
      }, {
        "name" : "HeadTalker",
        "screen_name" : "headtalker",
        "indices" : [ 61, 72 ],
        "id_str" : "2177390274",
        "id" : 2177390274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/1c9vArcQ6Q",
        "expanded_url" : "https:\/\/headtalker.com\/?p=63017",
        "display_url" : "headtalker.com\/?p=63017"
      } ]
    },
    "geo" : { },
    "id_str" : "735567958857154560",
    "text" : "Hey @amumu321 I just supported Help Katherine beat cancer on @HeadTalker https:\/\/t.co\/1c9vArcQ6Q",
    "id" : 735567958857154560,
    "created_at" : "2016-05-25 20:27:22 +0000",
    "user" : {
      "name" : "HeadTalker Supporter",
      "screen_name" : "HT_Supporter",
      "protected" : false,
      "id_str" : "20353836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616421678227197952\/r8DdokWG_normal.jpg",
      "id" : 20353836,
      "verified" : false
    }
  },
  "id" : 735569928225443841,
  "created_at" : "2016-05-25 20:35:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parth Mehta",
      "screen_name" : "parth638",
      "indices" : [ 0, 9 ],
      "id_str" : "105566576",
      "id" : 105566576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "735569223271911424",
  "geo" : { },
  "id_str" : "735569890141216774",
  "in_reply_to_user_id" : 105566576,
  "text" : "@parth638 Parth, please help and support my #HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 735569890141216774,
  "in_reply_to_status_id" : 735569223271911424,
  "created_at" : "2016-05-25 20:35:02 +0000",
  "in_reply_to_screen_name" : "parth638",
  "in_reply_to_user_id_str" : "105566576",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Leslie",
      "screen_name" : "Minipop84",
      "indices" : [ 0, 10 ],
      "id_str" : "20354388",
      "id" : 20354388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "735562515778658304",
  "geo" : { },
  "id_str" : "735569197720293377",
  "in_reply_to_user_id" : 20354388,
  "text" : "@Minipop84 These two don't go together so well!!!",
  "id" : 735569197720293377,
  "in_reply_to_status_id" : 735562515778658304,
  "created_at" : "2016-05-25 20:32:17 +0000",
  "in_reply_to_screen_name" : "Minipop84",
  "in_reply_to_user_id_str" : "20354388",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shauna Baker",
      "screen_name" : "ShaunaBaker",
      "indices" : [ 3, 15 ],
      "id_str" : "26406958",
      "id" : 26406958
    }, {
      "name" : "IdealFit",
      "screen_name" : "beidealfit",
      "indices" : [ 86, 97 ],
      "id_str" : "3505691973",
      "id" : 3505691973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idealfit",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "sp",
      "indices" : [ 118, 121 ]
    }, {
      "text" : "bakertwins",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735568974746931200",
  "text" : "RT @ShaunaBaker: Showed this mountain who's boss! \uD83D\uDE0E Now I'm repairing my muscles with @beidealfit's BCAA's. #idealfit #sp #bakertwins https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IdealFit",
        "screen_name" : "beidealfit",
        "indices" : [ 69, 80 ],
        "id_str" : "3505691973",
        "id" : 3505691973
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShaunaBaker\/status\/732716407876517889\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/S5za97yoUT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CishrrLUoAQWuKs.jpg",
        "id_str" : "732716398586142724",
        "id" : 732716398586142724,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CishrrLUoAQWuKs.jpg",
        "sizes" : [ {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/S5za97yoUT"
      } ],
      "hashtags" : [ {
        "text" : "idealfit",
        "indices" : [ 91, 100 ]
      }, {
        "text" : "sp",
        "indices" : [ 101, 104 ]
      }, {
        "text" : "bakertwins",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732716407876517889",
    "text" : "Showed this mountain who's boss! \uD83D\uDE0E Now I'm repairing my muscles with @beidealfit's BCAA's. #idealfit #sp #bakertwins https:\/\/t.co\/S5za97yoUT",
    "id" : 732716407876517889,
    "created_at" : "2016-05-17 23:36:19 +0000",
    "user" : {
      "name" : "Shauna Baker",
      "screen_name" : "ShaunaBaker",
      "protected" : false,
      "id_str" : "26406958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/828420006534733824\/E39oa_Xy_normal.jpg",
      "id" : 26406958,
      "verified" : true
    }
  },
  "id" : 735568974746931200,
  "created_at" : "2016-05-25 20:31:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detroit Red Wings",
      "screen_name" : "DetroitRedWings",
      "indices" : [ 3, 19 ],
      "id_str" : "16826656",
      "id" : 16826656
    }, {
      "name" : "DSBA",
      "screen_name" : "OfficialDSBA",
      "indices" : [ 84, 97 ],
      "id_str" : "246419046",
      "id" : 246419046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RedWings",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Vd7tFY5FTV",
      "expanded_url" : "http:\/\/redwn.gs\/1U7GxWR",
      "display_url" : "redwn.gs\/1U7GxWR"
    } ]
  },
  "geo" : { },
  "id_str" : "735568405969920000",
  "text" : "RT @DetroitRedWings: Congrats Dylan Larkin!!! Named #RedWings Rookie of the Year by @OfficialDSBA.\n\nDetails: https:\/\/t.co\/Vd7tFY5FTV https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DSBA",
        "screen_name" : "OfficialDSBA",
        "indices" : [ 63, 76 ],
        "id_str" : "246419046",
        "id" : 246419046
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DetroitRedWings\/status\/735108151897423872\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/2BYKn0oX6s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjOg9eUWUAA8kpf.jpg",
        "id_str" : "735108142162399232",
        "id" : 735108142162399232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjOg9eUWUAA8kpf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/2BYKn0oX6s"
      } ],
      "hashtags" : [ {
        "text" : "RedWings",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Vd7tFY5FTV",
        "expanded_url" : "http:\/\/redwn.gs\/1U7GxWR",
        "display_url" : "redwn.gs\/1U7GxWR"
      } ]
    },
    "geo" : { },
    "id_str" : "735108151897423872",
    "text" : "Congrats Dylan Larkin!!! Named #RedWings Rookie of the Year by @OfficialDSBA.\n\nDetails: https:\/\/t.co\/Vd7tFY5FTV https:\/\/t.co\/2BYKn0oX6s",
    "id" : 735108151897423872,
    "created_at" : "2016-05-24 14:00:15 +0000",
    "user" : {
      "name" : "Detroit Red Wings",
      "screen_name" : "DetroitRedWings",
      "protected" : false,
      "id_str" : "16826656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936456176648286213\/uBFaS0GR_normal.jpg",
      "id" : 16826656,
      "verified" : true
    }
  },
  "id" : 735568405969920000,
  "created_at" : "2016-05-25 20:29:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawanee",
      "screen_name" : "KawaneeHamilton",
      "indices" : [ 3, 19 ],
      "id_str" : "49892285",
      "id" : 49892285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechACeleb",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735568267570511873",
  "text" : "RT @KawaneeHamilton: #TechACeleb Fleetwood MacBook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TechACeleb",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735554326391840768",
    "text" : "#TechACeleb Fleetwood MacBook",
    "id" : 735554326391840768,
    "created_at" : "2016-05-25 19:33:12 +0000",
    "user" : {
      "name" : "Kawanee",
      "screen_name" : "KawaneeHamilton",
      "protected" : false,
      "id_str" : "49892285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572068778230292480\/ACbWSgYZ_normal.jpeg",
      "id" : 49892285,
      "verified" : false
    }
  },
  "id" : 735568267570511873,
  "created_at" : "2016-05-25 20:28:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelsey",
      "screen_name" : "kelspriestap",
      "indices" : [ 3, 16 ],
      "id_str" : "132278675",
      "id" : 132278675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kelspriestap\/status\/735561103539884032\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/qOvl6wOzWh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjU82WbVAAADwCz.jpg",
      "id_str" : "735561018575749120",
      "id" : 735561018575749120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjU82WbVAAADwCz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qOvl6wOzWh"
    } ],
    "hashtags" : [ {
      "text" : "TechACeleb",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735568126969012224",
  "text" : "RT @kelspriestap: #TechACeleb SIM Card-ashian https:\/\/t.co\/qOvl6wOzWh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kelspriestap\/status\/735561103539884032\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/qOvl6wOzWh",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjU82WbVAAADwCz.jpg",
        "id_str" : "735561018575749120",
        "id" : 735561018575749120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjU82WbVAAADwCz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/qOvl6wOzWh"
      } ],
      "hashtags" : [ {
        "text" : "TechACeleb",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735561103539884032",
    "text" : "#TechACeleb SIM Card-ashian https:\/\/t.co\/qOvl6wOzWh",
    "id" : 735561103539884032,
    "created_at" : "2016-05-25 20:00:07 +0000",
    "user" : {
      "name" : "Kelsey",
      "screen_name" : "kelspriestap",
      "protected" : false,
      "id_str" : "132278675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/950742032166805504\/omlvQFfK_normal.jpg",
      "id" : 132278675,
      "verified" : false
    }
  },
  "id" : 735568126969012224,
  "created_at" : "2016-05-25 20:28:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Worldplay",
      "screen_name" : "Worldplay",
      "indices" : [ 3, 13 ],
      "id_str" : "2149387010",
      "id" : 2149387010
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Worldplay\/status\/735563108630941697\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/tJbEF7x1Iu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjU-v89UYAAYY2_.jpg",
      "id_str" : "735563107683033088",
      "id" : 735563107683033088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjU-v89UYAAYY2_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/tJbEF7x1Iu"
    } ],
    "hashtags" : [ {
      "text" : "TechACeleb",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735568093985046528",
  "text" : "RT @Worldplay: Bruce Buffering. #TechACeleb https:\/\/t.co\/tJbEF7x1Iu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Worldplay\/status\/735563108630941697\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/tJbEF7x1Iu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjU-v89UYAAYY2_.jpg",
        "id_str" : "735563107683033088",
        "id" : 735563107683033088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjU-v89UYAAYY2_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/tJbEF7x1Iu"
      } ],
      "hashtags" : [ {
        "text" : "TechACeleb",
        "indices" : [ 17, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735563108630941697",
    "text" : "Bruce Buffering. #TechACeleb https:\/\/t.co\/tJbEF7x1Iu",
    "id" : 735563108630941697,
    "created_at" : "2016-05-25 20:08:05 +0000",
    "user" : {
      "name" : "Worldplay",
      "screen_name" : "Worldplay",
      "protected" : false,
      "id_str" : "2149387010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875462220259381248\/mH87b37X_normal.jpg",
      "id" : 2149387010,
      "verified" : false
    }
  },
  "id" : 735568093985046528,
  "created_at" : "2016-05-25 20:27:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FrancescoMarciuliano",
      "screen_name" : "fmarciuliano",
      "indices" : [ 3, 16 ],
      "id_str" : "107129460",
      "id" : 107129460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalWineDay",
      "indices" : [ 32, 48 ]
    }, {
      "text" : "NationalTapDanceDay",
      "indices" : [ 53, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735567859707940864",
  "text" : "RT @fmarciuliano: Today is both #NationalWineDay and #NationalTapDanceDay, which together should result in some great performances",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalWineDay",
        "indices" : [ 14, 30 ]
      }, {
        "text" : "NationalTapDanceDay",
        "indices" : [ 35, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735566540196712449",
    "text" : "Today is both #NationalWineDay and #NationalTapDanceDay, which together should result in some great performances",
    "id" : 735566540196712449,
    "created_at" : "2016-05-25 20:21:44 +0000",
    "user" : {
      "name" : "FrancescoMarciuliano",
      "screen_name" : "fmarciuliano",
      "protected" : false,
      "id_str" : "107129460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/986622500451663874\/Ykznmled_normal.jpg",
      "id" : 107129460,
      "verified" : false
    }
  },
  "id" : 735567859707940864,
  "created_at" : "2016-05-25 20:26:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marie Claire",
      "screen_name" : "marieclaire",
      "indices" : [ 3, 15 ],
      "id_str" : "19074134",
      "id" : 19074134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalWineDay",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/ej4RzrQhNM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d4359e04-9c29-4a49-a2df-caf5538b6a5e",
      "display_url" : "amp.twimg.com\/v\/d4359e04-9c2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735567643470614529",
  "text" : "RT @marieclaire: More wine please! \uD83C\uDF77\uD83C\uDF77\uD83C\uDF77 #NationalWineDay\nhttps:\/\/t.co\/ej4RzrQhNM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalWineDay",
        "indices" : [ 22, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/ej4RzrQhNM",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/d4359e04-9c29-4a49-a2df-caf5538b6a5e",
        "display_url" : "amp.twimg.com\/v\/d4359e04-9c2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735454144949932032",
    "text" : "More wine please! \uD83C\uDF77\uD83C\uDF77\uD83C\uDF77 #NationalWineDay\nhttps:\/\/t.co\/ej4RzrQhNM",
    "id" : 735454144949932032,
    "created_at" : "2016-05-25 12:55:06 +0000",
    "user" : {
      "name" : "Marie Claire",
      "screen_name" : "marieclaire",
      "protected" : false,
      "id_str" : "19074134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790520149854023680\/Uu5cTi7t_normal.jpg",
      "id" : 19074134,
      "verified" : true
    }
  },
  "id" : 735567643470614529,
  "created_at" : "2016-05-25 20:26:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nely Cab",
      "screen_name" : "NelyCab",
      "indices" : [ 0, 8 ],
      "id_str" : "26559512",
      "id" : 26559512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "in_reply_to_status_id_str" : "735553599443460097",
  "geo" : { },
  "id_str" : "735567531424026624",
  "in_reply_to_user_id" : 26559512,
  "text" : "@NelyCab Please checkout my HeadTalker https:\/\/t.co\/7RnJi9wx6E",
  "id" : 735567531424026624,
  "in_reply_to_status_id" : 735553599443460097,
  "created_at" : "2016-05-25 20:25:40 +0000",
  "in_reply_to_screen_name" : "NelyCab",
  "in_reply_to_user_id_str" : "26559512",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Your Life Assistant",
      "screen_name" : "NancyJack1014",
      "indices" : [ 0, 14 ],
      "id_str" : "4905663466",
      "id" : 4905663466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "in_reply_to_status_id_str" : "735561467517382656",
  "geo" : { },
  "id_str" : "735567438465671169",
  "in_reply_to_user_id" : 4905663466,
  "text" : "@NancyJack1014 Please support my #HeadTalker https:\/\/t.co\/7RnJi9wx6E",
  "id" : 735567438465671169,
  "in_reply_to_status_id" : 735561467517382656,
  "created_at" : "2016-05-25 20:25:18 +0000",
  "in_reply_to_screen_name" : "NancyJack1014",
  "in_reply_to_user_id_str" : "4905663466",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patric M. Abbo \u2618\uFE0F",
      "screen_name" : "PatricAbbo",
      "indices" : [ 14, 25 ],
      "id_str" : "60966290",
      "id" : 60966290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "geo" : { },
  "id_str" : "735567342755807232",
  "text" : "@DNAfever1978 @PatricAbbo Please support my #HeadTalker https:\/\/t.co\/7RnJi9wx6E",
  "id" : 735567342755807232,
  "created_at" : "2016-05-25 20:24:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/735566443182489604\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/DTlcDAviyr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjVBvlQVEAArvm0.jpg",
      "id_str" : "735566399855202304",
      "id" : 735566399855202304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjVBvlQVEAArvm0.jpg",
      "sizes" : [ {
        "h" : 268,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 420
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 420
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/DTlcDAviyr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735566443182489604",
  "text" : "I like it when people laugh at my really bad jokes. It makes me feel funny. https:\/\/t.co\/DTlcDAviyr",
  "id" : 735566443182489604,
  "created_at" : "2016-05-25 20:21:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/734855875073060865\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/plKnqrPVVo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjK7hgUWkAQNjLI.jpg",
      "id_str" : "734855873500188676",
      "id" : 734855873500188676,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjK7hgUWkAQNjLI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/plKnqrPVVo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/pspy3QN6ot",
      "expanded_url" : "http:\/\/engt.co\/1XOpSxm",
      "display_url" : "engt.co\/1XOpSxm"
    } ]
  },
  "geo" : { },
  "id_str" : "735210888161038336",
  "text" : "RT @engadget: $56,095 gets you this freaky 3D-printed electric motorbike https:\/\/t.co\/pspy3QN6ot https:\/\/t.co\/plKnqrPVVo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/734855875073060865\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/plKnqrPVVo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjK7hgUWkAQNjLI.jpg",
        "id_str" : "734855873500188676",
        "id" : 734855873500188676,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjK7hgUWkAQNjLI.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/plKnqrPVVo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/pspy3QN6ot",
        "expanded_url" : "http:\/\/engt.co\/1XOpSxm",
        "display_url" : "engt.co\/1XOpSxm"
      } ]
    },
    "geo" : { },
    "id_str" : "734855875073060865",
    "text" : "$56,095 gets you this freaky 3D-printed electric motorbike https:\/\/t.co\/pspy3QN6ot https:\/\/t.co\/plKnqrPVVo",
    "id" : 734855875073060865,
    "created_at" : "2016-05-23 21:17:48 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 735210888161038336,
  "created_at" : "2016-05-24 20:48:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/734844632442523649\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/hbyLYyYkcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjKxTHHWgAAgDKs.jpg",
      "id_str" : "734844631100325888",
      "id" : 734844631100325888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjKxTHHWgAAgDKs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hbyLYyYkcR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hkpWMjvB02",
      "expanded_url" : "http:\/\/engt.co\/20seB4t",
      "display_url" : "engt.co\/20seB4t"
    } ]
  },
  "geo" : { },
  "id_str" : "735210559730286592",
  "text" : "RT @engadget: NASA is building the next Mars rover in mixed reality https:\/\/t.co\/hkpWMjvB02 https:\/\/t.co\/hbyLYyYkcR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/734844632442523649\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/hbyLYyYkcR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjKxTHHWgAAgDKs.jpg",
        "id_str" : "734844631100325888",
        "id" : 734844631100325888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjKxTHHWgAAgDKs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hbyLYyYkcR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/hkpWMjvB02",
        "expanded_url" : "http:\/\/engt.co\/20seB4t",
        "display_url" : "engt.co\/20seB4t"
      } ]
    },
    "geo" : { },
    "id_str" : "734844632442523649",
    "text" : "NASA is building the next Mars rover in mixed reality https:\/\/t.co\/hkpWMjvB02 https:\/\/t.co\/hbyLYyYkcR",
    "id" : 734844632442523649,
    "created_at" : "2016-05-23 20:33:07 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 735210559730286592,
  "created_at" : "2016-05-24 20:47:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "NVIDIA",
      "screen_name" : "nvidia",
      "indices" : [ 35, 42 ],
      "id_str" : "61559439",
      "id" : 61559439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/MQ4ers31Zp",
      "expanded_url" : "http:\/\/engt.co\/1WO7Vjo",
      "display_url" : "engt.co\/1WO7Vjo"
    } ]
  },
  "geo" : { },
  "id_str" : "735210379681243136",
  "text" : "RT @engadget: Take a close look at @NVIDIA's GeForce GTX 1080 -- the fastest video card on the market https:\/\/t.co\/MQ4ers31Zp https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NVIDIA",
        "screen_name" : "nvidia",
        "indices" : [ 21, 28 ],
        "id_str" : "61559439",
        "id" : 61559439
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/734961405368111104\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/bptAwLPZp4",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjMbgKFWYAA_DlP.jpg",
        "id_str" : "734961403468079104",
        "id" : 734961403468079104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjMbgKFWYAA_DlP.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/bptAwLPZp4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/MQ4ers31Zp",
        "expanded_url" : "http:\/\/engt.co\/1WO7Vjo",
        "display_url" : "engt.co\/1WO7Vjo"
      } ]
    },
    "geo" : { },
    "id_str" : "734961405368111104",
    "text" : "Take a close look at @NVIDIA's GeForce GTX 1080 -- the fastest video card on the market https:\/\/t.co\/MQ4ers31Zp https:\/\/t.co\/bptAwLPZp4",
    "id" : 734961405368111104,
    "created_at" : "2016-05-24 04:17:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 735210379681243136,
  "created_at" : "2016-05-24 20:46:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "indices" : [ 3, 16 ],
      "id_str" : "39357604",
      "id" : 39357604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Q3QEwoCWs6",
      "expanded_url" : "http:\/\/nr.tn\/1Uail8X",
      "display_url" : "nr.tn\/1Uail8X"
    } ]
  },
  "geo" : { },
  "id_str" : "735210209929506816",
  "text" : "RT @NortonOnline: Dronebuster will let you point and shoot command hacks at pesky drones https:\/\/t.co\/Q3QEwoCWs6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Q3QEwoCWs6",
        "expanded_url" : "http:\/\/nr.tn\/1Uail8X",
        "display_url" : "nr.tn\/1Uail8X"
      } ]
    },
    "geo" : { },
    "id_str" : "735050457194827776",
    "text" : "Dronebuster will let you point and shoot command hacks at pesky drones https:\/\/t.co\/Q3QEwoCWs6",
    "id" : 735050457194827776,
    "created_at" : "2016-05-24 10:11:00 +0000",
    "user" : {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "protected" : false,
      "id_str" : "39357604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816328497694199808\/oeI12_Ei_normal.jpg",
      "id" : 39357604,
      "verified" : true
    }
  },
  "id" : 735210209929506816,
  "created_at" : "2016-05-24 20:45:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/UQv6UPVXLh",
      "expanded_url" : "http:\/\/www.hannity.com\/articles\/hanpr-election-493995\/listen-alleged-clinton-sexual-assault-victim-14746880\/",
      "display_url" : "hannity.com\/articles\/hanpr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735210033831628800",
  "text" : "RT @seanhannity: LISTEN: Alleged Clinton Sexual Assault Victim Describes Her Encounter With The Former President https:\/\/t.co\/UQv6UPVXLh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/UQv6UPVXLh",
        "expanded_url" : "http:\/\/www.hannity.com\/articles\/hanpr-election-493995\/listen-alleged-clinton-sexual-assault-victim-14746880\/",
        "display_url" : "hannity.com\/articles\/hanpr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735200474396282880",
    "text" : "LISTEN: Alleged Clinton Sexual Assault Victim Describes Her Encounter With The Former President https:\/\/t.co\/UQv6UPVXLh",
    "id" : 735200474396282880,
    "created_at" : "2016-05-24 20:07:07 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 735210033831628800,
  "created_at" : "2016-05-24 20:45:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 3, 13 ],
      "id_str" : "255245279",
      "id" : 255245279
    }, {
      "name" : "Janelle Ambrose",
      "screen_name" : "literal_janelle",
      "indices" : [ 15, 31 ],
      "id_str" : "4454704398",
      "id" : 4454704398
    }, {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "indices" : [ 32, 44 ],
      "id_str" : "713486956273991686",
      "id" : 713486956273991686
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 45, 57 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734785671928418306",
  "text" : "RT @AlanFelyk: @literal_janelle @BadLitAgent @gamer456148 Perhaps a studded collar, too. I could be her lap dog, but I weigh too much for t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Janelle Ambrose",
        "screen_name" : "literal_janelle",
        "indices" : [ 0, 16 ],
        "id_str" : "4454704398",
        "id" : 4454704398
      }, {
        "name" : "Bad Literary Agent",
        "screen_name" : "BadLitAgent",
        "indices" : [ 17, 29 ],
        "id_str" : "713486956273991686",
        "id" : 713486956273991686
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 30, 42 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "734772896841666560",
    "geo" : { },
    "id_str" : "734775393174052864",
    "in_reply_to_user_id" : 4454704398,
    "text" : "@literal_janelle @BadLitAgent @gamer456148 Perhaps a studded collar, too. I could be her lap dog, but I weigh too much for that.",
    "id" : 734775393174052864,
    "in_reply_to_status_id" : 734772896841666560,
    "created_at" : "2016-05-23 15:57:59 +0000",
    "in_reply_to_screen_name" : "literal_janelle",
    "in_reply_to_user_id_str" : "4454704398",
    "user" : {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "protected" : false,
      "id_str" : "255245279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3582417692\/d853116c99eb19f7e35d76c03540d0f7_normal.jpeg",
      "id" : 255245279,
      "verified" : false
    }
  },
  "id" : 734785671928418306,
  "created_at" : "2016-05-23 16:38:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janelle Ambrose",
      "screen_name" : "literal_janelle",
      "indices" : [ 0, 16 ],
      "id_str" : "4454704398",
      "id" : 4454704398
    }, {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 17, 27 ],
      "id_str" : "255245279",
      "id" : 255245279
    }, {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "indices" : [ 28, 40 ],
      "id_str" : "713486956273991686",
      "id" : 713486956273991686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Fel6Wssa33",
      "expanded_url" : "https:\/\/goo.gl\/d2umNY",
      "display_url" : "goo.gl\/d2umNY"
    } ]
  },
  "in_reply_to_status_id_str" : "734776300565630980",
  "geo" : { },
  "id_str" : "734785616647495682",
  "in_reply_to_user_id" : 4454704398,
  "text" : "@literal_janelle @AlanFelyk @BadLitAgent Guys, please checkout and support my HeadTalker https:\/\/t.co\/Fel6Wssa33",
  "id" : 734785616647495682,
  "in_reply_to_status_id" : 734776300565630980,
  "created_at" : "2016-05-23 16:38:37 +0000",
  "in_reply_to_screen_name" : "literal_janelle",
  "in_reply_to_user_id_str" : "4454704398",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "indices" : [ 3, 17 ],
      "id_str" : "17636405",
      "id" : 17636405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/8eb4W65e6i",
      "expanded_url" : "http:\/\/depot.ly\/16y5300tWYV",
      "display_url" : "depot.ly\/16y5300tWYV"
    } ]
  },
  "geo" : { },
  "id_str" : "734768834834509825",
  "text" : "RT @DesignerDepot: How to Center in CSS: Generator for CSS centering code https:\/\/t.co\/8eb4W65e6i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/8eb4W65e6i",
        "expanded_url" : "http:\/\/depot.ly\/16y5300tWYV",
        "display_url" : "depot.ly\/16y5300tWYV"
      } ]
    },
    "geo" : { },
    "id_str" : "734768496605835265",
    "text" : "How to Center in CSS: Generator for CSS centering code https:\/\/t.co\/8eb4W65e6i",
    "id" : 734768496605835265,
    "created_at" : "2016-05-23 15:30:35 +0000",
    "user" : {
      "name" : "Webdesigner Depot",
      "screen_name" : "DesignerDepot",
      "protected" : false,
      "id_str" : "17636405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938857270888112128\/fueDq6et_normal.jpg",
      "id" : 17636405,
      "verified" : false
    }
  },
  "id" : 734768834834509825,
  "created_at" : "2016-05-23 15:31:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/sLk6efalXu",
      "expanded_url" : "http:\/\/bit.ly\/1sxLKRf",
      "display_url" : "bit.ly\/1sxLKRf"
    } ]
  },
  "geo" : { },
  "id_str" : "734768735072948224",
  "text" : "UpVote us on Product Hunt: https:\/\/t.co\/sLk6efalXu",
  "id" : 734768735072948224,
  "created_at" : "2016-05-23 15:31:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "indices" : [ 3, 15 ],
      "id_str" : "713486956273991686",
      "id" : 713486956273991686
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 30, 40 ],
      "id_str" : "255245279",
      "id" : 255245279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734767006080208896",
  "text" : "RT @BadLitAgent: @gamer456148 @AlanFelyk go on. You know you want to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Alan Felyk",
        "screen_name" : "AlanFelyk",
        "indices" : [ 13, 23 ],
        "id_str" : "255245279",
        "id" : 255245279
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "734766537861693441",
    "geo" : { },
    "id_str" : "734766901985959936",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @AlanFelyk go on. You know you want to.",
    "id" : 734766901985959936,
    "in_reply_to_status_id" : 734766537861693441,
    "created_at" : "2016-05-23 15:24:15 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "protected" : false,
      "id_str" : "713486956273991686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713913667922825216\/OahOhQrk_normal.jpg",
      "id" : 713486956273991686,
      "verified" : false
    }
  },
  "id" : 734767006080208896,
  "created_at" : "2016-05-23 15:24:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 117, 128 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734766626688602112",
  "text" : "RT @pluralsight: \"Nearly half of all graduating students say college did not prepare them for the working world.\" -- @TechCrunch: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 100, 111 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/MrgOL0qbaB",
        "expanded_url" : "http:\/\/bit.ly\/1sMRffS",
        "display_url" : "bit.ly\/1sMRffS"
      } ]
    },
    "geo" : { },
    "id_str" : "734750753764450305",
    "text" : "\"Nearly half of all graduating students say college did not prepare them for the working world.\" -- @TechCrunch: https:\/\/t.co\/MrgOL0qbaB",
    "id" : 734750753764450305,
    "created_at" : "2016-05-23 14:20:05 +0000",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908381030821675009\/nOwJrmgq_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 734766626688602112,
  "created_at" : "2016-05-23 15:23:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 0, 10 ],
      "id_str" : "255245279",
      "id" : 255245279
    }, {
      "name" : "Bad Literary Agent",
      "screen_name" : "BadLitAgent",
      "indices" : [ 11, 23 ],
      "id_str" : "713486956273991686",
      "id" : 713486956273991686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734524091777077249",
  "geo" : { },
  "id_str" : "734766537861693441",
  "in_reply_to_user_id" : 255245279,
  "text" : "@AlanFelyk @BadLitAgent Oh my goodness",
  "id" : 734766537861693441,
  "in_reply_to_status_id" : 734524091777077249,
  "created_at" : "2016-05-23 15:22:48 +0000",
  "in_reply_to_screen_name" : "AlanFelyk",
  "in_reply_to_user_id_str" : "255245279",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734766223616053248",
  "text" : "RT @buysellshort: XGTI finacing week ago at 7c now runnin at 20c - stocks that dropped on financing getting ripped",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734766029939867648",
    "text" : "XGTI finacing week ago at 7c now runnin at 20c - stocks that dropped on financing getting ripped",
    "id" : 734766029939867648,
    "created_at" : "2016-05-23 15:20:47 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : true,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 734766223616053248,
  "created_at" : "2016-05-23 15:21:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub Status",
      "screen_name" : "githubstatus",
      "indices" : [ 0, 13 ],
      "id_str" : "785764172",
      "id" : 785764172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734766072126185474",
  "geo" : { },
  "id_str" : "734766163125796864",
  "in_reply_to_user_id" : 210979938,
  "text" : "@githubstatus This haven't happened before",
  "id" : 734766163125796864,
  "in_reply_to_status_id" : 734766072126185474,
  "created_at" : "2016-05-23 15:21:19 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub Status",
      "screen_name" : "githubstatus",
      "indices" : [ 0, 13 ],
      "id_str" : "785764172",
      "id" : 785764172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734766072126185474",
  "in_reply_to_user_id" : 785764172,
  "text" : "@githubstatus Seems like a glitch, but GitHub seems to be logging off for me automatically and there are sites latency issues.",
  "id" : 734766072126185474,
  "created_at" : "2016-05-23 15:20:57 +0000",
  "in_reply_to_screen_name" : "githubstatus",
  "in_reply_to_user_id_str" : "785764172",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/733784523507404807\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/NKPhYcr2un",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci7tIt6XIAAnxwv.jpg",
      "id_str" : "733784523327086592",
      "id" : 733784523327086592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci7tIt6XIAAnxwv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/NKPhYcr2un"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733784807893794821",
  "text" : "RT @rockindigo: Coffee table based off of a scene from Inception https:\/\/t.co\/NKPhYcr2un",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/733784523507404807\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/NKPhYcr2un",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci7tIt6XIAAnxwv.jpg",
        "id_str" : "733784523327086592",
        "id" : 733784523327086592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci7tIt6XIAAnxwv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/NKPhYcr2un"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733784523507404807",
    "text" : "Coffee table based off of a scene from Inception https:\/\/t.co\/NKPhYcr2un",
    "id" : 733784523507404807,
    "created_at" : "2016-05-20 22:20:38 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 733784807893794821,
  "created_at" : "2016-05-20 22:21:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u840C\u3048\u306E\u54C0\u308C",
      "screen_name" : "uncreativecat",
      "indices" : [ 0, 14 ],
      "id_str" : "281223410",
      "id" : 281223410
    }, {
      "name" : "Frank",
      "screen_name" : "Masaka_Arienai",
      "indices" : [ 15, 30 ],
      "id_str" : "622554857",
      "id" : 622554857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733783497635209216",
  "geo" : { },
  "id_str" : "733783815202689025",
  "in_reply_to_user_id" : 210979938,
  "text" : "@uncreativecat @Masaka_Arienai Okay, no problem. Have a nice day!",
  "id" : 733783815202689025,
  "in_reply_to_status_id" : 733783497635209216,
  "created_at" : "2016-05-20 22:17:49 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ursula G #NoKill",
      "screen_name" : "Ursulaanimals",
      "indices" : [ 0, 14 ],
      "id_str" : "2169853306",
      "id" : 2169853306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/TkPy9ddQ3n",
      "expanded_url" : "http:\/\/bit.ly\/22i9XYo",
      "display_url" : "bit.ly\/22i9XYo"
    } ]
  },
  "in_reply_to_status_id_str" : "733782584820404226",
  "geo" : { },
  "id_str" : "733783622646398976",
  "in_reply_to_user_id" : 2169853306,
  "text" : "@Ursulaanimals Please support my Thunderclap: https:\/\/t.co\/TkPy9ddQ3n",
  "id" : 733783622646398976,
  "in_reply_to_status_id" : 733782584820404226,
  "created_at" : "2016-05-20 22:17:03 +0000",
  "in_reply_to_screen_name" : "Ursulaanimals",
  "in_reply_to_user_id_str" : "2169853306",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733763131822870528",
  "geo" : { },
  "id_str" : "733763771068514304",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki Haha no way!!!",
  "id" : 733763771068514304,
  "in_reply_to_status_id" : 733763131822870528,
  "created_at" : "2016-05-20 20:58:10 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733755240235839490",
  "text" : "God made us for a purpose. There is something bigger.",
  "id" : 733755240235839490,
  "created_at" : "2016-05-20 20:24:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 3, 16 ],
      "id_str" : "19362341",
      "id" : 19362341
    }, {
      "name" : "C. Schwarzenegger",
      "screen_name" : "CSchwarzenegger",
      "indices" : [ 51, 67 ],
      "id_str" : "459905688",
      "id" : 459905688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/8LcfWKZrY4",
      "expanded_url" : "https:\/\/twitter.com\/cschwarzenegger\/status\/733698656549765120",
      "display_url" : "twitter.com\/cschwarzenegge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733755138809040896",
  "text" : "RT @mariashriver: Thank you my supportive daughter @CSchwarzenegger  https:\/\/t.co\/8LcfWKZrY4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C. Schwarzenegger",
        "screen_name" : "CSchwarzenegger",
        "indices" : [ 33, 49 ],
        "id_str" : "459905688",
        "id" : 459905688
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/8LcfWKZrY4",
        "expanded_url" : "https:\/\/twitter.com\/cschwarzenegger\/status\/733698656549765120",
        "display_url" : "twitter.com\/cschwarzenegge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733755006810120192",
    "text" : "Thank you my supportive daughter @CSchwarzenegger  https:\/\/t.co\/8LcfWKZrY4",
    "id" : 733755006810120192,
    "created_at" : "2016-05-20 20:23:20 +0000",
    "user" : {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "protected" : false,
      "id_str" : "19362341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522145107785428992\/zP6X2qUd_normal.jpeg",
      "id" : 19362341,
      "verified" : true
    }
  },
  "id" : 733755138809040896,
  "created_at" : "2016-05-20 20:23:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "indices" : [ 3, 14 ],
      "id_str" : "242435607",
      "id" : 242435607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733754967337635841",
  "text" : "RT @Anba_Ermia: \u0648\u0633\u064A\u0635\u0644\u0649 \u0639\u0644\u0649 \u062C\u062B\u0645\u0627\u0646\u0647 \u0627\u0644\u0637\u0627\u0647\u0631 \u0627\u0644\u0648\u0627\u062D\u062F\u0629 \u0638\u0647\u0631 \u0627\u0644\u063A\u062F \u0628\u0643\u0646\u064A\u0633\u0629 \u0627\u0644\u0645\u0644\u0627\u0643 \u0628\u0637\u0648\u0633\u0646.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733754642283270145",
    "text" : "\u0648\u0633\u064A\u0635\u0644\u0649 \u0639\u0644\u0649 \u062C\u062B\u0645\u0627\u0646\u0647 \u0627\u0644\u0637\u0627\u0647\u0631 \u0627\u0644\u0648\u0627\u062D\u062F\u0629 \u0638\u0647\u0631 \u0627\u0644\u063A\u062F \u0628\u0643\u0646\u064A\u0633\u0629 \u0627\u0644\u0645\u0644\u0627\u0643 \u0628\u0637\u0648\u0633\u0646.",
    "id" : 733754642283270145,
    "created_at" : "2016-05-20 20:21:53 +0000",
    "user" : {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "protected" : false,
      "id_str" : "242435607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580148862\/4cf7cba83bbd8d24e3a9a21f82ebc51e_normal.jpeg",
      "id" : 242435607,
      "verified" : false
    }
  },
  "id" : 733754967337635841,
  "created_at" : "2016-05-20 20:23:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Natasha",
      "screen_name" : "riptari",
      "indices" : [ 100, 108 ],
      "id_str" : "15734027",
      "id" : 15734027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/UgT9ynJrQd",
      "expanded_url" : "http:\/\/tcrn.ch\/1TuvuLe",
      "display_url" : "tcrn.ch\/1TuvuLe"
    } ]
  },
  "geo" : { },
  "id_str" : "733676180688244736",
  "text" : "RT @TechCrunch: Privacy guidance for drone operators issued by US agency https:\/\/t.co\/UgT9ynJrQd by @riptari",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Natasha",
        "screen_name" : "riptari",
        "indices" : [ 84, 92 ],
        "id_str" : "15734027",
        "id" : 15734027
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/UgT9ynJrQd",
        "expanded_url" : "http:\/\/tcrn.ch\/1TuvuLe",
        "display_url" : "tcrn.ch\/1TuvuLe"
      } ]
    },
    "geo" : { },
    "id_str" : "733660256203476992",
    "text" : "Privacy guidance for drone operators issued by US agency https:\/\/t.co\/UgT9ynJrQd by @riptari",
    "id" : 733660256203476992,
    "created_at" : "2016-05-20 14:06:50 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969240943671955456\/mGuud28F_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 733676180688244736,
  "created_at" : "2016-05-20 15:10:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TechCrunch\/status\/733671136802820096\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/iT8JsT8cVM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6GAg6XIAAPQ78.jpg",
      "id_str" : "733671132700811264",
      "id" : 733671132700811264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6GAg6XIAAPQ78.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 616
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/iT8JsT8cVM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/btvFVm1Imi",
      "expanded_url" : "http:\/\/tcrn.ch\/27FdrIw",
      "display_url" : "tcrn.ch\/27FdrIw"
    } ]
  },
  "geo" : { },
  "id_str" : "733676135725273088",
  "text" : "RT @TechCrunch: Chemists create an app that can tell if your beer is skunked https:\/\/t.co\/btvFVm1Imi https:\/\/t.co\/iT8JsT8cVM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechCrunch\/status\/733671136802820096\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/iT8JsT8cVM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6GAg6XIAAPQ78.jpg",
        "id_str" : "733671132700811264",
        "id" : 733671132700811264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6GAg6XIAAPQ78.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 616
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/iT8JsT8cVM"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/btvFVm1Imi",
        "expanded_url" : "http:\/\/tcrn.ch\/27FdrIw",
        "display_url" : "tcrn.ch\/27FdrIw"
      } ]
    },
    "geo" : { },
    "id_str" : "733671136802820096",
    "text" : "Chemists create an app that can tell if your beer is skunked https:\/\/t.co\/btvFVm1Imi https:\/\/t.co\/iT8JsT8cVM",
    "id" : 733671136802820096,
    "created_at" : "2016-05-20 14:50:04 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969240943671955456\/mGuud28F_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 733676135725273088,
  "created_at" : "2016-05-20 15:09:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/733675034615676928\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/PlwBr6Vxjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6Jjn7XIAAzrzZ.jpg",
      "id_str" : "733675034414358528",
      "id" : 733675034414358528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6Jjn7XIAAzrzZ.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PlwBr6Vxjg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/QHhp5XHi0e",
      "expanded_url" : "http:\/\/holykaw.alltop.com\/emotional-life-dogs-infographic?gk4",
      "display_url" : "holykaw.alltop.com\/emotional-life\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733676027550027776",
  "text" : "RT @GuyKawasaki: The emotional life of dogs [infographic] https:\/\/t.co\/QHhp5XHi0e https:\/\/t.co\/PlwBr6Vxjg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/alltop.com\/\" rel=\"nofollow\"\u003EAlltop Tweets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GuyKawasaki\/status\/733675034615676928\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/PlwBr6Vxjg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6Jjn7XIAAzrzZ.jpg",
        "id_str" : "733675034414358528",
        "id" : 733675034414358528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6Jjn7XIAAzrzZ.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/PlwBr6Vxjg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/QHhp5XHi0e",
        "expanded_url" : "http:\/\/holykaw.alltop.com\/emotional-life-dogs-infographic?gk4",
        "display_url" : "holykaw.alltop.com\/emotional-life\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733675034615676928",
    "text" : "The emotional life of dogs [infographic] https:\/\/t.co\/QHhp5XHi0e https:\/\/t.co\/PlwBr6Vxjg",
    "id" : 733675034615676928,
    "created_at" : "2016-05-20 15:05:33 +0000",
    "user" : {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "protected" : false,
      "id_str" : "8453452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791041568006348801\/_4Bbilhv_normal.jpg",
      "id" : 8453452,
      "verified" : true
    }
  },
  "id" : 733676027550027776,
  "created_at" : "2016-05-20 15:09:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "indices" : [ 3, 14 ],
      "id_str" : "552147406",
      "id" : 552147406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733675938521714690",
  "text" : "RT @TriviaHive: 47 million elementary school students use Elmer's Glue on a weekly basis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733675179663069186",
    "text" : "47 million elementary school students use Elmer's Glue on a weekly basis",
    "id" : 733675179663069186,
    "created_at" : "2016-05-20 15:06:08 +0000",
    "user" : {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "protected" : false,
      "id_str" : "552147406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705567159968071680\/PQrm33In_normal.jpg",
      "id" : 552147406,
      "verified" : false
    }
  },
  "id" : 733675938521714690,
  "created_at" : "2016-05-20 15:09:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733675907735556097",
  "text" : "RT @buysellshort: $NFLX rocking n rolling  -best couple days we seen in it in a few weeks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733675182447976448",
    "text" : "$NFLX rocking n rolling  -best couple days we seen in it in a few weeks",
    "id" : 733675182447976448,
    "created_at" : "2016-05-20 15:06:09 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : true,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 733675907735556097,
  "created_at" : "2016-05-20 15:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/lkWPARQLwT",
      "expanded_url" : "http:\/\/mashable.com\/2016\/05\/20\/aaron-gordon-zach-lavine-2k17-motion-capture\/",
      "display_url" : "mashable.com\/2016\/05\/20\/aar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733675881768620032",
  "text" : "RT @EmperorDarroux: How Aaron Gordon and Zach LaVine dunked their way into the 'NBA 2K17' video game https:\/\/t.co\/lkWPARQLwT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/lkWPARQLwT",
        "expanded_url" : "http:\/\/mashable.com\/2016\/05\/20\/aaron-gordon-zach-lavine-2k17-motion-capture\/",
        "display_url" : "mashable.com\/2016\/05\/20\/aar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733675412199464960",
    "text" : "How Aaron Gordon and Zach LaVine dunked their way into the 'NBA 2K17' video game https:\/\/t.co\/lkWPARQLwT",
    "id" : 733675412199464960,
    "created_at" : "2016-05-20 15:07:03 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 733675881768620032,
  "created_at" : "2016-05-20 15:08:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "indices" : [ 3, 16 ],
      "id_str" : "18433619",
      "id" : 18433619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733675812826820610",
  "text" : "RT @buysellshort: beaten up bio stocks from the last month looking very nice, lots of potential plays",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733675700729700354",
    "text" : "beaten up bio stocks from the last month looking very nice, lots of potential plays",
    "id" : 733675700729700354,
    "created_at" : "2016-05-20 15:08:12 +0000",
    "user" : {
      "name" : "buysellshort.net",
      "screen_name" : "buysellshort",
      "protected" : true,
      "id_str" : "18433619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1376766400\/BUYSELLSHORT2_test-2_normal.png",
      "id" : 18433619,
      "verified" : false
    }
  },
  "id" : 733675812826820610,
  "created_at" : "2016-05-20 15:08:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thunderclap",
      "screen_name" : "ThunderclapIt",
      "indices" : [ 0, 14 ],
      "id_str" : "561518048",
      "id" : 561518048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/TkPy9ddQ3n",
      "expanded_url" : "http:\/\/bit.ly\/22i9XYo",
      "display_url" : "bit.ly\/22i9XYo"
    } ]
  },
  "geo" : { },
  "id_str" : "733675753792020480",
  "in_reply_to_user_id" : 561518048,
  "text" : "@ThunderclapIt Just made a ThunderClap https:\/\/t.co\/TkPy9ddQ3n",
  "id" : 733675753792020480,
  "created_at" : "2016-05-20 15:08:25 +0000",
  "in_reply_to_screen_name" : "ThunderclapIt",
  "in_reply_to_user_id_str" : "561518048",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDFB8 ZE\u14AA\u142FI\u1515 \uD83C\uDFB8",
      "screen_name" : "loridowney3",
      "indices" : [ 0, 12 ],
      "id_str" : "1325229535",
      "id" : 1325229535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/TkPy9ddQ3n",
      "expanded_url" : "http:\/\/bit.ly\/22i9XYo",
      "display_url" : "bit.ly\/22i9XYo"
    } ]
  },
  "in_reply_to_status_id_str" : "733159258737381376",
  "geo" : { },
  "id_str" : "733675514427277312",
  "in_reply_to_user_id" : 1325229535,
  "text" : "@loridowney3 Please support my ThunderClap https:\/\/t.co\/TkPy9ddQ3n",
  "id" : 733675514427277312,
  "in_reply_to_status_id" : 733159258737381376,
  "created_at" : "2016-05-20 15:07:28 +0000",
  "in_reply_to_screen_name" : "loridowney3",
  "in_reply_to_user_id_str" : "1325229535",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eddie Izzard",
      "screen_name" : "eddieizzard",
      "indices" : [ 0, 12 ],
      "id_str" : "24447643",
      "id" : 24447643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/TkPy9ddQ3n",
      "expanded_url" : "http:\/\/bit.ly\/22i9XYo",
      "display_url" : "bit.ly\/22i9XYo"
    } ]
  },
  "in_reply_to_status_id_str" : "733239381088210944",
  "geo" : { },
  "id_str" : "733675210025664512",
  "in_reply_to_user_id" : 24447643,
  "text" : "@eddieizzard Please check out my ThunderClap https:\/\/t.co\/TkPy9ddQ3n",
  "id" : 733675210025664512,
  "in_reply_to_status_id" : 733239381088210944,
  "created_at" : "2016-05-20 15:06:15 +0000",
  "in_reply_to_screen_name" : "eddieizzard",
  "in_reply_to_user_id_str" : "24447643",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TechCrunch\/status\/733448408640434176\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/igRkhXLjGx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci27cOlWYAECE-V.jpg",
      "id_str" : "733448407956742145",
      "id" : 733448407956742145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci27cOlWYAECE-V.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 615
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/igRkhXLjGx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Y4hQ0FarYN",
      "expanded_url" : "http:\/\/tcrn.ch\/27DnI7S",
      "display_url" : "tcrn.ch\/27DnI7S"
    } ]
  },
  "geo" : { },
  "id_str" : "733454994364628993",
  "text" : "RT @TechCrunch: Boosted\u2019s v2 electric skateboards go 12 miles with swappable batteries https:\/\/t.co\/Y4hQ0FarYN https:\/\/t.co\/igRkhXLjGx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TechCrunch\/status\/733448408640434176\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/igRkhXLjGx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci27cOlWYAECE-V.jpg",
        "id_str" : "733448407956742145",
        "id" : 733448407956742145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci27cOlWYAECE-V.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 615
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/igRkhXLjGx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/Y4hQ0FarYN",
        "expanded_url" : "http:\/\/tcrn.ch\/27DnI7S",
        "display_url" : "tcrn.ch\/27DnI7S"
      } ]
    },
    "geo" : { },
    "id_str" : "733448408640434176",
    "text" : "Boosted\u2019s v2 electric skateboards go 12 miles with swappable batteries https:\/\/t.co\/Y4hQ0FarYN https:\/\/t.co\/igRkhXLjGx",
    "id" : 733448408640434176,
    "created_at" : "2016-05-20 00:05:02 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969240943671955456\/mGuud28F_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 733454994364628993,
  "created_at" : "2016-05-20 00:31:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733437108019306496",
  "text" : "RT @lorenridinger: \"The best preparation for tomorrow is doing your best today.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733417257334919168",
    "text" : "\"The best preparation for tomorrow is doing your best today.\"",
    "id" : 733417257334919168,
    "created_at" : "2016-05-19 22:01:15 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 733437108019306496,
  "created_at" : "2016-05-19 23:20:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/733431436330606594\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Jgoxzs8Bmf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci2sATrUYAEn0Zs.jpg",
      "id_str" : "733431435613200385",
      "id" : 733431435613200385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci2sATrUYAEn0Zs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Jgoxzs8Bmf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/TxlMSFntPb",
      "expanded_url" : "http:\/\/engt.co\/20cwvbk",
      "display_url" : "engt.co\/20cwvbk"
    } ]
  },
  "geo" : { },
  "id_str" : "733436936463912960",
  "text" : "RT @engadget: US Navy to arm its submarines with 'Blackwing' spy drones https:\/\/t.co\/TxlMSFntPb https:\/\/t.co\/Jgoxzs8Bmf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/733431436330606594\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/Jgoxzs8Bmf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci2sATrUYAEn0Zs.jpg",
        "id_str" : "733431435613200385",
        "id" : 733431435613200385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci2sATrUYAEn0Zs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Jgoxzs8Bmf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/TxlMSFntPb",
        "expanded_url" : "http:\/\/engt.co\/20cwvbk",
        "display_url" : "engt.co\/20cwvbk"
      } ]
    },
    "geo" : { },
    "id_str" : "733431436330606594",
    "text" : "US Navy to arm its submarines with 'Blackwing' spy drones https:\/\/t.co\/TxlMSFntPb https:\/\/t.co\/Jgoxzs8Bmf",
    "id" : 733431436330606594,
    "created_at" : "2016-05-19 22:57:35 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 733436936463912960,
  "created_at" : "2016-05-19 23:19:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skype",
      "screen_name" : "Skype",
      "indices" : [ 3, 9 ],
      "id_str" : "2459371",
      "id" : 2459371
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Skype\/status\/733434710660108289\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/4c3CHBPaOO",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2u-sxVAAAX0fw.jpg",
      "id_str" : "733434706524438528",
      "id" : 733434706524438528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2u-sxVAAAX0fw.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1080
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4c3CHBPaOO"
    } ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 11, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733436178431512576",
  "text" : "RT @Skype: #BadIdeaIn5Words: Forgetting to call mom back. https:\/\/t.co\/4c3CHBPaOO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Skype\/status\/733434710660108289\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/4c3CHBPaOO",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2u-sxVAAAX0fw.jpg",
        "id_str" : "733434706524438528",
        "id" : 733434706524438528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2u-sxVAAAX0fw.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 1080
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/4c3CHBPaOO"
      } ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733434710660108289",
    "text" : "#BadIdeaIn5Words: Forgetting to call mom back. https:\/\/t.co\/4c3CHBPaOO",
    "id" : 733434710660108289,
    "created_at" : "2016-05-19 23:10:36 +0000",
    "user" : {
      "name" : "Skype",
      "screen_name" : "Skype",
      "protected" : false,
      "id_str" : "2459371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/860624263669096449\/m-mJKvsM_normal.jpg",
      "id" : 2459371,
      "verified" : true
    }
  },
  "id" : 733436178431512576,
  "created_at" : "2016-05-19 23:16:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany",
      "screen_name" : "Brittlovesssxo",
      "indices" : [ 3, 18 ],
      "id_str" : "1582255993",
      "id" : 1582255993
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badideain5words",
      "indices" : [ 47, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733436081496985600",
  "text" : "RT @Brittlovesssxo: i can finish this tomorrow #badideain5words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badideain5words",
        "indices" : [ 27, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733435372898783232",
    "text" : "i can finish this tomorrow #badideain5words",
    "id" : 733435372898783232,
    "created_at" : "2016-05-19 23:13:14 +0000",
    "user" : {
      "name" : "Brittany",
      "screen_name" : "Brittlovesssxo",
      "protected" : false,
      "id_str" : "1582255993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711335170964627456\/unJnrKIy_normal.jpg",
      "id" : 1582255993,
      "verified" : false
    }
  },
  "id" : 733436081496985600,
  "created_at" : "2016-05-19 23:16:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AntiPornography.org",
      "screen_name" : "AntiPornography",
      "indices" : [ 3, 19 ],
      "id_str" : "75921365",
      "id" : 75921365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pornharms",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733435705926529025",
  "text" : "RT @AntiPornography: The porn industry is known to involve trafficked women &amp; children in films, images, &amp; on the web. #pornharms https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pornharms",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1xj7Nhkev2",
        "expanded_url" : "http:\/\/humangoods.net\/?p=993",
        "display_url" : "humangoods.net\/?p=993"
      } ]
    },
    "geo" : { },
    "id_str" : "732932502038306816",
    "text" : "The porn industry is known to involve trafficked women &amp; children in films, images, &amp; on the web. #pornharms https:\/\/t.co\/1xj7Nhkev2",
    "id" : 732932502038306816,
    "created_at" : "2016-05-18 13:55:00 +0000",
    "user" : {
      "name" : "AntiPornography.org",
      "screen_name" : "AntiPornography",
      "protected" : false,
      "id_str" : "75921365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000233025723\/e99aba7d7e07012d8eec9e3536f2db5f_normal.jpeg",
      "id" : 75921365,
      "verified" : false
    }
  },
  "id" : 733435705926529025,
  "created_at" : "2016-05-19 23:14:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FIGHTERS",
      "screen_name" : "FightTheNewDrug",
      "indices" : [ 3, 19 ],
      "id_str" : "51081149",
      "id" : 51081149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733435469032095744",
  "text" : "RT @FightTheNewDrug: Porn is a $97 billion industry, with $10 billion of that coming from the US. If you don't think porn is a global issue\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732387701920530432",
    "text" : "Porn is a $97 billion industry, with $10 billion of that coming from the US. If you don't think porn is a global issue, think again.",
    "id" : 732387701920530432,
    "created_at" : "2016-05-17 01:50:09 +0000",
    "user" : {
      "name" : "FIGHTERS",
      "screen_name" : "FightTheNewDrug",
      "protected" : false,
      "id_str" : "51081149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979760032345604096\/mi1OGBRK_normal.jpg",
      "id" : 51081149,
      "verified" : true
    }
  },
  "id" : 733435469032095744,
  "created_at" : "2016-05-19 23:13:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FIGHTERS",
      "screen_name" : "FightTheNewDrug",
      "indices" : [ 3, 19 ],
      "id_str" : "51081149",
      "id" : 51081149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalSendANudeDay",
      "indices" : [ 21, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733435295262068736",
  "text" : "RT @FightTheNewDrug: #NationalSendANudeDay is really not cool. This video shows one of many reasons why. Watch and share! https:\/\/t.co\/tYSm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalSendANudeDay",
        "indices" : [ 0, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/tYSmA5mXh5",
        "expanded_url" : "https:\/\/twitter.com\/NSPCC\/status\/733325751538225153",
        "display_url" : "twitter.com\/NSPCC\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733376984978325505",
    "text" : "#NationalSendANudeDay is really not cool. This video shows one of many reasons why. Watch and share! https:\/\/t.co\/tYSmA5mXh5",
    "id" : 733376984978325505,
    "created_at" : "2016-05-19 19:21:13 +0000",
    "user" : {
      "name" : "FIGHTERS",
      "screen_name" : "FightTheNewDrug",
      "protected" : false,
      "id_str" : "51081149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979760032345604096\/mi1OGBRK_normal.jpg",
      "id" : 51081149,
      "verified" : true
    }
  },
  "id" : 733435295262068736,
  "created_at" : "2016-05-19 23:12:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733395632304599040",
  "text" : "RT @realDonaldTrump: I look so forward to debating Crooked Hillary Clinton! Democrat Primaries are rigged, e-mail investigation is rigged -\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732751047022628865",
    "text" : "I look so forward to debating Crooked Hillary Clinton! Democrat Primaries are rigged, e-mail investigation is rigged - so time to get it on!",
    "id" : 732751047022628865,
    "created_at" : "2016-05-18 01:53:58 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874276197357596672\/kUuht00m_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 733395632304599040,
  "created_at" : "2016-05-19 20:35:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Reddit",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Kx1fiYSqm8",
      "expanded_url" : "http:\/\/bit.ly\/1ThYdES",
      "display_url" : "bit.ly\/1ThYdES"
    } ]
  },
  "geo" : { },
  "id_str" : "733395056627965952",
  "text" : "Check us on #Reddit https:\/\/t.co\/Kx1fiYSqm8",
  "id" : 733395056627965952,
  "created_at" : "2016-05-19 20:33:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lost in history",
      "screen_name" : "Sadhappyamazing",
      "indices" : [ 3, 19 ],
      "id_str" : "2972851670",
      "id" : 2972851670
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/732269261683449856\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/81BX61o6oj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CimLAaVWEAEUqIi.jpg",
      "id_str" : "732269253609525249",
      "id" : 732269253609525249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimLAaVWEAEUqIi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/81BX61o6oj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733374965995700224",
  "text" : "RT @SadHappyAmazing: James Dean and his Silver Porsche 550 Spyder, hours before the fatal crash in 1955. https:\/\/t.co\/81BX61o6oj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/732269261683449856\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/81BX61o6oj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimLAaVWEAEUqIi.jpg",
        "id_str" : "732269253609525249",
        "id" : 732269253609525249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimLAaVWEAEUqIi.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/81BX61o6oj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732269261683449856",
    "text" : "James Dean and his Silver Porsche 550 Spyder, hours before the fatal crash in 1955. https:\/\/t.co\/81BX61o6oj",
    "id" : 732269261683449856,
    "created_at" : "2016-05-16 17:59:31 +0000",
    "user" : {
      "name" : "Lost In History",
      "screen_name" : "HistoryToLearn",
      "protected" : false,
      "id_str" : "149760844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785671241004834816\/U77CuifE_normal.jpg",
      "id" : 149760844,
      "verified" : false
    }
  },
  "id" : 733374965995700224,
  "created_at" : "2016-05-19 19:13:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lost in history",
      "screen_name" : "Sadhappyamazing",
      "indices" : [ 3, 19 ],
      "id_str" : "2972851670",
      "id" : 2972851670
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jpdKxQCo8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEeQ8UkAAqZbw.jpg",
      "id_str" : "733106494833463296",
      "id" : 733106494833463296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEeQ8UkAAqZbw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 422
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 422
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jpdKxQCo8g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jpdKxQCo8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEcPIWsAAiPds.jpg",
      "id_str" : "733106459987324928",
      "id" : 733106459987324928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEcPIWsAAiPds.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 438
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 484
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jpdKxQCo8g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jpdKxQCo8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEdStVEAAqOJT.jpg",
      "id_str" : "733106478127583232",
      "id" : 733106478127583232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEdStVEAAqOJT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 498
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jpdKxQCo8g"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/jpdKxQCo8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEfZmXEAAmqNq.jpg",
      "id_str" : "733106514337140736",
      "id" : 733106514337140736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEfZmXEAAmqNq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 750
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jpdKxQCo8g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733374700538191872",
  "text" : "RT @SadHappyAmazing: Chicago, 1950s https:\/\/t.co\/jpdKxQCo8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/jpdKxQCo8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEeQ8UkAAqZbw.jpg",
        "id_str" : "733106494833463296",
        "id" : 733106494833463296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEeQ8UkAAqZbw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 422
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 422
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jpdKxQCo8g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/jpdKxQCo8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEcPIWsAAiPds.jpg",
        "id_str" : "733106459987324928",
        "id" : 733106459987324928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEcPIWsAAiPds.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 438
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 484
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jpdKxQCo8g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/jpdKxQCo8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEdStVEAAqOJT.jpg",
        "id_str" : "733106478127583232",
        "id" : 733106478127583232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEdStVEAAqOJT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 498
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jpdKxQCo8g"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733106525741404161\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/jpdKxQCo8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiyEfZmXEAAmqNq.jpg",
        "id_str" : "733106514337140736",
        "id" : 733106514337140736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiyEfZmXEAAmqNq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 527
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 750
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jpdKxQCo8g"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733106525741404161",
    "text" : "Chicago, 1950s https:\/\/t.co\/jpdKxQCo8g",
    "id" : 733106525741404161,
    "created_at" : "2016-05-19 01:26:30 +0000",
    "user" : {
      "name" : "Lost In History",
      "screen_name" : "HistoryToLearn",
      "protected" : false,
      "id_str" : "149760844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785671241004834816\/U77CuifE_normal.jpg",
      "id" : 149760844,
      "verified" : false
    }
  },
  "id" : 733374700538191872,
  "created_at" : "2016-05-19 19:12:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lost in history",
      "screen_name" : "Sadhappyamazing",
      "indices" : [ 3, 19 ],
      "id_str" : "2972851670",
      "id" : 2972851670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733374678488780800",
  "text" : "RT @SadHappyAmazing: Neil Armstrong fishing in Iceland during a trip where the Apollo 11 team prepared for the Voyage to the Moon https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SadHappyAmazing\/status\/733145242929614848\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/EHvoTyB7sM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciynr6aUkAAvyox.jpg",
        "id_str" : "733145212210417664",
        "id" : 733145212210417664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciynr6aUkAAvyox.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 454
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/EHvoTyB7sM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733145242929614848",
    "text" : "Neil Armstrong fishing in Iceland during a trip where the Apollo 11 team prepared for the Voyage to the Moon https:\/\/t.co\/EHvoTyB7sM",
    "id" : 733145242929614848,
    "created_at" : "2016-05-19 04:00:21 +0000",
    "user" : {
      "name" : "Lost In History",
      "screen_name" : "HistoryToLearn",
      "protected" : false,
      "id_str" : "149760844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785671241004834816\/U77CuifE_normal.jpg",
      "id" : 149760844,
      "verified" : false
    }
  },
  "id" : 733374678488780800,
  "created_at" : "2016-05-19 19:12:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Tweets\u2122",
      "screen_name" : "Lmao",
      "indices" : [ 0, 5 ],
      "id_str" : "237634998",
      "id" : 237634998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "geo" : { },
  "id_str" : "733374528890544128",
  "in_reply_to_user_id" : 237634998,
  "text" : "@Lmao Check out my #HeadTalker campaign https:\/\/t.co\/7RnJi9wx6E",
  "id" : 733374528890544128,
  "created_at" : "2016-05-19 19:11:27 +0000",
  "in_reply_to_screen_name" : "Lmao",
  "in_reply_to_user_id_str" : "237634998",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beppe Del Medico",
      "screen_name" : "beppedelmedico",
      "indices" : [ 0, 15 ],
      "id_str" : "767286449108426752",
      "id" : 767286449108426752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "geo" : { },
  "id_str" : "733374148429402112",
  "text" : "@BeppeDelMedico Check out my #HeadTalker campaign https:\/\/t.co\/7RnJi9wx6E",
  "id" : 733374148429402112,
  "created_at" : "2016-05-19 19:09:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Miller",
      "screen_name" : "jennim1982",
      "indices" : [ 0, 11 ],
      "id_str" : "2806570217",
      "id" : 2806570217
    }, {
      "name" : "Rebecca Hamilton",
      "screen_name" : "InkMuse",
      "indices" : [ 12, 20 ],
      "id_str" : "139529558",
      "id" : 139529558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/7RnJi9wx6E",
      "expanded_url" : "http:\/\/bit.ly\/22hrtw7",
      "display_url" : "bit.ly\/22hrtw7"
    } ]
  },
  "in_reply_to_status_id_str" : "733362467024326657",
  "geo" : { },
  "id_str" : "733374085686759425",
  "in_reply_to_user_id" : 2806570217,
  "text" : "@jennim1982 @InkMuse Check out my #HeadTalker campaign https:\/\/t.co\/7RnJi9wx6E",
  "id" : 733374085686759425,
  "in_reply_to_status_id" : 733362467024326657,
  "created_at" : "2016-05-19 19:09:42 +0000",
  "in_reply_to_screen_name" : "jennim1982",
  "in_reply_to_user_id_str" : "2806570217",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 35, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733373393949630464",
  "text" : "Gonna do that mountain-board thing #BadIdeaIn5Words",
  "id" : 733373393949630464,
  "created_at" : "2016-05-19 19:06:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733373291696693248",
  "text" : "I am now gonna rest #BadIdeaIn5Words",
  "id" : 733373291696693248,
  "created_at" : "2016-05-19 19:06:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abolish ice. send homan to the hague.",
      "screen_name" : "SeanMcElwee",
      "indices" : [ 3, 15 ],
      "id_str" : "318692762",
      "id" : 318692762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 17, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733372865232404481",
  "text" : "RT @SeanMcElwee: #BadIdeaIn5Words neoliberal policies can end poverty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733338864291618816",
    "text" : "#BadIdeaIn5Words neoliberal policies can end poverty",
    "id" : 733338864291618816,
    "created_at" : "2016-05-19 16:49:44 +0000",
    "user" : {
      "name" : "abolish ice. send homan to the hague.",
      "screen_name" : "SeanMcElwee",
      "protected" : false,
      "id_str" : "318692762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822966346992549889\/NyoZ3sZZ_normal.jpg",
      "id" : 318692762,
      "verified" : true
    }
  },
  "id" : 733372865232404481,
  "created_at" : "2016-05-19 19:04:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 61, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733372675792461826",
  "text" : "RT @Southern_PUNdit: Taxing the country's most productive.\n\n #BadIdeaIn5Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 40, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733357584443396096",
    "text" : "Taxing the country's most productive.\n\n #BadIdeaIn5Words",
    "id" : 733357584443396096,
    "created_at" : "2016-05-19 18:04:07 +0000",
    "user" : {
      "name" : "\uD83C\uDDFA\uD83C\uDDF8 Red, White, & Blue Devil \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "DukeBluePatriot",
      "protected" : false,
      "id_str" : "2363077314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/976961396373184512\/U17z59B4_normal.jpg",
      "id" : 2363077314,
      "verified" : false
    }
  },
  "id" : 733372675792461826,
  "created_at" : "2016-05-19 19:04:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malone",
      "screen_name" : "realmalone",
      "indices" : [ 3, 14 ],
      "id_str" : "288519272",
      "id" : 288519272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733372597958803458",
  "text" : "RT @RealMalone: I'll finish it tomorrow morning\n#BadIdeaIn5Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 32, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733371040198451200",
    "text" : "I'll finish it tomorrow morning\n#BadIdeaIn5Words",
    "id" : 733371040198451200,
    "created_at" : "2016-05-19 18:57:36 +0000",
    "user" : {
      "name" : "Moxas",
      "screen_name" : "MoraMoxas",
      "protected" : false,
      "id_str" : "2733831551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/982364038695763969\/_rmHBmEi_normal.jpg",
      "id" : 2733831551,
      "verified" : false
    }
  },
  "id" : 733372597958803458,
  "created_at" : "2016-05-19 19:03:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tasha Robinson",
      "screen_name" : "TashaRobinson",
      "indices" : [ 3, 17 ],
      "id_str" : "18518052",
      "id" : 18518052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TashaRobinson\/status\/733371365479309312\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/oKGj24eANZ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci11WTWVAAAE08L.jpg",
      "id_str" : "733371340342755328",
      "id" : 733371340342755328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci11WTWVAAAE08L.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 352
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/oKGj24eANZ"
    } ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 19, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733372567814311936",
  "text" : "RT @TashaRobinson: #BadIdeaIn5Words \"Let's read some YouTube comments.\" https:\/\/t.co\/oKGj24eANZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TashaRobinson\/status\/733371365479309312\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/oKGj24eANZ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci11WTWVAAAE08L.jpg",
        "id_str" : "733371340342755328",
        "id" : 733371340342755328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci11WTWVAAAE08L.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 352
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 352
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 352
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 352
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/oKGj24eANZ"
      } ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733371365479309312",
    "text" : "#BadIdeaIn5Words \"Let's read some YouTube comments.\" https:\/\/t.co\/oKGj24eANZ",
    "id" : 733371365479309312,
    "created_at" : "2016-05-19 18:58:53 +0000",
    "user" : {
      "name" : "Tasha Robinson",
      "screen_name" : "TashaRobinson",
      "protected" : false,
      "id_str" : "18518052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546016795841138688\/bL654kDd_normal.jpeg",
      "id" : 18518052,
      "verified" : true
    }
  },
  "id" : 733372567814311936,
  "created_at" : "2016-05-19 19:03:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitch",
      "screen_name" : "Twitch",
      "indices" : [ 3, 10 ],
      "id_str" : "309366491",
      "id" : 309366491
    }, {
      "name" : "Inferno988",
      "screen_name" : "inferno988",
      "indices" : [ 68, 79 ],
      "id_str" : "427895078",
      "id" : 427895078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Twitch\/status\/733357762319679489\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/i5gX6JGRjt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci1oyRSVAAA6pRS.jpg",
      "id_str" : "733357527174283264",
      "id" : 733357527174283264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci1oyRSVAAA6pRS.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/i5gX6JGRjt"
    } ],
    "hashtags" : [ {
      "text" : "BadIdeaIn5Words",
      "indices" : [ 41, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733372470225408000",
  "text" : "RT @Twitch: Let Twitch Chat control you. #BadIdeaIn5Words\n\n(Art via @inferno988) https:\/\/t.co\/i5gX6JGRjt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inferno988",
        "screen_name" : "inferno988",
        "indices" : [ 56, 67 ],
        "id_str" : "427895078",
        "id" : 427895078
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Twitch\/status\/733357762319679489\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/i5gX6JGRjt",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci1oyRSVAAA6pRS.jpg",
        "id_str" : "733357527174283264",
        "id" : 733357527174283264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci1oyRSVAAA6pRS.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/i5gX6JGRjt"
      } ],
      "hashtags" : [ {
        "text" : "BadIdeaIn5Words",
        "indices" : [ 29, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733357762319679489",
    "text" : "Let Twitch Chat control you. #BadIdeaIn5Words\n\n(Art via @inferno988) https:\/\/t.co\/i5gX6JGRjt",
    "id" : 733357762319679489,
    "created_at" : "2016-05-19 18:04:50 +0000",
    "user" : {
      "name" : "Twitch",
      "screen_name" : "Twitch",
      "protected" : false,
      "id_str" : "309366491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979092312553750528\/2ejlMVyG_normal.jpg",
      "id" : 309366491,
      "verified" : true
    }
  },
  "id" : 733372470225408000,
  "created_at" : "2016-05-19 19:03:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdSpeaking",
      "screen_name" : "crowdspeaking",
      "indices" : [ 3, 17 ],
      "id_str" : "2484571358",
      "id" : 2484571358
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 23, 35 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 75, 86 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/PIQBKORX2x",
      "expanded_url" : "https:\/\/headtalker.com\/?p=62145",
      "display_url" : "headtalker.com\/?p=62145"
    } ]
  },
  "geo" : { },
  "id_str" : "733372405461229568",
  "text" : "RT @crowdspeaking: Hey @gamer456148 I just supported StartHub Messenger on @HeadTalker https:\/\/t.co\/PIQBKORX2x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 4, 16 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "HeadTalker",
        "screen_name" : "headtalker",
        "indices" : [ 56, 67 ],
        "id_str" : "2177390274",
        "id" : 2177390274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/PIQBKORX2x",
        "expanded_url" : "https:\/\/headtalker.com\/?p=62145",
        "display_url" : "headtalker.com\/?p=62145"
      } ]
    },
    "geo" : { },
    "id_str" : "733370021204918274",
    "text" : "Hey @gamer456148 I just supported StartHub Messenger on @HeadTalker https:\/\/t.co\/PIQBKORX2x",
    "id" : 733370021204918274,
    "created_at" : "2016-05-19 18:53:33 +0000",
    "user" : {
      "name" : "CrowdSpeaking",
      "screen_name" : "crowdspeaking",
      "protected" : false,
      "id_str" : "2484571358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703799038240358400\/uVflknPr_normal.jpg",
      "id" : 2484571358,
      "verified" : false
    }
  },
  "id" : 733372405461229568,
  "created_at" : "2016-05-19 19:03:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 43, 54 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/aTa2NmEFEL",
      "expanded_url" : "https:\/\/headtalker.com\/?p=62145",
      "display_url" : "headtalker.com\/?p=62145"
    } ]
  },
  "geo" : { },
  "id_str" : "733372280273838080",
  "text" : "Hey I just supported StartHub Messenger on @HeadTalker https:\/\/t.co\/aTa2NmEFEL",
  "id" : 733372280273838080,
  "created_at" : "2016-05-19 19:02:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detroit Free Press",
      "screen_name" : "freep",
      "indices" : [ 0, 6 ],
      "id_str" : "8795772",
      "id" : 8795772
    }, {
      "name" : "MSG",
      "screen_name" : "TheGarden",
      "indices" : [ 7, 17 ],
      "id_str" : "121254571",
      "id" : 121254571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733327005811412993",
  "geo" : { },
  "id_str" : "733361191804915712",
  "in_reply_to_user_id" : 8795772,
  "text" : "@freep @TheGarden She did more than sing happy birthday, oh the golden days, lol",
  "id" : 733361191804915712,
  "in_reply_to_status_id" : 733327005811412993,
  "created_at" : "2016-05-19 18:18:27 +0000",
  "in_reply_to_screen_name" : "freep",
  "in_reply_to_user_id_str" : "8795772",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pro Motocross",
      "screen_name" : "ProMotocross",
      "indices" : [ 3, 16 ],
      "id_str" : "115471142",
      "id" : 115471142
    }, {
      "name" : "David Pingree",
      "screen_name" : "davidpingree",
      "indices" : [ 42, 55 ],
      "id_str" : "223937589",
      "id" : 223937589
    }, {
      "name" : "hangtownmxclassic",
      "screen_name" : "hangtownmx",
      "indices" : [ 59, 70 ],
      "id_str" : "2452458026",
      "id" : 2452458026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "ProMotocross",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "ThisIsMoto",
      "indices" : [ 99, 110 ]
    }, {
      "text" : "TBT",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733360967640330240",
  "text" : "RT @ProMotocross: #ThrowbackThursday with @davidpingree at @hangtownmx back in 2000. #ProMotocross #ThisIsMoto #TBT (Photo - Kuhn) https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Pingree",
        "screen_name" : "davidpingree",
        "indices" : [ 24, 37 ],
        "id_str" : "223937589",
        "id" : 223937589
      }, {
        "name" : "hangtownmxclassic",
        "screen_name" : "hangtownmx",
        "indices" : [ 41, 52 ],
        "id_str" : "2452458026",
        "id" : 2452458026
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProMotocross\/status\/733346293670653953\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Q5WbRUtA5q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1ekT-VEAA9uX-.jpg",
        "id_str" : "733346292261261312",
        "id" : 733346292261261312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1ekT-VEAA9uX-.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Q5WbRUtA5q"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 0, 18 ]
      }, {
        "text" : "ProMotocross",
        "indices" : [ 67, 80 ]
      }, {
        "text" : "ThisIsMoto",
        "indices" : [ 81, 92 ]
      }, {
        "text" : "TBT",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733346293670653953",
    "text" : "#ThrowbackThursday with @davidpingree at @hangtownmx back in 2000. #ProMotocross #ThisIsMoto #TBT (Photo - Kuhn) https:\/\/t.co\/Q5WbRUtA5q",
    "id" : 733346293670653953,
    "created_at" : "2016-05-19 17:19:15 +0000",
    "user" : {
      "name" : "Pro Motocross",
      "screen_name" : "ProMotocross",
      "protected" : false,
      "id_str" : "115471142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734837644035784705\/1SnEqqL8_normal.jpg",
      "id" : 115471142,
      "verified" : false
    }
  },
  "id" : 733360967640330240,
  "created_at" : "2016-05-19 18:17:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCVD Official",
      "screen_name" : "JCVD",
      "indices" : [ 3, 8 ],
      "id_str" : "390216128",
      "id" : 390216128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamJCVD",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "ChuckNorris",
      "indices" : [ 62, 74 ]
    }, {
      "text" : "martialarts",
      "indices" : [ 75, 87 ]
    }, {
      "text" : "karate",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "tbt",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733360910216073216",
  "text" : "RT @JCVD: Me and my old friend Chuck Norris \uD83D\uDC4A\uD83C\uDFFB\uD83D\uDCAA\uD83C\uDFFB\uD83D\uDC4A\uD83C\uDFFB\n\n#TeamJCVD #ChuckNorris #martialarts #karate #tbt #ThrowbackThursday https:\/\/t.co\/8nQ6aO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JCVD\/status\/733348514802106368\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/8nQ6aOtaEm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1glgWWEAAK3kw.jpg",
        "id_str" : "733348511786340352",
        "id" : 733348511786340352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1glgWWEAAK3kw.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/8nQ6aOtaEm"
      } ],
      "hashtags" : [ {
        "text" : "TeamJCVD",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "ChuckNorris",
        "indices" : [ 52, 64 ]
      }, {
        "text" : "martialarts",
        "indices" : [ 65, 77 ]
      }, {
        "text" : "karate",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "tbt",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 91, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733348514802106368",
    "text" : "Me and my old friend Chuck Norris \uD83D\uDC4A\uD83C\uDFFB\uD83D\uDCAA\uD83C\uDFFB\uD83D\uDC4A\uD83C\uDFFB\n\n#TeamJCVD #ChuckNorris #martialarts #karate #tbt #ThrowbackThursday https:\/\/t.co\/8nQ6aOtaEm",
    "id" : 733348514802106368,
    "created_at" : "2016-05-19 17:28:05 +0000",
    "user" : {
      "name" : "JCVD Official",
      "screen_name" : "JCVD",
      "protected" : false,
      "id_str" : "390216128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893785752420716546\/tUsJd_GI_normal.jpg",
      "id" : 390216128,
      "verified" : true
    }
  },
  "id" : 733360910216073216,
  "created_at" : "2016-05-19 18:17:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OnePlus",
      "screen_name" : "oneplus",
      "indices" : [ 3, 11 ],
      "id_str" : "2196922086",
      "id" : 2196922086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733360762702417921",
  "text" : "RT @oneplus: In November of 2014, Una turned one. And we enjoyed the best dog birthday, pretty much ever. #ThrowbackThursday https:\/\/t.co\/p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oneplus\/status\/733356811043151872\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/p514U6av5B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1oIiRWYAEy1Sn.jpg",
        "id_str" : "733356810179076097",
        "id" : 733356810179076097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1oIiRWYAEy1Sn.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/p514U6av5B"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 93, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733356811043151872",
    "text" : "In November of 2014, Una turned one. And we enjoyed the best dog birthday, pretty much ever. #ThrowbackThursday https:\/\/t.co\/p514U6av5B",
    "id" : 733356811043151872,
    "created_at" : "2016-05-19 18:01:03 +0000",
    "user" : {
      "name" : "OnePlus",
      "screen_name" : "oneplus",
      "protected" : false,
      "id_str" : "2196922086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/968377614531547136\/j2tUYHq__normal.jpg",
      "id" : 2196922086,
      "verified" : true
    }
  },
  "id" : 733360762702417921,
  "created_at" : "2016-05-19 18:16:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MotoGP\u2122\uD83C\uDDEA\uD83C\uDDF8\uD83C\uDFC1",
      "screen_name" : "MotoGP",
      "indices" : [ 3, 10 ],
      "id_str" : "14082692",
      "id" : 14082692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 12, 30 ]
    }, {
      "text" : "MotoGP",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/AH7p6BIy4I",
      "expanded_url" : "http:\/\/www.motogp.com\/en\/videos\/2016\/05\/17\/flashback-capirossi-on-ducati-s-first-motogp-victory\/201029",
      "display_url" : "motogp.com\/en\/videos\/2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733360678073958400",
  "text" : "RT @MotoGP: #ThrowbackThursday with Capirossi to when Ducati took their first #MotoGP victory!\n\nFull \uD83C\uDFA5\u25B6\uFE0F https:\/\/t.co\/AH7p6BIy4I https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 0, 18 ]
      }, {
        "text" : "MotoGP",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/AH7p6BIy4I",
        "expanded_url" : "http:\/\/www.motogp.com\/en\/videos\/2016\/05\/17\/flashback-capirossi-on-ducati-s-first-motogp-victory\/201029",
        "display_url" : "motogp.com\/en\/videos\/2016\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/vFGz7M8AzF",
        "expanded_url" : "http:\/\/snpy.tv\/1XBPQ77",
        "display_url" : "snpy.tv\/1XBPQ77"
      } ]
    },
    "geo" : { },
    "id_str" : "733296162204045312",
    "text" : "#ThrowbackThursday with Capirossi to when Ducati took their first #MotoGP victory!\n\nFull \uD83C\uDFA5\u25B6\uFE0F https:\/\/t.co\/AH7p6BIy4I https:\/\/t.co\/vFGz7M8AzF",
    "id" : 733296162204045312,
    "created_at" : "2016-05-19 14:00:03 +0000",
    "user" : {
      "name" : "MotoGP\u2122\uD83C\uDDEA\uD83C\uDDF8\uD83C\uDFC1",
      "screen_name" : "MotoGP",
      "protected" : false,
      "id_str" : "14082692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466637052885217280\/sVktQhxZ_normal.png",
      "id" : 14082692,
      "verified" : true
    }
  },
  "id" : 733360678073958400,
  "created_at" : "2016-05-19 18:16:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/x5XFujtPXz",
      "expanded_url" : "http:\/\/bit.ly\/22hgwdY",
      "display_url" : "bit.ly\/22hgwdY"
    } ]
  },
  "geo" : { },
  "id_str" : "733360200137211904",
  "text" : "The all-in-one social network, I will be marketing soon: https:\/\/t.co\/x5XFujtPXz",
  "id" : 733360200137211904,
  "created_at" : "2016-05-19 18:14:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Rogers",
      "screen_name" : "TheRealSJR",
      "indices" : [ 3, 14 ],
      "id_str" : "101524268",
      "id" : 101524268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733359608820072448",
  "text" : "RT @TheRealSJR: (Analysis) Web personalization: How big (and small) companies are increasing conversions and boosting retention https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/BBmt0w3nJW",
        "expanded_url" : "http:\/\/insight.venturebeat.com\/report\/website-personalization-increasing-conversions-and-retention-right-technology-partner",
        "display_url" : "insight.venturebeat.com\/report\/website\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733356698488950785",
    "text" : "(Analysis) Web personalization: How big (and small) companies are increasing conversions and boosting retention https:\/\/t.co\/BBmt0w3nJW",
    "id" : 733356698488950785,
    "created_at" : "2016-05-19 18:00:36 +0000",
    "user" : {
      "name" : "Stewart Rogers",
      "screen_name" : "TheRealSJR",
      "protected" : false,
      "id_str" : "101524268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910785483961184256\/DpQudOyF_normal.jpg",
      "id" : 101524268,
      "verified" : true
    }
  },
  "id" : 733359608820072448,
  "created_at" : "2016-05-19 18:12:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/1ACsF8Vqpf",
      "expanded_url" : "http:\/\/www.engadget.com\/2016\/05\/19\/android-apps-google-play-on-chromeOS\/",
      "display_url" : "engadget.com\/2016\/05\/19\/and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733359507410198528",
  "text" : "RT @EmperorDarroux: Android Apps and the Play Store are coming to Chrome OS this year https:\/\/t.co\/1ACsF8Vqpf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/1ACsF8Vqpf",
        "expanded_url" : "http:\/\/www.engadget.com\/2016\/05\/19\/android-apps-google-play-on-chromeOS\/",
        "display_url" : "engadget.com\/2016\/05\/19\/and\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733357270466101248",
    "text" : "Android Apps and the Play Store are coming to Chrome OS this year https:\/\/t.co\/1ACsF8Vqpf",
    "id" : 733357270466101248,
    "created_at" : "2016-05-19 18:02:53 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 733359507410198528,
  "created_at" : "2016-05-19 18:11:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "CloudKiddo",
      "indices" : [ 3, 14 ],
      "id_str" : "463629152",
      "id" : 463629152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733359307991973889",
  "text" : "RT @CloudKiddo: Take a moment out of your day and just relax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733359153415098369",
    "text" : "Take a moment out of your day and just relax",
    "id" : 733359153415098369,
    "created_at" : "2016-05-19 18:10:21 +0000",
    "user" : {
      "name" : "Daniel",
      "screen_name" : "CloudKiddo",
      "protected" : false,
      "id_str" : "463629152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/993249983863447552\/lmJT6Mya_normal.jpg",
      "id" : 463629152,
      "verified" : false
    }
  },
  "id" : 733359307991973889,
  "created_at" : "2016-05-19 18:10:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny",
      "screen_name" : "awkwardposts",
      "indices" : [ 3, 16 ],
      "id_str" : "390860562",
      "id" : 390860562
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/awkwardposts\/status\/733320885684346884\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/ryUuqzdCjJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1HdcPXEAEa6qw.jpg",
      "id_str" : "733320885453656065",
      "id" : 733320885453656065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1HdcPXEAEa6qw.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 583
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ryUuqzdCjJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733359177284890624",
  "text" : "RT @awkwardposts: Me: lol I don't care \n\nMe: 3 seconds later https:\/\/t.co\/ryUuqzdCjJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/awkwardposts\/status\/733320885684346884\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/ryUuqzdCjJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1HdcPXEAEa6qw.jpg",
        "id_str" : "733320885453656065",
        "id" : 733320885453656065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1HdcPXEAEa6qw.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 583
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 583
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ryUuqzdCjJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733320885684346884",
    "text" : "Me: lol I don't care \n\nMe: 3 seconds later https:\/\/t.co\/ryUuqzdCjJ",
    "id" : 733320885684346884,
    "created_at" : "2016-05-19 15:38:18 +0000",
    "user" : {
      "name" : "Funny",
      "screen_name" : "awkwardposts",
      "protected" : false,
      "id_str" : "390860562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765228804604358661\/SxBOdQEd_normal.jpg",
      "id" : 390860562,
      "verified" : false
    }
  },
  "id" : 733359177284890624,
  "created_at" : "2016-05-19 18:10:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Rushen",
      "screen_name" : "PamRushen",
      "indices" : [ 3, 13 ],
      "id_str" : "898167727",
      "id" : 898167727
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Pam Rushen",
      "screen_name" : "PamRushen",
      "indices" : [ 28, 38 ],
      "id_str" : "898167727",
      "id" : 898167727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733359018517925888",
  "text" : "RT @PamRushen: @gamer456148 @PamRushen Done!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Pam Rushen",
        "screen_name" : "PamRushen",
        "indices" : [ 13, 23 ],
        "id_str" : "898167727",
        "id" : 898167727
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "732198259817627648",
    "geo" : { },
    "id_str" : "732412233821474817",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @PamRushen Done!",
    "id" : 732412233821474817,
    "in_reply_to_status_id" : 732198259817627648,
    "created_at" : "2016-05-17 03:27:38 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Pam Rushen",
      "screen_name" : "PamRushen",
      "protected" : false,
      "id_str" : "898167727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2820106100\/21bf60c0c228300b8c4e521b79bd3568_normal.jpeg",
      "id" : 898167727,
      "verified" : false
    }
  },
  "id" : 733359018517925888,
  "created_at" : "2016-05-19 18:09:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Erpen",
      "screen_name" : "wes_fixers",
      "indices" : [ 0, 11 ],
      "id_str" : "134145748",
      "id" : 134145748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731928968304164864",
  "geo" : { },
  "id_str" : "733358769514643457",
  "in_reply_to_user_id" : 134145748,
  "text" : "@wes_fixers Please support my HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 733358769514643457,
  "in_reply_to_status_id" : 731928968304164864,
  "created_at" : "2016-05-19 18:08:50 +0000",
  "in_reply_to_screen_name" : "wes_fixers",
  "in_reply_to_user_id_str" : "134145748",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "trabian shorters",
      "screen_name" : "JoinBMe",
      "indices" : [ 0, 8 ],
      "id_str" : "120493123",
      "id" : 120493123
    }, {
      "name" : "BMe Community",
      "screen_name" : "BMeCommunity",
      "indices" : [ 9, 22 ],
      "id_str" : "318073630",
      "id" : 318073630
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 23, 34 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "733247465521090560",
  "geo" : { },
  "id_str" : "733358720240001025",
  "in_reply_to_user_id" : 120493123,
  "text" : "@JoinBMe @BMeCommunity @headtalker Please support my HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 733358720240001025,
  "in_reply_to_status_id" : 733247465521090560,
  "created_at" : "2016-05-19 18:08:38 +0000",
  "in_reply_to_screen_name" : "JoinBMe",
  "in_reply_to_user_id_str" : "120493123",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Burgin Logan",
      "screen_name" : "AngelaBLogan",
      "indices" : [ 3, 16 ],
      "id_str" : "25508986",
      "id" : 25508986
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TuesdayMotivation",
      "indices" : [ 75, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732604195799437312",
  "text" : "RT @AngelaBLogan: Hang in there, even Moses was a basket case at one time! #TuesdayMotivation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TuesdayMotivation",
        "indices" : [ 57, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732596129385353217",
    "text" : "Hang in there, even Moses was a basket case at one time! #TuesdayMotivation",
    "id" : 732596129385353217,
    "created_at" : "2016-05-17 15:38:22 +0000",
    "user" : {
      "name" : "Angela Burgin Logan",
      "screen_name" : "AngelaBLogan",
      "protected" : false,
      "id_str" : "25508986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/409105989\/Angela_normal.JPG",
      "id" : 25508986,
      "verified" : false
    }
  },
  "id" : 732604195799437312,
  "created_at" : "2016-05-17 16:10:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "indices" : [ 0, 16 ],
      "id_str" : "34221288",
      "id" : 34221288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732603924323110912",
  "in_reply_to_user_id" : 34221288,
  "text" : "@brianchandotcom I am impressed by your GitHub portfolio, you are perhaps one of the best and most active coders I ever seen.",
  "id" : 732603924323110912,
  "created_at" : "2016-05-17 16:09:21 +0000",
  "in_reply_to_screen_name" : "brianchandotcom",
  "in_reply_to_user_id_str" : "34221288",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "indices" : [ 3, 19 ],
      "id_str" : "34221288",
      "id" : 34221288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732603715740389376",
  "text" : "RT @brianchandotcom: I worship a loving, and vengeful God. Joel 2:13, 3:21.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727357350135242752",
    "text" : "I worship a loving, and vengeful God. Joel 2:13, 3:21.",
    "id" : 727357350135242752,
    "created_at" : "2016-05-03 04:41:20 +0000",
    "user" : {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "protected" : false,
      "id_str" : "34221288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995340295\/7a129dd7ff5048c5b52e0e33083af993_normal.jpeg",
      "id" : 34221288,
      "verified" : false
    }
  },
  "id" : 732603715740389376,
  "created_at" : "2016-05-17 16:08:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "indices" : [ 3, 19 ],
      "id_str" : "34221288",
      "id" : 34221288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732603680290177024",
  "text" : "RT @brianchandotcom: Some deals are always bad. 2 Kings 5:15-27, Mark 8:36.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727884719921078272",
    "text" : "Some deals are always bad. 2 Kings 5:15-27, Mark 8:36.",
    "id" : 727884719921078272,
    "created_at" : "2016-05-04 15:36:55 +0000",
    "user" : {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "protected" : false,
      "id_str" : "34221288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995340295\/7a129dd7ff5048c5b52e0e33083af993_normal.jpeg",
      "id" : 34221288,
      "verified" : false
    }
  },
  "id" : 732603680290177024,
  "created_at" : "2016-05-17 16:08:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "indices" : [ 3, 19 ],
      "id_str" : "34221288",
      "id" : 34221288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732603650590310401",
  "text" : "RT @brianchandotcom: Crying is expected, grumbling is forbidden. Crying is from faith, grumbling is from sin. One gives life, the other kil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728582145090813952",
    "text" : "Crying is expected, grumbling is forbidden. Crying is from faith, grumbling is from sin. One gives life, the other kills. Hebrews 5:7, 4:15.",
    "id" : 728582145090813952,
    "created_at" : "2016-05-06 13:48:14 +0000",
    "user" : {
      "name" : "Brian Chan",
      "screen_name" : "brianchandotcom",
      "protected" : false,
      "id_str" : "34221288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2995340295\/7a129dd7ff5048c5b52e0e33083af993_normal.jpeg",
      "id" : 34221288,
      "verified" : false
    }
  },
  "id" : 732603650590310401,
  "created_at" : "2016-05-17 16:08:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/xBHzfGgsL7",
      "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/boomstick-review\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/05\/16\/boo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732267995465170945",
  "text" : "RT @EmperorDarroux: BoomStick creates room-filling audio in your head https:\/\/t.co\/xBHzfGgsL7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/xBHzfGgsL7",
        "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/boomstick-review\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/05\/16\/boo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732267526936100865",
    "text" : "BoomStick creates room-filling audio in your head https:\/\/t.co\/xBHzfGgsL7",
    "id" : 732267526936100865,
    "created_at" : "2016-05-16 17:52:37 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 732267995465170945,
  "created_at" : "2016-05-16 17:54:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "indices" : [ 3, 16 ],
      "id_str" : "43532936",
      "id" : 43532936
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/eiKSuWQC4R",
      "expanded_url" : "http:\/\/www.feynmanlectures.caltech.edu\/",
      "display_url" : "feynmanlectures.caltech.edu"
    } ]
  },
  "geo" : { },
  "id_str" : "732264254884220929",
  "text" : "RT @cohasset_kid: @gamer456148 The Feynman Lectures on Physics #free online \u2192 http:\/\/t.co\/eiKSuWQC4R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.yoono.com\" rel=\"nofollow\"\u003Eyoono\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/eiKSuWQC4R",
        "expanded_url" : "http:\/\/www.feynmanlectures.caltech.edu\/",
        "display_url" : "feynmanlectures.caltech.edu"
      } ]
    },
    "geo" : { },
    "id_str" : "502442708963565571",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 The Feynman Lectures on Physics #free online \u2192 http:\/\/t.co\/eiKSuWQC4R",
    "id" : 502442708963565571,
    "created_at" : "2014-08-21 13:10:51 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "protected" : false,
      "id_str" : "43532936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592433281850716160\/JPeYcsA7_normal.jpg",
      "id" : 43532936,
      "verified" : false
    }
  },
  "id" : 732264254884220929,
  "created_at" : "2016-05-16 17:39:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "indices" : [ 3, 16 ],
      "id_str" : "43532936",
      "id" : 43532936
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263839698460672",
  "text" : "RT @cohasset_kid: @gamer456148 iPhone or Android? \u2190 not that it matters. I'm just curious",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "643910483720863744",
    "geo" : { },
    "id_str" : "643913491242446848",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 iPhone or Android? \u2190 not that it matters. I'm just curious",
    "id" : 643913491242446848,
    "in_reply_to_status_id" : 643910483720863744,
    "created_at" : "2015-09-15 22:25:14 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Jonster",
      "screen_name" : "cohasset_kid",
      "protected" : false,
      "id_str" : "43532936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592433281850716160\/JPeYcsA7_normal.jpg",
      "id" : 43532936,
      "verified" : false
    }
  },
  "id" : 732263839698460672,
  "created_at" : "2016-05-16 17:37:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "indices" : [ 3, 14 ],
      "id_str" : "1685698238",
      "id" : 1685698238
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/5x9SmgAGwy",
      "expanded_url" : "http:\/\/www.phpsimplex.com\/en\/",
      "display_url" : "phpsimplex.com\/en\/"
    } ]
  },
  "geo" : { },
  "id_str" : "732263647838412800",
  "text" : "RT @PHPSimplex: @gamer456148 check it: https:\/\/t.co\/5x9SmgAGwy  (theory, solved examples, tool to solve problems step-by-step,...). If in d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/5x9SmgAGwy",
        "expanded_url" : "http:\/\/www.phpsimplex.com\/en\/",
        "display_url" : "phpsimplex.com\/en\/"
      } ]
    },
    "in_reply_to_status_id_str" : "672792515981025281",
    "geo" : { },
    "id_str" : "672905721768517632",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 check it: https:\/\/t.co\/5x9SmgAGwy  (theory, solved examples, tool to solve problems step-by-step,...). If in doubt, ask us!",
    "id" : 672905721768517632,
    "in_reply_to_status_id" : 672792515981025281,
    "created_at" : "2015-12-04 22:30:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "PHPSimplex",
      "screen_name" : "PHPSimplex",
      "protected" : false,
      "id_str" : "1685698238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000328895370\/ac13e7a886c26f645af34c01324f00ab_normal.png",
      "id" : 1685698238,
      "verified" : false
    }
  },
  "id" : 732263647838412800,
  "created_at" : "2016-05-16 17:37:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RE2PECT 2 JETER",
      "screen_name" : "RE2PECT2JETER",
      "indices" : [ 3, 17 ],
      "id_str" : "2340141478",
      "id" : 2340141478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263358842408961",
  "text" : "RT @RE2PECT2JETER: Your time to succeed is approaching, always stay prepared!! Success happens when luck collides with preparation! #Monday\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 113, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732252620937629696",
    "text" : "Your time to succeed is approaching, always stay prepared!! Success happens when luck collides with preparation! #MondayMotivation",
    "id" : 732252620937629696,
    "created_at" : "2016-05-16 16:53:24 +0000",
    "user" : {
      "name" : "RE2PECT 2 JETER",
      "screen_name" : "RE2PECT2JETER",
      "protected" : false,
      "id_str" : "2340141478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/976814294011666432\/4QsyiLPt_normal.jpg",
      "id" : 2340141478,
      "verified" : false
    }
  },
  "id" : 732263358842408961,
  "created_at" : "2016-05-16 17:36:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nasdaq",
      "screen_name" : "Nasdaq",
      "indices" : [ 3, 10 ],
      "id_str" : "18639734",
      "id" : 18639734
    }, {
      "name" : "Pierre Omidyar",
      "screen_name" : "pierre",
      "indices" : [ 74, 81 ],
      "id_str" : "749963",
      "id" : 749963
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASDAQ\/status\/732253030465347584\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/qZzvBVonGS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil8QDqWsAAYWQU.jpg",
      "id_str" : "732253029727121408",
      "id" : 732253029727121408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil8QDqWsAAYWQU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qZzvBVonGS"
    } ],
    "hashtags" : [ {
      "text" : "MondayMotivation",
      "indices" : [ 90, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263321055973376",
  "text" : "RT @NASDAQ: \"If you're passionate about something and you work hard...\" - @Pierre Omidyar #MondayMotivation https:\/\/t.co\/qZzvBVonGS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pierre Omidyar",
        "screen_name" : "pierre",
        "indices" : [ 62, 69 ],
        "id_str" : "749963",
        "id" : 749963
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASDAQ\/status\/732253030465347584\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/qZzvBVonGS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil8QDqWsAAYWQU.jpg",
        "id_str" : "732253029727121408",
        "id" : 732253029727121408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil8QDqWsAAYWQU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/qZzvBVonGS"
      } ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 78, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732253030465347584",
    "text" : "\"If you're passionate about something and you work hard...\" - @Pierre Omidyar #MondayMotivation https:\/\/t.co\/qZzvBVonGS",
    "id" : 732253030465347584,
    "created_at" : "2016-05-16 16:55:01 +0000",
    "user" : {
      "name" : "Nasdaq",
      "screen_name" : "Nasdaq",
      "protected" : false,
      "id_str" : "18639734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914839219171987457\/l2DcYcQ9_normal.jpg",
      "id" : 18639734,
      "verified" : true
    }
  },
  "id" : 732263321055973376,
  "created_at" : "2016-05-16 17:35:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammarly",
      "screen_name" : "Grammarly",
      "indices" : [ 3, 13 ],
      "id_str" : "47191725",
      "id" : 47191725
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Grammarly\/status\/732254339012673536\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/iQoElnxFhX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil9cOZWwAAxegH.jpg",
      "id_str" : "732254338278670336",
      "id" : 732254338278670336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil9cOZWwAAxegH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1204
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1204
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/iQoElnxFhX"
    } ],
    "hashtags" : [ {
      "text" : "Mondaymotivation",
      "indices" : [ 42, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263270808190976",
  "text" : "RT @Grammarly: Never fear, you can do it. #Mondaymotivation https:\/\/t.co\/iQoElnxFhX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Grammarly\/status\/732254339012673536\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/iQoElnxFhX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil9cOZWwAAxegH.jpg",
        "id_str" : "732254338278670336",
        "id" : 732254338278670336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil9cOZWwAAxegH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1204
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1204
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/iQoElnxFhX"
      } ],
      "hashtags" : [ {
        "text" : "Mondaymotivation",
        "indices" : [ 27, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732254339012673536",
    "text" : "Never fear, you can do it. #Mondaymotivation https:\/\/t.co\/iQoElnxFhX",
    "id" : 732254339012673536,
    "created_at" : "2016-05-16 17:00:13 +0000",
    "user" : {
      "name" : "Grammarly",
      "screen_name" : "Grammarly",
      "protected" : false,
      "id_str" : "47191725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925943303316500480\/ON5SfAeV_normal.jpg",
      "id" : 47191725,
      "verified" : true
    }
  },
  "id" : 732263270808190976,
  "created_at" : "2016-05-16 17:35:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Hensel",
      "screen_name" : "gary_hensel",
      "indices" : [ 3, 15 ],
      "id_str" : "2215842624",
      "id" : 2215842624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "mondaymotivation",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263149106237440",
  "text" : "RT @gary_hensel: Mistakes should be examined, learned from, and discarded; not dwelled upon and stored.\u2015 Tim Fargo #quote #mondaymotivation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "mondaymotivation",
        "indices" : [ 105, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732261904865996800",
    "text" : "Mistakes should be examined, learned from, and discarded; not dwelled upon and stored.\u2015 Tim Fargo #quote #mondaymotivation",
    "id" : 732261904865996800,
    "created_at" : "2016-05-16 17:30:17 +0000",
    "user" : {
      "name" : "Gary Hensel",
      "screen_name" : "gary_hensel",
      "protected" : false,
      "id_str" : "2215842624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/820479007229517826\/C9r1NcpX_normal.jpg",
      "id" : 2215842624,
      "verified" : false
    }
  },
  "id" : 732263149106237440,
  "created_at" : "2016-05-16 17:35:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paws in the City",
      "screen_name" : "PawsintheCity",
      "indices" : [ 3, 17 ],
      "id_str" : "29600662",
      "id" : 29600662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MondayMotivation",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732263101685497856",
  "text" : "RT @PawsintheCity: FOZZIE wozzie is no bear, he's a dog! And a small one at that!\nConsider changing a life-YOURS.\n#MondayMotivation https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PawsintheCity\/status\/732262019269836800\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hM2csIS8ll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimEbPQWUAAATCb.jpg",
        "id_str" : "732262017910853632",
        "id" : 732262017910853632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimEbPQWUAAATCb.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hM2csIS8ll"
      } ],
      "hashtags" : [ {
        "text" : "MondayMotivation",
        "indices" : [ 95, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732262019269836800",
    "text" : "FOZZIE wozzie is no bear, he's a dog! And a small one at that!\nConsider changing a life-YOURS.\n#MondayMotivation https:\/\/t.co\/hM2csIS8ll",
    "id" : 732262019269836800,
    "created_at" : "2016-05-16 17:30:44 +0000",
    "user" : {
      "name" : "Paws in the City",
      "screen_name" : "PawsintheCity",
      "protected" : false,
      "id_str" : "29600662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895648922068299776\/LZgAmLZC_normal.jpg",
      "id" : 29600662,
      "verified" : false
    }
  },
  "id" : 732263101685497856,
  "created_at" : "2016-05-16 17:35:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732179634322845696",
  "geo" : { },
  "id_str" : "732262803898302465",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget A $5 price, the Raspberry Pi foundation never seems to disappoint me",
  "id" : 732262803898302465,
  "in_reply_to_status_id" : 732179634322845696,
  "created_at" : "2016-05-16 17:33:51 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 0, 9 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732240268389429248",
  "geo" : { },
  "id_str" : "732262581491077121",
  "in_reply_to_user_id" : 14372486,
  "text" : "@engadget Wait now the jocks become the gamers!!!",
  "id" : 732262581491077121,
  "in_reply_to_status_id" : 732240268389429248,
  "created_at" : "2016-05-16 17:32:58 +0000",
  "in_reply_to_screen_name" : "engadget",
  "in_reply_to_user_id_str" : "14372486",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartHub",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732262249788739584",
  "text" : "Releasing a new social media app soon hopefully, but until then happy coding #StartHub",
  "id" : 732262249788739584,
  "created_at" : "2016-05-16 17:31:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/sMRchkZWgf",
      "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/spinning-bus-london\/",
      "display_url" : "mashable.com\/2016\/05\/16\/spi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732262043814907904",
  "text" : "RT @EmperorDarroux: This bus will turn your commute into a hellish spinning studio class https:\/\/t.co\/sMRchkZWgf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/sMRchkZWgf",
        "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/spinning-bus-london\/",
        "display_url" : "mashable.com\/2016\/05\/16\/spi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732255942851485696",
    "text" : "This bus will turn your commute into a hellish spinning studio class https:\/\/t.co\/sMRchkZWgf",
    "id" : 732255942851485696,
    "created_at" : "2016-05-16 17:06:36 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 732262043814907904,
  "created_at" : "2016-05-16 17:30:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "San Francisco Giants",
      "screen_name" : "SFGiants",
      "indices" : [ 3, 12 ],
      "id_str" : "43024351",
      "id" : 43024351
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SFGiants\/status\/732254423791980544\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/PYqGVmLA6p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil9hEnVAAAlUQL.jpg",
      "id_str" : "732254421552267264",
      "id" : 732254421552267264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil9hEnVAAAlUQL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PYqGVmLA6p"
    } ],
    "hashtags" : [ {
      "text" : "WeAreSF",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/hNfgAc0so5",
      "expanded_url" : "http:\/\/atmlb.com\/1TgPRrO",
      "display_url" : "atmlb.com\/1TgPRrO"
    } ]
  },
  "geo" : { },
  "id_str" : "732261906476609536",
  "text" : "RT @SFGiants: 1 run over 7 frames, vintage Cain was a sight to see.\n\nhttps:\/\/t.co\/hNfgAc0so5 #WeAreSF https:\/\/t.co\/PYqGVmLA6p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SFGiants\/status\/732254423791980544\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/PYqGVmLA6p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil9hEnVAAAlUQL.jpg",
        "id_str" : "732254421552267264",
        "id" : 732254421552267264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil9hEnVAAAlUQL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/PYqGVmLA6p"
      } ],
      "hashtags" : [ {
        "text" : "WeAreSF",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/hNfgAc0so5",
        "expanded_url" : "http:\/\/atmlb.com\/1TgPRrO",
        "display_url" : "atmlb.com\/1TgPRrO"
      } ]
    },
    "geo" : { },
    "id_str" : "732254423791980544",
    "text" : "1 run over 7 frames, vintage Cain was a sight to see.\n\nhttps:\/\/t.co\/hNfgAc0so5 #WeAreSF https:\/\/t.co\/PYqGVmLA6p",
    "id" : 732254423791980544,
    "created_at" : "2016-05-16 17:00:33 +0000",
    "user" : {
      "name" : "San Francisco Giants",
      "screen_name" : "SFGiants",
      "protected" : false,
      "id_str" : "43024351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948256934091677696\/ZIUse-R2_normal.jpg",
      "id" : 43024351,
      "verified" : true
    }
  },
  "id" : 732261906476609536,
  "created_at" : "2016-05-16 17:30:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732261433103224833",
  "text" : "RT @BarbaraCorcoran: Indecision is poison. Even when you make the wrong decision, at least you're moving and have the chance of stumbling i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732260669228240896",
    "text" : "Indecision is poison. Even when you make the wrong decision, at least you're moving and have the chance of stumbling into something great.",
    "id" : 732260669228240896,
    "created_at" : "2016-05-16 17:25:22 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 732261433103224833,
  "created_at" : "2016-05-16 17:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POV on PBS",
      "screen_name" : "POVdocs",
      "indices" : [ 3, 11 ],
      "id_str" : "17965843",
      "id" : 17965843
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 123, 127 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "OfMenandWar",
      "indices" : [ 93, 105 ]
    }, {
      "text" : "MemorialDay",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732261285639913473",
  "text" : "RT @povdocs: #Veterans tell their stories for themselves, for each other, and also for us in #OfMenandWar. #MemorialDay on @PBS https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PBS",
        "screen_name" : "PBS",
        "indices" : [ 110, 114 ],
        "id_str" : "12133382",
        "id" : 12133382
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/povdocs\/status\/732259094380216320\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ybeDrHgHZT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil0qyVVEAAqz_J.jpg",
        "id_str" : "732244692838977536",
        "id" : 732244692838977536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil0qyVVEAAqz_J.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/ybeDrHgHZT"
      } ],
      "hashtags" : [ {
        "text" : "Veterans",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "OfMenandWar",
        "indices" : [ 80, 92 ]
      }, {
        "text" : "MemorialDay",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732259094380216320",
    "text" : "#Veterans tell their stories for themselves, for each other, and also for us in #OfMenandWar. #MemorialDay on @PBS https:\/\/t.co\/ybeDrHgHZT",
    "id" : 732259094380216320,
    "created_at" : "2016-05-16 17:19:07 +0000",
    "user" : {
      "name" : "POV on PBS",
      "screen_name" : "POVdocs",
      "protected" : false,
      "id_str" : "17965843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/965998540831973377\/XMw9uk9B_normal.jpg",
      "id" : 17965843,
      "verified" : true
    }
  },
  "id" : 732261285639913473,
  "created_at" : "2016-05-16 17:27:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0CeHXIWEaH",
      "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/old-comics-current-value\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/05\/16\/old\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732261220791791624",
  "text" : "RT @EmperorDarroux: Here's how much your vintage comics are now worth https:\/\/t.co\/0CeHXIWEaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/0CeHXIWEaH",
        "expanded_url" : "http:\/\/mashable.com\/2016\/05\/16\/old-comics-current-value\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/05\/16\/old\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732260927005843458",
    "text" : "Here's how much your vintage comics are now worth https:\/\/t.co\/0CeHXIWEaH",
    "id" : 732260927005843458,
    "created_at" : "2016-05-16 17:26:24 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 732261220791791624,
  "created_at" : "2016-05-16 17:27:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jericho Cosmetics",
      "screen_name" : "deadseajericho",
      "indices" : [ 0, 15 ],
      "id_str" : "4449846736",
      "id" : 4449846736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "geo" : { },
  "id_str" : "732261059277492225",
  "in_reply_to_user_id" : 4449846736,
  "text" : "@deadseajericho Would you mind supporting our campaign? https:\/\/t.co\/yBeZdEQUXN",
  "id" : 732261059277492225,
  "created_at" : "2016-05-16 17:26:55 +0000",
  "in_reply_to_screen_name" : "deadseajericho",
  "in_reply_to_user_id_str" : "4449846736",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "indices" : [ 3, 19 ],
      "id_str" : "31001654",
      "id" : 31001654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SPY",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732218786628128768",
  "text" : "RT @HamzeiAnalytics: BLOCK TRADE detected in #SPY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hamzeianalytics.com\/Products.asp\" rel=\"nofollow\"\u003EHFT DeskTop v2.x\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SPY",
        "indices" : [ 24, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732199794584653825",
    "text" : "BLOCK TRADE detected in #SPY",
    "id" : 732199794584653825,
    "created_at" : "2016-05-16 13:23:29 +0000",
    "user" : {
      "name" : "Fari Hamzei",
      "screen_name" : "HamzeiAnalytics",
      "protected" : false,
      "id_str" : "31001654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555830015\/farihamzei_normal.jpg",
      "id" : 31001654,
      "verified" : false
    }
  },
  "id" : 732218786628128768,
  "created_at" : "2016-05-16 14:38:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/732218768051441666\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ztikEB4R6X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CildE55UYAABXgl.jpg",
      "id_str" : "732218753266507776",
      "id" : 732218753266507776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CildE55UYAABXgl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ztikEB4R6X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732218768051441666",
  "text" : "Having a Roast Beef and Mozzarella sandwich \uD83D\uDE0B https:\/\/t.co\/ztikEB4R6X",
  "id" : 732218768051441666,
  "created_at" : "2016-05-16 14:38:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ARIF LUQMAN",
      "screen_name" : "arif_luqman",
      "indices" : [ 0, 12 ],
      "id_str" : "105018426",
      "id" : 105018426
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730535333910056960",
  "geo" : { },
  "id_str" : "732199347534827520",
  "in_reply_to_user_id" : 105018426,
  "text" : "@arif_luqman @YouTube Is it CG graphics, most likely???",
  "id" : 732199347534827520,
  "in_reply_to_status_id" : 730535333910056960,
  "created_at" : "2016-05-16 13:21:42 +0000",
  "in_reply_to_screen_name" : "arif_luqman",
  "in_reply_to_user_id_str" : "105018426",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mojomakerz",
      "screen_name" : "mojomakerz",
      "indices" : [ 3, 14 ],
      "id_str" : "1707369096",
      "id" : 1707369096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ColinFurze",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "Lincolnshire",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "UK",
      "indices" : [ 101, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/4zxnewxSFZ",
      "expanded_url" : "https:\/\/www.minds.com\/blog\/view\/574322502415687691",
      "display_url" : "minds.com\/blog\/view\/5743\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732198803026153472",
  "text" : "RT @mojomakerz: A British inventor built a working hoverbike in his garage #ColinFurze #Lincolnshire #UK\n https:\/\/t.co\/4zxnewxSFZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ColinFurze",
        "indices" : [ 59, 70 ]
      }, {
        "text" : "Lincolnshire",
        "indices" : [ 71, 84 ]
      }, {
        "text" : "UK",
        "indices" : [ 85, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/4zxnewxSFZ",
        "expanded_url" : "https:\/\/www.minds.com\/blog\/view\/574322502415687691",
        "display_url" : "minds.com\/blog\/view\/5743\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728716300143497216",
    "text" : "A British inventor built a working hoverbike in his garage #ColinFurze #Lincolnshire #UK\n https:\/\/t.co\/4zxnewxSFZ",
    "id" : 728716300143497216,
    "created_at" : "2016-05-06 22:41:19 +0000",
    "user" : {
      "name" : "mojomakerz",
      "screen_name" : "mojomakerz",
      "protected" : false,
      "id_str" : "1707369096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691164830611341313\/9HWoGtQF_normal.jpg",
      "id" : 1707369096,
      "verified" : false
    }
  },
  "id" : 732198803026153472,
  "created_at" : "2016-05-16 13:19:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Dugan",
      "screen_name" : "JDSpiedie",
      "indices" : [ 3, 13 ],
      "id_str" : "276178310",
      "id" : 276178310
    }, {
      "name" : "#InnovationNation",
      "screen_name" : "CBSInnovationTV",
      "indices" : [ 15, 31 ],
      "id_str" : "2698300332",
      "id" : 2698300332
    }, {
      "name" : "Mo Rocca",
      "screen_name" : "MoRocca",
      "indices" : [ 32, 40 ],
      "id_str" : "54275319",
      "id" : 54275319
    }, {
      "name" : "The Henry Ford",
      "screen_name" : "thehenryford",
      "indices" : [ 41, 54 ],
      "id_str" : "19039467",
      "id" : 19039467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ColinFurze",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732198750567997441",
  "text" : "RT @JDSpiedie: @CBSInnovationTV @MoRocca @thehenryford  You need to interview #ColinFurze",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#InnovationNation",
        "screen_name" : "CBSInnovationTV",
        "indices" : [ 0, 16 ],
        "id_str" : "2698300332",
        "id" : 2698300332
      }, {
        "name" : "Mo Rocca",
        "screen_name" : "MoRocca",
        "indices" : [ 17, 25 ],
        "id_str" : "54275319",
        "id" : 54275319
      }, {
        "name" : "The Henry Ford",
        "screen_name" : "thehenryford",
        "indices" : [ 26, 39 ],
        "id_str" : "19039467",
        "id" : 19039467
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ColinFurze",
        "indices" : [ 63, 74 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "728676043280789504",
    "geo" : { },
    "id_str" : "728791700433448960",
    "in_reply_to_user_id" : 2698300332,
    "text" : "@CBSInnovationTV @MoRocca @thehenryford  You need to interview #ColinFurze",
    "id" : 728791700433448960,
    "in_reply_to_status_id" : 728676043280789504,
    "created_at" : "2016-05-07 03:40:56 +0000",
    "in_reply_to_screen_name" : "CBSInnovationTV",
    "in_reply_to_user_id_str" : "2698300332",
    "user" : {
      "name" : "Joseph Dugan",
      "screen_name" : "JDSpiedie",
      "protected" : false,
      "id_str" : "276178310",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_normal.png",
      "id" : 276178310,
      "verified" : false
    }
  },
  "id" : 732198750567997441,
  "created_at" : "2016-05-16 13:19:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jolq Benavides",
      "screen_name" : "JolqBenavides",
      "indices" : [ 3, 17 ],
      "id_str" : "2807384355",
      "id" : 2807384355
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JolqBenavides\/status\/730785885873131522\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/4E1fnmbZK3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiRF5AfXAAAoewH.jpg",
      "id_str" : "730785885227253760",
      "id" : 730785885227253760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiRF5AfXAAAoewH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4E1fnmbZK3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/RaoeHJtzD9",
      "expanded_url" : "http:\/\/ift.tt\/1T7SfV3",
      "display_url" : "ift.tt\/1T7SfV3"
    } ]
  },
  "geo" : { },
  "id_str" : "732198673950646272",
  "text" : "RT @JolqBenavides: ColinFurze Makes a Smoking\/Strobing Bass:https:\/\/t.co\/RaoeHJtzD9 https:\/\/t.co\/4E1fnmbZK3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JolqBenavides\/status\/730785885873131522\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/4E1fnmbZK3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiRF5AfXAAAoewH.jpg",
        "id_str" : "730785885227253760",
        "id" : 730785885227253760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiRF5AfXAAAoewH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/4E1fnmbZK3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/RaoeHJtzD9",
        "expanded_url" : "http:\/\/ift.tt\/1T7SfV3",
        "display_url" : "ift.tt\/1T7SfV3"
      } ]
    },
    "geo" : { },
    "id_str" : "730785885873131522",
    "text" : "ColinFurze Makes a Smoking\/Strobing Bass:https:\/\/t.co\/RaoeHJtzD9 https:\/\/t.co\/4E1fnmbZK3",
    "id" : 730785885873131522,
    "created_at" : "2016-05-12 15:45:07 +0000",
    "user" : {
      "name" : "Jolq Benavides",
      "screen_name" : "JolqBenavides",
      "protected" : false,
      "id_str" : "2807384355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518719553346347008\/LNv9hVMb_normal.jpeg",
      "id" : 2807384355,
      "verified" : false
    }
  },
  "id" : 732198673950646272,
  "created_at" : "2016-05-16 13:19:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autos - chminer",
      "screen_name" : "chwww2pi",
      "indices" : [ 3, 12 ],
      "id_str" : "705805956567805952",
      "id" : 705805956567805952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Q3xGRIrzvr",
      "expanded_url" : "http:\/\/chminer.net\/pick?pickid=1215941",
      "display_url" : "chminer.net\/pick?pickid=12\u2026"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Qzw6jFCRjl",
      "expanded_url" : "http:\/\/youtu.be\/pSbI5_75BlM",
      "display_url" : "youtu.be\/pSbI5_75BlM"
    } ]
  },
  "geo" : { },
  "id_str" : "732198632028569601",
  "text" : "RT @chwww2pi: Making a Smoking\/Strobing Bass | colinfurze https:\/\/t.co\/Q3xGRIrzvr - https:\/\/t.co\/Qzw6jFCRjl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/chminer.net\/\" rel=\"nofollow\"\u003Epick www 2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/Q3xGRIrzvr",
        "expanded_url" : "http:\/\/chminer.net\/pick?pickid=1215941",
        "display_url" : "chminer.net\/pick?pickid=12\u2026"
      }, {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Qzw6jFCRjl",
        "expanded_url" : "http:\/\/youtu.be\/pSbI5_75BlM",
        "display_url" : "youtu.be\/pSbI5_75BlM"
      } ]
    },
    "geo" : { },
    "id_str" : "730886862391246848",
    "text" : "Making a Smoking\/Strobing Bass | colinfurze https:\/\/t.co\/Q3xGRIrzvr - https:\/\/t.co\/Qzw6jFCRjl",
    "id" : 730886862391246848,
    "created_at" : "2016-05-12 22:26:21 +0000",
    "user" : {
      "name" : "Autos - chminer",
      "screen_name" : "chwww2pi",
      "protected" : false,
      "id_str" : "705805956567805952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705807904071266304\/jwoHRXKI_normal.jpg",
      "id" : 705805956567805952,
      "verified" : false
    }
  },
  "id" : 732198632028569601,
  "created_at" : "2016-05-16 13:18:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beNICEmedia",
      "screen_name" : "be_nicemedia",
      "indices" : [ 0, 13 ],
      "id_str" : "2574936827",
      "id" : 2574936827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "732005685626589184",
  "geo" : { },
  "id_str" : "732198521483481092",
  "in_reply_to_user_id" : 2574936827,
  "text" : "@be_nicemedia Checkout my HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 732198521483481092,
  "in_reply_to_status_id" : 732005685626589184,
  "created_at" : "2016-05-16 13:18:25 +0000",
  "in_reply_to_screen_name" : "be_nicemedia",
  "in_reply_to_user_id_str" : "2574936827",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Rushen",
      "screen_name" : "PamRushen",
      "indices" : [ 0, 10 ],
      "id_str" : "898167727",
      "id" : 898167727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "geo" : { },
  "id_str" : "732198259817627648",
  "in_reply_to_user_id" : 898167727,
  "text" : "@PamRushen Check my HeadTalker Pam https:\/\/t.co\/yBeZdEQUXN",
  "id" : 732198259817627648,
  "created_at" : "2016-05-16 13:17:23 +0000",
  "in_reply_to_screen_name" : "PamRushen",
  "in_reply_to_user_id_str" : "898167727",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "geo" : { },
  "id_str" : "732198106150916097",
  "text" : "@theromanticpen Hey check out my #Headtalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 732198106150916097,
  "created_at" : "2016-05-16 13:16:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Petco",
      "screen_name" : "Petco",
      "indices" : [ 3, 9 ],
      "id_str" : "17396566",
      "id" : 17396566
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Petco\/status\/731903385511714816\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/CadXhf6Zif",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cig-QD5UoAAKMRm.jpg",
      "id_str" : "731903385092268032",
      "id" : 731903385092268032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cig-QD5UoAAKMRm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/CadXhf6Zif"
    } ],
    "hashtags" : [ {
      "text" : "SundayFunday",
      "indices" : [ 18, 31 ]
    }, {
      "text" : "Husky",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731915492332584961",
  "text" : "RT @Petco: What's #SundayFunday without a Petco cart ride? (Pic: Rokee the #Husky) https:\/\/t.co\/CadXhf6Zif",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Petco\/status\/731903385511714816\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/CadXhf6Zif",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cig-QD5UoAAKMRm.jpg",
        "id_str" : "731903385092268032",
        "id" : 731903385092268032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cig-QD5UoAAKMRm.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/CadXhf6Zif"
      } ],
      "hashtags" : [ {
        "text" : "SundayFunday",
        "indices" : [ 7, 20 ]
      }, {
        "text" : "Husky",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731903385511714816",
    "text" : "What's #SundayFunday without a Petco cart ride? (Pic: Rokee the #Husky) https:\/\/t.co\/CadXhf6Zif",
    "id" : 731903385511714816,
    "created_at" : "2016-05-15 17:45:39 +0000",
    "user" : {
      "name" : "Petco",
      "screen_name" : "Petco",
      "protected" : false,
      "id_str" : "17396566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747096775249399808\/Ws0-bcrO_normal.jpg",
      "id" : 17396566,
      "verified" : true
    }
  },
  "id" : 731915492332584961,
  "created_at" : "2016-05-15 18:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shark Tank",
      "screen_name" : "ABCSharkTank",
      "indices" : [ 3, 16 ],
      "id_str" : "468583731",
      "id" : 468583731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SundayFunday",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/ecAsG1T2Le",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b42b3d3e-577b-4022-ace5-eb55d2811abe",
      "display_url" : "amp.twimg.com\/v\/b42b3d3e-577\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731915138811502597",
  "text" : "RT @ABCSharkTank: In honor of #SundayFunday... https:\/\/t.co\/ecAsG1T2Le",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SundayFunday",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/ecAsG1T2Le",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/b42b3d3e-577b-4022-ace5-eb55d2811abe",
        "display_url" : "amp.twimg.com\/v\/b42b3d3e-577\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731884357955297280",
    "text" : "In honor of #SundayFunday... https:\/\/t.co\/ecAsG1T2Le",
    "id" : 731884357955297280,
    "created_at" : "2016-05-15 16:30:03 +0000",
    "user" : {
      "name" : "Shark Tank",
      "screen_name" : "ABCSharkTank",
      "protected" : false,
      "id_str" : "468583731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801183221949943808\/tglqEN_Q_normal.jpg",
      "id" : 468583731,
      "verified" : true
    }
  },
  "id" : 731915138811502597,
  "created_at" : "2016-05-15 18:32:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simi Xiamara~DHO",
      "screen_name" : "SimiXiamara",
      "indices" : [ 0, 12 ],
      "id_str" : "732118394",
      "id" : 732118394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 26, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731896270923534336",
  "geo" : { },
  "id_str" : "731914946968162305",
  "in_reply_to_user_id" : 732118394,
  "text" : "@SimiXiamara Check out my #HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731914946968162305,
  "in_reply_to_status_id" : 731896270923534336,
  "created_at" : "2016-05-15 18:31:36 +0000",
  "in_reply_to_screen_name" : "SimiXiamara",
  "in_reply_to_user_id_str" : "732118394",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Palana",
      "screen_name" : "KristenPalana",
      "indices" : [ 0, 14 ],
      "id_str" : "1527260750",
      "id" : 1527260750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "730683615634395136",
  "geo" : { },
  "id_str" : "731914731603279873",
  "in_reply_to_user_id" : 1527260750,
  "text" : "@KristenPalana Kristen please check my #HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731914731603279873,
  "in_reply_to_status_id" : 730683615634395136,
  "created_at" : "2016-05-15 18:30:44 +0000",
  "in_reply_to_screen_name" : "KristenPalana",
  "in_reply_to_user_id_str" : "1527260750",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronda Caudill",
      "screen_name" : "RondaCaudill",
      "indices" : [ 0, 13 ],
      "id_str" : "461135167",
      "id" : 461135167
    }, {
      "name" : "Armand Rosamilia",
      "screen_name" : "ArmandAuthor",
      "indices" : [ 14, 27 ],
      "id_str" : "18565896",
      "id" : 18565896
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 28, 39 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731855580332208129",
  "geo" : { },
  "id_str" : "731914535825747970",
  "in_reply_to_user_id" : 461135167,
  "text" : "@RondaCaudill @ArmandAuthor @headtalker Checkout my #Headtalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731914535825747970,
  "in_reply_to_status_id" : 731855580332208129,
  "created_at" : "2016-05-15 18:29:58 +0000",
  "in_reply_to_screen_name" : "RondaCaudill",
  "in_reply_to_user_id_str" : "461135167",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262F\uFE0F LipPlush \u262F\uFE0F",
      "screen_name" : "LipLush1",
      "indices" : [ 0, 9 ],
      "id_str" : "1890940244",
      "id" : 1890940244
    }, {
      "name" : "Alan Felyk",
      "screen_name" : "AlanFelyk",
      "indices" : [ 10, 20 ],
      "id_str" : "255245279",
      "id" : 255245279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726431460270428160",
  "geo" : { },
  "id_str" : "731602685795942400",
  "in_reply_to_user_id" : 1890940244,
  "text" : "@LipLush1 @AlanFelyk Then you just have some problems.",
  "id" : 731602685795942400,
  "in_reply_to_status_id" : 726431460270428160,
  "created_at" : "2016-05-14 21:50:47 +0000",
  "in_reply_to_screen_name" : "LipLush1",
  "in_reply_to_user_id_str" : "1890940244",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/731602426017529856\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/3KweGprrxs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CicsVD2WkAE2dPN.jpg",
      "id_str" : "731602204793147393",
      "id" : 731602204793147393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CicsVD2WkAE2dPN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/3KweGprrxs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731602426017529856",
  "text" : "Had Brooklyn Pizza in Troy, was not a 5 star pizza but was still really good: 4.9\/5 stars https:\/\/t.co\/3KweGprrxs",
  "id" : 731602426017529856,
  "created_at" : "2016-05-14 21:49:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731550991477297157",
  "text" : "RT @RandiAthenas: Did you hear about the ATM that got addicted to money? It suffered from withdrawals.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731523856876212224",
    "text" : "Did you hear about the ATM that got addicted to money? It suffered from withdrawals.",
    "id" : 731523856876212224,
    "created_at" : "2016-05-14 16:37:33 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 731550991477297157,
  "created_at" : "2016-05-14 18:25:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/731522618898153472\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/DXP9NlYA49",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cibj8gkXAAAIh7K.jpg",
      "id_str" : "731522618168377344",
      "id" : 731522618168377344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cibj8gkXAAAIh7K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/DXP9NlYA49"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/awaECIBeSt",
      "expanded_url" : "http:\/\/engt.co\/27mCTT4",
      "display_url" : "engt.co\/27mCTT4"
    } ]
  },
  "geo" : { },
  "id_str" : "731550919087788034",
  "text" : "RT @engadget: An instant camera with a modern take on retro photography https:\/\/t.co\/awaECIBeSt https:\/\/t.co\/DXP9NlYA49",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/731522618898153472\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/DXP9NlYA49",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cibj8gkXAAAIh7K.jpg",
        "id_str" : "731522618168377344",
        "id" : 731522618168377344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cibj8gkXAAAIh7K.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/DXP9NlYA49"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/awaECIBeSt",
        "expanded_url" : "http:\/\/engt.co\/27mCTT4",
        "display_url" : "engt.co\/27mCTT4"
      } ]
    },
    "geo" : { },
    "id_str" : "731522618898153472",
    "text" : "An instant camera with a modern take on retro photography https:\/\/t.co\/awaECIBeSt https:\/\/t.co\/DXP9NlYA49",
    "id" : 731522618898153472,
    "created_at" : "2016-05-14 16:32:38 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 731550919087788034,
  "created_at" : "2016-05-14 18:25:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "indices" : [ 3, 15 ],
      "id_str" : "834316544",
      "id" : 834316544
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/731536334838452224\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/zBvQnOiNET",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cibwa6eWwAAXN_6.jpg",
      "id_str" : "731536334658125824",
      "id" : 731536334658125824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cibwa6eWwAAXN_6.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/zBvQnOiNET"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731550789236359168",
  "text" : "RT @ItsFoodPorn: Peanut Butter Cheesecake https:\/\/t.co\/zBvQnOiNET",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsFoodPorn\/status\/731536334838452224\/photo\/1",
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/zBvQnOiNET",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cibwa6eWwAAXN_6.jpg",
        "id_str" : "731536334658125824",
        "id" : 731536334658125824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cibwa6eWwAAXN_6.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/zBvQnOiNET"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731536334838452224",
    "text" : "Peanut Butter Cheesecake https:\/\/t.co\/zBvQnOiNET",
    "id" : 731536334838452224,
    "created_at" : "2016-05-14 17:27:08 +0000",
    "user" : {
      "name" : "FoodPorn",
      "screen_name" : "ItsFoodPorn",
      "protected" : false,
      "id_str" : "834316544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737420820570644481\/vm3MKA-H_normal.jpg",
      "id" : 834316544,
      "verified" : false
    }
  },
  "id" : 731550789236359168,
  "created_at" : "2016-05-14 18:24:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731550702024183808",
  "text" : "RT @martincallan: Racing 92 9-21 Saracens: Saracens become champions of Europe as Owen Farrell kicks seven penalties against Ra... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hSyaUtBT70",
        "expanded_url" : "http:\/\/bbc.in\/1s6Ri53",
        "display_url" : "bbc.in\/1s6Ri53"
      } ]
    },
    "geo" : { },
    "id_str" : "731548864851775488",
    "text" : "Racing 92 9-21 Saracens: Saracens become champions of Europe as Owen Farrell kicks seven penalties against Ra... https:\/\/t.co\/hSyaUtBT70",
    "id" : 731548864851775488,
    "created_at" : "2016-05-14 18:16:55 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 731550702024183808,
  "created_at" : "2016-05-14 18:24:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. Todd Sweeney",
      "screen_name" : "SomeKindaBoogin",
      "indices" : [ 3, 19 ],
      "id_str" : "2791121294",
      "id" : 2791121294
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SomeKindaBoogin\/status\/731493511841886208\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2ERsuLN1W5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CibJePiUgAA9eb-.jpg",
      "id_str" : "731493510898024448",
      "id" : 731493510898024448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CibJePiUgAA9eb-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/2ERsuLN1W5"
    } ],
    "hashtags" : [ {
      "text" : "ItsNotRadicalToSay",
      "indices" : [ 21, 40 ]
    }, {
      "text" : "Trump2016",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731550474562904065",
  "text" : "RT @SomeKindaBoogin: #ItsNotRadicalToSay that borders exist for a reason #Trump2016 https:\/\/t.co\/2ERsuLN1W5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SomeKindaBoogin\/status\/731493511841886208\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/2ERsuLN1W5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CibJePiUgAA9eb-.jpg",
        "id_str" : "731493510898024448",
        "id" : 731493510898024448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CibJePiUgAA9eb-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/2ERsuLN1W5"
      } ],
      "hashtags" : [ {
        "text" : "ItsNotRadicalToSay",
        "indices" : [ 0, 19 ]
      }, {
        "text" : "Trump2016",
        "indices" : [ 52, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731493511841886208",
    "text" : "#ItsNotRadicalToSay that borders exist for a reason #Trump2016 https:\/\/t.co\/2ERsuLN1W5",
    "id" : 731493511841886208,
    "created_at" : "2016-05-14 14:36:58 +0000",
    "user" : {
      "name" : "R. Todd Sweeney",
      "screen_name" : "SomeKindaBoogin",
      "protected" : false,
      "id_str" : "2791121294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736675277644959744\/StI9xKFj_normal.jpg",
      "id" : 2791121294,
      "verified" : false
    }
  },
  "id" : 731550474562904065,
  "created_at" : "2016-05-14 18:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Born Conservative",
      "screen_name" : "BornToBeGOP",
      "indices" : [ 3, 15 ],
      "id_str" : "3895471456",
      "id" : 3895471456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsNotRadicalToSay",
      "indices" : [ 17, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731550204122566657",
  "text" : "RT @BornToBeGOP: #ItsNotRadicalToSay illegal immigrants shouldn't be given healthcare and benefits that many legal Americans struggle to ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsNotRadicalToSay",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731525503618809861",
    "text" : "#ItsNotRadicalToSay illegal immigrants shouldn't be given healthcare and benefits that many legal Americans struggle to get themselves.",
    "id" : 731525503618809861,
    "created_at" : "2016-05-14 16:44:05 +0000",
    "user" : {
      "name" : "Born Conservative",
      "screen_name" : "BornToBeGOP",
      "protected" : false,
      "id_str" : "3895471456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651948003670884352\/MG7gzDDi_normal.jpg",
      "id" : 3895471456,
      "verified" : false
    }
  },
  "id" : 731550204122566657,
  "created_at" : "2016-05-14 18:22:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreedomTex \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "freedomtex",
      "indices" : [ 3, 14 ],
      "id_str" : "585373512",
      "id" : 585373512
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/freedomtex\/status\/731542232780570624\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/KOz1svo1vY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cib1yMUVEAAd8jN.jpg",
      "id_str" : "731542232143040512",
      "id" : 731542232143040512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cib1yMUVEAAd8jN.jpg",
      "sizes" : [ {
        "h" : 479,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 512
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/KOz1svo1vY"
    } ],
    "hashtags" : [ {
      "text" : "ItsNotRadicalToSay",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731549835841703936",
  "text" : "RT @freedomtex: #ItsNotRadicalToSay Capitalism works, whether you believe in it or not. https:\/\/t.co\/KOz1svo1vY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/freedomtex\/status\/731542232780570624\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/KOz1svo1vY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cib1yMUVEAAd8jN.jpg",
        "id_str" : "731542232143040512",
        "id" : 731542232143040512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cib1yMUVEAAd8jN.jpg",
        "sizes" : [ {
          "h" : 479,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 512
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/KOz1svo1vY"
      } ],
      "hashtags" : [ {
        "text" : "ItsNotRadicalToSay",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731542232780570624",
    "text" : "#ItsNotRadicalToSay Capitalism works, whether you believe in it or not. https:\/\/t.co\/KOz1svo1vY",
    "id" : 731542232780570624,
    "created_at" : "2016-05-14 17:50:34 +0000",
    "user" : {
      "name" : "FreedomTex \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "freedomtex",
      "protected" : false,
      "id_str" : "585373512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841092290793816065\/WWkf1JrG_normal.jpg",
      "id" : 585373512,
      "verified" : false
    }
  },
  "id" : 731549835841703936,
  "created_at" : "2016-05-14 18:20:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#HandsOffSyria",
      "screen_name" : "BrookeObie",
      "indices" : [ 3, 14 ],
      "id_str" : "89639762",
      "id" : 89639762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsNotRadicalToSay",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731549720460591105",
  "text" : "RT @BrookeObie: #ItsNotRadicalToSay Humans are born worthy of decency and respect",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsNotRadicalToSay",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731481493994868736",
    "text" : "#ItsNotRadicalToSay Humans are born worthy of decency and respect",
    "id" : 731481493994868736,
    "created_at" : "2016-05-14 13:49:13 +0000",
    "user" : {
      "name" : "#HandsOffSyria",
      "screen_name" : "BrookeObie",
      "protected" : false,
      "id_str" : "89639762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963285063759810560\/nitUjmhl_normal.jpg",
      "id" : 89639762,
      "verified" : true
    }
  },
  "id" : 731549720460591105,
  "created_at" : "2016-05-14 18:20:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaldlskxns",
      "screen_name" : "httxswilly",
      "indices" : [ 0, 11 ],
      "id_str" : "802891521536258053",
      "id" : 802891521536258053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731487257291567104",
  "geo" : { },
  "id_str" : "731549610599157760",
  "in_reply_to_user_id" : 2792834372,
  "text" : "@httxswilly Checkout my #HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731549610599157760,
  "in_reply_to_status_id" : 731487257291567104,
  "created_at" : "2016-05-14 18:19:53 +0000",
  "in_reply_to_screen_name" : "marckoftme",
  "in_reply_to_user_id_str" : "2792834372",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xprtly!",
      "screen_name" : "Xprtly",
      "indices" : [ 0, 7 ],
      "id_str" : "1438943570",
      "id" : 1438943570
    }, {
      "name" : "Renee Gauthier",
      "screen_name" : "Ren071968",
      "indices" : [ 8, 18 ],
      "id_str" : "1179225367",
      "id" : 1179225367
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 19, 30 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731516951554605057",
  "geo" : { },
  "id_str" : "731549456370421761",
  "in_reply_to_user_id" : 1438943570,
  "text" : "@Xprtly @Ren071968 @headtalker Cool, checkout my campaign https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731549456370421761,
  "in_reply_to_status_id" : 731516951554605057,
  "created_at" : "2016-05-14 18:19:16 +0000",
  "in_reply_to_screen_name" : "Xprtly",
  "in_reply_to_user_id_str" : "1438943570",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3164\u3164\u3164",
      "screen_name" : "confessionsongs",
      "indices" : [ 3, 19 ],
      "id_str" : "2774530382",
      "id" : 2774530382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731512263467630593",
  "text" : "RT @confessionsongs: and now it's raining :\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731512176167559169",
    "text" : "and now it's raining :\/",
    "id" : 731512176167559169,
    "created_at" : "2016-05-14 15:51:08 +0000",
    "user" : {
      "name" : "inma",
      "screen_name" : "realgotvixx",
      "protected" : false,
      "id_str" : "742303004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992763894480429061\/KfRbj0oQ_normal.jpg",
      "id" : 742303004,
      "verified" : false
    }
  },
  "id" : 731512263467630593,
  "created_at" : "2016-05-14 15:51:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee Gauthier",
      "screen_name" : "Ren071968",
      "indices" : [ 3, 13 ],
      "id_str" : "1179225367",
      "id" : 1179225367
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Ken O'Neill",
      "screen_name" : "KenJONeill",
      "indices" : [ 28, 39 ],
      "id_str" : "113115541",
      "id" : 113115541
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 40, 51 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731508639161155586",
  "text" : "RT @Ren071968: @gamer456148 @KenJONeill @headtalker Supported. Good luck!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Ken O'Neill",
        "screen_name" : "KenJONeill",
        "indices" : [ 13, 24 ],
        "id_str" : "113115541",
        "id" : 113115541
      }, {
        "name" : "HeadTalker",
        "screen_name" : "headtalker",
        "indices" : [ 25, 36 ],
        "id_str" : "2177390274",
        "id" : 2177390274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "731506124747198464",
    "geo" : { },
    "id_str" : "731508262680559618",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @KenJONeill @headtalker Supported. Good luck!",
    "id" : 731508262680559618,
    "in_reply_to_status_id" : 731506124747198464,
    "created_at" : "2016-05-14 15:35:35 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Renee Gauthier",
      "screen_name" : "Ren071968",
      "protected" : false,
      "id_str" : "1179225367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456768021080444928\/2myvv_G-_normal.jpeg",
      "id" : 1179225367,
      "verified" : false
    }
  },
  "id" : 731508639161155586,
  "created_at" : "2016-05-14 15:37:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#Astrodog",
      "screen_name" : "Memeth_Astrodog",
      "indices" : [ 3, 19 ],
      "id_str" : "55309785",
      "id" : 55309785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetBlockedIn5Words",
      "indices" : [ 49, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731507296572866563",
  "text" : "RT @Memeth_Astrodog: Axl Rose sings better now.\n\n#GetBlockedIn5Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetBlockedIn5Words",
        "indices" : [ 28, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731498711143055360",
    "text" : "Axl Rose sings better now.\n\n#GetBlockedIn5Words",
    "id" : 731498711143055360,
    "created_at" : "2016-05-14 14:57:37 +0000",
    "user" : {
      "name" : "#Astrodog",
      "screen_name" : "Memeth_Astrodog",
      "protected" : false,
      "id_str" : "55309785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631283048072523776\/Bac1pDFC_normal.jpg",
      "id" : 55309785,
      "verified" : false
    }
  },
  "id" : 731507296572866563,
  "created_at" : "2016-05-14 15:31:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lex",
      "screen_name" : "jayalexis_",
      "indices" : [ 3, 14 ],
      "id_str" : "153893773",
      "id" : 153893773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetBlockedIn5Words",
      "indices" : [ 47, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731507213601112064",
  "text" : "RT @jayalexis_: \"I believe in reverse racism.\"\n#GetBlockedIn5Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetBlockedIn5Words",
        "indices" : [ 31, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731506289721913344",
    "text" : "\"I believe in reverse racism.\"\n#GetBlockedIn5Words",
    "id" : 731506289721913344,
    "created_at" : "2016-05-14 15:27:44 +0000",
    "user" : {
      "name" : "lex",
      "screen_name" : "jayalexis_",
      "protected" : false,
      "id_str" : "153893773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/857524681393537024\/ro7PiL9d_normal.jpg",
      "id" : 153893773,
      "verified" : false
    }
  },
  "id" : 731507213601112064,
  "created_at" : "2016-05-14 15:31:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Armand Rosamilia",
      "screen_name" : "ArmandAuthor",
      "indices" : [ 12, 25 ],
      "id_str" : "18565896",
      "id" : 18565896
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 26, 37 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/yBeZdF8vPl",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "729714179863678976",
  "geo" : { },
  "id_str" : "731506650318659584",
  "in_reply_to_user_id" : 726399518758068225,
  "text" : "@GoJulyWest @ArmandAuthor @headtalker Check my #Headtalker https:\/\/t.co\/yBeZdF8vPl",
  "id" : 731506650318659584,
  "in_reply_to_status_id" : 729714179863678976,
  "created_at" : "2016-05-14 15:29:10 +0000",
  "in_reply_to_screen_name" : "ManyLivesSeries",
  "in_reply_to_user_id_str" : "726399518758068225",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Tarr",
      "screen_name" : "SusanMTarr",
      "indices" : [ 0, 11 ],
      "id_str" : "2413312986",
      "id" : 2413312986
    }, {
      "name" : "Thomas Jerome Baker",
      "screen_name" : "profesortbaker",
      "indices" : [ 12, 27 ],
      "id_str" : "108277226",
      "id" : 108277226
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 28, 39 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/yBeZdF8vPl",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731392960139382786",
  "geo" : { },
  "id_str" : "731506475453939712",
  "in_reply_to_user_id" : 2413312986,
  "text" : "@SusanMTarr @profesortbaker @headtalker Checkout my #Headtalker https:\/\/t.co\/yBeZdF8vPl",
  "id" : 731506475453939712,
  "in_reply_to_status_id" : 731392960139382786,
  "created_at" : "2016-05-14 15:28:29 +0000",
  "in_reply_to_screen_name" : "SusanMTarr",
  "in_reply_to_user_id_str" : "2413312986",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken O'Neill",
      "screen_name" : "KenJONeill",
      "indices" : [ 0, 11 ],
      "id_str" : "113115541",
      "id" : 113115541
    }, {
      "name" : "Renee Gauthier",
      "screen_name" : "Ren071968",
      "indices" : [ 12, 22 ],
      "id_str" : "1179225367",
      "id" : 1179225367
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 23, 34 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/yBeZdF8vPl",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "731495977828405248",
  "geo" : { },
  "id_str" : "731506124747198464",
  "in_reply_to_user_id" : 113115541,
  "text" : "@KenJONeill @Ren071968 @headtalker Can you help contribute to my #Headtalker https:\/\/t.co\/yBeZdF8vPl",
  "id" : 731506124747198464,
  "in_reply_to_status_id" : 731495977828405248,
  "created_at" : "2016-05-14 15:27:05 +0000",
  "in_reply_to_screen_name" : "KenJONeill",
  "in_reply_to_user_id_str" : "113115541",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Women's Sport Trust",
      "screen_name" : "WomenSportTrust",
      "indices" : [ 0, 16 ],
      "id_str" : "869641152",
      "id" : 869641152
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 17, 28 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Headtalker",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/yBeZdF8vPl",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "729381653714501632",
  "geo" : { },
  "id_str" : "731506068463849473",
  "in_reply_to_user_id" : 869641152,
  "text" : "@WomenSportTrust @headtalker Can you help contribute to my #Headtalker https:\/\/t.co\/yBeZdF8vPl",
  "id" : 731506068463849473,
  "in_reply_to_status_id" : 729381653714501632,
  "created_at" : "2016-05-14 15:26:52 +0000",
  "in_reply_to_screen_name" : "WomenSportTrust",
  "in_reply_to_user_id_str" : "869641152",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/731275650779090946\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/N2NYoBJ5SH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiYDUjZWsAEKP_C.jpg",
      "id_str" : "731275641128136705",
      "id" : 731275641128136705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiYDUjZWsAEKP_C.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1520,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1520,
        "resize" : "fit",
        "w" : 2048
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/N2NYoBJ5SH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731275650779090946",
  "text" : "Cottage Inn does really good calzones \uD83D\uDE0F https:\/\/t.co\/N2NYoBJ5SH",
  "id" : 731275650779090946,
  "created_at" : "2016-05-14 00:11:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "indices" : [ 3, 14 ],
      "id_str" : "552147406",
      "id" : 552147406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731221823740870656",
  "text" : "RT @TriviaHive: The Han Dynasty used tickling as a form of torturing nobility",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731221479107510272",
    "text" : "The Han Dynasty used tickling as a form of torturing nobility",
    "id" : 731221479107510272,
    "created_at" : "2016-05-13 20:36:00 +0000",
    "user" : {
      "name" : "Trivia Hive",
      "screen_name" : "TriviaHive",
      "protected" : false,
      "id_str" : "552147406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705567159968071680\/PQrm33In_normal.jpg",
      "id" : 552147406,
      "verified" : false
    }
  },
  "id" : 731221823740870656,
  "created_at" : "2016-05-13 20:37:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cynthia P. Willow",
      "screen_name" : "CynthiaPWillow",
      "indices" : [ 3, 18 ],
      "id_str" : "709566798",
      "id" : 709566798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/tHvla0Vk7b",
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/731185081277124608",
      "display_url" : "twitter.com\/gamer456148\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731221116551860224",
  "text" : "RT @CynthiaPWillow: Supported! https:\/\/t.co\/tHvla0Vk7b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/tHvla0Vk7b",
        "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/731185081277124608",
        "display_url" : "twitter.com\/gamer456148\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731194957378260992",
    "text" : "Supported! https:\/\/t.co\/tHvla0Vk7b",
    "id" : 731194957378260992,
    "created_at" : "2016-05-13 18:50:37 +0000",
    "user" : {
      "name" : "Cynthia P. Willow",
      "screen_name" : "CynthiaPWillow",
      "protected" : false,
      "id_str" : "709566798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000269645268\/fe9f34500e0f7206952ec8ecb08d5d0b_normal.jpeg",
      "id" : 709566798,
      "verified" : false
    }
  },
  "id" : 731221116551860224,
  "created_at" : "2016-05-13 20:34:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arizona Coyotes",
      "screen_name" : "ArizonaCoyotes",
      "indices" : [ 3, 18 ],
      "id_str" : "20006987",
      "id" : 20006987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731189535539924992",
  "text" : "RT @ArizonaCoyotes: Before becoming an NHL Head Coach, Mike Sullivan played in 709 NHL games, including 256 as a Yote. #FlashbackFriday htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ArizonaCoyotes\/status\/728675815924228096\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/kEyqqO1BZa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChzGyaWVEAEjgJk.jpg",
        "id_str" : "728675809095913473",
        "id" : 728675809095913473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChzGyaWVEAEjgJk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/kEyqqO1BZa"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728675815924228096",
    "text" : "Before becoming an NHL Head Coach, Mike Sullivan played in 709 NHL games, including 256 as a Yote. #FlashbackFriday https:\/\/t.co\/kEyqqO1BZa",
    "id" : 728675815924228096,
    "created_at" : "2016-05-06 20:00:27 +0000",
    "user" : {
      "name" : "Arizona Coyotes",
      "screen_name" : "ArizonaCoyotes",
      "protected" : false,
      "id_str" : "20006987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/975408195546972160\/8jLwkAoG_normal.jpg",
      "id" : 20006987,
      "verified" : true
    }
  },
  "id" : 731189535539924992,
  "created_at" : "2016-05-13 18:29:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65707359",
      "id" : 65707359
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 41, 46 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 96, 112 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731189416887259136",
  "text" : "RT @ShuttleCDRKelly: 20 yrs ago this wk, @NASA announced its 1996 astronaut class that included @StationCDRKelly &amp; me. #FlashbackFriday htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 20, 25 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Scott Kelly",
        "screen_name" : "StationCDRKelly",
        "indices" : [ 75, 91 ],
        "id_str" : "65647594",
        "id" : 65647594
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShuttleCDRKelly\/status\/728683321169879041\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/fY6XdqXndK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChzHg1kWUAA29tF.jpg",
        "id_str" : "728676606676455424",
        "id" : 728676606676455424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChzHg1kWUAA29tF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fY6XdqXndK"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 102, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728683321169879041",
    "text" : "20 yrs ago this wk, @NASA announced its 1996 astronaut class that included @StationCDRKelly &amp; me. #FlashbackFriday https:\/\/t.co\/fY6XdqXndK",
    "id" : 728683321169879041,
    "created_at" : "2016-05-06 20:30:16 +0000",
    "user" : {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "protected" : false,
      "id_str" : "65707359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738724057177325568\/QrZIaw99_normal.jpg",
      "id" : 65707359,
      "verified" : true
    }
  },
  "id" : 731189416887259136,
  "created_at" : "2016-05-13 18:28:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amer. Diabetes Assn.",
      "screen_name" : "AmDiabetesAssn",
      "indices" : [ 3, 18 ],
      "id_str" : "23794763",
      "id" : 23794763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 20, 36 ]
    }, {
      "text" : "GetFitDontSit",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731188722910302208",
  "text" : "RT @AmDiabetesAssn: #FlashbackFriday when we celebrated our annual #GetFitDontSit day and encouraged everyone to get up and move! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "GetFitDontSit",
        "indices" : [ 47, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/EJpAItp5rS",
        "expanded_url" : "http:\/\/sfy.co\/h1OYY",
        "display_url" : "sfy.co\/h1OYY"
      } ]
    },
    "geo" : { },
    "id_str" : "731114361784164353",
    "text" : "#FlashbackFriday when we celebrated our annual #GetFitDontSit day and encouraged everyone to get up and move! https:\/\/t.co\/EJpAItp5rS",
    "id" : 731114361784164353,
    "created_at" : "2016-05-13 13:30:21 +0000",
    "user" : {
      "name" : "Amer. Diabetes Assn.",
      "screen_name" : "AmDiabetesAssn",
      "protected" : false,
      "id_str" : "23794763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980891964739645444\/Va4NbTwo_normal.jpg",
      "id" : 23794763,
      "verified" : true
    }
  },
  "id" : 731188722910302208,
  "created_at" : "2016-05-13 18:25:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fr Matthew Schneider LC",
      "screen_name" : "FrMatthewLC",
      "indices" : [ 3, 15 ],
      "id_str" : "932013864",
      "id" : 932013864
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FrMatthewLC\/status\/731143905828347904\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4z5V8Bq0vF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWLgb-XIAE2kwL.jpg",
      "id_str" : "731143903898968065",
      "id" : 731143903898968065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWLgb-XIAE2kwL.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4z5V8Bq0vF"
    } ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 17, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731188557499539457",
  "text" : "RT @FrMatthewLC: #FlashbackFriday 35 years ago today, the shots that rang out throughout the world... https:\/\/t.co\/4z5V8Bq0vF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FrMatthewLC\/status\/731143905828347904\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/4z5V8Bq0vF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWLgb-XIAE2kwL.jpg",
        "id_str" : "731143903898968065",
        "id" : 731143903898968065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWLgb-XIAE2kwL.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/4z5V8Bq0vF"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731143905828347904",
    "text" : "#FlashbackFriday 35 years ago today, the shots that rang out throughout the world... https:\/\/t.co\/4z5V8Bq0vF",
    "id" : 731143905828347904,
    "created_at" : "2016-05-13 15:27:45 +0000",
    "user" : {
      "name" : "Fr Matthew Schneider LC",
      "screen_name" : "FrMatthewLC",
      "protected" : false,
      "id_str" : "932013864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972452670689726465\/sBa2XGNQ_normal.jpg",
      "id" : 932013864,
      "verified" : true
    }
  },
  "id" : 731188557499539457,
  "created_at" : "2016-05-13 18:25:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minnesota Wild",
      "screen_name" : "mnwild",
      "indices" : [ 3, 10 ],
      "id_str" : "17374906",
      "id" : 17374906
    }, {
      "name" : "IIHF",
      "screen_name" : "IIHFHockey",
      "indices" : [ 75, 86 ],
      "id_str" : "34895713",
      "id" : 34895713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 12, 28 ]
    }, {
      "text" : "nhlfi",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/rertGc6AAJ",
      "expanded_url" : "http:\/\/ow.ly\/o6zE300axwL",
      "display_url" : "ow.ly\/o6zE300axwL"
    } ]
  },
  "geo" : { },
  "id_str" : "731188442361675777",
  "text" : "RT @mnwild: #FlashbackFriday: 5 yrs ago Granlund showed his pure talent at @IIHFHockey Worlds\u2192 https:\/\/t.co\/rertGc6AAJ #nhlfi https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IIHF",
        "screen_name" : "IIHFHockey",
        "indices" : [ 63, 74 ],
        "id_str" : "34895713",
        "id" : 34895713
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mnwild\/status\/731163192563511296\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/GwF0yNljGY",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiWOxLgWUAEFhuS.jpg",
        "id_str" : "731147490070777857",
        "id" : 731147490070777857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiWOxLgWUAEFhuS.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 598
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/GwF0yNljGY"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "nhlfi",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/rertGc6AAJ",
        "expanded_url" : "http:\/\/ow.ly\/o6zE300axwL",
        "display_url" : "ow.ly\/o6zE300axwL"
      } ]
    },
    "geo" : { },
    "id_str" : "731163192563511296",
    "text" : "#FlashbackFriday: 5 yrs ago Granlund showed his pure talent at @IIHFHockey Worlds\u2192 https:\/\/t.co\/rertGc6AAJ #nhlfi https:\/\/t.co\/GwF0yNljGY",
    "id" : 731163192563511296,
    "created_at" : "2016-05-13 16:44:24 +0000",
    "user" : {
      "name" : "Minnesota Wild",
      "screen_name" : "mnwild",
      "protected" : false,
      "id_str" : "17374906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/987525414355685381\/9VwNibNU_normal.jpg",
      "id" : 17374906,
      "verified" : true
    }
  },
  "id" : 731188442361675777,
  "created_at" : "2016-05-13 18:24:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ShuttleCDRKelly\/status\/731167347415744513\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/FcBf50ysbA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWNj9DXEAAHXZm.jpg",
      "id_str" : "731146163341168640",
      "id" : 731146163341168640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWNj9DXEAAHXZm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/FcBf50ysbA"
    } ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 21, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731188318294167552",
  "text" : "RT @ShuttleCDRKelly: #FlashbackFriday to the final launch of Space Shuttle Endeavour 5 years ago this week. https:\/\/t.co\/FcBf50ysbA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShuttleCDRKelly\/status\/731167347415744513\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/FcBf50ysbA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWNj9DXEAAHXZm.jpg",
        "id_str" : "731146163341168640",
        "id" : 731146163341168640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWNj9DXEAAHXZm.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/FcBf50ysbA"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731167347415744513",
    "text" : "#FlashbackFriday to the final launch of Space Shuttle Endeavour 5 years ago this week. https:\/\/t.co\/FcBf50ysbA",
    "id" : 731167347415744513,
    "created_at" : "2016-05-13 17:00:54 +0000",
    "user" : {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "protected" : false,
      "id_str" : "65707359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738724057177325568\/QrZIaw99_normal.jpg",
      "id" : 65707359,
      "verified" : true
    }
  },
  "id" : 731188318294167552,
  "created_at" : "2016-05-13 18:24:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Performance Toyota",
      "screen_name" : "ToyotaStCath",
      "indices" : [ 3, 16 ],
      "id_str" : "344899916",
      "id" : 344899916
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Toyota",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "FlashbackFriday",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731187874205437953",
  "text" : "RT @ToyotaStCath: Ever seen one of these? Built for families with lots of cargo to carry around. 1970 #Toyota Crown. #FlashbackFriday https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ToyotaStCath\/status\/731187147173154817\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Tr0Br0NKPC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWy1fcWUAAY_6s.jpg",
        "id_str" : "731187146560786432",
        "id" : 731187146560786432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWy1fcWUAAY_6s.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/Tr0Br0NKPC"
      } ],
      "hashtags" : [ {
        "text" : "Toyota",
        "indices" : [ 84, 91 ]
      }, {
        "text" : "FlashbackFriday",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731187147173154817",
    "text" : "Ever seen one of these? Built for families with lots of cargo to carry around. 1970 #Toyota Crown. #FlashbackFriday https:\/\/t.co\/Tr0Br0NKPC",
    "id" : 731187147173154817,
    "created_at" : "2016-05-13 18:19:35 +0000",
    "user" : {
      "name" : "Performance Toyota",
      "screen_name" : "ToyotaStCath",
      "protected" : false,
      "id_str" : "344899916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/938157253735211009\/oo7h26m4_normal.jpg",
      "id" : 344899916,
      "verified" : false
    }
  },
  "id" : 731187874205437953,
  "created_at" : "2016-05-13 18:22:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ray \uD83E\uDD18\uD83C\uDFFE\uD83D\uDCAF\uD83D\uDE08",
      "screen_name" : "twoofresh_bst",
      "indices" : [ 3, 17 ],
      "id_str" : "154946095",
      "id" : 154946095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsAllFunAndGamesUntil",
      "indices" : [ 19, 42 ]
    }, {
      "text" : "RxyalMafia",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731187750527991810",
  "text" : "RT @twoofresh_bst: #ItsAllFunAndGamesUntil you get your feelings hurt #RxyalMafia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsAllFunAndGamesUntil",
        "indices" : [ 0, 23 ]
      }, {
        "text" : "RxyalMafia",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724041590843531264",
    "text" : "#ItsAllFunAndGamesUntil you get your feelings hurt #RxyalMafia",
    "id" : 724041590843531264,
    "created_at" : "2016-04-24 01:05:41 +0000",
    "user" : {
      "name" : "ray \uD83E\uDD18\uD83C\uDFFE\uD83D\uDCAF\uD83D\uDE08",
      "screen_name" : "twoofresh_bst",
      "protected" : false,
      "id_str" : "154946095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812506079909265409\/Oztu6mlj_normal.jpg",
      "id" : 154946095,
      "verified" : false
    }
  },
  "id" : 731187750527991810,
  "created_at" : "2016-05-13 18:21:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jr and Miyah Mommy",
      "screen_name" : "kammydenisee",
      "indices" : [ 3, 16 ],
      "id_str" : "1271101693",
      "id" : 1271101693
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsAllFunAndGamesUntil",
      "indices" : [ 18, 41 ]
    }, {
      "text" : "RxyalMafia",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731187603979014145",
  "text" : "RT @kammydenisee: #ItsAllFunAndGamesUntil reality hits #RxyalMafia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsAllFunAndGamesUntil",
        "indices" : [ 0, 23 ]
      }, {
        "text" : "RxyalMafia",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "724046452733841408",
    "text" : "#ItsAllFunAndGamesUntil reality hits #RxyalMafia",
    "id" : 724046452733841408,
    "created_at" : "2016-04-24 01:25:01 +0000",
    "user" : {
      "name" : "Jr and Miyah Mommy",
      "screen_name" : "kammydenisee",
      "protected" : false,
      "id_str" : "1271101693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748788075220774912\/_xwdlofY_normal.jpg",
      "id" : 1271101693,
      "verified" : false
    }
  },
  "id" : 731187603979014145,
  "created_at" : "2016-05-13 18:21:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayme Wait",
      "screen_name" : "theachero",
      "indices" : [ 3, 13 ],
      "id_str" : "3805550774",
      "id" : 3805550774
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoExcuses",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "FridayFeeling",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731187043477430272",
  "text" : "RT @theachero: It takes just as much energy to think of an excuse as it does to think of a solution.  #NoExcuses #FridayFeeling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoExcuses",
        "indices" : [ 87, 97 ]
      }, {
        "text" : "FridayFeeling",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731144475066523648",
    "text" : "It takes just as much energy to think of an excuse as it does to think of a solution.  #NoExcuses #FridayFeeling",
    "id" : 731144475066523648,
    "created_at" : "2016-05-13 15:30:01 +0000",
    "user" : {
      "name" : "Jayme Wait",
      "screen_name" : "theachero",
      "protected" : false,
      "id_str" : "3805550774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691443033997324288\/O47gy8fo_normal.jpg",
      "id" : 3805550774,
      "verified" : false
    }
  },
  "id" : 731187043477430272,
  "created_at" : "2016-05-13 18:19:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Orlando City SC",
      "screen_name" : "OrlandoCitySC",
      "indices" : [ 3, 17 ],
      "id_str" : "213474069",
      "id" : 213474069
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OrlandoCitySC\/status\/731169142842097664\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/xxZyvW7nzo",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiV8uTYXAAAWKL8.jpg",
      "id_str" : "731127649435844608",
      "id" : 731127649435844608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiV8uTYXAAAWKL8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 320
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/xxZyvW7nzo"
    } ],
    "hashtags" : [ {
      "text" : "FridayFeeling",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731186638529937409",
  "text" : "RT @OrlandoCitySC: That #FridayFeeling https:\/\/t.co\/xxZyvW7nzo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OrlandoCitySC\/status\/731169142842097664\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/xxZyvW7nzo",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiV8uTYXAAAWKL8.jpg",
        "id_str" : "731127649435844608",
        "id" : 731127649435844608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiV8uTYXAAAWKL8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 320
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/xxZyvW7nzo"
      } ],
      "hashtags" : [ {
        "text" : "FridayFeeling",
        "indices" : [ 5, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731169142842097664",
    "text" : "That #FridayFeeling https:\/\/t.co\/xxZyvW7nzo",
    "id" : 731169142842097664,
    "created_at" : "2016-05-13 17:08:02 +0000",
    "user" : {
      "name" : "Orlando City SC",
      "screen_name" : "OrlandoCitySC",
      "protected" : false,
      "id_str" : "213474069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877585874871099393\/gN_kHN7-_normal.jpg",
      "id" : 213474069,
      "verified" : true
    }
  },
  "id" : 731186638529937409,
  "created_at" : "2016-05-13 18:17:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "swaronian",
      "indices" : [ 11, 21 ],
      "id_str" : "588453145",
      "id" : 588453145
    }, {
      "name" : "HeadTalker",
      "screen_name" : "headtalker",
      "indices" : [ 22, 33 ],
      "id_str" : "2177390274",
      "id" : 2177390274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "in_reply_to_status_id_str" : "729671956983779328",
  "geo" : { },
  "id_str" : "731186250921709568",
  "in_reply_to_user_id" : 1197376298,
  "text" : "@himani_1D @swaronian @headtalker Cool, checkout our HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731186250921709568,
  "in_reply_to_status_id" : 729671956983779328,
  "created_at" : "2016-05-13 18:16:01 +0000",
  "in_reply_to_screen_name" : "Himani_169",
  "in_reply_to_user_id_str" : "1197376298",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cynthia P. Willow",
      "screen_name" : "CynthiaPWillow",
      "indices" : [ 0, 15 ],
      "id_str" : "709566798",
      "id" : 709566798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadTalker",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/yBeZdEQUXN",
      "expanded_url" : "http:\/\/bit.ly\/27kldXW",
      "display_url" : "bit.ly\/27kldXW"
    } ]
  },
  "geo" : { },
  "id_str" : "731185081277124608",
  "in_reply_to_user_id" : 709566798,
  "text" : "@CynthiaPWillow Checkout my #HeadTalker https:\/\/t.co\/yBeZdEQUXN",
  "id" : 731185081277124608,
  "created_at" : "2016-05-13 18:11:22 +0000",
  "in_reply_to_screen_name" : "CynthiaPWillow",
  "in_reply_to_user_id_str" : "709566798",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Premium",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "DeadSeaUSA",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/JLWnQUhcfB",
      "expanded_url" : "https:\/\/hdtk.co\/RQKLA",
      "display_url" : "hdtk.co\/RQKLA"
    } ]
  },
  "geo" : { },
  "id_str" : "730816808689803264",
  "text" : "\u201CGet the best #Premium organic skin scrubs at low cost #DeadSeaUSA  https:\/\/t.co\/JLWnQUhcfB\u201D",
  "id" : 730816808689803264,
  "created_at" : "2016-05-12 17:47:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "texty biscuit",
      "screen_name" : "Fuffanie",
      "indices" : [ 3, 12 ],
      "id_str" : "327727961",
      "id" : 327727961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouMayBeRight",
      "indices" : [ 14, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729737426760024064",
  "text" : "RT @Fuffanie: #YouMayBeRight but that would mean I'm wrong",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouMayBeRight",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729733143859625984",
    "text" : "#YouMayBeRight but that would mean I'm wrong",
    "id" : 729733143859625984,
    "created_at" : "2016-05-09 18:01:53 +0000",
    "user" : {
      "name" : "texty biscuit",
      "screen_name" : "Fuffanie",
      "protected" : false,
      "id_str" : "327727961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758931788353765377\/2YqkICgi_normal.jpg",
      "id" : 327727961,
      "verified" : false
    }
  },
  "id" : 729737426760024064,
  "created_at" : "2016-05-09 18:18:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Cloud",
      "screen_name" : "theclobra",
      "indices" : [ 3, 13 ],
      "id_str" : "2418808274",
      "id" : 2418808274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouMayBeRight",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729737167665299460",
  "text" : "RT @theclobra: #YouMayBeRight but this will go much faster if you'll just go ahead and apologize.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouMayBeRight",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729646861955436545",
    "text" : "#YouMayBeRight but this will go much faster if you'll just go ahead and apologize.",
    "id" : 729646861955436545,
    "created_at" : "2016-05-09 12:19:02 +0000",
    "user" : {
      "name" : "Brandon Cloud",
      "screen_name" : "theclobra",
      "protected" : false,
      "id_str" : "2418808274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/964582269401825281\/KCYUtDbV_normal.jpg",
      "id" : 2418808274,
      "verified" : true
    }
  },
  "id" : 729737167665299460,
  "created_at" : "2016-05-09 18:17:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PETA",
      "screen_name" : "peta",
      "indices" : [ 3, 8 ],
      "id_str" : "9890492",
      "id" : 9890492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouMayBeRight",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729736981438189568",
  "text" : "RT @peta: If you think adopting a homeless animal will make you feel better than buying one #YouMayBeRight \u2764\uFE0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouMayBeRight",
        "indices" : [ 82, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729698703234064384",
    "text" : "If you think adopting a homeless animal will make you feel better than buying one #YouMayBeRight \u2764\uFE0F",
    "id" : 729698703234064384,
    "created_at" : "2016-05-09 15:45:02 +0000",
    "user" : {
      "name" : "PETA",
      "screen_name" : "peta",
      "protected" : false,
      "id_str" : "9890492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/951227440126361600\/dYu2t-bw_normal.jpg",
      "id" : 9890492,
      "verified" : true
    }
  },
  "id" : 729736981438189568,
  "created_at" : "2016-05-09 18:17:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hypocrite Twins",
      "screen_name" : "HypocriteTwins",
      "indices" : [ 0, 15 ],
      "id_str" : "3430270660",
      "id" : 3430270660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729662299905085441",
  "geo" : { },
  "id_str" : "729736659479187456",
  "in_reply_to_user_id" : 3430270660,
  "text" : "@HypocriteTwins Oh my goodness",
  "id" : 729736659479187456,
  "in_reply_to_status_id" : 729662299905085441,
  "created_at" : "2016-05-09 18:15:52 +0000",
  "in_reply_to_screen_name" : "HypocriteTwins",
  "in_reply_to_user_id_str" : "3430270660",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Javier Garde",
      "screen_name" : "jose_garde",
      "indices" : [ 0, 11 ],
      "id_str" : "2284237477",
      "id" : 2284237477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729672506936713216",
  "geo" : { },
  "id_str" : "729736544211316736",
  "in_reply_to_user_id" : 2284237477,
  "text" : "@jose_garde But it is a social network, how is it a news app?",
  "id" : 729736544211316736,
  "in_reply_to_status_id" : 729672506936713216,
  "created_at" : "2016-05-09 18:15:24 +0000",
  "in_reply_to_screen_name" : "jose_garde",
  "in_reply_to_user_id_str" : "2284237477",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 15, 24 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Ben Woods",
      "screen_name" : "TheNextWoods",
      "indices" : [ 25, 38 ],
      "id_str" : "163032364",
      "id" : 163032364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729736156594720768",
  "text" : "@BukanivEvgeni @facebook @TheNextWoods Well....",
  "id" : 729736156594720768,
  "created_at" : "2016-05-09 18:13:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Jenkins",
      "screen_name" : "MeganJe07350032",
      "indices" : [ 0, 16 ],
      "id_str" : "498725549",
      "id" : 498725549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/fB3P5Q72Ld",
      "expanded_url" : "http:\/\/andsocialrew.net",
      "display_url" : "andsocialrew.net"
    } ]
  },
  "in_reply_to_status_id_str" : "729735718357045248",
  "geo" : { },
  "id_str" : "729735978517200896",
  "in_reply_to_user_id" : 498725549,
  "text" : "@MeganJe07350032 What about my site, https:\/\/t.co\/fB3P5Q72Ld Lol",
  "id" : 729735978517200896,
  "in_reply_to_status_id" : 729735718357045248,
  "created_at" : "2016-05-09 18:13:09 +0000",
  "in_reply_to_screen_name" : "MeganJe07350032",
  "in_reply_to_user_id_str" : "498725549",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 122, 138 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729522089854558210",
  "text" : "RT @TheSharkDaymond: \u201CThere\u2019s no better motivation for an entrepreneur than wanting to prove something\u201D RT if you\u2019re with @BarbaraCorcoran.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barbara Corcoran",
        "screen_name" : "BarbaraCorcoran",
        "indices" : [ 101, 117 ],
        "id_str" : "36728196",
        "id" : 36728196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728758219208839168",
    "text" : "\u201CThere\u2019s no better motivation for an entrepreneur than wanting to prove something\u201D RT if you\u2019re with @BarbaraCorcoran. #SharkTank",
    "id" : 728758219208839168,
    "created_at" : "2016-05-07 01:27:53 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932689703391940615\/zAkwGMNj_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 729522089854558210,
  "created_at" : "2016-05-09 04:03:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "indices" : [ 3, 16 ],
      "id_str" : "39357604",
      "id" : 39357604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MostDangerousTown",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/mYBCX4JKxn",
      "expanded_url" : "http:\/\/nr.tn\/1WLRX7x",
      "display_url" : "nr.tn\/1WLRX7x"
    } ]
  },
  "geo" : { },
  "id_str" : "729521750799618048",
  "text" : "RT @NortonOnline: #MostDangerousTown subject 'Guccifer' Says He Hacked Hillary Clinton's Email and 'It Was Easy' https:\/\/t.co\/mYBCX4JKxn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MostDangerousTown",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/mYBCX4JKxn",
        "expanded_url" : "http:\/\/nr.tn\/1WLRX7x",
        "display_url" : "nr.tn\/1WLRX7x"
      } ]
    },
    "geo" : { },
    "id_str" : "728707415634497536",
    "text" : "#MostDangerousTown subject 'Guccifer' Says He Hacked Hillary Clinton's Email and 'It Was Easy' https:\/\/t.co\/mYBCX4JKxn",
    "id" : 728707415634497536,
    "created_at" : "2016-05-06 22:06:01 +0000",
    "user" : {
      "name" : "Norton",
      "screen_name" : "NortonOnline",
      "protected" : false,
      "id_str" : "39357604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816328497694199808\/oeI12_Ei_normal.jpg",
      "id" : 39357604,
      "verified" : true
    }
  },
  "id" : 729521750799618048,
  "created_at" : "2016-05-09 04:01:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "indices" : [ 3, 16 ],
      "id_str" : "369885165",
      "id" : 369885165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729520789767127040",
  "text" : "RT @RandiAthenas: I asked the hotel receptionist for a wake-up call. Next morning, he calls and says 'What are you going to do with your li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728687301811798016",
    "text" : "I asked the hotel receptionist for a wake-up call. Next morning, he calls and says 'What are you going to do with your life?'",
    "id" : 728687301811798016,
    "created_at" : "2016-05-06 20:46:05 +0000",
    "user" : {
      "name" : "Randi Athenas",
      "screen_name" : "RandiAthenas",
      "protected" : false,
      "id_str" : "369885165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1533892239\/me_guitar_cropped_normal.jpg",
      "id" : 369885165,
      "verified" : false
    }
  },
  "id" : 729520789767127040,
  "created_at" : "2016-05-09 03:58:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729519922372448256",
  "text" : "Had the Quesadilla Rellena @ El Patio today, was so good 4.84\/5 stars",
  "id" : 729519922372448256,
  "created_at" : "2016-05-09 03:54:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729026425752162304",
  "text" : "Had the BBQ Chicken FlatBread at Kona Grill: 4.55\/5 stars",
  "id" : 729026425752162304,
  "created_at" : "2016-05-07 19:13:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "indices" : [ 3, 15 ],
      "id_str" : "231971209",
      "id" : 231971209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728664201963573248",
  "text" : "RT @DJPROEBEATS: If you still think blogs are the main way to grow your fan base, you're already way behind the curve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728312186095865861",
    "text" : "If you still think blogs are the main way to grow your fan base, you're already way behind the curve",
    "id" : 728312186095865861,
    "created_at" : "2016-05-05 19:55:31 +0000",
    "user" : {
      "name" : "DJ Proe",
      "screen_name" : "DJPROEBEATS",
      "protected" : false,
      "id_str" : "231971209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/943587710220079104\/0stt_yN1_normal.jpg",
      "id" : 231971209,
      "verified" : false
    }
  },
  "id" : 728664201963573248,
  "created_at" : "2016-05-06 19:14:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728664146871377925",
  "text" : "RT @hannahbleau_: This is the most wonderful pander-y thing ever. The only thing that would've made it better is a sombrero.  https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/TJzoHfQtUu",
        "expanded_url" : "https:\/\/twitter.com\/realDonaldTrump\/status\/728297587418247168",
        "display_url" : "twitter.com\/realDonaldTrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728303228518043649",
    "text" : "This is the most wonderful pander-y thing ever. The only thing that would've made it better is a sombrero.  https:\/\/t.co\/TJzoHfQtUu",
    "id" : 728303228518043649,
    "created_at" : "2016-05-05 19:19:55 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891134811548639234\/n0VqdxCX_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 728664146871377925,
  "created_at" : "2016-05-06 19:14:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "candy",
      "screen_name" : "candysohood",
      "indices" : [ 0, 12 ],
      "id_str" : "709535172564111360",
      "id" : 709535172564111360
    }, {
      "name" : "Peaches",
      "screen_name" : "sexxandblunts",
      "indices" : [ 13, 27 ],
      "id_str" : "200751709",
      "id" : 200751709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728505193009156096",
  "geo" : { },
  "id_str" : "728663864137547776",
  "in_reply_to_user_id" : 709535172564111360,
  "text" : "@candysohood @sexxandblunts Just why?",
  "id" : 728663864137547776,
  "in_reply_to_status_id" : 728505193009156096,
  "created_at" : "2016-05-06 19:12:57 +0000",
  "in_reply_to_screen_name" : "candysohood",
  "in_reply_to_user_id_str" : "709535172564111360",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/728663574160117760\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/8xASNtvm1l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chy7pRoVEAAzHcw.jpg",
      "id_str" : "728663557508763648",
      "id" : 728663557508763648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chy7pRoVEAAzHcw.jpg",
      "sizes" : [ {
        "h" : 1930,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1131,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1930,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/8xASNtvm1l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728663574160117760",
  "text" : "Went to Smash Burger w\/ my bro Pat; 4.18\/5 stars https:\/\/t.co\/8xASNtvm1l",
  "id" : 728663574160117760,
  "created_at" : "2016-05-06 19:11:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda McDonald",
      "screen_name" : "AmandaMcBuch",
      "indices" : [ 3, 16 ],
      "id_str" : "1670605052",
      "id" : 1670605052
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 18, 26 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728594700861644802",
  "text" : "RT @AmandaMcBuch: @tedcruz we love you! Ready and waiting to see you back in the race in 2020. This is just your 1976 run. 1980 is on the h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 0, 8 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CruzCrew",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "728332395531796481",
    "geo" : { },
    "id_str" : "728417931248472064",
    "in_reply_to_user_id" : 23022687,
    "text" : "@tedcruz we love you! Ready and waiting to see you back in the race in 2020. This is just your 1976 run. 1980 is on the horizon. #CruzCrew",
    "id" : 728417931248472064,
    "in_reply_to_status_id" : 728332395531796481,
    "created_at" : "2016-05-06 02:55:42 +0000",
    "in_reply_to_screen_name" : "tedcruz",
    "in_reply_to_user_id_str" : "23022687",
    "user" : {
      "name" : "Amanda McDonald",
      "screen_name" : "AmandaMcBuch",
      "protected" : false,
      "id_str" : "1670605052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780597472796282880\/h7nXp6EX_normal.jpg",
      "id" : 1670605052,
      "verified" : false
    }
  },
  "id" : 728594700861644802,
  "created_at" : "2016-05-06 14:38:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/8d6lI3SuTB",
      "expanded_url" : "http:\/\/mashable.com\/2016\/05\/05\/elon-musk-tesla-sleep\/",
      "display_url" : "mashable.com\/2016\/05\/05\/elo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728215835802804228",
  "text" : "RT @EmperorDarroux: Elon Musk sleeps at Tesla's factory 'quite frequently' to hit lofty production targets https:\/\/t.co\/8d6lI3SuTB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/8d6lI3SuTB",
        "expanded_url" : "http:\/\/mashable.com\/2016\/05\/05\/elon-musk-tesla-sleep\/",
        "display_url" : "mashable.com\/2016\/05\/05\/elo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728215396436746240",
    "text" : "Elon Musk sleeps at Tesla's factory 'quite frequently' to hit lofty production targets https:\/\/t.co\/8d6lI3SuTB",
    "id" : 728215396436746240,
    "created_at" : "2016-05-05 13:30:54 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 728215835802804228,
  "created_at" : "2016-05-05 13:32:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Relatable Poems",
      "screen_name" : "RelatabIePoems",
      "indices" : [ 0, 15 ],
      "id_str" : "592848274",
      "id" : 592848274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SassAttack",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728215327000010752",
  "geo" : { },
  "id_str" : "728215777816522752",
  "in_reply_to_user_id" : 592848274,
  "text" : "@RelatabIePoems Oh snap #SassAttack",
  "id" : 728215777816522752,
  "in_reply_to_status_id" : 728215327000010752,
  "created_at" : "2016-05-05 13:32:25 +0000",
  "in_reply_to_screen_name" : "RelatabIePoems",
  "in_reply_to_user_id_str" : "592848274",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728213958218395648",
  "text" : "RT @BarbaraCorcoran: The only difference between my hugely successful salespeople and everyone else is how long they take to feel sorry for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728203962227277824",
    "text" : "The only difference between my hugely successful salespeople and everyone else is how long they take to feel sorry for themselves.",
    "id" : 728203962227277824,
    "created_at" : "2016-05-05 12:45:28 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 728213958218395648,
  "created_at" : "2016-05-05 13:25:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProTips",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728204190468718593",
  "geo" : { },
  "id_str" : "728213589824311296",
  "in_reply_to_user_id" : 35141577,
  "text" : "@kellyriotx Then it's not really love? Love isn't one way!!! #ProTips",
  "id" : 728213589824311296,
  "in_reply_to_status_id" : 728204190468718593,
  "created_at" : "2016-05-05 13:23:44 +0000",
  "in_reply_to_screen_name" : "kriotx",
  "in_reply_to_user_id_str" : "35141577",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/728202093727764480\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/4EetgP7HgO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsX8iDXIAAfL7N.jpg",
      "id_str" : "728202093450960896",
      "id" : 728202093450960896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsX8iDXIAAfL7N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4EetgP7HgO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728213397150543872",
  "text" : "RT @rockindigo: This guy is so underrated https:\/\/t.co\/4EetgP7HgO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/728202093727764480\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/4EetgP7HgO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsX8iDXIAAfL7N.jpg",
        "id_str" : "728202093450960896",
        "id" : 728202093450960896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsX8iDXIAAfL7N.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/4EetgP7HgO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728202093727764480",
    "text" : "This guy is so underrated https:\/\/t.co\/4EetgP7HgO",
    "id" : 728202093727764480,
    "created_at" : "2016-05-05 12:38:03 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908767325456932865\/SRpEZ2Ut_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 728213397150543872,
  "created_at" : "2016-05-05 13:22:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "indices" : [ 3, 16 ],
      "id_str" : "24664726",
      "id" : 24664726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728212888981258240",
  "text" : "RT @andykleinman: For the second year in a row, the Hawks don't even deserve to be in the Playoffs at all. What a disappointing and horribl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728025920406102016",
    "text" : "For the second year in a row, the Hawks don't even deserve to be in the Playoffs at all. What a disappointing and horrible team.",
    "id" : 728025920406102016,
    "created_at" : "2016-05-05 00:58:00 +0000",
    "user" : {
      "name" : "Andy Kleinman",
      "screen_name" : "andykleinman",
      "protected" : false,
      "id_str" : "24664726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866530832315408384\/h0ORI03N_normal.jpg",
      "id" : 24664726,
      "verified" : true
    }
  },
  "id" : 728212888981258240,
  "created_at" : "2016-05-05 13:20:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "des",
      "screen_name" : "stuffedjalapeno",
      "indices" : [ 0, 16 ],
      "id_str" : "635930726",
      "id" : 635930726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728021032511004672",
  "geo" : { },
  "id_str" : "728212786598260736",
  "in_reply_to_user_id" : 635930726,
  "text" : "@stuffedjalapeno Yeah it happens, bugs are pesky critters, aren't they?",
  "id" : 728212786598260736,
  "in_reply_to_status_id" : 728021032511004672,
  "created_at" : "2016-05-05 13:20:32 +0000",
  "in_reply_to_screen_name" : "stuffedjalapeno",
  "in_reply_to_user_id_str" : "635930726",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/727980705020530693\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/V5SmY69rBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpOl_PXAAIdhM2.jpg",
      "id_str" : "727980704311738370",
      "id" : 727980704311738370,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpOl_PXAAIdhM2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/V5SmY69rBE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/aN9TCYAJIw",
      "expanded_url" : "http:\/\/engt.co\/1Tn0mZN",
      "display_url" : "engt.co\/1Tn0mZN"
    } ]
  },
  "geo" : { },
  "id_str" : "728212340676661249",
  "text" : "RT @engadget: With a new 75kWh battery option, Tesla's Model S just became more enticing https:\/\/t.co\/aN9TCYAJIw https:\/\/t.co\/V5SmY69rBE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/727980705020530693\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/V5SmY69rBE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpOl_PXAAIdhM2.jpg",
        "id_str" : "727980704311738370",
        "id" : 727980704311738370,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpOl_PXAAIdhM2.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/V5SmY69rBE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/aN9TCYAJIw",
        "expanded_url" : "http:\/\/engt.co\/1Tn0mZN",
        "display_url" : "engt.co\/1Tn0mZN"
      } ]
    },
    "geo" : { },
    "id_str" : "727980705020530693",
    "text" : "With a new 75kWh battery option, Tesla's Model S just became more enticing https:\/\/t.co\/aN9TCYAJIw https:\/\/t.co\/V5SmY69rBE",
    "id" : 727980705020530693,
    "created_at" : "2016-05-04 21:58:19 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 728212340676661249,
  "created_at" : "2016-05-05 13:18:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Destinie",
      "screen_name" : "dessalexandria",
      "indices" : [ 0, 15 ],
      "id_str" : "447848592",
      "id" : 447848592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728092958482800641",
  "geo" : { },
  "id_str" : "728195391087325184",
  "in_reply_to_user_id" : 447848592,
  "text" : "@dessalexandria @YazmineJimenez A woman shouldn't fall in love with a man who mistreats her, but it happens often in this society",
  "id" : 728195391087325184,
  "in_reply_to_status_id" : 728092958482800641,
  "created_at" : "2016-05-05 12:11:25 +0000",
  "in_reply_to_screen_name" : "dessalexandria",
  "in_reply_to_user_id_str" : "447848592",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728194743952355328",
  "text" : "It is so inspiring how successful some people at Silicon Valley is, but some just got lucky.",
  "id" : 728194743952355328,
  "created_at" : "2016-05-05 12:08:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Evans",
      "screen_name" : "JustinJumpstart",
      "indices" : [ 3, 19 ],
      "id_str" : "62087551",
      "id" : 62087551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728194105302503424",
  "text" : "RT @JustinJumpstart: For the Lord is good. His unfailing love continues forever, and his faithfulness continues to each generation. \/\/ Psal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728164882428755968",
    "text" : "For the Lord is good. His unfailing love continues forever, and his faithfulness continues to each generation. \/\/ Psalm 100:5",
    "id" : 728164882428755968,
    "created_at" : "2016-05-05 10:10:11 +0000",
    "user" : {
      "name" : "Justin Evans",
      "screen_name" : "JustinJumpstart",
      "protected" : false,
      "id_str" : "62087551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856809645918355456\/70o1LBMu_normal.jpg",
      "id" : 62087551,
      "verified" : false
    }
  },
  "id" : 728194105302503424,
  "created_at" : "2016-05-05 12:06:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JONATHAN M. MELLOR",
      "screen_name" : "JonathanMellor",
      "indices" : [ 3, 18 ],
      "id_str" : "32863252",
      "id" : 32863252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728193745599008768",
  "text" : "RT @JonathanMellor: I have too much energy at night times than mornings... \uD83D\uDE38 \uD83D\uDE39 \uD83D\uDE3D \uD83D\uDE3A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728051581149687810",
    "text" : "I have too much energy at night times than mornings... \uD83D\uDE38 \uD83D\uDE39 \uD83D\uDE3D \uD83D\uDE3A",
    "id" : 728051581149687810,
    "created_at" : "2016-05-05 02:39:58 +0000",
    "user" : {
      "name" : "JONATHAN M. MELLOR",
      "screen_name" : "JonathanMellor",
      "protected" : false,
      "id_str" : "32863252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/992179788130463750\/kuwgGEDw_normal.jpg",
      "id" : 32863252,
      "verified" : false
    }
  },
  "id" : 728193745599008768,
  "created_at" : "2016-05-05 12:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pluralsight\/status\/728181716922171392\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/p9V8365YYw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsFaXMUoAA6bZ8.jpg",
      "id_str" : "728181715210903552",
      "id" : 728181715210903552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsFaXMUoAA6bZ8.jpg",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 720
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/p9V8365YYw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/jD9t10LShr",
      "expanded_url" : "http:\/\/bit.ly\/21zCYP6",
      "display_url" : "bit.ly\/21zCYP6"
    } ]
  },
  "geo" : { },
  "id_str" : "728193472017084416",
  "text" : "RT @pluralsight: Microsoft\u2019s next version of SQL Server will launch June 1: https:\/\/t.co\/jD9t10LShr https:\/\/t.co\/p9V8365YYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 -Social Media Management\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pluralsight\/status\/728181716922171392\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/p9V8365YYw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsFaXMUoAA6bZ8.jpg",
        "id_str" : "728181715210903552",
        "id" : 728181715210903552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsFaXMUoAA6bZ8.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 720
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/p9V8365YYw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/jD9t10LShr",
        "expanded_url" : "http:\/\/bit.ly\/21zCYP6",
        "display_url" : "bit.ly\/21zCYP6"
      } ]
    },
    "geo" : { },
    "id_str" : "728181716922171392",
    "text" : "Microsoft\u2019s next version of SQL Server will launch June 1: https:\/\/t.co\/jD9t10LShr https:\/\/t.co\/p9V8365YYw",
    "id" : 728181716922171392,
    "created_at" : "2016-05-05 11:17:04 +0000",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908381030821675009\/nOwJrmgq_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 728193472017084416,
  "created_at" : "2016-05-05 12:03:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Mena",
      "screen_name" : "alexmenamiami",
      "indices" : [ 0, 14 ],
      "id_str" : "394465457",
      "id" : 394465457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727675576295677952",
  "geo" : { },
  "id_str" : "727714605645103106",
  "in_reply_to_user_id" : 394465457,
  "text" : "@alexmenamiami Well I guess I am supporting Trump now, if it means not voting for the wicked witch of Washongton.",
  "id" : 727714605645103106,
  "in_reply_to_status_id" : 727675576295677952,
  "created_at" : "2016-05-04 04:20:56 +0000",
  "in_reply_to_screen_name" : "alexmenamiami",
  "in_reply_to_user_id_str" : "394465457",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grant schwomeyer",
      "screen_name" : "gschwo",
      "indices" : [ 3, 10 ],
      "id_str" : "126357484",
      "id" : 126357484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727636707445768192",
  "text" : "RT @gschwo: I can't wrap my head around the people who complain complain complain about issues in our country but then choose not to vote...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727636397557977089",
    "text" : "I can't wrap my head around the people who complain complain complain about issues in our country but then choose not to vote...",
    "id" : 727636397557977089,
    "created_at" : "2016-05-03 23:10:10 +0000",
    "user" : {
      "name" : "grant schwomeyer",
      "screen_name" : "gschwo",
      "protected" : false,
      "id_str" : "126357484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869218236243562496\/Dx5W8vxP_normal.jpg",
      "id" : 126357484,
      "verified" : false
    }
  },
  "id" : 727636707445768192,
  "created_at" : "2016-05-03 23:11:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727634205576974336",
  "text" : "Angry dad shows up #RuinPromIn4Words",
  "id" : 727634205576974336,
  "created_at" : "2016-05-03 23:01:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Autism Speaks",
      "screen_name" : "autismspeaks",
      "indices" : [ 3, 16 ],
      "id_str" : "14266331",
      "id" : 14266331
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Autism",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "TeacherAppreciationDay",
      "indices" : [ 114, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/0P66KjQl9Q",
      "expanded_url" : "https:\/\/shar.es\/1eYM7X",
      "display_url" : "shar.es\/1eYM7X"
    } ]
  },
  "geo" : { },
  "id_str" : "727633945920147460",
  "text" : "RT @autismspeaks: Special Ed Teacher Writes Poem About What #Autism Means to Him &gt;&gt; https:\/\/t.co\/0P66KjQl9Q #TeacherAppreciationDay https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/autismspeaks\/status\/727616424039075840\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/0gsI6iErVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkDP8eUUAA3R6Y.jpg",
        "id_str" : "727616387263254528",
        "id" : 727616387263254528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkDP8eUUAA3R6Y.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 685
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 685
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 685
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/0gsI6iErVE"
      } ],
      "hashtags" : [ {
        "text" : "Autism",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "TeacherAppreciationDay",
        "indices" : [ 96, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/0P66KjQl9Q",
        "expanded_url" : "https:\/\/shar.es\/1eYM7X",
        "display_url" : "shar.es\/1eYM7X"
      } ]
    },
    "geo" : { },
    "id_str" : "727616424039075840",
    "text" : "Special Ed Teacher Writes Poem About What #Autism Means to Him &gt;&gt; https:\/\/t.co\/0P66KjQl9Q #TeacherAppreciationDay https:\/\/t.co\/0gsI6iErVE",
    "id" : 727616424039075840,
    "created_at" : "2016-05-03 21:50:48 +0000",
    "user" : {
      "name" : "Autism Speaks",
      "screen_name" : "autismspeaks",
      "protected" : false,
      "id_str" : "14266331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879727903621210112\/pxvUN9BI_normal.jpg",
      "id" : 14266331,
      "verified" : true
    }
  },
  "id" : 727633945920147460,
  "created_at" : "2016-05-03 23:00:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Darryn Zewalk",
      "screen_name" : "darrynzewalk",
      "indices" : [ 3, 16 ],
      "id_str" : "30561781",
      "id" : 30561781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverBetter",
      "indices" : [ 29, 41 ]
    }, {
      "text" : "God",
      "indices" : [ 60, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727633039602425856",
  "text" : "RT @darrynzewalk: Nothing is #NeverBetter than knowing that #God loves you...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeverBetter",
        "indices" : [ 11, 23 ]
      }, {
        "text" : "God",
        "indices" : [ 42, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727600181382778881",
    "text" : "Nothing is #NeverBetter than knowing that #God loves you...",
    "id" : 727600181382778881,
    "created_at" : "2016-05-03 20:46:16 +0000",
    "user" : {
      "name" : "J. Darryn Zewalk",
      "screen_name" : "darrynzewalk",
      "protected" : false,
      "id_str" : "30561781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000398050163\/ab6d7ee62fa9a84d7082bd8dc4d292fe_normal.jpeg",
      "id" : 30561781,
      "verified" : false
    }
  },
  "id" : 727633039602425856,
  "created_at" : "2016-05-03 22:56:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632761264193536",
  "text" : "RT @supersirsunset1: Let's just be friends.... #RuinPromIn4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RuinPromIn4Words",
        "indices" : [ 26, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727628889921564672",
    "text" : "Let's just be friends.... #RuinPromIn4Words",
    "id" : 727628889921564672,
    "created_at" : "2016-05-03 22:40:20 +0000",
    "user" : {
      "name" : "Ben",
      "screen_name" : "Canhistoryrules",
      "protected" : false,
      "id_str" : "506943829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895039664071090178\/lKZzfj1R_normal.jpg",
      "id" : 506943829,
      "verified" : false
    }
  },
  "id" : 727632761264193536,
  "created_at" : "2016-05-03 22:55:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lovell",
      "screen_name" : "__RedComet__",
      "indices" : [ 3, 16 ],
      "id_str" : "1093608007",
      "id" : 1093608007
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727632511883464705",
  "text" : "RT @__RedComet__: Let's go as friends #RuinPromIn4Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RuinPromIn4Words",
        "indices" : [ 20, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727629309679034368",
    "text" : "Let's go as friends #RuinPromIn4Words",
    "id" : 727629309679034368,
    "created_at" : "2016-05-03 22:42:00 +0000",
    "user" : {
      "name" : "Lovell",
      "screen_name" : "__RedComet__",
      "protected" : false,
      "id_str" : "1093608007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/935628964877553664\/fUK-JeER_normal.jpg",
      "id" : 1093608007,
      "verified" : false
    }
  },
  "id" : 727632511883464705,
  "created_at" : "2016-05-03 22:54:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 25, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727631589342064641",
  "text" : "Less productive time use #RuinPromIn4Words",
  "id" : 727631589342064641,
  "created_at" : "2016-05-03 22:51:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727631514230505472",
  "text" : "She will dump you #RuinPromIn4Words",
  "id" : 727631514230505472,
  "created_at" : "2016-05-03 22:50:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Berens",
      "screen_name" : "CharlieBerens",
      "indices" : [ 3, 17 ],
      "id_str" : "15896129",
      "id" : 15896129
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CharlieBerens\/status\/727625244341469184\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/fPbIJaHsMv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkLTauU4AAgrAR.jpg",
      "id_str" : "727625243016093696",
      "id" : 727625243016093696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkLTauU4AAgrAR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 930
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fPbIJaHsMv"
    } ],
    "hashtags" : [ {
      "text" : "RuinPromIn4Words",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727631251323146241",
  "text" : "RT @CharlieBerens: #RuinPromIn4Words The limo is here. https:\/\/t.co\/fPbIJaHsMv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CharlieBerens\/status\/727625244341469184\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/fPbIJaHsMv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkLTauU4AAgrAR.jpg",
        "id_str" : "727625243016093696",
        "id" : 727625243016093696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkLTauU4AAgrAR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 930
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fPbIJaHsMv"
      } ],
      "hashtags" : [ {
        "text" : "RuinPromIn4Words",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727625244341469184",
    "text" : "#RuinPromIn4Words The limo is here. https:\/\/t.co\/fPbIJaHsMv",
    "id" : 727625244341469184,
    "created_at" : "2016-05-03 22:25:51 +0000",
    "user" : {
      "name" : "Charlie Berens",
      "screen_name" : "CharlieBerens",
      "protected" : false,
      "id_str" : "15896129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771168635830231042\/AGHbvGvs_normal.jpg",
      "id" : 15896129,
      "verified" : true
    }
  },
  "id" : 727631251323146241,
  "created_at" : "2016-05-03 22:49:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wajahat Ali",
      "screen_name" : "WajahatAli",
      "indices" : [ 3, 14 ],
      "id_str" : "21733692",
      "id" : 21733692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruinpromin4words",
      "indices" : [ 36, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727631204204326912",
  "text" : "RT @WajahatAli: \"I am your cousin.\" #ruinpromin4words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ruinpromin4words",
        "indices" : [ 20, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727625670185127938",
    "text" : "\"I am your cousin.\" #ruinpromin4words",
    "id" : 727625670185127938,
    "created_at" : "2016-05-03 22:27:33 +0000",
    "user" : {
      "name" : "Wajahat Ali",
      "screen_name" : "WajahatAli",
      "protected" : false,
      "id_str" : "21733692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/859503016940097537\/uaa6krZQ_normal.jpg",
      "id" : 21733692,
      "verified" : true
    }
  },
  "id" : 727631204204326912,
  "created_at" : "2016-05-03 22:49:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FootyManagerTV",
      "screen_name" : "FootyManagerTV",
      "indices" : [ 0, 15 ],
      "id_str" : "147948174",
      "id" : 147948174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727623089605877760",
  "geo" : { },
  "id_str" : "727630655543230464",
  "in_reply_to_user_id" : 147948174,
  "text" : "@FootyManagerTV Mod or mode?",
  "id" : 727630655543230464,
  "in_reply_to_status_id" : 727623089605877760,
  "created_at" : "2016-05-03 22:47:21 +0000",
  "in_reply_to_screen_name" : "FootyManagerTV",
  "in_reply_to_user_id_str" : "147948174",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FootyManagerTV",
      "screen_name" : "FootyManagerTV",
      "indices" : [ 3, 18 ],
      "id_str" : "147948174",
      "id" : 147948174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727630549091799040",
  "text" : "RT @FootyManagerTV: if EA continue to be stubborn and not really improve the mode, I think us content creators have to take initiative and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727623089605877760",
    "text" : "if EA continue to be stubborn and not really improve the mode, I think us content creators have to take initiative and create unique series'",
    "id" : 727623089605877760,
    "created_at" : "2016-05-03 22:17:17 +0000",
    "user" : {
      "name" : "FootyManagerTV",
      "screen_name" : "FootyManagerTV",
      "protected" : false,
      "id_str" : "147948174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956668581378326528\/00JGnTdF_normal.jpg",
      "id" : 147948174,
      "verified" : false
    }
  },
  "id" : 727630549091799040,
  "created_at" : "2016-05-03 22:46:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "indices" : [ 3, 19 ],
      "id_str" : "14550939",
      "id" : 14550939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Love",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "RT",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/5kZJCG9LI4",
      "expanded_url" : "http:\/\/bit.ly\/24ou6Ri",
      "display_url" : "bit.ly\/24ou6Ri"
    } ]
  },
  "geo" : { },
  "id_str" : "727629586570354688",
  "text" : "RT @lawrence_author: Child Piano Prodigy Proves That Autism Is Not a Roadblock (WATCH) https:\/\/t.co\/5kZJCG9LI4 #Love #RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Love",
        "indices" : [ 90, 95 ]
      }, {
        "text" : "RT",
        "indices" : [ 96, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/5kZJCG9LI4",
        "expanded_url" : "http:\/\/bit.ly\/24ou6Ri",
        "display_url" : "bit.ly\/24ou6Ri"
      } ]
    },
    "geo" : { },
    "id_str" : "727626499616997376",
    "text" : "Child Piano Prodigy Proves That Autism Is Not a Roadblock (WATCH) https:\/\/t.co\/5kZJCG9LI4 #Love #RT",
    "id" : 727626499616997376,
    "created_at" : "2016-05-03 22:30:50 +0000",
    "user" : {
      "name" : "Lawrence D. Elliott",
      "screen_name" : "lawrence_author",
      "protected" : false,
      "id_str" : "14550939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878189064393863168\/0QsTPIPw_normal.jpg",
      "id" : 14550939,
      "verified" : false
    }
  },
  "id" : 727629586570354688,
  "created_at" : "2016-05-03 22:43:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "indices" : [ 0, 9 ],
      "id_str" : "96013710",
      "id" : 96013710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727620527448305664",
  "geo" : { },
  "id_str" : "727629315920252929",
  "in_reply_to_user_id" : 96013710,
  "text" : "@FactSoup @BONNIELYNN2015 Me shedding tears, what!!!",
  "id" : 727629315920252929,
  "in_reply_to_status_id" : 727620527448305664,
  "created_at" : "2016-05-03 22:42:02 +0000",
  "in_reply_to_screen_name" : "FactSoup",
  "in_reply_to_user_id_str" : "96013710",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "indices" : [ 3, 12 ],
      "id_str" : "96013710",
      "id" : 96013710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727629223146434560",
  "text" : "RT @FactSoup: Sometimes you just got to be strong. It may hurt and you may shed a few tears, but everything's going to be alright.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727620527448305664",
    "text" : "Sometimes you just got to be strong. It may hurt and you may shed a few tears, but everything's going to be alright.",
    "id" : 727620527448305664,
    "created_at" : "2016-05-03 22:07:06 +0000",
    "user" : {
      "name" : "Amazing Facts",
      "screen_name" : "FactSoup",
      "protected" : false,
      "id_str" : "96013710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956327042554896384\/xHimnR1u_normal.jpg",
      "id" : 96013710,
      "verified" : false
    }
  },
  "id" : 727629223146434560,
  "created_at" : "2016-05-03 22:41:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Relatable Poems",
      "screen_name" : "RelatabIePoems",
      "indices" : [ 0, 15 ],
      "id_str" : "592848274",
      "id" : 592848274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727626339834945536",
  "geo" : { },
  "id_str" : "727629174727450624",
  "in_reply_to_user_id" : 592848274,
  "text" : "@RelatabIePoems Well.....",
  "id" : 727629174727450624,
  "in_reply_to_status_id" : 727626339834945536,
  "created_at" : "2016-05-03 22:41:28 +0000",
  "in_reply_to_screen_name" : "RelatabIePoems",
  "in_reply_to_user_id_str" : "592848274",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/727471189602504705\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/nsEAVU6BOn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chh_KY5W0AAZWpP.jpg",
      "id_str" : "727471156278775808",
      "id" : 727471156278775808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chh_KY5W0AAZWpP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/nsEAVU6BOn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727471189602504705",
  "text" : "Went to Romeo Family Restaurant: 3.8\/5 stars for breakfast, 5\/5 stars for service https:\/\/t.co\/nsEAVU6BOn",
  "id" : 727471189602504705,
  "created_at" : "2016-05-03 12:13:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 3, 16 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727470953278656512",
  "text" : "RT @LinkedInHelp: @gamer456148 Thanks for the feedback on this. We'll definitely forward it along. -jlk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "726956792874340352",
    "geo" : { },
    "id_str" : "727061389865525248",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Thanks for the feedback on this. We'll definitely forward it along. -jlk",
    "id" : 727061389865525248,
    "in_reply_to_status_id" : 726956792874340352,
    "created_at" : "2016-05-02 09:05:18 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "protected" : false,
      "id_str" : "252792134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/991135365988667392\/JXDDdlqf_normal.jpg",
      "id" : 252792134,
      "verified" : true
    }
  },
  "id" : 727470953278656512,
  "created_at" : "2016-05-03 12:12:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726956899241873409",
  "text" : "RT @JustOneAsian: Summer starts next month and if that doesn\u2019t make you happy then idk what will",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726955893900767232",
    "text" : "Summer starts next month and if that doesn\u2019t make you happy then idk what will",
    "id" : 726955893900767232,
    "created_at" : "2016-05-02 02:06:05 +0000",
    "user" : {
      "name" : "Tommy \u30C4",
      "screen_name" : "Asian_Made",
      "protected" : false,
      "id_str" : "263330949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/986796980469891072\/wfXqA8xu_normal.jpg",
      "id" : 263330949,
      "verified" : false
    }
  },
  "id" : 726956899241873409,
  "created_at" : "2016-05-02 02:10:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 14, 23 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726956641627701248",
  "geo" : { },
  "id_str" : "726956792874340352",
  "in_reply_to_user_id" : 210979938,
  "text" : "@LinkedInHelp @LinkedIn Plus it could be more colored in pattern and UX",
  "id" : 726956792874340352,
  "in_reply_to_status_id" : 726956641627701248,
  "created_at" : "2016-05-02 02:09:40 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn Help",
      "screen_name" : "LinkedInHelp",
      "indices" : [ 0, 13 ],
      "id_str" : "252792134",
      "id" : 252792134
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 14, 23 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726956641627701248",
  "in_reply_to_user_id" : 252792134,
  "text" : "@LinkedInHelp @Linkedin When are you guys planning on improving UI for the desktop site, the tabs should be expandable to minimize scrolling",
  "id" : 726956641627701248,
  "created_at" : "2016-05-02 02:09:04 +0000",
  "in_reply_to_screen_name" : "LinkedInHelp",
  "in_reply_to_user_id_str" : "252792134",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]