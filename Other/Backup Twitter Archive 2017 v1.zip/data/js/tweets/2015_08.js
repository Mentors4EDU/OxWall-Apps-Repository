Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 15, 27 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/638377038559215621\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/gA0kQLmYIS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNv4iMIWUAAnQLM.jpg",
      "id_str" : "638377038458540032",
      "id" : 638377038458540032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNv4iMIWUAAnQLM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gA0kQLmYIS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638377038559215621",
  "text" : "Video games :) @BestGamezUp http:\/\/t.co\/gA0kQLmYIS",
  "id" : 638377038559215621,
  "created_at" : "2015-08-31 15:45:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/638376922129526784\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/4Fd8GsYm7C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNv4bagWEAA2HnH.jpg",
      "id_str" : "638376922058199040",
      "id" : 638376922058199040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNv4bagWEAA2HnH.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4Fd8GsYm7C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638376922129526784",
  "text" : "That annoyance you get when someone doesn't put the sauce on the side http:\/\/t.co\/4Fd8GsYm7C",
  "id" : 638376922129526784,
  "created_at" : "2015-08-31 15:44:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/638376708090032128\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/FlquyRvNfC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNv4O88WsAAnPKr.jpg",
      "id_str" : "638376707964186624",
      "id" : 638376707964186624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNv4O88WsAAnPKr.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FlquyRvNfC"
    } ],
    "hashtags" : [ {
      "text" : "Knapps",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638376708090032128",
  "text" : "Donuts after college #Knapps http:\/\/t.co\/FlquyRvNfC",
  "id" : 638376708090032128,
  "created_at" : "2015-08-31 15:44:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coptic",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638093044814888961",
  "text" : "I think I just met a bishop today, then I met up with my mom to go to a farmer's market called Fresh Thyme. It was all together nice #Coptic",
  "id" : 638093044814888961,
  "created_at" : "2015-08-30 20:56:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/637753159553810432\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/04qKa64rRi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnBHp1XAAAnFp_.jpg",
      "id_str" : "637753159482540032",
      "id" : 637753159482540032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnBHp1XAAAnFp_.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/04qKa64rRi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637753159553810432",
  "text" : "Plus my little sis was there &amp; now I am going to church, better day then the mess that happened yesterday. Thanks God http:\/\/t.co\/04qKa64rRi",
  "id" : 637753159553810432,
  "created_at" : "2015-08-29 22:26:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/637752882981437440\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8kRRoGjZcN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnA3jZW8AA-HAv.jpg",
      "id_str" : "637752882876575744",
      "id" : 637752882876575744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnA3jZW8AA-HAv.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/8kRRoGjZcN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637752882981437440",
  "text" : "My mom took me to Edamame Sushi for Sushi as well as fried tampora, then we had ice cream, then we seen the movie Max http:\/\/t.co\/8kRRoGjZcN",
  "id" : 637752882981437440,
  "created_at" : "2015-08-29 22:25:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/637359614435176448\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zZj8uSJLuN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNhbMT-W8AA-cyC.jpg",
      "id_str" : "637359614351306752",
      "id" : 637359614351306752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNhbMT-W8AA-cyC.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zZj8uSJLuN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637359614435176448",
  "text" : "Had a wonderful day tell this happened by someone on the rode, thanks God we were safe http:\/\/t.co\/zZj8uSJLuN",
  "id" : 637359614435176448,
  "created_at" : "2015-08-28 20:22:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B05\uFE0F Her Vibes \uD83D\uDC4C\uD83C\uDFFE",
      "screen_name" : "SheGorgeous_BTW",
      "indices" : [ 0, 16 ],
      "id_str" : "201980394",
      "id" : 201980394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636522532720504832",
  "geo" : { },
  "id_str" : "637270539883687937",
  "in_reply_to_user_id" : 201980394,
  "text" : "@SheGorgeous_BTW \"Fancy on us\", lol",
  "id" : 637270539883687937,
  "in_reply_to_status_id" : 636522532720504832,
  "created_at" : "2015-08-28 14:28:31 +0000",
  "in_reply_to_screen_name" : "SheGorgeous_BTW",
  "in_reply_to_user_id_str" : "201980394",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 3, 12 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oaklandu\/status\/636212595993800704\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/opNVKB7Daa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNRH_CTUsAAWrAn.png",
      "id_str" : "636212595641331712",
      "id" : 636212595641331712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNRH_CTUsAAWrAn.png",
      "sizes" : [ {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 842,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/opNVKB7Daa"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637270224660766720",
  "text" : "RT @oaklandu: This is what our web developers do on their lunch hour. #ThisIsOU http:\/\/t.co\/opNVKB7Daa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oaklandu\/status\/636212595993800704\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/opNVKB7Daa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNRH_CTUsAAWrAn.png",
        "id_str" : "636212595641331712",
        "id" : 636212595641331712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNRH_CTUsAAWrAn.png",
        "sizes" : [ {
          "h" : 713,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 1210
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/opNVKB7Daa"
      } ],
      "hashtags" : [ {
        "text" : "ThisIsOU",
        "indices" : [ 56, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636212595993800704",
    "text" : "This is what our web developers do on their lunch hour. #ThisIsOU http:\/\/t.co\/opNVKB7Daa",
    "id" : 636212595993800704,
    "created_at" : "2015-08-25 16:24:37 +0000",
    "user" : {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "protected" : false,
      "id_str" : "17468189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474898532759912448\/Dxj_fOZo_normal.jpeg",
      "id" : 17468189,
      "verified" : false
    }
  },
  "id" : 637270224660766720,
  "created_at" : "2015-08-28 14:27:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637269714809561088",
  "text" : "Would you mind taking a picture next to these cute girls holding a home decor coupon, I guess not???",
  "id" : 637269714809561088,
  "created_at" : "2015-08-28 14:25:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/637265573001474048\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/updUqp11Er",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNgFqVQWgAA-sGf.jpg",
      "id_str" : "637265572091297792",
      "id" : 637265572091297792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNgFqVQWgAA-sGf.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/updUqp11Er"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637265573001474048",
  "text" : "This plus the Funyons I had, might give me heartburn http:\/\/t.co\/updUqp11Er",
  "id" : 637265573001474048,
  "created_at" : "2015-08-28 14:08:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "636926115148263424",
  "geo" : { },
  "id_str" : "637231730705977345",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz Not just defund them but put a criminal investigation on this so called \"organization\".",
  "id" : 637231730705977345,
  "in_reply_to_status_id" : 636926115148263424,
  "created_at" : "2015-08-28 11:54:18 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/0Sls2l3b6h",
      "expanded_url" : "http:\/\/www.stoptheirandeal.com",
      "display_url" : "stoptheirandeal.com"
    } ]
  },
  "geo" : { },
  "id_str" : "637231521917730816",
  "text" : "RT @tedcruz: Glad @realdonaldtrump accepted my invitation to rally in DC to stop the catastrophic #IranDeal. http:\/\/t.co\/0Sls2l3b6h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 5, 21 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/0Sls2l3b6h",
        "expanded_url" : "http:\/\/www.stoptheirandeal.com",
        "display_url" : "stoptheirandeal.com"
      } ]
    },
    "geo" : { },
    "id_str" : "636979911299760130",
    "text" : "Glad @realdonaldtrump accepted my invitation to rally in DC to stop the catastrophic #IranDeal. http:\/\/t.co\/0Sls2l3b6h",
    "id" : 636979911299760130,
    "created_at" : "2015-08-27 19:13:40 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 637231521917730816,
  "created_at" : "2015-08-28 11:53:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    }, {
      "name" : "Gov. Greg Abbott",
      "screen_name" : "GovAbbott",
      "indices" : [ 26, 36 ],
      "id_str" : "19291441",
      "id" : 19291441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/UG6PCmmgG4",
      "expanded_url" : "https:\/\/twitter.com\/GovAbbott\/status\/636586272434184192",
      "display_url" : "twitter.com\/GovAbbott\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "637231328136593408",
  "text" : "RT @SenTedCruz: Thank you @govabbott for honoring the sacrifice and memory of these two great #Texas heroes https:\/\/t.co\/UG6PCmmgG4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gov. Greg Abbott",
        "screen_name" : "GovAbbott",
        "indices" : [ 10, 20 ],
        "id_str" : "19291441",
        "id" : 19291441
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 78, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/UG6PCmmgG4",
        "expanded_url" : "https:\/\/twitter.com\/GovAbbott\/status\/636586272434184192",
        "display_url" : "twitter.com\/GovAbbott\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636939247908483072",
    "text" : "Thank you @govabbott for honoring the sacrifice and memory of these two great #Texas heroes https:\/\/t.co\/UG6PCmmgG4",
    "id" : 636939247908483072,
    "created_at" : "2015-08-27 16:32:05 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 637231328136593408,
  "created_at" : "2015-08-28 11:52:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxOaklandU",
      "screen_name" : "TEDxOaklandU",
      "indices" : [ 0, 13 ],
      "id_str" : "2294678792",
      "id" : 2294678792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/Pw4ckJJZBo",
      "expanded_url" : "https:\/\/www.createspace.com\/5704265",
      "display_url" : "createspace.com\/5704265"
    } ]
  },
  "geo" : { },
  "id_str" : "637231123815354368",
  "in_reply_to_user_id" : 2294678792,
  "text" : "@TEDxOaklandU OU Grizzly publishes this cool book: https:\/\/t.co\/Pw4ckJJZBo",
  "id" : 637231123815354368,
  "created_at" : "2015-08-28 11:51:53 +0000",
  "in_reply_to_screen_name" : "TEDxOaklandU",
  "in_reply_to_user_id_str" : "2294678792",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/636612147825479680\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/lfxnSIJ6pW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNWzYB6WUAAZtRd.jpg",
      "id_str" : "636612147754192896",
      "id" : 636612147754192896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNWzYB6WUAAZtRd.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lfxnSIJ6pW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636612147825479680",
  "text" : "Shelby's Donuts 3.34\/5 stars http:\/\/t.co\/lfxnSIJ6pW",
  "id" : 636612147825479680,
  "created_at" : "2015-08-26 18:52:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636184379643920384",
  "text" : "Just tried sweet potato chips, man that was good :P",
  "id" : 636184379643920384,
  "created_at" : "2015-08-25 14:32:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    }, {
      "name" : "Katy Tigers",
      "screen_name" : "KatyHighSchool",
      "indices" : [ 62, 77 ],
      "id_str" : "281736496",
      "id" : 281736496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636181908079136768",
  "text" : "RT @SenTedCruz: Proud of Petty Officer Kimbrough, graduate of @KatyHighSchool, who was involved in the rescue of two F\/A-18 aviators. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katy Tigers",
        "screen_name" : "KatyHighSchool",
        "indices" : [ 46, 61 ],
        "id_str" : "281736496",
        "id" : 281736496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/We7slsHGVO",
        "expanded_url" : "http:\/\/bit.ly\/1KhFC1d",
        "display_url" : "bit.ly\/1KhFC1d"
      } ]
    },
    "geo" : { },
    "id_str" : "631497578102812672",
    "text" : "Proud of Petty Officer Kimbrough, graduate of @KatyHighSchool, who was involved in the rescue of two F\/A-18 aviators. http:\/\/t.co\/We7slsHGVO",
    "id" : 631497578102812672,
    "created_at" : "2015-08-12 16:08:49 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 636181908079136768,
  "created_at" : "2015-08-25 14:22:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 0, 15 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635538261092384768",
  "geo" : { },
  "id_str" : "636181627958390784",
  "in_reply_to_user_id" : 2687742392,
  "text" : "@VigilantChrist That's disturbing",
  "id" : 636181627958390784,
  "in_reply_to_status_id" : 635538261092384768,
  "created_at" : "2015-08-25 14:21:34 +0000",
  "in_reply_to_screen_name" : "VigilantChrist",
  "in_reply_to_user_id_str" : "2687742392",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "635455222794424322",
  "geo" : { },
  "id_str" : "636181197903777792",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice That is just sad",
  "id" : 636181197903777792,
  "in_reply_to_status_id" : 635455222794424322,
  "created_at" : "2015-08-25 14:19:51 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 3, 12 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/uRypR5sgig",
      "expanded_url" : "https:\/\/youtu.be\/bYhTFz_SGw0",
      "display_url" : "youtu.be\/bYhTFz_SGw0"
    } ]
  },
  "geo" : { },
  "id_str" : "636181157185495040",
  "text" : "RT @MarkDice: People Choose Free Candy Bar over Free 10 oz Silver Bar (Worth $150) in Experiment  https:\/\/t.co\/uRypR5sgig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/uRypR5sgig",
        "expanded_url" : "https:\/\/youtu.be\/bYhTFz_SGw0",
        "display_url" : "youtu.be\/bYhTFz_SGw0"
      } ]
    },
    "geo" : { },
    "id_str" : "635455222794424322",
    "text" : "People Choose Free Candy Bar over Free 10 oz Silver Bar (Worth $150) in Experiment  https:\/\/t.co\/uRypR5sgig",
    "id" : 635455222794424322,
    "created_at" : "2015-08-23 14:15:05 +0000",
    "user" : {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "protected" : false,
      "id_str" : "35039490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670269162241966080\/Hu4j1LKq_normal.png",
      "id" : 35039490,
      "verified" : true
    }
  },
  "id" : 636181157185495040,
  "created_at" : "2015-08-25 14:19:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/636181044849471488\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/MT9ZwCZD48",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQrSXQWIAA0DNc.jpg",
      "id_str" : "636181041846296576",
      "id" : 636181041846296576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQrSXQWIAA0DNc.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MT9ZwCZD48"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636181044849471488",
  "text" : "$4.13 for four expresso shots, a big ripoff but what can you do? http:\/\/t.co\/MT9ZwCZD48",
  "id" : 636181044849471488,
  "created_at" : "2015-08-25 14:19:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635833474188996612",
  "text" : "To the nice blonde who said I look nice today, Rachel this is for you \uD83C\uDF6B #ThisIsOU",
  "id" : 635833474188996612,
  "created_at" : "2015-08-24 15:18:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635793411216424960",
  "text" : "We have something in common, we are both people, at least I thought so? Whereas people's humanity nowadays?",
  "id" : 635793411216424960,
  "created_at" : "2015-08-24 12:38:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635651582932185089",
  "text" : "I guess today was kinda fun, kinda stressful, and kinda exhausting, maybe a bit Quirky",
  "id" : 635651582932185089,
  "created_at" : "2015-08-24 03:15:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635651413348077568",
  "text" : "The Meijers Chicken Italian Sub, the Louie's pizza, the other two pizzas, and the Greek Salad I had today is gonna give me a hard time soon",
  "id" : 635651413348077568,
  "created_at" : "2015-08-24 03:14:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635530842333388800",
  "text" : "Even pizza from louie's and another place didn't make my mood better ;(",
  "id" : 635530842333388800,
  "created_at" : "2015-08-23 19:15:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634854954214268928",
  "text" : "God Bless our patriots",
  "id" : 634854954214268928,
  "created_at" : "2015-08-21 22:29:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Mattera",
      "screen_name" : "JasonMattera",
      "indices" : [ 3, 16 ],
      "id_str" : "15954472",
      "id" : 15954472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634854748429156352",
  "text" : "RT @JasonMattera: Who lied to Ellen Page and told her it was a good idea to try to debate Ted Cruz? lol lol lol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634842958152339456",
    "text" : "Who lied to Ellen Page and told her it was a good idea to try to debate Ted Cruz? lol lol lol",
    "id" : 634842958152339456,
    "created_at" : "2015-08-21 21:42:10 +0000",
    "user" : {
      "name" : "Jason Mattera",
      "screen_name" : "JasonMattera",
      "protected" : false,
      "id_str" : "15954472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595652169136807937\/oDeiYo0z_normal.jpg",
      "id" : 15954472,
      "verified" : true
    }
  },
  "id" : 634854748429156352,
  "created_at" : "2015-08-21 22:29:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 28, 35 ],
      "id_str" : "20793816",
      "id" : 20793816
    }, {
      "name" : "San Marcos",
      "screen_name" : "CityofSanMarcos",
      "indices" : [ 109, 125 ],
      "id_str" : "17809043",
      "id" : 17809043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634854709682171904",
  "text" : "RT @SenTedCruz: Great news! @Amazon plans to open new distribution facility in #Texas, bringing 1000 jobs to @CityofSanMarcos  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 12, 19 ],
        "id_str" : "20793816",
        "id" : 20793816
      }, {
        "name" : "San Marcos",
        "screen_name" : "CityofSanMarcos",
        "indices" : [ 93, 109 ],
        "id_str" : "17809043",
        "id" : 17809043
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 63, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/T242Y5z1Sc",
        "expanded_url" : "http:\/\/bit.ly\/1UXVuNY",
        "display_url" : "bit.ly\/1UXVuNY"
      } ]
    },
    "geo" : { },
    "id_str" : "634797824559960064",
    "text" : "Great news! @Amazon plans to open new distribution facility in #Texas, bringing 1000 jobs to @CityofSanMarcos  http:\/\/t.co\/T242Y5z1Sc",
    "id" : 634797824559960064,
    "created_at" : "2015-08-21 18:42:50 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 634854709682171904,
  "created_at" : "2015-08-21 22:28:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634854592518451200",
  "text" : "True bravery is doing something courageous, and rarely talking about it",
  "id" : 634854592518451200,
  "created_at" : "2015-08-21 22:28:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "indices" : [ 0, 5 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634836802705080320",
  "in_reply_to_user_id" : 13393052,
  "text" : "@ACLU Freedom can't protect itself, really? How do you define freedom?",
  "id" : 634836802705080320,
  "created_at" : "2015-08-21 21:17:43 +0000",
  "in_reply_to_screen_name" : "ACLU",
  "in_reply_to_user_id_str" : "13393052",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634835261503881217",
  "text" : "Since Al-Amoudi founded the ISB and AMC, both of these organizations need to be shut down. Why allow an organization by a traitor to exist?",
  "id" : 634835261503881217,
  "created_at" : "2015-08-21 21:11:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "troops",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634832875322368000",
  "text" : "We need to support our #troops and put an end to terrorism",
  "id" : 634832875322368000,
  "created_at" : "2015-08-21 21:02:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FBI Boston",
      "screen_name" : "FBIBoston",
      "indices" : [ 128, 138 ],
      "id_str" : "351157948",
      "id" : 351157948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/RXVZoNLhBZ",
      "expanded_url" : "https:\/\/goo.gl\/7hfGfo",
      "display_url" : "goo.gl\/7hfGfo"
    } ]
  },
  "geo" : { },
  "id_str" : "634830412490145792",
  "text" : "The Islamic Society of Boston Cultural Center is a terrorist organization, and need to be investigated. https:\/\/t.co\/RXVZoNLhBZ @FBIBoston",
  "id" : 634830412490145792,
  "created_at" : "2015-08-21 20:52:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634727906678145024",
  "text" : "Sometimes true patriotism may be the opposite of what your country is currently following or fighting for",
  "id" : 634727906678145024,
  "created_at" : "2015-08-21 14:05:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634727574887792640",
  "text" : "Follow in the path of light rather then walking blindly into darkness expecting not to get lost",
  "id" : 634727574887792640,
  "created_at" : "2015-08-21 14:03:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634727375528263688",
  "text" : "Don't be a sheep following a wolf that will devour you at the end",
  "id" : 634727375528263688,
  "created_at" : "2015-08-21 14:02:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634727299951149056",
  "text" : "Don't let the world enslave you to the point it tears your own personal beliefs",
  "id" : 634727299951149056,
  "created_at" : "2015-08-21 14:02:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxOaklandU",
      "screen_name" : "TEDxOaklandU",
      "indices" : [ 0, 13 ],
      "id_str" : "2294678792",
      "id" : 2294678792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/I8FyTAZFfe",
      "expanded_url" : "http:\/\/vixra.org\/pdf\/1407.0112v1.pdf",
      "display_url" : "vixra.org\/pdf\/1407.0112v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634727126768349184",
  "in_reply_to_user_id" : 2294678792,
  "text" : "@TEDxOaklandU Some poetry that may inspire: http:\/\/t.co\/I8FyTAZFfe",
  "id" : 634727126768349184,
  "created_at" : "2015-08-21 14:01:54 +0000",
  "in_reply_to_screen_name" : "TEDxOaklandU",
  "in_reply_to_user_id_str" : "2294678792",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik \u2615\uFE0F",
      "screen_name" : "ijustine",
      "indices" : [ 3, 12 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634726698005590016",
  "text" : "RT @ijustine: Fist time flying drone outside... First time getting yelled at to not fly drone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634606861388394496",
    "text" : "Fist time flying drone outside... First time getting yelled at to not fly drone.",
    "id" : 634606861388394496,
    "created_at" : "2015-08-21 06:04:00 +0000",
    "user" : {
      "name" : "Justine Ezarik \u2615\uFE0F",
      "screen_name" : "ijustine",
      "protected" : false,
      "id_str" : "7846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823989703573573632\/ndieod1F_normal.jpg",
      "id" : 7846,
      "verified" : true
    }
  },
  "id" : 634726698005590016,
  "created_at" : "2015-08-21 14:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxOaklandU",
      "screen_name" : "TEDxOaklandU",
      "indices" : [ 0, 13 ],
      "id_str" : "2294678792",
      "id" : 2294678792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634450720742330369",
  "geo" : { },
  "id_str" : "634492692324597760",
  "in_reply_to_user_id" : 2294678792,
  "text" : "@TEDxOaklandU I applied, hopefully it isn't too late ;)",
  "id" : 634492692324597760,
  "in_reply_to_status_id" : 634450720742330369,
  "created_at" : "2015-08-20 22:30:20 +0000",
  "in_reply_to_screen_name" : "TEDxOaklandU",
  "in_reply_to_user_id_str" : "2294678792",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEDxOaklandU",
      "screen_name" : "TEDxOaklandU",
      "indices" : [ 0, 13 ],
      "id_str" : "2294678792",
      "id" : 2294678792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634445383192567808",
  "in_reply_to_user_id" : 2294678792,
  "text" : "@TEDxOaklandU If it isn't too late, maybe you can invite me to speak :)",
  "id" : 634445383192567808,
  "created_at" : "2015-08-20 19:22:21 +0000",
  "in_reply_to_screen_name" : "TEDxOaklandU",
  "in_reply_to_user_id_str" : "2294678792",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634432723864715265",
  "text" : "God bless me for all my times of troubles. Thanks God for every day I receive.",
  "id" : 634432723864715265,
  "created_at" : "2015-08-20 18:32:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "House Republicans",
      "screen_name" : "HouseGOP",
      "indices" : [ 3, 12 ],
      "id_str" : "15207668",
      "id" : 15207668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634432390698532864",
  "text" : "RT @HouseGOP: A historic day for the people of the U.S. and Cuba, but we still desire democracy and freedom for all.  https:\/\/t.co\/ranVkVpm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/ranVkVpmaK",
        "expanded_url" : "https:\/\/twitter.com\/GOPEspanol\/status\/632207038995656704",
        "display_url" : "twitter.com\/GOPEspanol\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632208085701017600",
    "text" : "A historic day for the people of the U.S. and Cuba, but we still desire democracy and freedom for all.  https:\/\/t.co\/ranVkVpmaK",
    "id" : 632208085701017600,
    "created_at" : "2015-08-14 15:12:08 +0000",
    "user" : {
      "name" : "House Republicans",
      "screen_name" : "HouseGOP",
      "protected" : false,
      "id_str" : "15207668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453650371626291202\/akETL2nV_normal.jpeg",
      "id" : 15207668,
      "verified" : true
    }
  },
  "id" : 634432390698532864,
  "created_at" : "2015-08-20 18:30:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634427490988130304",
  "geo" : { },
  "id_str" : "634432235123396608",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 mph",
  "id" : 634432235123396608,
  "in_reply_to_status_id" : 634427490988130304,
  "created_at" : "2015-08-20 18:30:06 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634430985061466113",
  "text" : "Don't get me wrong, lots of cops are good people, but some have an abuse of power.",
  "id" : 634430985061466113,
  "created_at" : "2015-08-20 18:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634427667190804480",
  "text" : "It gets better, he is making me pickup my car in couple days, seriously was he in a bad mood or something, nothing better to do?",
  "id" : 634427667190804480,
  "created_at" : "2015-08-20 18:11:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634427490988130304",
  "text" : "Cop pulls me over because he thought the energy drinks I had was beer, then he writes me a ticket for going over 5pm in the speed limit",
  "id" : 634427490988130304,
  "created_at" : "2015-08-20 18:11:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/634381879299440640\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/E3aCkItKei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM3G9UIWIAAs7aj.jpg",
      "id_str" : "634381879207141376",
      "id" : 634381879207141376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM3G9UIWIAAs7aj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E3aCkItKei"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634381879299440640",
  "text" : "They support troops, made in America and 2 for $3, so how can I resist? http:\/\/t.co\/E3aCkItKei",
  "id" : 634381879299440640,
  "created_at" : "2015-08-20 15:10:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634052884494090240",
  "text" : "People need to learn to suck it up or get along :&gt;)",
  "id" : 634052884494090240,
  "created_at" : "2015-08-19 17:22:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/634037599905148928\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/csWCz9jNTt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMyN1ngWEAA_SAk.jpg",
      "id_str" : "634037599829626880",
      "id" : 634037599829626880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMyN1ngWEAA_SAk.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/csWCz9jNTt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634037599905148928",
  "text" : "This is my kind of chocolate bar http:\/\/t.co\/csWCz9jNTt",
  "id" : 634037599905148928,
  "created_at" : "2015-08-19 16:21:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633742231065636864",
  "text" : "Here is a social experiment: Try telling people good afternoon, and most of them will say hi rather then good afternoon, at least in college",
  "id" : 633742231065636864,
  "created_at" : "2015-08-18 20:48:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633308831871709184",
  "text" : "Man, today was tiring indeed, but that's because it is a Monday",
  "id" : 633308831871709184,
  "created_at" : "2015-08-17 16:06:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/633308619405160448\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ZXv58h5hM8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMn21XgWUAAC6Yb.jpg",
      "id_str" : "633308619325460480",
      "id" : 633308619325460480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMn21XgWUAAC6Yb.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ZXv58h5hM8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633308619405160448",
  "text" : "Ever notice how junk\/comfort food makes your day less crappy? I had a really crappy day, so I would know http:\/\/t.co\/ZXv58h5hM8",
  "id" : 633308619405160448,
  "created_at" : "2015-08-17 16:05:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/633308376378789888\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/NTwdJ8VqAS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMn2nOLWsAE3ePw.jpg",
      "id_str" : "633308376303316993",
      "id" : 633308376303316993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMn2nOLWsAE3ePw.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/NTwdJ8VqAS"
    } ],
    "hashtags" : [ {
      "text" : "Donuts",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "Knapps",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633308376378789888",
  "text" : "#Donuts make your days better #Knapps http:\/\/t.co\/NTwdJ8VqAS",
  "id" : 633308376378789888,
  "created_at" : "2015-08-17 16:04:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/633234167870963713\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/zOlC9oIHQV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMmzHt9W8AEGWIx.jpg",
      "id_str" : "633234167799672833",
      "id" : 633234167799672833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMmzHt9W8AEGWIx.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zOlC9oIHQV"
    } ],
    "hashtags" : [ {
      "text" : "coffee",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633234167870963713",
  "text" : "Look how small this can is #coffee http:\/\/t.co\/zOlC9oIHQV",
  "id" : 633234167870963713,
  "created_at" : "2015-08-17 11:09:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631999722182606848",
  "text" : "RT @DavidLimbaugh: It\u2019s one thing for a Clinton already in office to defy conviction on impeachment charges; it\u2019s another for one to avoid \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631864533565460480",
    "text" : "It\u2019s one thing for a Clinton already in office to defy conviction on impeachment charges; it\u2019s another for one to avoid a primary derailing",
    "id" : 631864533565460480,
    "created_at" : "2015-08-13 16:26:58 +0000",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 631999722182606848,
  "created_at" : "2015-08-14 01:24:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631999546298646528",
  "text" : "RT @DavidLimbaugh: Maybe the difference between socialists and Dems is that Dems are also necessarily horrendous on foreign policy and nati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631924418692972544",
    "text" : "Maybe the difference between socialists and Dems is that Dems are also necessarily horrendous on foreign policy and national security. LOLOL",
    "id" : 631924418692972544,
    "created_at" : "2015-08-13 20:24:56 +0000",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 631999546298646528,
  "created_at" : "2015-08-14 01:23:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 31, 46 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/CzHqxgFAoP",
      "expanded_url" : "http:\/\/goo.gl\/X5AA0M",
      "display_url" : "goo.gl\/X5AA0M"
    } ]
  },
  "geo" : { },
  "id_str" : "631999353264152576",
  "text" : "I have an article I would like @RichardDawkins to read: http:\/\/t.co\/CzHqxgFAoP",
  "id" : 631999353264152576,
  "created_at" : "2015-08-14 01:22:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "ThisIsOU",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631826030785724416",
  "text" : "Just helped some farmers #USA #ThisIsOU",
  "id" : 631826030785724416,
  "created_at" : "2015-08-13 13:53:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631428668460507136",
  "text" : "Lots of the trends on twitter makes me just wonder, why?",
  "id" : 631428668460507136,
  "created_at" : "2015-08-12 11:35:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pinker",
      "screen_name" : "sapinker",
      "indices" : [ 0, 9 ],
      "id_str" : "107225267",
      "id" : 107225267
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 10, 24 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631428125335928832",
  "in_reply_to_user_id" : 107225267,
  "text" : "@sapinker @BernieSanders Be prepared for a challenge on your points of view, they are filled with self-contradictions &amp; illogical fallacies",
  "id" : 631428125335928832,
  "created_at" : "2015-08-12 11:32:51 +0000",
  "in_reply_to_screen_name" : "sapinker",
  "in_reply_to_user_id_str" : "107225267",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631238714362998784",
  "text" : "I like holding the door for a lady or giving her my jacket when it gets chilly, how is that masculine bias? What is wrong with society?",
  "id" : 631238714362998784,
  "created_at" : "2015-08-11 23:00:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/631238421525037056\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/MRtUbNZw4j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMKb_7oUwAA4AjZ.jpg",
      "id_str" : "631238420426178560",
      "id" : 631238420426178560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMKb_7oUwAA4AjZ.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MRtUbNZw4j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631238421525037056",
  "text" : "Woman need to stop thinking everything is sexist; Seriously it is sexist to be a gentleman to woman? http:\/\/t.co\/MRtUbNZw4j",
  "id" : 631238421525037056,
  "created_at" : "2015-08-11 22:59:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631099101539512320",
  "text" : "Just met someone named Andriana, what a nice name :)",
  "id" : 631099101539512320,
  "created_at" : "2015-08-11 13:45:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631068893734375424",
  "text" : "My day is off to a normal start: Hard work and greeting people \uD83D\uDE10",
  "id" : 631068893734375424,
  "created_at" : "2015-08-11 11:45:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630774030157656064",
  "text" : "In college I may either be called the junkie \uD83C\uDF5F or the greeter",
  "id" : 630774030157656064,
  "created_at" : "2015-08-10 16:13:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dolph Ziggler",
      "screen_name" : "HEELZiggler",
      "indices" : [ 50, 62 ],
      "id_str" : "105251590",
      "id" : 105251590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630567777812770816",
  "text" : "I always wanted to play Rock, Paper, Sissors with @HEELZiggler I don't know why, seems like a normal thing for a bucket list :P",
  "id" : 630567777812770816,
  "created_at" : "2015-08-10 02:34:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dolph Ziggler",
      "screen_name" : "HEELZiggler",
      "indices" : [ 3, 15 ],
      "id_str" : "105251590",
      "id" : 105251590
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 36, 44 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/2rMqb6h3dh",
      "expanded_url" : "https:\/\/twitter.com\/kiley1234567890\/status\/616399939640365056",
      "display_url" : "twitter.com\/kiley123456789\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630567274383020032",
  "text" : "RT @HEELZiggler: Anything hosted by @FoxNews anchors \uD83D\uDE0F https:\/\/t.co\/2rMqb6h3dh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 19, 27 ],
        "id_str" : "1367531",
        "id" : 1367531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/2rMqb6h3dh",
        "expanded_url" : "https:\/\/twitter.com\/kiley1234567890\/status\/616399939640365056",
        "display_url" : "twitter.com\/kiley123456789\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616400335607693313",
    "text" : "Anything hosted by @FoxNews anchors \uD83D\uDE0F https:\/\/t.co\/2rMqb6h3dh",
    "id" : 616400335607693313,
    "created_at" : "2015-07-02 00:17:46 +0000",
    "user" : {
      "name" : "Dolph Ziggler",
      "screen_name" : "HEELZiggler",
      "protected" : false,
      "id_str" : "105251590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000338448759\/04f414cc9d4c74acb58205772614469b_normal.jpeg",
      "id" : 105251590,
      "verified" : true
    }
  },
  "id" : 630567274383020032,
  "created_at" : "2015-08-10 02:32:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadassah Perry",
      "screen_name" : "HadassahPerry",
      "indices" : [ 0, 14 ],
      "id_str" : "630654220",
      "id" : 630654220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630565340880216064",
  "in_reply_to_user_id" : 630654220,
  "text" : "@HadassahPerry Your birthday was a day before mine, happy birthday random stranger, hope you had a good one :)",
  "id" : 630565340880216064,
  "created_at" : "2015-08-10 02:24:27 +0000",
  "in_reply_to_screen_name" : "HadassahPerry",
  "in_reply_to_user_id_str" : "630654220",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630564587281248256",
  "text" : "I wish I could wake up from this nightmare and find out that this is all a dream, and Reagan is president, but sadly, this is the reality :(",
  "id" : 630564587281248256,
  "created_at" : "2015-08-10 02:21:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630517661433094144",
  "text" : "RT @chknfriedsteak: @gamer456148 this administration is the epitome of a 3 ring circus.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "630338686790594560",
    "geo" : { },
    "id_str" : "630411716724043776",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 this administration is the epitome of a 3 ring circus.",
    "id" : 630411716724043776,
    "in_reply_to_status_id" : 630338686790594560,
    "created_at" : "2015-08-09 16:14:00 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 630517661433094144,
  "created_at" : "2015-08-09 23:14:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/630517568101441536\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/PAhHjuKvGH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMAMYzFUsAAcKdJ.jpg",
      "id_str" : "630517568000798720",
      "id" : 630517568000798720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMAMYzFUsAAcKdJ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/PAhHjuKvGH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630517568101441536",
  "text" : "That lamb died for a purpose \uD83C\uDF74 http:\/\/t.co\/PAhHjuKvGH",
  "id" : 630517568101441536,
  "created_at" : "2015-08-09 23:14:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 121, 136 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630338686790594560",
  "text" : "Anyone else believe we should change Obama's title from \"Commander in Chief\" to \"Monkey in Chief\", we can also use Clown @chknfriedsteak",
  "id" : 630338686790594560,
  "created_at" : "2015-08-09 11:23:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630338323773554688",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS In other words, get your head out of the sand Mr.President, you are turning America into a laughing stock of bafoons.",
  "id" : 630338323773554688,
  "created_at" : "2015-08-09 11:22:22 +0000",
  "in_reply_to_screen_name" : "POTUS44",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 0, 6 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630338042419654656",
  "in_reply_to_user_id" : 1536791610,
  "text" : "@POTUS God doesn't make mistakes, so stop having your free will listen to the devil, and maybe you will be not a total monkey.",
  "id" : 630338042419654656,
  "created_at" : "2015-08-09 11:21:15 +0000",
  "in_reply_to_screen_name" : "POTUS44",
  "in_reply_to_user_id_str" : "1536791610",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630320937485905920",
  "text" : "Things that make me want to throw up: 1) Obama exists 2) He is president 3) He is still president",
  "id" : 630320937485905920,
  "created_at" : "2015-08-09 10:13:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 0, 11 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "628351596829765633",
  "geo" : { },
  "id_str" : "630320707470102528",
  "in_reply_to_user_id" : 1074480192,
  "text" : "@SenTedCruz Not just defund them, but to criminally prosecute those baby butchering maniacs",
  "id" : 630320707470102528,
  "in_reply_to_status_id" : 628351596829765633,
  "created_at" : "2015-08-09 10:12:22 +0000",
  "in_reply_to_screen_name" : "SenTedCruz",
  "in_reply_to_user_id_str" : "1074480192",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/xyjoC7GDAT",
      "expanded_url" : "http:\/\/1.usa.gov\/1g2jZu6",
      "display_url" : "1.usa.gov\/1g2jZu6"
    } ]
  },
  "geo" : { },
  "id_str" : "630320562263343104",
  "text" : "RT @SenTedCruz: We should not rest until we have done everything to protect the lives of unborn children. http:\/\/t.co\/xyjoC7GDAT http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenTedCruz\/status\/628351596829765633\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/e0AVzLBsyj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLhaaTuWgAApRKY.png",
        "id_str" : "628351556035969024",
        "id" : 628351556035969024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLhaaTuWgAApRKY.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 2040
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/e0AVzLBsyj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/xyjoC7GDAT",
        "expanded_url" : "http:\/\/1.usa.gov\/1g2jZu6",
        "display_url" : "1.usa.gov\/1g2jZu6"
      } ]
    },
    "geo" : { },
    "id_str" : "628351596829765633",
    "text" : "We should not rest until we have done everything to protect the lives of unborn children. http:\/\/t.co\/xyjoC7GDAT http:\/\/t.co\/e0AVzLBsyj",
    "id" : 628351596829765633,
    "created_at" : "2015-08-03 23:47:49 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 630320562263343104,
  "created_at" : "2015-08-09 10:11:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "indices" : [ 3, 16 ],
      "id_str" : "65691824",
      "id" : 65691824
    }, {
      "name" : "Jake Tapper",
      "screen_name" : "jaketapper",
      "indices" : [ 39, 50 ],
      "id_str" : "14529929",
      "id" : 14529929
    }, {
      "name" : "State of the Union",
      "screen_name" : "CNNSotu",
      "indices" : [ 54, 62 ],
      "id_str" : "17112878",
      "id" : 17112878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PylDcjbyM8",
      "expanded_url" : "http:\/\/www.cnn.com\/about\/tv\/",
      "display_url" : "cnn.com\/about\/tv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "630320355693993984",
  "text" : "RT @CarlyFiorina: I\u2019ll also be joining @jaketapper on @CNNSotu. Catch it at 9 a.m. ET or noon when it re-airs! http:\/\/t.co\/PylDcjbyM8 #Carl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jake Tapper",
        "screen_name" : "jaketapper",
        "indices" : [ 21, 32 ],
        "id_str" : "14529929",
        "id" : 14529929
      }, {
        "name" : "State of the Union",
        "screen_name" : "CNNSotu",
        "indices" : [ 36, 44 ],
        "id_str" : "17112878",
        "id" : 17112878
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Carly2016",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/PylDcjbyM8",
        "expanded_url" : "http:\/\/www.cnn.com\/about\/tv\/",
        "display_url" : "cnn.com\/about\/tv\/"
      } ]
    },
    "geo" : { },
    "id_str" : "630196499260043264",
    "text" : "I\u2019ll also be joining @jaketapper on @CNNSotu. Catch it at 9 a.m. ET or noon when it re-airs! http:\/\/t.co\/PylDcjbyM8 #Carly2016",
    "id" : 630196499260043264,
    "created_at" : "2015-08-09 01:58:48 +0000",
    "user" : {
      "name" : "Carly Fiorina",
      "screen_name" : "CarlyFiorina",
      "protected" : false,
      "id_str" : "65691824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712639037194895360\/Dm6_vdam_normal.jpg",
      "id" : 65691824,
      "verified" : true
    }
  },
  "id" : 630320355693993984,
  "created_at" : "2015-08-09 10:10:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nephtali Valdez",
      "screen_name" : "zeroneff",
      "indices" : [ 3, 12 ],
      "id_str" : "36493227",
      "id" : 36493227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greta",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629811139036205057",
  "text" : "RT @zeroneff: Security at the cost of freedom? No way, I'm with Paul on this one. #greta ,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greta",
        "indices" : [ 68, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629793900509540354",
    "text" : "Security at the cost of freedom? No way, I'm with Paul on this one. #greta ,",
    "id" : 629793900509540354,
    "created_at" : "2015-08-07 23:19:01 +0000",
    "user" : {
      "name" : "Nephtali Valdez",
      "screen_name" : "zeroneff",
      "protected" : false,
      "id_str" : "36493227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703688636508680193\/6Rjg78-f_normal.jpg",
      "id" : 36493227,
      "verified" : false
    }
  },
  "id" : 629811139036205057,
  "created_at" : "2015-08-08 00:27:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reciprocity",
      "screen_name" : "Reciprocity4",
      "indices" : [ 3, 16 ],
      "id_str" : "1904924659",
      "id" : 1904924659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greta",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629811077136711680",
  "text" : "RT @Reciprocity4: Team Paul \"Those Who Sacrifice Liberty For Security Deserve Neither.\" Ben Franklin  Get a clue people #greta",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greta",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629796023645417472",
    "text" : "Team Paul \"Those Who Sacrifice Liberty For Security Deserve Neither.\" Ben Franklin  Get a clue people #greta",
    "id" : 629796023645417472,
    "created_at" : "2015-08-07 23:27:27 +0000",
    "user" : {
      "name" : "Reciprocity",
      "screen_name" : "Reciprocity4",
      "protected" : false,
      "id_str" : "1904924659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837704866898325504\/_5N4ijTc_normal.jpg",
      "id" : 1904924659,
      "verified" : false
    }
  },
  "id" : 629811077136711680,
  "created_at" : "2015-08-08 00:27:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greta",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629792851103191040",
  "text" : "Team Paul #greta",
  "id" : 629792851103191040,
  "created_at" : "2015-08-07 23:14:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629753214347423745",
  "text" : "Not going to the Business Forum this year, I had a conflicting situation #ThisIsOU",
  "id" : 629753214347423745,
  "created_at" : "2015-08-07 20:37:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629661717916708864",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ I love love your twitter banner!!!! Reagon and then the catch phrase \"Shut up Hippie!\"",
  "id" : 629661717916708864,
  "created_at" : "2015-08-07 14:33:46 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 66, 74 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629660865231474688",
  "text" : "RT @hannahbleau_: You'll know them by their fruits. Darn straight @tedcruz #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 48, 56 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 57, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629485055698534400",
    "text" : "You'll know them by their fruits. Darn straight @tedcruz #GOPDebate",
    "id" : 629485055698534400,
    "created_at" : "2015-08-07 02:51:47 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629660865231474688,
  "created_at" : "2015-08-07 14:30:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Scott Walker",
      "screen_name" : "ScottWalker",
      "indices" : [ 62, 74 ],
      "id_str" : "33750798",
      "id" : 33750798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamJesus",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "GOPDebate",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629660845841227777",
  "text" : "RT @hannahbleau_: Woo redeemed by the \"blood of Jesus Christ\" @ScottWalker went there. #teamJesus #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Walker",
        "screen_name" : "ScottWalker",
        "indices" : [ 44, 56 ],
        "id_str" : "33750798",
        "id" : 33750798
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teamJesus",
        "indices" : [ 69, 79 ]
      }, {
        "text" : "GOPDebate",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629485822148882432",
    "text" : "Woo redeemed by the \"blood of Jesus Christ\" @ScottWalker went there. #teamJesus #GOPDebate",
    "id" : 629485822148882432,
    "created_at" : "2015-08-07 02:54:49 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629660845841227777,
  "created_at" : "2015-08-07 14:30:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629488477961203712",
  "text" : "Okay I stayed to watch it all, Cruz definitely nailed it ;) GOOD NIGHT GUYS",
  "id" : 629488477961203712,
  "created_at" : "2015-08-07 03:05:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629477128510140416",
  "geo" : { },
  "id_str" : "629483748820656128",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ I am sure his words came back to haunt him, now I gotta sleep for a business forum tomorrow, but I bet Cruz is nailing it!!!",
  "id" : 629483748820656128,
  "in_reply_to_status_id" : 629477128510140416,
  "created_at" : "2015-08-07 02:46:35 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629483420712873984",
  "text" : "RT @hannahbleau_: @gamer456148 well his book is dedicated to Lucifer so it's only fitting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629475496359800832",
    "geo" : { },
    "id_str" : "629477128510140416",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 well his book is dedicated to Lucifer so it's only fitting.",
    "id" : 629477128510140416,
    "in_reply_to_status_id" : 629475496359800832,
    "created_at" : "2015-08-07 02:20:17 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629483420712873984,
  "created_at" : "2015-08-07 02:45:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 0, 12 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629476751245062145",
  "in_reply_to_user_id" : 813286,
  "text" : "@BarackObama Thanks for trusting our enemies, that is my last tweet for the night",
  "id" : 629476751245062145,
  "created_at" : "2015-08-07 02:18:47 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629475764476489728",
  "text" : "Yes, please repeal and replace Obama care",
  "id" : 629475764476489728,
  "created_at" : "2015-08-07 02:14:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629472779650232321",
  "geo" : { },
  "id_str" : "629475496359800832",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ Alinsky's the idiot who basically said he would chose to go to hell in the case of an afterlife, an evil scumbag",
  "id" : 629475496359800832,
  "in_reply_to_status_id" : 629472779650232321,
  "created_at" : "2015-08-07 02:13:48 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629472779650232321",
  "geo" : { },
  "id_str" : "629474958322868224",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ Her 1969 thesis, just reminds us she been a long time witch. Alinsky was an ass, who was a fan of Objective truth, and marxism",
  "id" : 629474958322868224,
  "in_reply_to_status_id" : 629472779650232321,
  "created_at" : "2015-08-07 02:11:39 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Ben & Candy Carson",
      "screen_name" : "RealBenCarson",
      "indices" : [ 79, 93 ],
      "id_str" : "1180379185",
      "id" : 1180379185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629470989181689856",
  "text" : "RT @hannahbleau_: There's no such thing as a politically correct war. Right on @RealBenCarson #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben & Candy Carson",
        "screen_name" : "RealBenCarson",
        "indices" : [ 61, 75 ],
        "id_str" : "1180379185",
        "id" : 1180379185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629468566291529728",
    "text" : "There's no such thing as a politically correct war. Right on @RealBenCarson #GOPDebate",
    "id" : 629468566291529728,
    "created_at" : "2015-08-07 01:46:15 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629470989181689856,
  "created_at" : "2015-08-07 01:55:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629467949460496384",
  "text" : "Cruz is so far nailing it #GOP :)",
  "id" : 629467949460496384,
  "created_at" : "2015-08-07 01:43:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629466901077331968",
  "text" : "Christie is definitely getting a nail in the head from Rand Paul",
  "id" : 629466901077331968,
  "created_at" : "2015-08-07 01:39:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GopDebate",
      "indices" : [ 95, 105 ]
    }, {
      "text" : "No2Amnesty",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629466078381494272",
  "text" : "Illegal are increasing the crime rate in this country. Why give criminals a slap on the wrist? #GopDebate #No2Amnesty",
  "id" : 629466078381494272,
  "created_at" : "2015-08-07 01:36:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629461548017127425",
  "geo" : { },
  "id_str" : "629461974858997760",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ But he was kinda funny though \uD83D\uDE05",
  "id" : 629461974858997760,
  "in_reply_to_status_id" : 629461548017127425,
  "created_at" : "2015-08-07 01:20:04 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629461548017127425",
  "geo" : { },
  "id_str" : "629461773553401856",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ True",
  "id" : 629461773553401856,
  "in_reply_to_status_id" : 629461548017127425,
  "created_at" : "2015-08-07 01:19:16 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629461710357823488",
  "text" : "RT @hannahbleau_: Trump's \"jab\" at Megyn Kelly..... Lame. Grow up. #GOPDebate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629461548017127425",
    "text" : "Trump's \"jab\" at Megyn Kelly..... Lame. Grow up. #GOPDebate",
    "id" : 629461548017127425,
    "created_at" : "2015-08-07 01:18:22 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629461710357823488,
  "created_at" : "2015-08-07 01:19:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629459133390041088",
  "text" : "When you feel stupid, just remember people are actually voting for Hillary Hosebeast",
  "id" : 629459133390041088,
  "created_at" : "2015-08-07 01:08:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629458874752483328",
  "text" : "How the hell do sub-human baby butchering scums like Planned Craphood sleep with themselves? The fact that they exist makes me wanna vomit.",
  "id" : 629458874752483328,
  "created_at" : "2015-08-07 01:07:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629458474276007940",
  "text" : "Trump is on!!!",
  "id" : 629458474276007940,
  "created_at" : "2015-08-07 01:06:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 14, 29 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629414939829010432",
  "geo" : { },
  "id_str" : "629453899053801472",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ @HillaryClinton I would call her a sub-human species but I think that is being too nice",
  "id" : 629453899053801472,
  "in_reply_to_status_id" : 629414939829010432,
  "created_at" : "2015-08-07 00:47:58 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629449740678107136\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/W7XiTz8iMl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLxBNATWgAAv4mZ.png",
      "id_str" : "629449739600297984",
      "id" : 629449739600297984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLxBNATWgAAv4mZ.png",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 139,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 695
      } ],
      "display_url" : "pic.twitter.com\/W7XiTz8iMl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629449740678107136",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ Take this as a compliment. It can go one way or the other. I either flattered you or creeped you out ;) http:\/\/t.co\/W7XiTz8iMl",
  "id" : 629449740678107136,
  "created_at" : "2015-08-07 00:31:27 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629443790126776321",
  "text" : "RT @hannahbleau_: @gamer456148 I believe the Bible is the infallible word of God. And He loves the crap out of us. No sugarcoating there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629410028395601921",
    "geo" : { },
    "id_str" : "629415663501574144",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I believe the Bible is the infallible word of God. And He loves the crap out of us. No sugarcoating there.",
    "id" : 629415663501574144,
    "in_reply_to_status_id" : 629410028395601921,
    "created_at" : "2015-08-06 22:16:02 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629443790126776321,
  "created_at" : "2015-08-07 00:07:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629392048253067265",
  "geo" : { },
  "id_str" : "629410028395601921",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ What is your opinion on me believing the bible is the most profound book of wisdom and the spoken true word of God all mighty?",
  "id" : 629410028395601921,
  "in_reply_to_status_id" : 629392048253067265,
  "created_at" : "2015-08-06 21:53:39 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629409480774676480",
  "text" : "RT @hannahbleau_: @gamer456148 yep, as of right now Cruz is my guy. (And I don't see myself changing my mind.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629372315713839104",
    "geo" : { },
    "id_str" : "629392048253067265",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 yep, as of right now Cruz is my guy. (And I don't see myself changing my mind.)",
    "id" : 629392048253067265,
    "in_reply_to_status_id" : 629372315713839104,
    "created_at" : "2015-08-06 20:42:12 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629409480774676480,
  "created_at" : "2015-08-06 21:51:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629372315713839104",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ Are you a Ted Cruz fan, he's my optimal candidate pick?",
  "id" : 629372315713839104,
  "created_at" : "2015-08-06 19:23:47 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629371820244893697",
  "text" : "RT @hannahbleau_: @gamer456148 aw I'm flattered! You have a great day too! \uD83D\uDE01\uD83C\uDDFA\uD83C\uDDF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629295997781438464",
    "geo" : { },
    "id_str" : "629355497607589888",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 aw I'm flattered! You have a great day too! \uD83D\uDE01\uD83C\uDDFA\uD83C\uDDF8",
    "id" : 629355497607589888,
    "in_reply_to_status_id" : 629295997781438464,
    "created_at" : "2015-08-06 18:16:58 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 629371820244893697,
  "created_at" : "2015-08-06 19:21:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629326133801005056",
  "text" : "@JosefLokmani Watch the GOP debate tonight, maybe you will learn something new, for now this discussion is over, talk to you later :)",
  "id" : 629326133801005056,
  "created_at" : "2015-08-06 16:20:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629325935875985408",
  "text" : "@JosefLokmani Dude I don't get why you always try arguing, I have to go, my time is more valuable then this",
  "id" : 629325935875985408,
  "created_at" : "2015-08-06 16:19:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629325488821944320",
  "text" : "@JosefLokmani Who wouldn't be afraid of one of the biggest economic powers or country's in the world. Even North Korea is afraid of Russia.",
  "id" : 629325488821944320,
  "created_at" : "2015-08-06 16:17:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629323845539729408",
  "text" : "@JosefLokmani If they were afraid of Iran, why would they give them more power?",
  "id" : 629323845539729408,
  "created_at" : "2015-08-06 16:11:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629323237529227264",
  "text" : "@JosefLokmani Why would someone play poker with the Devil and expect good results?",
  "id" : 629323237529227264,
  "created_at" : "2015-08-06 16:08:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629322227528302593",
  "text" : "@JosefLokmani Dude no offense, but whoever teaches you this crap is an idiot",
  "id" : 629322227528302593,
  "created_at" : "2015-08-06 16:04:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629321432103686144",
  "text" : "@JosefLokmani By the US giving Iran more power, they would be making the situation even worse not better",
  "id" : 629321432103686144,
  "created_at" : "2015-08-06 16:01:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629319934187692032",
  "geo" : { },
  "id_str" : "629321098828517377",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Cruz by far is the best GOP candidate and the most Reagan like personality. He reminds of an old school no-bs conservative",
  "id" : 629321098828517377,
  "in_reply_to_status_id" : 629319934187692032,
  "created_at" : "2015-08-06 16:00:16 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 33, 46 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629320500842377216",
  "text" : "RT @chknfriedsteak: @gamer456148 @JosefLokmani Ted Cruz is a brilliant man. He'll dominate the debate tonight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 13, 26 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629318619961294848",
    "geo" : { },
    "id_str" : "629319934187692032",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @JosefLokmani Ted Cruz is a brilliant man. He'll dominate the debate tonight.",
    "id" : 629319934187692032,
    "in_reply_to_status_id" : 629318619961294848,
    "created_at" : "2015-08-06 15:55:39 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 629320500842377216,
  "created_at" : "2015-08-06 15:57:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629320352015908866",
  "text" : "@JosefLokmani Read the story of Saeed Abedini, the Iranian captive, the military over there took part of a radical revolution",
  "id" : 629320352015908866,
  "created_at" : "2015-08-06 15:57:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629319791392616448",
  "text" : "@JosefLokmani Iran is very hostile towards Christians, and Muslims that convert to Christianity get severely tortured under Sharia law",
  "id" : 629319791392616448,
  "created_at" : "2015-08-06 15:55:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629318619961294848",
  "text" : "@JosefLokmani You can't call Cruz a twat, you don't have any idea how bad the situation there is, you are clueless",
  "id" : 629318619961294848,
  "created_at" : "2015-08-06 15:50:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Kaufman",
      "screen_name" : "benkaufman",
      "indices" : [ 0, 11 ],
      "id_str" : "14402471",
      "id" : 14402471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629317062532333568",
  "in_reply_to_user_id" : 14402471,
  "text" : "@benkaufman I mean let us have a conversation man!!!",
  "id" : 629317062532333568,
  "created_at" : "2015-08-06 15:44:14 +0000",
  "in_reply_to_screen_name" : "benkaufman",
  "in_reply_to_user_id_str" : "14402471",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Kaufman",
      "screen_name" : "benkaufman",
      "indices" : [ 0, 11 ],
      "id_str" : "14402471",
      "id" : 14402471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629316881640337408",
  "in_reply_to_user_id" : 14402471,
  "text" : "@benkaufman I been a community member for 5 years, did 1500+ contributions and got almost nothing, at least talk to me, I still believe in U",
  "id" : 629316881640337408,
  "created_at" : "2015-08-06 15:43:31 +0000",
  "in_reply_to_screen_name" : "benkaufman",
  "in_reply_to_user_id_str" : "14402471",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629315783546441728",
  "text" : "I guess most things don't make sense",
  "id" : 629315783546441728,
  "created_at" : "2015-08-06 15:39:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 98, 110 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629315432978092032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/00Q2uzNBDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvHDQGUsAAREa3.jpg",
      "id_str" : "629315431623340032",
      "id" : 629315431623340032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvHDQGUsAAREa3.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      } ],
      "display_url" : "pic.twitter.com\/00Q2uzNBDm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629315432978092032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/00Q2uzNBDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvHDSoVEAAfdbx.jpg",
      "id_str" : "629315432302841856",
      "id" : 629315432302841856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvHDSoVEAAfdbx.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/00Q2uzNBDm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629315432978092032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/00Q2uzNBDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvHDN5UEAEN8ri.jpg",
      "id_str" : "629315431031902209",
      "id" : 629315431031902209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvHDN5UEAEN8ri.jpg",
      "sizes" : [ {
        "h" : 57,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 91,
        "resize" : "crop",
        "w" : 91
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      } ],
      "display_url" : "pic.twitter.com\/00Q2uzNBDm"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629315432978092032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/00Q2uzNBDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvHDRHVAAAxCWH.jpg",
      "id_str" : "629315431895990272",
      "id" : 629315431895990272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvHDRHVAAAxCWH.jpg",
      "sizes" : [ {
        "h" : 57,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 91,
        "resize" : "crop",
        "w" : 91
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 539
      } ],
      "display_url" : "pic.twitter.com\/00Q2uzNBDm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629315432978092032",
  "text" : "@JosefLokmani Why trust people who call you an idiot for trusting them? Doesn't make sense @POTUS @BarackObama http:\/\/t.co\/00Q2uzNBDm",
  "id" : 629315432978092032,
  "created_at" : "2015-08-06 15:37:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 0, 8 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629309217539784705",
  "geo" : { },
  "id_str" : "629314255737610242",
  "in_reply_to_user_id" : 91220126,
  "text" : "@adwords I sent a DM. Waiting to hear back!!!",
  "id" : 629314255737610242,
  "in_reply_to_status_id" : 629309217539784705,
  "created_at" : "2015-08-06 15:33:05 +0000",
  "in_reply_to_screen_name" : "adwords",
  "in_reply_to_user_id_str" : "91220126",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629303962504687616",
  "text" : "@888casino Can you just give me the money without playing, you were going to give it to someone anyways, lol :P",
  "id" : 629303962504687616,
  "created_at" : "2015-08-06 14:52:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629302437770317824",
  "text" : "@JosefLokmani Why does a country support another country that hates that country, doesn't make any logical sense",
  "id" : 629302437770317824,
  "created_at" : "2015-08-06 14:46:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629302263090163712",
  "text" : "@JosefLokmani Dude they aren't our allies. It makes us look weaker. The Iranian PM even put a cartoon of Obama putting a gun to his head!!!",
  "id" : 629302263090163712,
  "created_at" : "2015-08-06 14:45:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google AdWords",
      "screen_name" : "adwords",
      "indices" : [ 0, 8 ],
      "id_str" : "91220126",
      "id" : 91220126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629301742623150080",
  "in_reply_to_user_id" : 91220126,
  "text" : "@adwords Can't you just give me the Adwords credit I deserve without me having to spend more \uD83D\uDCB5. Your costumer support by the way is awful!!",
  "id" : 629301742623150080,
  "created_at" : "2015-08-06 14:43:21 +0000",
  "in_reply_to_screen_name" : "adwords",
  "in_reply_to_user_id_str" : "91220126",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 14, 22 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629300407429410816",
  "text" : "@JosefLokmani @tedcruz No, it doesn't",
  "id" : 629300407429410816,
  "created_at" : "2015-08-06 14:38:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 14, 22 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629300348021272576",
  "text" : "@JosefLokmani @tedcruz Ted Cruz said he basically doesn't want a radical country to have more nuclear research, does it make him a twat?",
  "id" : 629300348021272576,
  "created_at" : "2015-08-06 14:37:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629299953123336192",
  "text" : "Whether or not I agree with him is a whole different story.",
  "id" : 629299953123336192,
  "created_at" : "2015-08-06 14:36:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 23, 39 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629299796168298500",
  "text" : "The thing I like about @realDonaldTrump is he unapologetic and doesn't back down on any of his stances. I like that personality.",
  "id" : 629299796168298500,
  "created_at" : "2015-08-06 14:35:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 14, 30 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629299011330158592",
  "text" : "@JosefLokmani @realDonaldTrump No Josef he doesn't sound like a kid, just arrogant. I never would use my IQ to put people down.",
  "id" : 629299011330158592,
  "created_at" : "2015-08-06 14:32:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 14, 22 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629298451843547136",
  "text" : "@JosefLokmani @tedcruz By the way Ted Cruz knows alot about politics then you, and maybe even more than me. Don't call him a twat!!!",
  "id" : 629298451843547136,
  "created_at" : "2015-08-06 14:30:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 14, 22 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629298232707969026",
  "text" : "@JosefLokmani @tedcruz What the hell Josef, why would anyone support letting Iran doing Nuclear research? A country that hates America....",
  "id" : 629298232707969026,
  "created_at" : "2015-08-06 14:29:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629297484339265536",
  "text" : "@JosefLokmani If you notice my twitter feed, I am gaining weight and fat. I wish I was gaining muscle. Been so busy trying to find the time-",
  "id" : 629297484339265536,
  "created_at" : "2015-08-06 14:26:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629291273430671360",
  "geo" : { },
  "id_str" : "629297114967855104",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo The battle is tough with this one :(",
  "id" : 629297114967855104,
  "in_reply_to_status_id" : 629291273430671360,
  "created_at" : "2015-08-06 14:24:58 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lana Del Rey",
      "screen_name" : "LanaDelRey",
      "indices" : [ 0, 11 ],
      "id_str" : "45266183",
      "id" : 45266183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629293937375756288",
  "geo" : { },
  "id_str" : "629296581079076864",
  "in_reply_to_user_id" : 45266183,
  "text" : "@LanaDelRey I won't even watch it and I am almost certain it will be filled with garbage and satanic symbolism. Stop showing up on my feed!!",
  "id" : 629296581079076864,
  "in_reply_to_status_id" : 629293937375756288,
  "created_at" : "2015-08-06 14:22:51 +0000",
  "in_reply_to_screen_name" : "LanaDelRey",
  "in_reply_to_user_id_str" : "45266183",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629295997781438464",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ Guess whose my conservative crush? \uD83D\uDE09 Seriously though you are beautiful and I hope you have a beautiful day!!!",
  "id" : 629295997781438464,
  "created_at" : "2015-08-06 14:20:32 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bubble",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629280585425494016",
  "text" : "Don't even go there #Bubble",
  "id" : 629280585425494016,
  "created_at" : "2015-08-06 13:19:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Voltage",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "OU",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629280398065991680",
  "text" : "I am not socially awkward, its those around me #Voltage #OU",
  "id" : 629280398065991680,
  "created_at" : "2015-08-06 13:18:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/629262968929300480\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/hq1npprtDg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLuXVg0XAAAu7Ay.jpg",
      "id_str" : "629262968790908928",
      "id" : 629262968790908928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLuXVg0XAAAu7Ay.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/hq1npprtDg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629262968929300480",
  "text" : "Basically my ever day breakfast is as unhealthy and GMO filled as one could get http:\/\/t.co\/hq1npprtDg",
  "id" : 629262968929300480,
  "created_at" : "2015-08-06 12:09:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629248532885700608",
  "text" : "Investing in precious metals isn't always wise, unless you know how to do it right ;)",
  "id" : 629248532885700608,
  "created_at" : "2015-08-06 11:11:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629098749525004288",
  "geo" : { },
  "id_str" : "629099355157495808",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak I hate going to investors and giving them equity or royalties for the rest of your life, would never recommend it.",
  "id" : 629099355157495808,
  "in_reply_to_status_id" : 629098749525004288,
  "created_at" : "2015-08-06 01:19:09 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 19, 31 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 32, 40 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629098832756887552",
  "text" : "RT @DavidLimbaugh: @gamer456148 @tedcruz Ditto!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 13, 21 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629098589902499840",
    "geo" : { },
    "id_str" : "629098665605398529",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @tedcruz Ditto!",
    "id" : 629098665605398529,
    "in_reply_to_status_id" : 629098589902499840,
    "created_at" : "2015-08-06 01:16:24 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 629098832756887552,
  "created_at" : "2015-08-06 01:17:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629098700208537600",
  "text" : "RT @chknfriedsteak: @gamer456148 yeah- I've got a friend that went to MIT who wants to help me with the iOS side of a dream that I had...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629097961067294720",
    "geo" : { },
    "id_str" : "629098422432219136",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 yeah- I've got a friend that went to MIT who wants to help me with the iOS side of a dream that I had...",
    "id" : 629098422432219136,
    "in_reply_to_status_id" : 629097961067294720,
    "created_at" : "2015-08-06 01:15:26 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 629098700208537600,
  "created_at" : "2015-08-06 01:16:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 0, 14 ],
      "id_str" : "179245596",
      "id" : 179245596
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 54, 62 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629098589902499840",
  "in_reply_to_user_id" : 179245596,
  "text" : "@DavidLimbaugh Who is your optimal candidate, mine is @tedcruz",
  "id" : 629098589902499840,
  "created_at" : "2015-08-06 01:16:06 +0000",
  "in_reply_to_screen_name" : "DavidLimbaugh",
  "in_reply_to_user_id_str" : "179245596",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/wehuHi6bom",
      "expanded_url" : "https:\/\/twitter.com\/RichCarlsen\/status\/628435419957334020",
      "display_url" : "twitter.com\/RichCarlsen\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629098307730673665",
  "text" : "RT @DavidLimbaugh: No, because Communism self described as atheist. See your boy Karl.  http:\/\/t.co\/wehuHi6bom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/wehuHi6bom",
        "expanded_url" : "https:\/\/twitter.com\/RichCarlsen\/status\/628435419957334020",
        "display_url" : "twitter.com\/RichCarlsen\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628435789760761856",
    "text" : "No, because Communism self described as atheist. See your boy Karl.  http:\/\/t.co\/wehuHi6bom",
    "id" : 628435789760761856,
    "created_at" : "2015-08-04 05:22:22 +0000",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 629098307730673665,
  "created_at" : "2015-08-06 01:14:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629098130097709056",
  "text" : "RT @DavidLimbaugh: This one will a) explode the heads of  the snarky atheists inhabiting my timeline &amp; b) convince them I\u2019m a simpleton htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/9bbrrD4saw",
        "expanded_url" : "https:\/\/www.facebook.com\/official.Ray.Comfort\/videos\/1077188105634995\/",
        "display_url" : "facebook.com\/official.Ray.C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629084549209698304",
    "text" : "This one will a) explode the heads of  the snarky atheists inhabiting my timeline &amp; b) convince them I\u2019m a simpleton https:\/\/t.co\/9bbrrD4saw",
    "id" : 629084549209698304,
    "created_at" : "2015-08-06 00:20:19 +0000",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 629098130097709056,
  "created_at" : "2015-08-06 01:14:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629097238396977152",
  "geo" : { },
  "id_str" : "629097961067294720",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak I had inventions before, just none that was a major success, the patent market sucks and is monopolized by lobbyists",
  "id" : 629097961067294720,
  "in_reply_to_status_id" : 629097238396977152,
  "created_at" : "2015-08-06 01:13:36 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "indices" : [ 0, 12 ],
      "id_str" : "323894401",
      "id" : 323894401
    }, {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 13, 22 ],
      "id_str" : "17468189",
      "id" : 17468189
    }, {
      "name" : "Oakland Problems",
      "screen_name" : "OaklandProb",
      "indices" : [ 23, 35 ],
      "id_str" : "1855776752",
      "id" : 1855776752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NiceTREND",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "GrizzGreet",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629096915511169024",
  "in_reply_to_user_id" : 323894401,
  "text" : "@ashhlaaypie @Oaklandu @OaklandProb Everyone tweet to somebody you don't know and tell them to have a beautiful day #NiceTREND #GrizzGreet",
  "id" : 629096915511169024,
  "created_at" : "2015-08-06 01:09:27 +0000",
  "in_reply_to_screen_name" : "ashhlaaypie",
  "in_reply_to_user_id_str" : "323894401",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    }, {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610907453291544576",
  "geo" : { },
  "id_str" : "629091973891268609",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ I feel like a dog, should I be paying taxes, I feel like a Native, do I get free college, liberals are just hypocrites @POTUS",
  "id" : 629091973891268609,
  "in_reply_to_status_id" : 610907453291544576,
  "created_at" : "2015-08-06 00:49:49 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 0, 13 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623271107282386944",
  "geo" : { },
  "id_str" : "629090896257122305",
  "in_reply_to_user_id" : 2355686438,
  "text" : "@hannahbleau_ But she ain't a lady :P",
  "id" : 629090896257122305,
  "in_reply_to_status_id" : 623271107282386944,
  "created_at" : "2015-08-06 00:45:32 +0000",
  "in_reply_to_screen_name" : "hannahbleau_",
  "in_reply_to_user_id_str" : "2355686438",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "indices" : [ 0, 12 ],
      "id_str" : "323894401",
      "id" : 323894401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619603093190279168",
  "geo" : { },
  "id_str" : "629016715981135872",
  "in_reply_to_user_id" : 323894401,
  "text" : "@ashhlaaypie \"Sighs\"",
  "id" : 629016715981135872,
  "in_reply_to_status_id" : 619603093190279168,
  "created_at" : "2015-08-05 19:50:46 +0000",
  "in_reply_to_screen_name" : "ashhlaaypie",
  "in_reply_to_user_id_str" : "323894401",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "indices" : [ 3, 15 ],
      "id_str" : "323894401",
      "id" : 323894401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629016594505707521",
  "text" : "RT @ashhlaaypie: Today is definitely not my day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620982222200406016",
    "text" : "Today is definitely not my day",
    "id" : 620982222200406016,
    "created_at" : "2015-07-14 15:44:33 +0000",
    "user" : {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "protected" : false,
      "id_str" : "323894401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839281884194566144\/NCl1CcEc_normal.jpg",
      "id" : 323894401,
      "verified" : false
    }
  },
  "id" : 629016594505707521,
  "created_at" : "2015-08-05 19:50:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "indices" : [ 3, 15 ],
      "id_str" : "323894401",
      "id" : 323894401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629016388200493056",
  "text" : "RT @ashhlaaypie: My life is just full of awkward moments",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624410612236484610",
    "text" : "My life is just full of awkward moments",
    "id" : 624410612236484610,
    "created_at" : "2015-07-24 02:47:45 +0000",
    "user" : {
      "name" : "ash",
      "screen_name" : "ashhlaaypie",
      "protected" : false,
      "id_str" : "323894401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839281884194566144\/NCl1CcEc_normal.jpg",
      "id" : 323894401,
      "verified" : false
    }
  },
  "id" : 629016388200493056,
  "created_at" : "2015-08-05 19:49:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari",
      "screen_name" : "MariPallis",
      "indices" : [ 3, 14 ],
      "id_str" : "416489468",
      "id" : 416489468
    }, {
      "name" : "Oakland Problems",
      "screen_name" : "OaklandProb",
      "indices" : [ 16, 28 ],
      "id_str" : "1855776752",
      "id" : 1855776752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629015619149635584",
  "text" : "RT @MariPallis: @OaklandProb OU is raising tuition by 8%...that whole \"you can afford to go here\" marketing plan should probably be changed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oakland Problems",
        "screen_name" : "OaklandProb",
        "indices" : [ 0, 12 ],
        "id_str" : "1855776752",
        "id" : 1855776752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618593203143487488",
    "in_reply_to_user_id" : 1855776752,
    "text" : "@OaklandProb OU is raising tuition by 8%...that whole \"you can afford to go here\" marketing plan should probably be changed...",
    "id" : 618593203143487488,
    "created_at" : "2015-07-08 01:31:27 +0000",
    "in_reply_to_screen_name" : "OaklandProb",
    "in_reply_to_user_id_str" : "1855776752",
    "user" : {
      "name" : "Mari",
      "screen_name" : "MariPallis",
      "protected" : false,
      "id_str" : "416489468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819637311608590336\/LhTWvrCG_normal.jpg",
      "id" : 416489468,
      "verified" : false
    }
  },
  "id" : 629015619149635584,
  "created_at" : "2015-08-05 19:46:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FinalCutIcon",
      "screen_name" : "finalcuticon",
      "indices" : [ 0, 13 ],
      "id_str" : "186978700",
      "id" : 186978700
    }, {
      "name" : "Flash Player icon",
      "screen_name" : "Flashplayericon",
      "indices" : [ 14, 30 ],
      "id_str" : "186982727",
      "id" : 186982727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "25214918426",
  "geo" : { },
  "id_str" : "629015486194429953",
  "in_reply_to_user_id" : 186978700,
  "text" : "@finalcuticon @Flashplayericon A long, long time ago, I can still remember",
  "id" : 629015486194429953,
  "in_reply_to_status_id" : 25214918426,
  "created_at" : "2015-08-05 19:45:53 +0000",
  "in_reply_to_screen_name" : "finalcuticon",
  "in_reply_to_user_id_str" : "186978700",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FinalCutIcon",
      "screen_name" : "finalcuticon",
      "indices" : [ 3, 16 ],
      "id_str" : "186978700",
      "id" : 186978700
    }, {
      "name" : "Flash Player icon",
      "screen_name" : "Flashplayericon",
      "indices" : [ 18, 34 ],
      "id_str" : "186982727",
      "id" : 186982727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629015386684563456",
  "text" : "RT @finalcuticon: @Flashplayericon One reason not to: it's made with Silverlight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Flash Player icon",
        "screen_name" : "Flashplayericon",
        "indices" : [ 0, 16 ],
        "id_str" : "186982727",
        "id" : 186982727
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "25180982238",
    "geo" : { },
    "id_str" : "25214918426",
    "in_reply_to_user_id" : 186982727,
    "text" : "@Flashplayericon One reason not to: it's made with Silverlight.",
    "id" : 25214918426,
    "in_reply_to_status_id" : 25180982238,
    "created_at" : "2010-09-22 14:14:43 +0000",
    "in_reply_to_screen_name" : "Flashplayericon",
    "in_reply_to_user_id_str" : "186982727",
    "user" : {
      "name" : "FinalCutIcon",
      "screen_name" : "finalcuticon",
      "protected" : false,
      "id_str" : "186978700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117417848\/FinalCutIcon_normal.jpg",
      "id" : 186978700,
      "verified" : false
    }
  },
  "id" : 629015386684563456,
  "created_at" : "2015-08-05 19:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629015174587006976",
  "text" : "Notice how I need to shorten me tweets to make it 140 characters, try to have a conversation on twitter, it is not at all easy. I mean .....",
  "id" : 629015174587006976,
  "created_at" : "2015-08-05 19:44:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MHacks",
      "screen_name" : "mhacks",
      "indices" : [ 0, 7 ],
      "id_str" : "870221107",
      "id" : 870221107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629014865085075456",
  "in_reply_to_user_id" : 870221107,
  "text" : "@mhacks U made a terrible decission not accepting me and putting me on ur waiting list, but I applied late, U can't win them all I guess",
  "id" : 629014865085075456,
  "created_at" : "2015-08-05 19:43:25 +0000",
  "in_reply_to_screen_name" : "mhacks",
  "in_reply_to_user_id_str" : "870221107",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628960752897007616",
  "text" : "And trust me sir, I ain't no square :P",
  "id" : 628960752897007616,
  "created_at" : "2015-08-05 16:08:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628960617467105280",
  "text" : "It is my birthday month so I don't have to diet, not that I ever diet, lol. My form of exercise is chopping wood, shoveling, and lawn mowing",
  "id" : 628960617467105280,
  "created_at" : "2015-08-05 16:07:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/628960202830839808\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ZZnUx8fRxa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqD-NHW8AA0qjT.jpg",
      "id_str" : "628960202667257856",
      "id" : 628960202667257856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqD-NHW8AA0qjT.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/ZZnUx8fRxa"
    } ],
    "hashtags" : [ {
      "text" : "Deepfried",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628960202830839808",
  "text" : "I love almond chicken with some gravy #Deepfried http:\/\/t.co\/ZZnUx8fRxa",
  "id" : 628960202830839808,
  "created_at" : "2015-08-05 16:06:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628936910254309376",
  "text" : "Be the change God wants you to be in this world :)",
  "id" : 628936910254309376,
  "created_at" : "2015-08-05 14:33:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628933650055217152",
  "text" : "I think.... I am always thinking \uD83D\uDE14",
  "id" : 628933650055217152,
  "created_at" : "2015-08-05 14:20:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628931830465593344",
  "text" : "Ever notice how medical school students seem to be the most socialable, lol #ThisIsOU This coming from a computers guy, haha",
  "id" : 628931830465593344,
  "created_at" : "2015-08-05 14:13:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628931452474781697",
  "text" : "Sweet and Sour chicken would probably be the food that reminds me of myself, just a random thought ;)",
  "id" : 628931452474781697,
  "created_at" : "2015-08-05 14:11:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628923380373127168",
  "text" : "I am nice, I just sometimes meet people at the wrong time, lol",
  "id" : 628923380373127168,
  "created_at" : "2015-08-05 13:39:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/628920437385392128\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/uB62yS2N4p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpfzjgWcAATx_7.jpg",
      "id_str" : "628920437280501760",
      "id" : 628920437280501760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpfzjgWcAATx_7.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/uB62yS2N4p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628920437385392128",
  "text" : "You know you have a problem when this is your breakfast http:\/\/t.co\/uB62yS2N4p",
  "id" : 628920437385392128,
  "created_at" : "2015-08-05 13:28:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628920070526377984",
  "text" : "@JosefLokmani I just think ISIS is a cult",
  "id" : 628920070526377984,
  "created_at" : "2015-08-05 13:26:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 19, 32 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628919898505355264",
  "text" : "No I am not racist @JosefLokmani",
  "id" : 628919898505355264,
  "created_at" : "2015-08-05 13:26:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Excited",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "Confused",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628884071267995648",
  "text" : "Just got the non-beta edition of Windows 10, this is what Microsoft spent many month on? #Excited #Confused",
  "id" : 628884071267995648,
  "created_at" : "2015-08-05 11:03:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627841345789558788",
  "geo" : { },
  "id_str" : "628545649886294016",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump As true as that kinda is, you still never fail to amuse me :P",
  "id" : 628545649886294016,
  "in_reply_to_status_id" : 627841345789558788,
  "created_at" : "2015-08-04 12:38:55 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBS",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628545440271745024",
  "text" : "I wanna start the #NoBS movement, who is with me?",
  "id" : 628545440271745024,
  "created_at" : "2015-08-04 12:38:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628545246176149505",
  "text" : "Anyone who advocates for the Iran Nuclear Deal is like saying it is a good idea to play poker with the Devil. Our enemies aren't friends.",
  "id" : 628545246176149505,
  "created_at" : "2015-08-04 12:37:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "No2ISIS",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628544368400535552",
  "text" : "There was once a famous man named Hitler who believed in radical Islam's cause and the hatred of Jews. Wonder what happened to him? #No2ISIS",
  "id" : 628544368400535552,
  "created_at" : "2015-08-04 12:33:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "No2ISIS",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628543935439204352",
  "text" : "I am not afraid of being called an infidel for believing in Jesus's profound truth or thinking genocide isn't miraculous holy work. #No2ISIS",
  "id" : 628543935439204352,
  "created_at" : "2015-08-04 12:32:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628543500494045184",
  "text" : "Seriously, I have a friend named Ahmed who knows I am Coptic Orthodox. That is what's normal. This small cult are psychopathic sub-humans.",
  "id" : 628543500494045184,
  "created_at" : "2015-08-04 12:30:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notanotherbrother",
      "indices" : [ 23, 41 ]
    }, {
      "text" : "No2ISIS",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628542778457366528",
  "text" : "Islams should join the #notanotherbrother and the #No2ISIS campaign. We should say enough is enough for these radical demonic species.",
  "id" : 628542778457366528,
  "created_at" : "2015-08-04 12:27:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628533478112526336",
  "text" : "@JosefLokmani Oh Josef, you never fail to amuse me. You seem in a better mood these days. Did you start going to church my brother?",
  "id" : 628533478112526336,
  "created_at" : "2015-08-04 11:50:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628533043423264768",
  "text" : "I like to see people laugh or smile. You can meet someone and never see them again, but you still made a difference in their day. Be happy!!",
  "id" : 628533043423264768,
  "created_at" : "2015-08-04 11:48:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Jessel",
      "screen_name" : "Ray_Jessel",
      "indices" : [ 0, 11 ],
      "id_str" : "2594057088",
      "id" : 2594057088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628321157285081090",
  "in_reply_to_user_id" : 2594057088,
  "text" : "@Ray_Jessel Man you are one dirty minded Orthodox Jew, lol",
  "id" : 628321157285081090,
  "created_at" : "2015-08-03 21:46:52 +0000",
  "in_reply_to_screen_name" : "Ray_Jessel",
  "in_reply_to_user_id_str" : "2594057088",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veteran",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628253518768533504",
  "text" : "I just saluted a #veteran today, what did you do?",
  "id" : 628253518768533504,
  "created_at" : "2015-08-03 17:18:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628247611535810560",
  "text" : "In no way does asking for advice or peer review constitutes as academic dishonesty!!!",
  "id" : 628247611535810560,
  "created_at" : "2015-08-03 16:54:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628245686258012160",
  "text" : "I hate it when there's this one secretary that is always annoying. Especially, if you go to tutoring. #ThisIsOU",
  "id" : 628245686258012160,
  "created_at" : "2015-08-03 16:46:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Not",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "BS",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628245454745001984",
  "text" : "Asking for advice on the paper or help learning a subject being taught for an assignment apparently is academic dishonesty #Not really #BS",
  "id" : 628245454745001984,
  "created_at" : "2015-08-03 16:46:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HungryGrizz",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628236896058126336",
  "text" : "Tornados, a whirlwind of my lunch \uD83D\uDE0B #HungryGrizz",
  "id" : 628236896058126336,
  "created_at" : "2015-08-03 16:12:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OUGreet",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "Grizzly",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628221340798074880",
  "text" : "Why doesn't everyone tell others to have a nice day? #OUGreet #Grizzly",
  "id" : 628221340798074880,
  "created_at" : "2015-08-03 15:10:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628207966781591552",
  "text" : "People are being extra nice today, and it is a Monday, how shocking isn't it? Why can't people be nice everyday? Maybe it is the caffeine.",
  "id" : 628207966781591552,
  "created_at" : "2015-08-03 14:17:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628206642396467205",
  "text" : "Some people are so nice, you start to wonder how #ThisIsOU",
  "id" : 628206642396467205,
  "created_at" : "2015-08-03 14:11:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628205261245808640",
  "text" : "@JosefLokmani Or go to business or finance, those people make lots of money. Personally, I think you would like engineering :)",
  "id" : 628205261245808640,
  "created_at" : "2015-08-03 14:06:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628204925357551616",
  "text" : "@JosefLokmani You should go to Computer Engineering or IT like me. Then we can meet up when we graduated and start a startup, lol \uD83D\uDE01",
  "id" : 628204925357551616,
  "created_at" : "2015-08-03 14:05:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/628204235033825280\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/syt4ImfOdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLfUbFxWEAAO8-l.jpg",
      "id_str" : "628204234912174080",
      "id" : 628204234912174080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLfUbFxWEAAO8-l.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/syt4ImfOdh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628204235033825280",
  "text" : "My breakfast described by a picture http:\/\/t.co\/syt4ImfOdh",
  "id" : 628204235033825280,
  "created_at" : "2015-08-03 14:02:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628199489317249024",
  "text" : "A medical student (Junior) from OU, just taught me a fact. #ThisIsOU",
  "id" : 628199489317249024,
  "created_at" : "2015-08-03 13:43:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OU in Macomb County",
      "screen_name" : "OUMacomb",
      "indices" : [ 0, 9 ],
      "id_str" : "16189058",
      "id" : 16189058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626398081798549505",
  "geo" : { },
  "id_str" : "628185642300755968",
  "in_reply_to_user_id" : 16189058,
  "text" : "@OUMacomb You mean the ones we payed for?",
  "id" : 628185642300755968,
  "in_reply_to_status_id" : 626398081798549505,
  "created_at" : "2015-08-03 12:48:22 +0000",
  "in_reply_to_screen_name" : "OUMacomb",
  "in_reply_to_user_id_str" : "16189058",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/628185172463255553\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rhjwE7HJRf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLfDFd-W8AA1mpF.png",
      "id_str" : "628185171754414080",
      "id" : 628185171754414080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLfDFd-W8AA1mpF.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1419
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rhjwE7HJRf"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "WIMF",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "CW",
      "indices" : [ 87, 90 ]
    }, {
      "text" : "HW15",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628185172463255553",
  "text" : "So far I written well over 10,000 words, and I am just getting started #ThisIsOU #WIMF #CW #HW15 http:\/\/t.co\/rhjwE7HJRf",
  "id" : 628185172463255553,
  "created_at" : "2015-08-03 12:46:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628184840303714304",
  "text" : "RT @chknfriedsteak: @gamer456148 my only sincere hope for this person is that they find Jesus.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "627240380778479616",
    "geo" : { },
    "id_str" : "627269423871582208",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 my only sincere hope for this person is that they find Jesus.",
    "id" : 627269423871582208,
    "in_reply_to_status_id" : 627240380778479616,
    "created_at" : "2015-08-01 00:07:39 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 628184840303714304,
  "created_at" : "2015-08-03 12:45:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1stBDay",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "Family",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627656802172170240",
  "text" : "I had an awesome time with some little ones today #1stBDay #Family",
  "id" : 627656802172170240,
  "created_at" : "2015-08-02 01:46:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627265475920015361",
  "text" : "@JosefLokmani If they think like that, they are entirely brain dead",
  "id" : 627265475920015361,
  "created_at" : "2015-07-31 23:51:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/qiwLqtkMkf",
      "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/623245117776723968",
      "display_url" : "twitter.com\/YoungCons\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627242490391851008",
  "text" : "RT @hannahbleau_: Seriously though.  https:\/\/t.co\/qiwLqtkMkf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/qiwLqtkMkf",
        "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/623245117776723968",
        "display_url" : "twitter.com\/YoungCons\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623271008653344768",
    "text" : "Seriously though.  https:\/\/t.co\/qiwLqtkMkf",
    "id" : 623271008653344768,
    "created_at" : "2015-07-20 23:19:22 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 627242490391851008,
  "created_at" : "2015-07-31 22:20:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627240670097358848",
  "text" : "I don't care about the fact that Dr.Walter Palmer killed a lion, what is a bigger issue is that he was charged with sexual harassment",
  "id" : 627240670097358848,
  "created_at" : "2015-07-31 22:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/627240380778479616\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/sy0Uafa9LB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLRnzXEUkAAKkfR.jpg",
      "id_str" : "627240380174471168",
      "id" : 627240380174471168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLRnzXEUkAAKkfR.jpg",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 872
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 872
      } ],
      "display_url" : "pic.twitter.com\/sy0Uafa9LB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627240380778479616",
  "text" : "What type of sicko would type something like this? http:\/\/t.co\/sy0Uafa9LB",
  "id" : 627240380778479616,
  "created_at" : "2015-07-31 22:12:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]