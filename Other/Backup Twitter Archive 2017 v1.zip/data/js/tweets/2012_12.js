Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/zXcVR2dM",
      "expanded_url" : "http:\/\/youtu.be\/P_r8pDziQKE?a",
      "display_url" : "youtu.be\/P_r8pDziQKE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285613247221096448",
  "text" : "I liked a @YouTube video http:\/\/t.co\/zXcVR2dM Celine Dion - Because you loved me",
  "id" : 285613247221096448,
  "created_at" : "2012-12-31 05:07:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/nvnGynXc",
      "expanded_url" : "http:\/\/youtu.be\/-Y9n5_EAivg?a",
      "display_url" : "youtu.be\/-Y9n5_EAivg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285603126558466049",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/nvnGynXc SEFMD 2013 Abstract Presentation",
  "id" : 285603126558466049,
  "created_at" : "2012-12-31 04:27:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/nvnGynXc",
      "expanded_url" : "http:\/\/youtu.be\/-Y9n5_EAivg?a",
      "display_url" : "youtu.be\/-Y9n5_EAivg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285598126046314497",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/nvnGynXc SEFMD 2013 Abstract Presentation",
  "id" : 285598126046314497,
  "created_at" : "2012-12-31 04:07:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/UAaori4q",
      "expanded_url" : "http:\/\/youtu.be\/9hF9y1VLS74?a",
      "display_url" : "youtu.be\/9hF9y1VLS74?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285568586913816577",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/UAaori4q Playing Wall Pong in Celebration of our 250th Upload!!!",
  "id" : 285568586913816577,
  "created_at" : "2012-12-31 02:10:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/kAcPNH4e",
      "expanded_url" : "http:\/\/apps.facebook.com\/kartfighterworldtour\/",
      "display_url" : "apps.facebook.com\/kartfighterwor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285548510105960448",
  "text" : "I just won a new Achievement on Kart Fighter World Tour: http:\/\/t.co\/kAcPNH4e",
  "id" : 285548510105960448,
  "created_at" : "2012-12-31 00:50:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WL8cuvXL",
      "expanded_url" : "http:\/\/youtu.be\/G8kwmuu5Q5M?a",
      "display_url" : "youtu.be\/G8kwmuu5Q5M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285532108196290560",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/WL8cuvXL REMORSE FOR AN UNCLE",
  "id" : 285532108196290560,
  "created_at" : "2012-12-30 23:45:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/PNMOeCoM",
      "expanded_url" : "http:\/\/youtu.be\/L6HHxVZMU3k?a",
      "display_url" : "youtu.be\/L6HHxVZMU3k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285518805457838080",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/PNMOeCoM Redesigning the De Vinci Flying Machine",
  "id" : 285518805457838080,
  "created_at" : "2012-12-30 22:52:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/PNMOeCoM",
      "expanded_url" : "http:\/\/youtu.be\/L6HHxVZMU3k?a",
      "display_url" : "youtu.be\/L6HHxVZMU3k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285518806921666561",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/PNMOeCoM Redesigning the De Vinci Flying Machine",
  "id" : 285518806921666561,
  "created_at" : "2012-12-30 22:52:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/0uOzkwP1",
      "expanded_url" : "http:\/\/youtu.be\/FY1ORFrur5o?a",
      "display_url" : "youtu.be\/FY1ORFrur5o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "285492566181429248",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/0uOzkwP1 Artist Representation of Me",
  "id" : 285492566181429248,
  "created_at" : "2012-12-30 21:08:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/TVnVnvxS",
      "expanded_url" : "http:\/\/youtu.be\/apnjg-gm5nY?a",
      "display_url" : "youtu.be\/apnjg-gm5nY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284829877457264640",
  "text" : "I liked a @YouTube video http:\/\/t.co\/TVnVnvxS Merry NeXmas from Y4Y4",
  "id" : 284829877457264640,
  "created_at" : "2012-12-29 01:15:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/RfGHdnWF",
      "expanded_url" : "http:\/\/youtu.be\/CTAIb9gEVis?a",
      "display_url" : "youtu.be\/CTAIb9gEVis?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284829474497916929",
  "text" : "I liked a @YouTube video http:\/\/t.co\/RfGHdnWF Crossfire gameplay episodio 13 ( sobreviviendo fin del mundo )",
  "id" : 284829474497916929,
  "created_at" : "2012-12-29 01:13:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/57LxllkX",
      "expanded_url" : "http:\/\/youtu.be\/qSTHEjh-89w?a",
      "display_url" : "youtu.be\/qSTHEjh-89w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284829000382164992",
  "text" : "I liked a @YouTube video http:\/\/t.co\/57LxllkX Grand Theft Auto San Andreas iPhone\/iPad Gameplay V2",
  "id" : 284829000382164992,
  "created_at" : "2012-12-29 01:11:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/JTkGmhnz",
      "expanded_url" : "http:\/\/youtu.be\/PVH714w0Vn0?a",
      "display_url" : "youtu.be\/PVH714w0Vn0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284828492556812288",
  "text" : "I liked a @YouTube video http:\/\/t.co\/JTkGmhnz Unadapted OCE EDIT: Lift Lakai",
  "id" : 284828492556812288,
  "created_at" : "2012-12-29 01:09:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/PfShGadb",
      "expanded_url" : "http:\/\/youtu.be\/Hw5qCt0W0rk?a",
      "display_url" : "youtu.be\/Hw5qCt0W0rk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284828171881299968",
  "text" : "I liked a @YouTube video from @mirshuebahmed http:\/\/t.co\/PfShGadb Unreal Tournament Gameplay",
  "id" : 284828171881299968,
  "created_at" : "2012-12-29 01:08:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/HzvZRTAs",
      "expanded_url" : "http:\/\/youtu.be\/VdNceZSgNu8?a",
      "display_url" : "youtu.be\/VdNceZSgNu8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284827758973054976",
  "text" : "I liked a @YouTube video http:\/\/t.co\/HzvZRTAs Far cry 3 PC gameplay ***MAXED OUT*** CRISP CLEAR HD",
  "id" : 284827758973054976,
  "created_at" : "2012-12-29 01:06:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/bODxylK0",
      "expanded_url" : "http:\/\/youtu.be\/gtSVP0_YiZM?a",
      "display_url" : "youtu.be\/gtSVP0_YiZM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284827373319356416",
  "text" : "I liked a @YouTube video http:\/\/t.co\/bODxylK0 EpiDemiks - death worm Jimi",
  "id" : 284827373319356416,
  "created_at" : "2012-12-29 01:05:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/4iEclRHo",
      "expanded_url" : "http:\/\/youtu.be\/6Zc57eTNP7Y?a",
      "display_url" : "youtu.be\/6Zc57eTNP7Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284826910414995456",
  "text" : "I liked a @YouTube video from @iamjayquaun http:\/\/t.co\/4iEclRHo Wiz Khalifa - Bed Rest Freestyle (Remix) by JayQuaun!!!!",
  "id" : 284826910414995456,
  "created_at" : "2012-12-29 01:03:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Z6etvaBd",
      "expanded_url" : "http:\/\/youtu.be\/4GA_uOXbmNE?a",
      "display_url" : "youtu.be\/4GA_uOXbmNE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284716743874707457",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Z6etvaBd My little siz",
  "id" : 284716743874707457,
  "created_at" : "2012-12-28 17:45:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/MGFqiQVL",
      "expanded_url" : "http:\/\/youtu.be\/2ieZcad1n9M?a",
      "display_url" : "youtu.be\/2ieZcad1n9M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284454336187232257",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/MGFqiQVL 360 Degree View of Detroit (Motor City)",
  "id" : 284454336187232257,
  "created_at" : "2012-12-28 00:22:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XHJw4zXu",
      "expanded_url" : "http:\/\/youtu.be\/8TULE6geSuw?a",
      "display_url" : "youtu.be\/8TULE6geSuw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284450318610227200",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XHJw4zXu FULL BLUE MOON",
  "id" : 284450318610227200,
  "created_at" : "2012-12-28 00:06:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gcE7bej9",
      "expanded_url" : "http:\/\/youtu.be\/htR13s3W65w?a",
      "display_url" : "youtu.be\/htR13s3W65w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284396185052123136",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/gcE7bej9 Scenario IQ Game and Mind Trainer Video Game High Score",
  "id" : 284396185052123136,
  "created_at" : "2012-12-27 20:31:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/EXquHiUN",
      "expanded_url" : "http:\/\/youtu.be\/SUOsTT8OcdE?a",
      "display_url" : "youtu.be\/SUOsTT8OcdE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "284001247600713729",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/EXquHiUN Wii Storage Tower Unboxing Photos",
  "id" : 284001247600713729,
  "created_at" : "2012-12-26 18:22:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/X7kUK3OS",
      "expanded_url" : "http:\/\/youtu.be\/Sg11KLgm24M?a",
      "display_url" : "youtu.be\/Sg11KLgm24M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283999916471222273",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/X7kUK3OS My Comics and Magazine Collection",
  "id" : 283999916471222273,
  "created_at" : "2012-12-26 18:17:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/E4kpjLfA",
      "expanded_url" : "http:\/\/youtu.be\/NOhwVgGMmQc?a",
      "display_url" : "youtu.be\/NOhwVgGMmQc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283959962659606528",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/E4kpjLfA Free Promo Giveaway",
  "id" : 283959962659606528,
  "created_at" : "2012-12-26 15:38:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 12, 20 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/NQuOKZ7s",
      "expanded_url" : "http:\/\/youtu.be\/V7WtVJSJQaM?a",
      "display_url" : "youtu.be\/V7WtVJSJQaM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283950119580225536",
  "text" : "Its not :P (@YouTube http:\/\/t.co\/NQuOKZ7s)",
  "id" : 283950119580225536,
  "created_at" : "2012-12-26 14:59:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/inuYfjl8",
      "expanded_url" : "http:\/\/youtu.be\/313uecy8-Gk?a",
      "display_url" : "youtu.be\/313uecy8-Gk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283800644106739715",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/inuYfjl8 Inventions",
  "id" : 283800644106739715,
  "created_at" : "2012-12-26 05:05:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/inuYfjl8",
      "expanded_url" : "http:\/\/youtu.be\/313uecy8-Gk?a",
      "display_url" : "youtu.be\/313uecy8-Gk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283800593162727424",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/inuYfjl8 Inventions",
  "id" : 283800593162727424,
  "created_at" : "2012-12-26 05:05:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/sxjiTNfh",
      "expanded_url" : "http:\/\/youtu.be\/DhUvSvuuWII?a",
      "display_url" : "youtu.be\/DhUvSvuuWII?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283796497202548736",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/sxjiTNfh NUMERIX APP REVIEW",
  "id" : 283796497202548736,
  "created_at" : "2012-12-26 04:48:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/rxQZATFB",
      "expanded_url" : "http:\/\/youtu.be\/9CLrUseL08M?a",
      "display_url" : "youtu.be\/9CLrUseL08M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283778947467079680",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/rxQZATFB First Time Playing MineCraft",
  "id" : 283778947467079680,
  "created_at" : "2012-12-26 03:39:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ukrq6qyJ",
      "expanded_url" : "http:\/\/youtu.be\/TG1wMIM58wg?a",
      "display_url" : "youtu.be\/TG1wMIM58wg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283641919530229760",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ukrq6qyJ Highest Score on Digi Drop the Video Game",
  "id" : 283641919530229760,
  "created_at" : "2012-12-25 18:34:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/jyiMh7kw",
      "expanded_url" : "http:\/\/youtu.be\/3DFlPiZekqU?a",
      "display_url" : "youtu.be\/3DFlPiZekqU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283381736656740352",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/jyiMh7kw Contract Killer (The Video Game)",
  "id" : 283381736656740352,
  "created_at" : "2012-12-25 01:20:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/59CQwSnp",
      "expanded_url" : "http:\/\/youtu.be\/p1PcH1WaMsM?a",
      "display_url" : "youtu.be\/p1PcH1WaMsM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283368230733623296",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/59CQwSnp Canoon Defense Video Game",
  "id" : 283368230733623296,
  "created_at" : "2012-12-25 00:27:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/j1XrrZvV",
      "expanded_url" : "http:\/\/youtu.be\/1OT_NqKzTMQ?a",
      "display_url" : "youtu.be\/1OT_NqKzTMQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283340936241639424",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/j1XrrZvV How to Play Zombie Madness, (The Video Game)",
  "id" : 283340936241639424,
  "created_at" : "2012-12-24 22:38:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/eKeEymo0",
      "expanded_url" : "http:\/\/youtu.be\/2j1osfWWfvY?a",
      "display_url" : "youtu.be\/2j1osfWWfvY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283271576269508610",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/eKeEymo0 GP2x Wiz Unboxing",
  "id" : 283271576269508610,
  "created_at" : "2012-12-24 18:03:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/rrE9Hynu",
      "expanded_url" : "http:\/\/youtu.be\/5CYbXsZOpPc?a",
      "display_url" : "youtu.be\/5CYbXsZOpPc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283261698645831680",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/rrE9Hynu Nintendo 3DS vs. DSI XL (Tied Gaming-Wise)",
  "id" : 283261698645831680,
  "created_at" : "2012-12-24 17:23:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ipu0WpyE",
      "expanded_url" : "http:\/\/youtu.be\/K0M9rDgav_o?a",
      "display_url" : "youtu.be\/K0M9rDgav_o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283259625946640384",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ipu0WpyE Wowee Light Stike Review (Cheaper Alternative to Portals 2 Gun)",
  "id" : 283259625946640384,
  "created_at" : "2012-12-24 17:15:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 8, 16 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/qiCClWA8",
      "expanded_url" : "http:\/\/youtu.be\/yie_wTnhMTA?a",
      "display_url" : "youtu.be\/yie_wTnhMTA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "283057974346407936",
  "text" : "awsome (@YouTube http:\/\/t.co\/qiCClWA8)",
  "id" : 283057974346407936,
  "created_at" : "2012-12-24 03:54:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/FTiHHdw0",
      "expanded_url" : "http:\/\/youtu.be\/lskgWmsySmw?a",
      "display_url" : "youtu.be\/lskgWmsySmw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282653850295488513",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/FTiHHdw0 My Angry Birds Space Score",
  "id" : 282653850295488513,
  "created_at" : "2012-12-23 01:08:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/yhe0ESGl",
      "expanded_url" : "http:\/\/youtu.be\/-5H4AyYsnmI?a",
      "display_url" : "youtu.be\/-5H4AyYsnmI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282643215272796161",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/yhe0ESGl What is My Angry Birds Star Wars Score",
  "id" : 282643215272796161,
  "created_at" : "2012-12-23 00:26:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/diO40H0n",
      "expanded_url" : "http:\/\/youtu.be\/SdCg2spG6Zk?a",
      "display_url" : "youtu.be\/SdCg2spG6Zk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282602419018399745",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/diO40H0n My Inventions",
  "id" : 282602419018399745,
  "created_at" : "2012-12-22 21:44:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/diO40H0n",
      "expanded_url" : "http:\/\/youtu.be\/SdCg2spG6Zk?a",
      "display_url" : "youtu.be\/SdCg2spG6Zk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282597695619747840",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/diO40H0n My Inventions",
  "id" : 282597695619747840,
  "created_at" : "2012-12-22 21:25:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6MzVpHMv",
      "expanded_url" : "http:\/\/youtu.be\/Ym_eB3rZZD4?a",
      "display_url" : "youtu.be\/Ym_eB3rZZD4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282595050234449920",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6MzVpHMv My Quirky Inventions",
  "id" : 282595050234449920,
  "created_at" : "2012-12-22 21:14:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/6MzVpHMv",
      "expanded_url" : "http:\/\/youtu.be\/Ym_eB3rZZD4?a",
      "display_url" : "youtu.be\/Ym_eB3rZZD4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282594870546296834",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6MzVpHMv My Quirky Inventions",
  "id" : 282594870546296834,
  "created_at" : "2012-12-22 21:14:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/t8y3ZKpD",
      "expanded_url" : "http:\/\/youtu.be\/C7KArcH6X1I?a",
      "display_url" : "youtu.be\/C7KArcH6X1I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282577236786311168",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/t8y3ZKpD My Angry Birds Score",
  "id" : 282577236786311168,
  "created_at" : "2012-12-22 20:03:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/L2w9e2XV",
      "expanded_url" : "http:\/\/youtu.be\/yC9ccvxqlXI?a",
      "display_url" : "youtu.be\/yC9ccvxqlXI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282552268509822976",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/L2w9e2XV Thanks Team Steam USA",
  "id" : 282552268509822976,
  "created_at" : "2012-12-22 18:24:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/yCMP2bdA",
      "expanded_url" : "http:\/\/youtu.be\/WnPnGYht7BM?a",
      "display_url" : "youtu.be\/WnPnGYht7BM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282541890056900608",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/yCMP2bdA The Future of Green Technology",
  "id" : 282541890056900608,
  "created_at" : "2012-12-22 17:43:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/yCMP2bdA",
      "expanded_url" : "http:\/\/youtu.be\/WnPnGYht7BM?a",
      "display_url" : "youtu.be\/WnPnGYht7BM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282541800068091905",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/yCMP2bdA The Future of Green Technology",
  "id" : 282541800068091905,
  "created_at" : "2012-12-22 17:43:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gsywtthD",
      "expanded_url" : "http:\/\/youtu.be\/OzyHic7qo84?a",
      "display_url" : "youtu.be\/OzyHic7qo84?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282541033387085824",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/gsywtthD Weird Photos of the Sky",
  "id" : 282541033387085824,
  "created_at" : "2012-12-22 17:40:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/GjRPWwo9",
      "expanded_url" : "http:\/\/youtu.be\/aZnmoWlwEPI?a",
      "display_url" : "youtu.be\/aZnmoWlwEPI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282332887154556928",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/GjRPWwo9 Nokia Lumia 710 Overview",
  "id" : 282332887154556928,
  "created_at" : "2012-12-22 03:53:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gNqk6fGa",
      "expanded_url" : "http:\/\/youtu.be\/ChQf5j22zwo?a",
      "display_url" : "youtu.be\/ChQf5j22zwo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282314758479290368",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/gNqk6fGa Windows Phone Integrated Chat Settings",
  "id" : 282314758479290368,
  "created_at" : "2012-12-22 02:40:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/XWvtldm2",
      "expanded_url" : "http:\/\/youtu.be\/r8ijwjcQ94c?a",
      "display_url" : "youtu.be\/r8ijwjcQ94c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282279005657382913",
  "text" : "I also recently downloaded YouTube downloader and PrimeTube to my lumia 710, I rate those 5\/5 (@YouTube http:\/\/t.co\/XWvtldm2)",
  "id" : 282279005657382913,
  "created_at" : "2012-12-22 00:18:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/1NSTHMgw",
      "expanded_url" : "http:\/\/youtu.be\/UceF_8i8GyY?a",
      "display_url" : "youtu.be\/UceF_8i8GyY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282273390423838720",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/1NSTHMgw Just a Few of the Windows Phone Apps",
  "id" : 282273390423838720,
  "created_at" : "2012-12-21 23:56:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/WR6Z2Sgw",
      "expanded_url" : "http:\/\/youtu.be\/h4GhD2s0iV0?a",
      "display_url" : "youtu.be\/h4GhD2s0iV0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282273333632983040",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/WR6Z2Sgw Massive UFO Sightings on December 21st, 2012",
  "id" : 282273333632983040,
  "created_at" : "2012-12-21 23:56:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ZpUWVHVn",
      "expanded_url" : "http:\/\/youtu.be\/mfk9qpAgEYY?a",
      "display_url" : "youtu.be\/mfk9qpAgEYY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282255553512751104",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ZpUWVHVn Join my Website",
  "id" : 282255553512751104,
  "created_at" : "2012-12-21 22:45:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WR6Z2Sgw",
      "expanded_url" : "http:\/\/youtu.be\/h4GhD2s0iV0?a",
      "display_url" : "youtu.be\/h4GhD2s0iV0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282248507677605888",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/WR6Z2Sgw Massive UFO Sightings on December 21st, 2012",
  "id" : 282248507677605888,
  "created_at" : "2012-12-21 22:17:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/KUjm0tPX",
      "expanded_url" : "http:\/\/youtu.be\/DYcWFEmex00?a",
      "display_url" : "youtu.be\/DYcWFEmex00?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282239555246120960",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/KUjm0tPX S-34 App Review",
  "id" : 282239555246120960,
  "created_at" : "2012-12-21 21:42:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XWvtldm2",
      "expanded_url" : "http:\/\/youtu.be\/r8ijwjcQ94c?a",
      "display_url" : "youtu.be\/r8ijwjcQ94c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282238445055787009",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XWvtldm2 AR Paintball App Review",
  "id" : 282238445055787009,
  "created_at" : "2012-12-21 21:37:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/GNcwI8xM",
      "expanded_url" : "http:\/\/youtu.be\/8JOfpIWx9MI?a",
      "display_url" : "youtu.be\/8JOfpIWx9MI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282207668490338305",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/GNcwI8xM Wandarama Trial 1",
  "id" : 282207668490338305,
  "created_at" : "2012-12-21 19:35:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/B7B6pKnC",
      "expanded_url" : "http:\/\/youtu.be\/SxH-rbz6jDo?a",
      "display_url" : "youtu.be\/SxH-rbz6jDo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282207274653605889",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/B7B6pKnC My Little Sis Trying to Fly a RC Helicopter",
  "id" : 282207274653605889,
  "created_at" : "2012-12-21 19:33:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/7iwfQKya",
      "expanded_url" : "http:\/\/youtu.be\/XCO7FoxlPIQ?a",
      "display_url" : "youtu.be\/XCO7FoxlPIQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282156566948478976",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/7iwfQKya BOINC Projects (Latest)",
  "id" : 282156566948478976,
  "created_at" : "2012-12-21 16:12:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7iwfQKya",
      "expanded_url" : "http:\/\/youtu.be\/XCO7FoxlPIQ?a",
      "display_url" : "youtu.be\/XCO7FoxlPIQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "282156296172605441",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/7iwfQKya BOINC Projects (Latest)",
  "id" : 282156296172605441,
  "created_at" : "2012-12-21 16:11:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 34, 42 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/nBTS9VA2",
      "expanded_url" : "http:\/\/youtu.be\/DetYqpaoHak?a",
      "display_url" : "youtu.be\/DetYqpaoHak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281900599061135360",
  "text" : "this is the truth @MrGamer456148 (@YouTube http:\/\/t.co\/nBTS9VA2)",
  "id" : 281900599061135360,
  "created_at" : "2012-12-20 23:15:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 51, 59 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/nBTS9VA2",
      "expanded_url" : "http:\/\/youtu.be\/DetYqpaoHak?a",
      "display_url" : "youtu.be\/DetYqpaoHak?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281900514826924032",
  "text" : "obama is the first horse rider and the antichrist (@YouTube http:\/\/t.co\/nBTS9VA2)",
  "id" : 281900514826924032,
  "created_at" : "2012-12-20 23:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/XGcHvzg4",
      "expanded_url" : "http:\/\/youtu.be\/hH60TtX2n5A?a",
      "display_url" : "youtu.be\/hH60TtX2n5A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281899947757019136",
  "text" : "Obama is the first horse rider defined in revelations, he is the antichrist (@YouTube http:\/\/t.co\/XGcHvzg4)",
  "id" : 281899947757019136,
  "created_at" : "2012-12-20 23:12:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/uYkP1Lk9",
      "expanded_url" : "http:\/\/youtu.be\/-5D9CQbWNjQ?a",
      "display_url" : "youtu.be\/-5D9CQbWNjQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281625348171501568",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/uYkP1Lk9 Angelic Face Appears Next to Painting of God",
  "id" : 281625348171501568,
  "created_at" : "2012-12-20 05:01:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/e3XxBpi4",
      "expanded_url" : "http:\/\/youtu.be\/ZFUUtGVsEOE?a",
      "display_url" : "youtu.be\/ZFUUtGVsEOE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281624585366032384",
  "text" : "I liked a @YouTube video http:\/\/t.co\/e3XxBpi4 Mountain - Mississippi Queen live @ Randall's Island N.Y 1970",
  "id" : 281624585366032384,
  "created_at" : "2012-12-20 04:58:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ZQdyy7F2",
      "expanded_url" : "http:\/\/youtu.be\/WeWEBDCj868?a",
      "display_url" : "youtu.be\/WeWEBDCj868?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281589813029769216",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ZQdyy7F2 Nokia Lumia Unboxing",
  "id" : 281589813029769216,
  "created_at" : "2012-12-20 02:40:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/4HDXbXBU",
      "expanded_url" : "http:\/\/youtu.be\/V35kL2OwdbY?a",
      "display_url" : "youtu.be\/V35kL2OwdbY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281476422026018816",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/4HDXbXBU Best of \"Rock n Roll\"",
  "id" : 281476422026018816,
  "created_at" : "2012-12-19 19:09:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/4HDXbXBU",
      "expanded_url" : "http:\/\/youtu.be\/V35kL2OwdbY?a",
      "display_url" : "youtu.be\/V35kL2OwdbY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281476051085975555",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/4HDXbXBU Best of \"Rock n Roll\"",
  "id" : 281476051085975555,
  "created_at" : "2012-12-19 19:08:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/cjER7XZZ",
      "expanded_url" : "http:\/\/youtu.be\/-u7LtiPIZLU?a",
      "display_url" : "youtu.be\/-u7LtiPIZLU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281427995426693122",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/cjER7XZZ Proud Mary \"AMKAMAL\" Coverup",
  "id" : 281427995426693122,
  "created_at" : "2012-12-19 15:57:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/cjER7XZZ",
      "expanded_url" : "http:\/\/youtu.be\/-u7LtiPIZLU?a",
      "display_url" : "youtu.be\/-u7LtiPIZLU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281427843647406081",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/cjER7XZZ Proud Mary \"AMKAMAL\" Coverup",
  "id" : 281427843647406081,
  "created_at" : "2012-12-19 15:56:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/SyfNNTGD",
      "expanded_url" : "http:\/\/youtu.be\/826HGVl8qss?a",
      "display_url" : "youtu.be\/826HGVl8qss?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281391709970112512",
  "text" : "Really Troy (@YouTube http:\/\/t.co\/SyfNNTGD)",
  "id" : 281391709970112512,
  "created_at" : "2012-12-19 13:33:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/4c9JxpFn",
      "expanded_url" : "http:\/\/youtu.be\/466hzgF1C8o?a",
      "display_url" : "youtu.be\/466hzgF1C8o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281242057220177920",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/4c9JxpFn My Full Google Science Fair Presintation Video Entry",
  "id" : 281242057220177920,
  "created_at" : "2012-12-19 03:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/esyOJo6v",
      "expanded_url" : "http:\/\/youtu.be\/tyHNHlkr0mw?a",
      "display_url" : "youtu.be\/tyHNHlkr0mw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281242058461700096",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/esyOJo6v Google Science Fair Project -Pics",
  "id" : 281242058461700096,
  "created_at" : "2012-12-19 03:38:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/o2g78uEU",
      "expanded_url" : "http:\/\/youtu.be\/D_FKOJFiUXc?a",
      "display_url" : "youtu.be\/D_FKOJFiUXc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281242055852834816",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/o2g78uEU Google Science Project",
  "id" : 281242055852834816,
  "created_at" : "2012-12-19 03:38:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/5O3H4cHf",
      "expanded_url" : "http:\/\/youtu.be\/jYXpTs_x6UE?a",
      "display_url" : "youtu.be\/jYXpTs_x6UE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281242038601674752",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/5O3H4cHf Full Google Science Fair Project Demonstration",
  "id" : 281242038601674752,
  "created_at" : "2012-12-19 03:38:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/XQJHXCww",
      "expanded_url" : "http:\/\/youtu.be\/lXJFHtmS2LU?a",
      "display_url" : "youtu.be\/lXJFHtmS2LU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241728558702593",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/XQJHXCww FHB Galaxies (As Seen on the Discovery Channel)",
  "id" : 281241728558702593,
  "created_at" : "2012-12-19 03:37:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/nala8zJH",
      "expanded_url" : "http:\/\/youtu.be\/b8kd212F4Xk?a",
      "display_url" : "youtu.be\/b8kd212F4Xk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241690289864705",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/nala8zJH My Invention USA Audition",
  "id" : 281241690289864705,
  "created_at" : "2012-12-19 03:36:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/k5uiC7jV",
      "expanded_url" : "http:\/\/youtu.be\/oon5JEKKsqo?a",
      "display_url" : "youtu.be\/oon5JEKKsqo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241599445463041",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/k5uiC7jV My Designs",
  "id" : 281241599445463041,
  "created_at" : "2012-12-19 03:36:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/eLMMSsy4",
      "expanded_url" : "http:\/\/youtu.be\/z5DTE6tRzjY?a",
      "display_url" : "youtu.be\/z5DTE6tRzjY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241598220713984",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/eLMMSsy4 My Second Invention USA Audition",
  "id" : 281241598220713984,
  "created_at" : "2012-12-19 03:36:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/JYbViRVm",
      "expanded_url" : "http:\/\/youtu.be\/-luPeMx_wic?a",
      "display_url" : "youtu.be\/-luPeMx_wic?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241550158172160",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/JYbViRVm Building an Ionizer Part I",
  "id" : 281241550158172160,
  "created_at" : "2012-12-19 03:36:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/XSys7nAt",
      "expanded_url" : "http:\/\/youtu.be\/jnM91xJoEMk?a",
      "display_url" : "youtu.be\/jnM91xJoEMk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241514363981825",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/XSys7nAt Best Physics Projects Where I Was There",
  "id" : 281241514363981825,
  "created_at" : "2012-12-19 03:36:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/o1dnPq1a",
      "expanded_url" : "http:\/\/youtu.be\/6fl9_P2Oz7Q?a",
      "display_url" : "youtu.be\/6fl9_P2Oz7Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241498014588929",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/o1dnPq1a Crevolution 2851 - Cerberus 2010 - Drive system",
  "id" : 281241498014588929,
  "created_at" : "2012-12-19 03:36:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/gCGISKOZ",
      "expanded_url" : "http:\/\/youtu.be\/5NsHn6v2B7U?a",
      "display_url" : "youtu.be\/5NsHn6v2B7U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241402057306113",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/gCGISKOZ RC Vehicle Attachment (Design Concept)",
  "id" : 281241402057306113,
  "created_at" : "2012-12-19 03:35:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/FG5zlNSq",
      "expanded_url" : "http:\/\/youtu.be\/w-0l4GbiY1k?a",
      "display_url" : "youtu.be\/w-0l4GbiY1k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241230271193088",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/FG5zlNSq Fully Trademarked Video",
  "id" : 281241230271193088,
  "created_at" : "2012-12-19 03:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ys1Vmuno",
      "expanded_url" : "http:\/\/youtu.be\/aSbVgtu1cEI?a",
      "display_url" : "youtu.be\/aSbVgtu1cEI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241231927951360",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ys1Vmuno My Latest Inventions &amp; Audition for Inventor Shows",
  "id" : 281241231927951360,
  "created_at" : "2012-12-19 03:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/gCGISKOZ",
      "expanded_url" : "http:\/\/youtu.be\/5NsHn6v2B7U?a",
      "display_url" : "youtu.be\/5NsHn6v2B7U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241226685075456",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/gCGISKOZ RC Vehicle Attachment (Design Concept)",
  "id" : 281241226685075456,
  "created_at" : "2012-12-19 03:35:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/hZjO6Vr9",
      "expanded_url" : "http:\/\/youtu.be\/uW1PD8bPdSI?a",
      "display_url" : "youtu.be\/uW1PD8bPdSI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281241228647993344",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/hZjO6Vr9 My Latest Model Rocket",
  "id" : 281241228647993344,
  "created_at" : "2012-12-19 03:35:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/AUOtWBQK",
      "expanded_url" : "http:\/\/youtu.be\/GIIvpL-1M_E?a",
      "display_url" : "youtu.be\/GIIvpL-1M_E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281207410268442625",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/AUOtWBQK Light Racer 3D Highest Score Attempt",
  "id" : 281207410268442625,
  "created_at" : "2012-12-19 01:20:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/ozA0RZJP",
      "expanded_url" : "http:\/\/youtu.be\/CxDFR5lKCNE?a",
      "display_url" : "youtu.be\/CxDFR5lKCNE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281190708117909504",
  "text" : "I love republicans, they are what we need to make this country better. Also the last time a (@YouTube http:\/\/t.co\/ozA0RZJP)",
  "id" : 281190708117909504,
  "created_at" : "2012-12-19 00:14:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/D8e0XsVM",
      "expanded_url" : "http:\/\/youtu.be\/drR3t33fqdY?a",
      "display_url" : "youtu.be\/drR3t33fqdY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281189761413165057",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/D8e0XsVM How to Play Destructo Truck",
  "id" : 281189761413165057,
  "created_at" : "2012-12-19 00:10:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/GXApl55H",
      "expanded_url" : "http:\/\/youtu.be\/JvYuEQkupgA?a",
      "display_url" : "youtu.be\/JvYuEQkupgA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281189352606932993",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/GXApl55H Lost Nuke Levels 1&amp;2",
  "id" : 281189352606932993,
  "created_at" : "2012-12-19 00:09:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Just Planes",
      "screen_name" : "justplanes",
      "indices" : [ 30, 41 ],
      "id_str" : "33149259",
      "id" : 33149259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/RYwBKcbO",
      "expanded_url" : "http:\/\/youtu.be\/Ma-q0MVfYA4?a",
      "display_url" : "youtu.be\/Ma-q0MVfYA4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281174286230761472",
  "text" : "I liked a @YouTube video from @justplanes http:\/\/t.co\/RYwBKcbO Boeing 787 Dreamliner Inside &amp; Out! (Teaser)",
  "id" : 281174286230761472,
  "created_at" : "2012-12-18 23:09:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/hZjO6Vr9",
      "expanded_url" : "http:\/\/youtu.be\/uW1PD8bPdSI?a",
      "display_url" : "youtu.be\/uW1PD8bPdSI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281171976096198656",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/hZjO6Vr9 My Latest Model Rocket",
  "id" : 281171976096198656,
  "created_at" : "2012-12-18 22:59:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/m1ZS6Rf0",
      "expanded_url" : "http:\/\/youtu.be\/JF4iqNhyZTY?a",
      "display_url" : "youtu.be\/JF4iqNhyZTY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281139255445692417",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/m1ZS6Rf0 Street Racer Test 1 Marble",
  "id" : 281139255445692417,
  "created_at" : "2012-12-18 20:49:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/A0uQCYGl",
      "expanded_url" : "http:\/\/youtu.be\/6nnRoIf-YL0?a",
      "display_url" : "youtu.be\/6nnRoIf-YL0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281136565630156800",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/A0uQCYGl Street Racer Test 3 Carpet",
  "id" : 281136565630156800,
  "created_at" : "2012-12-18 20:39:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/dFrSga4B",
      "expanded_url" : "http:\/\/youtu.be\/yIqGRR70SVo?a",
      "display_url" : "youtu.be\/yIqGRR70SVo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281135304914657281",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/dFrSga4B Street Racer Test 2 Carpet",
  "id" : 281135304914657281,
  "created_at" : "2012-12-18 20:34:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/vljkwzJI",
      "expanded_url" : "http:\/\/youtu.be\/MnVlJLCnxg0?a",
      "display_url" : "youtu.be\/MnVlJLCnxg0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281133825952739328",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/vljkwzJI Street Racer Test 1 Carpet",
  "id" : 281133825952739328,
  "created_at" : "2012-12-18 20:28:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/QLX5TFCn",
      "expanded_url" : "http:\/\/youtu.be\/dDlyAMtZY_c?a",
      "display_url" : "youtu.be\/dDlyAMtZY_c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281133218785292288",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/QLX5TFCn Awsome Intro",
  "id" : 281133218785292288,
  "created_at" : "2012-12-18 20:25:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WcVvtUnS",
      "expanded_url" : "http:\/\/youtu.be\/jUFX5dK8atk?a",
      "display_url" : "youtu.be\/jUFX5dK8atk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281115020522315776",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/WcVvtUnS Zombie Trapper Level 5",
  "id" : 281115020522315776,
  "created_at" : "2012-12-18 19:13:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/z5O3Prjw",
      "expanded_url" : "http:\/\/youtu.be\/vbmpI79sGUA?a",
      "display_url" : "youtu.be\/vbmpI79sGUA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281114760248950784",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/z5O3Prjw Zombie Trapper Level 4",
  "id" : 281114760248950784,
  "created_at" : "2012-12-18 19:12:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/mGBgOTtr",
      "expanded_url" : "http:\/\/youtu.be\/7RLmj7Ic9RY?a",
      "display_url" : "youtu.be\/7RLmj7Ic9RY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281114244106293248",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/mGBgOTtr Zombie Trapper Level 3",
  "id" : 281114244106293248,
  "created_at" : "2012-12-18 19:10:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6w1A291G",
      "expanded_url" : "http:\/\/youtu.be\/bL1EOIpOj2Q?a",
      "display_url" : "youtu.be\/bL1EOIpOj2Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281113262639173632",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6w1A291G Zombie Trapper Level 2",
  "id" : 281113262639173632,
  "created_at" : "2012-12-18 19:06:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/silXunck",
      "expanded_url" : "http:\/\/youtu.be\/_G3LXYKHBXU?a",
      "display_url" : "youtu.be\/_G3LXYKHBXU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281112967364362240",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/silXunck Zombie Trapper Level 1",
  "id" : 281112967364362240,
  "created_at" : "2012-12-18 19:05:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/qlhJGevU",
      "expanded_url" : "http:\/\/youtu.be\/a_Ab1wVunj0?a",
      "display_url" : "youtu.be\/a_Ab1wVunj0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281096703908646912",
  "text" : "This is beyond funny (@YouTube http:\/\/t.co\/qlhJGevU)",
  "id" : 281096703908646912,
  "created_at" : "2012-12-18 18:00:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 9, 17 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/qlhJGevU",
      "expanded_url" : "http:\/\/youtu.be\/a_Ab1wVunj0?a",
      "display_url" : "youtu.be\/a_Ab1wVunj0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281096666927472640",
  "text" : "x=Islam (@YouTube http:\/\/t.co\/qlhJGevU)",
  "id" : 281096666927472640,
  "created_at" : "2012-12-18 18:00:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/FG5zlNSq",
      "expanded_url" : "http:\/\/youtu.be\/w-0l4GbiY1k?a",
      "display_url" : "youtu.be\/w-0l4GbiY1k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "281084024993247232",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/FG5zlNSq Fully Trademarked Video",
  "id" : 281084024993247232,
  "created_at" : "2012-12-18 17:10:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/GXGaLWM2",
      "expanded_url" : "http:\/\/youtu.be\/bSoOE9LYz1s?a",
      "display_url" : "youtu.be\/bSoOE9LYz1s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280874741580046336",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/GXGaLWM2 What I got for Hanukkah",
  "id" : 280874741580046336,
  "created_at" : "2012-12-18 03:18:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/PHpLCpot",
      "expanded_url" : "http:\/\/youtu.be\/H5IGqHeQDgg?a",
      "display_url" : "youtu.be\/H5IGqHeQDgg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280751092688646144",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/PHpLCpot Answer to the \"Genius\" Puzzle",
  "id" : 280751092688646144,
  "created_at" : "2012-12-17 19:07:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/ys1Vmuno",
      "expanded_url" : "http:\/\/youtu.be\/aSbVgtu1cEI?a",
      "display_url" : "youtu.be\/aSbVgtu1cEI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280745669856198656",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ys1Vmuno My Latest Inventions &amp; Inventor's Audtion",
  "id" : 280745669856198656,
  "created_at" : "2012-12-17 18:45:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ys1Vmuno",
      "expanded_url" : "http:\/\/youtu.be\/aSbVgtu1cEI?a",
      "display_url" : "youtu.be\/aSbVgtu1cEI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280741823536828416",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ys1Vmuno My Latest Inventions",
  "id" : 280741823536828416,
  "created_at" : "2012-12-17 18:30:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 23, 31 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/v05nBQbo",
      "expanded_url" : "http:\/\/youtu.be\/EOxAThylgo0?a",
      "display_url" : "youtu.be\/EOxAThylgo0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280736937688580096",
  "text" : "I wish I can help you (@YouTube http:\/\/t.co\/v05nBQbo)",
  "id" : 280736937688580096,
  "created_at" : "2012-12-17 18:11:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/UtwV3sLV",
      "expanded_url" : "http:\/\/youtu.be\/CGfc2vBk6JI?a",
      "display_url" : "youtu.be\/CGfc2vBk6JI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280490234112774145",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/UtwV3sLV Storm Ops Flash Demo",
  "id" : 280490234112774145,
  "created_at" : "2012-12-17 01:50:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/BcK2zdOz",
      "expanded_url" : "http:\/\/youtu.be\/G_Me-k-zk6k?a",
      "display_url" : "youtu.be\/G_Me-k-zk6k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280488425394688001",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/BcK2zdOz Call of Duty 2 Flash Demo",
  "id" : 280488425394688001,
  "created_at" : "2012-12-17 01:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/KOEqzXGS",
      "expanded_url" : "http:\/\/youtu.be\/uHQR9EnXc28?a",
      "display_url" : "youtu.be\/uHQR9EnXc28?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280487829690277888",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/KOEqzXGS Call of Duty Flash DEMO",
  "id" : 280487829690277888,
  "created_at" : "2012-12-17 01:41:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/YLAiG2gI",
      "expanded_url" : "http:\/\/youtu.be\/EU7H--USv6Y?a",
      "display_url" : "youtu.be\/EU7H--USv6Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280482552052064256",
  "text" : "I liked a @YouTube video http:\/\/t.co\/YLAiG2gI Creedence Clearwater Revival - Fortunate Son",
  "id" : 280482552052064256,
  "created_at" : "2012-12-17 01:20:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/pE8qtL2q",
      "expanded_url" : "http:\/\/youtu.be\/PYviA_e_Q-o?a",
      "display_url" : "youtu.be\/PYviA_e_Q-o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280481775573147648",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/pE8qtL2q Dead Zed Level 5 Gameplay",
  "id" : 280481775573147648,
  "created_at" : "2012-12-17 01:17:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/a3kLxUKT",
      "expanded_url" : "http:\/\/youtu.be\/S4GFeVLvcn8?a",
      "display_url" : "youtu.be\/S4GFeVLvcn8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280481773987704832",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/a3kLxUKT Dead Zed Levels 3&amp;4 Gameplay",
  "id" : 280481773987704832,
  "created_at" : "2012-12-17 01:17:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/wmMiFSlI",
      "expanded_url" : "http:\/\/youtu.be\/kyd4FQHNRzk?a",
      "display_url" : "youtu.be\/kyd4FQHNRzk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280480374570745856",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/wmMiFSlI Dead Zed Levels 1&amp;2 Gameplay",
  "id" : 280480374570745856,
  "created_at" : "2012-12-17 01:11:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/D3rYuRZW",
      "expanded_url" : "http:\/\/youtu.be\/9vPPbbuc8DQ?a",
      "display_url" : "youtu.be\/9vPPbbuc8DQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280471748871335936",
  "text" : "I liked a @YouTube video http:\/\/t.co\/D3rYuRZW Inflatable spacecraft heat shield ready to launch",
  "id" : 280471748871335936,
  "created_at" : "2012-12-17 00:37:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 29, 37 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/Ye5AUKRK",
      "expanded_url" : "http:\/\/youtu.be\/fsiFEupHVQ8?a",
      "display_url" : "youtu.be\/fsiFEupHVQ8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280471377276964864",
  "text" : "estes made a better version (@YouTube http:\/\/t.co\/Ye5AUKRK)",
  "id" : 280471377276964864,
  "created_at" : "2012-12-17 00:36:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/1WAkN8qV",
      "expanded_url" : "http:\/\/youtu.be\/EPVSzDP0iYI?a",
      "display_url" : "youtu.be\/EPVSzDP0iYI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280470316071919616",
  "text" : "I made one of those before (@YouTube http:\/\/t.co\/1WAkN8qV)",
  "id" : 280470316071919616,
  "created_at" : "2012-12-17 00:31:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/c7cBeRBG",
      "expanded_url" : "http:\/\/youtu.be\/N9xnNN0A7HU?a",
      "display_url" : "youtu.be\/N9xnNN0A7HU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280431598392971265",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/c7cBeRBG Zombie Attack Game Play Demo",
  "id" : 280431598392971265,
  "created_at" : "2012-12-16 21:57:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/HmtRfC0E",
      "expanded_url" : "http:\/\/youtu.be\/r6wT5yBdfgg?a",
      "display_url" : "youtu.be\/r6wT5yBdfgg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280429884222877698",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/HmtRfC0E Sniper Level 1 to 4 Play",
  "id" : 280429884222877698,
  "created_at" : "2012-12-16 21:51:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/hGiQ4At4",
      "expanded_url" : "http:\/\/youtu.be\/W2SFZ4c2pxk?a",
      "display_url" : "youtu.be\/W2SFZ4c2pxk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280425865861554176",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/hGiQ4At4 Palisades Garden Demo",
  "id" : 280425865861554176,
  "created_at" : "2012-12-16 21:35:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/StmCtKYb",
      "expanded_url" : "http:\/\/youtu.be\/oGZd6T_tBCM?a",
      "display_url" : "youtu.be\/oGZd6T_tBCM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280423632512094209",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/StmCtKYb Halo 1 Version Play",
  "id" : 280423632512094209,
  "created_at" : "2012-12-16 21:26:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/r0AkZGfo",
      "expanded_url" : "http:\/\/youtu.be\/DCBEiOE2X54?a",
      "display_url" : "youtu.be\/DCBEiOE2X54?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280417677892268032",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/r0AkZGfo STO Teleportation Demo",
  "id" : 280417677892268032,
  "created_at" : "2012-12-16 21:02:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/kh7dHjeR",
      "expanded_url" : "http:\/\/youtu.be\/0pXqZAm8uz8?a",
      "display_url" : "youtu.be\/0pXqZAm8uz8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280408186870185984",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/kh7dHjeR STO CHARACTER STARTER DEMO",
  "id" : 280408186870185984,
  "created_at" : "2012-12-16 20:24:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u8yeO1PG",
      "expanded_url" : "http:\/\/youtu.be\/oC82ECqtcNg?a",
      "display_url" : "youtu.be\/oC82ECqtcNg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280384581847355392",
  "text" : "there is show called inventors usa, please email me at gamer456148@gmail.com and we will talk (@YouTube http:\/\/t.co\/u8yeO1PG)",
  "id" : 280384581847355392,
  "created_at" : "2012-12-16 18:51:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/tq5KugIo",
      "expanded_url" : "http:\/\/youtu.be\/Gpqz3cdVPLM?a",
      "display_url" : "youtu.be\/Gpqz3cdVPLM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280378984590622720",
  "text" : "I liked a @YouTube video http:\/\/t.co\/tq5KugIo Creedence Clearwater Revival - Proud Mary",
  "id" : 280378984590622720,
  "created_at" : "2012-12-16 18:28:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/T6XBMr7w",
      "expanded_url" : "http:\/\/youtu.be\/wIjUY3pjN8E?a",
      "display_url" : "youtu.be\/wIjUY3pjN8E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280377462767091712",
  "text" : "I liked a @YouTube video http:\/\/t.co\/T6XBMr7w Creedence Clearwater Revival - Born On The Bayou",
  "id" : 280377462767091712,
  "created_at" : "2012-12-16 18:22:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 43, 51 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/NQuOKZ7s",
      "expanded_url" : "http:\/\/youtu.be\/V7WtVJSJQaM?a",
      "display_url" : "youtu.be\/V7WtVJSJQaM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280376867599552513",
  "text" : "this was on forest gump and it was awsome (@YouTube http:\/\/t.co\/NQuOKZ7s)",
  "id" : 280376867599552513,
  "created_at" : "2012-12-16 18:20:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/NQuOKZ7s",
      "expanded_url" : "http:\/\/youtu.be\/V7WtVJSJQaM?a",
      "display_url" : "youtu.be\/V7WtVJSJQaM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280376583431282688",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/NQuOKZ7s Creedence Clearwater Revival - vietnam war song",
  "id" : 280376583431282688,
  "created_at" : "2012-12-16 18:19:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/NQuOKZ7s",
      "expanded_url" : "http:\/\/youtu.be\/V7WtVJSJQaM?a",
      "display_url" : "youtu.be\/V7WtVJSJQaM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280375999072436224",
  "text" : "I liked a @YouTube video http:\/\/t.co\/NQuOKZ7s Creedence Clearwater Revival - vietnam war song",
  "id" : 280375999072436224,
  "created_at" : "2012-12-16 18:17:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Indy Mogul",
      "screen_name" : "indymogul",
      "indices" : [ 30, 40 ],
      "id_str" : "8902462",
      "id" : 8902462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/dTtvz3te",
      "expanded_url" : "http:\/\/youtu.be\/N3yMYu12zd0?a",
      "display_url" : "youtu.be\/N3yMYu12zd0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280370661732515840",
  "text" : "I liked a @YouTube video from @indymogul http:\/\/t.co\/dTtvz3te Iron Man 2 Robot Repulsor Arm : How to : BFX",
  "id" : 280370661732515840,
  "created_at" : "2012-12-16 17:55:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 7, 15 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/dTtvz3te",
      "expanded_url" : "http:\/\/youtu.be\/N3yMYu12zd0?a",
      "display_url" : "youtu.be\/N3yMYu12zd0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280370316893646849",
  "text" : "Sweet (@YouTube http:\/\/t.co\/dTtvz3te)",
  "id" : 280370316893646849,
  "created_at" : "2012-12-16 17:54:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/xUYCMjfo",
      "expanded_url" : "http:\/\/youtu.be\/5AKRYOc3IZM?a",
      "display_url" : "youtu.be\/5AKRYOc3IZM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280370179580506112",
  "text" : "I want one so badly (@YouTube http:\/\/t.co\/xUYCMjfo)",
  "id" : 280370179580506112,
  "created_at" : "2012-12-16 17:53:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/u8yeO1PG",
      "expanded_url" : "http:\/\/youtu.be\/oC82ECqtcNg?a",
      "display_url" : "youtu.be\/oC82ECqtcNg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280369757490905091",
  "text" : "to espensive (@YouTube http:\/\/t.co\/u8yeO1PG)",
  "id" : 280369757490905091,
  "created_at" : "2012-12-16 17:52:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 33, 41 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/u8yeO1PG",
      "expanded_url" : "http:\/\/youtu.be\/oC82ECqtcNg?a",
      "display_url" : "youtu.be\/oC82ECqtcNg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280369084640681984",
  "text" : "You should be on inventor's usa (@YouTube http:\/\/t.co\/u8yeO1PG)",
  "id" : 280369084640681984,
  "created_at" : "2012-12-16 17:49:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/rvFLniRn",
      "expanded_url" : "http:\/\/youtu.be\/SzqtAoJjV8Y?a",
      "display_url" : "youtu.be\/SzqtAoJjV8Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280368892226973696",
  "text" : "I liked a @YouTube video http:\/\/t.co\/rvFLniRn TESLA CANNON: Directed Energy",
  "id" : 280368892226973696,
  "created_at" : "2012-12-16 17:48:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 5, 13 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/PqWXJLZB",
      "expanded_url" : "http:\/\/youtu.be\/A8OTSC_iVT0?a",
      "display_url" : "youtu.be\/A8OTSC_iVT0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280366251937763328",
  "text" : "wow (@YouTube http:\/\/t.co\/PqWXJLZB)",
  "id" : 280366251937763328,
  "created_at" : "2012-12-16 17:38:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 8, 16 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/OUXZviDH",
      "expanded_url" : "http:\/\/youtu.be\/JEDZG1HuwHc?a",
      "display_url" : "youtu.be\/JEDZG1HuwHc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280365965743624192",
  "text" : "creepy (@YouTube http:\/\/t.co\/OUXZviDH)",
  "id" : 280365965743624192,
  "created_at" : "2012-12-16 17:37:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 28, 36 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/BSJ8q0zg",
      "expanded_url" : "http:\/\/youtu.be\/u9H0hNH24gA?a",
      "display_url" : "youtu.be\/u9H0hNH24gA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280365527656980481",
  "text" : "How to make one using gimp (@YouTube http:\/\/t.co\/BSJ8q0zg)",
  "id" : 280365527656980481,
  "created_at" : "2012-12-16 17:35:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 15, 23 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/wFqEtkhi",
      "expanded_url" : "http:\/\/youtu.be\/8gko4Oadn3g?a",
      "display_url" : "youtu.be\/8gko4Oadn3g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280363320408678400",
  "text" : "I meant added (@YouTube http:\/\/t.co\/wFqEtkhi)",
  "id" : 280363320408678400,
  "created_at" : "2012-12-16 17:26:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/wFqEtkhi",
      "expanded_url" : "http:\/\/youtu.be\/8gko4Oadn3g?a",
      "display_url" : "youtu.be\/8gko4Oadn3g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280363100023160832",
  "text" : "I made one to but affef a switch, and a metal board after the magnet (@YouTube http:\/\/t.co\/wFqEtkhi)",
  "id" : 280363100023160832,
  "created_at" : "2012-12-16 17:25:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/xZ2TBTcD",
      "expanded_url" : "http:\/\/youtu.be\/LqayfG7exi4?a",
      "display_url" : "youtu.be\/LqayfG7exi4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280362627547414528",
  "text" : "It took alot of hard work, I like it (@YouTube http:\/\/t.co\/xZ2TBTcD)",
  "id" : 280362627547414528,
  "created_at" : "2012-12-16 17:23:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 18, 26 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/x5G2Ju8b",
      "expanded_url" : "http:\/\/youtu.be\/L07k7jvxjIk?a",
      "display_url" : "youtu.be\/L07k7jvxjIk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280361509924777984",
  "text" : "Rare model, nice (@YouTube http:\/\/t.co\/x5G2Ju8b)",
  "id" : 280361509924777984,
  "created_at" : "2012-12-16 17:19:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 23, 31 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/OPmvHl8n",
      "expanded_url" : "http:\/\/youtu.be\/brD5D0ytD04?a",
      "display_url" : "youtu.be\/brD5D0ytD04?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280361131237851137",
  "text" : "She is a pretty robot (@YouTube http:\/\/t.co\/OPmvHl8n)",
  "id" : 280361131237851137,
  "created_at" : "2012-12-16 17:17:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/t2AiTdSy",
      "expanded_url" : "http:\/\/youtu.be\/JhQcVEmft_Y?a",
      "display_url" : "youtu.be\/JhQcVEmft_Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280359096920715267",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/t2AiTdSy Funny Chess Parody",
  "id" : 280359096920715267,
  "created_at" : "2012-12-16 17:09:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/zbyn7CIa",
      "expanded_url" : "http:\/\/youtu.be\/yHYsUlzR-6E?a",
      "display_url" : "youtu.be\/yHYsUlzR-6E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280188397358821376",
  "text" : "I liked a @YouTube video http:\/\/t.co\/zbyn7CIa Sacred Geometry DNA changes 2012 Mollecular Atom Consciousness.mp4",
  "id" : 280188397358821376,
  "created_at" : "2012-12-16 05:51:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/2f0sYzQB",
      "expanded_url" : "http:\/\/youtu.be\/Ob6gfLuS0RA?a",
      "display_url" : "youtu.be\/Ob6gfLuS0RA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280187706565337088",
  "text" : "what music is this (@YouTube http:\/\/t.co\/2f0sYzQB)",
  "id" : 280187706565337088,
  "created_at" : "2012-12-16 05:48:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/qldtIj5b",
      "expanded_url" : "http:\/\/youtu.be\/uxgMhHOaUSY?a",
      "display_url" : "youtu.be\/uxgMhHOaUSY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280186406905737216",
  "text" : "How did you do this (@YouTube http:\/\/t.co\/qldtIj5b)",
  "id" : 280186406905737216,
  "created_at" : "2012-12-16 05:43:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 8, 16 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/aNfQ5UuB",
      "expanded_url" : "http:\/\/youtu.be\/uPU9cEK5YsM?a",
      "display_url" : "youtu.be\/uPU9cEK5YsM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280185389711519744",
  "text" : "awsome (@YouTube http:\/\/t.co\/aNfQ5UuB)",
  "id" : 280185389711519744,
  "created_at" : "2012-12-16 05:39:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/8kYbItVF",
      "expanded_url" : "http:\/\/youtu.be\/xhDOqktA7L4?a",
      "display_url" : "youtu.be\/xhDOqktA7L4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280184162042916865",
  "text" : "I liked a @YouTube video http:\/\/t.co\/8kYbItVF How to make alcohol rocket",
  "id" : 280184162042916865,
  "created_at" : "2012-12-16 05:34:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 19, 27 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/WLkLPcb1",
      "expanded_url" : "http:\/\/youtu.be\/oQmJGkvooSs?a",
      "display_url" : "youtu.be\/oQmJGkvooSs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280183404132196352",
  "text" : "made by camonetec\n(@YouTube http:\/\/t.co\/WLkLPcb1)",
  "id" : 280183404132196352,
  "created_at" : "2012-12-16 05:31:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XSys7nAt",
      "expanded_url" : "http:\/\/youtu.be\/jnM91xJoEMk?a",
      "display_url" : "youtu.be\/jnM91xJoEMk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280182927776677888",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XSys7nAt Best Physics Projects Where I Was There",
  "id" : 280182927776677888,
  "created_at" : "2012-12-16 05:29:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 86, 94 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5KpupN6i",
      "expanded_url" : "http:\/\/youtu.be\/8EhQVoyF_0c?a",
      "display_url" : "youtu.be\/8EhQVoyF_0c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280182466109665280",
  "text" : "I did something similar with donald micka, also see the estes big daddy model rcoket (@YouTube http:\/\/t.co\/5KpupN6i)",
  "id" : 280182466109665280,
  "created_at" : "2012-12-16 05:28:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 37, 45 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/v05nBQbo",
      "expanded_url" : "http:\/\/youtu.be\/EOxAThylgo0?a",
      "display_url" : "youtu.be\/EOxAThylgo0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280181488404811778",
  "text" : "Do bigger rockets= get bigger views (@YouTube http:\/\/t.co\/v05nBQbo)",
  "id" : 280181488404811778,
  "created_at" : "2012-12-16 05:24:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/vH1Yr6Xv",
      "expanded_url" : "http:\/\/youtu.be\/0qzOzjRJpaU?a",
      "display_url" : "youtu.be\/0qzOzjRJpaU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280176815241318400",
  "text" : "This is awsome 10X (@YouTube http:\/\/t.co\/vH1Yr6Xv)",
  "id" : 280176815241318400,
  "created_at" : "2012-12-16 05:05:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/rgkO6LVG",
      "expanded_url" : "http:\/\/youtu.be\/ByrxSZG9Avk?a",
      "display_url" : "youtu.be\/ByrxSZG9Avk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280176517672235010",
  "text" : "I made a water powered only launcher (@YouTube http:\/\/t.co\/rgkO6LVG)",
  "id" : 280176517672235010,
  "created_at" : "2012-12-16 05:04:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/iNyDPmi1",
      "expanded_url" : "http:\/\/youtu.be\/D4UVz-ZGODw?a",
      "display_url" : "youtu.be\/D4UVz-ZGODw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280175943522336768",
  "text" : "What physics team are you, I want to join so badly (@YouTube http:\/\/t.co\/iNyDPmi1)",
  "id" : 280175943522336768,
  "created_at" : "2012-12-16 05:02:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/54GUNZ3n",
      "expanded_url" : "http:\/\/youtu.be\/FUwh0D28pyk?a",
      "display_url" : "youtu.be\/FUwh0D28pyk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280175658385154048",
  "text" : "I liked a @YouTube video http:\/\/t.co\/54GUNZ3n Mecanum Drive RC Electric Kart",
  "id" : 280175658385154048,
  "created_at" : "2012-12-16 05:00:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/PM8mCDFu",
      "expanded_url" : "http:\/\/youtu.be\/4GLAEgOqSes?a",
      "display_url" : "youtu.be\/4GLAEgOqSes?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280174987996966913",
  "text" : "I invented the electromagnetic hoverbaord and it was cooler (@YouTube http:\/\/t.co\/PM8mCDFu)",
  "id" : 280174987996966913,
  "created_at" : "2012-12-16 04:58:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/dZiPFUKF",
      "expanded_url" : "http:\/\/youtu.be\/pOJV2tWdIhE?a",
      "display_url" : "youtu.be\/pOJV2tWdIhE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280173761129492480",
  "text" : "I wouls not want to be on an airplane when this happens (@YouTube http:\/\/t.co\/dZiPFUKF)",
  "id" : 280173761129492480,
  "created_at" : "2012-12-16 04:53:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/4XWmojHP",
      "expanded_url" : "http:\/\/youtu.be\/S6KAFLqqv_8?a",
      "display_url" : "youtu.be\/S6KAFLqqv_8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280173413379747840",
  "text" : "Haha Nasa didn't discover it, proves Europe and the Russian Space Center is better (@YouTube http:\/\/t.co\/4XWmojHP)",
  "id" : 280173413379747840,
  "created_at" : "2012-12-16 04:52:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/6ZNXUoPj",
      "expanded_url" : "http:\/\/youtu.be\/wEPPuf6I0Ic?a",
      "display_url" : "youtu.be\/wEPPuf6I0Ic?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280171177979310081",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6ZNXUoPj World Will Not End On 12.21.12... Really, NASA Says | Video",
  "id" : 280171177979310081,
  "created_at" : "2012-12-16 04:43:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 40, 48 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/6ZNXUoPj",
      "expanded_url" : "http:\/\/youtu.be\/wEPPuf6I0Ic?a",
      "display_url" : "youtu.be\/wEPPuf6I0Ic?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280171112099368961",
  "text" : "YES THE WORLD WILL NOT END ON THE 21ST (@YouTube http:\/\/t.co\/6ZNXUoPj)",
  "id" : 280171112099368961,
  "created_at" : "2012-12-16 04:42:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Y9PZRBSj",
      "expanded_url" : "http:\/\/youtu.be\/kvQrZw2CdpU?a",
      "display_url" : "youtu.be\/kvQrZw2CdpU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280104143132176384",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Y9PZRBSj ORB IQ Test Solution",
  "id" : 280104143132176384,
  "created_at" : "2012-12-16 00:16:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/K1XiXoum",
      "expanded_url" : "http:\/\/youtu.be\/_qWu-Mm7nvE?a",
      "display_url" : "youtu.be\/_qWu-Mm7nvE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280089190560067584",
  "text" : "I liked a @YouTube video http:\/\/t.co\/K1XiXoum The Good Samaritan",
  "id" : 280089190560067584,
  "created_at" : "2012-12-15 23:17:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/yaKpEwZV",
      "expanded_url" : "http:\/\/youtu.be\/wnLm5evO5QY?a",
      "display_url" : "youtu.be\/wnLm5evO5QY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280088823755571201",
  "text" : "I liked a @YouTube video http:\/\/t.co\/yaKpEwZV The Journey of a Gay Man - Are You Suprised ?",
  "id" : 280088823755571201,
  "created_at" : "2012-12-15 23:15:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/o1dnPq1a",
      "expanded_url" : "http:\/\/youtu.be\/6fl9_P2Oz7Q?a",
      "display_url" : "youtu.be\/6fl9_P2Oz7Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280063852685717504",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/o1dnPq1a Crevolution 2851 - Cerberus 2010 - Drive system",
  "id" : 280063852685717504,
  "created_at" : "2012-12-15 21:36:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/T1Wc8dSM",
      "expanded_url" : "http:\/\/youtu.be\/Pc_Wjwj-X8w?a",
      "display_url" : "youtu.be\/Pc_Wjwj-X8w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280059531030048769",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/T1Wc8dSM Was Jesus Married?",
  "id" : 280059531030048769,
  "created_at" : "2012-12-15 21:19:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/NDVa95yp",
      "expanded_url" : "http:\/\/youtu.be\/NsuTRhEaj8w?a",
      "display_url" : "youtu.be\/NsuTRhEaj8w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280058440326459392",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/NDVa95yp What Happens When Scientist Mess With Genetics",
  "id" : 280058440326459392,
  "created_at" : "2012-12-15 21:15:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/EtZjfUF0",
      "expanded_url" : "http:\/\/youtu.be\/-C6NkRUbI38?a",
      "display_url" : "youtu.be\/-C6NkRUbI38?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280051791373168640",
  "text" : "Part of the \"Texas Monkey Project\" they injected monkey dna to a baby human's genes (@YouTube http:\/\/t.co\/EtZjfUF0)",
  "id" : 280051791373168640,
  "created_at" : "2012-12-15 20:48:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/AR8490LE",
      "expanded_url" : "http:\/\/youtu.be\/PHr1gXrH-3I?a",
      "display_url" : "youtu.be\/PHr1gXrH-3I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280032985019973632",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/AR8490LE Final Day of Hanukkah",
  "id" : 280032985019973632,
  "created_at" : "2012-12-15 19:34:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/JYbViRVm",
      "expanded_url" : "http:\/\/youtu.be\/-luPeMx_wic?a",
      "display_url" : "youtu.be\/-luPeMx_wic?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280029642868543488",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/JYbViRVm Building an Ionizer Part I",
  "id" : 280029642868543488,
  "created_at" : "2012-12-15 19:20:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ZIQLZSo5",
      "expanded_url" : "http:\/\/youtu.be\/pi88eYIPpNw?a",
      "display_url" : "youtu.be\/pi88eYIPpNw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "280000841312792576",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ZIQLZSo5 How to Survive the Apocalypse",
  "id" : 280000841312792576,
  "created_at" : "2012-12-15 17:26:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/0j6Xo5no",
      "expanded_url" : "http:\/\/youtu.be\/4-fHKFZn9Sc?a",
      "display_url" : "youtu.be\/4-fHKFZn9Sc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279711542776320000",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/0j6Xo5no My World Record Attempt for Highest 3D Racer Score",
  "id" : 279711542776320000,
  "created_at" : "2012-12-14 22:16:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/jtN5OMQx",
      "expanded_url" : "http:\/\/youtu.be\/husl0tGz5R8?a",
      "display_url" : "youtu.be\/husl0tGz5R8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279682525838848000",
  "text" : "Bamboorules, http:\/\/t.co\/jtN5OMQx",
  "id" : 279682525838848000,
  "created_at" : "2012-12-14 20:21:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/qlb8WnNS",
      "expanded_url" : "http:\/\/youtu.be\/sL28Bb6OmHo?a",
      "display_url" : "youtu.be\/sL28Bb6OmHo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279635039694766080",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/qlb8WnNS What Others Have Said About My Ideas &amp; Inventions",
  "id" : 279635039694766080,
  "created_at" : "2012-12-14 17:12:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/qlb8WnNS",
      "expanded_url" : "http:\/\/youtu.be\/sL28Bb6OmHo?a",
      "display_url" : "youtu.be\/sL28Bb6OmHo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279364827821006848",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/qlb8WnNS What Others Have Said About My Ideas &amp; Inventions",
  "id" : 279364827821006848,
  "created_at" : "2012-12-13 23:18:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/xwxaL8vv",
      "expanded_url" : "http:\/\/youtu.be\/1xpqPpNYoLE?a",
      "display_url" : "youtu.be\/1xpqPpNYoLE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279275424931000320",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/xwxaL8vv Happy Sixth Day of Hanukkah",
  "id" : 279275424931000320,
  "created_at" : "2012-12-13 17:23:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ulUpwhTx",
      "expanded_url" : "http:\/\/youtu.be\/CTu8YYxsDf8?a",
      "display_url" : "youtu.be\/CTu8YYxsDf8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279273414030680064",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ulUpwhTx HOW TO GET FAMOUS WITH SEO",
  "id" : 279273414030680064,
  "created_at" : "2012-12-13 17:15:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/eLMMSsy4",
      "expanded_url" : "http:\/\/youtu.be\/z5DTE6tRzjY?a",
      "display_url" : "youtu.be\/z5DTE6tRzjY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279075661161824256",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/eLMMSsy4 My Second Invention USA Audition",
  "id" : 279075661161824256,
  "created_at" : "2012-12-13 04:09:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Yb1SFpJ7",
      "expanded_url" : "http:\/\/youtu.be\/PJxGANNEFTQ?a",
      "display_url" : "youtu.be\/PJxGANNEFTQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279045640456110080",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/Yb1SFpJ7 How my Sculpture is Doing so Far",
  "id" : 279045640456110080,
  "created_at" : "2012-12-13 02:10:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/k5uiC7jV",
      "expanded_url" : "http:\/\/youtu.be\/oon5JEKKsqo?a",
      "display_url" : "youtu.be\/oon5JEKKsqo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "279003713702596608",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/k5uiC7jV My Designs",
  "id" : 279003713702596608,
  "created_at" : "2012-12-12 23:24:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/XycwJz4G",
      "expanded_url" : "http:\/\/youtu.be\/SUlzyD2LxCM?a",
      "display_url" : "youtu.be\/SUlzyD2LxCM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278938935646900224",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/XycwJz4G Happy Fifth Day of Hanukkah",
  "id" : 278938935646900224,
  "created_at" : "2012-12-12 19:06:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/FYMRoodK",
      "expanded_url" : "http:\/\/youtu.be\/gpe8n1hv9zw?a",
      "display_url" : "youtu.be\/gpe8n1hv9zw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278723591485399040",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/FYMRoodK Why do Video Game downloads last si long?",
  "id" : 278723591485399040,
  "created_at" : "2012-12-12 04:50:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/rxuzT3d5",
      "expanded_url" : "http:\/\/youtu.be\/ec0XKhAHR5I?a",
      "display_url" : "youtu.be\/ec0XKhAHR5I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278698874015715328",
  "text" : "I liked a @YouTube video http:\/\/t.co\/rxuzT3d5 Creedence Clearwater Revival: Fortunate Son",
  "id" : 278698874015715328,
  "created_at" : "2012-12-12 03:12:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/vS9jdEkd",
      "expanded_url" : "http:\/\/youtu.be\/7LtMvc7wdm8?a",
      "display_url" : "youtu.be\/7LtMvc7wdm8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278698442346332160",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/vS9jdEkd Free Realms Demo 2",
  "id" : 278698442346332160,
  "created_at" : "2012-12-12 03:11:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/xvhx2ieU",
      "expanded_url" : "http:\/\/youtu.be\/iqzmphag5Oo?a",
      "display_url" : "youtu.be\/iqzmphag5Oo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278695122605072384",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/xvhx2ieU Free Realms Demo 1",
  "id" : 278695122605072384,
  "created_at" : "2012-12-12 02:57:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/iPOmYDaQ",
      "expanded_url" : "http:\/\/youtu.be\/1wuQqc51_Jw?a",
      "display_url" : "youtu.be\/1wuQqc51_Jw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278650889793843201",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/iPOmYDaQ Happy Fourth Day of Hanukkah",
  "id" : 278650889793843201,
  "created_at" : "2012-12-12 00:02:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/qiH0Tb33",
      "expanded_url" : "http:\/\/youtu.be\/dfsiEU_mFAA?a",
      "display_url" : "youtu.be\/dfsiEU_mFAA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278336006871212032",
  "text" : "I liked a @YouTube video http:\/\/t.co\/qiH0Tb33 Dead Island - Was ein Zombey [HD] #04",
  "id" : 278336006871212032,
  "created_at" : "2012-12-11 03:10:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/J9k815t6",
      "expanded_url" : "http:\/\/youtu.be\/sA79VVxnkaQ?a",
      "display_url" : "youtu.be\/sA79VVxnkaQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278262409637011456",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/J9k815t6 VOICEMAIL OF RHR Celebrating My World Record For Highest IQ",
  "id" : 278262409637011456,
  "created_at" : "2012-12-10 22:18:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/7TcJvPRo",
      "expanded_url" : "http:\/\/youtu.be\/IxPsTlvdfkw?a",
      "display_url" : "youtu.be\/IxPsTlvdfkw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "278259565060042753",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/7TcJvPRo Third Day of Hanukkah Celebration",
  "id" : 278259565060042753,
  "created_at" : "2012-12-10 22:07:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/L7f94f0e",
      "expanded_url" : "http:\/\/youtu.be\/zo44YUiOL4I?a",
      "display_url" : "youtu.be\/zo44YUiOL4I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277885560805265411",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/L7f94f0e SakaProductions News Announcement for ME",
  "id" : 277885560805265411,
  "created_at" : "2012-12-09 21:20:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/82NowPXZ",
      "expanded_url" : "http:\/\/youtu.be\/XW1hPwHZyPA?a",
      "display_url" : "youtu.be\/XW1hPwHZyPA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277811534078562304",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/82NowPXZ Webcam video from December 9, 2012 11:25 AM",
  "id" : 277811534078562304,
  "created_at" : "2012-12-09 16:26:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/sXVgL54R",
      "expanded_url" : "http:\/\/youtu.be\/kDcmZ19Tic4?a",
      "display_url" : "youtu.be\/kDcmZ19Tic4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277602389916262402",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/sXVgL54R A Song For Those Who Lost Their Ways",
  "id" : 277602389916262402,
  "created_at" : "2012-12-09 02:35:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/sXVgL54R",
      "expanded_url" : "http:\/\/youtu.be\/kDcmZ19Tic4?a",
      "display_url" : "youtu.be\/kDcmZ19Tic4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277601745046224898",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/sXVgL54R Webcam video from December 8, 2012 9:27 PM",
  "id" : 277601745046224898,
  "created_at" : "2012-12-09 02:33:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/3xcFFtV7",
      "expanded_url" : "http:\/\/youtu.be\/O5IdCifo430?a",
      "display_url" : "youtu.be\/O5IdCifo430?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277448573480738816",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/3xcFFtV7 A Celebration of Hanukkah",
  "id" : 277448573480738816,
  "created_at" : "2012-12-08 16:24:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/SQZ7JTo9",
      "expanded_url" : "http:\/\/youtu.be\/rpFiDfRJiKc?a",
      "display_url" : "youtu.be\/rpFiDfRJiKc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277225461594062849",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/SQZ7JTo9 How to Play Galaxy Wars the Video Game",
  "id" : 277225461594062849,
  "created_at" : "2012-12-08 01:37:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/4UK0DBaL",
      "expanded_url" : "http:\/\/youtu.be\/cj5ksLWC4UM?a",
      "display_url" : "youtu.be\/cj5ksLWC4UM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "277209170476953600",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/4UK0DBaL My New App Released",
  "id" : 277209170476953600,
  "created_at" : "2012-12-08 00:33:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/mfwiKKbj",
      "expanded_url" : "http:\/\/youtu.be\/pR0foLYKn-g?a",
      "display_url" : "youtu.be\/pR0foLYKn-g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276923922581184513",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/mfwiKKbj Time Engineers Demo Video",
  "id" : 276923922581184513,
  "created_at" : "2012-12-07 05:39:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/2BQAN0pV",
      "expanded_url" : "http:\/\/youtu.be\/MneqXOMBPIg?a",
      "display_url" : "youtu.be\/MneqXOMBPIg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276906201990713346",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/2BQAN0pV I Forgot I Was Playing Hearts",
  "id" : 276906201990713346,
  "created_at" : "2012-12-07 04:29:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/YeIYEAsf",
      "expanded_url" : "http:\/\/youtu.be\/VdoyRgjGaaM?a",
      "display_url" : "youtu.be\/VdoyRgjGaaM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276904273562963968",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/YeIYEAsf Hiroads Level 2",
  "id" : 276904273562963968,
  "created_at" : "2012-12-07 04:21:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/tiML4rJx",
      "expanded_url" : "http:\/\/youtu.be\/wzA8K0gf7Mw?a",
      "display_url" : "youtu.be\/wzA8K0gf7Mw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276903929764265984",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/tiML4rJx Hiroads Level 1",
  "id" : 276903929764265984,
  "created_at" : "2012-12-07 04:20:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/cGz3fFbO",
      "expanded_url" : "http:\/\/youtu.be\/i1r2XDqtaTE?a",
      "display_url" : "youtu.be\/i1r2XDqtaTE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276901289546366977",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/cGz3fFbO Dinorun Level 1",
  "id" : 276901289546366977,
  "created_at" : "2012-12-07 04:09:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/oKvHRpEa",
      "expanded_url" : "http:\/\/youtu.be\/ffqYY3vJmqU?a",
      "display_url" : "youtu.be\/ffqYY3vJmqU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276881525096726528",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/oKvHRpEa Star Trek Academy Trainer Part.1",
  "id" : 276881525096726528,
  "created_at" : "2012-12-07 02:51:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/LwpHFI0k",
      "expanded_url" : "http:\/\/youtu.be\/yMlDNBPnC3g?a",
      "display_url" : "youtu.be\/yMlDNBPnC3g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276876230748409858",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/LwpHFI0k Star Fleet Video Game",
  "id" : 276876230748409858,
  "created_at" : "2012-12-07 02:30:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 62, 70 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/A9jhZx0w",
      "expanded_url" : "http:\/\/youtu.be\/_Xru5aEydvk?a",
      "display_url" : "youtu.be\/_Xru5aEydvk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276429185835229185",
  "text" : "I am an inventor to, message me, we can do business together (@YouTube http:\/\/t.co\/A9jhZx0w)",
  "id" : 276429185835229185,
  "created_at" : "2012-12-05 20:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 68, 76 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/vzIyQDq9",
      "expanded_url" : "http:\/\/youtu.be\/xB85ZcjQMhY?a",
      "display_url" : "youtu.be\/xB85ZcjQMhY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276428565539586048",
  "text" : "I am inventor to, I would like to interview you, please message me (@YouTube http:\/\/t.co\/vzIyQDq9)",
  "id" : 276428565539586048,
  "created_at" : "2012-12-05 20:51:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 0, 8 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276410568540315649",
  "in_reply_to_user_id" : 17874544,
  "text" : "@Support I need help getting me account verified, I am a worldly known inventor, and ceo",
  "id" : 276410568540315649,
  "created_at" : "2012-12-05 19:39:49 +0000",
  "in_reply_to_screen_name" : "Support",
  "in_reply_to_user_id_str" : "17874544",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Verified",
      "screen_name" : "verified",
      "indices" : [ 0, 9 ],
      "id_str" : "63796828",
      "id" : 63796828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240862454089920512",
  "geo" : { },
  "id_str" : "276408240240226304",
  "in_reply_to_user_id" : 63796828,
  "text" : "@verified Can you verify my account",
  "id" : 276408240240226304,
  "in_reply_to_status_id" : 240862454089920512,
  "created_at" : "2012-12-05 19:30:34 +0000",
  "in_reply_to_screen_name" : "verified",
  "in_reply_to_user_id_str" : "63796828",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Verified",
      "screen_name" : "verified",
      "indices" : [ 0, 9 ],
      "id_str" : "63796828",
      "id" : 63796828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276408024162267136",
  "in_reply_to_user_id" : 63796828,
  "text" : "@verified Can I get my account verified, I am a worldly known inventor, who is Andrew Magdy Kamal",
  "id" : 276408024162267136,
  "created_at" : "2012-12-05 19:29:43 +0000",
  "in_reply_to_screen_name" : "verified",
  "in_reply_to_user_id_str" : "63796828",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/CdaXwQzz",
      "expanded_url" : "http:\/\/youtu.be\/VHb3UB8Sj18?a",
      "display_url" : "youtu.be\/VHb3UB8Sj18?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276330879348006912",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/CdaXwQzz Webcam video from December 5, 2012 9:17 AM",
  "id" : 276330879348006912,
  "created_at" : "2012-12-05 14:23:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/nala8zJH",
      "expanded_url" : "http:\/\/youtu.be\/b8kd212F4Xk?a",
      "display_url" : "youtu.be\/b8kd212F4Xk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276145556210987008",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/nala8zJH My Invention USA Audition",
  "id" : 276145556210987008,
  "created_at" : "2012-12-05 02:06:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/iXYSNI2M",
      "expanded_url" : "http:\/\/youtu.be\/tAe-EMbK0u4?a",
      "display_url" : "youtu.be\/tAe-EMbK0u4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "276019395338313728",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/iXYSNI2M Presidents and War US HISTORY REPORT FOR YOUTUBERS OUT THERE",
  "id" : 276019395338313728,
  "created_at" : "2012-12-04 17:45:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/QEDNuK7W",
      "expanded_url" : "http:\/\/youtu.be\/4MpMDBwMZpY?a",
      "display_url" : "youtu.be\/4MpMDBwMZpY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275971990341447680",
  "text" : "I liked a @YouTube video http:\/\/t.co\/QEDNuK7W Cute Girlfriend! - Minecraft Couple Part 1 w\/Cutie",
  "id" : 275971990341447680,
  "created_at" : "2012-12-04 14:37:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/MyfOOKRN",
      "expanded_url" : "http:\/\/youtu.be\/ekuMplQTKzs?a",
      "display_url" : "youtu.be\/ekuMplQTKzs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275969981672480768",
  "text" : "I liked a @YouTube video http:\/\/t.co\/MyfOOKRN Thoughts on Black Ops 2",
  "id" : 275969981672480768,
  "created_at" : "2012-12-04 14:29:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/eDWzGzhs",
      "expanded_url" : "http:\/\/youtu.be\/JXYrAn6OoJw?a",
      "display_url" : "youtu.be\/JXYrAn6OoJw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275937746625908736",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/eDWzGzhs Webcam video from December 4, 2012 7:16 AM",
  "id" : 275937746625908736,
  "created_at" : "2012-12-04 12:21:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/YRqgwus2",
      "expanded_url" : "http:\/\/youtu.be\/mLWnNwCmSNQ?a",
      "display_url" : "youtu.be\/mLWnNwCmSNQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275790709381017600",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/YRqgwus2 Chat with Bella",
  "id" : 275790709381017600,
  "created_at" : "2012-12-04 02:36:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 28, 40 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/zYfv7hNC",
      "expanded_url" : "http:\/\/youtu.be\/Cjjl6K68kIw?a",
      "display_url" : "youtu.be\/Cjjl6K68kIw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275779871135911936",
  "text" : "My skype is @coptdeacon, or @gamer456148 (@YouTube http:\/\/t.co\/zYfv7hNC)",
  "id" : 275779871135911936,
  "created_at" : "2012-12-04 01:53:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 62, 70 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/zYfv7hNC",
      "expanded_url" : "http:\/\/youtu.be\/Cjjl6K68kIw?a",
      "display_url" : "youtu.be\/Cjjl6K68kIw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275779486891520001",
  "text" : "I already know how to chat with Zendaya but cool sign me up, (@YouTube http:\/\/t.co\/zYfv7hNC)",
  "id" : 275779486891520001,
  "created_at" : "2012-12-04 01:52:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/MyEUZQkk",
      "expanded_url" : "http:\/\/youtu.be\/DJjtE1SPfCk?a",
      "display_url" : "youtu.be\/DJjtE1SPfCk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275770840245731328",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/MyEUZQkk Full Video of Professor Puppet (A Muppet) Anouncing my Record",
  "id" : 275770840245731328,
  "created_at" : "2012-12-04 01:17:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/sKRUG9gK",
      "expanded_url" : "http:\/\/youtu.be\/NRZ4B3UNjSg?a",
      "display_url" : "youtu.be\/NRZ4B3UNjSg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275673361919668225",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/sKRUG9gK I Got Braces Today",
  "id" : 275673361919668225,
  "created_at" : "2012-12-03 18:50:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/8zpCZYxk",
      "expanded_url" : "http:\/\/youtu.be\/vbe-Xqu7AHU?a",
      "display_url" : "youtu.be\/vbe-Xqu7AHU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275673338511233024",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/8zpCZYxk Professor Puppet From the Muppets Anouncing my World Record!!!!",
  "id" : 275673338511233024,
  "created_at" : "2012-12-03 18:50:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/wapaLCUV",
      "expanded_url" : "http:\/\/youtu.be\/9oKk71cwCFQ?a",
      "display_url" : "youtu.be\/9oKk71cwCFQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275464688828035072",
  "text" : "Most people want to talk to a celeb about how they are just a big fan or silly things like (@YouTube http:\/\/t.co\/wapaLCUV)",
  "id" : 275464688828035072,
  "created_at" : "2012-12-03 05:01:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/iA4flCbb",
      "expanded_url" : "http:\/\/youtu.be\/ZpDDLe2D6Mk?a",
      "display_url" : "youtu.be\/ZpDDLe2D6Mk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275464071774613504",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/iA4flCbb My Thanksgiving 2012 (Please Read Discription)",
  "id" : 275464071774613504,
  "created_at" : "2012-12-03 04:58:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/wapaLCUV",
      "expanded_url" : "http:\/\/youtu.be\/9oKk71cwCFQ?a",
      "display_url" : "youtu.be\/9oKk71cwCFQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275442907748655104",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/wapaLCUV My Chat With Zendaya about the Coptic Orphans Program",
  "id" : 275442907748655104,
  "created_at" : "2012-12-03 03:34:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/3VFkCX1D",
      "expanded_url" : "http:\/\/youtu.be\/JzhJOyRS0ps?a",
      "display_url" : "youtu.be\/JzhJOyRS0ps?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275079680011427840",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/3VFkCX1D Saka Productions ReAnimated Logo by ME",
  "id" : 275079680011427840,
  "created_at" : "2012-12-02 03:31:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/7X8Oaly0",
      "expanded_url" : "http:\/\/youtu.be\/F92XKkgeZFk?a",
      "display_url" : "youtu.be\/F92XKkgeZFk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275019341647470592",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/7X8Oaly0 Dirt - Courteney and Jennifer kiss!",
  "id" : 275019341647470592,
  "created_at" : "2012-12-01 23:31:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 37, 45 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Yyi3u2bb",
      "expanded_url" : "http:\/\/youtu.be\/bQ6Do50Eel0?a",
      "display_url" : "youtu.be\/bQ6Do50Eel0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275018685071114240",
  "text" : "I actidently clicked on this sickos (@YouTube http:\/\/t.co\/Yyi3u2bb)",
  "id" : 275018685071114240,
  "created_at" : "2012-12-01 23:28:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6jhKJcFa",
      "expanded_url" : "http:\/\/youtu.be\/I_ugwVveTk4?a",
      "display_url" : "youtu.be\/I_ugwVveTk4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "275010616727588865",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6jhKJcFa \"Skinny by Tara\" Reviewing my World Record!!!",
  "id" : 275010616727588865,
  "created_at" : "2012-12-01 22:56:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275004979419422720",
  "text" : "http:\/\/fiverr. com\/skinnyby tara",
  "id" : 275004979419422720,
  "created_at" : "2012-12-01 22:34:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275004883558600704",
  "text" : "Check these out http:\/\/fiverr. com\/skinnybytara",
  "id" : 275004883558600704,
  "created_at" : "2012-12-01 22:34:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275004836351721473",
  "text" : "http:\/\/fiverr .com\/ skinnybytara",
  "id" : 275004836351721473,
  "created_at" : "2012-12-01 22:33:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/25CZY8h0",
      "expanded_url" : "http:\/\/youtu.be\/IQV-wTVgSPA?a",
      "display_url" : "youtu.be\/IQV-wTVgSPA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "274991220080648192",
  "text" : "The world is not going to end in December 21. 2012, but Obama will start war with Israel (@YouTube http:\/\/t.co\/25CZY8h0)",
  "id" : 274991220080648192,
  "created_at" : "2012-12-01 21:39:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/YZPHwBHG",
      "expanded_url" : "http:\/\/www.recordholdersrepublic.co.uk\/recordholdersdetails.asp?id=1105",
      "display_url" : "recordholdersrepublic.co.uk\/recordholdersd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274984873591193600",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Check out my world record http:\/\/t.co\/YZPHwBHG",
  "id" : 274984873591193600,
  "created_at" : "2012-12-01 21:14:37 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/YZPHwBHG",
      "expanded_url" : "http:\/\/www.recordholdersrepublic.co.uk\/recordholdersdetails.asp?id=1105",
      "display_url" : "recordholdersrepublic.co.uk\/recordholdersd\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "274966750045540352",
  "geo" : { },
  "id_str" : "274984822361948160",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Zendaya Check out my world record http:\/\/t.co\/YZPHwBHG",
  "id" : 274984822361948160,
  "in_reply_to_status_id" : 274966750045540352,
  "created_at" : "2012-12-01 21:14:25 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/lU5nl3P2",
      "expanded_url" : "http:\/\/youtu.be\/XbC06w3okdc?a",
      "display_url" : "youtu.be\/XbC06w3okdc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "274953047564775424",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/lU5nl3P2 Andrew Magdy Kamal Featured on Entrepreneur TV",
  "id" : 274953047564775424,
  "created_at" : "2012-12-01 19:08:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/bNPAjavV",
      "expanded_url" : "http:\/\/youtu.be\/gNlaPigzIoQ?a",
      "display_url" : "youtu.be\/gNlaPigzIoQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "274893383326109697",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/bNPAjavV My World Record for Highest IQ Average Anounced Next to Historical Monument",
  "id" : 274893383326109697,
  "created_at" : "2012-12-01 15:11:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274708747073503232",
  "text" : "http:\/\/fiverr .com\/arjunrocks",
  "id" : 274708747073503232,
  "created_at" : "2012-12-01 02:57:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]