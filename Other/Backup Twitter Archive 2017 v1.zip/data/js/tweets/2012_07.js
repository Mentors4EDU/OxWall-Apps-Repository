Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/jdkHTRCO",
      "expanded_url" : "http:\/\/www.quirky.com\/ideations\/273037",
      "display_url" : "quirky.com\/ideations\/2730\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230359964655439872",
  "text" : "Vote for my new invention idea http:\/\/t.co\/jdkHTRCO",
  "id" : 230359964655439872,
  "created_at" : "2012-07-31 17:51:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/6b19vpXu",
      "expanded_url" : "http:\/\/youtu.be\/2sRCzwW5dHI?a",
      "display_url" : "youtu.be\/2sRCzwW5dHI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "230356718750679040",
  "text" : "I liked a @YouTube video http:\/\/t.co\/6b19vpXu Virtual Reality Gaming Suit",
  "id" : 230356718750679040,
  "created_at" : "2012-07-31 17:38:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6b19vpXu",
      "expanded_url" : "http:\/\/youtu.be\/2sRCzwW5dHI?a",
      "display_url" : "youtu.be\/2sRCzwW5dHI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "230355370747523072",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6b19vpXu Virtual Reality Gaming Suit",
  "id" : 230355370747523072,
  "created_at" : "2012-07-31 17:32:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/oOMKy3yQ",
      "expanded_url" : "http:\/\/lnkd.in\/nRwW_N",
      "display_url" : "lnkd.in\/nRwW_N"
    } ]
  },
  "geo" : { },
  "id_str" : "230347623045926912",
  "text" : "Vote for the virtual reality gaming suit: http:\/\/t.co\/oOMKy3yQ",
  "id" : 230347623045926912,
  "created_at" : "2012-07-31 17:02:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "230272314527330304",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 230272314527330304,
  "created_at" : "2012-07-31 12:02:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "230032112269533184",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 230032112269533184,
  "created_at" : "2012-07-30 20:08:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/mH7fmF0Z",
      "expanded_url" : "https:\/\/sites.google.com\/site\/kamaltheories\/",
      "display_url" : "sites.google.com\/site\/kamaltheo\u2026"
    }, {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/PrZo8c0g",
      "expanded_url" : "http:\/\/lnkd.in\/qdrB4M",
      "display_url" : "lnkd.in\/qdrB4M"
    } ]
  },
  "geo" : { },
  "id_str" : "229976762023571456",
  "text" : "To see my copyrighted and patent protected theories and ideas go to https:\/\/t.co\/mH7fmF0Z: http:\/\/t.co\/PrZo8c0g",
  "id" : 229976762023571456,
  "created_at" : "2012-07-30 16:28:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/zsu5Vv56",
      "expanded_url" : "http:\/\/andsocialrew.wall.fm",
      "display_url" : "andsocialrew.wall.fm"
    }, {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Rq0souMk",
      "expanded_url" : "http:\/\/lnkd.in\/NxvMj4",
      "display_url" : "lnkd.in\/NxvMj4"
    } ]
  },
  "geo" : { },
  "id_str" : "229976507089559552",
  "text" : "Join http:\/\/t.co\/zsu5Vv56: http:\/\/t.co\/Rq0souMk",
  "id" : 229976507089559552,
  "created_at" : "2012-07-30 16:27:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/nN1LplY2",
      "expanded_url" : "http:\/\/lnkd.in\/Qm34_w",
      "display_url" : "lnkd.in\/Qm34_w"
    } ]
  },
  "geo" : { },
  "id_str" : "229976203820404736",
  "text" : "I created group Theoretical Physicist Professionals on Linkedin.: http:\/\/t.co\/nN1LplY2",
  "id" : 229976203820404736,
  "created_at" : "2012-07-30 16:26:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "229841454938333184",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 229841454938333184,
  "created_at" : "2012-07-30 07:30:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/fkUpmK2g",
      "expanded_url" : "http:\/\/youtu.be\/AnFQuxX9Luo?a",
      "display_url" : "youtu.be\/AnFQuxX9Luo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "229735306700652544",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/fkUpmK2g 3D Slide Show",
  "id" : 229735306700652544,
  "created_at" : "2012-07-30 00:29:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/OdHYK3j4",
      "expanded_url" : "http:\/\/youtu.be\/xYI63kITDuQ?a",
      "display_url" : "youtu.be\/xYI63kITDuQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "229674634293960706",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/OdHYK3j4 MOMMA Bird Photos",
  "id" : 229674634293960706,
  "created_at" : "2012-07-29 20:27:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/j4kG2eiu",
      "expanded_url" : "http:\/\/youtu.be\/R6QI0Eh6MBE?a",
      "display_url" : "youtu.be\/R6QI0Eh6MBE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "229672848082477057",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/j4kG2eiu Movie 0003",
  "id" : 229672848082477057,
  "created_at" : "2012-07-29 20:20:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "229551082974609408",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 229551082974609408,
  "created_at" : "2012-07-29 12:16:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "229311723679653888",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 229311723679653888,
  "created_at" : "2012-07-28 20:25:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/OghUQ8Lj",
      "expanded_url" : "http:\/\/youtu.be\/RGBUgppTy40?a",
      "display_url" : "youtu.be\/RGBUgppTy40?a"
    } ]
  },
  "geo" : { },
  "id_str" : "229261000581447680",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/OghUQ8Lj My Antiques",
  "id" : 229261000581447680,
  "created_at" : "2012-07-28 17:04:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "229116992756514817",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 229116992756514817,
  "created_at" : "2012-07-28 07:32:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~Zombiekiller~",
      "screen_name" : "Still_BlazinTho",
      "indices" : [ 59, 75 ],
      "id_str" : "1855331066",
      "id" : 1855331066
    }, {
      "name" : "Naury Isnaini Zulva",
      "screen_name" : "naury_likas",
      "indices" : [ 76, 88 ],
      "id_str" : "300140749",
      "id" : 300140749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/shAiG1rL",
      "expanded_url" : "http:\/\/tinyurl.com\/btz7g5r",
      "display_url" : "tinyurl.com\/btz7g5r"
    } ]
  },
  "geo" : { },
  "id_str" : "229019096711303168",
  "text" : "RT \u279C GET \u279C FOLLOWERS \u279C http:\/\/t.co\/shAiG1rL @I_am_Scarface @still_blazintho @naury_likas",
  "id" : 229019096711303168,
  "created_at" : "2012-07-28 01:03:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/fpqeW8mp",
      "expanded_url" : "http:\/\/youtu.be\/EUmgrxD-Ej0?a",
      "display_url" : "youtu.be\/EUmgrxD-Ej0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "229012268363444224",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/fpqeW8mp FlapJack's Birthday",
  "id" : 229012268363444224,
  "created_at" : "2012-07-28 00:35:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/NJltX5wT",
      "expanded_url" : "http:\/\/youtu.be\/_FIumKgpy9A?a",
      "display_url" : "youtu.be\/_FIumKgpy9A?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228896161036132353",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/NJltX5wT Meet the Parkers Funny momment",
  "id" : 228896161036132353,
  "created_at" : "2012-07-27 16:54:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ql1DkMTI",
      "expanded_url" : "http:\/\/youtu.be\/W_YH8siJjAI?a",
      "display_url" : "youtu.be\/W_YH8siJjAI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228888518640947200",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ql1DkMTI Annoying Lemon, Annoying Orange Parody",
  "id" : 228888518640947200,
  "created_at" : "2012-07-27 16:24:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/eHMtim2o",
      "expanded_url" : "http:\/\/youtu.be\/9CD0GSmMpTo?a",
      "display_url" : "youtu.be\/9CD0GSmMpTo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228887533755441152",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/eHMtim2o Thats Alright MOMMA AKAMAL COVERUP",
  "id" : 228887533755441152,
  "created_at" : "2012-07-27 16:20:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/mND9kNC5",
      "expanded_url" : "http:\/\/youtu.be\/ktFzXb27liw?a",
      "display_url" : "youtu.be\/ktFzXb27liw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228887194461425664",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/mND9kNC5 Heartbreak Hotel AKAMAL Coverup",
  "id" : 228887194461425664,
  "created_at" : "2012-07-27 16:18:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/ep3g2CWn",
      "expanded_url" : "http:\/\/youtu.be\/lutSQ-gUJ4k?a",
      "display_url" : "youtu.be\/lutSQ-gUJ4k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228886377171935232",
  "text" : "I liked a @YouTube video http:\/\/t.co\/ep3g2CWn Eye of the Tiger AKAMAL COVERUP",
  "id" : 228886377171935232,
  "created_at" : "2012-07-27 16:15:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/ep3g2CWn",
      "expanded_url" : "http:\/\/youtu.be\/lutSQ-gUJ4k?a",
      "display_url" : "youtu.be\/lutSQ-gUJ4k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "228886344171155456",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/ep3g2CWn Eye of the Tiger AKAMAL COVERUP",
  "id" : 228886344171155456,
  "created_at" : "2012-07-27 16:15:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "228874515025915906",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 228874515025915906,
  "created_at" : "2012-07-27 15:28:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "228636201664532484",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 228636201664532484,
  "created_at" : "2012-07-26 23:41:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "QTP",
      "screen_name" : "carolinaquan",
      "indices" : [ 47, 60 ],
      "id_str" : "66338553",
      "id" : 66338553
    }, {
      "name" : "Alex Joshua Thomas",
      "screen_name" : "alexjoshthomas",
      "indices" : [ 61, 76 ],
      "id_str" : "732650575",
      "id" : 732650575
    }, {
      "name" : "ABDI FAUZI",
      "screen_name" : "IAMABDIFAUZI",
      "indices" : [ 77, 90 ],
      "id_str" : "618654296",
      "id" : 618654296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/2ZIqQNiQ",
      "expanded_url" : "http:\/\/tinyurl.com\/cpgbq9u",
      "display_url" : "tinyurl.com\/cpgbq9u"
    } ]
  },
  "geo" : { },
  "id_str" : "228495402964492291",
  "text" : "GET \u2605 FREE \u2605 FOLLOWERS \u279C  http:\/\/t.co\/2ZIqQNiQ @carolinaquan @alexjoshthomas @IAMABDIFAUZI",
  "id" : 228495402964492291,
  "created_at" : "2012-07-26 14:22:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "228449324063944704",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 228449324063944704,
  "created_at" : "2012-07-26 11:18:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "228221616251867136",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 228221616251867136,
  "created_at" : "2012-07-25 20:14:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "227969924876890112",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 227969924876890112,
  "created_at" : "2012-07-25 03:34:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/2ZIqQNiQ",
      "expanded_url" : "http:\/\/tinyurl.com\/cpgbq9u",
      "display_url" : "tinyurl.com\/cpgbq9u"
    } ]
  },
  "geo" : { },
  "id_str" : "227966912880050177",
  "text" : "GET \u2605 FREE \u2605 FOLLOWERS \u279C  http:\/\/t.co\/2ZIqQNiQ",
  "id" : 227966912880050177,
  "created_at" : "2012-07-25 03:22:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brooke Hyland",
      "screen_name" : "BrookeHyland1",
      "indices" : [ 0, 14 ],
      "id_str" : "325867787",
      "id" : 325867787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/zsu5Vv56",
      "expanded_url" : "http:\/\/andsocialrew.wall.fm",
      "display_url" : "andsocialrew.wall.fm"
    } ]
  },
  "geo" : { },
  "id_str" : "227949394002059266",
  "in_reply_to_user_id" : 325867787,
  "text" : "@BrookeHyland1 Join professional network  at http:\/\/t.co\/zsu5Vv56 help a celeb\/CEO out",
  "id" : 227949394002059266,
  "created_at" : "2012-07-25 02:12:25 +0000",
  "in_reply_to_screen_name" : "BrookeHyland1",
  "in_reply_to_user_id_str" : "325867787",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Youtube",
      "indices" : [ 5, 13 ]
    }, {
      "text" : "vagex",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/L081s3wA",
      "expanded_url" : "http:\/\/vagex.com\/?ref=151751",
      "display_url" : "vagex.com\/?ref=151751"
    } ]
  },
  "geo" : { },
  "id_str" : "227860210935529472",
  "text" : "Free #Youtube Views #vagex http:\/\/t.co\/L081s3wA",
  "id" : 227860210935529472,
  "created_at" : "2012-07-24 20:18:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.followtofollow.com\" rel=\"nofollow\"\u003EFollow to Follow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/es1yUS0R",
      "expanded_url" : "http:\/\/bit.ly\/get-newfollowers",
      "display_url" : "bit.ly\/get-newfollowe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "227853008074072064",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? Please Visit http:\/\/t.co\/es1yUS0R",
  "id" : 227853008074072064,
  "created_at" : "2012-07-24 19:49:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.followtofollow.com\" rel=\"nofollow\"\u003EFollow to Follow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamFollowBack",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/WsICOgUW",
      "expanded_url" : "http:\/\/www.bestfollowers.us",
      "display_url" : "bestfollowers.us"
    } ]
  },
  "geo" : { },
  "id_str" : "227853010921988096",
  "text" : "#TeamFollowBack GET MORE FOLLOWERS MY BEST FRIENDS? http:\/\/t.co\/WsICOgUW",
  "id" : 227853010921988096,
  "created_at" : "2012-07-24 19:49:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/kvsemBfI",
      "expanded_url" : "http:\/\/youtu.be\/fzcVfX3Pogw?a",
      "display_url" : "youtu.be\/fzcVfX3Pogw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "227797365480910848",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/kvsemBfI Movie",
  "id" : 227797365480910848,
  "created_at" : "2012-07-24 16:08:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/zsu5Vv56",
      "expanded_url" : "http:\/\/andsocialrew.wall.fm",
      "display_url" : "andsocialrew.wall.fm"
    } ]
  },
  "geo" : { },
  "id_str" : "226821823805939712",
  "text" : "Create an account on my new fun gaming social network at http:\/\/t.co\/zsu5Vv56",
  "id" : 226821823805939712,
  "created_at" : "2012-07-21 23:31:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    }, {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 39, 46 ],
      "id_str" : "24206345",
      "id" : 24206345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/fi7RvrEW",
      "expanded_url" : "http:\/\/www.quirky.com\/ideations\/258435",
      "display_url" : "quirky.com\/ideations\/2584\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219859060231651330",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Vote for this great idea on @quirky: \"Hoverboard\tInvented By Andrew Magdy Kamal\" http:\/\/t.co\/fi7RvrEW",
  "id" : 219859060231651330,
  "created_at" : "2012-07-02 18:24:19 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]