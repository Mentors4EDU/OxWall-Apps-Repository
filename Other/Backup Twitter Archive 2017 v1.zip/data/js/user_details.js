var user_details =  {
  "screen_name" : "gamer456148",
  "location" : "The Universe",
  "full_name" : "Andrew Kamal",
  "bio" : "The dude with many different talents *Developer *Researcher *Inventor *Startup Advisor *Coptic Activist *Sponsored Athlete *Popular Blogger",
  "id" : "210979938",
  "created_at" : "2010-11-01 23:38:02 +0000"
}