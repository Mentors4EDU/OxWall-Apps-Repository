Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549755069600526337",
  "text" : "Colin Furze's new video is amazing :-)",
  "id" : 549755069600526337,
  "created_at" : "2014-12-30 02:33:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549300767190814721",
  "text" : "Went to the American church today, U_U",
  "id" : 549300767190814721,
  "created_at" : "2014-12-28 20:28:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549300572096962560",
  "text" : "Vince &amp; Joe's always have nice groceries. Really cool store.",
  "id" : 549300572096962560,
  "created_at" : "2014-12-28 20:27:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548989051957551105",
  "text" : "Had a nice day today. That is all I am gonna say. Btw had Quails' at the Sahara Restaurant in MI. 3.65\/5 stars",
  "id" : 548989051957551105,
  "created_at" : "2014-12-27 23:49:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2W7QYzudjV",
      "expanded_url" : "http:\/\/youtu.be\/iyKU1UwUAqQ",
      "display_url" : "youtu.be\/iyKU1UwUAqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "548828499092312064",
  "text" : "RT @colin_furze: \u00A3500 phones in the freezerAbove Earth HTC Phone Footage and Fireworks part 2 Freezer test (2 of 3): http:\/\/t.co\/2W7QYzudjV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 127, 135 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/2W7QYzudjV",
        "expanded_url" : "http:\/\/youtu.be\/iyKU1UwUAqQ",
        "display_url" : "youtu.be\/iyKU1UwUAqQ"
      } ]
    },
    "geo" : { },
    "id_str" : "548509668767563776",
    "text" : "\u00A3500 phones in the freezerAbove Earth HTC Phone Footage and Fireworks part 2 Freezer test (2 of 3): http:\/\/t.co\/2W7QYzudjV via @YouTube",
    "id" : 548509668767563776,
    "created_at" : "2014-12-26 16:04:30 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 548828499092312064,
  "created_at" : "2014-12-27 13:11:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 75, 85 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548828386475245569",
  "text" : "I will be honest, I would love to get into a philosophical discussion with @neiltyson",
  "id" : 548828386475245569,
  "created_at" : "2014-12-27 13:10:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548828176239976449",
  "text" : "RT @neiltyson: Merry Christmas to all. A Pagan holiday (BC) becomes a Religious holiday (AD). Which then becomes a Shopping holiday (USA).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "548144728693551106",
    "text" : "Merry Christmas to all. A Pagan holiday (BC) becomes a Religious holiday (AD). Which then becomes a Shopping holiday (USA).",
    "id" : 548144728693551106,
    "created_at" : "2014-12-25 15:54:22 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 548828176239976449,
  "created_at" : "2014-12-27 13:10:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "548323035271270401",
  "text" : "Had a nice day today :P",
  "id" : 548323035271270401,
  "created_at" : "2014-12-26 03:42:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547895309892734978",
  "text" : "I was outside the whole day, and it was tiring :P",
  "id" : 547895309892734978,
  "created_at" : "2014-12-24 23:23:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547592513175830528",
  "text" : "Colin Furze uploaded a new video and his new victim is his phone.",
  "id" : 547592513175830528,
  "created_at" : "2014-12-24 03:20:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546415698000375808",
  "text" : "I had homemade fudge, caramel, and peanut butter chunks, tasted so good. Thanks to whoever made it.",
  "id" : 546415698000375808,
  "created_at" : "2014-12-20 21:23:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/GclWxHV0Od",
      "expanded_url" : "http:\/\/goo.gl\/Nk3lMx",
      "display_url" : "goo.gl\/Nk3lMx"
    } ]
  },
  "geo" : { },
  "id_str" : "545727912775667712",
  "text" : "That pizza was awesome: http:\/\/t.co\/GclWxHV0Od",
  "id" : 545727912775667712,
  "created_at" : "2014-12-18 23:50:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544330313044742145",
  "text" : "RT @colin_furze: The current project is not working as I'd like. People of Twitter send hope to the shed in Stamford.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544228738507231232",
    "text" : "The current project is not working as I'd like. People of Twitter send hope to the shed in Stamford.",
    "id" : 544228738507231232,
    "created_at" : "2014-12-14 20:33:37 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 544330313044742145,
  "created_at" : "2014-12-15 03:17:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544327992210501632",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Why do people give a crap if a celebrity releases a PR on their new outfit? They aren't higher then us. Who cares?",
  "id" : 544327992210501632,
  "created_at" : "2014-12-15 03:08:01 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "544327518065401856",
  "text" : "Today was my cheat day, I had Egg Nog, Poweraide, and gummy worms. Plus all that fastfood, man I need to diet.",
  "id" : 544327518065401856,
  "created_at" : "2014-12-15 03:06:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ltyVMNUWA0",
      "expanded_url" : "http:\/\/goo.gl\/z9MpaH",
      "display_url" : "goo.gl\/z9MpaH"
    } ]
  },
  "geo" : { },
  "id_str" : "543950067632070656",
  "text" : "That was amazing, http:\/\/t.co\/ltyVMNUWA0, a true hero",
  "id" : 543950067632070656,
  "created_at" : "2014-12-14 02:06:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/VAWLOi5dpr",
      "expanded_url" : "http:\/\/youtu.be\/VSdUDa1IY48?a",
      "display_url" : "youtu.be\/VSdUDa1IY48?a"
    } ]
  },
  "geo" : { },
  "id_str" : "543949859904974848",
  "text" : "RT @VigilantChrist: Family Guy &amp; Simpsons Mock God 4 Christmas on Holiday Specials!  http:\/\/t.co\/VAWLOi5dpr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/VAWLOi5dpr",
        "expanded_url" : "http:\/\/youtu.be\/VSdUDa1IY48?a",
        "display_url" : "youtu.be\/VSdUDa1IY48?a"
      } ]
    },
    "geo" : { },
    "id_str" : "542769785625255936",
    "text" : "Family Guy &amp; Simpsons Mock God 4 Christmas on Holiday Specials!  http:\/\/t.co\/VAWLOi5dpr",
    "id" : 542769785625255936,
    "created_at" : "2014-12-10 19:56:15 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 543949859904974848,
  "created_at" : "2014-12-14 02:05:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543201663356391424",
  "text" : "Had Sorrento's pizza 3.75\/5 stars, was okay but not the best.",
  "id" : 543201663356391424,
  "created_at" : "2014-12-12 00:32:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "542424106369445889",
  "text" : "Went out with my parents on Sunday, had an amazing time, and had a delightful week so far, glory be to God!!!",
  "id" : 542424106369445889,
  "created_at" : "2014-12-09 21:02:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540643576636387328",
  "text" : "Entertainment these days, geez",
  "id" : 540643576636387328,
  "created_at" : "2014-12-04 23:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach King",
      "screen_name" : "FinalCutKing",
      "indices" : [ 3, 16 ],
      "id_str" : "30599331",
      "id" : 30599331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/SE9bk6c0qK",
      "expanded_url" : "https:\/\/vine.co\/v\/OiagzQ7Tjx1",
      "display_url" : "vine.co\/v\/OiagzQ7Tjx1"
    } ]
  },
  "geo" : { },
  "id_str" : "540643200105345024",
  "text" : "RT @FinalCutKing: When your parents are coming to check if your room is clean!!! https:\/\/t.co\/SE9bk6c0qK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/SE9bk6c0qK",
        "expanded_url" : "https:\/\/vine.co\/v\/OiagzQ7Tjx1",
        "display_url" : "vine.co\/v\/OiagzQ7Tjx1"
      } ]
    },
    "geo" : { },
    "id_str" : "531483886606225408",
    "text" : "When your parents are coming to check if your room is clean!!! https:\/\/t.co\/SE9bk6c0qK",
    "id" : 531483886606225408,
    "created_at" : "2014-11-09 16:30:07 +0000",
    "user" : {
      "name" : "Zach King",
      "screen_name" : "FinalCutKing",
      "protected" : false,
      "id_str" : "30599331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473970390868316161\/KZvt_QCh_normal.jpeg",
      "id" : 30599331,
      "verified" : true
    }
  },
  "id" : 540643200105345024,
  "created_at" : "2014-12-04 23:05:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekSlayer",
      "screen_name" : "GeekSlayer73",
      "indices" : [ 0, 13 ],
      "id_str" : "137869559",
      "id" : 137869559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540642994295037952",
  "in_reply_to_user_id" : 137869559,
  "text" : "@GeekSlayer73 Are you sure you aren't just some racist bastard making fun of your own culture?",
  "id" : 540642994295037952,
  "created_at" : "2014-12-04 23:05:09 +0000",
  "in_reply_to_screen_name" : "GeekSlayer73",
  "in_reply_to_user_id_str" : "137869559",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekSlayer",
      "screen_name" : "GeekSlayer73",
      "indices" : [ 3, 16 ],
      "id_str" : "137869559",
      "id" : 137869559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/TxlYAG2yCg",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=psymAkTA4w8",
      "display_url" : "youtube.com\/watch?v=psymAk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540642870634348545",
  "text" : "RT @GeekSlayer73: Get fit the Indian way with the Indian Workout Tape (new video!) https:\/\/t.co\/TxlYAG2yCg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/TxlYAG2yCg",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=psymAkTA4w8",
        "display_url" : "youtube.com\/watch?v=psymAk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "536552456394518528",
    "text" : "Get fit the Indian way with the Indian Workout Tape (new video!) https:\/\/t.co\/TxlYAG2yCg",
    "id" : 536552456394518528,
    "created_at" : "2014-11-23 16:10:48 +0000",
    "user" : {
      "name" : "GeekSlayer",
      "screen_name" : "GeekSlayer73",
      "protected" : false,
      "id_str" : "137869559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498249457926815745\/jWnDmxIe_normal.jpeg",
      "id" : 137869559,
      "verified" : false
    }
  },
  "id" : 540642870634348545,
  "created_at" : "2014-12-04 23:04:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/vjhOh6Fno2",
      "expanded_url" : "http:\/\/youtu.be\/7y93MYaTx6M",
      "display_url" : "youtu.be\/7y93MYaTx6M"
    } ]
  },
  "geo" : { },
  "id_str" : "540642727331758082",
  "text" : "RT @colin_furze: The ULTIMATE Tuk Tuk Unleashed the TUK600 (Far Cry 4) it's all madness I tell ya http:\/\/t.co\/vjhOh6Fno2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/youtube\/id544007664?mt=8&uo=4\" rel=\"nofollow\"\u003EYouTube on iOS_\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/vjhOh6Fno2",
        "expanded_url" : "http:\/\/youtu.be\/7y93MYaTx6M",
        "display_url" : "youtu.be\/7y93MYaTx6M"
      } ]
    },
    "geo" : { },
    "id_str" : "535001211897143296",
    "text" : "The ULTIMATE Tuk Tuk Unleashed the TUK600 (Far Cry 4) it's all madness I tell ya http:\/\/t.co\/vjhOh6Fno2",
    "id" : 535001211897143296,
    "created_at" : "2014-11-19 09:26:43 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 540642727331758082,
  "created_at" : "2014-12-04 23:04:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540642477938470912",
  "text" : "I just had a $5 sub from Vine and Joe's tasted so good. LOL",
  "id" : 540642477938470912,
  "created_at" : "2014-12-04 23:03:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/cWgNpIqFoF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=vL1lxH7s3Cw",
      "display_url" : "youtube.com\/watch?v=vL1lxH\u2026"
    }, {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/2QVMZbBZYW",
      "expanded_url" : "http:\/\/fb.me\/6XweoyUKf",
      "display_url" : "fb.me\/6XweoyUKf"
    } ]
  },
  "geo" : { },
  "id_str" : "540029655970242560",
  "text" : "God have mercy https:\/\/t.co\/cWgNpIqFoF http:\/\/t.co\/2QVMZbBZYW",
  "id" : 540029655970242560,
  "created_at" : "2014-12-03 06:27:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/nbHDsZMREH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lCZqy8t2MNw",
      "display_url" : "youtube.com\/watch?v=lCZqy8\u2026"
    }, {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/uX7FLdZDFC",
      "expanded_url" : "http:\/\/fb.me\/45aYcKXWj",
      "display_url" : "fb.me\/45aYcKXWj"
    } ]
  },
  "geo" : { },
  "id_str" : "540027693337964545",
  "text" : "How the Orthodox pray: https:\/\/t.co\/nbHDsZMREH http:\/\/t.co\/uX7FLdZDFC",
  "id" : 540027693337964545,
  "created_at" : "2014-12-03 06:20:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3LE6oLM7tx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=UB5UtOsa6C4",
      "display_url" : "youtube.com\/watch?v=UB5UtO\u2026"
    }, {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/2UDhyK1ekC",
      "expanded_url" : "http:\/\/fb.me\/3qNVY3VOr",
      "display_url" : "fb.me\/3qNVY3VOr"
    } ]
  },
  "geo" : { },
  "id_str" : "540027599662383104",
  "text" : "https:\/\/t.co\/3LE6oLM7tx http:\/\/t.co\/2UDhyK1ekC",
  "id" : 540027599662383104,
  "created_at" : "2014-12-03 06:19:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]