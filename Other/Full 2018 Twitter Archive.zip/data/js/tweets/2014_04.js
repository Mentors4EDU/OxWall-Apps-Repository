Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461649988263505920",
  "text" : "Turned out to be rotten, just ate part of something rotten, gross",
  "id" : 461649988263505920,
  "created_at" : "2014-04-30 23:35:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/lRmxx0rvBM",
      "expanded_url" : "http:\/\/1drv.ms\/1n4oZgw",
      "display_url" : "1drv.ms\/1n4oZgw"
    } ]
  },
  "geo" : { },
  "id_str" : "461648495317749760",
  "text" : "Didn't like it so much http:\/\/t.co\/lRmxx0rvBM",
  "id" : 461648495317749760,
  "created_at" : "2014-04-30 23:29:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Vanderberg",
      "screen_name" : "GunRights",
      "indices" : [ 0, 10 ],
      "id_str" : "1619841",
      "id" : 1619841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461388339661115392",
  "in_reply_to_user_id" : 1619841,
  "text" : "@GunRights Are you a tea party member as well?",
  "id" : 461388339661115392,
  "created_at" : "2014-04-30 06:15:27 +0000",
  "in_reply_to_screen_name" : "GunRights",
  "in_reply_to_user_id_str" : "1619841",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461364563997642752",
  "text" : "Wondering why the government (who claims to be protecting us) is taking away our self defense weapons",
  "id" : 461364563997642752,
  "created_at" : "2014-04-30 04:40:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Vanderberg",
      "screen_name" : "GunRights",
      "indices" : [ 3, 13 ],
      "id_str" : "1619841",
      "id" : 1619841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/e84EFzkA0u",
      "expanded_url" : "http:\/\/ht.ly\/wjlib",
      "display_url" : "ht.ly\/wjlib"
    } ]
  },
  "geo" : { },
  "id_str" : "461364349177962497",
  "text" : "RT @GunRights: Report: Pentagon to destroy $1B in ammunition http:\/\/t.co\/e84EFzkA0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/e84EFzkA0u",
        "expanded_url" : "http:\/\/ht.ly\/wjlib",
        "display_url" : "ht.ly\/wjlib"
      } ]
    },
    "geo" : { },
    "id_str" : "461334131386114048",
    "text" : "Report: Pentagon to destroy $1B in ammunition http:\/\/t.co\/e84EFzkA0u",
    "id" : 461334131386114048,
    "created_at" : "2014-04-30 02:40:02 +0000",
    "user" : {
      "name" : "Mark Vanderberg",
      "screen_name" : "GunRights",
      "protected" : false,
      "id_str" : "1619841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673681945692274688\/iT8dgMrE_normal.jpg",
      "id" : 1619841,
      "verified" : false
    }
  },
  "id" : 461364349177962497,
  "created_at" : "2014-04-30 04:40:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    }, {
      "name" : "World Vision",
      "screen_name" : "WorldVision",
      "indices" : [ 30, 42 ],
      "id_str" : "14086764",
      "id" : 14086764
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/461351881889943552\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IMrHh9HK3l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmcNF50CEAAcWrp.jpg",
      "id_str" : "461351881898332160",
      "id" : 461351881898332160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmcNF50CEAAcWrp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 646
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/IMrHh9HK3l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461351881889943552",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice The shameful CEO of @WorldVision have stated in an interview that he still supports same sex marriage http:\/\/t.co\/IMrHh9HK3l",
  "id" : 461351881889943552,
  "created_at" : "2014-04-30 03:50:34 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461265048644493312",
  "text" : "Wondering how my day went, it was okay. Found out I have to do more than 120 assignments, no slacking off. Just started college applications",
  "id" : 461265048644493312,
  "created_at" : "2014-04-29 22:05:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/dM5UoYbuZR",
      "expanded_url" : "http:\/\/1drv.ms\/1jeM8vW",
      "display_url" : "1drv.ms\/1jeM8vW"
    } ]
  },
  "geo" : { },
  "id_str" : "461262146194911232",
  "text" : "Went to Texas Roadhouse http:\/\/t.co\/dM5UoYbuZR",
  "id" : 461262146194911232,
  "created_at" : "2014-04-29 21:54:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ireport",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/RqmdgAAKm3",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-1125900",
      "display_url" : "ireport.cnn.com\/docs\/DOC-11259\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461126118888579072",
  "text" : "Lawyers use Google Glass to Win Case http:\/\/t.co\/RqmdgAAKm3 #ireport",
  "id" : 461126118888579072,
  "created_at" : "2014-04-29 12:53:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/tM9vRKMSFW",
      "expanded_url" : "http:\/\/1drv.ms\/1rvPv2o",
      "display_url" : "1drv.ms\/1rvPv2o"
    } ]
  },
  "geo" : { },
  "id_str" : "460617652390875137",
  "text" : "Pasta http:\/\/t.co\/tM9vRKMSFW",
  "id" : 460617652390875137,
  "created_at" : "2014-04-28 03:13:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/lSx6Tx2IpK",
      "expanded_url" : "http:\/\/www.ranker.com\/list\/5-youtubers-that-are-illuminati-puppets\/gamer456148",
      "display_url" : "ranker.com\/list\/5-youtube\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460615331678261248",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice 5 Youtubers who are illuminati puppets http:\/\/t.co\/lSx6Tx2IpK",
  "id" : 460615331678261248,
  "created_at" : "2014-04-28 03:03:47 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Yk0TKIiwn0",
      "expanded_url" : "http:\/\/www.ranker.com\/list\/10-really-good-android-apps-that-aren-and-_39_t-noticed-v1\/gamer456148?var=3&utm_expid=16418821-2.PAaBT_MORcmI67lBYq2pgw.2&format=GRID&page=10&utm_referrer=http%3A%2F%2Fwww.ranker.com%2Flist%2F10-really-good-android-apps-that-aren-and-_39_t-noticed-v1%2Fgamer456148%3Fformat%3DSLIDESHOW%26page%3D10",
      "display_url" : "ranker.com\/list\/10-really\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460572391555358720",
  "text" : "http:\/\/t.co\/Yk0TKIiwn0",
  "id" : 460572391555358720,
  "created_at" : "2014-04-28 00:13:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Tawadros II",
      "screen_name" : "PopeTawadros",
      "indices" : [ 0, 13 ],
      "id_str" : "927421452",
      "id" : 927421452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460519330187198464",
  "in_reply_to_user_id" : 927421452,
  "text" : "@PopeTawadros Only 105k twitter followers, you deserve so many more!!! God Bless You",
  "id" : 460519330187198464,
  "created_at" : "2014-04-27 20:42:19 +0000",
  "in_reply_to_screen_name" : "PopeTawadros",
  "in_reply_to_user_id_str" : "927421452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SUS Copts",
      "screen_name" : "suscopts",
      "indices" : [ 3, 12 ],
      "id_str" : "281563816",
      "id" : 281563816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/sBskofZAsY",
      "expanded_url" : "http:\/\/bit.ly\/1ipkXPo",
      "display_url" : "bit.ly\/1ipkXPo"
    } ]
  },
  "geo" : { },
  "id_str" : "460519154152656896",
  "text" : "RT @suscopts: New Press Release - Broadcasting: Thomas Sunday Divine Liturgy by His Grace http:\/\/t.co\/sBskofZAsY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/sBskofZAsY",
        "expanded_url" : "http:\/\/bit.ly\/1ipkXPo",
        "display_url" : "bit.ly\/1ipkXPo"
      } ]
    },
    "geo" : { },
    "id_str" : "460251236139139072",
    "text" : "New Press Release - Broadcasting: Thomas Sunday Divine Liturgy by His Grace http:\/\/t.co\/sBskofZAsY",
    "id" : 460251236139139072,
    "created_at" : "2014-04-27 02:57:00 +0000",
    "user" : {
      "name" : "SUS Copts",
      "screen_name" : "suscopts",
      "protected" : false,
      "id_str" : "281563816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473274874811523072\/3fwoHegW_normal.png",
      "id" : 281563816,
      "verified" : false
    }
  },
  "id" : 460519154152656896,
  "created_at" : "2014-04-27 20:41:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460518972165611520",
  "text" : "Seriously I just searched my name on twitter, can't believe how many people tweeted about me, thanks guys!!!",
  "id" : 460518972165611520,
  "created_at" : "2014-04-27 20:40:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shailesh Tripathi",
      "screen_name" : "ShaileshTr",
      "indices" : [ 3, 14 ],
      "id_str" : "113422725",
      "id" : 113422725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/pg9ZXDFE",
      "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-884601",
      "display_url" : "ireport.cnn.com\/docs\/DOC-884601"
    } ]
  },
  "geo" : { },
  "id_str" : "460518634138644480",
  "text" : "RT @ShaileshTR: Middle Eastern Genius, http:\/\/t.co\/pg9ZXDFE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/pg9ZXDFE",
        "expanded_url" : "http:\/\/ireport.cnn.com\/docs\/DOC-884601",
        "display_url" : "ireport.cnn.com\/docs\/DOC-884601"
      } ]
    },
    "geo" : { },
    "id_str" : "271381408176566273",
    "text" : "Middle Eastern Genius, http:\/\/t.co\/pg9ZXDFE",
    "id" : 271381408176566273,
    "created_at" : "2012-11-21 22:35:44 +0000",
    "user" : {
      "name" : "Shailesh Tripathi",
      "screen_name" : "ShaileshTr",
      "protected" : false,
      "id_str" : "113422725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687184612372578305\/roTKJcae_normal.jpg",
      "id" : 113422725,
      "verified" : false
    }
  },
  "id" : 460518634138644480,
  "created_at" : "2014-04-27 20:39:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PROMO_KING",
      "screen_name" : "1_promo_king",
      "indices" : [ 0, 13 ],
      "id_str" : "603965824",
      "id" : 603965824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460518400989478913",
  "in_reply_to_user_id" : 603965824,
  "text" : "@1_Promo_king Thanks for tweeting me before",
  "id" : 460518400989478913,
  "created_at" : "2014-04-27 20:38:37 +0000",
  "in_reply_to_screen_name" : "1_promo_king",
  "in_reply_to_user_id_str" : "603965824",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/9Y5Y1eRgSg",
      "expanded_url" : "http:\/\/1drv.ms\/1nvj7iL",
      "display_url" : "1drv.ms\/1nvj7iL"
    } ]
  },
  "geo" : { },
  "id_str" : "460019041454022656",
  "text" : "Running a 5k today!!! http:\/\/t.co\/9Y5Y1eRgSg",
  "id" : 460019041454022656,
  "created_at" : "2014-04-26 11:34:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459797314237116416",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice You should expose youtubers like pewdiepie or smosh. They are purely corrupt media.",
  "id" : 459797314237116416,
  "created_at" : "2014-04-25 20:53:16 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Brent Bozell",
      "screen_name" : "BrentBozell",
      "indices" : [ 37, 49 ],
      "id_str" : "20243128",
      "id" : 20243128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MRC",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "Hannity",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459796920345853952",
  "text" : "RT @seanhannity: The revolving door: @BrentBozell is here exposing the links between team Obama and the mainstream media #MRC #Hannity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brent Bozell",
        "screen_name" : "BrentBozell",
        "indices" : [ 20, 32 ],
        "id_str" : "20243128",
        "id" : 20243128
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MRC",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "Hannity",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459162428765253632",
    "text" : "The revolving door: @BrentBozell is here exposing the links between team Obama and the mainstream media #MRC #Hannity",
    "id" : 459162428765253632,
    "created_at" : "2014-04-24 02:50:28 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 459796920345853952,
  "created_at" : "2014-04-25 20:51:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 67, 82 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459796870542663680",
  "text" : "RT @seanhannity: Ouch: State Department spokeswoman can\u2019t name one @HillaryClinton accomplishment we have the video next #Hannity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 50, 65 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459157646897983488",
    "text" : "Ouch: State Department spokeswoman can\u2019t name one @HillaryClinton accomplishment we have the video next #Hannity",
    "id" : 459157646897983488,
    "created_at" : "2014-04-24 02:31:28 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 459796870542663680,
  "created_at" : "2014-04-25 20:51:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ipEIiRQT44",
      "expanded_url" : "http:\/\/1drv.ms\/1mInuo8",
      "display_url" : "1drv.ms\/1mInuo8"
    } ]
  },
  "geo" : { },
  "id_str" : "459795320763723776",
  "text" : "Roasted peppers taste great http:\/\/t.co\/ipEIiRQT44",
  "id" : 459795320763723776,
  "created_at" : "2014-04-25 20:45:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/ZdURSwtCSb",
      "expanded_url" : "http:\/\/1drv.ms\/1lLj0vp",
      "display_url" : "1drv.ms\/1lLj0vp"
    } ]
  },
  "geo" : { },
  "id_str" : "459474679997427713",
  "text" : "Sandwich, didn't like it that much!!! http:\/\/t.co\/ZdURSwtCSb",
  "id" : 459474679997427713,
  "created_at" : "2014-04-24 23:31:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459184910327382017",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice knows what he is talking about",
  "id" : 459184910327382017,
  "created_at" : "2014-04-24 04:19:48 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/tWzKyCqqzU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Mbf9SR9w_Qc",
      "display_url" : "youtube.com\/watch?v=Mbf9SR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459181731153989632",
  "text" : "I actually tried cowbrain before, it tasted good https:\/\/t.co\/tWzKyCqqzU",
  "id" : 459181731153989632,
  "created_at" : "2014-04-24 04:07:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/mOAme93yQt",
      "expanded_url" : "http:\/\/1drv.ms\/PrLmjt",
      "display_url" : "1drv.ms\/PrLmjt"
    } ]
  },
  "geo" : { },
  "id_str" : "458755428298809344",
  "text" : "Yeah http:\/\/t.co\/mOAme93yQt",
  "id" : 458755428298809344,
  "created_at" : "2014-04-22 23:53:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458059308421246976",
  "text" : "Went to family party, played football, played with the little ones",
  "id" : 458059308421246976,
  "created_at" : "2014-04-21 01:47:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457351361055555586",
  "text" : "Went to a party today, had fun, played with the little ones, met some family members, twas a nice day.",
  "id" : 457351361055555586,
  "created_at" : "2014-04-19 02:53:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/9jMQSMVwCl",
      "expanded_url" : "http:\/\/1drv.ms\/1eRe4GU",
      "display_url" : "1drv.ms\/1eRe4GU"
    } ]
  },
  "geo" : { },
  "id_str" : "457244273864626177",
  "text" : "I need to shave, will do it today http:\/\/t.co\/9jMQSMVwCl",
  "id" : 457244273864626177,
  "created_at" : "2014-04-18 19:48:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456803756009857024",
  "text" : "More like first invention",
  "id" : 456803756009857024,
  "created_at" : "2014-04-17 14:37:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/envSMRVuCi",
      "expanded_url" : "http:\/\/1drv.ms\/1hOjJNi",
      "display_url" : "1drv.ms\/1hOjJNi"
    } ]
  },
  "geo" : { },
  "id_str" : "456803673339736064",
  "text" : "My first DIY project, over 6 yrs ago http:\/\/t.co\/envSMRVuCi",
  "id" : 456803673339736064,
  "created_at" : "2014-04-17 14:37:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/E5QQDJUT7U",
      "expanded_url" : "http:\/\/1drv.ms\/1mgRaZd",
      "display_url" : "1drv.ms\/1mgRaZd"
    } ]
  },
  "geo" : { },
  "id_str" : "456800083959230464",
  "text" : "These taste great, also have you ever went to china city in Baltimore Ohio last time I went was 2011? Lol just random http:\/\/t.co\/E5QQDJUT7U",
  "id" : 456800083959230464,
  "created_at" : "2014-04-17 14:23:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ZM6laPr1dB",
      "expanded_url" : "http:\/\/1drv.ms\/QkyzQy",
      "display_url" : "1drv.ms\/QkyzQy"
    } ]
  },
  "geo" : { },
  "id_str" : "455407191395422209",
  "text" : "Ourban http:\/\/t.co\/ZM6laPr1dB",
  "id" : 455407191395422209,
  "created_at" : "2014-04-13 18:08:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RdBNMGNgHT",
      "expanded_url" : "http:\/\/1drv.ms\/1gn9B9T",
      "display_url" : "1drv.ms\/1gn9B9T"
    } ]
  },
  "geo" : { },
  "id_str" : "455173976051171328",
  "text" : "Favorite snack other then crab ragoons, chicken pot stickers, and turkey bacon http:\/\/t.co\/RdBNMGNgHT",
  "id" : 455173976051171328,
  "created_at" : "2014-04-13 02:41:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Cu0LJjBsif",
      "expanded_url" : "http:\/\/1drv.ms\/1n34HpI",
      "display_url" : "1drv.ms\/1n34HpI"
    } ]
  },
  "geo" : { },
  "id_str" : "455095534379073536",
  "text" : "Delightful http:\/\/t.co\/Cu0LJjBsif",
  "id" : 455095534379073536,
  "created_at" : "2014-04-12 21:30:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/1K12DsAFoY",
      "expanded_url" : "http:\/\/1drv.ms\/1n9UbKD",
      "display_url" : "1drv.ms\/1n9UbKD"
    } ]
  },
  "geo" : { },
  "id_str" : "454411315243925504",
  "text" : "Yummy http:\/\/t.co\/1K12DsAFoY",
  "id" : 454411315243925504,
  "created_at" : "2014-04-11 00:11:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/dQsGmOUwr5",
      "expanded_url" : "http:\/\/1drv.ms\/1n7AKlB",
      "display_url" : "1drv.ms\/1n7AKlB"
    } ]
  },
  "geo" : { },
  "id_str" : "454238607466061824",
  "text" : "New soft bed, so comfy, about $470 with tax http:\/\/t.co\/dQsGmOUwr5",
  "id" : 454238607466061824,
  "created_at" : "2014-04-10 12:44:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 19, 28 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453612568427249664",
  "text" : "Stay tuned because @MarkDice has more videos coming soon!!!",
  "id" : 453612568427249664,
  "created_at" : "2014-04-08 19:17:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 19, 28 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453612470314090496",
  "text" : "Do a digital detox @MarkDice",
  "id" : 453612470314090496,
  "created_at" : "2014-04-08 19:16:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453612215006818304",
  "text" : "RT @colin_furze: I'm looking at a device that's going to make an amazing youtube video.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448766627489001472",
    "text" : "I'm looking at a device that's going to make an amazing youtube video.",
    "id" : 448766627489001472,
    "created_at" : "2014-03-26 10:21:16 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 453612215006818304,
  "created_at" : "2014-04-08 19:15:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J Owen Shroyer \u2B50\u2B50\u2B50",
      "screen_name" : "allidoisowen",
      "indices" : [ 3, 16 ],
      "id_str" : "337484648",
      "id" : 337484648
    }, {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 18, 27 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/allidoisowen\/status\/453590248329453568\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/BtU75ibFjv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkt57VvCcAAeDLl.jpg",
      "id_str" : "453590247834546176",
      "id" : 453590247834546176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkt57VvCcAAeDLl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/BtU75ibFjv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453611687405309952",
  "text" : "RT @allidoisowen: @MarkDice this is on a government building in downtown St. Louis...normal http:\/\/t.co\/BtU75ibFjv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Dice",
        "screen_name" : "MarkDice",
        "indices" : [ 0, 9 ],
        "id_str" : "35039490",
        "id" : 35039490
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/allidoisowen\/status\/453590248329453568\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/BtU75ibFjv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bkt57VvCcAAeDLl.jpg",
        "id_str" : "453590247834546176",
        "id" : 453590247834546176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bkt57VvCcAAeDLl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 2064,
          "resize" : "fit",
          "w" : 1161
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/BtU75ibFjv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "453590248329453568",
    "in_reply_to_user_id" : 35039490,
    "text" : "@MarkDice this is on a government building in downtown St. Louis...normal http:\/\/t.co\/BtU75ibFjv",
    "id" : 453590248329453568,
    "created_at" : "2014-04-08 17:48:37 +0000",
    "in_reply_to_screen_name" : "MarkDice",
    "in_reply_to_user_id_str" : "35039490",
    "user" : {
      "name" : "J Owen Shroyer \u2B50\u2B50\u2B50",
      "screen_name" : "allidoisowen",
      "protected" : false,
      "id_str" : "337484648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1055651006934081542\/LTiMZLD1_normal.jpg",
      "id" : 337484648,
      "verified" : true
    }
  },
  "id" : 453611687405309952,
  "created_at" : "2014-04-08 19:13:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    }, {
      "name" : "Adrash GAMES",
      "screen_name" : "AdrashGAMES",
      "indices" : [ 10, 22 ],
      "id_str" : "1410102265",
      "id" : 1410102265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/nk4kP8WdML",
      "expanded_url" : "http:\/\/www.movavi.com\/support\/how-to\/mac\/how-to-convert-avi-to-mp4.html",
      "display_url" : "movavi.com\/support\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453055198940766208",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine @AdrashGAMES Tutorial on how to \u200Bconvert AVI to MP4 on Mac: \u200Bhttp:\/\/t.co\/nk4kP8WdML",
  "id" : 453055198940766208,
  "created_at" : "2014-04-07 06:22:31 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/nk4kP8WdML",
      "expanded_url" : "http:\/\/www.movavi.com\/support\/how-to\/mac\/how-to-convert-avi-to-mp4.html",
      "display_url" : "movavi.com\/support\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453055079981936641",
  "text" : "Tutorial on how to \u200Bconvert AVI to MP4 on Mac: \u200Bhttp:\/\/t.co\/nk4kP8WdML",
  "id" : 453055079981936641,
  "created_at" : "2014-04-07 06:22:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H2",
      "screen_name" : "More2History",
      "indices" : [ 3, 16 ],
      "id_str" : "378015672",
      "id" : 378015672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookofSecrets",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452976574720004096",
  "text" : "RT @More2History: Here's a sneak peak of America's #BookofSecrets!  Tonight at 10E\/11P, secrets will be revealed. Don't miss it: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookofSecrets",
        "indices" : [ 33, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/h9ZGu2cYkM",
        "expanded_url" : "http:\/\/histv.co\/1i06y93",
        "display_url" : "histv.co\/1i06y93"
      } ]
    },
    "geo" : { },
    "id_str" : "450054901838938112",
    "text" : "Here's a sneak peak of America's #BookofSecrets!  Tonight at 10E\/11P, secrets will be revealed. Don't miss it: http:\/\/t.co\/h9ZGu2cYkM",
    "id" : 450054901838938112,
    "created_at" : "2014-03-29 23:40:24 +0000",
    "user" : {
      "name" : "H2",
      "screen_name" : "More2History",
      "protected" : false,
      "id_str" : "378015672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527566993520467968\/Zoh-jdUa_normal.jpeg",
      "id" : 378015672,
      "verified" : true
    }
  },
  "id" : 452976574720004096,
  "created_at" : "2014-04-07 01:10:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Dice",
      "screen_name" : "MarkDice",
      "indices" : [ 0, 9 ],
      "id_str" : "35039490",
      "id" : 35039490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452976337108488192",
  "in_reply_to_user_id" : 35039490,
  "text" : "@MarkDice Just reached 60 million youtube views, congrats, you deserve them and many more",
  "id" : 452976337108488192,
  "created_at" : "2014-04-07 01:09:09 +0000",
  "in_reply_to_screen_name" : "MarkDice",
  "in_reply_to_user_id_str" : "35039490",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 0, 8 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452975695526760448",
  "in_reply_to_user_id" : 31239408,
  "text" : "@Beyonce You dress like a prostitute and are in music videos that call girls whores and bitches, and think calling a woman bossy is sexist?",
  "id" : 452975695526760448,
  "created_at" : "2014-04-07 01:06:36 +0000",
  "in_reply_to_screen_name" : "Beyonce",
  "in_reply_to_user_id_str" : "31239408",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452949412839305216",
  "text" : "Had so much food lol",
  "id" : 452949412839305216,
  "created_at" : "2014-04-06 23:22:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452255916910714880",
  "text" : "Had buscemi's meat lover sub and square pizza, so good",
  "id" : 452255916910714880,
  "created_at" : "2014-04-05 01:26:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]