Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/L84dMLc4BT",
      "expanded_url" : "http:\/\/youtu.be\/P7-oSpgfGEE?a",
      "display_url" : "youtu.be\/P7-oSpgfGEE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306637501395767296",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/L84dMLc4BT HOT &amp; SEXY DANICA PATRICK",
  "id" : 306637501395767296,
  "created_at" : "2013-02-27 05:30:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/NcGuPyDN6O",
      "expanded_url" : "http:\/\/youtu.be\/HQi6C-A966U?a",
      "display_url" : "youtu.be\/HQi6C-A966U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306636631132225536",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/NcGuPyDN6O Danica Patrick's Godaddy com",
  "id" : 306636631132225536,
  "created_at" : "2013-02-27 05:27:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZL78rnWYie",
      "expanded_url" : "http:\/\/youtu.be\/0p92AoBB1Y0?a",
      "display_url" : "youtu.be\/0p92AoBB1Y0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306636278575808512",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ZL78rnWYie Go Daddy Cherry Stem Commercial",
  "id" : 306636278575808512,
  "created_at" : "2013-02-27 05:26:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/O35pxRt5hN",
      "expanded_url" : "http:\/\/youtu.be\/YJgldvU6rfs?a",
      "display_url" : "youtu.be\/YJgldvU6rfs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306635580450676736",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/O35pxRt5hN Bar Refaeli ~ Go Daddy Super Bowl Official Go Daddy Super Bowl Video",
  "id" : 306635580450676736,
  "created_at" : "2013-02-27 05:23:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/YRm6Rr6TRH",
      "expanded_url" : "http:\/\/youtu.be\/AnFEaHFBr4E?a",
      "display_url" : "youtu.be\/AnFEaHFBr4E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306633869187223553",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/YRm6Rr6TRH Go Daddy Superbowl Commercial- The Kiss- NOCd Up- Ep 144",
  "id" : 306633869187223553,
  "created_at" : "2013-02-27 05:16:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/39lSCAjeTH",
      "expanded_url" : "http:\/\/youtu.be\/1R_0H73Ae9s?a",
      "display_url" : "youtu.be\/1R_0H73Ae9s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306633492295454721",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/39lSCAjeTH \"Eternal\" Scene",
  "id" : 306633492295454721,
  "created_at" : "2013-02-27 05:14:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/z7QboQ4KuW",
      "expanded_url" : "http:\/\/youtu.be\/l507nGV3LXo?a",
      "display_url" : "youtu.be\/l507nGV3LXo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306632720010858497",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/z7QboQ4KuW HIMYM - I Kissed A Girl",
  "id" : 306632720010858497,
  "created_at" : "2013-02-27 05:11:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/oUcdqba2mj",
      "expanded_url" : "http:\/\/youtu.be\/hLp9Co66SKQ?a",
      "display_url" : "youtu.be\/hLp9Co66SKQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306632626658242560",
  "text" : "Thanks for completely ruining that show, liberal media (@YouTube http:\/\/t.co\/oUcdqba2mj)",
  "id" : 306632626658242560,
  "created_at" : "2013-02-27 05:11:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/wwVWs8cc9v",
      "expanded_url" : "http:\/\/youtu.be\/47sJwR2MUU4?a",
      "display_url" : "youtu.be\/47sJwR2MUU4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306630359364300802",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/wwVWs8cc9v Drunk College Girls Kiss (First Lesbian Experience)",
  "id" : 306630359364300802,
  "created_at" : "2013-02-27 05:02:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/QKu0POLUNt",
      "expanded_url" : "http:\/\/youtu.be\/GS4vnBezRLI?a",
      "display_url" : "youtu.be\/GS4vnBezRLI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306630199045414913",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/QKu0POLUNt Sexy Drunk Girls Have First Lesbian Experience",
  "id" : 306630199045414913,
  "created_at" : "2013-02-27 05:01:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6RoyYpKq9n",
      "expanded_url" : "http:\/\/youtu.be\/iAhtvEM5_KE?a",
      "display_url" : "youtu.be\/iAhtvEM5_KE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629805795852288",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6RoyYpKq9n Smoking Hot Lesbians Kissing 2",
  "id" : 306629805795852288,
  "created_at" : "2013-02-27 05:00:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/T0NHQPJFLh",
      "expanded_url" : "http:\/\/youtu.be\/8Eae6SbpH64?a",
      "display_url" : "youtu.be\/8Eae6SbpH64?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629406569426945",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/T0NHQPJFLh Sexy Drunk Girls Have First Lesbian Experience",
  "id" : 306629406569426945,
  "created_at" : "2013-02-27 04:58:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/xHYgWxiuAn",
      "expanded_url" : "http:\/\/youtu.be\/P6P3HnINybg?a",
      "display_url" : "youtu.be\/P6P3HnINybg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629250780393472",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/xHYgWxiuAn Two Girls Tongue Kissing in public!",
  "id" : 306629250780393472,
  "created_at" : "2013-02-27 04:58:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6ejNtnQhxQ",
      "expanded_url" : "http:\/\/youtu.be\/k1YL_b0Tni0?a",
      "display_url" : "youtu.be\/k1YL_b0Tni0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629146971369472",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/6ejNtnQhxQ HOTTEST LESBIAN MAKE OUT EVER",
  "id" : 306629146971369472,
  "created_at" : "2013-02-27 04:57:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/LBaPLwS65O",
      "expanded_url" : "http:\/\/youtu.be\/CZuXdfaf0JU?a",
      "display_url" : "youtu.be\/CZuXdfaf0JU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629028926849024",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/LBaPLwS65O Sexy Latin Make Out Session",
  "id" : 306629028926849024,
  "created_at" : "2013-02-27 04:57:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/y5QE13TJvk",
      "expanded_url" : "http:\/\/youtu.be\/zfH40RUQOFM?a",
      "display_url" : "youtu.be\/zfH40RUQOFM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306629004255969280",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/y5QE13TJvk Sexy Lesbian Girls Kissing",
  "id" : 306629004255969280,
  "created_at" : "2013-02-27 04:57:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VUGv0jX0uT",
      "expanded_url" : "http:\/\/youtu.be\/-ddkgVHr-KA?a",
      "display_url" : "youtu.be\/-ddkgVHr-KA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306628606623363072",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/VUGv0jX0uT Ann &amp; Robin having fun",
  "id" : 306628606623363072,
  "created_at" : "2013-02-27 04:55:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/jSYcAynVdU",
      "expanded_url" : "http:\/\/youtu.be\/8zlUpEYktuc?a",
      "display_url" : "youtu.be\/8zlUpEYktuc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306628446103162881",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/jSYcAynVdU \"My First Lesbian Experience..\" (2012)",
  "id" : 306628446103162881,
  "created_at" : "2013-02-27 04:54:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/okjLB7gBvo",
      "expanded_url" : "http:\/\/youtu.be\/iNQ3v-MYeqQ?a",
      "display_url" : "youtu.be\/iNQ3v-MYeqQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306628131387764737",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/okjLB7gBvo Sophie &amp; Sian - All Kisses",
  "id" : 306628131387764737,
  "created_at" : "2013-02-27 04:53:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/nXjuE3E7cC",
      "expanded_url" : "http:\/\/youtu.be\/1tAXNi1UNd8?a",
      "display_url" : "youtu.be\/1tAXNi1UNd8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306257255815331840",
  "text" : "I liked a @YouTube video http:\/\/t.co\/nXjuE3E7cC Kid sings Bon Jovi",
  "id" : 306257255815331840,
  "created_at" : "2013-02-26 04:19:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/nXjuE3E7cC",
      "expanded_url" : "http:\/\/youtu.be\/1tAXNi1UNd8?a",
      "display_url" : "youtu.be\/1tAXNi1UNd8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306257245488939008",
  "text" : "Are we doing the youtube partnership thing (@YouTube http:\/\/t.co\/nXjuE3E7cC)",
  "id" : 306257245488939008,
  "created_at" : "2013-02-26 04:19:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 78, 86 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/dhMv4fi2on",
      "expanded_url" : "http:\/\/youtu.be\/Pb1tknG58D4?a",
      "display_url" : "youtu.be\/Pb1tknG58D4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306132727936188416",
  "text" : "RFID CHIP MAY COME TO ISRAEL AFTER IT COMES TO US: http:\/\/t.co\/dhMv4fi2on via @YouTube",
  "id" : 306132727936188416,
  "created_at" : "2013-02-25 20:05:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/r3tzmsoB1C",
      "expanded_url" : "http:\/\/youtu.be\/KpQtc7-YKWg?a",
      "display_url" : "youtu.be\/KpQtc7-YKWg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "306125696693055488",
  "text" : "US Government Health Care Mandate Implaments Mark of the Beast: http:\/\/t.co\/r3tzmsoB1C via @YouTube",
  "id" : 306125696693055488,
  "created_at" : "2013-02-25 19:37:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/P1tPLGHKnB",
      "expanded_url" : "http:\/\/youtu.be\/iO0OL_TjILs?a",
      "display_url" : "youtu.be\/iO0OL_TjILs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305885302793330688",
  "text" : "What happened to all your videos, you were amazing, are we doing that youtube partnership (@YouTube http:\/\/t.co\/P1tPLGHKnB)",
  "id" : 305885302793330688,
  "created_at" : "2013-02-25 03:41:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/KevN8ymXNu",
      "expanded_url" : "http:\/\/youtu.be\/povomwhfZas?a",
      "display_url" : "youtu.be\/povomwhfZas?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305883120937357312",
  "text" : "I liked a @YouTube video http:\/\/t.co\/KevN8ymXNu All Shook Up (AMKAMAL COVERUP)",
  "id" : 305883120937357312,
  "created_at" : "2013-02-25 03:33:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305820230700126208",
  "text" : "Okay post my youtube channel link in your youtube channel description, also I suggest you sing (@YouTube http:\/\/t.co\/nQlAd2wjsL)",
  "id" : 305820230700126208,
  "created_at" : "2013-02-24 23:23:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305732367434260480",
  "text" : "Yup, just post the link on your youtube description, and I will continue sending you these (@YouTube http:\/\/t.co\/nQlAd2wjsL)",
  "id" : 305732367434260480,
  "created_at" : "2013-02-24 17:34:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305728492849463296",
  "text" : "Okay I will post the videos in my popular channel, if you send them to me, but they will be (@YouTube http:\/\/t.co\/nQlAd2wjsL)",
  "id" : 305728492849463296,
  "created_at" : "2013-02-24 17:18:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/er5dWGGJX1",
      "expanded_url" : "http:\/\/youtu.be\/1lV5X3rBkrM?a",
      "display_url" : "youtu.be\/1lV5X3rBkrM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305530897954906112",
  "text" : "I liked a @YouTube video http:\/\/t.co\/er5dWGGJX1 That's How We Connect Roe T.",
  "id" : 305530897954906112,
  "created_at" : "2013-02-24 04:13:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Tcw3O0zxKW",
      "expanded_url" : "http:\/\/youtu.be\/_7coMmh9WYA?a",
      "display_url" : "youtu.be\/_7coMmh9WYA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305524256513609728",
  "text" : "I liked a @YouTube video http:\/\/t.co\/Tcw3O0zxKW Tim McGraw Truck Yeah--Me Singing",
  "id" : 305524256513609728,
  "created_at" : "2013-02-24 03:47:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 44, 52 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/6d1FD03OBb",
      "expanded_url" : "http:\/\/youtu.be\/8qYvtn6AfYs?a",
      "display_url" : "youtu.be\/8qYvtn6AfYs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305523818515021824",
  "text" : "I will send you hundreds of subscribers :) (@YouTube http:\/\/t.co\/6d1FD03OBb)",
  "id" : 305523818515021824,
  "created_at" : "2013-02-24 03:45:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305522991503114240",
  "text" : "I will make you famous, I promise, how would you like to be part of my youtube partnership, my (@YouTube http:\/\/t.co\/nQlAd2wjsL)",
  "id" : 305522991503114240,
  "created_at" : "2013-02-24 03:42:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305517333160550400",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/nQlAd2wjsL Celine Dion I'm Alive--Me Singing",
  "id" : 305517333160550400,
  "created_at" : "2013-02-24 03:19:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/EycuyPQJI4",
      "expanded_url" : "http:\/\/youtu.be\/e7twxLwN3F0?a",
      "display_url" : "youtu.be\/e7twxLwN3F0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305517219104841728",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/EycuyPQJI4 Could I Have This Dance Anne Murray--Me Singing",
  "id" : 305517219104841728,
  "created_at" : "2013-02-24 03:19:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EycuyPQJI4",
      "expanded_url" : "http:\/\/youtu.be\/e7twxLwN3F0?a",
      "display_url" : "youtu.be\/e7twxLwN3F0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305517152310550528",
  "text" : "I liked a @YouTube video http:\/\/t.co\/EycuyPQJI4 Could I Have This Dance Anne Murray--Me Singing",
  "id" : 305517152310550528,
  "created_at" : "2013-02-24 03:19:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305516316784205824",
  "text" : "I will make sure this gets thousands of views. (@YouTube http:\/\/t.co\/nQlAd2wjsL)",
  "id" : 305516316784205824,
  "created_at" : "2013-02-24 03:15:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/nQlAd2wjsL",
      "expanded_url" : "http:\/\/youtu.be\/mV9l08Ji7G4?a",
      "display_url" : "youtu.be\/mV9l08Ji7G4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305515895533473793",
  "text" : "I liked a @YouTube video http:\/\/t.co\/nQlAd2wjsL Celine Dion I'm Alive--Me Singing",
  "id" : 305515895533473793,
  "created_at" : "2013-02-24 03:14:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/dtGuPepcop",
      "expanded_url" : "http:\/\/youtu.be\/qjUWl0MnVhk?a",
      "display_url" : "youtu.be\/qjUWl0MnVhk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305087689135366144",
  "text" : "I liked a @YouTube video http:\/\/t.co\/dtGuPepcop Lemonade Mouth Determinate--Me Singing",
  "id" : 305087689135366144,
  "created_at" : "2013-02-22 22:52:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 32, 40 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/6d1FD03OBb",
      "expanded_url" : "http:\/\/youtu.be\/8qYvtn6AfYs?a",
      "display_url" : "youtu.be\/8qYvtn6AfYs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305087475100033024",
  "text" : "Also without the hand gestures (@YouTube http:\/\/t.co\/6d1FD03OBb)",
  "id" : 305087475100033024,
  "created_at" : "2013-02-22 22:51:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/6d1FD03OBb",
      "expanded_url" : "http:\/\/youtu.be\/8qYvtn6AfYs?a",
      "display_url" : "youtu.be\/8qYvtn6AfYs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305087022299766785",
  "text" : "I liked a @YouTube video http:\/\/t.co\/6d1FD03OBb Eye Of The Tiger Survivor--Me Singing",
  "id" : 305087022299766785,
  "created_at" : "2013-02-22 22:49:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/OY7cqC2vUo",
      "expanded_url" : "http:\/\/youtu.be\/QO2_8WqFmxM?a",
      "display_url" : "youtu.be\/QO2_8WqFmxM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305008016460247040",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/OY7cqC2vUo Coptic Orphans - Join The Movement",
  "id" : 305008016460247040,
  "created_at" : "2013-02-22 17:35:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/DBiaNq1gwr",
      "expanded_url" : "http:\/\/youtu.be\/-pMYTMnaXyA?a",
      "display_url" : "youtu.be\/-pMYTMnaXyA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305007670555975681",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/DBiaNq1gwr The Liturgy before the Funeral Service for H.H. Pope Shenouda III",
  "id" : 305007670555975681,
  "created_at" : "2013-02-22 17:34:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/PAVTTP3kXO",
      "expanded_url" : "http:\/\/youtu.be\/3AnSSzTDQpI?a",
      "display_url" : "youtu.be\/3AnSSzTDQpI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305007589157134336",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/PAVTTP3kXO Papal Altar Lot Liturgy",
  "id" : 305007589157134336,
  "created_at" : "2013-02-22 17:34:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ckru3MgtFq",
      "expanded_url" : "http:\/\/youtu.be\/1O-y0F9F4ZY?a",
      "display_url" : "youtu.be\/1O-y0F9F4ZY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305007419157794817",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ckru3MgtFq HH Pope Tawadros answers many questions concerning many issues",
  "id" : 305007419157794817,
  "created_at" : "2013-02-22 17:33:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/JG0n7ruAf4",
      "expanded_url" : "http:\/\/youtu.be\/G-XFI23Yi74?a",
      "display_url" : "youtu.be\/G-XFI23Yi74?a"
    } ]
  },
  "geo" : { },
  "id_str" : "305007375155331073",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/JG0n7ruAf4 the way of loving neighbor: Pope Tawadros weekly sermon 13 Feb 2013",
  "id" : 305007375155331073,
  "created_at" : "2013-02-22 17:33:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/D21xcwx4rw",
      "expanded_url" : "http:\/\/youtu.be\/8nsXrsng3c4?a",
      "display_url" : "youtu.be\/8nsXrsng3c4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "304455620730433536",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/D21xcwx4rw Hava' Nagila (My New Version of the Song)",
  "id" : 304455620730433536,
  "created_at" : "2013-02-21 05:00:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ideaneurs Mag ",
      "screen_name" : "IdeaneursMag",
      "indices" : [ 0, 13 ],
      "id_str" : "1202015275",
      "id" : 1202015275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/yEoRMO29Ma",
      "expanded_url" : "http:\/\/andrew-magdy-kamal.wikispaces.com\/",
      "display_url" : "andrew-magdy-kamal.wikispaces.com"
    } ]
  },
  "in_reply_to_status_id_str" : "304337014575226880",
  "geo" : { },
  "id_str" : "304344880182878208",
  "in_reply_to_user_id" : 1202015275,
  "text" : "@IdeaneursMag Hello this is my profile http:\/\/t.co\/yEoRMO29Ma what do you think about putting me in your magazine?",
  "id" : 304344880182878208,
  "in_reply_to_status_id" : 304337014575226880,
  "created_at" : "2013-02-20 21:40:48 +0000",
  "in_reply_to_screen_name" : "IdeaneursMag",
  "in_reply_to_user_id_str" : "1202015275",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Franky",
      "screen_name" : "Frankiezzy",
      "indices" : [ 34, 45 ],
      "id_str" : "464026538",
      "id" : 464026538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/7HZSE5bH",
      "expanded_url" : "http:\/\/youtu.be\/N2-4TENZ1NQ?a",
      "display_url" : "youtu.be\/N2-4TENZ1NQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303922832654618625",
  "text" : "I favorited a @YouTube video from @frankiezzy http:\/\/t.co\/7HZSE5bH We Won!",
  "id" : 303922832654618625,
  "created_at" : "2013-02-19 17:43:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Franky",
      "screen_name" : "Frankiezzy",
      "indices" : [ 30, 41 ],
      "id_str" : "464026538",
      "id" : 464026538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/7HZSE5bH",
      "expanded_url" : "http:\/\/youtu.be\/N2-4TENZ1NQ?a",
      "display_url" : "youtu.be\/N2-4TENZ1NQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303922824098222080",
  "text" : "I liked a @YouTube video from @frankiezzy http:\/\/t.co\/7HZSE5bH We Won!",
  "id" : 303922824098222080,
  "created_at" : "2013-02-19 17:43:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/dx09a3HH",
      "expanded_url" : "http:\/\/youtu.be\/WKwrDEkXYNM?a",
      "display_url" : "youtu.be\/WKwrDEkXYNM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303334043091615744",
  "text" : "Watch this http:\/\/t.co\/dx09a3HH",
  "id" : 303334043091615744,
  "created_at" : "2013-02-18 02:44:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/ecEh6Nlj",
      "expanded_url" : "http:\/\/youtu.be\/IW2RdCaV8cg?a",
      "display_url" : "youtu.be\/IW2RdCaV8cg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303259096755343360",
  "text" : "Cracking the Revelations Code: http:\/\/t.co\/ecEh6Nlj via @YouTube",
  "id" : 303259096755343360,
  "created_at" : "2013-02-17 21:46:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/1ShmUtIa",
      "expanded_url" : "http:\/\/youtu.be\/bHDEl9P6o_k?a",
      "display_url" : "youtu.be\/bHDEl9P6o_k?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303205479960694784",
  "text" : "I liked a @YouTube video http:\/\/t.co\/1ShmUtIa \u062A\u0631\u0646\u064A\u0645\u0629 \u0631\u0648\u062D \u0627\u0644\u0644\u0647 \u0646\u062F\u0639\u0648\u0643 - \u0641\u0631\u064A\u0642 \u0627\u0644\u062D\u064A\u0627\u0629 \u0627\u0644\u0623\u0641\u0636\u0644",
  "id" : 303205479960694784,
  "created_at" : "2013-02-17 18:13:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/3pcic1ol",
      "expanded_url" : "http:\/\/youtu.be\/9CkKuA86Mis?a",
      "display_url" : "youtu.be\/9CkKuA86Mis?a"
    } ]
  },
  "geo" : { },
  "id_str" : "303204302585987073",
  "text" : "I liked a @YouTube video http:\/\/t.co\/3pcic1ol Celine Dion - Because You Loved Me lyrics",
  "id" : 303204302585987073,
  "created_at" : "2013-02-17 18:08:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/C8psz4uQ",
      "expanded_url" : "http:\/\/youtu.be\/TcTbkxt4TY4?a",
      "display_url" : "youtu.be\/TcTbkxt4TY4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302995990741405698",
  "text" : "Look at this the rapture is soon http:\/\/t.co\/C8psz4uQ",
  "id" : 302995990741405698,
  "created_at" : "2013-02-17 04:20:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/kCgaesco",
      "expanded_url" : "http:\/\/youtu.be\/k3OBcLerJn8?a",
      "display_url" : "youtu.be\/k3OBcLerJn8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302979254881234946",
  "text" : "Hey, look at this new video. http:\/\/t.co\/kCgaesco",
  "id" : 302979254881234946,
  "created_at" : "2013-02-17 03:14:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leticia Miranda",
      "screen_name" : "leticia",
      "indices" : [ 26, 34 ],
      "id_str" : "96904590",
      "id" : 96904590
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 45, 53 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/nxAMD8Cn",
      "expanded_url" : "http:\/\/youtu.be\/mdS0ZIn7ssw?a",
      "display_url" : "youtu.be\/mdS0ZIn7ssw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302879157640130560",
  "text" : "God bless you dear friend @Leticia Quinonez (@YouTube http:\/\/t.co\/nxAMD8Cn)",
  "id" : 302879157640130560,
  "created_at" : "2013-02-16 20:36:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/DHtKKGYs",
      "expanded_url" : "http:\/\/youtu.be\/iP7BKHU4WUc?a",
      "display_url" : "youtu.be\/iP7BKHU4WUc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302251004630560768",
  "text" : "I liked a @YouTube video http:\/\/t.co\/DHtKKGYs Hydrographics- Dipping my hand in carbon fiber film",
  "id" : 302251004630560768,
  "created_at" : "2013-02-15 03:00:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/kRQOnmwX",
      "expanded_url" : "http:\/\/youtu.be\/NXAFV77Vy5w?a",
      "display_url" : "youtu.be\/NXAFV77Vy5w?a"
    } ]
  },
  "geo" : { },
  "id_str" : "302250157318209536",
  "text" : "I liked a @YouTube video http:\/\/t.co\/kRQOnmwX !!! PORTAL OPEN AGAIN - LIGHTSHIPS COMING OUT !!! @ SAKURAJIMA VOLCANO JAPAN 2013",
  "id" : 302250157318209536,
  "created_at" : "2013-02-15 02:57:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/uR561L94",
      "expanded_url" : "http:\/\/youtu.be\/MCgZUymnr_U?a",
      "display_url" : "youtu.be\/MCgZUymnr_U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "301744271357276161",
  "text" : "I liked a @YouTube video http:\/\/t.co\/uR561L94 Dany Surface - Hopeless (Original)",
  "id" : 301744271357276161,
  "created_at" : "2013-02-13 17:26:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 39, 47 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/1F4quYBs",
      "expanded_url" : "http:\/\/youtu.be\/8nsXrsng3c4?a",
      "display_url" : "youtu.be\/8nsXrsng3c4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300760356266049536",
  "text" : "Hava' Nagila: http:\/\/t.co\/1F4quYBs via @YouTube",
  "id" : 300760356266049536,
  "created_at" : "2013-02-11 00:17:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 40, 48 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/W8fRsdXk",
      "expanded_url" : "http:\/\/youtu.be\/uQ9dVpnuGto?a",
      "display_url" : "youtu.be\/uQ9dVpnuGto?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300754347208368128",
  "text" : "Elohim Melody: http:\/\/t.co\/W8fRsdXk via @YouTube",
  "id" : 300754347208368128,
  "created_at" : "2013-02-10 23:53:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/SYtgcmUi",
      "expanded_url" : "http:\/\/youtu.be\/-Z-tNoGpnYo?a",
      "display_url" : "youtu.be\/-Z-tNoGpnYo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300752176391802881",
  "text" : "A Very Beautiful Song for Israel: http:\/\/t.co\/SYtgcmUi via @YouTube",
  "id" : 300752176391802881,
  "created_at" : "2013-02-10 23:44:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/n22mVYo2",
      "expanded_url" : "http:\/\/youtu.be\/K4bvCY9wA1Y?a",
      "display_url" : "youtu.be\/K4bvCY9wA1Y?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300277507763077121",
  "text" : "Sweet gaming, this epicness, I mean very cool, lol will watch more of your videos soon, this (@YouTube http:\/\/t.co\/n22mVYo2)",
  "id" : 300277507763077121,
  "created_at" : "2013-02-09 16:18:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 54, 62 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/uuFOlNlH",
      "expanded_url" : "http:\/\/youtu.be\/qGsDpIJMZss?a",
      "display_url" : "youtu.be\/qGsDpIJMZss?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300277245736542208",
  "text" : "NICEEEEEEEEEEEEEEEEEEEEEEEEE, COOL MIXING&lt; TRACKS (@YouTube http:\/\/t.co\/uuFOlNlH)",
  "id" : 300277245736542208,
  "created_at" : "2013-02-09 16:17:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/L0ZeQKu4",
      "expanded_url" : "http:\/\/youtu.be\/lTUs3-N-uIU?a",
      "display_url" : "youtu.be\/lTUs3-N-uIU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300277038177218560",
  "text" : "COOOOOOOOOOOOOOOOL&lt; GAMING+EPICNESS= DAYZ MOD+ THIS IS EPIC (@YouTube http:\/\/t.co\/L0ZeQKu4)",
  "id" : 300277038177218560,
  "created_at" : "2013-02-09 16:16:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/cAYijmxf",
      "expanded_url" : "http:\/\/youtu.be\/Hi2eVmTAdIs?a",
      "display_url" : "youtu.be\/Hi2eVmTAdIs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300276393885970433",
  "text" : "This is so CUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUTE (@YouTube http:\/\/t.co\/cAYijmxf)",
  "id" : 300276393885970433,
  "created_at" : "2013-02-09 16:14:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/1NuzPgZl",
      "expanded_url" : "http:\/\/youtu.be\/EWK9CxOx0EY?a",
      "display_url" : "youtu.be\/EWK9CxOx0EY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300276098133008385",
  "text" : "What the heck, lol, you make comedy like videos, anyways this is pretty funny, made me laugh (@YouTube http:\/\/t.co\/1NuzPgZl)",
  "id" : 300276098133008385,
  "created_at" : "2013-02-09 16:12:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/rxs4RiOz",
      "expanded_url" : "http:\/\/youtu.be\/GMBxI53BrwA?a",
      "display_url" : "youtu.be\/GMBxI53BrwA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300275901810225152",
  "text" : "Hah, this is pretty funny lol, funny stuff, anyways cool channel, make more videos, because (@YouTube http:\/\/t.co\/rxs4RiOz)",
  "id" : 300275901810225152,
  "created_at" : "2013-02-09 16:12:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/GEQEUdXb",
      "expanded_url" : "http:\/\/youtu.be\/wphN2sAUTSg?a",
      "display_url" : "youtu.be\/wphN2sAUTSg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300275444949856256",
  "text" : "Thanks for the subscribing, that was pretty cool of you. anyways nice motion put into your (@YouTube http:\/\/t.co\/GEQEUdXb)",
  "id" : 300275444949856256,
  "created_at" : "2013-02-09 16:10:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/TWmXGGLD",
      "expanded_url" : "http:\/\/youtu.be\/K6IhEHhiaVg?a",
      "display_url" : "youtu.be\/K6IhEHhiaVg?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300275117626363906",
  "text" : "Sweet, pokemon is so epic, I want to catch them all, have you seen the Justy Field Episode 18 (@YouTube http:\/\/t.co\/TWmXGGLD)",
  "id" : 300275117626363906,
  "created_at" : "2013-02-09 16:09:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/PVKMlpMx",
      "expanded_url" : "http:\/\/youtu.be\/KhzPnAAHJQY?a",
      "display_url" : "youtu.be\/KhzPnAAHJQY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300274882544029696",
  "text" : "Epic effects, pretty cool dude, may have acquired some auto tuning, but this is pretty cool, (@YouTube http:\/\/t.co\/PVKMlpMx)",
  "id" : 300274882544029696,
  "created_at" : "2013-02-09 16:08:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/L0ZeQKu4",
      "expanded_url" : "http:\/\/youtu.be\/lTUs3-N-uIU?a",
      "display_url" : "youtu.be\/lTUs3-N-uIU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "300274602268057600",
  "text" : "Nice hack, extremely cool, will watch again, I mean this is really cool way to enhance gaming (@YouTube http:\/\/t.co\/L0ZeQKu4)",
  "id" : 300274602268057600,
  "created_at" : "2013-02-09 16:06:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/5GYSrtIC",
      "expanded_url" : "http:\/\/youtu.be\/1JUPG01nAAE?a",
      "display_url" : "youtu.be\/1JUPG01nAAE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299940143429730304",
  "text" : "There is a southern style Bangerz, cool, do you use hip hop instrumentals to make this video (@YouTube http:\/\/t.co\/5GYSrtIC)",
  "id" : 299940143429730304,
  "created_at" : "2013-02-08 17:57:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/srd2yYuw",
      "expanded_url" : "http:\/\/youtu.be\/STkzkDe3GHc?a",
      "display_url" : "youtu.be\/STkzkDe3GHc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299939126461988864",
  "text" : "Rapping is good when it is clean. Anyways nice free style, cool beats dude (@YouTube http:\/\/t.co\/srd2yYuw)",
  "id" : 299939126461988864,
  "created_at" : "2013-02-08 17:53:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/pTvSWTxE",
      "expanded_url" : "http:\/\/youtu.be\/JnHPO0GSQe8?a",
      "display_url" : "youtu.be\/JnHPO0GSQe8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299938918390976512",
  "text" : "Cool video effects, lol, anyways nice channel. I will watch more videos, this channel seems (@YouTube http:\/\/t.co\/pTvSWTxE)",
  "id" : 299938918390976512,
  "created_at" : "2013-02-08 17:53:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/pTvSWTxE",
      "expanded_url" : "http:\/\/youtu.be\/JnHPO0GSQe8?a",
      "display_url" : "youtu.be\/JnHPO0GSQe8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299938661049446400",
  "text" : "Cool video effects, lol, anyways nice channel. (@YouTube http:\/\/t.co\/pTvSWTxE)",
  "id" : 299938661049446400,
  "created_at" : "2013-02-08 17:52:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 14, 22 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Wongene",
      "screen_name" : "WongeneKIM",
      "indices" : [ 34, 45 ],
      "id_str" : "824532702",
      "id" : 824532702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/QWle3drH",
      "expanded_url" : "http:\/\/youtu.be\/h1cXGclpGnA?a",
      "display_url" : "youtu.be\/h1cXGclpGnA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299937808041271296",
  "text" : "I favorited a @YouTube video from @wongenekim http:\/\/t.co\/QWle3drH \"Minecraft Style\" - A Parody of PSY's Gangnam Style",
  "id" : 299937808041271296,
  "created_at" : "2013-02-08 17:48:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 52, 60 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/tith39M4",
      "expanded_url" : "http:\/\/youtu.be\/qcXjNNMKAHc?a",
      "display_url" : "youtu.be\/qcXjNNMKAHc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299937455967174657",
  "text" : "Super cool video. AWSOME!!! Will like this channel (@YouTube http:\/\/t.co\/tith39M4)",
  "id" : 299937455967174657,
  "created_at" : "2013-02-08 17:47:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/VjYPmDIQ",
      "expanded_url" : "http:\/\/youtu.be\/oA6ftwZSH64?a",
      "display_url" : "youtu.be\/oA6ftwZSH64?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299935896919236608",
  "text" : "Awsome beats dude, what software did you use, because your videos are so cool. I am totally (@YouTube http:\/\/t.co\/VjYPmDIQ)",
  "id" : 299935896919236608,
  "created_at" : "2013-02-08 17:41:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 95, 103 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/qnQHCVyq",
      "expanded_url" : "http:\/\/youtu.be\/AbmG6fg35BA?a",
      "display_url" : "youtu.be\/AbmG6fg35BA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299935636360658945",
  "text" : "Sweet gaming dude, wow your channel is awsome, I am totally subscribing. I like watching cool (@YouTube http:\/\/t.co\/qnQHCVyq)",
  "id" : 299935636360658945,
  "created_at" : "2013-02-08 17:40:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/rajybI5l",
      "expanded_url" : "http:\/\/youtu.be\/V5Hkvzccb5E?a",
      "display_url" : "youtu.be\/V5Hkvzccb5E?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299935384081674240",
  "text" : "This is just great, wow keep up the good work. Nice video, will watch again, sweet beats man (@YouTube http:\/\/t.co\/rajybI5l)",
  "id" : 299935384081674240,
  "created_at" : "2013-02-08 17:39:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/NJ4PuFIr",
      "expanded_url" : "http:\/\/youtu.be\/FUYSdSeptCQ?a",
      "display_url" : "youtu.be\/FUYSdSeptCQ?a"
    } ]
  },
  "geo" : { },
  "id_str" : "299935266385317890",
  "text" : "Awsome thanks, this is so cool, people subscribe to this channel. I will watch this video (@YouTube http:\/\/t.co\/NJ4PuFIr)",
  "id" : 299935266385317890,
  "created_at" : "2013-02-08 17:38:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/aDo1CQZT",
      "expanded_url" : "http:\/\/youtu.be\/hORO5Hg-jZc?a",
      "display_url" : "youtu.be\/hORO5Hg-jZc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "298855669929480192",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/aDo1CQZT BANNED ADS, NAMM 13 COVERAGE AND COMPANY OF THIEVES!!! SHOWCAINE",
  "id" : 298855669929480192,
  "created_at" : "2013-02-05 18:08:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 61, 69 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/6TUAYWfF",
      "expanded_url" : "http:\/\/youtu.be\/QaRplfMT1So?a",
      "display_url" : "youtu.be\/QaRplfMT1So?a"
    } ]
  },
  "geo" : { },
  "id_str" : "297766787855024130",
  "text" : "I am part of string theory developement group and I love it (@YouTube http:\/\/t.co\/6TUAYWfF)",
  "id" : 297766787855024130,
  "created_at" : "2013-02-02 18:01:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 25, 33 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/3gNUysQ4",
      "expanded_url" : "http:\/\/youtu.be\/mwd_AjQks-M?a",
      "display_url" : "youtu.be\/mwd_AjQks-M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "297766328041865216",
  "text" : "bought it long time ago (@YouTube http:\/\/t.co\/3gNUysQ4)",
  "id" : 297766328041865216,
  "created_at" : "2013-02-02 17:59:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/qQYm8lOf",
      "expanded_url" : "http:\/\/youtu.be\/NkIlkuYIgpk?a",
      "display_url" : "youtu.be\/NkIlkuYIgpk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "297765893260337152",
  "text" : "I got it from ebay for $2.63 but it is also available on dealextreme (@YouTube http:\/\/t.co\/qQYm8lOf)",
  "id" : 297765893260337152,
  "created_at" : "2013-02-02 17:58:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/qQYm8lOf",
      "expanded_url" : "http:\/\/youtu.be\/NkIlkuYIgpk?a",
      "display_url" : "youtu.be\/NkIlkuYIgpk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "297765698900484096",
  "text" : "I liked a @YouTube video http:\/\/t.co\/qQYm8lOf Gold Bar Lighter",
  "id" : 297765698900484096,
  "created_at" : "2013-02-02 17:57:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/S31PFtU5",
      "expanded_url" : "http:\/\/youtu.be\/fJR84trAP7Q?a",
      "display_url" : "youtu.be\/fJR84trAP7Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "297421430981795840",
  "text" : "Thats me (@YouTube http:\/\/t.co\/S31PFtU5)",
  "id" : 297421430981795840,
  "created_at" : "2013-02-01 19:09:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]