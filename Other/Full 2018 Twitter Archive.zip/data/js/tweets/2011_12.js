Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/eEd1OaCo",
      "expanded_url" : "http:\/\/Appsgeyser.com",
      "display_url" : "Appsgeyser.com"
    }, {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/rt1DOQYd",
      "expanded_url" : "http:\/\/www.appsgeyser.com\/114374",
      "display_url" : "appsgeyser.com\/114374"
    } ]
  },
  "geo" : { },
  "id_str" : "151377605696815105",
  "text" : "I've found ANDsocialREW Android App built by http:\/\/t.co\/eEd1OaCo. Get it here http:\/\/t.co\/rt1DOQYd",
  "id" : 151377605696815105,
  "created_at" : "2011-12-26 19:03:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150384735410065408",
  "geo" : { },
  "id_str" : "150394774753513474",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me ############",
  "id" : 150394774753513474,
  "in_reply_to_status_id" : 150384735410065408,
  "created_at" : "2011-12-24 01:58:03 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150394659653431296",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me #####################",
  "id" : 150394659653431296,
  "created_at" : "2011-12-24 01:57:35 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150375394858643456",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me\n)__)__)__)_",
  "id" : 150375394858643456,
  "created_at" : "2011-12-24 00:41:02 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150341800421367808",
  "geo" : { },
  "id_str" : "150375301308891136",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me *********",
  "id" : 150375301308891136,
  "in_reply_to_status_id" : 150341800421367808,
  "created_at" : "2011-12-24 00:40:40 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150268464995631104",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me &lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&lt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;",
  "id" : 150268464995631104,
  "created_at" : "2011-12-23 17:36:08 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 39, 51 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "150169196356059136",
  "geo" : { },
  "id_str" : "150261827715072001",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 are u going to follow me at @gamer456148",
  "id" : 150261827715072001,
  "in_reply_to_status_id" : 150169196356059136,
  "created_at" : "2011-12-23 17:09:46 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150261237480042496",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 are u gonna follow me",
  "id" : 150261237480042496,
  "created_at" : "2011-12-23 17:07:25 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150234508921278464",
  "text" : "@ColemanArmy im not no doll, im a 15yr old man",
  "id" : 150234508921278464,
  "created_at" : "2011-12-23 15:21:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149907996028321792",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me ~~~~",
  "id" : 149907996028321792,
  "created_at" : "2011-12-22 17:43:46 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149888097482579968",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Please follow me\n:::::::::::::::::::::::::::::::::::::::::::::::::::::::",
  "id" : 149888097482579968,
  "created_at" : "2011-12-22 16:24:41 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149887951147507712",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me please",
  "id" : 149887951147507712,
  "created_at" : "2011-12-22 16:24:06 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149564018904940545",
  "geo" : { },
  "id_str" : "149887901545676800",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me\n0000000000000000000000",
  "id" : 149887901545676800,
  "in_reply_to_status_id" : 149564018904940545,
  "created_at" : "2011-12-22 16:23:55 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149633536113127424",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me*****************",
  "id" : 149633536113127424,
  "created_at" : "2011-12-21 23:33:09 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149627634018553856",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me",
  "id" : 149627634018553856,
  "created_at" : "2011-12-21 23:09:42 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149622574702272512",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me=====================",
  "id" : 149622574702272512,
  "created_at" : "2011-12-21 22:49:36 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149619896899219457",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me---=p---=p",
  "id" : 149619896899219457,
  "created_at" : "2011-12-21 22:38:57 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149608382746198017",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me pleazzzzz",
  "id" : 149608382746198017,
  "created_at" : "2011-12-21 21:53:12 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149603075106156545",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me--------------------------------------",
  "id" : 149603075106156545,
  "created_at" : "2011-12-21 21:32:07 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149588095975698433",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me___________________________",
  "id" : 149588095975698433,
  "created_at" : "2011-12-21 20:32:35 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149574967988719616",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me -=========------=-=-=---",
  "id" : 149574967988719616,
  "created_at" : "2011-12-21 19:40:25 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149564018904940545",
  "geo" : { },
  "id_str" : "149574125269159936",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me\n-------------------------------------",
  "id" : 149574125269159936,
  "in_reply_to_status_id" : 149564018904940545,
  "created_at" : "2011-12-21 19:37:05 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149573979718430720",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 -----------------------------------follow me------------------------------------",
  "id" : 149573979718430720,
  "created_at" : "2011-12-21 19:36:30 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149565972842422273",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me!!!!",
  "id" : 149565972842422273,
  "created_at" : "2011-12-21 19:04:41 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149565635528105985",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 PLEASE FALLOW ME",
  "id" : 149565635528105985,
  "created_at" : "2011-12-21 19:03:20 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149564018904940545",
  "geo" : { },
  "id_str" : "149565323161501697",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me",
  "id" : 149565323161501697,
  "in_reply_to_status_id" : 149564018904940545,
  "created_at" : "2011-12-21 19:02:06 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149565168060350464",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 folloe me",
  "id" : 149565168060350464,
  "created_at" : "2011-12-21 19:01:29 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 35, 47 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149546233109815297",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Follow me my profile is @gamer456148",
  "id" : 149546233109815297,
  "created_at" : "2011-12-21 17:46:15 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149246569412177922",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me----",
  "id" : 149246569412177922,
  "created_at" : "2011-12-20 21:55:29 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149244148086607872",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me *************",
  "id" : 149244148086607872,
  "created_at" : "2011-12-20 21:45:52 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149243609793835009",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me,,,,,",
  "id" : 149243609793835009,
  "created_at" : "2011-12-20 21:43:44 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149189344782069760",
  "geo" : { },
  "id_str" : "149221184175734784",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me-----------",
  "id" : 149221184175734784,
  "in_reply_to_status_id" : 149189344782069760,
  "created_at" : "2011-12-20 20:14:37 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "149189344782069760",
  "geo" : { },
  "id_str" : "149220861277257728",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter ---___---",
  "id" : 149220861277257728,
  "in_reply_to_status_id" : 149189344782069760,
  "created_at" : "2011-12-20 20:13:20 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149193119739559937",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter-------",
  "id" : 149193119739559937,
  "created_at" : "2011-12-20 18:23:06 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148948487550156801",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 please follow me on twitter \\'_'\/   &lt;'='&gt;   :) \n('_')",
  "id" : 148948487550156801,
  "created_at" : "2011-12-20 02:11:01 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 13, 23 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148927557469880320",
  "geo" : { },
  "id_str" : "148927765587038209",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 @Zendaya96 follow me",
  "id" : 148927765587038209,
  "in_reply_to_status_id" : 148927557469880320,
  "created_at" : "2011-12-20 00:48:40 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 16, 26 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148912642893946882",
  "geo" : { },
  "id_str" : "148927557469880320",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 to @Zendaya96 follow e",
  "id" : 148927557469880320,
  "in_reply_to_status_id" : 148912642893946882,
  "created_at" : "2011-12-20 00:47:51 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148912642893946882",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me !!!!!!!! lol",
  "id" : 148912642893946882,
  "created_at" : "2011-12-19 23:48:35 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148911797326446592",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow my profile on twitter, and God bless U",
  "id" : 148911797326446592,
  "created_at" : "2011-12-19 23:45:13 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148894313034686464",
  "geo" : { },
  "id_str" : "148908494848929792",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow the twitter profile I have",
  "id" : 148908494848929792,
  "in_reply_to_status_id" : 148894313034686464,
  "created_at" : "2011-12-19 23:32:06 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148898463394959360",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow mine twitter profile",
  "id" : 148898463394959360,
  "created_at" : "2011-12-19 22:52:15 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148895523821207552",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 hey follow me threw twitter",
  "id" : 148895523821207552,
  "created_at" : "2011-12-19 22:40:33 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148894313034686464",
  "geo" : { },
  "id_str" : "148894577070321665",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me",
  "id" : 148894577070321665,
  "in_reply_to_status_id" : 148894313034686464,
  "created_at" : "2011-12-19 22:36:48 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148891259271004160",
  "geo" : { },
  "id_str" : "148894484271341568",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 will u follow my profile thats on twitter? \/ 'o' \/",
  "id" : 148894484271341568,
  "in_reply_to_status_id" : 148891259271004160,
  "created_at" : "2011-12-19 22:36:26 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 69 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "in_reply_to_status_id_str" : "148868038157012992",
  "geo" : { },
  "id_str" : "148879822427389952",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow the twitter profile I have at https:\/\/t.co\/jNxNZbx4",
  "id" : 148879822427389952,
  "in_reply_to_status_id" : 148868038157012992,
  "created_at" : "2011-12-19 21:38:10 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "148879247514152961",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow my profile for twitter at :::  https:\/\/t.co\/jNxNZbx4",
  "id" : 148879247514152961,
  "created_at" : "2011-12-19 21:35:53 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148878844441542657",
  "text" : "@ColemanArmy hi",
  "id" : 148878844441542657,
  "created_at" : "2011-12-19 21:34:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 59 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "148876764314222592",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 can u follow my twitter at https:\/\/t.co\/jNxNZbx4",
  "id" : 148876764314222592,
  "created_at" : "2011-12-19 21:26:01 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 39 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "148868155735932930",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow https:\/\/t.co\/jNxNZbx4",
  "id" : 148868155735932930,
  "created_at" : "2011-12-19 20:51:48 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 46 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "in_reply_to_status_id_str" : "148867310206201857",
  "geo" : { },
  "id_str" : "148867848335396865",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me at: https:\/\/t.co\/jNxNZbx4",
  "id" : 148867848335396865,
  "in_reply_to_status_id" : 148867310206201857,
  "created_at" : "2011-12-19 20:50:35 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 45 ],
      "url" : "https:\/\/t.co\/jNxNZbx4",
      "expanded_url" : "https:\/\/twitter.com\/#!\/gamer456148",
      "display_url" : "twitter.com\/#!\/gamer456148"
    } ]
  },
  "in_reply_to_status_id_str" : "148861118000005120",
  "geo" : { },
  "id_str" : "148867162239537152",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me at https:\/\/t.co\/jNxNZbx4",
  "id" : 148867162239537152,
  "in_reply_to_status_id" : 148861118000005120,
  "created_at" : "2011-12-19 20:47:51 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148845821109092353",
  "geo" : { },
  "id_str" : "148857165623468034",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow my profile on twitter",
  "id" : 148857165623468034,
  "in_reply_to_status_id" : 148845821109092353,
  "created_at" : "2011-12-19 20:08:08 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148845821109092353",
  "geo" : { },
  "id_str" : "148856704170340352",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter",
  "id" : 148856704170340352,
  "in_reply_to_status_id" : 148845821109092353,
  "created_at" : "2011-12-19 20:06:18 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148839174324232192",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96  follow me twitter___",
  "id" : 148839174324232192,
  "created_at" : "2011-12-19 18:56:39 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148835734890086400",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter-",
  "id" : 148835734890086400,
  "created_at" : "2011-12-19 18:42:59 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148832818036867072",
  "text" : "follw me on twitter ( '.' )",
  "id" : 148832818036867072,
  "created_at" : "2011-12-19 18:31:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148831555685597184",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter :&gt; :P",
  "id" : 148831555685597184,
  "created_at" : "2011-12-19 18:26:22 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148556629858725888",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter",
  "id" : 148556629858725888,
  "created_at" : "2011-12-19 00:13:55 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148552815315402753",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 follow me on twitter :P",
  "id" : 148552815315402753,
  "created_at" : "2011-12-18 23:58:45 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148547615267618816",
  "text" : "@ColemanArmy hi zendaya",
  "id" : 148547615267618816,
  "created_at" : "2011-12-18 23:38:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Zendaya",
      "screen_name" : "Zendaya96",
      "indices" : [ 0, 10 ],
      "id_str" : "1135594057",
      "id" : 1135594057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148546586199330816",
  "in_reply_to_user_id" : 154280902,
  "text" : "@Zendaya96 Can u follow me on twitter :)",
  "id" : 148546586199330816,
  "created_at" : "2011-12-18 23:34:00 +0000",
  "in_reply_to_screen_name" : "Zendaya",
  "in_reply_to_user_id_str" : "154280902",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148533985209892865",
  "text" : "@ColemanArmy hey zendaya",
  "id" : 148533985209892865,
  "created_at" : "2011-12-18 22:43:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148503204689223680",
  "text" : "@ColemamArmy can u Follow me on twitter :&gt; :P",
  "id" : 148503204689223680,
  "created_at" : "2011-12-18 20:41:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Brian Birdwell",
      "screen_name" : "SenatorBirdwell",
      "indices" : [ 0, 16 ],
      "id_str" : "245993078",
      "id" : 245993078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148250141583884288",
  "in_reply_to_user_id" : 245993078,
  "text" : "@SenatorBirdwell I am a proud conservative republican and christian",
  "id" : 148250141583884288,
  "created_at" : "2011-12-18 03:56:02 +0000",
  "in_reply_to_screen_name" : "SenatorBirdwell",
  "in_reply_to_user_id_str" : "245993078",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148188235653324801",
  "text" : "@ColemanArmy lol",
  "id" : 148188235653324801,
  "created_at" : "2011-12-17 23:50:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148112133735981056",
  "text" : "@ColemanArmy send me a friend repuest on skype, my username is gamer456148",
  "id" : 148112133735981056,
  "created_at" : "2011-12-17 18:47:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143036219914338304",
  "text" : "@ColemanArmy I sent you a freind request to zendayaskype",
  "id" : 143036219914338304,
  "created_at" : "2011-12-03 18:37:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143034908040892416",
  "text" : "@ColemanArmy I sent u a freind request to zendayaskype",
  "id" : 143034908040892416,
  "created_at" : "2011-12-03 18:32:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u10E6 z\u0454\u03B7\u2202\u03B1\u0443\u03B1 & \u0432\u0454\u2113\u2113\u03B1 \u10E6",
      "screen_name" : "ColemanArmy",
      "indices" : [ 0, 12 ],
      "id_str" : "863731963",
      "id" : 863731963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142816840693977088",
  "text" : "@ColemanArmy I sent you a freind request on skype to username zendayaskype ,confirm it, thanks God bless u :)",
  "id" : 142816840693977088,
  "created_at" : "2011-12-03 04:06:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]