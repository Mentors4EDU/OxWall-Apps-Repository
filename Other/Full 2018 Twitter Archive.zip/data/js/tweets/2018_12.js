Grailbird.data.tweets_2018_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7hqH3D1PNU",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/03\/the-food-lab-how-to-make-great-hummus.html",
      "display_url" : "seriouseats.com\/2016\/03\/the-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1079867815958593536",
  "text" : "RT @seriouseats: One of the year's most popular videos: A recipe worthy of your NYE spread.\nhttps:\/\/t.co\/7hqH3D1PNU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/7hqH3D1PNU",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/03\/the-food-lab-how-to-make-great-hummus.html",
        "display_url" : "seriouseats.com\/2016\/03\/the-fo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1079844648477122561",
    "text" : "One of the year's most popular videos: A recipe worthy of your NYE spread.\nhttps:\/\/t.co\/7hqH3D1PNU",
    "id" : 1079844648477122561,
    "created_at" : "2018-12-31 21:00:01 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1079867815958593536,
  "created_at" : "2018-12-31 22:32:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Kasparov",
      "screen_name" : "Kasparov63",
      "indices" : [ 3, 14 ],
      "id_str" : "449588356",
      "id" : 449588356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079810603575922688",
  "text" : "RT @Kasparov63: 2018 was a turbulent year, but let's share the positive right now. What was something good in your life, or anything that j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klinkerapps.com\" rel=\"nofollow\"\u003ETalon (Plus)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079773080514379776",
    "text" : "2018 was a turbulent year, but let's share the positive right now. What was something good in your life, or anything that just made you happy in the past year?",
    "id" : 1079773080514379776,
    "created_at" : "2018-12-31 16:15:38 +0000",
    "user" : {
      "name" : "Garry Kasparov",
      "screen_name" : "Kasparov63",
      "protected" : false,
      "id_str" : "449588356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1004031810173579265\/YrEIbzio_normal.jpg",
      "id" : 449588356,
      "verified" : true
    }
  },
  "id" : 1079810603575922688,
  "created_at" : "2018-12-31 18:44:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "3511430425",
      "id" : 3511430425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fermatslibrary\/status\/1079757617944236032\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hYvBU6eIId",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DvwR1KkWwAEW-XQ.jpg",
      "id_str" : "1079757615729655809",
      "id" : 1079757615729655809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvwR1KkWwAEW-XQ.jpg",
      "sizes" : [ {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1680,
        "resize" : "fit",
        "w" : 2992
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hYvBU6eIId"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079810561251164160",
  "text" : "RT @fermatslibrary: Here's a special countdown for 2019. Happy New Year! https:\/\/t.co\/hYvBU6eIId",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fermatslibrary\/status\/1079757617944236032\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/hYvBU6eIId",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DvwR1KkWwAEW-XQ.jpg",
        "id_str" : "1079757615729655809",
        "id" : 1079757615729655809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvwR1KkWwAEW-XQ.jpg",
        "sizes" : [ {
          "h" : 1150,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1680,
          "resize" : "fit",
          "w" : 2992
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hYvBU6eIId"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079757617944236032",
    "text" : "Here's a special countdown for 2019. Happy New Year! https:\/\/t.co\/hYvBU6eIId",
    "id" : 1079757617944236032,
    "created_at" : "2018-12-31 15:14:11 +0000",
    "user" : {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "protected" : false,
      "id_str" : "3511430425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641822497457860608\/zd6kUAag_normal.png",
      "id" : 3511430425,
      "verified" : false
    }
  },
  "id" : 1079810561251164160,
  "created_at" : "2018-12-31 18:44:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079509120326291459",
  "text" : "RT @ausecure: Streaming #Gold $1283.4 +$6.6\/0.51% #Silver $15.52 +$0.22\/1.42% #Platinum $795 -$7.2\/0.91% #Palladium $1260.9 -$12.3\/0.98%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079421876676505601",
    "text" : "Streaming #Gold $1283.4 +$6.6\/0.51% #Silver $15.52 +$0.22\/1.42% #Platinum $795 -$7.2\/0.91% #Palladium $1260.9 -$12.3\/0.98%",
    "id" : 1079421876676505601,
    "created_at" : "2018-12-30 17:00:04 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 1079509120326291459,
  "created_at" : "2018-12-30 22:46:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "indices" : [ 3, 15 ],
      "id_str" : "908383032767369216",
      "id" : 908383032767369216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3Dprinter",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079508351422251009",
  "text" : "RT @shea_street: Now my question is what can I do #3Dprinter wise with a whole shopping cart full worth of threaded rod? Go old school and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3Dprinter",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077799303282913280",
    "text" : "Now my question is what can I do #3Dprinter wise with a whole shopping cart full worth of threaded rod? Go old school and build some complete frames out of it? Make some braces? I am sure there is a whole lot I have not thought about but just trying to figure out some projects.\uD83E\uDD14",
    "id" : 1077799303282913280,
    "created_at" : "2018-12-26 05:32:33 +0000",
    "user" : {
      "name" : "Shea Street",
      "screen_name" : "shea_street",
      "protected" : false,
      "id_str" : "908383032767369216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908394866639589377\/KRY3inx7_normal.jpg",
      "id" : 908383032767369216,
      "verified" : false
    }
  },
  "id" : 1079508351422251009,
  "created_at" : "2018-12-30 22:43:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Cernovich \uD83E\uDD8D\uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Cernovich",
      "indices" : [ 3, 13 ],
      "id_str" : "358545917",
      "id" : 358545917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079508267401920512",
  "text" : "RT @Cernovich: What\u2019s the best documentary you have ever seen?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078068703529320448",
    "text" : "What\u2019s the best documentary you have ever seen?",
    "id" : 1078068703529320448,
    "created_at" : "2018-12-26 23:23:03 +0000",
    "user" : {
      "name" : "Mike Cernovich \uD83E\uDD8D\uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Cernovich",
      "protected" : false,
      "id_str" : "358545917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077437678675648514\/qihFil2__normal.jpg",
      "id" : 358545917,
      "verified" : true
    }
  },
  "id" : 1079508267401920512,
  "created_at" : "2018-12-30 22:43:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079507011874836481",
  "text" : "RT @BarbaraCorcoran: Fun is the most underutilized tool in business today. Happy people always make good employees.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078440571511980033",
    "text" : "Fun is the most underutilized tool in business today. Happy people always make good employees.",
    "id" : 1078440571511980033,
    "created_at" : "2018-12-28 00:00:43 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1079507011874836481,
  "created_at" : "2018-12-30 22:38:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "\u0F3AGRIMES\u0F3B",
      "screen_name" : "Grimezsz",
      "indices" : [ 14, 23 ],
      "id_str" : "276540738",
      "id" : 276540738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079506943817994240",
  "text" : "RT @elonmusk: @Grimezsz Turns out if you take Dayquil, you exit The Matrix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0F3AGRIMES\u0F3B",
        "screen_name" : "Grimezsz",
        "indices" : [ 0, 9 ],
        "id_str" : "276540738",
        "id" : 276540738
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1079457030060924928",
    "geo" : { },
    "id_str" : "1079459047252709377",
    "in_reply_to_user_id" : 276540738,
    "text" : "@Grimezsz Turns out if you take Dayquil, you exit The Matrix",
    "id" : 1079459047252709377,
    "in_reply_to_status_id" : 1079457030060924928,
    "created_at" : "2018-12-30 19:27:46 +0000",
    "in_reply_to_screen_name" : "Grimezsz",
    "in_reply_to_user_id_str" : "276540738",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1079506943817994240,
  "created_at" : "2018-12-30 22:38:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079506317495160832",
  "text" : "RT @BarbaraCorcoran: You don\u2019t have to get it right, you just have to get it going.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078742700696969216",
    "text" : "You don\u2019t have to get it right, you just have to get it going.",
    "id" : 1078742700696969216,
    "created_at" : "2018-12-28 20:01:16 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1079506317495160832,
  "created_at" : "2018-12-30 22:35:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079506050670305280",
  "text" : "RT @BarbaraCorcoran: Everybody has something they excel at. You need to figure out what yours is and build a life around it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078621868746309634",
    "text" : "Everybody has something they excel at. You need to figure out what yours is and build a life around it.",
    "id" : 1078621868746309634,
    "created_at" : "2018-12-28 12:01:07 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1079506050670305280,
  "created_at" : "2018-12-30 22:34:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Man_like_Rex\u2122\uD83D\uDD25",
      "screen_name" : "Rex_highstar",
      "indices" : [ 3, 16 ],
      "id_str" : "1067462418345934848",
      "id" : 1067462418345934848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079505963600830464",
  "text" : "RT @Rex_highstar: Which one is more frustrating?\n\n1. Battery low\n2. No network",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079286258009030656",
    "text" : "Which one is more frustrating?\n\n1. Battery low\n2. No network",
    "id" : 1079286258009030656,
    "created_at" : "2018-12-30 08:01:10 +0000",
    "user" : {
      "name" : "Man_like_Rex\u2122\uD83D\uDD25",
      "screen_name" : "Rex_highstar",
      "protected" : false,
      "id_str" : "1067462418345934848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1073123041033498624\/v7bJL2mY_normal.jpg",
      "id" : 1067462418345934848,
      "verified" : false
    }
  },
  "id" : 1079505963600830464,
  "created_at" : "2018-12-30 22:34:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1079505858088833024\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/E25yJTdxpn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dvss2VpWoAI-_RB.jpg",
      "id_str" : "1079505847720517634",
      "id" : 1079505847720517634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dvss2VpWoAI-_RB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/E25yJTdxpn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1079505858088833024",
  "text" : "And research disclosures are up... https:\/\/t.co\/E25yJTdxpn",
  "id" : 1079505858088833024,
  "created_at" : "2018-12-30 22:33:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/96xLHLFVpE",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2014\/12\/how-to-cook-crown-rack-of-lamb-holiday-roast.html",
      "display_url" : "seriouseats.com\/2014\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1078137587078959105",
  "text" : "RT @seriouseats: The crown jewel of your NYE dinner (Ba-dum, tss). https:\/\/t.co\/96xLHLFVpE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/96xLHLFVpE",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2014\/12\/how-to-cook-crown-rack-of-lamb-holiday-roast.html",
        "display_url" : "seriouseats.com\/2014\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1078062904258134016",
    "text" : "The crown jewel of your NYE dinner (Ba-dum, tss). https:\/\/t.co\/96xLHLFVpE",
    "id" : 1078062904258134016,
    "created_at" : "2018-12-26 23:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1078137587078959105,
  "created_at" : "2018-12-27 03:56:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1078137333499727872",
  "text" : "RT @KassyDillon: $1.85 for gas in Texas?!?!? \n\nI hate you LA.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077984022180044802",
    "text" : "$1.85 for gas in Texas?!?!? \n\nI hate you LA.",
    "id" : 1077984022180044802,
    "created_at" : "2018-12-26 17:46:33 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1076158543168847872\/vztW80IL_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 1078137333499727872,
  "created_at" : "2018-12-27 03:55:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1078137291145707520",
  "text" : "RT @Fact: Find three hobbies: one to make you money, one to keep you in shape, and one to keep you creative.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078040002976796689",
    "text" : "Find three hobbies: one to make you money, one to keep you in shape, and one to keep you creative.",
    "id" : 1078040002976796689,
    "created_at" : "2018-12-26 21:29:00 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 1078137291145707520,
  "created_at" : "2018-12-27 03:55:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sasha Ivanov",
      "screen_name" : "sasha35625",
      "indices" : [ 3, 14 ],
      "id_str" : "1142606887",
      "id" : 1142606887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/6GarEOkYV2",
      "expanded_url" : "https:\/\/wavesexplorer.com\/",
      "display_url" : "wavesexplorer.com"
    } ]
  },
  "geo" : { },
  "id_str" : "1078137217070100482",
  "text" : "RT @sasha35625: https:\/\/t.co\/6GarEOkYV2  We updated our $waves explorer! Please give me your feedback :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/6GarEOkYV2",
        "expanded_url" : "https:\/\/wavesexplorer.com\/",
        "display_url" : "wavesexplorer.com"
      } ]
    },
    "geo" : { },
    "id_str" : "1077924150042415106",
    "text" : "https:\/\/t.co\/6GarEOkYV2  We updated our $waves explorer! Please give me your feedback :)",
    "id" : 1077924150042415106,
    "created_at" : "2018-12-26 13:48:38 +0000",
    "user" : {
      "name" : "Sasha Ivanov",
      "screen_name" : "sasha35625",
      "protected" : false,
      "id_str" : "1142606887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1046791203986051072\/Zlyn_fpL_normal.jpg",
      "id" : 1142606887,
      "verified" : false
    }
  },
  "id" : 1078137217070100482,
  "created_at" : "2018-12-27 03:55:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1078137199332343808",
  "text" : "RT @BarbaraCorcoran: There\u2019s great power in an insult. You can use it to prove the world wrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077957449104138241",
    "text" : "There\u2019s great power in an insult. You can use it to prove the world wrong.",
    "id" : 1077957449104138241,
    "created_at" : "2018-12-26 16:00:58 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1078137199332343808,
  "created_at" : "2018-12-27 03:55:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Cage",
      "screen_name" : "Petercage27",
      "indices" : [ 0, 12 ],
      "id_str" : "3160570746",
      "id" : 3160570746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/naSZMZX25j",
      "expanded_url" : "https:\/\/www.minds.com\/gamer456148\/blog\/my-explanation-of-the-universe-through-quantum-origin-924057887114285056",
      "display_url" : "minds.com\/gamer456148\/bl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "1077413873655914498",
  "geo" : { },
  "id_str" : "1078137108018200576",
  "in_reply_to_user_id" : 3160570746,
  "text" : "@Petercage27 https:\/\/t.co\/naSZMZX25j",
  "id" : 1078137108018200576,
  "in_reply_to_status_id" : 1077413873655914498,
  "created_at" : "2018-12-27 03:54:52 +0000",
  "in_reply_to_screen_name" : "Petercage27",
  "in_reply_to_user_id_str" : "3160570746",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/i308RXrg6Q",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Br1fZroAKXb\/?utm_source=ig_twitter_share&igshid=u893bnqaqkcl",
      "display_url" : "instagram.com\/p\/Br1fZroAKXb\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077771753101893633",
  "text" : "The appetizers my extended family makes, oh gosh https:\/\/t.co\/i308RXrg6Q",
  "id" : 1077771753101893633,
  "created_at" : "2018-12-26 03:43:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make:",
      "screen_name" : "make",
      "indices" : [ 3, 8 ],
      "id_str" : "1118451",
      "id" : 1118451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/OIagdwn5Qy",
      "expanded_url" : "http:\/\/ht.ly\/YWYu30n26bk",
      "display_url" : "ht.ly\/YWYu30n26bk"
    } ]
  },
  "geo" : { },
  "id_str" : "1077370203388940288",
  "text" : "RT @make: can you 3d print a decently functional DC motor? https:\/\/t.co\/OIagdwn5Qy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/OIagdwn5Qy",
        "expanded_url" : "http:\/\/ht.ly\/YWYu30n26bk",
        "display_url" : "ht.ly\/YWYu30n26bk"
      } ]
    },
    "geo" : { },
    "id_str" : "1075068214172884992",
    "text" : "can you 3d print a decently functional DC motor? https:\/\/t.co\/OIagdwn5Qy",
    "id" : 1075068214172884992,
    "created_at" : "2018-12-18 16:40:10 +0000",
    "user" : {
      "name" : "Make:",
      "screen_name" : "make",
      "protected" : false,
      "id_str" : "1118451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783080298665775108\/LESsgngz_normal.jpg",
      "id" : 1118451,
      "verified" : true
    }
  },
  "id" : 1077370203388940288,
  "created_at" : "2018-12-25 01:07:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/9MvuguCemf",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/924105140795535360",
      "display_url" : "minds.com\/newsfeed\/92410\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077369452595953671",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/9MvuguCemf",
  "id" : 1077369452595953671,
  "created_at" : "2018-12-25 01:04:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 12, 24 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/gbl5NitZHR",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5744244-Fun-Post?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Fun%20Post&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5744244-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077369043861061632",
  "text" : "Fun Post by @gamer456148 https:\/\/t.co\/gbl5NitZHR",
  "id" : 1077369043861061632,
  "created_at" : "2018-12-25 01:02:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BNO News",
      "screen_name" : "BNONews",
      "indices" : [ 3, 11 ],
      "id_str" : "189305014",
      "id" : 189305014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077342119927472129",
  "text" : "RT @BNONews: BREAKING: Partial U.S. government shutdown begins",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076341564740378624",
    "text" : "BREAKING: Partial U.S. government shutdown begins",
    "id" : 1076341564740378624,
    "created_at" : "2018-12-22 05:00:01 +0000",
    "user" : {
      "name" : "BNO News",
      "screen_name" : "BNONews",
      "protected" : false,
      "id_str" : "189305014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882103883610427393\/vLTiH3uR_normal.jpg",
      "id" : 189305014,
      "verified" : true
    }
  },
  "id" : 1077342119927472129,
  "created_at" : "2018-12-24 23:15:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077342098179981314",
  "text" : "Seriously long research day and just tired",
  "id" : 1077342098179981314,
  "created_at" : "2018-12-24 23:15:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077338318407434241",
  "text" : "RT @BTCticker: One Bitcoin now worth $4215.897. Market Cap $73.525 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077036175339253761",
    "text" : "One Bitcoin now worth $4215.897. Market Cap $73.525 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1077036175339253761,
    "created_at" : "2018-12-24 03:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1077338318407434241,
  "created_at" : "2018-12-24 23:00:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077338309846814720",
  "text" : "RT @BTCticker: One Bitcoin now worth $4187.367. Market Cap $73.032 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077209814818832386",
    "text" : "One Bitcoin now worth $4187.367. Market Cap $73.032 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1077209814818832386,
    "created_at" : "2018-12-24 14:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1077338309846814720,
  "created_at" : "2018-12-24 23:00:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/dxedcyzPk1",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2014\/12\/how-to-make-the-best-swedish-meatballs.html",
      "display_url" : "seriouseats.com\/2014\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077338290565627904",
  "text" : "RT @seriouseats: Tender, juicy, and toothpick-able Swedish meatballs.\nhttps:\/\/t.co\/dxedcyzPk1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/dxedcyzPk1",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2014\/12\/how-to-make-the-best-swedish-meatballs.html",
        "display_url" : "seriouseats.com\/2014\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1077021039371186177",
    "text" : "Tender, juicy, and toothpick-able Swedish meatballs.\nhttps:\/\/t.co\/dxedcyzPk1",
    "id" : 1077021039371186177,
    "created_at" : "2018-12-24 02:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1077338290565627904,
  "created_at" : "2018-12-24 23:00:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/mEmTYWIl1R",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/12\/use-vodka-for-crispier-fried-food.html",
      "display_url" : "seriouseats.com\/2016\/12\/use-vo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077338269254369282",
  "text" : "RT @seriouseats: Vodka's volatility makes it ideal for fry batters.\nhttps:\/\/t.co\/mEmTYWIl1R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/mEmTYWIl1R",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/12\/use-vodka-for-crispier-fried-food.html",
        "display_url" : "seriouseats.com\/2016\/12\/use-vo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1077338129478995969",
    "text" : "Vodka's volatility makes it ideal for fry batters.\nhttps:\/\/t.co\/mEmTYWIl1R",
    "id" : 1077338129478995969,
    "created_at" : "2018-12-24 23:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1077338269254369282,
  "created_at" : "2018-12-24 23:00:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/naSZMZX25j",
      "expanded_url" : "https:\/\/www.minds.com\/gamer456148\/blog\/my-explanation-of-the-universe-through-quantum-origin-924057887114285056",
      "display_url" : "minds.com\/gamer456148\/bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077337905918603269",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/naSZMZX25j",
  "id" : 1077337905918603269,
  "created_at" : "2018-12-24 22:59:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077280066424500225",
  "text" : "RT @BTCticker: One Bitcoin now worth $4112.525. Market Cap $71.727 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077270214239289344",
    "text" : "One Bitcoin now worth $4112.525. Market Cap $71.727 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1077270214239289344,
    "created_at" : "2018-12-24 18:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1077280066424500225,
  "created_at" : "2018-12-24 19:09:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "storage",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/fXkgFUNjrF",
      "expanded_url" : "https:\/\/techxplore.com\/news\/2018-12-malta-energy-storage.html",
      "display_url" : "techxplore.com\/news\/2018-12-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077279928671002626",
  "text" : "RT @TechXplore_com: Malta #energy #storage system is looking forward to first pilot https:\/\/t.co\/fXkgFUNjrF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 6, 13 ]
      }, {
        "text" : "storage",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fXkgFUNjrF",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-12-malta-energy-storage.html",
        "display_url" : "techxplore.com\/news\/2018-12-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1076931873438347266",
    "text" : "Malta #energy #storage system is looking forward to first pilot https:\/\/t.co\/fXkgFUNjrF",
    "id" : 1076931873438347266,
    "created_at" : "2018-12-23 20:05:41 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1077279928671002626,
  "created_at" : "2018-12-24 19:08:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "indices" : [ 3, 14 ],
      "id_str" : "25170188",
      "id" : 25170188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/Y3BWaSaooQ",
      "expanded_url" : "http:\/\/bonap.it\/Umkenkf",
      "display_url" : "bonap.it\/Umkenkf"
    } ]
  },
  "geo" : { },
  "id_str" : "1077278723785846784",
  "text" : "RT @bonappetit: We'll just leave this here https:\/\/t.co\/Y3BWaSaooQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/Y3BWaSaooQ",
        "expanded_url" : "http:\/\/bonap.it\/Umkenkf",
        "display_url" : "bonap.it\/Umkenkf"
      } ]
    },
    "geo" : { },
    "id_str" : "1077252087069769729",
    "text" : "We'll just leave this here https:\/\/t.co\/Y3BWaSaooQ",
    "id" : 1077252087069769729,
    "created_at" : "2018-12-24 17:18:06 +0000",
    "user" : {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "protected" : false,
      "id_str" : "25170188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308597170\/bon-appetit-twitter-icon_normal.jpg",
      "id" : 25170188,
      "verified" : true
    }
  },
  "id" : 1077278723785846784,
  "created_at" : "2018-12-24 19:03:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077278195957796864",
  "text" : "RT @BTCticker: One Bitcoin now worth $4092.135. Market Cap $71.372 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077277759011995651",
    "text" : "One Bitcoin now worth $4092.135. Market Cap $71.372 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1077277759011995651,
    "created_at" : "2018-12-24 19:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1077278195957796864,
  "created_at" : "2018-12-24 19:01:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimarsh Shah",
      "screen_name" : "Vimarsh244",
      "indices" : [ 3, 14 ],
      "id_str" : "941631088740278273",
      "id" : 941631088740278273
    }, {
      "name" : "Arduino",
      "screen_name" : "arduino",
      "indices" : [ 25, 33 ],
      "id_str" : "266400754",
      "id" : 266400754
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Vimarsh244\/status\/1077147762100035584\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/aRrsbRxLpp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DvLMJqaVsAAvArA.jpg",
      "id_str" : "1077147727270621184",
      "id" : 1077147727270621184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvLMJqaVsAAvArA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1440
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/aRrsbRxLpp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077278072976617473",
  "text" : "RT @Vimarsh244: A little @arduino stack of different MKR boards... https:\/\/t.co\/aRrsbRxLpp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arduino",
        "screen_name" : "arduino",
        "indices" : [ 9, 17 ],
        "id_str" : "266400754",
        "id" : 266400754
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Vimarsh244\/status\/1077147762100035584\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/aRrsbRxLpp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DvLMJqaVsAAvArA.jpg",
        "id_str" : "1077147727270621184",
        "id" : 1077147727270621184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvLMJqaVsAAvArA.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1440
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/aRrsbRxLpp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077147762100035584",
    "text" : "A little @arduino stack of different MKR boards... https:\/\/t.co\/aRrsbRxLpp",
    "id" : 1077147762100035584,
    "created_at" : "2018-12-24 10:23:33 +0000",
    "user" : {
      "name" : "Vimarsh Shah",
      "screen_name" : "Vimarsh244",
      "protected" : false,
      "id_str" : "941631088740278273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/952782529144041472\/JotHU_yy_normal.jpg",
      "id" : 941631088740278273,
      "verified" : false
    }
  },
  "id" : 1077278072976617473,
  "created_at" : "2018-12-24 19:01:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "indices" : [ 3, 10 ],
      "id_str" : "712685130",
      "id" : 712685130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TindieBlog",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/oaWeoxbnQc",
      "expanded_url" : "http:\/\/E.box",
      "display_url" : "E.box"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6BiWee7Ugi",
      "expanded_url" : "https:\/\/blog.tindie.com\/2018\/12\/e-box-power-analyzer-lab-smart-home\/",
      "display_url" : "blog.tindie.com\/2018\/12\/e-box-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077278031406944258",
  "text" : "RT @tindie: https:\/\/t.co\/oaWeoxbnQc is the Ultimate Power Analyzer For Your Lab or Smart Home. #TindieBlog https:\/\/t.co\/6BiWee7Ugi https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tindie\/status\/1077244042264629250\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/cQSMMm9wEG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DvMjv0gU8AAff69.jpg",
        "id_str" : "1077244040326737920",
        "id" : 1077244040326737920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvMjv0gU8AAff69.jpg",
        "sizes" : [ {
          "h" : 762,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 762,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 762,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/cQSMMm9wEG"
      } ],
      "hashtags" : [ {
        "text" : "TindieBlog",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/oaWeoxbnQc",
        "expanded_url" : "http:\/\/E.box",
        "display_url" : "E.box"
      }, {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/6BiWee7Ugi",
        "expanded_url" : "https:\/\/blog.tindie.com\/2018\/12\/e-box-power-analyzer-lab-smart-home\/",
        "display_url" : "blog.tindie.com\/2018\/12\/e-box-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1077244042264629250",
    "text" : "https:\/\/t.co\/oaWeoxbnQc is the Ultimate Power Analyzer For Your Lab or Smart Home. #TindieBlog https:\/\/t.co\/6BiWee7Ugi https:\/\/t.co\/cQSMMm9wEG",
    "id" : 1077244042264629250,
    "created_at" : "2018-12-24 16:46:08 +0000",
    "user" : {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "protected" : false,
      "id_str" : "712685130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694634209567068160\/R8oCIMeb_normal.png",
      "id" : 712685130,
      "verified" : true
    }
  },
  "id" : 1077278031406944258,
  "created_at" : "2018-12-24 19:01:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MixThatDrink",
      "screen_name" : "MixThatDrink",
      "indices" : [ 3, 16 ],
      "id_str" : "232463343",
      "id" : 232463343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/LPzTGCIflr",
      "expanded_url" : "http:\/\/bit.ly\/2GpA3bs",
      "display_url" : "bit.ly\/2GpA3bs"
    } ]
  },
  "geo" : { },
  "id_str" : "1077277948393213953",
  "text" : "RT @MixThatDrink: The old holiday classic, in two versions: cook or no cook. https:\/\/t.co\/LPzTGCIflr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/smarterqueue.com\" rel=\"nofollow\"\u003ESmarterQueue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/LPzTGCIflr",
        "expanded_url" : "http:\/\/bit.ly\/2GpA3bs",
        "display_url" : "bit.ly\/2GpA3bs"
      } ]
    },
    "geo" : { },
    "id_str" : "1077024940795314181",
    "text" : "The old holiday classic, in two versions: cook or no cook. https:\/\/t.co\/LPzTGCIflr",
    "id" : 1077024940795314181,
    "created_at" : "2018-12-24 02:15:30 +0000",
    "user" : {
      "name" : "MixThatDrink",
      "screen_name" : "MixThatDrink",
      "protected" : false,
      "id_str" : "232463343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1031172338346274816\/AYFFjTNj_normal.jpg",
      "id" : 232463343,
      "verified" : false
    }
  },
  "id" : 1077277948393213953,
  "created_at" : "2018-12-24 19:00:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold Price",
      "screen_name" : "goldpricetweets",
      "indices" : [ 3, 19 ],
      "id_str" : "472488467",
      "id" : 472488467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "Price",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077277920496939010",
  "text" : "RT @goldpricetweets: New York Comex #Gold #Price Open: $1255.6 USD per oz 2018-12-24 08:20:57 EST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/resourcetwit.com\/\" rel=\"nofollow\"\u003EResourcetwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 15, 20 ]
      }, {
        "text" : "Price",
        "indices" : [ 21, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077192409442742277",
    "text" : "New York Comex #Gold #Price Open: $1255.6 USD per oz 2018-12-24 08:20:57 EST",
    "id" : 1077192409442742277,
    "created_at" : "2018-12-24 13:20:58 +0000",
    "user" : {
      "name" : "Gold Price",
      "screen_name" : "goldpricetweets",
      "protected" : false,
      "id_str" : "472488467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2022012912\/goldprices_normal.jpg",
      "id" : 472488467,
      "verified" : false
    }
  },
  "id" : 1077277920496939010,
  "created_at" : "2018-12-24 19:00:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strong Women",
      "screen_name" : "A_StrongWomen",
      "indices" : [ 3, 17 ],
      "id_str" : "1870258736",
      "id" : 1870258736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077277835394469891",
  "text" : "RT @A_StrongWomen: I'd rather be disliked for who I am than liked for who I'm not.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kucukbeyin.com\/\" rel=\"nofollow\"\u003E\u015Flsjgoeshgl\u0131eh\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077275190265106432",
    "text" : "I'd rather be disliked for who I am than liked for who I'm not.",
    "id" : 1077275190265106432,
    "created_at" : "2018-12-24 18:49:54 +0000",
    "user" : {
      "name" : "Strong Women",
      "screen_name" : "A_StrongWomen",
      "protected" : false,
      "id_str" : "1870258736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479388927459987457\/230bmLAZ_normal.jpeg",
      "id" : 1870258736,
      "verified" : false
    }
  },
  "id" : 1077277835394469891,
  "created_at" : "2018-12-24 19:00:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/08f9OVAFgV",
      "expanded_url" : "https:\/\/www.seriouseats.com\/roundups\/hot-cocktail-recipes",
      "display_url" : "seriouseats.com\/roundups\/hot-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077277791719251968",
  "text" : "RT @seriouseats: Cozy up to the fireplace with one of these. https:\/\/t.co\/08f9OVAFgV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/08f9OVAFgV",
        "expanded_url" : "https:\/\/www.seriouseats.com\/roundups\/hot-cocktail-recipes",
        "display_url" : "seriouseats.com\/roundups\/hot-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1077277651570737152",
    "text" : "Cozy up to the fireplace with one of these. https:\/\/t.co\/08f9OVAFgV",
    "id" : 1077277651570737152,
    "created_at" : "2018-12-24 18:59:41 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1077277791719251968,
  "created_at" : "2018-12-24 19:00:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1077277638635462656\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/kwHdJvpLLi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DvNCGizX0AAC0kC.jpg",
      "id_str" : "1077277416060604416",
      "id" : 1077277416060604416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvNCGizX0AAC0kC.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1056,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 1056,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 1056,
        "resize" : "fit",
        "w" : 816
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/kwHdJvpLLi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/MbzGQU8oOh",
      "expanded_url" : "http:\/\/bit.ly\/quantumframework",
      "display_url" : "bit.ly\/quantumframewo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077277638635462656",
  "text" : "Get the free e-book: https:\/\/t.co\/MbzGQU8oOh https:\/\/t.co\/kwHdJvpLLi",
  "id" : 1077277638635462656,
  "created_at" : "2018-12-24 18:59:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 16, 28 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/KotHOi2DgF",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5743688-E-Book-Cover?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=E-Book%20Cover&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5743688-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077277147356635138",
  "text" : "E-Book Cover by @gamer456148 https:\/\/t.co\/KotHOi2DgF",
  "id" : 1077277147356635138,
  "created_at" : "2018-12-24 18:57:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "indices" : [ 3, 10 ],
      "id_str" : "712685130",
      "id" : 712685130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/STlw3jMi4r",
      "expanded_url" : "https:\/\/www.tindie.com\/products\/leonerd\/oscilloscope-current-probe-adapter\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
      "display_url" : "tindie.com\/products\/leone\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077276091457462272",
  "text" : "RT @tindie: Back in Stock! Oscilloscope Current Probe Adapter https:\/\/t.co\/STlw3jMi4r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.tindie.com\" rel=\"nofollow\"\u003ETindie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/STlw3jMi4r",
        "expanded_url" : "https:\/\/www.tindie.com\/products\/leonerd\/oscilloscope-current-probe-adapter\/?utm_source=twitter.com&utm_medium=referral&utm_content=tweet&utm_campaign=product_back_in_stock_tweets",
        "display_url" : "tindie.com\/products\/leone\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1077269801263804416",
    "text" : "Back in Stock! Oscilloscope Current Probe Adapter https:\/\/t.co\/STlw3jMi4r",
    "id" : 1077269801263804416,
    "created_at" : "2018-12-24 18:28:29 +0000",
    "user" : {
      "name" : "Tindie Maker Marketplace",
      "screen_name" : "tindie",
      "protected" : false,
      "id_str" : "712685130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694634209567068160\/R8oCIMeb_normal.png",
      "id" : 712685130,
      "verified" : true
    }
  },
  "id" : 1077276091457462272,
  "created_at" : "2018-12-24 18:53:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1077004449715896320\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/jGyc53PDWO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DvJJm04U8AANJbg.jpg",
      "id_str" : "1077004192273723392",
      "id" : 1077004192273723392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvJJm04U8AANJbg.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jGyc53PDWO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/095WHX44BX",
      "expanded_url" : "http:\/\/flickr.com\/spacex",
      "display_url" : "flickr.com\/spacex"
    } ]
  },
  "geo" : { },
  "id_str" : "1077276075598721024",
  "text" : "RT @SpaceX: More photos from today\u2019s Falcon 9 launch; SpaceX\u2019s 21st mission of 2018 \u2192 https:\/\/t.co\/095WHX44BX https:\/\/t.co\/jGyc53PDWO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1077004449715896320\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/jGyc53PDWO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DvJJm04U8AANJbg.jpg",
        "id_str" : "1077004192273723392",
        "id" : 1077004192273723392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvJJm04U8AANJbg.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jGyc53PDWO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/095WHX44BX",
        "expanded_url" : "http:\/\/flickr.com\/spacex",
        "display_url" : "flickr.com\/spacex"
      } ]
    },
    "geo" : { },
    "id_str" : "1077004449715896320",
    "text" : "More photos from today\u2019s Falcon 9 launch; SpaceX\u2019s 21st mission of 2018 \u2192 https:\/\/t.co\/095WHX44BX https:\/\/t.co\/jGyc53PDWO",
    "id" : 1077004449715896320,
    "created_at" : "2018-12-24 00:54:05 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1077276075598721024,
  "created_at" : "2018-12-24 18:53:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/hCeQjzcKad",
      "expanded_url" : "https:\/\/wapo.st\/2CxyR1S",
      "display_url" : "wapo.st\/2CxyR1S"
    } ]
  },
  "geo" : { },
  "id_str" : "1077276044477034496",
  "text" : "RT @washingtonpost: Despite U.S. crackdown, Huawei ships a record 200 million smartphones https:\/\/t.co\/hCeQjzcKad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/hCeQjzcKad",
        "expanded_url" : "https:\/\/wapo.st\/2CxyR1S",
        "display_url" : "wapo.st\/2CxyR1S"
      } ]
    },
    "geo" : { },
    "id_str" : "1077269947661893632",
    "text" : "Despite U.S. crackdown, Huawei ships a record 200 million smartphones https:\/\/t.co\/hCeQjzcKad",
    "id" : 1077269947661893632,
    "created_at" : "2018-12-24 18:29:04 +0000",
    "user" : {
      "name" : "The Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1060271522319925257\/fJKwJ0r2_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 1077276044477034496,
  "created_at" : "2018-12-24 18:53:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 3, 7 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077276029729804288",
  "text" : "RT @ABC: Lava and ash spew from a new fracture on Mount Etna, the largest of three active volcanoes in Italy. At least 130 tremors have bee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/1077270121142460423\/video\/1",
        "indices" : [ 212, 235 ],
        "url" : "https:\/\/t.co\/1GBzOIUhn5",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1077269913868349440\/pu\/img\/hDQRObwAyVn7JPTn.jpg",
        "id_str" : "1077269913868349440",
        "id" : 1077269913868349440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1077269913868349440\/pu\/img\/hDQRObwAyVn7JPTn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1GBzOIUhn5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 188, 211 ],
        "url" : "https:\/\/t.co\/8jn7LapTIq",
        "expanded_url" : "https:\/\/abcn.ws\/2ELlTPN",
        "display_url" : "abcn.ws\/2ELlTPN"
      } ]
    },
    "geo" : { },
    "id_str" : "1077270121142460423",
    "text" : "Lava and ash spew from a new fracture on Mount Etna, the largest of three active volcanoes in Italy. At least 130 tremors have been recorded, with the most powerful at a magnitude of 4.0. https:\/\/t.co\/8jn7LapTIq https:\/\/t.co\/1GBzOIUhn5",
    "id" : 1077270121142460423,
    "created_at" : "2018-12-24 18:29:46 +0000",
    "user" : {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "protected" : false,
      "id_str" : "28785486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877547979363758080\/ny06RNTT_normal.jpg",
      "id" : 28785486,
      "verified" : true
    }
  },
  "id" : 1077276029729804288,
  "created_at" : "2018-12-24 18:53:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "India TV",
      "screen_name" : "indiatvnews",
      "indices" : [ 3, 15 ],
      "id_str" : "34245009",
      "id" : 34245009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsunami",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077275899890933760",
  "text" : "RT @indiatvnews: Indonesia's disaster agency says #tsunami death toll climbs to 373, with 128 missing and 1,459 injured. (AP)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tsunami",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077204752243449857",
    "text" : "Indonesia's disaster agency says #tsunami death toll climbs to 373, with 128 missing and 1,459 injured. (AP)",
    "id" : 1077204752243449857,
    "created_at" : "2018-12-24 14:10:01 +0000",
    "user" : {
      "name" : "India TV",
      "screen_name" : "indiatvnews",
      "protected" : false,
      "id_str" : "34245009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438346326007234560\/YyvWcpAf_normal.jpeg",
      "id" : 34245009,
      "verified" : true
    }
  },
  "id" : 1077275899890933760,
  "created_at" : "2018-12-24 18:52:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "14173315",
      "id" : 14173315
    }, {
      "name" : "CNBC",
      "screen_name" : "CNBC",
      "indices" : [ 63, 68 ],
      "id_str" : "20402945",
      "id" : 20402945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077275730382409728",
  "text" : "RT @NBCNews: JUST IN: Dow falls more than 500 points Monday. - @CNBC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNBC",
        "screen_name" : "CNBC",
        "indices" : [ 50, 55 ],
        "id_str" : "20402945",
        "id" : 20402945
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077256351565393925",
    "text" : "JUST IN: Dow falls more than 500 points Monday. - @CNBC",
    "id" : 1077256351565393925,
    "created_at" : "2018-12-24 17:35:03 +0000",
    "user" : {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "protected" : false,
      "id_str" : "14173315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875411730679173121\/l9PSFLJb_normal.jpg",
      "id" : 14173315,
      "verified" : true
    }
  },
  "id" : 1077275730382409728,
  "created_at" : "2018-12-24 18:52:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/lo4tBYuMQ5",
      "expanded_url" : "https:\/\/play.google.com\/store\/books\/details?id=CymBDwAAQBAJ",
      "display_url" : "play.google.com\/store\/books\/de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077275542406205441",
  "text" : "https:\/\/t.co\/lo4tBYuMQ5",
  "id" : 1077275542406205441,
  "created_at" : "2018-12-24 18:51:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hJkYKu5pHx",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/924010927699283968",
      "display_url" : "minds.com\/newsfeed\/92401\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077275438278496261",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/hJkYKu5pHx",
  "id" : 1077275438278496261,
  "created_at" : "2018-12-24 18:50:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/lUlUouHDLP",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/924010350292692992",
      "display_url" : "minds.com\/newsfeed\/92401\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077275400106065920",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/lUlUouHDLP",
  "id" : 1077275400106065920,
  "created_at" : "2018-12-24 18:50:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SilverQuote",
      "screen_name" : "silverquote",
      "indices" : [ 3, 15 ],
      "id_str" : "528732350",
      "id" : 528732350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Silver",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "Price",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077255517943357442",
  "text" : "RT @silverquote: New York Comex #Silver #Price Open: $14.59 USD per oz 2018-12-24 08:20:57 EST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/resourcetwit.com\/\" rel=\"nofollow\"\u003EResourcetwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Silver",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "Price",
        "indices" : [ 23, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077192405768581120",
    "text" : "New York Comex #Silver #Price Open: $14.59 USD per oz 2018-12-24 08:20:57 EST",
    "id" : 1077192405768581120,
    "created_at" : "2018-12-24 13:20:57 +0000",
    "user" : {
      "name" : "SilverQuote",
      "screen_name" : "silverquote",
      "protected" : false,
      "id_str" : "528732350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2021978988\/silverprices_normal.jpg",
      "id" : 528732350,
      "verified" : false
    }
  },
  "id" : 1077255517943357442,
  "created_at" : "2018-12-24 17:31:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "indices" : [ 3, 15 ],
      "id_str" : "798906869582544896",
      "id" : 798906869582544896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "Blockchain",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "Cryptocurrency",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077255500738281476",
  "text" : "RT @SmartcoinFr: Le cours du #Bitcoin est de 3713.35\u20AC\uD83C\uDDEA\uD83C\uDDFA  (4244.63$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smartcoin.fr\" rel=\"nofollow\"\u003EBitcoinPriceReal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Blockchain",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "Cryptocurrency",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077109884536147968",
    "text" : "Le cours du #Bitcoin est de 3713.35\u20AC\uD83C\uDDEA\uD83C\uDDFA  (4244.63$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
    "id" : 1077109884536147968,
    "created_at" : "2018-12-24 07:53:02 +0000",
    "user" : {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "protected" : false,
      "id_str" : "798906869582544896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911003345342599168\/Yu2M7_bQ_normal.jpg",
      "id" : 798906869582544896,
      "verified" : false
    }
  },
  "id" : 1077255500738281476,
  "created_at" : "2018-12-24 17:31:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077255310253977600",
  "text" : "RT @BTCticker: One Bitcoin now worth $4116.317. Market Cap $71.793 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077255109837492226",
    "text" : "One Bitcoin now worth $4116.317. Market Cap $71.793 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1077255109837492226,
    "created_at" : "2018-12-24 17:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1077255310253977600,
  "created_at" : "2018-12-24 17:30:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077255301693349888",
  "text" : "RT @ausecure: Streaming #Gold $1266.5 +$8.5\/0.67% #Silver $14.78 +$0.1\/0.68% #Platinum $791 -$1.1\/0.14% #Palladium $1244.2 +$15.8\/1.27%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 36, 43 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 63, 72 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1077232445093761030",
    "text" : "Streaming #Gold $1266.5 +$8.5\/0.67% #Silver $14.78 +$0.1\/0.68% #Platinum $791 -$1.1\/0.14% #Palladium $1244.2 +$15.8\/1.27%",
    "id" : 1077232445093761030,
    "created_at" : "2018-12-24 16:00:03 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 1077255301693349888,
  "created_at" : "2018-12-24 17:30:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 107, 116 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/JcJ5Z8dnfi",
      "expanded_url" : "https:\/\/www.academia.edu\/38033687\/The_Infinite_Quantum_Loop_Series_Multi-Dimensional_Quantum_Breakpoint_Theorem?source=swp_share",
      "display_url" : "academia.edu\/38033687\/The_I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077254847920066562",
  "text" : "The Infinite Quantum Loop Series: Multi-Dimensional Quantum Breakpoint Theorem https:\/\/t.co\/JcJ5Z8dnfi via @academia",
  "id" : 1077254847920066562,
  "created_at" : "2018-12-24 17:29:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/wSQAu7J1V1",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/923990243201220608",
      "display_url" : "minds.com\/newsfeed\/92399\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1077254611017318401",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/wSQAu7J1V1",
  "id" : 1077254611017318401,
  "created_at" : "2018-12-24 17:28:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650998930784256",
  "text" : "RT @seriouseats: The key to awesome deviled eggs is the perfect cooking, coupled with the great olive oil and plenty of acid and salt. \nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/Hnjgzh0L05",
        "expanded_url" : "http:\/\/bit.ly\/2gnUCX6",
        "display_url" : "bit.ly\/2gnUCX6"
      } ]
    },
    "geo" : { },
    "id_str" : "1076492560745578497",
    "text" : "The key to awesome deviled eggs is the perfect cooking, coupled with the great olive oil and plenty of acid and salt. \nhttps:\/\/t.co\/Hnjgzh0L05",
    "id" : 1076492560745578497,
    "created_at" : "2018-12-22 15:00:01 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1076650998930784256,
  "created_at" : "2018-12-23 01:29:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "indices" : [ 3, 18 ],
      "id_str" : "2984496093",
      "id" : 2984496093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650758605586432",
  "text" : "RT @_daniellebleau: I\u2019m sorry but why do we care where the heck David Hogg goes to school? Stop giving him attention.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076640340948463616",
    "text" : "I\u2019m sorry but why do we care where the heck David Hogg goes to school? Stop giving him attention.",
    "id" : 1076640340948463616,
    "created_at" : "2018-12-23 00:47:14 +0000",
    "user" : {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "protected" : false,
      "id_str" : "2984496093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936751927429386241\/Ra89-JcI_normal.jpg",
      "id" : 2984496093,
      "verified" : false
    }
  },
  "id" : 1076650758605586432,
  "created_at" : "2018-12-23 01:28:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/v71ANPMrNw",
      "expanded_url" : "http:\/\/www.seriouseats.com\/2013\/12\/the-food-lab-how-to-roast-vegetables.html",
      "display_url" : "seriouseats.com\/2013\/12\/the-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076650693413519362",
  "text" : "RT @seriouseats: Caramelized cabbage is a total game-changer.\nhttps:\/\/t.co\/v71ANPMrNw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/v71ANPMrNw",
        "expanded_url" : "http:\/\/www.seriouseats.com\/2013\/12\/the-food-lab-how-to-roast-vegetables.html",
        "display_url" : "seriouseats.com\/2013\/12\/the-fo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1076296270111596544",
    "text" : "Caramelized cabbage is a total game-changer.\nhttps:\/\/t.co\/v71ANPMrNw",
    "id" : 1076296270111596544,
    "created_at" : "2018-12-22 02:00:02 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1076650693413519362,
  "created_at" : "2018-12-23 01:28:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TipsyBartender\/status\/1076500106436849666\/video\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/gta0iRfnpK",
      "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/1075922540646678529\/img\/AZA9WvbNDYUe6dxz.jpg",
      "id_str" : "1075922540646678529",
      "id" : 1075922540646678529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/1075922540646678529\/img\/AZA9WvbNDYUe6dxz.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/gta0iRfnpK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650514463494145",
  "text" : "RT @TipsyBartender: Up your cocktail game with these ice hacks! \u2744\uFE0F\uD83C\uDF78 https:\/\/t.co\/gta0iRfnpK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003ETwitter Media Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TipsyBartender\/status\/1076500106436849666\/video\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/gta0iRfnpK",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/1075922540646678529\/img\/AZA9WvbNDYUe6dxz.jpg",
        "id_str" : "1075922540646678529",
        "id" : 1075922540646678529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/1075922540646678529\/img\/AZA9WvbNDYUe6dxz.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/gta0iRfnpK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076500106436849666",
    "text" : "Up your cocktail game with these ice hacks! \u2744\uFE0F\uD83C\uDF78 https:\/\/t.co\/gta0iRfnpK",
    "id" : 1076500106436849666,
    "created_at" : "2018-12-22 15:30:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1076650514463494145,
  "created_at" : "2018-12-23 01:27:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Katchadourian",
      "screen_name" : "ashkatch",
      "indices" : [ 0, 9 ],
      "id_str" : "47178606",
      "id" : 47178606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1076296495836450818",
  "geo" : { },
  "id_str" : "1076650444271820800",
  "in_reply_to_user_id" : 47178606,
  "text" : "@ashkatch Like cheese and wine",
  "id" : 1076650444271820800,
  "in_reply_to_status_id" : 1076296495836450818,
  "created_at" : "2018-12-23 01:27:23 +0000",
  "in_reply_to_screen_name" : "ashkatch",
  "in_reply_to_user_id_str" : "47178606",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650330719432705",
  "text" : "RT @BarbaraCorcoran: No one can be good at everything, it takes a real team to grow a business.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076452329581395968",
    "text" : "No one can be good at everything, it takes a real team to grow a business.",
    "id" : 1076452329581395968,
    "created_at" : "2018-12-22 12:20:09 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1076650330719432705,
  "created_at" : "2018-12-23 01:26:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650297655742464",
  "text" : "RT @Fact: Before you talk, listen. Before you react, think. Before you criticize, wait. Before you pray, forgive. Before you quit, try.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076638017496989696",
    "text" : "Before you talk, listen. Before you react, think. Before you criticize, wait. Before you pray, forgive. Before you quit, try.",
    "id" : 1076638017496989696,
    "created_at" : "2018-12-23 00:38:00 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 1076650297655742464,
  "created_at" : "2018-12-23 01:26:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650046307876866",
  "text" : "RT @BarbaraCorcoran: The best reason for going for it is you won\u2019t live to regret it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076588215371526145",
    "text" : "The best reason for going for it is you won\u2019t live to regret it.",
    "id" : 1076588215371526145,
    "created_at" : "2018-12-22 21:20:07 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1076650046307876866,
  "created_at" : "2018-12-23 01:25:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650032290500609",
  "text" : "RT @elonmusk: Anxiety is a scalar, fear is a vector",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076020860173996032",
    "text" : "Anxiety is a scalar, fear is a vector",
    "id" : 1076020860173996032,
    "created_at" : "2018-12-21 07:45:39 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1076650032290500609,
  "created_at" : "2018-12-23 01:25:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076650011126087680",
  "text" : "Fill in the blank, as a man I get confused by ...........",
  "id" : 1076650011126087680,
  "created_at" : "2018-12-23 01:25:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "NASA Goddard",
      "screen_name" : "NASAGoddard",
      "indices" : [ 83, 95 ],
      "id_str" : "20060293",
      "id" : 20060293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "comet",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/5K1Olz4lev",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-nasa-telescopes-brightest-comet.html",
      "display_url" : "phys.org\/news\/2018-12-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076008950380797953",
  "text" : "RT @physorg_com: NASA telescopes take a close look at the brightest #comet of 2018 @NASAGoddard https:\/\/t.co\/5K1Olz4lev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA Goddard",
        "screen_name" : "NASAGoddard",
        "indices" : [ 66, 78 ],
        "id_str" : "20060293",
        "id" : 20060293
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "comet",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/5K1Olz4lev",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-nasa-telescopes-brightest-comet.html",
        "display_url" : "phys.org\/news\/2018-12-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075862180527071234",
    "text" : "NASA telescopes take a close look at the brightest #comet of 2018 @NASAGoddard https:\/\/t.co\/5K1Olz4lev",
    "id" : 1075862180527071234,
    "created_at" : "2018-12-20 21:15:07 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1076008950380797953,
  "created_at" : "2018-12-21 06:58:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Legion Hoops",
      "screen_name" : "LegionHoops",
      "indices" : [ 3, 15 ],
      "id_str" : "291438698",
      "id" : 291438698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076007041284628480",
  "text" : "RT @LegionHoops: The Knicks have shown \u201Cpreliminary interest\u201D in trading for Jabari Parker, reports ESPN.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075854077383168005",
    "text" : "The Knicks have shown \u201Cpreliminary interest\u201D in trading for Jabari Parker, reports ESPN.",
    "id" : 1075854077383168005,
    "created_at" : "2018-12-20 20:42:55 +0000",
    "user" : {
      "name" : "Legion Hoops",
      "screen_name" : "LegionHoops",
      "protected" : false,
      "id_str" : "291438698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1027430221144682496\/2Mq-EPG8_normal.jpg",
      "id" : 291438698,
      "verified" : false
    }
  },
  "id" : 1076007041284628480,
  "created_at" : "2018-12-21 06:50:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alana Mastrangelo",
      "screen_name" : "ARmastrangelo",
      "indices" : [ 3, 17 ],
      "id_str" : "26520948",
      "id" : 26520948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoFundTheWall",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076006944157118464",
  "text" : "RT @ARmastrangelo: If you paid any attention to veterans, you\u2019d realize that a VETERAN started that #GoFundTheWall campaign you\u2019re mocking.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoFundTheWall",
        "indices" : [ 81, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/nHhn5XBaGm",
        "expanded_url" : "https:\/\/twitter.com\/Alyssa_Milano\/status\/1075804158320492544",
        "display_url" : "twitter.com\/Alyssa_Milano\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075920217178603520",
    "text" : "If you paid any attention to veterans, you\u2019d realize that a VETERAN started that #GoFundTheWall campaign you\u2019re mocking. https:\/\/t.co\/nHhn5XBaGm",
    "id" : 1075920217178603520,
    "created_at" : "2018-12-21 01:05:44 +0000",
    "user" : {
      "name" : "Alana Mastrangelo",
      "screen_name" : "ARmastrangelo",
      "protected" : false,
      "id_str" : "26520948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1074051815585517569\/dZShrS9b_normal.jpg",
      "id" : 26520948,
      "verified" : true
    }
  },
  "id" : 1076006944157118464,
  "created_at" : "2018-12-21 06:50:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076006233591697409",
  "text" : "RT @BTCticker: One Bitcoin now worth $4042.567. Market Cap $70.479 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076001861457588224",
    "text" : "One Bitcoin now worth $4042.567. Market Cap $70.479 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1076001861457588224,
    "created_at" : "2018-12-21 06:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1076006233591697409,
  "created_at" : "2018-12-21 06:47:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1076006173713801218",
  "text" : "RT @BTCticker: One Bitcoin now worth $3973.46@bitstamp. High $4172.070. Low $3690.700. Market Cap $69.272 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1076001862644588544",
    "text" : "One Bitcoin now worth $3973.46@bitstamp. High $4172.070. Low $3690.700. Market Cap $69.272 Billion #bitcoin",
    "id" : 1076001862644588544,
    "created_at" : "2018-12-21 06:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1076006173713801218,
  "created_at" : "2018-12-21 06:47:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/h0dJ3gA5w7",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5731305-Final-Product?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Final%20Product&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5731305-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076004464337846272",
  "text" : "Final Product by @gamer456148 https:\/\/t.co\/h0dJ3gA5w7",
  "id" : 1076004464337846272,
  "created_at" : "2018-12-21 06:40:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 17, 29 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/eTdZ3RMWOP",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5731297-Chat-App-Logo?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Chat%20App%20Logo&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5731297-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076003800866021376",
  "text" : "Chat App Logo by @gamer456148 https:\/\/t.co\/eTdZ3RMWOP",
  "id" : 1076003800866021376,
  "created_at" : "2018-12-21 06:37:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 22, 34 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/7n2g5W4PFf",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5731295-Research-Promotion?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Research%20Promotion&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5731295-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076003474649874433",
  "text" : "Research Promotion by @gamer456148 https:\/\/t.co\/7n2g5W4PFf",
  "id" : 1076003474649874433,
  "created_at" : "2018-12-21 06:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 25, 37 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/r3gpYysdJs",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5731288-Change-the-World-Post?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Change%20the%20World%20Post&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5731288-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1076003112123580416",
  "text" : "Change the World Post by @gamer456148 https:\/\/t.co\/r3gpYysdJs",
  "id" : 1076003112123580416,
  "created_at" : "2018-12-21 06:35:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075994366001459201",
  "text" : "RT @BTCticker: One Bitcoin now worth $4019.738. Market Cap $70.080 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075994301493067776",
    "text" : "One Bitcoin now worth $4019.738. Market Cap $70.080 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075994301493067776,
    "created_at" : "2018-12-21 06:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075994366001459201,
  "created_at" : "2018-12-21 06:00:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richardredhawk",
      "screen_name" : "richardredhawk",
      "indices" : [ 3, 18 ],
      "id_str" : "15080354",
      "id" : 15080354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shortribs",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075994234266796033",
  "text" : "RT @richardredhawk: Slow Cooker beef short ribs. Fall-apart beef served with a rich and red wine gravy. This is serious comfort  #shortribs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kitchen Sanctuary",
        "screen_name" : "KitchenSanc2ary",
        "indices" : [ 264, 280 ],
        "id_str" : "26327787",
        "id" : 26327787
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shortribs",
        "indices" : [ 109, 119 ]
      }, {
        "text" : "beefshortribs",
        "indices" : [ 120, 134 ]
      }, {
        "text" : "comfortfood",
        "indices" : [ 135, 147 ]
      }, {
        "text" : "dinnertonight",
        "indices" : [ 148, 162 ]
      }, {
        "text" : "winterfood",
        "indices" : [ 163, 174 ]
      }, {
        "text" : "SlowCooker",
        "indices" : [ 175, 186 ]
      }, {
        "text" : "slowcooked",
        "indices" : [ 187, 198 ]
      }, {
        "text" : "Beef",
        "indices" : [ 199, 204 ]
      }, {
        "text" : "Crockpot",
        "indices" : [ 205, 214 ]
      }, {
        "text" : "Recipe",
        "indices" : [ 215, 222 ]
      }, {
        "text" : "glutenfree",
        "indices" : [ 223, 234 ]
      } ],
      "urls" : [ {
        "indices" : [ 236, 259 ],
        "url" : "https:\/\/t.co\/u5rUaUkrEH",
        "expanded_url" : "https:\/\/www.kitchensanctuary.com\/crockpot-beef-short-ribs-with-rich-gravy\/?utm_source=twitter&utm_medium=Social&utm_campaign=SocialWarfare",
        "display_url" : "kitchensanctuary.com\/crockpot-beef-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075252500004069376",
    "text" : "Slow Cooker beef short ribs. Fall-apart beef served with a rich and red wine gravy. This is serious comfort  #shortribs #beefshortribs #comfortfood #dinnertonight #winterfood #SlowCooker #slowcooked #Beef #Crockpot #Recipe #glutenfree  https:\/\/t.co\/u5rUaUkrEH via @KitchenSanc2ary",
    "id" : 1075252500004069376,
    "created_at" : "2018-12-19 04:52:27 +0000",
    "user" : {
      "name" : "richardredhawk",
      "screen_name" : "richardredhawk",
      "protected" : false,
      "id_str" : "15080354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2878028280\/d3197b11c47410fd2f782860369b2e3c_normal.jpeg",
      "id" : 15080354,
      "verified" : false
    }
  },
  "id" : 1075994234266796033,
  "created_at" : "2018-12-21 05:59:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "indices" : [ 3, 15 ],
      "id_str" : "30278532",
      "id" : 30278532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075994099826810887",
  "text" : "RT @foodandwine: Inexpensive skirt steak is great cut for this recipe\u2014cooking it hot and fast is the key to the most tender results. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zWt2EutTCQ",
        "expanded_url" : "https:\/\/trib.al\/Jk9yISO",
        "display_url" : "trib.al\/Jk9yISO"
      } ]
    },
    "geo" : { },
    "id_str" : "1075940157830955009",
    "text" : "Inexpensive skirt steak is great cut for this recipe\u2014cooking it hot and fast is the key to the most tender results. https:\/\/t.co\/zWt2EutTCQ",
    "id" : 1075940157830955009,
    "created_at" : "2018-12-21 02:24:58 +0000",
    "user" : {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "protected" : false,
      "id_str" : "30278532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738810295301246977\/sJKDqlWh_normal.jpg",
      "id" : 30278532,
      "verified" : true
    }
  },
  "id" : 1075994099826810887,
  "created_at" : "2018-12-21 05:59:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Silver",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "Platinum",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075994073637502976",
  "text" : "RT @ausecure: Streaming #Gold $1260.8 +$16.8\/1.33% #Silver $14.75 +$0.1\/0.68% #Platinum $793.3 +$3.6\/0.45% #Palladium $1259.5 -$8.4\/0.67%",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Silver",
        "indices" : [ 37, 44 ]
      }, {
        "text" : "Platinum",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075797991372529669",
    "text" : "Streaming #Gold $1260.8 +$16.8\/1.33% #Silver $14.75 +$0.1\/0.68% #Platinum $793.3 +$3.6\/0.45% #Palladium $1259.5 -$8.4\/0.67%",
    "id" : 1075797991372529669,
    "created_at" : "2018-12-20 17:00:03 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 1075994073637502976,
  "created_at" : "2018-12-21 05:59:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "indices" : [ 3, 18 ],
      "id_str" : "1626294277",
      "id" : 1626294277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075994061616627712",
  "text" : "RT @spectatorindex: BREAKING: 7000 US troops to withdraw from Afghanistan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075916377238659072",
    "text" : "BREAKING: 7000 US troops to withdraw from Afghanistan",
    "id" : 1075916377238659072,
    "created_at" : "2018-12-21 00:50:28 +0000",
    "user" : {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "protected" : false,
      "id_str" : "1626294277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839067030904922112\/LH4xqz-d_normal.jpg",
      "id" : 1626294277,
      "verified" : false
    }
  },
  "id" : 1075994061616627712,
  "created_at" : "2018-12-21 05:59:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075993992502931456",
  "text" : "RT @SpaceX: Now targeting December 22 launch of GPS III SV01. Weather is 80% favorable for the launch window which opens at 8:55 a.m. EST,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075778452064632838",
    "text" : "Now targeting December 22 launch of GPS III SV01. Weather is 80% favorable for the launch window which opens at 8:55 a.m. EST, 13:55 UTC.",
    "id" : 1075778452064632838,
    "created_at" : "2018-12-20 15:42:24 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1075993992502931456,
  "created_at" : "2018-12-21 05:58:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Odisho",
      "screen_name" : "JustinOdisho",
      "indices" : [ 3, 16 ],
      "id_str" : "374160477",
      "id" : 374160477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075993644652470275",
  "text" : "RT @JustinOdisho: Who says you have to do it the way it\u2019s always been done before",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069762076208480257",
    "text" : "Who says you have to do it the way it\u2019s always been done before",
    "id" : 1069762076208480257,
    "created_at" : "2018-12-04 01:15:28 +0000",
    "user" : {
      "name" : "Justin Odisho",
      "screen_name" : "JustinOdisho",
      "protected" : false,
      "id_str" : "374160477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928568639061745664\/XbHY04mZ_normal.jpg",
      "id" : 374160477,
      "verified" : false
    }
  },
  "id" : 1075993644652470275,
  "created_at" : "2018-12-21 05:57:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Tracffic Pattern",
      "screen_name" : "thetrfcpattern",
      "indices" : [ 3, 18 ],
      "id_str" : "1055119944323608576",
      "id" : 1055119944323608576
    }, {
      "name" : "Justin Odisho",
      "screen_name" : "JustinOdisho",
      "indices" : [ 98, 111 ],
      "id_str" : "374160477",
      "id" : 374160477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075993460002471936",
  "text" : "RT @thetrfcpattern: I literally just watched the best mobile podcast setup on YouTube, created by @JustinOdisho ! Wow. Great content! Thank\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Odisho",
        "screen_name" : "JustinOdisho",
        "indices" : [ 78, 91 ],
        "id_str" : "374160477",
        "id" : 374160477
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073098630121357312",
    "text" : "I literally just watched the best mobile podcast setup on YouTube, created by @JustinOdisho ! Wow. Great content! Thank you!",
    "id" : 1073098630121357312,
    "created_at" : "2018-12-13 06:13:45 +0000",
    "user" : {
      "name" : "The Tracffic Pattern",
      "screen_name" : "thetrfcpattern",
      "protected" : false,
      "id_str" : "1055119944323608576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1057343992470429696\/2ZIIn56n_normal.jpg",
      "id" : 1055119944323608576,
      "verified" : false
    }
  },
  "id" : 1075993460002471936,
  "created_at" : "2018-12-21 05:56:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Odisho",
      "screen_name" : "JustinOdisho",
      "indices" : [ 3, 16 ],
      "id_str" : "374160477",
      "id" : 374160477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075993398652358656",
  "text" : "RT @JustinOdisho: If you make a 10 hour video nobody will watch it, but if you take that same video and cut it into 10 one hour episodes...\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073783562422444032",
    "text" : "If you make a 10 hour video nobody will watch it, but if you take that same video and cut it into 10 one hour episodes... people will watch it straight through",
    "id" : 1073783562422444032,
    "created_at" : "2018-12-15 03:35:25 +0000",
    "user" : {
      "name" : "Justin Odisho",
      "screen_name" : "JustinOdisho",
      "protected" : false,
      "id_str" : "374160477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/928568639061745664\/XbHY04mZ_normal.jpg",
      "id" : 374160477,
      "verified" : false
    }
  },
  "id" : 1075993398652358656,
  "created_at" : "2018-12-21 05:56:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "indices" : [ 3, 18 ],
      "id_str" : "2984496093",
      "id" : 2984496093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075993282688270336",
  "text" : "RT @_daniellebleau: Life motto: be sweet but don\u2019t get walked all over",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075980825110503433",
    "text" : "Life motto: be sweet but don\u2019t get walked all over",
    "id" : 1075980825110503433,
    "created_at" : "2018-12-21 05:06:34 +0000",
    "user" : {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "protected" : false,
      "id_str" : "2984496093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936751927429386241\/Ra89-JcI_normal.jpg",
      "id" : 2984496093,
      "verified" : false
    }
  },
  "id" : 1075993282688270336,
  "created_at" : "2018-12-21 05:56:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/mSkibc8cBz",
      "expanded_url" : "https:\/\/trib.al\/tOO5sMp",
      "display_url" : "trib.al\/tOO5sMp"
    } ]
  },
  "geo" : { },
  "id_str" : "1075993230918017029",
  "text" : "RT @epicurious: It\u2019s easily breakable\u2014but we\u2019re here to prevent that. \nhttps:\/\/t.co\/mSkibc8cBz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/mSkibc8cBz",
        "expanded_url" : "https:\/\/trib.al\/tOO5sMp",
        "display_url" : "trib.al\/tOO5sMp"
      } ]
    },
    "geo" : { },
    "id_str" : "1075989509915983872",
    "text" : "It\u2019s easily breakable\u2014but we\u2019re here to prevent that. \nhttps:\/\/t.co\/mSkibc8cBz",
    "id" : 1075989509915983872,
    "created_at" : "2018-12-21 05:41:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1075993230918017029,
  "created_at" : "2018-12-21 05:55:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 23, 35 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/rd7ZdDjxQL",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5731169-Specialized-Buttons?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Specialized%20Buttons&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5731169-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075992808513781760",
  "text" : "Specialized Buttons by @gamer456148 https:\/\/t.co\/rd7ZdDjxQL",
  "id" : 1075992808513781760,
  "created_at" : "2018-12-21 05:54:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pablo Wilco",
      "screen_name" : "KatfishWilly",
      "indices" : [ 3, 16 ],
      "id_str" : "2397263106",
      "id" : 2397263106
    }, {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "indices" : [ 18, 33 ],
      "id_str" : "3511430425",
      "id" : 3511430425
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075902127992639488",
  "text" : "RT @KatfishWilly: @fermatslibrary @gamer456148 Practically it's 7-8 metres due to loss of pressure from creating the flow, resistance\/frict\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fermat's Library",
        "screen_name" : "fermatslibrary",
        "indices" : [ 0, 15 ],
        "id_str" : "3511430425",
        "id" : 3511430425
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 16, 28 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1075752940709797888",
    "geo" : { },
    "id_str" : "1075831750498996225",
    "in_reply_to_user_id" : 3511430425,
    "text" : "@fermatslibrary @gamer456148 Practically it's 7-8 metres due to loss of pressure from creating the flow, resistance\/friction loss, static head and the temperature and turbidity of the liquid your drinking from.",
    "id" : 1075831750498996225,
    "in_reply_to_status_id" : 1075752940709797888,
    "created_at" : "2018-12-20 19:14:11 +0000",
    "in_reply_to_screen_name" : "fermatslibrary",
    "in_reply_to_user_id_str" : "3511430425",
    "user" : {
      "name" : "Pablo Wilco",
      "screen_name" : "KatfishWilly",
      "protected" : false,
      "id_str" : "2397263106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/987913666853879808\/LWDkrN3B_normal.jpg",
      "id" : 2397263106,
      "verified" : false
    }
  },
  "id" : 1075902127992639488,
  "created_at" : "2018-12-20 23:53:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075901991203823617",
  "text" : "RT @AP: BREAKING: Another brutal day on Wall Street leaves Dow down 10 percent for December, headed for its worst month in nearly a decade.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075859285136076800",
    "text" : "BREAKING: Another brutal day on Wall Street leaves Dow down 10 percent for December, headed for its worst month in nearly a decade.",
    "id" : 1075859285136076800,
    "created_at" : "2018-12-20 21:03:36 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 1075901991203823617,
  "created_at" : "2018-12-20 23:53:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vidIQ \uD83C\uDF89\uD83D\uDE80\uD83D\uDCC8",
      "screen_name" : "vidIQ",
      "indices" : [ 3, 9 ],
      "id_str" : "394213943",
      "id" : 394213943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075901938548514819",
  "text" : "RT @vidIQ: \uD83C\uDF84\uD83C\uDF81\uD83C\uDF89 All I want for Christmas is _______?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075876748598894594",
    "text" : "\uD83C\uDF84\uD83C\uDF81\uD83C\uDF89 All I want for Christmas is _______?",
    "id" : 1075876748598894594,
    "created_at" : "2018-12-20 22:13:00 +0000",
    "user" : {
      "name" : "vidIQ \uD83C\uDF89\uD83D\uDE80\uD83D\uDCC8",
      "screen_name" : "vidIQ",
      "protected" : false,
      "id_str" : "394213943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000837588547\/3525fadd947ce31e6e4dd43f16e08794_normal.png",
      "id" : 394213943,
      "verified" : true
    }
  },
  "id" : 1075901938548514819,
  "created_at" : "2018-12-20 23:53:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6AY4buFFmE",
      "expanded_url" : "https:\/\/learn.tradimo.com\/instructors\/34386",
      "display_url" : "learn.tradimo.com\/instructors\/34\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075901876917420032",
  "text" : "https:\/\/t.co\/6AY4buFFmE",
  "id" : 1075901876917420032,
  "created_at" : "2018-12-20 23:52:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 38, 45 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 46, 55 ]
    }, {
      "text" : "instafood",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "foodchats",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/2PngWyPWUM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BroGqZ6Fx-U\/?utm_source=ig_twitter_share&igshid=1cbqob6drgd80",
      "display_url" : "instagram.com\/p\/BroGqZ6Fx-U\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075887097653981184",
  "text" : "Homemade garlic bread was done for me #foodie #foodpics #instafood #foodchats https:\/\/t.co\/2PngWyPWUM",
  "id" : 1075887097653981184,
  "created_at" : "2018-12-20 22:54:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "instafood",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "foodiechats",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/tDR8thS4Ox",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Brnu0MDlF3s\/?utm_source=ig_twitter_share&igshid=1wcipzgk8hnej",
      "display_url" : "instagram.com\/p\/Brnu0MDlF3s\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075835190000390144",
  "text" : "Food is just awesome #foodie #instafood #foodpics #foodiechats https:\/\/t.co\/tDR8thS4Ox",
  "id" : 1075835190000390144,
  "created_at" : "2018-12-20 19:27:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3DPrinting",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/hVqjKlfR8f",
      "expanded_url" : "https:\/\/adafru.it\/Dnl",
      "display_url" : "adafru.it\/Dnl"
    } ]
  },
  "geo" : { },
  "id_str" : "1075821514044440577",
  "text" : "RT @adafruit: Filament Guide with Duster and Filament Runout Sensor #3DPrinting https:\/\/t.co\/hVqjKlfR8f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3DPrinting",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/hVqjKlfR8f",
        "expanded_url" : "https:\/\/adafru.it\/Dnl",
        "display_url" : "adafru.it\/Dnl"
      } ]
    },
    "geo" : { },
    "id_str" : "1075798240635830274",
    "text" : "Filament Guide with Duster and Filament Runout Sensor #3DPrinting https:\/\/t.co\/hVqjKlfR8f",
    "id" : 1075798240635830274,
    "created_at" : "2018-12-20 17:01:02 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1075821514044440577,
  "created_at" : "2018-12-20 18:33:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075821416040316929",
  "text" : "RT @MikeWShell: Stock prices stop falling when those who want to sell have sold and prices reach a low enough level that attracts new buyin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075815544761319424",
    "text" : "Stock prices stop falling when those who want to sell have sold and prices reach a low enough level that attracts new buying.",
    "id" : 1075815544761319424,
    "created_at" : "2018-12-20 18:09:48 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1075821416040316929,
  "created_at" : "2018-12-20 18:33:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075821391231025152",
  "text" : "RT @BTCticker: One Bitcoin now worth $4064.08@bitstamp. High $4172.070. Low $3650.000. Market Cap $70.845 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075820664278401024",
    "text" : "One Bitcoin now worth $4064.08@bitstamp. High $4172.070. Low $3650.000. Market Cap $70.845 Billion #bitcoin",
    "id" : 1075820664278401024,
    "created_at" : "2018-12-20 18:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075821391231025152,
  "created_at" : "2018-12-20 18:33:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shell Capital \u2014 ASYMMETRY\u00AE",
      "screen_name" : "ShellCapital",
      "indices" : [ 3, 16 ],
      "id_str" : "923564411142443019",
      "id" : 923564411142443019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075821366962778115",
  "text" : "RT @ShellCapital: What direction do you think is most likely next for the U. S. stock market?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075803217878024194",
    "text" : "What direction do you think is most likely next for the U. S. stock market?",
    "id" : 1075803217878024194,
    "created_at" : "2018-12-20 17:20:49 +0000",
    "user" : {
      "name" : "Shell Capital \u2014 ASYMMETRY\u00AE",
      "screen_name" : "ShellCapital",
      "protected" : false,
      "id_str" : "923564411142443019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/998551055234301953\/6v6Ib_7X_normal.jpg",
      "id" : 923564411142443019,
      "verified" : false
    }
  },
  "id" : 1075821366962778115,
  "created_at" : "2018-12-20 18:32:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isabelle Morales",
      "screen_name" : "IsabelleAliciaa",
      "indices" : [ 3, 19 ],
      "id_str" : "2510648068",
      "id" : 2510648068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075821267243159552",
  "text" : "RT @IsabelleAliciaa: If your objective in the Middle East is to keep our troops deployed until there is complete peace, then you should sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075806220387319808",
    "text" : "If your objective in the Middle East is to keep our troops deployed until there is complete peace, then you should start coming to terms with the fact that you will never want to bring troops home from the area.",
    "id" : 1075806220387319808,
    "created_at" : "2018-12-20 17:32:45 +0000",
    "user" : {
      "name" : "Isabelle Morales",
      "screen_name" : "IsabelleAliciaa",
      "protected" : false,
      "id_str" : "2510648068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077406159668240384\/f2j0UZpv_normal.jpg",
      "id" : 2510648068,
      "verified" : false
    }
  },
  "id" : 1075821267243159552,
  "created_at" : "2018-12-20 18:32:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075821175639601153",
  "text" : "Just did another XPrize proposal, not one of my best, will see how it goes",
  "id" : 1075821175639601153,
  "created_at" : "2018-12-20 18:32:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bitcoin Spreads",
      "screen_name" : "BitcoinSpreads",
      "indices" : [ 3, 18 ],
      "id_str" : "2257986397",
      "id" : 2257986397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTC",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "Bitcoin",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "Bitstamp",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "Kraken",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075796495058784258",
  "text" : "RT @BitcoinSpreads: 1 #BTC (#Bitcoin) quotes:\n$3833.74\/$3837.99 #Bitstamp\n$3837.39\/$3838.90 #Kraken\n\u21E2$-0.60\/$5.16\n$3817.82\/$3857.07 #Coinba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/ignacio\/LuaOAuth\/\" rel=\"nofollow\"\u003Econtributor\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BTC",
        "indices" : [ 2, 6 ]
      }, {
        "text" : "Bitcoin",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "Bitstamp",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "Kraken",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "Coinbase",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069667632666812416",
    "text" : "1 #BTC (#Bitcoin) quotes:\n$3833.74\/$3837.99 #Bitstamp\n$3837.39\/$3838.90 #Kraken\n\u21E2$-0.60\/$5.16\n$3817.82\/$3857.07 #Coinbase\n\u21E2$-20.17\/$23.33",
    "id" : 1069667632666812416,
    "created_at" : "2018-12-03 19:00:11 +0000",
    "user" : {
      "name" : "Bitcoin Spreads",
      "screen_name" : "BitcoinSpreads",
      "protected" : false,
      "id_str" : "2257986397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443138626134630400\/e7IdYQZG_normal.png",
      "id" : 2257986397,
      "verified" : false
    }
  },
  "id" : 1075796495058784258,
  "created_at" : "2018-12-20 16:54:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bitcoin Spreads",
      "screen_name" : "BitcoinSpreads",
      "indices" : [ 3, 18 ],
      "id_str" : "2257986397",
      "id" : 2257986397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTC",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "Bitcoin",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "Bitstamp",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "Kraken",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075796477409193984",
  "text" : "RT @BitcoinSpreads: 1 #BTC (#Bitcoin) quotes:\n$3811.32\/$3813.78 #Bitstamp\n$3813.11\/$3818.50 #Kraken\n\u21E2$-0.67\/$7.18\n$3792.73\/$3830.98 #Coinba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/github.com\/ignacio\/LuaOAuth\/\" rel=\"nofollow\"\u003Econtributor\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BTC",
        "indices" : [ 2, 6 ]
      }, {
        "text" : "Bitcoin",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "Bitstamp",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "Kraken",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "Coinbase",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069682734090596352",
    "text" : "1 #BTC (#Bitcoin) quotes:\n$3811.32\/$3813.78 #Bitstamp\n$3813.11\/$3818.50 #Kraken\n\u21E2$-0.67\/$7.18\n$3792.73\/$3830.98 #Coinbase\n\u21E2$-21.05\/$19.66",
    "id" : 1069682734090596352,
    "created_at" : "2018-12-03 20:00:12 +0000",
    "user" : {
      "name" : "Bitcoin Spreads",
      "screen_name" : "BitcoinSpreads",
      "protected" : false,
      "id_str" : "2257986397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443138626134630400\/e7IdYQZG_normal.png",
      "id" : 2257986397,
      "verified" : false
    }
  },
  "id" : 1075796477409193984,
  "created_at" : "2018-12-20 16:54:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075796283942686721",
  "text" : "RT @BTCticker: One Bitcoin now worth $4038.813. Market Cap $70.408 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075745169964744711",
    "text" : "One Bitcoin now worth $4038.813. Market Cap $70.408 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075745169964744711,
    "created_at" : "2018-12-20 13:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075796283942686721,
  "created_at" : "2018-12-20 16:53:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 3, 11 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075796174538506240",
  "text" : "RT @garyvee: Winners win. I am fascinated to see emerging winners try to tear down other winners, never works",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075777700361433088",
    "text" : "Winners win. I am fascinated to see emerging winners try to tear down other winners, never works",
    "id" : 1075777700361433088,
    "created_at" : "2018-12-20 15:39:25 +0000",
    "user" : {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "protected" : false,
      "id_str" : "5768872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839672994159013894\/ndVV3x8D_normal.jpg",
      "id" : 5768872,
      "verified" : true
    }
  },
  "id" : 1075796174538506240,
  "created_at" : "2018-12-20 16:52:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075796044976316416",
  "text" : "RT @BTCticker: One Bitcoin now worth $4109.432. Market Cap $71.640 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075790463972581376",
    "text" : "One Bitcoin now worth $4109.432. Market Cap $71.640 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075790463972581376,
    "created_at" : "2018-12-20 16:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075796044976316416,
  "created_at" : "2018-12-20 16:52:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/9ptwh4yJUr",
      "expanded_url" : "https:\/\/twitter.com\/ABC7Chicago\/status\/1075524917725184000",
      "display_url" : "twitter.com\/ABC7Chicago\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075796015180062720",
  "text" : "RT @KassyDillon: Leave. Him. Alone. https:\/\/t.co\/9ptwh4yJUr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/9ptwh4yJUr",
        "expanded_url" : "https:\/\/twitter.com\/ABC7Chicago\/status\/1075524917725184000",
        "display_url" : "twitter.com\/ABC7Chicago\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075788719053885443",
    "text" : "Leave. Him. Alone. https:\/\/t.co\/9ptwh4yJUr",
    "id" : 1075788719053885443,
    "created_at" : "2018-12-20 16:23:12 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1076158543168847872\/vztW80IL_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 1075796015180062720,
  "created_at" : "2018-12-20 16:52:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "indices" : [ 3, 9 ],
      "id_str" : "4020532937",
      "id" : 4020532937
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1075632252992794626\/video\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fGxpn0OixL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Du1cHjWXcAAzJjE.jpg",
      "id_str" : "1075617173429727232",
      "id" : 1075617173429727232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du1cHjWXcAAzJjE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fGxpn0OixL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075795911182352390",
  "text" : "RT @tasty: Chicken fingers that'll have you drooling...\nWhich is your favorite?! https:\/\/t.co\/fGxpn0OixL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/pubhub.buzzfeed.com\" rel=\"nofollow\"\u003EBF PubHub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1075632252992794626\/video\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/fGxpn0OixL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Du1cHjWXcAAzJjE.jpg",
        "id_str" : "1075617173429727232",
        "id" : 1075617173429727232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du1cHjWXcAAzJjE.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/fGxpn0OixL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075632252992794626",
    "text" : "Chicken fingers that'll have you drooling...\nWhich is your favorite?! https:\/\/t.co\/fGxpn0OixL",
    "id" : 1075632252992794626,
    "created_at" : "2018-12-20 06:01:28 +0000",
    "user" : {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "protected" : false,
      "id_str" : "4020532937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887725624105738240\/enrb4x3-_normal.jpg",
      "id" : 4020532937,
      "verified" : true
    }
  },
  "id" : 1075795911182352390,
  "created_at" : "2018-12-20 16:51:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "3511430425",
      "id" : 3511430425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fermatslibrary\/status\/1075752940709797888\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/pw7cuFrGcX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Du3XmQRXgAEyPRO.jpg",
      "id_str" : "1075752938214227969",
      "id" : 1075752938214227969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du3XmQRXgAEyPRO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1680,
        "resize" : "fit",
        "w" : 2992
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/pw7cuFrGcX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075795811470999552",
  "text" : "RT @fermatslibrary: The longest straw you can drink from is approximately 10.3 m (33.8 ft) long https:\/\/t.co\/pw7cuFrGcX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fermatslibrary\/status\/1075752940709797888\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/pw7cuFrGcX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Du3XmQRXgAEyPRO.jpg",
        "id_str" : "1075752938214227969",
        "id" : 1075752938214227969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du3XmQRXgAEyPRO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1150,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1680,
          "resize" : "fit",
          "w" : 2992
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/pw7cuFrGcX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075752940709797888",
    "text" : "The longest straw you can drink from is approximately 10.3 m (33.8 ft) long https:\/\/t.co\/pw7cuFrGcX",
    "id" : 1075752940709797888,
    "created_at" : "2018-12-20 14:01:02 +0000",
    "user" : {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "protected" : false,
      "id_str" : "3511430425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641822497457860608\/zd6kUAag_normal.png",
      "id" : 3511430425,
      "verified" : false
    }
  },
  "id" : 1075795811470999552,
  "created_at" : "2018-12-20 16:51:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/mKlTMera3d",
      "expanded_url" : "https:\/\/goo.gl\/K3dHeD",
      "display_url" : "goo.gl\/K3dHeD"
    } ]
  },
  "geo" : { },
  "id_str" : "1075795642369433600",
  "text" : "This Guy started a Drone Startup at 21 https:\/\/t.co\/mKlTMera3d",
  "id" : 1075795642369433600,
  "created_at" : "2018-12-20 16:50:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/crWILj8tCH",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/922531049917534208",
      "display_url" : "minds.com\/newsfeed\/92253\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075795533640425472",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/crWILj8tCH",
  "id" : 1075795533640425472,
  "created_at" : "2018-12-20 16:50:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Food Lab",
      "screen_name" : "TheFoodLab",
      "indices" : [ 3, 14 ],
      "id_str" : "86328927",
      "id" : 86328927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075629649621848064",
  "text" : "RT @TheFoodLab: One of the few cuts of meat that is easy, impressive, AND affordable\u2014so yeah, it's a good candidate for your holiday table.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/M4l8o0Iowr",
        "expanded_url" : "http:\/\/www.seriouseats.com\/2015\/11\/how-to-make-pork-loin-roast.html",
        "display_url" : "seriouseats.com\/2015\/11\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075495991845875712",
    "text" : "One of the few cuts of meat that is easy, impressive, AND affordable\u2014so yeah, it's a good candidate for your holiday table.\nhttps:\/\/t.co\/M4l8o0Iowr",
    "id" : 1075495991845875712,
    "created_at" : "2018-12-19 21:00:00 +0000",
    "user" : {
      "name" : "The Food Lab",
      "screen_name" : "TheFoodLab",
      "protected" : false,
      "id_str" : "86328927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588391006115995648\/GW0c4n4-_normal.png",
      "id" : 86328927,
      "verified" : true
    }
  },
  "id" : 1075629649621848064,
  "created_at" : "2018-12-20 05:51:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075629208716623872",
  "text" : "RT @BTCticker: One Bitcoin now worth $3775.203. Market Cap $65.810 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075624365734182913",
    "text" : "One Bitcoin now worth $3775.203. Market Cap $65.810 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075624365734182913,
    "created_at" : "2018-12-20 05:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075629208716623872,
  "created_at" : "2018-12-20 05:49:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodpics",
      "indices" : [ 40, 49 ]
    }, {
      "text" : "foodie",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "instafood",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "foodiechats",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/8FzCVOdXwf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrmRUtAFRgg\/?utm_source=ig_twitter_share&igshid=1gfz8xb5jy8uq",
      "display_url" : "instagram.com\/p\/BrmRUtAFRgg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075629067251130369",
  "text" : "French bread makes the best Texas toast #foodpics #foodie #instafood #foodiechats https:\/\/t.co\/8FzCVOdXwf",
  "id" : 1075629067251130369,
  "created_at" : "2018-12-20 05:48:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075612410034225152",
  "text" : "RT @AP: BREAKING: Japan's court denies prosecutor's request to extend detention of ex-Nissan chair Carlos Ghosn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075612126620860416",
    "text" : "BREAKING: Japan's court denies prosecutor's request to extend detention of ex-Nissan chair Carlos Ghosn.",
    "id" : 1075612126620860416,
    "created_at" : "2018-12-20 04:41:29 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 1075612410034225152,
  "created_at" : "2018-12-20 04:42:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NJPAdiFA5m",
      "expanded_url" : "https:\/\/adafru.it\/DmS",
      "display_url" : "adafru.it\/DmS"
    } ]
  },
  "geo" : { },
  "id_str" : "1075612125056372736",
  "text" : "RT @adafruit: NEW PRODUCTS \u2013 USB Micro B and USB Mini B to 5-pin Terminal Blocks https:\/\/t.co\/NJPAdiFA5m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/NJPAdiFA5m",
        "expanded_url" : "https:\/\/adafru.it\/DmS",
        "display_url" : "adafru.it\/DmS"
      } ]
    },
    "geo" : { },
    "id_str" : "1075496248763924480",
    "text" : "NEW PRODUCTS \u2013 USB Micro B and USB Mini B to 5-pin Terminal Blocks https:\/\/t.co\/NJPAdiFA5m",
    "id" : 1075496248763924480,
    "created_at" : "2018-12-19 21:01:02 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1075612125056372736,
  "created_at" : "2018-12-20 04:41:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#TheMoneyMan",
      "screen_name" : "LawrenceCainJr",
      "indices" : [ 3, 18 ],
      "id_str" : "246534434",
      "id" : 246534434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075612032626503682",
  "text" : "RT @LawrenceCainJr: Anytime I talk to a close friend about their goals, I get hype like they\u2019re my goals.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070493772029616129",
    "text" : "Anytime I talk to a close friend about their goals, I get hype like they\u2019re my goals.",
    "id" : 1070493772029616129,
    "created_at" : "2018-12-06 01:42:58 +0000",
    "user" : {
      "name" : "#TheMoneyMan",
      "screen_name" : "LawrenceCainJr",
      "protected" : false,
      "id_str" : "246534434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1067527816311435266\/z0aVEmLo_normal.jpg",
      "id" : 246534434,
      "verified" : false
    }
  },
  "id" : 1075612032626503682,
  "created_at" : "2018-12-20 04:41:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Mayer",
      "screen_name" : "ashleymayer",
      "indices" : [ 3, 15 ],
      "id_str" : "18994034",
      "id" : 18994034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075611615205212160",
  "text" : "RT @ashleymayer: Nothing makes you want to own less stuff more than moving. \uD83D\uDE33",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075610822221524992",
    "text" : "Nothing makes you want to own less stuff more than moving. \uD83D\uDE33",
    "id" : 1075610822221524992,
    "created_at" : "2018-12-20 04:36:18 +0000",
    "user" : {
      "name" : "Ashley Mayer",
      "screen_name" : "ashleymayer",
      "protected" : false,
      "id_str" : "18994034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1033227403282153472\/zdfIv_-o_normal.jpg",
      "id" : 18994034,
      "verified" : false
    }
  },
  "id" : 1075611615205212160,
  "created_at" : "2018-12-20 04:39:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "indices" : [ 3, 17 ],
      "id_str" : "1070137173054291968",
      "id" : 1070137173054291968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075611345192652800",
  "text" : "RT @Evie_Magazine: Some women believe choosing to serve a male boss or CEO is empowering, while choosing to serve your family is a form of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075504073783238656",
    "text" : "Some women believe choosing to serve a male boss or CEO is empowering, while choosing to serve your family is a form of oppression.",
    "id" : 1075504073783238656,
    "created_at" : "2018-12-19 21:32:07 +0000",
    "user" : {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "protected" : false,
      "id_str" : "1070137173054291968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1070138769192480768\/0Ul8pT5t_normal.jpg",
      "id" : 1070137173054291968,
      "verified" : false
    }
  },
  "id" : 1075611345192652800,
  "created_at" : "2018-12-20 04:38:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "indices" : [ 3, 17 ],
      "id_str" : "1070137173054291968",
      "id" : 1070137173054291968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075611279493074949",
  "text" : "RT @Evie_Magazine: Please stop telling us we're victims. There is nothing empowering about embracing victimhood. Women have more equality a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "empowerment",
        "indices" : [ 202, 214 ]
      }, {
        "text" : "WomensRights",
        "indices" : [ 215, 228 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075507861319409665",
    "text" : "Please stop telling us we're victims. There is nothing empowering about embracing victimhood. Women have more equality and opportunity now than ever before in history. Look for solutions, not problems. #empowerment #WomensRights",
    "id" : 1075507861319409665,
    "created_at" : "2018-12-19 21:47:10 +0000",
    "user" : {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "protected" : false,
      "id_str" : "1070137173054291968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1070138769192480768\/0Ul8pT5t_normal.jpg",
      "id" : 1070137173054291968,
      "verified" : false
    }
  },
  "id" : 1075611279493074949,
  "created_at" : "2018-12-20 04:38:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "indices" : [ 3, 17 ],
      "id_str" : "1070137173054291968",
      "id" : 1070137173054291968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075611222953943041",
  "text" : "RT @Evie_Magazine: Masculinity in men is not toxic for society. Effeminacy is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075541296339607552",
    "text" : "Masculinity in men is not toxic for society. Effeminacy is.",
    "id" : 1075541296339607552,
    "created_at" : "2018-12-20 00:00:02 +0000",
    "user" : {
      "name" : "Evie",
      "screen_name" : "Evie_Magazine",
      "protected" : false,
      "id_str" : "1070137173054291968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1070138769192480768\/0Ul8pT5t_normal.jpg",
      "id" : 1070137173054291968,
      "verified" : false
    }
  },
  "id" : 1075611222953943041,
  "created_at" : "2018-12-20 04:37:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075610976261734401",
  "text" : "RT @BTCticker: One Bitcoin now worth $3778.830. Market Cap $65.873 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075609271365234688",
    "text" : "One Bitcoin now worth $3778.830. Market Cap $65.873 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075609271365234688,
    "created_at" : "2018-12-20 04:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075610976261734401,
  "created_at" : "2018-12-20 04:36:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Boring Company",
      "screen_name" : "boringcompany",
      "indices" : [ 3, 17 ],
      "id_str" : "859816394556284929",
      "id" : 859816394556284929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/boringcompany\/status\/1075318894871470081\/video\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/xVpDHzZKXB",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1075318818245771265\/pu\/img\/d2RVx1m4LT7OO6cW.jpg",
      "id_str" : "1075318818245771265",
      "id" : 1075318818245771265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1075318818245771265\/pu\/img\/d2RVx1m4LT7OO6cW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/xVpDHzZKXB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075610856707235840",
  "text" : "RT @boringcompany: The Boring Company Loop system https:\/\/t.co\/xVpDHzZKXB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/boringcompany\/status\/1075318894871470081\/video\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/xVpDHzZKXB",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1075318818245771265\/pu\/img\/d2RVx1m4LT7OO6cW.jpg",
        "id_str" : "1075318818245771265",
        "id" : 1075318818245771265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1075318818245771265\/pu\/img\/d2RVx1m4LT7OO6cW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/xVpDHzZKXB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075318894871470081",
    "text" : "The Boring Company Loop system https:\/\/t.co\/xVpDHzZKXB",
    "id" : 1075318894871470081,
    "created_at" : "2018-12-19 09:16:17 +0000",
    "user" : {
      "name" : "The Boring Company",
      "screen_name" : "boringcompany",
      "protected" : false,
      "id_str" : "859816394556284929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1039775185862242304\/-NLaPOqV_normal.jpg",
      "id" : 859816394556284929,
      "verified" : true
    }
  },
  "id" : 1075610856707235840,
  "created_at" : "2018-12-20 04:36:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "Institute of Physics",
      "screen_name" : "PhysicsNews",
      "indices" : [ 88, 100 ],
      "id_str" : "34960648",
      "id" : 34960648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Satellite",
      "indices" : [ 17, 27 ]
    }, {
      "text" : "quantum",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/z5Gi03Getu",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-satellite-global-quantum.html",
      "display_url" : "phys.org\/news\/2018-12-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075610576213151744",
  "text" : "RT @physorg_com: #Satellite study proves global #quantum communication will be possible @physicsnews https:\/\/t.co\/z5Gi03Getu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Institute of Physics",
        "screen_name" : "PhysicsNews",
        "indices" : [ 71, 83 ],
        "id_str" : "34960648",
        "id" : 34960648
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Satellite",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "quantum",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/z5Gi03Getu",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-satellite-global-quantum.html",
        "display_url" : "phys.org\/news\/2018-12-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075541296478109696",
    "text" : "#Satellite study proves global #quantum communication will be possible @physicsnews https:\/\/t.co\/z5Gi03Getu",
    "id" : 1075541296478109696,
    "created_at" : "2018-12-20 00:00:02 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1075610576213151744,
  "created_at" : "2018-12-20 04:35:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Q",
      "screen_name" : "qwoyak4",
      "indices" : [ 3, 11 ],
      "id_str" : "4822004507",
      "id" : 4822004507
    }, {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 47, 55 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075610325947424768",
  "text" : "RT @qwoyak4: I feel like I learn more watching @garyvee videos than I do sitting at school all day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gary Vaynerchuk",
        "screen_name" : "garyvee",
        "indices" : [ 34, 42 ],
        "id_str" : "5768872",
        "id" : 5768872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075227402933100544",
    "text" : "I feel like I learn more watching @garyvee videos than I do sitting at school all day.",
    "id" : 1075227402933100544,
    "created_at" : "2018-12-19 03:12:44 +0000",
    "user" : {
      "name" : "Q",
      "screen_name" : "qwoyak4",
      "protected" : false,
      "id_str" : "4822004507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1041841843829387265\/zVSDY826_normal.jpg",
      "id" : 4822004507,
      "verified" : false
    }
  },
  "id" : 1075610325947424768,
  "created_at" : "2018-12-20 04:34:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u072A\u071D\u0721\u0710",
      "screen_name" : "rimapana",
      "indices" : [ 3, 12 ],
      "id_str" : "1022056945207922689",
      "id" : 1022056945207922689
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/hedgGcFZSV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORjWsAUTQkV.jpg",
      "id_str" : "1075502937101742085",
      "id" : 1075502937101742085,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORjWsAUTQkV.jpg",
      "sizes" : [ {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 846
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 479
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hedgGcFZSV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/hedgGcFZSV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORmWsAYu6y5.jpg",
      "id_str" : "1075502937114324998",
      "id" : 1075502937114324998,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORmWsAYu6y5.jpg",
      "sizes" : [ {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 479
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 846
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hedgGcFZSV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/hedgGcFZSV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORjWsA0jh3w.jpg",
      "id_str" : "1075502937101742093",
      "id" : 1075502937101742093,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORjWsA0jh3w.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hedgGcFZSV"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/hedgGcFZSV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORhWsAs_FCD.jpg",
      "id_str" : "1075502937093353483",
      "id" : 1075502937093353483,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORhWsAs_FCD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1247,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1247,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hedgGcFZSV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075610054001418240",
  "text" : "RT @rimapana: 24 new readers [qoruye] to serve the syriac orthodox church in damascus. \u0710\u0720\u0717\u0710 \u0721\u0712\u072A\u071F\u0323 \u0720\u0717\u0718\u0722. https:\/\/t.co\/hedgGcFZSV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hedgGcFZSV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORjWsAUTQkV.jpg",
        "id_str" : "1075502937101742085",
        "id" : 1075502937101742085,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORjWsAUTQkV.jpg",
        "sizes" : [ {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 846
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 479
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hedgGcFZSV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hedgGcFZSV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORmWsAYu6y5.jpg",
        "id_str" : "1075502937114324998",
        "id" : 1075502937114324998,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORmWsAYu6y5.jpg",
        "sizes" : [ {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 479
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 846
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hedgGcFZSV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hedgGcFZSV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORjWsA0jh3w.jpg",
        "id_str" : "1075502937101742093",
        "id" : 1075502937101742093,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORjWsA0jh3w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hedgGcFZSV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rimapana\/status\/1075502961114132484\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hedgGcFZSV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz0ORhWsAs_FCD.jpg",
        "id_str" : "1075502937093353483",
        "id" : 1075502937093353483,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz0ORhWsAs_FCD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1247,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1247,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hedgGcFZSV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075502961114132484",
    "text" : "24 new readers [qoruye] to serve the syriac orthodox church in damascus. \u0710\u0720\u0717\u0710 \u0721\u0712\u072A\u071F\u0323 \u0720\u0717\u0718\u0722. https:\/\/t.co\/hedgGcFZSV",
    "id" : 1075502961114132484,
    "created_at" : "2018-12-19 21:27:42 +0000",
    "user" : {
      "name" : "\u2022",
      "screen_name" : "rimapana",
      "protected" : false,
      "id_str" : "1022056945207922689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1080179314866511873\/fdfOnOo__normal.jpg",
      "id" : 1022056945207922689,
      "verified" : false
    }
  },
  "id" : 1075610054001418240,
  "created_at" : "2018-12-20 04:33:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075609601255575552",
  "text" : "RT @BTCticker: One Bitcoin now worth $3853.552. Market Cap $67.173 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075443177480511494",
    "text" : "One Bitcoin now worth $3853.552. Market Cap $67.173 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075443177480511494,
    "created_at" : "2018-12-19 17:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075609601255575552,
  "created_at" : "2018-12-20 04:31:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075609502777573376",
  "text" : "RT @BTCticker: One Bitcoin now worth $3819.15@bitstamp. High $3924.010. Low $3472.830. Market Cap $66.568 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075443176477999110",
    "text" : "One Bitcoin now worth $3819.15@bitstamp. High $3924.010. Low $3472.830. Market Cap $66.568 Billion #bitcoin",
    "id" : 1075443176477999110,
    "created_at" : "2018-12-19 17:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075609502777573376,
  "created_at" : "2018-12-20 04:31:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/VY9obwnJWF",
      "expanded_url" : "https:\/\/trib.al\/EgQhQyT",
      "display_url" : "trib.al\/EgQhQyT"
    } ]
  },
  "geo" : { },
  "id_str" : "1075609383537655810",
  "text" : "RT @epicurious: The classiest apps we\u2019ve ever seen. \nhttps:\/\/t.co\/VY9obwnJWF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/VY9obwnJWF",
        "expanded_url" : "https:\/\/trib.al\/EgQhQyT",
        "display_url" : "trib.al\/EgQhQyT"
      } ]
    },
    "geo" : { },
    "id_str" : "1075323621910999041",
    "text" : "The classiest apps we\u2019ve ever seen. \nhttps:\/\/t.co\/VY9obwnJWF",
    "id" : 1075323621910999041,
    "created_at" : "2018-12-19 09:35:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1075609383537655810,
  "created_at" : "2018-12-20 04:30:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "3511430425",
      "id" : 3511430425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075609362381582336",
  "text" : "RT @fermatslibrary: There is a sequence of digits that is not prime in any base\nProof: 121 is an example. In base-b, 121 = 1b\u00B2+2b+1 = (b+1)\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fermatslibrary\/status\/1075386551054581760\/photo\/1",
        "indices" : [ 142, 165 ],
        "url" : "https:\/\/t.co\/f3djeRqroe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DuyKXjxXgAEwMsU.jpg",
        "id_str" : "1075386548378632193",
        "id" : 1075386548378632193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuyKXjxXgAEwMsU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1147,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1676,
          "resize" : "fit",
          "w" : 2992
        }, {
          "h" : 672,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/f3djeRqroe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075386551054581760",
    "text" : "There is a sequence of digits that is not prime in any base\nProof: 121 is an example. In base-b, 121 = 1b\u00B2+2b+1 = (b+1)(b+1), thus not prime! https:\/\/t.co\/f3djeRqroe",
    "id" : 1075386551054581760,
    "created_at" : "2018-12-19 13:45:08 +0000",
    "user" : {
      "name" : "Fermat's Library",
      "screen_name" : "fermatslibrary",
      "protected" : false,
      "id_str" : "3511430425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641822497457860608\/zd6kUAag_normal.png",
      "id" : 3511430425,
      "verified" : false
    }
  },
  "id" : 1075609362381582336,
  "created_at" : "2018-12-20 04:30:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/CM6W6M4oXn",
      "expanded_url" : "https:\/\/trib.al\/0gv9xC0",
      "display_url" : "trib.al\/0gv9xC0"
    } ]
  },
  "geo" : { },
  "id_str" : "1075609266525011968",
  "text" : "RT @epicurious: Just in time for hibernation season. \nhttps:\/\/t.co\/CM6W6M4oXn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/CM6W6M4oXn",
        "expanded_url" : "https:\/\/trib.al\/0gv9xC0",
        "display_url" : "trib.al\/0gv9xC0"
      } ]
    },
    "geo" : { },
    "id_str" : "1075399376170823680",
    "text" : "Just in time for hibernation season. \nhttps:\/\/t.co\/CM6W6M4oXn",
    "id" : 1075399376170823680,
    "created_at" : "2018-12-19 14:36:05 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1075609266525011968,
  "created_at" : "2018-12-20 04:30:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Church Father",
      "screen_name" : "Church_Father",
      "indices" : [ 3, 17 ],
      "id_str" : "924761006101975042",
      "id" : 924761006101975042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075609133620097024",
  "text" : "RT @Church_Father: The glory of the sacraments is the redemption of captives. Truly they are precious vessels, for they redeem men from dea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075134357260640256",
    "text" : "The glory of the sacraments is the redemption of captives. Truly they are precious vessels, for they redeem men from death. That, indeed, is the true treasure of the Lord which effects what His blood effected. \n\nSt. Ambrose",
    "id" : 1075134357260640256,
    "created_at" : "2018-12-18 21:03:00 +0000",
    "user" : {
      "name" : "Church Father",
      "screen_name" : "Church_Father",
      "protected" : false,
      "id_str" : "924761006101975042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/924783336135913472\/mx5LJP58_normal.jpg",
      "id" : 924761006101975042,
      "verified" : false
    }
  },
  "id" : 1075609133620097024,
  "created_at" : "2018-12-20 04:29:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075609041655750656",
  "text" : "RT @BarbaraCorcoran: Cynical people use and positive people help.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075360304295538689",
    "text" : "Cynical people use and positive people help.",
    "id" : 1075360304295538689,
    "created_at" : "2018-12-19 12:00:50 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1075609041655750656,
  "created_at" : "2018-12-20 04:29:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesla",
      "screen_name" : "Tesla",
      "indices" : [ 3, 9 ],
      "id_str" : "13298072",
      "id" : 13298072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/efxsovF238",
      "expanded_url" : "https:\/\/cards.twitter.com\/cards\/7x0uw\/6nas9",
      "display_url" : "cards.twitter.com\/cards\/7x0uw\/6n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075608885942239232",
  "text" : "RT @Tesla: You can now play TeslAtari with a USB game controller\nhttps:\/\/t.co\/efxsovF238",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/efxsovF238",
        "expanded_url" : "https:\/\/cards.twitter.com\/cards\/7x0uw\/6nas9",
        "display_url" : "cards.twitter.com\/cards\/7x0uw\/6n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075551142128410624",
    "text" : "You can now play TeslAtari with a USB game controller\nhttps:\/\/t.co\/efxsovF238",
    "id" : 1075551142128410624,
    "created_at" : "2018-12-20 00:39:09 +0000",
    "user" : {
      "name" : "Tesla",
      "screen_name" : "Tesla",
      "protected" : false,
      "id_str" : "13298072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489192650474414080\/4RxZxsud_normal.png",
      "id" : 13298072,
      "verified" : true
    }
  },
  "id" : 1075608885942239232,
  "created_at" : "2018-12-20 04:28:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608794904829952",
  "text" : "RT @BTCticker: One Bitcoin now worth $3768.058. Market Cap $65.685 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075594170293764096",
    "text" : "One Bitcoin now worth $3768.058. Market Cap $65.685 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075594170293764096,
    "created_at" : "2018-12-20 03:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075608794904829952,
  "created_at" : "2018-12-20 04:28:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Aptk7mGMjT",
      "expanded_url" : "https:\/\/fstoppers.com\/news\/sony-fixes-file-loss-bug-a7r-iii-and-a7-iii-320107?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/news\/sony-fixe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075608787657154562",
  "text" : "RT @JayHoque: Sony Fixes File Loss Bug on a7R III and a7 III: https:\/\/t.co\/Aptk7mGMjT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/Aptk7mGMjT",
        "expanded_url" : "https:\/\/fstoppers.com\/news\/sony-fixes-file-loss-bug-a7r-iii-and-a7-iii-320107?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/news\/sony-fixe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075528019052322816",
    "text" : "Sony Fixes File Loss Bug on a7R III and a7 III: https:\/\/t.co\/Aptk7mGMjT",
    "id" : 1075528019052322816,
    "created_at" : "2018-12-19 23:07:16 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1075608787657154562,
  "created_at" : "2018-12-20 04:28:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "indices" : [ 3, 9 ],
      "id_str" : "4020532937",
      "id" : 4020532937
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1075580847921774593\/video\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/PgpaC5CHLg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Du0tUM8XcAAu-4E.jpg",
      "id_str" : "1075565713165860864",
      "id" : 1075565713165860864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du0tUM8XcAAu-4E.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PgpaC5CHLg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/2krzMFuQAD",
      "expanded_url" : "https:\/\/tasty.co\/recipe\/ham-and-garlic-pull-apart-garlic-bread",
      "display_url" : "tasty.co\/recipe\/ham-and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075608696787529728",
  "text" : "RT @tasty: Garlic bread like you've never had before! \nFULL RECIPE: https:\/\/t.co\/2krzMFuQAD https:\/\/t.co\/PgpaC5CHLg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/pubhub.buzzfeed.com\" rel=\"nofollow\"\u003EBF PubHub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tasty\/status\/1075580847921774593\/video\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/PgpaC5CHLg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Du0tUM8XcAAu-4E.jpg",
        "id_str" : "1075565713165860864",
        "id" : 1075565713165860864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Du0tUM8XcAAu-4E.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/PgpaC5CHLg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2krzMFuQAD",
        "expanded_url" : "https:\/\/tasty.co\/recipe\/ham-and-garlic-pull-apart-garlic-bread",
        "display_url" : "tasty.co\/recipe\/ham-and\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075580847921774593",
    "text" : "Garlic bread like you've never had before! \nFULL RECIPE: https:\/\/t.co\/2krzMFuQAD https:\/\/t.co\/PgpaC5CHLg",
    "id" : 1075580847921774593,
    "created_at" : "2018-12-20 02:37:12 +0000",
    "user" : {
      "name" : "Tasty",
      "screen_name" : "tasty",
      "protected" : false,
      "id_str" : "4020532937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887725624105738240\/enrb4x3-_normal.jpg",
      "id" : 4020532937,
      "verified" : true
    }
  },
  "id" : 1075608696787529728,
  "created_at" : "2018-12-20 04:27:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/tSUwBVF5vV",
      "expanded_url" : "https:\/\/www.lightstalking.com\/dell-shows-off-world-first-49-inch-dual-qhd-monitor\/",
      "display_url" : "lightstalking.com\/dell-shows-off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075608489056235520",
  "text" : "RT @JayHoque: Dell Shows Off World-First 49-Inch Dual QHD Monitor: https:\/\/t.co\/tSUwBVF5vV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/tSUwBVF5vV",
        "expanded_url" : "https:\/\/www.lightstalking.com\/dell-shows-off-world-first-49-inch-dual-qhd-monitor\/",
        "display_url" : "lightstalking.com\/dell-shows-off\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075531803677679616",
    "text" : "Dell Shows Off World-First 49-Inch Dual QHD Monitor: https:\/\/t.co\/tSUwBVF5vV",
    "id" : 1075531803677679616,
    "created_at" : "2018-12-19 23:22:19 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1075608489056235520,
  "created_at" : "2018-12-20 04:27:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Moore",
      "screen_name" : "TheNewsAtGlenn",
      "indices" : [ 3, 18 ],
      "id_str" : "218438862",
      "id" : 218438862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608389974151168",
  "text" : "RT @TheNewsAtGlenn: All I'm saying is, if I were a billionaire, I'd tell all my aspiring rivals that the secret to success was getting up a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074995364195917824",
    "text" : "All I'm saying is, if I were a billionaire, I'd tell all my aspiring rivals that the secret to success was getting up at 4am.",
    "id" : 1074995364195917824,
    "created_at" : "2018-12-18 11:50:41 +0000",
    "user" : {
      "name" : "Glenn Moore",
      "screen_name" : "TheNewsAtGlenn",
      "protected" : false,
      "id_str" : "218438862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493628716\/86603b3486828980976cba5be9328656_normal.png",
      "id" : 218438862,
      "verified" : false
    }
  },
  "id" : 1075608389974151168,
  "created_at" : "2018-12-20 04:26:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608337687998465",
  "text" : "RT @BTCticker: One Bitcoin now worth $3764.917. Market Cap $65.631 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075601717042077697",
    "text" : "One Bitcoin now worth $3764.917. Market Cap $65.631 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075601717042077697,
    "created_at" : "2018-12-20 04:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075608337687998465,
  "created_at" : "2018-12-20 04:26:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608235929931776",
  "text" : "RT @MikeWShell: I guess your all gonna have to go short so the stock market to go back up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075583545576472576",
    "text" : "I guess your all gonna have to go short so the stock market to go back up.",
    "id" : 1075583545576472576,
    "created_at" : "2018-12-20 02:47:55 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1075608235929931776,
  "created_at" : "2018-12-20 04:26:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Murad Mahmudov \uD83D\uDE80",
      "screen_name" : "MustStopMurad",
      "indices" : [ 3, 17 ],
      "id_str" : "844304603336232960",
      "id" : 844304603336232960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608045433094144",
  "text" : "RT @MustStopMurad: Long 3500 (this week)\nClose 4100-4400 (early Q1 2019)\nShort 4100-4400 (early Q1 2019)\nClose 2500 (Q1 2019)\nLong 2500 (la\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075540559643729920",
    "text" : "Long 3500 (this week)\nClose 4100-4400 (early Q1 2019)\nShort 4100-4400 (early Q1 2019)\nClose 2500 (Q1 2019)\nLong 2500 (late Q1 2019)\nClose ~133,000 (2023)\nShort ~120,000 w\/ confirmations\nClose ~30,000 (~2025)\nLong ~30,000\n&amp; NEVER CLOSE",
    "id" : 1075540559643729920,
    "created_at" : "2018-12-19 23:57:06 +0000",
    "user" : {
      "name" : "Murad Mahmudov \uD83D\uDE80",
      "screen_name" : "MustStopMurad",
      "protected" : false,
      "id_str" : "844304603336232960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963761323766157312\/XwE76xMk_normal.jpg",
      "id" : 844304603336232960,
      "verified" : false
    }
  },
  "id" : 1075608045433094144,
  "created_at" : "2018-12-20 04:25:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075608029406605313",
  "text" : "RT @BTCticker: One Bitcoin now worth $3718.60@bitstamp. High $3924.010. Low $3642.690. Market Cap $64.815 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075533780792807425",
    "text" : "One Bitcoin now worth $3718.60@bitstamp. High $3924.010. Low $3642.690. Market Cap $64.815 Billion #bitcoin",
    "id" : 1075533780792807425,
    "created_at" : "2018-12-19 23:30:10 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075608029406605313,
  "created_at" : "2018-12-20 04:25:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075607925387857920",
  "text" : "RT @MikeWShell: Fed Chairman Powell:  \n\n\u201CThe US economy continues to perform well and no longer needs the Fed\u2019s support either through lowe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075533419902328832",
    "text" : "Fed Chairman Powell:  \n\n\u201CThe US economy continues to perform well and no longer needs the Fed\u2019s support either through lower than normal interest rates or by maintaining a massive balance sheet\u201D.",
    "id" : 1075533419902328832,
    "created_at" : "2018-12-19 23:28:44 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1075607925387857920,
  "created_at" : "2018-12-20 04:24:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/JSgbWzvdRL",
      "expanded_url" : "https:\/\/trib.al\/wXKzM5F",
      "display_url" : "trib.al\/wXKzM5F"
    } ]
  },
  "geo" : { },
  "id_str" : "1075607881804861442",
  "text" : "RT @epicurious: It\u2019s waaay easier to cook than your guests will think. \nhttps:\/\/t.co\/JSgbWzvdRL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/JSgbWzvdRL",
        "expanded_url" : "https:\/\/trib.al\/wXKzM5F",
        "display_url" : "trib.al\/wXKzM5F"
      } ]
    },
    "geo" : { },
    "id_str" : "1075581055128739840",
    "text" : "It\u2019s waaay easier to cook than your guests will think. \nhttps:\/\/t.co\/JSgbWzvdRL",
    "id" : 1075581055128739840,
    "created_at" : "2018-12-20 02:38:01 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1075607881804861442,
  "created_at" : "2018-12-20 04:24:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075607775902924800",
  "text" : "Applying for Startup Programs for my crypto mining startup....",
  "id" : 1075607775902924800,
  "created_at" : "2018-12-20 04:24:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edgar Alvarez",
      "screen_name" : "abcdedgar",
      "indices" : [ 3, 13 ],
      "id_str" : "38753712",
      "id" : 38753712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075516516718788608",
  "text" : "RT @abcdedgar: Now more than ever, technology is shaping sneaker culture. The cat-and-mouse game Nike and Adidas are playing w\/ people who\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 256, 279 ],
        "url" : "https:\/\/t.co\/GbpfEuCheN",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/18\/nike-air-jordan-xi-concord-drop-online-bots-security",
        "display_url" : "engadget.com\/2018\/12\/18\/nik\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075099006039142400",
    "text" : "Now more than ever, technology is shaping sneaker culture. The cat-and-mouse game Nike and Adidas are playing w\/ people who create and sell bot services will fascinate anyone. Spoke to brand execs and a 20-year-old who\u2019s a big headache for them. My story: https:\/\/t.co\/GbpfEuCheN",
    "id" : 1075099006039142400,
    "created_at" : "2018-12-18 18:42:32 +0000",
    "user" : {
      "name" : "Edgar Alvarez",
      "screen_name" : "abcdedgar",
      "protected" : false,
      "id_str" : "38753712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/969978395974144001\/TlCvSd38_normal.jpg",
      "id" : 38753712,
      "verified" : true
    }
  },
  "id" : 1075516516718788608,
  "created_at" : "2018-12-19 22:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/OyBpJbDgFp",
      "expanded_url" : "http:\/\/mag.time.com\/O9iGU5o",
      "display_url" : "mag.time.com\/O9iGU5o"
    } ]
  },
  "geo" : { },
  "id_str" : "1075516272060829697",
  "text" : "RT @TIME: A Filipino boy was 'speechless' after discovering George H.W. Bush was his pen pal for years https:\/\/t.co\/OyBpJbDgFp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/OyBpJbDgFp",
        "expanded_url" : "http:\/\/mag.time.com\/O9iGU5o",
        "display_url" : "mag.time.com\/O9iGU5o"
      } ]
    },
    "geo" : { },
    "id_str" : "1075514890096443393",
    "text" : "A Filipino boy was 'speechless' after discovering George H.W. Bush was his pen pal for years https:\/\/t.co\/OyBpJbDgFp",
    "id" : 1075514890096443393,
    "created_at" : "2018-12-19 22:15:06 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 1075516272060829697,
  "created_at" : "2018-12-19 22:20:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/rLThmMHNpH",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/30-free-fonts-you-must-have\/",
      "display_url" : "webdesigndev.com\/30-free-fonts-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075515925284179971",
  "text" : "RT @WebDesignDev: 30 Free Fonts You MUST Have: https:\/\/t.co\/rLThmMHNpH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/rLThmMHNpH",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/30-free-fonts-you-must-have\/",
        "display_url" : "webdesigndev.com\/30-free-fonts-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075515788939939842",
    "text" : "30 Free Fonts You MUST Have: https:\/\/t.co\/rLThmMHNpH",
    "id" : 1075515788939939842,
    "created_at" : "2018-12-19 22:18:40 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1075515925284179971,
  "created_at" : "2018-12-19 22:19:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075515704638664704",
  "text" : "RT @TipsyBartender: Irish Lemonade - Insane lemon-lime whiskey drink!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074328295208939520",
    "text" : "Irish Lemonade - Insane lemon-lime whiskey drink!",
    "id" : 1074328295208939520,
    "created_at" : "2018-12-16 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1075515704638664704,
  "created_at" : "2018-12-19 22:18:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gtC39uBC7z",
      "expanded_url" : "http:\/\/spacex.com\/webcast",
      "display_url" : "spacex.com\/webcast"
    } ]
  },
  "geo" : { },
  "id_str" : "1075514837768200192",
  "text" : "RT @SpaceX: T-30 minutes until Falcon 9 launch of GPS III SV01. Launch webcast will go live in about 15 minutes \u2192 https:\/\/t.co\/gtC39uBC7z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/gtC39uBC7z",
        "expanded_url" : "http:\/\/spacex.com\/webcast",
        "display_url" : "spacex.com\/webcast"
      } ]
    },
    "geo" : { },
    "id_str" : "1075029153240408064",
    "text" : "T-30 minutes until Falcon 9 launch of GPS III SV01. Launch webcast will go live in about 15 minutes \u2192 https:\/\/t.co\/gtC39uBC7z",
    "id" : 1075029153240408064,
    "created_at" : "2018-12-18 14:04:57 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1075514837768200192,
  "created_at" : "2018-12-19 22:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food52",
      "screen_name" : "Food52",
      "indices" : [ 3, 10 ],
      "id_str" : "21769127",
      "id" : 21769127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/l7ljQmL1Hb",
      "expanded_url" : "https:\/\/f52.co\/2PLdZaY",
      "display_url" : "f52.co\/2PLdZaY"
    } ]
  },
  "geo" : { },
  "id_str" : "1075514442350252032",
  "text" : "RT @Food52: Ohhh, Ina. \uD83D\uDC95 https:\/\/t.co\/l7ljQmL1Hb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/l7ljQmL1Hb",
        "expanded_url" : "https:\/\/f52.co\/2PLdZaY",
        "display_url" : "f52.co\/2PLdZaY"
      } ]
    },
    "geo" : { },
    "id_str" : "1075229735775539201",
    "text" : "Ohhh, Ina. \uD83D\uDC95 https:\/\/t.co\/l7ljQmL1Hb",
    "id" : 1075229735775539201,
    "created_at" : "2018-12-19 03:22:00 +0000",
    "user" : {
      "name" : "Food52",
      "screen_name" : "Food52",
      "protected" : false,
      "id_str" : "21769127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729725723565395971\/3eWxWjEe_normal.jpg",
      "id" : 21769127,
      "verified" : true
    }
  },
  "id" : 1075514442350252032,
  "created_at" : "2018-12-19 22:13:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/a53R1PohSx",
      "expanded_url" : "https:\/\/adafru.it\/DmV",
      "display_url" : "adafru.it\/DmV"
    } ]
  },
  "geo" : { },
  "id_str" : "1075514421034786821",
  "text" : "RT @adafruit: NEW PRODUCT \u2013 Mini Soft Touch Push-button Switches (6mm square) x 10 pack https:\/\/t.co\/a53R1PohSx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/a53R1PohSx",
        "expanded_url" : "https:\/\/adafru.it\/DmV",
        "display_url" : "adafru.it\/DmV"
      } ]
    },
    "geo" : { },
    "id_str" : "1075511206037852161",
    "text" : "NEW PRODUCT \u2013 Mini Soft Touch Push-button Switches (6mm square) x 10 pack https:\/\/t.co\/a53R1PohSx",
    "id" : 1075511206037852161,
    "created_at" : "2018-12-19 22:00:28 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1075514421034786821,
  "created_at" : "2018-12-19 22:13:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075513160109559813",
  "text" : "RT @BTCticker: One Bitcoin now worth $3704.308. Market Cap $64.573 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075511125700165632",
    "text" : "One Bitcoin now worth $3704.308. Market Cap $64.573 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075511125700165632,
    "created_at" : "2018-12-19 22:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075513160109559813,
  "created_at" : "2018-12-19 22:08:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075510797143547905",
  "text" : "RT @elonmusk: Join our underground movement!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075509421260697602",
    "text" : "Join our underground movement!",
    "id" : 1075509421260697602,
    "created_at" : "2018-12-19 21:53:22 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1075510797143547905,
  "created_at" : "2018-12-19 21:58:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1075510710900269057\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/C0KH3NzvpJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Duz7SaCWkAEJQkZ.jpg",
      "id_str" : "1075510704680112129",
      "id" : 1075510704680112129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Duz7SaCWkAEJQkZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/C0KH3NzvpJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/SdnWpifXmx",
      "expanded_url" : "https:\/\/www.udemy.com\/ohsa-course\/",
      "display_url" : "udemy.com\/ohsa-course\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075510710900269057",
  "text" : "It is happening :) https:\/\/t.co\/SdnWpifXmx https:\/\/t.co\/C0KH3NzvpJ",
  "id" : 1075510710900269057,
  "created_at" : "2018-12-19 21:58:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/SdnWpifXmx",
      "expanded_url" : "https:\/\/www.udemy.com\/ohsa-course\/",
      "display_url" : "udemy.com\/ohsa-course\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075510633716740101",
  "text" : "https:\/\/t.co\/SdnWpifXmx",
  "id" : 1075510633716740101,
  "created_at" : "2018-12-19 21:58:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/1bhIula2IH",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/922245921914064896",
      "display_url" : "minds.com\/newsfeed\/92224\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075510303755026435",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/1bhIula2IH",
  "id" : 1075510303755026435,
  "created_at" : "2018-12-19 21:56:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guild of Makers",
      "screen_name" : "GuildOfMakers",
      "indices" : [ 3, 17 ],
      "id_str" : "867488150633013250",
      "id" : 867488150633013250
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakersHour",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075484181059330050",
  "text" : "RT @GuildOfMakers: Q1 Hello! Say hi, and tell us what you\u2019ve been up to this week! #MakersHour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakersHour",
        "indices" : [ 64, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075480893995802624",
    "text" : "Q1 Hello! Say hi, and tell us what you\u2019ve been up to this week! #MakersHour",
    "id" : 1075480893995802624,
    "created_at" : "2018-12-19 20:00:01 +0000",
    "user" : {
      "name" : "Guild of Makers",
      "screen_name" : "GuildOfMakers",
      "protected" : false,
      "id_str" : "867488150633013250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1049932675203694592\/vZVDJpUC_normal.jpg",
      "id" : 867488150633013250,
      "verified" : false
    }
  },
  "id" : 1075484181059330050,
  "created_at" : "2018-12-19 20:13:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075483803303456769",
  "text" : "RT @SpaceX: SpaceX team called a hold due to an out of family reading on first stage sensors. Vehicle and payload remain healthy; next laun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075037745633001472",
    "text" : "SpaceX team called a hold due to an out of family reading on first stage sensors. Vehicle and payload remain healthy; next launch attempt is tomorrow at 9:07 EST, 14:07 UTC.",
    "id" : 1075037745633001472,
    "created_at" : "2018-12-18 14:39:06 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1075483803303456769,
  "created_at" : "2018-12-19 20:11:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075483783221141504",
  "text" : "RT @SpaceX: Standing down from today\u2019s launch attempt of GPS III SV01 to further evaluate out of family reading on first stage sensors; wil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075353149219717120",
    "text" : "Standing down from today\u2019s launch attempt of GPS III SV01 to further evaluate out of family reading on first stage sensors; will confirm a new launch date once complete.",
    "id" : 1075353149219717120,
    "created_at" : "2018-12-19 11:32:24 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1075483783221141504,
  "created_at" : "2018-12-19 20:11:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/1063824485621645312\/video\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/y24AaicGRy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DsOD5E-U0AAFb2g.jpg",
      "id_str" : "1063824113251307520",
      "id" : 1063824113251307520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DsOD5E-U0AAFb2g.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/y24AaicGRy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075483754670514176",
  "text" : "RT @NASA: We're returning to the Moon, preparing to go beyond to Mars. We are going. We are NASA. https:\/\/t.co\/y24AaicGRy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/1063824485621645312\/video\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/y24AaicGRy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DsOD5E-U0AAFb2g.jpg",
        "id_str" : "1063824113251307520",
        "id" : 1063824113251307520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DsOD5E-U0AAFb2g.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/y24AaicGRy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1063824485621645312",
    "text" : "We're returning to the Moon, preparing to go beyond to Mars. We are going. We are NASA. https:\/\/t.co\/y24AaicGRy",
    "id" : 1063824485621645312,
    "created_at" : "2018-11-17 16:01:36 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 1075483754670514176,
  "created_at" : "2018-12-19 20:11:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075482858028969984",
  "text" : "RT @BTCticker: One Bitcoin now worth $3807.100. Market Cap $66.364 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075480920210268161",
    "text" : "One Bitcoin now worth $3807.100. Market Cap $66.364 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075480920210268161,
    "created_at" : "2018-12-19 20:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075482858028969984,
  "created_at" : "2018-12-19 20:07:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1075482760599531522\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/cGaLiwm8St",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuzhyetW4AEufwK.jpg",
      "id_str" : "1075482668387721217",
      "id" : 1075482668387721217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuzhyetW4AEufwK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/cGaLiwm8St"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/so7xO712hm",
      "expanded_url" : "https:\/\/www.udemy.com\/rocket-safety\/",
      "display_url" : "udemy.com\/rocket-safety\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075482760599531522",
  "text" : "I really enjoyed making these practice tests :) https:\/\/t.co\/so7xO712hm https:\/\/t.co\/cGaLiwm8St",
  "id" : 1075482760599531522,
  "created_at" : "2018-12-19 20:07:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/so7xO712hm",
      "expanded_url" : "https:\/\/www.udemy.com\/rocket-safety\/",
      "display_url" : "udemy.com\/rocket-safety\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075482531481485313",
  "text" : "Yes, you guessed it: https:\/\/t.co\/so7xO712hm",
  "id" : 1075482531481485313,
  "created_at" : "2018-12-19 20:06:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/rfGxWIYyWS",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/922217790153998336",
      "display_url" : "minds.com\/newsfeed\/92221\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075482048616456192",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/rfGxWIYyWS",
  "id" : 1075482048616456192,
  "created_at" : "2018-12-19 20:04:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/VN79M1Hjbg",
      "expanded_url" : "https:\/\/wpbeg.in\/2KdLnEn",
      "display_url" : "wpbeg.in\/2KdLnEn"
    } ]
  },
  "geo" : { },
  "id_str" : "1075472478091309058",
  "text" : "RT @wpbeginner: How to Rename the Uncategorized Category in #WordPress - https:\/\/t.co\/VN79M1Hjbg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 44, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/VN79M1Hjbg",
        "expanded_url" : "https:\/\/wpbeg.in\/2KdLnEn",
        "display_url" : "wpbeg.in\/2KdLnEn"
      } ]
    },
    "geo" : { },
    "id_str" : "1075182174352146432",
    "text" : "How to Rename the Uncategorized Category in #WordPress - https:\/\/t.co\/VN79M1Hjbg",
    "id" : 1075182174352146432,
    "created_at" : "2018-12-19 00:13:00 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 1075472478091309058,
  "created_at" : "2018-12-19 19:26:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shell Capital \u2014 ASYMMETRY\u00AE",
      "screen_name" : "ShellCapital",
      "indices" : [ 3, 16 ],
      "id_str" : "923564411142443019",
      "id" : 923564411142443019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472418301460482",
  "text" : "RT @ShellCapital: If the stock market volatility and correction develops into a full bear market, the asset allocations that are fully expo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 189, 212 ],
        "url" : "https:\/\/t.co\/xfSM7Uiu5x",
        "expanded_url" : "https:\/\/asymmetryobservations.com\/2018\/12\/18\/global-asset-allocation-takes-a-beating-in-2018\/",
        "display_url" : "asymmetryobservations.com\/2018\/12\/18\/glo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075375706476085248",
    "text" : "If the stock market volatility and correction develops into a full bear market, the asset allocations that are fully exposed to downside risk will test investors' tolerance for drawdowns.\n\nhttps:\/\/t.co\/xfSM7Uiu5x",
    "id" : 1075375706476085248,
    "created_at" : "2018-12-19 13:02:02 +0000",
    "user" : {
      "name" : "Shell Capital \u2014 ASYMMETRY\u00AE",
      "screen_name" : "ShellCapital",
      "protected" : false,
      "id_str" : "923564411142443019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/998551055234301953\/6v6Ib_7X_normal.jpg",
      "id" : 923564411142443019,
      "verified" : false
    }
  },
  "id" : 1075472418301460482,
  "created_at" : "2018-12-19 19:26:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472275716169729",
  "text" : "RT @BTCticker: One Bitcoin now worth $3825.675. Market Cap $66.687 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075458281232052224",
    "text" : "One Bitcoin now worth $3825.675. Market Cap $66.687 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075458281232052224,
    "created_at" : "2018-12-19 18:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075472275716169729,
  "created_at" : "2018-12-19 19:25:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472165695148032",
  "text" : "RT @BTCticker: One Bitcoin now worth $3831.327. Market Cap $66.786 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075465824733937665",
    "text" : "One Bitcoin now worth $3831.327. Market Cap $66.786 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075465824733937665,
    "created_at" : "2018-12-19 19:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075472165695148032,
  "created_at" : "2018-12-19 19:25:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472054479130626",
  "text" : "RT @elonmusk: A variety of vehicles, like normal roads, from a small car to a densely seated bus. Must be seated &amp; belted for high speed sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1075468125221441536",
    "geo" : { },
    "id_str" : "1075469603503915008",
    "in_reply_to_user_id" : 44196397,
    "text" : "A variety of vehicles, like normal roads, from a small car to a densely seated bus. Must be seated &amp; belted for high speed safety.",
    "id" : 1075469603503915008,
    "in_reply_to_status_id" : 1075468125221441536,
    "created_at" : "2018-12-19 19:15:09 +0000",
    "in_reply_to_screen_name" : "elonmusk",
    "in_reply_to_user_id_str" : "44196397",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1075472054479130626,
  "created_at" : "2018-12-19 19:24:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "The Boring Company",
      "screen_name" : "boringcompany",
      "indices" : [ 28, 42 ],
      "id_str" : "859816394556284929",
      "id" : 859816394556284929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472039929135104",
  "text" : "RT @elonmusk: Next step for @BoringCompany Loop is demonstrating high throughput at high speed. Target is 4000 vehicles\/hour at 155mph (250\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Boring Company",
        "screen_name" : "boringcompany",
        "indices" : [ 14, 28 ],
        "id_str" : "859816394556284929",
        "id" : 859816394556284929
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075468125221441536",
    "text" : "Next step for @BoringCompany Loop is demonstrating high throughput at high speed. Target is 4000 vehicles\/hour at 155mph (250km\/h).",
    "id" : 1075468125221441536,
    "created_at" : "2018-12-19 19:09:16 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1075472039929135104,
  "created_at" : "2018-12-19 19:24:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472022686351361",
  "text" : "RT @TheSharkDaymond: Success is not money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075448689102110723",
    "text" : "Success is not money.",
    "id" : 1075448689102110723,
    "created_at" : "2018-12-19 17:52:03 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1075472022686351361,
  "created_at" : "2018-12-19 19:24:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "random:",
      "screen_name" : "randomwrld",
      "indices" : [ 3, 14 ],
      "id_str" : "954897457770582016",
      "id" : 954897457770582016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075472013152739329",
  "text" : "RT @randomwrld: \u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\u2800\u2800             \n      T R U S T   G O D ' S   P L A N\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialjukebox.com\" rel=\"nofollow\"\u003EThe Social Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075259517200449538",
    "text" : "\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\u2800\u2800             \n      T R U S T   G O D ' S   P L A N\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800\n\u2800",
    "id" : 1075259517200449538,
    "created_at" : "2018-12-19 05:20:20 +0000",
    "user" : {
      "name" : "RANDOM! \uD83E\uDD73\uD83E\uDD2F\uD83E\uDD2C\uD83E\uDD76\uD83E\uDD2E\uD83D\uDE08\uD83E\uDD13\uD83C\uDF0E",
      "screen_name" : "randomwrld",
      "protected" : false,
      "id_str" : "954897457770582016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1080173935390584832\/w64yNPEE_normal.jpg",
      "id" : 954897457770582016,
      "verified" : false
    }
  },
  "id" : 1075472013152739329,
  "created_at" : "2018-12-19 19:24:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1075471818981601281\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/73BpJfDhH8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuzX5dEXQAIhwYW.jpg",
      "id_str" : "1075471793090150402",
      "id" : 1075471793090150402,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuzX5dEXQAIhwYW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/73BpJfDhH8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/3RP29RxZMK",
      "expanded_url" : "https:\/\/www.udemy.com\/trading-terms\/",
      "display_url" : "udemy.com\/trading-terms\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075471818981601281",
  "text" : "Another new Udemy course: https:\/\/t.co\/3RP29RxZMK https:\/\/t.co\/73BpJfDhH8",
  "id" : 1075471818981601281,
  "created_at" : "2018-12-19 19:23:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/3RP29RxZMK",
      "expanded_url" : "https:\/\/www.udemy.com\/trading-terms\/",
      "display_url" : "udemy.com\/trading-terms\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1075471690308706304",
  "text" : "https:\/\/t.co\/3RP29RxZMK",
  "id" : 1075471690308706304,
  "created_at" : "2018-12-19 19:23:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/WK4CKwinc9",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/922206574710931456",
      "display_url" : "minds.com\/newsfeed\/92220\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075471281133367297",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/WK4CKwinc9",
  "id" : 1075471281133367297,
  "created_at" : "2018-12-19 19:21:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/wCQaweXDFN",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/18\/boring-company-test-tunnel-opening-LA\/",
      "display_url" : "engadget.com\/2018\/12\/18\/bor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075251528435425280",
  "text" : "RT @engadget: Elon Musk's LA tunnel turns Teslas into a 'rail-guided train' https:\/\/t.co\/wCQaweXDFN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/wCQaweXDFN",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/18\/boring-company-test-tunnel-opening-LA\/",
        "display_url" : "engadget.com\/2018\/12\/18\/bor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075247120473575424",
    "text" : "Elon Musk's LA tunnel turns Teslas into a 'rail-guided train' https:\/\/t.co\/wCQaweXDFN",
    "id" : 1075247120473575424,
    "created_at" : "2018-12-19 04:31:05 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1075251528435425280,
  "created_at" : "2018-12-19 04:48:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075251482050609152",
  "text" : "RT @BTCticker: One Bitcoin now worth $3779.485. Market Cap $65.878 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075246877946339328",
    "text" : "One Bitcoin now worth $3779.485. Market Cap $65.878 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1075246877946339328,
    "created_at" : "2018-12-19 04:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1075251482050609152,
  "created_at" : "2018-12-19 04:48:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ibbFXiS4Zv",
      "expanded_url" : "https:\/\/fstoppers.com\/gear\/long-overdue-canon-7d-mark-iii-arriving-early-2019-319048?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/gear\/long-over\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075251379596349440",
  "text" : "RT @JayHoque: Is the Long Overdue Canon 7D Mark III Arriving in Early 2019?: https:\/\/t.co\/ibbFXiS4Zv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/ibbFXiS4Zv",
        "expanded_url" : "https:\/\/fstoppers.com\/gear\/long-overdue-canon-7d-mark-iii-arriving-early-2019-319048?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/gear\/long-over\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075065777554886661",
    "text" : "Is the Long Overdue Canon 7D Mark III Arriving in Early 2019?: https:\/\/t.co\/ibbFXiS4Zv",
    "id" : 1075065777554886661,
    "created_at" : "2018-12-18 16:30:29 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1075251379596349440,
  "created_at" : "2018-12-19 04:48:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075251352455000065",
  "text" : "RT @TipsyBartender: Chocolate Almond Butter Milkshake - this is what buttery angels drink \uD83D\uDC7C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075027910812200960",
    "text" : "Chocolate Almond Butter Milkshake - this is what buttery angels drink \uD83D\uDC7C",
    "id" : 1075027910812200960,
    "created_at" : "2018-12-18 14:00:01 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1075251352455000065,
  "created_at" : "2018-12-19 04:47:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075251321597501440",
  "text" : "RT @MikeWShell: The stock market now has a binary outcome. It either trends up to a new high in the months ahead, or it loses the upward mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 255, 278 ],
        "url" : "https:\/\/t.co\/BaQVtkMQMC",
        "expanded_url" : "https:\/\/asymmetryobservations.com\/2018\/12\/17\/whats-going-to-happen-next-for-the-stock-market\/",
        "display_url" : "asymmetryobservations.com\/2018\/12\/17\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075024156679438336",
    "text" : "The stock market now has a binary outcome. It either trends up to a new high in the months ahead, or it loses the upward momentum and falls into a bear market. It's why the $VIX is elevated: the market expects a wide range of outcome, one way or another\n\nhttps:\/\/t.co\/BaQVtkMQMC",
    "id" : 1075024156679438336,
    "created_at" : "2018-12-18 13:45:06 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1075251321597501440,
  "created_at" : "2018-12-19 04:47:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/y0rstty00u",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/921980269861146624",
      "display_url" : "minds.com\/newsfeed\/92198\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075251148259516421",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/y0rstty00u",
  "id" : 1075251148259516421,
  "created_at" : "2018-12-19 04:47:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/RXrugjRd87",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/921986692384284672",
      "display_url" : "minds.com\/newsfeed\/92198\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075251033327222786",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/RXrugjRd87",
  "id" : 1075251033327222786,
  "created_at" : "2018-12-19 04:46:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.squarespace.com\" rel=\"nofollow\"\u003ESquarespace\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/5MDY4qumrC",
      "expanded_url" : "https:\/\/www.digitalcpr.net\/blog\/2018\/12\/18\/innovation-at-its-best",
      "display_url" : "digitalcpr.net\/blog\/2018\/12\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7207559, -74.00076130000002 ]
  },
  "id_str" : "1075250482984177664",
  "text" : "Innovation at its Best  https:\/\/t.co\/5MDY4qumrC",
  "id" : 1075250482984177664,
  "created_at" : "2018-12-19 04:44:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075245054581706752",
  "text" : "RT @MikeWShell: Index funds and ETFs are cheap because they simply provide exposure to market risks and rewards. They provide this exposure\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 248, 271 ],
        "url" : "https:\/\/t.co\/p5nEEAfC7m",
        "expanded_url" : "https:\/\/asymmetryobservations.com\/2018\/12\/18\/global-asset-allocation-takes-a-beating-in-2018\/",
        "display_url" : "asymmetryobservations.com\/2018\/12\/18\/glo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075209144557363200",
    "text" : "Index funds and ETFs are cheap because they simply provide exposure to market risks and rewards. They provide this exposure all the time, so when markets fall as they do in a bear market, they lose value and have no stop loss for risk management.\n\nhttps:\/\/t.co\/p5nEEAfC7m",
    "id" : 1075209144557363200,
    "created_at" : "2018-12-19 02:00:11 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1075245054581706752,
  "created_at" : "2018-12-19 04:22:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/b9958ELEs3",
      "expanded_url" : "https:\/\/trib.al\/vVWhppE",
      "display_url" : "trib.al\/vVWhppE"
    } ]
  },
  "geo" : { },
  "id_str" : "1075244955436793856",
  "text" : "RT @epicurious: From ricotta toasts and polenta bites to pasta e fagioli and sea bream crudo.\nhttps:\/\/t.co\/b9958ELEs3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/b9958ELEs3",
        "expanded_url" : "https:\/\/trib.al\/vVWhppE",
        "display_url" : "trib.al\/vVWhppE"
      } ]
    },
    "geo" : { },
    "id_str" : "1075202571667734528",
    "text" : "From ricotta toasts and polenta bites to pasta e fagioli and sea bream crudo.\nhttps:\/\/t.co\/b9958ELEs3",
    "id" : 1075202571667734528,
    "created_at" : "2018-12-19 01:34:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1075244955436793856,
  "created_at" : "2018-12-19 04:22:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075244873333293056",
  "text" : "RT @TheSharkDaymond: Success doesn't happen overnight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1075146436340269056",
    "text" : "Success doesn't happen overnight.",
    "id" : 1075146436340269056,
    "created_at" : "2018-12-18 21:51:00 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1075244873333293056,
  "created_at" : "2018-12-19 04:22:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LoneroLNR",
      "screen_name" : "LoneroLNR",
      "indices" : [ 3, 13 ],
      "id_str" : "1012394583836233733",
      "id" : 1012394583836233733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/14XpktuSxe",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/oM6OU0OlfN",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/921980269861146624",
      "display_url" : "minds.com\/newsfeed\/92198\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075244867943583744",
  "text" : "RT @LoneroLNR: Shared via https:\/\/t.co\/14XpktuSxe https:\/\/t.co\/oM6OU0OlfN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/14XpktuSxe",
        "expanded_url" : "http:\/\/Minds.com",
        "display_url" : "Minds.com"
      }, {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/oM6OU0OlfN",
        "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/921980269861146624",
        "display_url" : "minds.com\/newsfeed\/92198\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1075244608202948608",
    "text" : "Shared via https:\/\/t.co\/14XpktuSxe https:\/\/t.co\/oM6OU0OlfN",
    "id" : 1075244608202948608,
    "created_at" : "2018-12-19 04:21:06 +0000",
    "user" : {
      "name" : "LoneroLNR",
      "screen_name" : "LoneroLNR",
      "protected" : false,
      "id_str" : "1012394583836233733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1012397398914629633\/S4IE_5lz_normal.jpg",
      "id" : 1012394583836233733,
      "verified" : false
    }
  },
  "id" : 1075244867943583744,
  "created_at" : "2018-12-19 04:22:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instafood",
      "indices" : [ 26, 36 ]
    }, {
      "text" : "pizza",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "foodie",
      "indices" : [ 44, 51 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/PLlGJJjwFh",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bri55O3F7UK\/?utm_source=ig_twitter_share&igshid=1u8xkwom5kho",
      "display_url" : "instagram.com\/p\/Bri55O3F7UK\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1075155336250695680",
  "text" : "A picture says 1000 words #instafood #pizza #foodie #foodpics https:\/\/t.co\/PLlGJJjwFh",
  "id" : 1075155336250695680,
  "created_at" : "2018-12-18 22:26:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074889870114463745",
  "text" : "RT @TheSharkDaymond: Two full weeks left in 2018. Make them count.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074496542948712449",
    "text" : "Two full weeks left in 2018. Make them count.",
    "id" : 1074496542948712449,
    "created_at" : "2018-12-17 02:48:33 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1074889870114463745,
  "created_at" : "2018-12-18 04:51:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074889589343612929",
  "text" : "RT @TipsyBartender: Paloma Mimosa - Mimooooooosa time!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074690683586236416",
    "text" : "Paloma Mimosa - Mimooooooosa time!",
    "id" : 1074690683586236416,
    "created_at" : "2018-12-17 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1074889589343612929,
  "created_at" : "2018-12-18 04:50:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/0jdK92z6Jf",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/free-css-buttons-icons\/",
      "display_url" : "webdesigndev.com\/free-css-butto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074889425237262336",
  "text" : "RT @WebDesignDev: 20 Awesome and Free CSS Buttons and Icons: https:\/\/t.co\/0jdK92z6Jf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/0jdK92z6Jf",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/free-css-buttons-icons\/",
        "display_url" : "webdesigndev.com\/free-css-butto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074886511034859521",
    "text" : "20 Awesome and Free CSS Buttons and Icons: https:\/\/t.co\/0jdK92z6Jf",
    "id" : 1074886511034859521,
    "created_at" : "2018-12-18 04:38:09 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1074889425237262336,
  "created_at" : "2018-12-18 04:49:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "indices" : [ 3, 18 ],
      "id_str" : "1626294277",
      "id" : 1626294277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074889242395009029",
  "text" : "RT @spectatorindex: Monthly minimum wage, 2016.\n\nLuxembourg: \u20AC1922\nBelgium: \u20AC1501\nNetherlands: \u20AC1501\nIreland: \u20AC1461\nFrance: \u20AC1457\nGermany:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074657968950525953",
    "text" : "Monthly minimum wage, 2016.\n\nLuxembourg: \u20AC1922\nBelgium: \u20AC1501\nNetherlands: \u20AC1501\nIreland: \u20AC1461\nFrance: \u20AC1457\nGermany: \u20AC1440\nUK: \u20AC1378\nSlovenia: \u20AC790\nSpain: \u20AC756\nMalta: \u20AC720\nGreece: \u20AC683\nPortugal: \u20AC589\nTurkey: \u20AC424\nPoland: \u20AC409\nHungary: \u20AC332\nAlbania: \u20AC159",
    "id" : 1074657968950525953,
    "created_at" : "2018-12-17 13:30:00 +0000",
    "user" : {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "protected" : false,
      "id_str" : "1626294277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839067030904922112\/LH4xqz-d_normal.jpg",
      "id" : 1626294277,
      "verified" : false
    }
  },
  "id" : 1074889242395009029,
  "created_at" : "2018-12-18 04:49:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "indices" : [ 3, 12 ],
      "id_str" : "295330659",
      "id" : 295330659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "palladiumprice",
      "indices" : [ 19, 34 ]
    }, {
      "text" : "Palladium",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8LELlwkVBi",
      "expanded_url" : "https:\/\/www.ausecure.com\/chartHistory\/XPD\/USD\/?end=2018-12-18T04%3A48%3A02%2B0000&cache-refresh=1",
      "display_url" : "ausecure.com\/chartHistory\/X\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074889218911027201",
  "text" : "RT @ausecure: Live #palladiumprice for spot #Palladium trading $1266.3 USD, higher by +$6 or 0.47% on the day - https:\/\/t.co\/8LELlwkVBi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.ausecure.com\/\" rel=\"nofollow\"\u003EAusecure.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "palladiumprice",
        "indices" : [ 5, 20 ]
      }, {
        "text" : "Palladium",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/8LELlwkVBi",
        "expanded_url" : "https:\/\/www.ausecure.com\/chartHistory\/XPD\/USD\/?end=2018-12-18T04%3A48%3A02%2B0000&cache-refresh=1",
        "display_url" : "ausecure.com\/chartHistory\/X\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074889000673009664",
    "text" : "Live #palladiumprice for spot #Palladium trading $1266.3 USD, higher by +$6 or 0.47% on the day - https:\/\/t.co\/8LELlwkVBi",
    "id" : 1074889000673009664,
    "created_at" : "2018-12-18 04:48:02 +0000",
    "user" : {
      "name" : "Ausecure",
      "screen_name" : "ausecure",
      "protected" : false,
      "id_str" : "295330659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666744791594504194\/hyfLTdkg_normal.jpg",
      "id" : 295330659,
      "verified" : false
    }
  },
  "id" : 1074889218911027201,
  "created_at" : "2018-12-18 04:48:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/y0sU6c9pVo",
      "expanded_url" : "http:\/\/github.com\/mentors4edu",
      "display_url" : "github.com\/mentors4edu"
    }, {
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/nozZFCvh87",
      "expanded_url" : "http:\/\/bit.ly\/box-chat",
      "display_url" : "bit.ly\/box-chat"
    } ]
  },
  "geo" : { },
  "id_str" : "1074889070780792832",
  "text" : "Been active on GitHub a bit, also working on a new thing... (Well just need to find the time)... https:\/\/t.co\/y0sU6c9pVo &amp; https:\/\/t.co\/nozZFCvh87",
  "id" : 1074889070780792832,
  "created_at" : "2018-12-18 04:48:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074388023717040129",
  "text" : "RT @BarbaraCorcoran: I think we are all able to build a world we want to live in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074348730378305537",
    "text" : "I think we are all able to build a world we want to live in.",
    "id" : 1074348730378305537,
    "created_at" : "2018-12-16 17:01:12 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1074388023717040129,
  "created_at" : "2018-12-16 19:37:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/FvzZbxdaZD",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/09\/how-to-reheat-old-bagels.html",
      "display_url" : "seriouseats.com\/2015\/09\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074388000908423168",
  "text" : "RT @seriouseats: Or, how to save old bagels.\nhttps:\/\/t.co\/FvzZbxdaZD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/FvzZbxdaZD",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/09\/how-to-reheat-old-bagels.html",
        "display_url" : "seriouseats.com\/2015\/09\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074378635824398336",
    "text" : "Or, how to save old bagels.\nhttps:\/\/t.co\/FvzZbxdaZD",
    "id" : 1074378635824398336,
    "created_at" : "2018-12-16 19:00:02 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1074388000908423168,
  "created_at" : "2018-12-16 19:37:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074387978280202240",
  "text" : "RT @BTCticker: One Bitcoin now worth $3270.805. Market Cap $56.998 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074386213367373824",
    "text" : "One Bitcoin now worth $3270.805. Market Cap $56.998 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1074386213367373824,
    "created_at" : "2018-12-16 19:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074387978280202240,
  "created_at" : "2018-12-16 19:37:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "indices" : [ 3, 19 ],
      "id_str" : "29856819",
      "id" : 29856819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "richdad",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074183153508593664",
  "text" : "RT @theRealKiyosaki: Take care of your teams because ultimately it is they, not you, who will enable you to achieve success. #richdad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "richdad",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074140809836908544",
    "text" : "Take care of your teams because ultimately it is they, not you, who will enable you to achieve success. #richdad",
    "id" : 1074140809836908544,
    "created_at" : "2018-12-16 03:15:00 +0000",
    "user" : {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "protected" : false,
      "id_str" : "29856819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472421066007015424\/MHUJj15g_normal.jpeg",
      "id" : 29856819,
      "verified" : true
    }
  },
  "id" : 1074183153508593664,
  "created_at" : "2018-12-16 06:03:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/AwGRWPjBt7",
      "expanded_url" : "https:\/\/wpbeg.in\/2NZFa1g",
      "display_url" : "wpbeg.in\/2NZFa1g"
    } ]
  },
  "geo" : { },
  "id_str" : "1074183033681530880",
  "text" : "RT @wpbeginner: How to Create a Custom User Registration Form in #WordPress - https:\/\/t.co\/AwGRWPjBt7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/AwGRWPjBt7",
        "expanded_url" : "https:\/\/wpbeg.in\/2NZFa1g",
        "display_url" : "wpbeg.in\/2NZFa1g"
      } ]
    },
    "geo" : { },
    "id_str" : "1074144607074689024",
    "text" : "How to Create a Custom User Registration Form in #WordPress - https:\/\/t.co\/AwGRWPjBt7",
    "id" : 1074144607074689024,
    "created_at" : "2018-12-16 03:30:05 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 1074183033681530880,
  "created_at" : "2018-12-16 06:02:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "indices" : [ 3, 7 ],
      "id_str" : "16896485",
      "id" : 16896485
    }, {
      "name" : "Marcel Schwantes",
      "screen_name" : "MarcelSchwantes",
      "indices" : [ 105, 121 ],
      "id_str" : "77102803",
      "id" : 77102803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074182975925952512",
  "text" : "RT @Inc: Steve Jobs Said This 1 Simple Leadership Habit Separates the Successful Ones From Everyone Else @MarcelSchwantes https:\/\/t.co\/lsng\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcel Schwantes",
        "screen_name" : "MarcelSchwantes",
        "indices" : [ 96, 112 ],
        "id_str" : "77102803",
        "id" : 77102803
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/lsngo0vv0s",
        "expanded_url" : "http:\/\/on.inc.com\/ISupEKL",
        "display_url" : "on.inc.com\/ISupEKL"
      } ]
    },
    "geo" : { },
    "id_str" : "1074176228192591872",
    "text" : "Steve Jobs Said This 1 Simple Leadership Habit Separates the Successful Ones From Everyone Else @MarcelSchwantes https:\/\/t.co\/lsngo0vv0s",
    "id" : 1074176228192591872,
    "created_at" : "2018-12-16 05:35:44 +0000",
    "user" : {
      "name" : "Inc.",
      "screen_name" : "Inc",
      "protected" : false,
      "id_str" : "16896485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794517026672967680\/M4bp9e6f_normal.jpg",
      "id" : 16896485,
      "verified" : true
    }
  },
  "id" : 1074182975925952512,
  "created_at" : "2018-12-16 06:02:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074182523859668994",
  "text" : "RT @sparkfun: The mad genius responsible for some of our favorite projects (fire-breathing vacuums, an organ made of Furbies, the SynthBike\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LOOK MUM NO COMPUTER",
        "screen_name" : "LOOKMUMNOCMPUTR",
        "indices" : [ 192, 208 ],
        "id_str" : "45370849",
        "id" : 45370849
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gameboy",
        "indices" : [ 171, 179 ]
      }, {
        "text" : "synth",
        "indices" : [ 180, 186 ]
      } ],
      "urls" : [ {
        "indices" : [ 209, 232 ],
        "url" : "https:\/\/t.co\/pweq53MH19",
        "expanded_url" : "http:\/\/bit.ly\/2zJrpPD",
        "display_url" : "bit.ly\/2zJrpPD"
      } ]
    },
    "geo" : { },
    "id_str" : "1072235002124034048",
    "text" : "The mad genius responsible for some of our favorite projects (fire-breathing vacuums, an organ made of Furbies, the SynthBike, oh my) is back...with a massive, 48-console #Gameboy #synth rig. @LOOKMUMNOCMPUTR https:\/\/t.co\/pweq53MH19",
    "id" : 1072235002124034048,
    "created_at" : "2018-12-10 21:02:00 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 1074182523859668994,
  "created_at" : "2018-12-16 06:00:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074182325779480577",
  "text" : "RT @instructables: Would you attempt building your own bandsaw? Check out this Instructable for the full process and tips. https:\/\/t.co\/LLQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/LLQ3yc8TBc",
        "expanded_url" : "http:\/\/bit.ly\/2EtsBKN",
        "display_url" : "bit.ly\/2EtsBKN"
      } ]
    },
    "geo" : { },
    "id_str" : "1073680027399675904",
    "text" : "Would you attempt building your own bandsaw? Check out this Instructable for the full process and tips. https:\/\/t.co\/LLQ3yc8TBc",
    "id" : 1073680027399675904,
    "created_at" : "2018-12-14 20:44:01 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1074182325779480577,
  "created_at" : "2018-12-16 05:59:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikhail Alfon",
      "screen_name" : "miqk",
      "indices" : [ 3, 8 ],
      "id_str" : "47809456",
      "id" : 47809456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074182026016755713",
  "text" : "RT @miqk: You don\u2019t have to wait until Christmas to give a gift and you don\u2019t have to wait until the New Year to make a commitment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074097729414955008",
    "text" : "You don\u2019t have to wait until Christmas to give a gift and you don\u2019t have to wait until the New Year to make a commitment.",
    "id" : 1074097729414955008,
    "created_at" : "2018-12-16 00:23:49 +0000",
    "user" : {
      "name" : "Mikhail Alfon",
      "screen_name" : "miqk",
      "protected" : false,
      "id_str" : "47809456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1033769805617094656\/VSTQMZ7S_normal.jpg",
      "id" : 47809456,
      "verified" : false
    }
  },
  "id" : 1074182026016755713,
  "created_at" : "2018-12-16 05:58:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 3, 15 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074181963219644417",
  "text" : "RT @KassyDillon: I find myself listening to old movies and songs a lot and saying \u201Cwell, the PC mob wouldn\u2019t let that fly if it was release\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074179662744416262",
    "text" : "I find myself listening to old movies and songs a lot and saying \u201Cwell, the PC mob wouldn\u2019t let that fly if it was released today.\u201D",
    "id" : 1074179662744416262,
    "created_at" : "2018-12-16 05:49:23 +0000",
    "user" : {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "protected" : false,
      "id_str" : "178999981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1076158543168847872\/vztW80IL_normal.jpg",
      "id" : 178999981,
      "verified" : true
    }
  },
  "id" : 1074181963219644417,
  "created_at" : "2018-12-16 05:58:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074181924552359936",
  "text" : "RT @BTCticker: One Bitcoin now worth $3232.61@bitstamp. High $3256.680. Low $3122.280. Market Cap $56.328 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074174809947414528",
    "text" : "One Bitcoin now worth $3232.61@bitstamp. High $3256.680. Low $3122.280. Market Cap $56.328 Billion #bitcoin",
    "id" : 1074174809947414528,
    "created_at" : "2018-12-16 05:30:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074181924552359936,
  "created_at" : "2018-12-16 05:58:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074181916130205696",
  "text" : "RT @BTCticker: One Bitcoin now worth $3271.600. Market Cap $57.009 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074174809519591424",
    "text" : "One Bitcoin now worth $3271.600. Market Cap $57.009 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1074174809519591424,
    "created_at" : "2018-12-16 05:30:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074181916130205696,
  "created_at" : "2018-12-16 05:58:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/8Vw1fTSQbd",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/920916351030210560",
      "display_url" : "minds.com\/newsfeed\/92091\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074180577966911489",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/8Vw1fTSQbd",
  "id" : 1074180577966911489,
  "created_at" : "2018-12-16 05:53:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.squarespace.com\" rel=\"nofollow\"\u003ESquarespace\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/f9dmPgrUm0",
      "expanded_url" : "https:\/\/www.digitalcpr.net\/blog\/2018\/12\/16\/the-cost-of-brilliance",
      "display_url" : "digitalcpr.net\/blog\/2018\/12\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7207559, -74.00076130000002 ]
  },
  "id_str" : "1074180320210096128",
  "text" : "The Cost of Brilliance  https:\/\/t.co\/f9dmPgrUm0",
  "id" : 1074180320210096128,
  "created_at" : "2018-12-16 05:52:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/ygKMHpiN3W",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/920909847335743488",
      "display_url" : "minds.com\/newsfeed\/92090\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074174382937919488",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/ygKMHpiN3W",
  "id" : 1074174382937919488,
  "created_at" : "2018-12-16 05:28:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/08zRLQj1Az",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/920909000591527936",
      "display_url" : "minds.com\/newsfeed\/92090\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074174355180003330",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/08zRLQj1Az",
  "id" : 1074174355180003330,
  "created_at" : "2018-12-16 05:28:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "indices" : [ 3, 18 ],
      "id_str" : "2984496093",
      "id" : 2984496093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074172028805095424",
  "text" : "RT @_daniellebleau: Why do people that decide to sell things online think it\u2019s cool to all of the sudden become really annoying and spam my\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074144665870446597",
    "text" : "Why do people that decide to sell things online think it\u2019s cool to all of the sudden become really annoying and spam my DMs. Please crawl out.",
    "id" : 1074144665870446597,
    "created_at" : "2018-12-16 03:30:19 +0000",
    "user" : {
      "name" : "Danielle Bleau",
      "screen_name" : "_daniellebleau",
      "protected" : false,
      "id_str" : "2984496093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936751927429386241\/Ra89-JcI_normal.jpg",
      "id" : 2984496093,
      "verified" : false
    }
  },
  "id" : 1074172028805095424,
  "created_at" : "2018-12-16 05:19:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074171818200743936",
  "text" : "RT @BTCticker: One Bitcoin now worth $3272.032. Market Cap $57.016 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074167266764382208",
    "text" : "One Bitcoin now worth $3272.032. Market Cap $57.016 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1074167266764382208,
    "created_at" : "2018-12-16 05:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074171818200743936,
  "created_at" : "2018-12-16 05:18:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "Richard Branson",
      "screen_name" : "richardbranson",
      "indices" : [ 14, 29 ],
      "id_str" : "8161232",
      "id" : 8161232
    }, {
      "name" : "Virgin Galactic",
      "screen_name" : "virgingalactic",
      "indices" : [ 30, 45 ],
      "id_str" : "26208862",
      "id" : 26208862
    }, {
      "name" : "TheSpaceshipCompany",
      "screen_name" : "TheSpaceshipCo",
      "indices" : [ 46, 61 ],
      "id_str" : "373727589",
      "id" : 373727589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074171786567319552",
  "text" : "RT @elonmusk: @richardbranson @virgingalactic @TheSpaceshipCo Thanks!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Branson",
        "screen_name" : "richardbranson",
        "indices" : [ 0, 15 ],
        "id_str" : "8161232",
        "id" : 8161232
      }, {
        "name" : "Virgin Galactic",
        "screen_name" : "virgingalactic",
        "indices" : [ 16, 31 ],
        "id_str" : "26208862",
        "id" : 26208862
      }, {
        "name" : "TheSpaceshipCompany",
        "screen_name" : "TheSpaceshipCo",
        "indices" : [ 32, 47 ],
        "id_str" : "373727589",
        "id" : 373727589
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1074150184345616384",
    "geo" : { },
    "id_str" : "1074154185543696384",
    "in_reply_to_user_id" : 8161232,
    "text" : "@richardbranson @virgingalactic @TheSpaceshipCo Thanks!",
    "id" : 1074154185543696384,
    "in_reply_to_status_id" : 1074150184345616384,
    "created_at" : "2018-12-16 04:08:09 +0000",
    "in_reply_to_screen_name" : "richardbranson",
    "in_reply_to_user_id_str" : "8161232",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1074171786567319552,
  "created_at" : "2018-12-16 05:18:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/MYoPFd3LoR",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/920907086156607488",
      "display_url" : "minds.com\/newsfeed\/92090\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074171604660350981",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/MYoPFd3LoR",
  "id" : 1074171604660350981,
  "created_at" : "2018-12-16 05:17:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "instafood",
      "indices" : [ 41, 51 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Mskt9FmNdg",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrbmxsTlfEV\/?utm_source=ig_twitter_share&igshid=8asvgoj2trax",
      "display_url" : "instagram.com\/p\/BrbmxsTlfEV\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074128139691819008",
  "text" : "Meat mountain @ Miami from a fan #foodie #instafood #foodpics https:\/\/t.co\/Mskt9FmNdg",
  "id" : 1074128139691819008,
  "created_at" : "2018-12-16 02:24:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/PpUvOR8NNK",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/basic-css-tricks-that-are-not-so-basic\/",
      "display_url" : "webdesigndev.com\/basic-css-tric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074107987827023873",
  "text" : "RT @WebDesignDev: Basic CSS Tricks that Are Not So Basic: https:\/\/t.co\/PpUvOR8NNK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/PpUvOR8NNK",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/basic-css-tricks-that-are-not-so-basic\/",
        "display_url" : "webdesigndev.com\/basic-css-tric\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074075152894300160",
    "text" : "Basic CSS Tricks that Are Not So Basic: https:\/\/t.co\/PpUvOR8NNK",
    "id" : 1074075152894300160,
    "created_at" : "2018-12-15 22:54:06 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1074107987827023873,
  "created_at" : "2018-12-16 01:04:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074107901789257729",
  "text" : "RT @BTCticker: One Bitcoin now worth $3236.255. Market Cap $56.392 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074069118817591303",
    "text" : "One Bitcoin now worth $3236.255. Market Cap $56.392 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1074069118817591303,
    "created_at" : "2018-12-15 22:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074107901789257729,
  "created_at" : "2018-12-16 01:04:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "indices" : [ 3, 16 ],
      "id_str" : "20508477",
      "id" : 20508477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/eLVIYmze9v",
      "expanded_url" : "http:\/\/www.webdesigndev.com\/flash-animation-tutorial\/",
      "display_url" : "webdesigndev.com\/flash-animatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074107847288463360",
  "text" : "RT @WebDesignDev: 20 Sleek CSS Animations and Effects: https:\/\/t.co\/eLVIYmze9v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/eLVIYmze9v",
        "expanded_url" : "http:\/\/www.webdesigndev.com\/flash-animation-tutorial\/",
        "display_url" : "webdesigndev.com\/flash-animatio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074088238233587713",
    "text" : "20 Sleek CSS Animations and Effects: https:\/\/t.co\/eLVIYmze9v",
    "id" : 1074088238233587713,
    "created_at" : "2018-12-15 23:46:06 +0000",
    "user" : {
      "name" : "WebDesignDev",
      "screen_name" : "WebDesignDev",
      "protected" : false,
      "id_str" : "20508477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/299830993\/icon_dev_normal.jpg",
      "id" : 20508477,
      "verified" : false
    }
  },
  "id" : 1074107847288463360,
  "created_at" : "2018-12-16 01:04:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "indices" : [ 3, 12 ],
      "id_str" : "14607140",
      "id" : 14607140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3dprinting",
      "indices" : [ 26, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/RuaT3eSywa",
      "expanded_url" : "https:\/\/wp.me\/pk3lN-1pCr",
      "display_url" : "wp.me\/pk3lN-1pCr"
    } ]
  },
  "geo" : { },
  "id_str" : "1074107809984327681",
  "text" : "RT @hackaday: Microscopic #3dprinting? Try disposable diapers. Really. https:\/\/t.co\/RuaT3eSywa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "3dprinting",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/RuaT3eSywa",
        "expanded_url" : "https:\/\/wp.me\/pk3lN-1pCr",
        "display_url" : "wp.me\/pk3lN-1pCr"
      } ]
    },
    "geo" : { },
    "id_str" : "1074091830931873792",
    "text" : "Microscopic #3dprinting? Try disposable diapers. Really. https:\/\/t.co\/RuaT3eSywa",
    "id" : 1074091830931873792,
    "created_at" : "2018-12-16 00:00:22 +0000",
    "user" : {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "protected" : false,
      "id_str" : "14607140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699222440702926848\/8Pm7yZFb_normal.png",
      "id" : 14607140,
      "verified" : true
    }
  },
  "id" : 1074107809984327681,
  "created_at" : "2018-12-16 01:03:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Wedekind \u2728",
      "screen_name" : "EmmaWedekind",
      "indices" : [ 3, 16 ],
      "id_str" : "491821358",
      "id" : 491821358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074107792330539010",
  "text" : "RT @EmmaWedekind: In the spirit of gift giving, what was the best piece of career advice someone ever gifted to you? \uD83C\uDF81\uD83C\uDF84",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073931173896863745",
    "text" : "In the spirit of gift giving, what was the best piece of career advice someone ever gifted to you? \uD83C\uDF81\uD83C\uDF84",
    "id" : 1073931173896863745,
    "created_at" : "2018-12-15 13:21:59 +0000",
    "user" : {
      "name" : "Emma Wedekind \u2728",
      "screen_name" : "EmmaWedekind",
      "protected" : false,
      "id_str" : "491821358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077623963067576320\/-gZd_oMp_normal.jpg",
      "id" : 491821358,
      "verified" : false
    }
  },
  "id" : 1074107792330539010,
  "created_at" : "2018-12-16 01:03:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074107767626104837",
  "text" : "RT @BTCticker: One Bitcoin now worth $3217.910. Market Cap $56.072 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074106861593477121",
    "text" : "One Bitcoin now worth $3217.910. Market Cap $56.072 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1074106861593477121,
    "created_at" : "2018-12-16 01:00:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1074107767626104837,
  "created_at" : "2018-12-16 01:03:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xhfpLbVgvi",
      "expanded_url" : "https:\/\/fstoppers.com\/gear\/eos-r-and-6d-mark-ii-canon-best-option-vloggers-318763?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/gear\/eos-r-and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074107743617908736",
  "text" : "RT @JayHoque: With the EOS R and the 6D Mark II, Is Canon the Best Option for Vloggers?: https:\/\/t.co\/xhfpLbVgvi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/xhfpLbVgvi",
        "expanded_url" : "https:\/\/fstoppers.com\/gear\/eos-r-and-6d-mark-ii-canon-best-option-vloggers-318763?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/gear\/eos-r-and\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074080015741083649",
    "text" : "With the EOS R and the 6D Mark II, Is Canon the Best Option for Vloggers?: https:\/\/t.co\/xhfpLbVgvi",
    "id" : 1074080015741083649,
    "created_at" : "2018-12-15 23:13:25 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1074107743617908736,
  "created_at" : "2018-12-16 01:03:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/XADT7LjCUR",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/07\/how-to-make-spicy-salami-soppressata-honey-pizza.html",
      "display_url" : "seriouseats.com\/2015\/07\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1074107701062459398",
  "text" : "RT @seriouseats: A match made in heaven, brought together by\u2014what else!\u2014bread and cheese.\nhttps:\/\/t.co\/XADT7LjCUR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/XADT7LjCUR",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/07\/how-to-make-spicy-salami-soppressata-honey-pizza.html",
        "display_url" : "seriouseats.com\/2015\/07\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1074076637476610053",
    "text" : "A match made in heaven, brought together by\u2014what else!\u2014bread and cheese.\nhttps:\/\/t.co\/XADT7LjCUR",
    "id" : 1074076637476610053,
    "created_at" : "2018-12-15 23:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1074107701062459398,
  "created_at" : "2018-12-16 01:03:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074107686176899072",
  "text" : "Nah probably not really",
  "id" : 1074107686176899072,
  "created_at" : "2018-12-16 01:03:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074107651762675712",
  "text" : "I am such a tease sometimes",
  "id" : 1074107651762675712,
  "created_at" : "2018-12-16 01:03:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074062421084520448",
  "text" : "RT @TipsyBartender: Pom-A-Rita - Beautiful, tangy twist on the classic margarita!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073965907913912320",
    "text" : "Pom-A-Rita - Beautiful, tangy twist on the classic margarita!",
    "id" : 1073965907913912320,
    "created_at" : "2018-12-15 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1074062421084520448,
  "created_at" : "2018-12-15 22:03:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074062307628630016",
  "text" : "RT @TheSharkDaymond: Thank You. \uD83D\uDE4F\uD83C\uDFFF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073993196940730368",
    "text" : "Thank You. \uD83D\uDE4F\uD83C\uDFFF",
    "id" : 1073993196940730368,
    "created_at" : "2018-12-15 17:28:26 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1074062307628630016,
  "created_at" : "2018-12-15 22:03:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074062263131213826",
  "text" : "RT @BarbaraCorcoran: The hardest part is taking the first step. After that, the direction is set, and forward momentum helps you all along\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1074061725492764673",
    "text" : "The hardest part is taking the first step. After that, the direction is set, and forward momentum helps you all along the way.",
    "id" : 1074061725492764673,
    "created_at" : "2018-12-15 22:00:45 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1074062263131213826,
  "created_at" : "2018-12-15 22:02:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1074062243988422656",
  "text" : "Been so busy lately it's been going...",
  "id" : 1074062243988422656,
  "created_at" : "2018-12-15 22:02:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    }, {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 97, 110 ],
      "id_str" : "302666251",
      "id" : 302666251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piday",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "raspberrypi",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/JAWENpSthB",
      "expanded_url" : "https:\/\/adafru.it\/Dki",
      "display_url" : "adafru.it\/Dki"
    } ]
  },
  "geo" : { },
  "id_str" : "1073696501812158466",
  "text" : "RT @adafruit: Valve helps Raspberry Pi owners build their own Steam Link box #piday #raspberrypi @Raspberry_Pi https:\/\/t.co\/JAWENpSthB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raspberry Pi",
        "screen_name" : "Raspberry_Pi",
        "indices" : [ 83, 96 ],
        "id_str" : "302666251",
        "id" : 302666251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "piday",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "raspberrypi",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/JAWENpSthB",
        "expanded_url" : "https:\/\/adafru.it\/Dki",
        "display_url" : "adafru.it\/Dki"
      } ]
    },
    "geo" : { },
    "id_str" : "1073608563950538753",
    "text" : "Valve helps Raspberry Pi owners build their own Steam Link box #piday #raspberrypi @Raspberry_Pi https:\/\/t.co\/JAWENpSthB",
    "id" : 1073608563950538753,
    "created_at" : "2018-12-14 16:00:02 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1073696501812158466,
  "created_at" : "2018-12-14 21:49:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/r2dbXJ8NoE",
      "expanded_url" : "https:\/\/www.seriouseats.com\/roundups\/festive-vegetarian-main-dishes",
      "display_url" : "seriouseats.com\/roundups\/festi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073696458354896898",
  "text" : "RT @seriouseats: You don't need glazed ham or prime rib to have a festive holiday. https:\/\/t.co\/r2dbXJ8NoE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/r2dbXJ8NoE",
        "expanded_url" : "https:\/\/www.seriouseats.com\/roundups\/festive-vegetarian-main-dishes",
        "display_url" : "seriouseats.com\/roundups\/festi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1073626566872190977",
    "text" : "You don't need glazed ham or prime rib to have a festive holiday. https:\/\/t.co\/r2dbXJ8NoE",
    "id" : 1073626566872190977,
    "created_at" : "2018-12-14 17:11:35 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1073696458354896898,
  "created_at" : "2018-12-14 21:49:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/TjEtKQ8zeA",
      "expanded_url" : "https:\/\/fstoppers.com\/originals\/better-way-edit-your-photos-fstoppers-reviews-loupedeck-editing-console-318088?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/originals\/bett\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073696390713356288",
  "text" : "RT @JayHoque: A Better Way to Edit Your Photos: Fstoppers Reviews the Loupedeck+ Editing Console: https:\/\/t.co\/TjEtKQ8zeA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/TjEtKQ8zeA",
        "expanded_url" : "https:\/\/fstoppers.com\/originals\/better-way-edit-your-photos-fstoppers-reviews-loupedeck-editing-console-318088?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/originals\/bett\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1073657174109421568",
    "text" : "A Better Way to Edit Your Photos: Fstoppers Reviews the Loupedeck+ Editing Console: https:\/\/t.co\/TjEtKQ8zeA",
    "id" : 1073657174109421568,
    "created_at" : "2018-12-14 19:13:12 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1073696390713356288,
  "created_at" : "2018-12-14 21:49:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.squarespace.com\" rel=\"nofollow\"\u003ESquarespace\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/In1uxIspCe",
      "expanded_url" : "https:\/\/www.digitalcpr.net\/blog\/2018\/12\/14\/the-startup-world-been-crazy",
      "display_url" : "digitalcpr.net\/blog\/2018\/12\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7207559, -74.00076130000002 ]
  },
  "id_str" : "1073696221158629376",
  "text" : "rThe Startup World Been Crazy  https:\/\/t.co\/In1uxIspCe",
  "id" : 1073696221158629376,
  "created_at" : "2018-12-14 21:48:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "instafood",
      "indices" : [ 26, 36 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "foodchat",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/7OiSRbW9V6",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrYO5F9g8xj\/?utm_source=ig_twitter_share&igshid=1x8rpzs0vtxsq",
      "display_url" : "instagram.com\/p\/BrYO5F9g8xj\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073653473936314369",
  "text" : "Baked goods plate #foodie #instafood #foodpics #foodchat https:\/\/t.co\/7OiSRbW9V6",
  "id" : 1073653473936314369,
  "created_at" : "2018-12-14 18:58:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 28, 35 ]
    }, {
      "text" : "instafood",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/FrDQMxukpa",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrWXkeplcH6\/?utm_source=ig_twitter_share&igshid=b3fbxn3trddo",
      "display_url" : "instagram.com\/p\/BrWXkeplcH6\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073391300836188160",
  "text" : "Eating some veggie stir fry #foodie #instafood https:\/\/t.co\/FrDQMxukpa",
  "id" : 1073391300836188160,
  "created_at" : "2018-12-14 01:36:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instafood",
      "indices" : [ 11, 21 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "foodie",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/WqDO8dMN79",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrVy5t_ACgz\/?utm_source=ig_twitter_share&igshid=1ke1fflngvebb",
      "display_url" : "instagram.com\/p\/BrVy5t_ACgz\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073310395241242624",
  "text" : "More sushi #instafood #foodpics #foodie https:\/\/t.co\/WqDO8dMN79",
  "id" : 1073310395241242624,
  "created_at" : "2018-12-13 20:15:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073270687308091392",
  "text" : "RT @BTCticker: One Bitcoin now worth $3405.532. Market Cap $59.327 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073268846079995904",
    "text" : "One Bitcoin now worth $3405.532. Market Cap $59.327 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1073268846079995904,
    "created_at" : "2018-12-13 17:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1073270687308091392,
  "created_at" : "2018-12-13 17:37:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BusinessUnusual",
      "indices" : [ 63, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073270636146016261",
  "text" : "RT @BarbaraCorcoran: Got a question for me? Ask me here for my #BusinessUnusual podcast.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BusinessUnusual",
        "indices" : [ 42, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073208564909596673",
    "text" : "Got a question for me? Ask me here for my #BusinessUnusual podcast.",
    "id" : 1073208564909596673,
    "created_at" : "2018-12-13 13:30:35 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1073270636146016261,
  "created_at" : "2018-12-13 17:37:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073270607708676097",
  "text" : "RT @TipsyBartender: German Chocolate Cake Shot - chocolate J\u00E4germeister shots!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1073241132337905665",
    "text" : "German Chocolate Cake Shot - chocolate J\u00E4germeister shots!",
    "id" : 1073241132337905665,
    "created_at" : "2018-12-13 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1073270607708676097,
  "created_at" : "2018-12-13 17:37:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTCUSD",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/MBsqwrHov1",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BTCUSD\/jQCT4DxQ-The-BItcoin-Price-Breakdown\/",
      "display_url" : "tradingview.com\/chart\/BTCUSD\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1073067867426320384",
  "text" : "The BItcoin Price Breakdown - #BTCUSD chart https:\/\/t.co\/MBsqwrHov1",
  "id" : 1073067867426320384,
  "created_at" : "2018-12-13 04:11:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BTCUSD",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/lePzjwd6GY",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/BTCUSD\/48ewuvwV-BTC-Continued-HODL-Negative-Shorts\/",
      "display_url" : "tradingview.com\/chart\/BTCUSD\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072890358680309760",
  "text" : "BTC, Continued HODL + Negative Shorts - #BTCUSD chart https:\/\/t.co\/lePzjwd6GY",
  "id" : 1072890358680309760,
  "created_at" : "2018-12-12 16:26:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072734837541404672",
  "text" : "RT @BTCticker: One Bitcoin now worth $3377.688. Market Cap $58.835 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072732821477838848",
    "text" : "One Bitcoin now worth $3377.688. Market Cap $58.835 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072732821477838848,
    "created_at" : "2018-12-12 06:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072734837541404672,
  "created_at" : "2018-12-12 06:08:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/XkQibuDNZC",
      "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/12\/12\/review-flashpoint-xplor-600-pro-ttl-battery-powered-monolight\/",
      "display_url" : "thephoblographer.com\/2018\/12\/12\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072734814665695232",
  "text" : "RT @JayHoque: Review: Flashpoint XPLOR 600 Pro TTL Battery Powered Monolight (Sony TTL): https:\/\/t.co\/XkQibuDNZC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/XkQibuDNZC",
        "expanded_url" : "https:\/\/www.thephoblographer.com\/2018\/12\/12\/review-flashpoint-xplor-600-pro-ttl-battery-powered-monolight\/",
        "display_url" : "thephoblographer.com\/2018\/12\/12\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072730082916139008",
    "text" : "Review: Flashpoint XPLOR 600 Pro TTL Battery Powered Monolight (Sony TTL): https:\/\/t.co\/XkQibuDNZC",
    "id" : 1072730082916139008,
    "created_at" : "2018-12-12 05:49:16 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1072734814665695232,
  "created_at" : "2018-12-12 06:08:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072700814844583936",
  "text" : "RT @TheSharkDaymond: Over-provide, outsource, and out-hustle. Whether you are an employee, an intern, or starting out small, it is crucial\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070718126357123075",
    "text" : "Over-provide, outsource, and out-hustle. Whether you are an employee, an intern, or starting out small, it is crucial not to be the bench warmer.",
    "id" : 1070718126357123075,
    "created_at" : "2018-12-06 16:34:28 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1072700814844583936,
  "created_at" : "2018-12-12 03:52:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Martin",
      "screen_name" : "joeDmarti",
      "indices" : [ 3, 13 ],
      "id_str" : "19720110",
      "id" : 19720110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072700777242726400",
  "text" : "RT @joeDmarti: Successful people don\u2019t answer their emails for the first hour of the day. You\u2019re answering other peoples problems . @TheSha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daymond John",
        "screen_name" : "TheSharkDaymond",
        "indices" : [ 117, 133 ],
        "id_str" : "16225240",
        "id" : 16225240
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WednesdayWisdom",
        "indices" : [ 136, 152 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070324027762237440",
    "text" : "Successful people don\u2019t answer their emails for the first hour of the day. You\u2019re answering other peoples problems . @TheSharkDaymond \n\n#WednesdayWisdom",
    "id" : 1070324027762237440,
    "created_at" : "2018-12-05 14:28:28 +0000",
    "user" : {
      "name" : "Joe Martin",
      "screen_name" : "joeDmarti",
      "protected" : false,
      "id_str" : "19720110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1043157734705618945\/-kuB3IAB_normal.jpg",
      "id" : 19720110,
      "verified" : true
    }
  },
  "id" : 1072700777242726400,
  "created_at" : "2018-12-12 03:52:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norman Chan",
      "screen_name" : "nchan",
      "indices" : [ 3, 9 ],
      "id_str" : "8732012",
      "id" : 8732012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072700467862519814",
  "text" : "RT @nchan: seeing a movie rate 99% fresh on rottentomatoes is maybe more enticing than a 100% rating, because you know it factors in at lea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072634587245895681",
    "text" : "seeing a movie rate 99% fresh on rottentomatoes is maybe more enticing than a 100% rating, because you know it factors in at least 100 reviews.",
    "id" : 1072634587245895681,
    "created_at" : "2018-12-11 23:29:48 +0000",
    "user" : {
      "name" : "Norman Chan",
      "screen_name" : "nchan",
      "protected" : false,
      "id_str" : "8732012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515964416257294337\/AHU02d36_normal.jpeg",
      "id" : 8732012,
      "verified" : false
    }
  },
  "id" : 1072700467862519814,
  "created_at" : "2018-12-12 03:51:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 3, 12 ],
      "id_str" : "17877351",
      "id" : 17877351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072700092036104195",
  "text" : "RT @sparkfun: \"Liquid cooling is a popular way to get a bit of extra performance out of your computer. If you want dive deeper into the wor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hubspot.com\/\" rel=\"nofollow\"\u003EHubSpot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaspberryPi",
        "indices" : [ 214, 226 ]
      }, {
        "text" : "computing",
        "indices" : [ 227, 237 ]
      } ],
      "urls" : [ {
        "indices" : [ 238, 261 ],
        "url" : "https:\/\/t.co\/AKnez7DEgZ",
        "expanded_url" : "http:\/\/bit.ly\/2PjMq8q",
        "display_url" : "bit.ly\/2PjMq8q"
      } ]
    },
    "geo" : { },
    "id_str" : "1072597937002299393",
    "text" : "\"Liquid cooling is a popular way to get a bit of extra performance out of your computer. If you want dive deeper into the world of liquid cooling, you can submerge your entire computer in a bath of mineral oil...\" #RaspberryPi #computing https:\/\/t.co\/AKnez7DEgZ",
    "id" : 1072597937002299393,
    "created_at" : "2018-12-11 21:04:10 +0000",
    "user" : {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "protected" : false,
      "id_str" : "17877351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823909015012769792\/qJrILRQh_normal.jpg",
      "id" : 17877351,
      "verified" : false
    }
  },
  "id" : 1072700092036104195,
  "created_at" : "2018-12-12 03:50:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072699523191971840",
  "text" : "RT @TheSharkDaymond: If you have a passion for something, pursue it! You never know where it could take you. #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071957781052301313",
    "text" : "If you have a passion for something, pursue it! You never know where it could take you. #SharkTank",
    "id" : 1071957781052301313,
    "created_at" : "2018-12-10 02:40:25 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1072699523191971840,
  "created_at" : "2018-12-12 03:47:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072699301028118528",
  "text" : "RT @JayHoque: Kipon released MTF charts and sample photos from the new ELEGANT full-frame mirrorless lenses for Nikon Z-mount: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/KglUwXz8ls",
        "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/11\/kipon-released-mtf-charts-and-sample-photos-from-the-new-elegant-full-frame-mirrorless-lenses-for-nikon-z-mount.aspx\/",
        "display_url" : "nikonrumors.com\/2018\/12\/11\/kip\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072696095673851904",
    "text" : "Kipon released MTF charts and sample photos from the new ELEGANT full-frame mirrorless lenses for Nikon Z-mount: https:\/\/t.co\/KglUwXz8ls",
    "id" : 1072696095673851904,
    "created_at" : "2018-12-12 03:34:13 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1072699301028118528,
  "created_at" : "2018-12-12 03:46:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNET",
      "screen_name" : "CNET",
      "indices" : [ 3, 8 ],
      "id_str" : "30261067",
      "id" : 30261067
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CNET\/status\/1072340196501397512\/video\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/zmc3AJHgkn",
      "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/1070758836292673536\/img\/U9ne4mUfahIF-Gar.jpg",
      "id_str" : "1070758836292673536",
      "id" : 1070758836292673536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/1070758836292673536\/img\/U9ne4mUfahIF-Gar.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/zmc3AJHgkn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072699178722168832",
  "text" : "RT @CNET: Fun level: 11\/10 https:\/\/t.co\/zmc3AJHgkn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003ETwitter Media Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CNET\/status\/1072340196501397512\/video\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/zmc3AJHgkn",
        "media_url" : "http:\/\/pbs.twimg.com\/amplify_video_thumb\/1070758836292673536\/img\/U9ne4mUfahIF-Gar.jpg",
        "id_str" : "1070758836292673536",
        "id" : 1070758836292673536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/amplify_video_thumb\/1070758836292673536\/img\/U9ne4mUfahIF-Gar.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/zmc3AJHgkn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072340196501397512",
    "text" : "Fun level: 11\/10 https:\/\/t.co\/zmc3AJHgkn",
    "id" : 1072340196501397512,
    "created_at" : "2018-12-11 04:00:00 +0000",
    "user" : {
      "name" : "CNET",
      "screen_name" : "CNET",
      "protected" : false,
      "id_str" : "30261067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/963998359001317376\/scuoOV5m_normal.jpg",
      "id" : 30261067,
      "verified" : true
    }
  },
  "id" : 1072699178722168832,
  "created_at" : "2018-12-12 03:46:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salesforce SE",
      "screen_name" : "StackSalesforce",
      "indices" : [ 3, 19 ],
      "id_str" : "735058458",
      "id" : 735058458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visualforce",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/YFN7DXow7B",
      "expanded_url" : "https:\/\/salesforce.stackexchange.com\/q\/242135?atw=1",
      "display_url" : "salesforce.stackexchange.com\/q\/242135?atw=1"
    } ]
  },
  "geo" : { },
  "id_str" : "1072698678006214656",
  "text" : "RT @StackSalesforce: How do I produce a \"New\" record button to look like a standard \"New\" button? https:\/\/t.co\/YFN7DXow7B #visualforce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/stackexchange.com\" rel=\"nofollow\"\u003EStack Exchange\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visualforce",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/YFN7DXow7B",
        "expanded_url" : "https:\/\/salesforce.stackexchange.com\/q\/242135?atw=1",
        "display_url" : "salesforce.stackexchange.com\/q\/242135?atw=1"
      } ]
    },
    "geo" : { },
    "id_str" : "1072687694927544322",
    "text" : "How do I produce a \"New\" record button to look like a standard \"New\" button? https:\/\/t.co\/YFN7DXow7B #visualforce",
    "id" : 1072687694927544322,
    "created_at" : "2018-12-12 03:00:50 +0000",
    "user" : {
      "name" : "Salesforce SE",
      "screen_name" : "StackSalesforce",
      "protected" : false,
      "id_str" : "735058458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700015326574948352\/SxCeO0-m_normal.png",
      "id" : 735058458,
      "verified" : false
    }
  },
  "id" : 1072698678006214656,
  "created_at" : "2018-12-12 03:44:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/zT0ax2aUIa",
      "expanded_url" : "http:\/\/bit.ly\/2UzbY5a",
      "display_url" : "bit.ly\/2UzbY5a"
    } ]
  },
  "geo" : { },
  "id_str" : "1072696934798909440",
  "text" : "Yes :) https:\/\/t.co\/zT0ax2aUIa",
  "id" : 1072696934798909440,
  "created_at" : "2018-12-12 03:37:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ZhylJ2veVB",
      "expanded_url" : "https:\/\/www.skillshare.com\/profile\/Andrew-Kamal\/4704589",
      "display_url" : "skillshare.com\/profile\/Andrew\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072696729710051328",
  "text" : "https:\/\/t.co\/ZhylJ2veVB",
  "id" : 1072696729710051328,
  "created_at" : "2018-12-12 03:36:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/A2xXhJa8DS",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/919432413374439424",
      "display_url" : "minds.com\/newsfeed\/91943\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072696682637348864",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/A2xXhJa8DS",
  "id" : 1072696682637348864,
  "created_at" : "2018-12-12 03:36:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072628617635684353",
  "text" : "RT @BarbaraCorcoran: You won\u2019t invent anything good standing still! All the good ideas happen when you\u2019re too busy and on your way to somet\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072627188057427968",
    "text" : "You won\u2019t invent anything good standing still! All the good ideas happen when you\u2019re too busy and on your way to something else.",
    "id" : 1072627188057427968,
    "created_at" : "2018-12-11 23:00:24 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1072628617635684353,
  "created_at" : "2018-12-11 23:06:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "indices" : [ 3, 18 ],
      "id_str" : "1626294277",
      "id" : 1626294277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072558316994334720",
  "text" : "RT @spectatorindex: Most traffic congested cities, 2017.\n\n1. Los Angeles\n2. Moscow\n3. New York\n\n7. London\n12. Paris\n16. Bangkok\n17. Jakarta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072513840611495936",
    "text" : "Most traffic congested cities, 2017.\n\n1. Los Angeles\n2. Moscow\n3. New York\n\n7. London\n12. Paris\n16. Bangkok\n17. Jakarta\n20. Istanbul\n21. Mexico City\n22. Chicago\n35. Munich\n38. Montreal\n67. Berlin\n76. Madrid\n104. Rome\n165. Riyadh\n175. Dublin\n208. Dubai\n906. Singapore\n\n(INRIX)",
    "id" : 1072513840611495936,
    "created_at" : "2018-12-11 15:30:00 +0000",
    "user" : {
      "name" : "The Spectator Index",
      "screen_name" : "spectatorindex",
      "protected" : false,
      "id_str" : "1626294277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839067030904922112\/LH4xqz-d_normal.jpg",
      "id" : 1626294277,
      "verified" : false
    }
  },
  "id" : 1072558316994334720,
  "created_at" : "2018-12-11 18:26:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Lusardi",
      "screen_name" : "pyskell",
      "indices" : [ 3, 11 ],
      "id_str" : "936029116729524227",
      "id" : 936029116729524227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072558072135118848",
  "text" : "RT @pyskell: NOTICE: The $ETC community GitHub organization is moving from ethereumproject to ethereumclassic.\n\nLeaving out links. Twitter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072474759257096193",
    "text" : "NOTICE: The $ETC community GitHub organization is moving from ethereumproject to ethereumclassic.\n\nLeaving out links. Twitter deprioritizes them and this needs maximum exposure.",
    "id" : 1072474759257096193,
    "created_at" : "2018-12-11 12:54:42 +0000",
    "user" : {
      "name" : "Anthony Lusardi",
      "screen_name" : "pyskell",
      "protected" : false,
      "id_str" : "936029116729524227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1063477719885856768\/PqdgPkR1_normal.jpg",
      "id" : 936029116729524227,
      "verified" : false
    }
  },
  "id" : 1072558072135118848,
  "created_at" : "2018-12-11 18:25:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "instafood",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/X3Ail2j9kr",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrQcrxgl3D7\/?utm_source=ig_twitter_share&igshid=15lndccbc5twj",
      "display_url" : "instagram.com\/p\/BrQcrxgl3D7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072557931432943617",
  "text" : "This is why pizza is so awesome #foodie #instafood #foodpics https:\/\/t.co\/X3Ail2j9kr",
  "id" : 1072557931432943617,
  "created_at" : "2018-12-11 18:25:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072551958899245056",
  "text" : "RT @TipsyBartender: Melon Sunrise - beautiful, light, and fruity!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072491194955886592",
    "text" : "Melon Sunrise - beautiful, light, and fruity!",
    "id" : 1072491194955886592,
    "created_at" : "2018-12-11 14:00:01 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1072551958899245056,
  "created_at" : "2018-12-11 18:01:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072551781736046597",
  "text" : "RT @BTCticker: One Bitcoin now worth $3376.187. Market Cap $58.806 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072551624021815298",
    "text" : "One Bitcoin now worth $3376.187. Market Cap $58.806 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072551624021815298,
    "created_at" : "2018-12-11 18:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072551781736046597,
  "created_at" : "2018-12-11 18:00:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "indices" : [ 3, 12 ],
      "id_str" : "14607140",
      "id" : 14607140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "technology",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UwYZNMvIEg",
      "expanded_url" : "https:\/\/wp.me\/pk3lN-1pqj",
      "display_url" : "wp.me\/pk3lN-1pqj"
    } ]
  },
  "geo" : { },
  "id_str" : "1072551656410238976",
  "text" : "RT @hackaday: Will your next vehicle have a liquid drivetrain? (Probably not, but...) #technology https:\/\/t.co\/UwYZNMvIEg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "technology",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/UwYZNMvIEg",
        "expanded_url" : "https:\/\/wp.me\/pk3lN-1pqj",
        "display_url" : "wp.me\/pk3lN-1pqj"
      } ]
    },
    "geo" : { },
    "id_str" : "1072528993600053248",
    "text" : "Will your next vehicle have a liquid drivetrain? (Probably not, but...) #technology https:\/\/t.co\/UwYZNMvIEg",
    "id" : 1072528993600053248,
    "created_at" : "2018-12-11 16:30:13 +0000",
    "user" : {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "protected" : false,
      "id_str" : "14607140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699222440702926848\/8Pm7yZFb_normal.png",
      "id" : 14607140,
      "verified" : true
    }
  },
  "id" : 1072551656410238976,
  "created_at" : "2018-12-11 18:00:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/prfAh85Xow",
      "expanded_url" : "https:\/\/petapixel.com\/2018\/12\/11\/kipon-unveils-the-first-3rd-party-lenses-for-canon-r-and-nikon-z\/",
      "display_url" : "petapixel.com\/2018\/12\/11\/kip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072551413392265217",
  "text" : "RT @JayHoque: KIPON Unveils the First 3rd-Party Lenses for Canon R and Nikon Z: https:\/\/t.co\/prfAh85Xow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/prfAh85Xow",
        "expanded_url" : "https:\/\/petapixel.com\/2018\/12\/11\/kipon-unveils-the-first-3rd-party-lenses-for-canon-r-and-nikon-z\/",
        "display_url" : "petapixel.com\/2018\/12\/11\/kip\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072537580590297088",
    "text" : "KIPON Unveils the First 3rd-Party Lenses for Canon R and Nikon Z: https:\/\/t.co\/prfAh85Xow",
    "id" : 1072537580590297088,
    "created_at" : "2018-12-11 17:04:20 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1072551413392265217,
  "created_at" : "2018-12-11 17:59:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072551276574064646",
  "text" : "RT @BTCticker: One Bitcoin now worth $3365.362. Market Cap $58.617 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072536518680592384",
    "text" : "One Bitcoin now worth $3365.362. Market Cap $58.617 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072536518680592384,
    "created_at" : "2018-12-11 17:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072551276574064646,
  "created_at" : "2018-12-11 17:58:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/R9VF2fKgBm",
      "expanded_url" : "https:\/\/trib.al\/KcAPJhf",
      "display_url" : "trib.al\/KcAPJhf"
    } ]
  },
  "geo" : { },
  "id_str" : "1072551244357611520",
  "text" : "RT @epicurious: For those of us who love shortbread and chocolate equally. \nhttps:\/\/t.co\/R9VF2fKgBm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/R9VF2fKgBm",
        "expanded_url" : "https:\/\/trib.al\/KcAPJhf",
        "display_url" : "trib.al\/KcAPJhf"
      } ]
    },
    "geo" : { },
    "id_str" : "1072550565501169665",
    "text" : "For those of us who love shortbread and chocolate equally. \nhttps:\/\/t.co\/R9VF2fKgBm",
    "id" : 1072550565501169665,
    "created_at" : "2018-12-11 17:55:56 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1072551244357611520,
  "created_at" : "2018-12-11 17:58:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    }, {
      "name" : "Bloomberg",
      "screen_name" : "business",
      "indices" : [ 14, 23 ],
      "id_str" : "34713362",
      "id" : 34713362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072551136945692672",
  "text" : "RT @elonmusk: @business Incorrect. \u201CChairman\u201D is an honorific, not executive role, which means it\u2019s not needed to run Tesla. Will retire th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bloomberg",
        "screen_name" : "business",
        "indices" : [ 0, 9 ],
        "id_str" : "34713362",
        "id" : 34713362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1072474778785714181",
    "geo" : { },
    "id_str" : "1072528643488972802",
    "in_reply_to_user_id" : 34713362,
    "text" : "@business Incorrect. \u201CChairman\u201D is an honorific, not executive role, which means it\u2019s not needed to run Tesla. Will retire that title at Tesla in 3 years. 60 Mins edited out end of my sentence, where I said I could do whatever I want. They cut \u201Cprovided I have the support of shareholders\u201D.",
    "id" : 1072528643488972802,
    "in_reply_to_status_id" : 1072474778785714181,
    "created_at" : "2018-12-11 16:28:49 +0000",
    "in_reply_to_screen_name" : "business",
    "in_reply_to_user_id_str" : "34713362",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1072551136945692672,
  "created_at" : "2018-12-11 17:58:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/67hZGzVgj6",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/01\/the-food-lab-pressure-cooker-caramelized-onions-onion-soup.html",
      "display_url" : "seriouseats.com\/2016\/01\/the-fo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072551043005902851",
  "text" : "RT @seriouseats: Instant Pot French onion soup! https:\/\/t.co\/67hZGzVgj6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/67hZGzVgj6",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/01\/the-food-lab-pressure-cooker-caramelized-onions-onion-soup.html",
        "display_url" : "seriouseats.com\/2016\/01\/the-fo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072536505565020162",
    "text" : "Instant Pot French onion soup! https:\/\/t.co\/67hZGzVgj6",
    "id" : 1072536505565020162,
    "created_at" : "2018-12-11 17:00:04 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1072551043005902851,
  "created_at" : "2018-12-11 17:57:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072550908133810176\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/HI7IgJrhX0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuJ3WsQW4AAEeTZ.jpg",
      "id_str" : "1072550892988194816",
      "id" : 1072550892988194816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuJ3WsQW4AAEeTZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/HI7IgJrhX0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/OzCAxrvXsN",
      "expanded_url" : "https:\/\/www.udemy.com\/blockchain-certification-practice\/",
      "display_url" : "udemy.com\/blockchain-cer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072550908133810176",
  "text" : "New Udemy course :) https:\/\/t.co\/OzCAxrvXsN https:\/\/t.co\/HI7IgJrhX0",
  "id" : 1072550908133810176,
  "created_at" : "2018-12-11 17:57:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/o8Hoq4OEMq",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/919286271441494016",
      "display_url" : "minds.com\/newsfeed\/91928\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072550653401186307",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/o8Hoq4OEMq",
  "id" : 1072550653401186307,
  "created_at" : "2018-12-11 17:56:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Sowell",
      "screen_name" : "ThomasSowell",
      "indices" : [ 3, 16 ],
      "id_str" : "57338175",
      "id" : 57338175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072519802206457856",
  "text" : "RT @ThomasSowell: \u201COne of the most pathetic\u2014and dangerous\u2014signs of our times is the growing number of individuals and groups who believe th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072189966367764480",
    "text" : "\u201COne of the most pathetic\u2014and dangerous\u2014signs of our times is the growing number of individuals and groups who believe that no one can possibly disagree with them for any honest reason.\u201D",
    "id" : 1072189966367764480,
    "created_at" : "2018-12-10 18:03:02 +0000",
    "user" : {
      "name" : "Thomas Sowell",
      "screen_name" : "ThomasSowell",
      "protected" : false,
      "id_str" : "57338175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/316502615\/sowell2_normal.bmp",
      "id" : 57338175,
      "verified" : false
    }
  },
  "id" : 1072519802206457856,
  "created_at" : "2018-12-11 15:53:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072519728558673921",
  "text" : "RT @BTCticker: One Bitcoin now worth $3452.155. Market Cap $60.126 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072370430026108928",
    "text" : "One Bitcoin now worth $3452.155. Market Cap $60.126 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072370430026108928,
    "created_at" : "2018-12-11 06:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072519728558673921,
  "created_at" : "2018-12-11 15:53:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072368712211152897",
  "text" : "RT @BTCticker: One Bitcoin now worth $3405.23@bitstamp. High $3534.900. Low $3355.000. Market Cap $59.308 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072362874427842560",
    "text" : "One Bitcoin now worth $3405.23@bitstamp. High $3534.900. Low $3355.000. Market Cap $59.308 Billion #bitcoin",
    "id" : 1072362874427842560,
    "created_at" : "2018-12-11 05:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072368712211152897,
  "created_at" : "2018-12-11 05:53:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/QXRROkfLxA",
      "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/10\/sigma-40mm-f-1-4-dg-hsm-art-lens-now-in-stock-first-reviews-already-online.aspx\/",
      "display_url" : "nikonrumors.com\/2018\/12\/10\/sig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072368636659154944",
  "text" : "RT @JayHoque: Sigma 40mm f\/1.4 DG HSM Art lens now in stock, first reviews already online: https:\/\/t.co\/QXRROkfLxA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/QXRROkfLxA",
        "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/10\/sigma-40mm-f-1-4-dg-hsm-art-lens-now-in-stock-first-reviews-already-online.aspx\/",
        "display_url" : "nikonrumors.com\/2018\/12\/10\/sig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072352562534367232",
    "text" : "Sigma 40mm f\/1.4 DG HSM Art lens now in stock, first reviews already online: https:\/\/t.co\/QXRROkfLxA",
    "id" : 1072352562534367232,
    "created_at" : "2018-12-11 04:49:08 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1072368636659154944,
  "created_at" : "2018-12-11 05:53:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072347221134331905",
  "text" : "RT @TheSharkDaymond: I thought I\u2019ve seen it all until this.  #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 40, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071950393222008833",
    "text" : "I thought I\u2019ve seen it all until this.  #SharkTank",
    "id" : 1071950393222008833,
    "created_at" : "2018-12-10 02:11:04 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1072347221134331905,
  "created_at" : "2018-12-11 04:27:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Metzler",
      "screen_name" : "MTestKitchen",
      "indices" : [ 3, 16 ],
      "id_str" : "775093526602272768",
      "id" : 775093526602272768
    }, {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 61, 75 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/JCRctrDZBs",
      "expanded_url" : "https:\/\/www.instructables.com\/id\/Foolproof-Biscuits",
      "display_url" : "instructables.com\/id\/Foolproof-B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072346363755708418",
  "text" : "RT @MTestKitchen: Just posted my recipe \"Foolproof Biscuits\" @instructables ! https:\/\/t.co\/JCRctrDZBs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "instructables",
        "screen_name" : "instructables",
        "indices" : [ 43, 57 ],
        "id_str" : "7597362",
        "id" : 7597362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/JCRctrDZBs",
        "expanded_url" : "https:\/\/www.instructables.com\/id\/Foolproof-Biscuits",
        "display_url" : "instructables.com\/id\/Foolproof-B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1071478092298928129",
    "text" : "Just posted my recipe \"Foolproof Biscuits\" @instructables ! https:\/\/t.co\/JCRctrDZBs",
    "id" : 1071478092298928129,
    "created_at" : "2018-12-08 18:54:18 +0000",
    "user" : {
      "name" : "Michael Metzler",
      "screen_name" : "MTestKitchen",
      "protected" : false,
      "id_str" : "775093526602272768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077692017994477568\/jEyKotx5_normal.jpg",
      "id" : 775093526602272768,
      "verified" : false
    }
  },
  "id" : 1072346363755708418,
  "created_at" : "2018-12-11 04:24:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OSHStencils",
      "screen_name" : "OSHStencils",
      "indices" : [ 3, 15 ],
      "id_str" : "1390818332",
      "id" : 1390818332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072346303902945280",
  "text" : "RT @OSHStencils: We will be closed Thursday and Friday for annual machine \/ shop maintenance.  If you need stencils, try to get them ordere\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1037401188000358400",
    "text" : "We will be closed Thursday and Friday for annual machine \/ shop maintenance.  If you need stencils, try to get them ordered today and we'll do our best to get them shipped before the maintenance begins tomorrow. Thanks for your patience and understanding :)",
    "id" : 1037401188000358400,
    "created_at" : "2018-09-05 18:04:51 +0000",
    "user" : {
      "name" : "OSHStencils",
      "screen_name" : "OSHStencils",
      "protected" : false,
      "id_str" : "1390818332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745351520967745537\/fLglzFHk_normal.jpg",
      "id" : 1390818332,
      "verified" : false
    }
  },
  "id" : 1072346303902945280,
  "created_at" : "2018-12-11 04:24:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OSH Park",
      "screen_name" : "oshpark",
      "indices" : [ 3, 11 ],
      "id_str" : "243342953",
      "id" : 243342953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072346254980599815",
  "text" : "RT @oshpark: We now offer 2 layer Flex PCBs for $15 per square inch including 3 copies of your design. Orders will be sent to fabrication w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 224, 247 ],
        "url" : "https:\/\/t.co\/vHqhmUYBv7",
        "expanded_url" : "http:\/\/docs.oshpark.com\/services\/flex\/",
        "display_url" : "docs.oshpark.com\/services\/flex\/"
      } ]
    },
    "geo" : { },
    "id_str" : "1072110055695167488",
    "text" : "We now offer 2 layer Flex PCBs for $15 per square inch including 3 copies of your design. Orders will be sent to fabrication weekly and ship within 21 calendar days of ordering. Find out more on our Flex documentation page: https:\/\/t.co\/vHqhmUYBv7",
    "id" : 1072110055695167488,
    "created_at" : "2018-12-10 12:45:30 +0000",
    "user" : {
      "name" : "OSH Park",
      "screen_name" : "oshpark",
      "protected" : false,
      "id_str" : "243342953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2392894818\/mm3mheojls2zb0zx622n_normal.png",
      "id" : 243342953,
      "verified" : false
    }
  },
  "id" : 1072346254980599815,
  "created_at" : "2018-12-11 04:24:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ohmohm",
      "screen_name" : "ohmohm",
      "indices" : [ 3, 10 ],
      "id_str" : "14935588",
      "id" : 14935588
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tindie",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/kY5ft8SWnU",
      "expanded_url" : "https:\/\/www.tindie.com\/products\/m2m\/1-channel-lorawan-gateway-shield-for-raspberry-pi\/",
      "display_url" : "tindie.com\/products\/m2m\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072346206356033537",
  "text" : "RT @ohmohm: Made in Thailand - 1 Channel LoRaWan Gateway Shield for Raspberry Pi  https:\/\/t.co\/kY5ft8SWnU on #Tindie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tindie",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/kY5ft8SWnU",
        "expanded_url" : "https:\/\/www.tindie.com\/products\/m2m\/1-channel-lorawan-gateway-shield-for-raspberry-pi\/",
        "display_url" : "tindie.com\/products\/m2m\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1071711895529304066",
    "text" : "Made in Thailand - 1 Channel LoRaWan Gateway Shield for Raspberry Pi  https:\/\/t.co\/kY5ft8SWnU on #Tindie",
    "id" : 1071711895529304066,
    "created_at" : "2018-12-09 10:23:21 +0000",
    "user" : {
      "name" : "ohmohm",
      "screen_name" : "ohmohm",
      "protected" : false,
      "id_str" : "14935588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/55159506\/ohmohm_normal.png",
      "id" : 14935588,
      "verified" : false
    }
  },
  "id" : 1072346206356033537,
  "created_at" : "2018-12-11 04:23:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072345108895424512\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ElAXKUpREg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuG8KOvWsAAnIIX.jpg",
      "id_str" : "1072345070232317952",
      "id" : 1072345070232317952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuG8KOvWsAAnIIX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 750
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ElAXKUpREg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/9vhVI1ODdb",
      "expanded_url" : "https:\/\/www.udemy.com\/learnstartups\/",
      "display_url" : "udemy.com\/learnstartups\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1072345108895424512",
  "text" : "Really excited about my new practice test course for Startup Terminology: https:\/\/t.co\/9vhVI1ODdb https:\/\/t.co\/ElAXKUpREg",
  "id" : 1072345108895424512,
  "created_at" : "2018-12-11 04:19:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/9vhVI1ODdb",
      "expanded_url" : "https:\/\/www.udemy.com\/learnstartups\/",
      "display_url" : "udemy.com\/learnstartups\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1072344976279904257",
  "text" : "Really excited about my new practice test course for Startup Terminology: https:\/\/t.co\/9vhVI1ODdb",
  "id" : 1072344976279904257,
  "created_at" : "2018-12-11 04:19:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/9vhVI1ODdb",
      "expanded_url" : "https:\/\/www.udemy.com\/learnstartups\/",
      "display_url" : "udemy.com\/learnstartups\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1072344883313152000",
  "text" : "https:\/\/t.co\/9vhVI1ODdb",
  "id" : 1072344883313152000,
  "created_at" : "2018-12-11 04:18:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/qaDJyPGzv6",
      "expanded_url" : "https:\/\/www.facebook.com\/eduRepo.1\/",
      "display_url" : "facebook.com\/eduRepo.1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "1072344804800061441",
  "text" : "https:\/\/t.co\/qaDJyPGzv6",
  "id" : 1072344804800061441,
  "created_at" : "2018-12-11 04:18:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/vrnwBmYS28",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/919079828675932160",
      "display_url" : "minds.com\/newsfeed\/91907\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072344580853514241",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/vrnwBmYS28",
  "id" : 1072344580853514241,
  "created_at" : "2018-12-11 04:17:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072304654313250816",
  "text" : "RT @TheSharkDaymond: Marketing is only half the game. If your business isn\u2019t built to scale, you better figure it out and fast. #SharkTank",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071963032182501378",
    "text" : "Marketing is only half the game. If your business isn\u2019t built to scale, you better figure it out and fast. #SharkTank",
    "id" : 1071963032182501378,
    "created_at" : "2018-12-10 03:01:17 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048022980863954944\/eZvGANn0_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 1072304654313250816,
  "created_at" : "2018-12-11 01:38:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    }, {
      "name" : "Univ. of Arizona \uD83D\uDC3B\u2B07",
      "screen_name" : "UofA",
      "indices" : [ 102, 107 ],
      "id_str" : "14862639",
      "id" : 14862639
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OSIRIS",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "Bennu",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/64uwFq5s3d",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-osiris-rex-asteroid-bennu-excellent-mission.html",
      "display_url" : "phys.org\/news\/2018-12-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072304461748539395",
  "text" : "RT @physorg_com: #OSIRIS-REx discovers water on asteroid, confirms #Bennu as excellent mission target @uofa https:\/\/t.co\/64uwFq5s3d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Univ. of Arizona \uD83D\uDC3B\u2B07",
        "screen_name" : "UofA",
        "indices" : [ 85, 90 ],
        "id_str" : "14862639",
        "id" : 14862639
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OSIRIS",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Bennu",
        "indices" : [ 50, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/64uwFq5s3d",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-osiris-rex-asteroid-bennu-excellent-mission.html",
        "display_url" : "phys.org\/news\/2018-12-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072240396992987138",
    "text" : "#OSIRIS-REx discovers water on asteroid, confirms #Bennu as excellent mission target @uofa https:\/\/t.co\/64uwFq5s3d",
    "id" : 1072240396992987138,
    "created_at" : "2018-12-10 21:23:26 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1072304461748539395,
  "created_at" : "2018-12-11 01:38:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/njOPHt2eDN",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/01\/lemon-spaghetti-bright-fresh-fast-and-perfect-for-a-winter-night.html",
      "display_url" : "seriouseats.com\/2018\/01\/lemon-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072304325630849025",
  "text" : "RT @seriouseats: Your Monday night pick me up. https:\/\/t.co\/njOPHt2eDN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/njOPHt2eDN",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/01\/lemon-spaghetti-bright-fresh-fast-and-perfect-for-a-winter-night.html",
        "display_url" : "seriouseats.com\/2018\/01\/lemon-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072234501319749632",
    "text" : "Your Monday night pick me up. https:\/\/t.co\/njOPHt2eDN",
    "id" : 1072234501319749632,
    "created_at" : "2018-12-10 21:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1072304325630849025,
  "created_at" : "2018-12-11 01:37:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/cFWdtECz3i",
      "expanded_url" : "http:\/\/www.seriouseats.com\/2017\/12\/how-to-make-homemade-cinnamon-rolls.html",
      "display_url" : "seriouseats.com\/2017\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072304270266064896",
  "text" : "RT @seriouseats: Nothing says \"Today is a special day\" like waking up to the smell of cinnamon rolls.\n https:\/\/t.co\/cFWdtECz3i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/cFWdtECz3i",
        "expanded_url" : "http:\/\/www.seriouseats.com\/2017\/12\/how-to-make-homemade-cinnamon-rolls.html",
        "display_url" : "seriouseats.com\/2017\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072264700862185473",
    "text" : "Nothing says \"Today is a special day\" like waking up to the smell of cinnamon rolls.\n https:\/\/t.co\/cFWdtECz3i",
    "id" : 1072264700862185473,
    "created_at" : "2018-12-10 23:00:01 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1072304270266064896,
  "created_at" : "2018-12-11 01:37:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072304239953801217",
  "text" : "RT @BarbaraCorcoran: I go out of my way to stay away from negative people. They don\u2019t mean to do it, but they rob you blind, stealing your\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072265009533722624",
    "text" : "I go out of my way to stay away from negative people. They don\u2019t mean to do it, but they rob you blind, stealing your energy and your joy. I like to think I\u2019m smarter than that.",
    "id" : 1072265009533722624,
    "created_at" : "2018-12-10 23:01:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1072304239953801217,
  "created_at" : "2018-12-11 01:37:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072304176166789120\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bwbhl2oHT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuGW4IrXcAAC1Ee.jpg",
      "id_str" : "1072304077437104128",
      "id" : 1072304077437104128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuGW4IrXcAAC1Ee.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/bwbhl2oHT8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072304176166789120\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bwbhl2oHT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuGW5PFXQAEYKOH.jpg",
      "id_str" : "1072304096336625665",
      "id" : 1072304096336625665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuGW5PFXQAEYKOH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/bwbhl2oHT8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072304176166789120\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bwbhl2oHT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuGW6srWsAE9QuS.jpg",
      "id_str" : "1072304121460469761",
      "id" : 1072304121460469761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuGW6srWsAE9QuS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1166
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 3242,
        "resize" : "fit",
        "w" : 1845
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 387
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/bwbhl2oHT8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NDmwmfPG5W",
      "expanded_url" : "http:\/\/chainterra.com",
      "display_url" : "chainterra.com"
    } ]
  },
  "geo" : { },
  "id_str" : "1072304176166789120",
  "text" : "I am obviously more then just a brand ambassador, I built this tech and it is amazing :) via https:\/\/t.co\/NDmwmfPG5W https:\/\/t.co\/bwbhl2oHT8",
  "id" : 1072304176166789120,
  "created_at" : "2018-12-11 01:36:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CypressSemiconductor",
      "screen_name" : "CypressSemi",
      "indices" : [ 3, 15 ],
      "id_str" : "18239140",
      "id" : 18239140
    }, {
      "name" : "Digi-Key Electronics",
      "screen_name" : "digikey",
      "indices" : [ 43, 51 ],
      "id_str" : "17346756",
      "id" : 17346756
    }, {
      "name" : "SparkFun Electronics",
      "screen_name" : "sparkfun",
      "indices" : [ 53, 62 ],
      "id_str" : "17877351",
      "id" : 17877351
    }, {
      "name" : "W\u00FCrth Elektronik",
      "screen_name" : "we_online",
      "indices" : [ 67, 77 ],
      "id_str" : "1091565476",
      "id" : 1091565476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072162222376411136",
  "text" : "RT @CypressSemi: We\u2019re joining forces with @digikey, @sparkfun and @we_online to bring the farm-to-fork revolution to you! \uD83C\uDF31 Check out how\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Digi-Key Electronics",
        "screen_name" : "digikey",
        "indices" : [ 26, 34 ],
        "id_str" : "17346756",
        "id" : 17346756
      }, {
        "name" : "SparkFun Electronics",
        "screen_name" : "sparkfun",
        "indices" : [ 36, 45 ],
        "id_str" : "17877351",
        "id" : 17877351
      }, {
        "name" : "W\u00FCrth Elektronik",
        "screen_name" : "we_online",
        "indices" : [ 50, 60 ],
        "id_str" : "1091565476",
        "id" : 1091565476
      }, {
        "name" : "Electronic Design",
        "screen_name" : "ElectronicDesgn",
        "indices" : [ 232, 248 ],
        "id_str" : "28454112",
        "id" : 28454112
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LED",
        "indices" : [ 156, 160 ]
      }, {
        "text" : "PSoC6",
        "indices" : [ 174, 180 ]
      }, {
        "text" : "IoT",
        "indices" : [ 206, 210 ]
      }, {
        "text" : "agriculture",
        "indices" : [ 211, 223 ]
      } ],
      "urls" : [ {
        "indices" : [ 249, 272 ],
        "url" : "https:\/\/t.co\/S7tes2LdPy",
        "expanded_url" : "https:\/\/bit.ly\/2QsHoLe",
        "display_url" : "bit.ly\/2QsHoLe"
      } ]
    },
    "geo" : { },
    "id_str" : "1068510213387489281",
    "text" : "We\u2019re joining forces with @digikey, @sparkfun and @we_online to bring the farm-to-fork revolution to you! \uD83C\uDF31 Check out how our Green House Solution combines #LED lighting and #PSoC6 tech to create an indoor #IoT #agriculture system. @ElectronicDesgn https:\/\/t.co\/S7tes2LdPy",
    "id" : 1068510213387489281,
    "created_at" : "2018-11-30 14:21:01 +0000",
    "user" : {
      "name" : "CypressSemiconductor",
      "screen_name" : "CypressSemi",
      "protected" : false,
      "id_str" : "18239140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841441032923299841\/CqBTcn7i_normal.jpg",
      "id" : 18239140,
      "verified" : true
    }
  },
  "id" : 1072162222376411136,
  "created_at" : "2018-12-10 16:12:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "indices" : [ 3, 11 ],
      "id_str" : "850107536",
      "id" : 850107536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072160700733235200",
  "text" : "RT @codeorg: Happy birthday, Ada Lovelace! Born Dec. 10, 1815 in London, Lovelace is considered the world's FIRST programmer. Nearly a cent\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 253, 276 ],
        "url" : "https:\/\/t.co\/DP09nYW8jx",
        "expanded_url" : "https:\/\/buff.ly\/2G76N5B",
        "display_url" : "buff.ly\/2G76N5B"
      } ]
    },
    "geo" : { },
    "id_str" : "1072159003394871296",
    "text" : "Happy birthday, Ada Lovelace! Born Dec. 10, 1815 in London, Lovelace is considered the world's FIRST programmer. Nearly a century before the computing age, she wrote about a machine that could be programmed to follow instructions, calculate and create. https:\/\/t.co\/DP09nYW8jx",
    "id" : 1072159003394871296,
    "created_at" : "2018-12-10 16:00:00 +0000",
    "user" : {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "protected" : false,
      "id_str" : "850107536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1063120830454886400\/7JhtceE5_normal.jpg",
      "id" : 850107536,
      "verified" : true
    }
  },
  "id" : 1072160700733235200,
  "created_at" : "2018-12-10 16:06:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072160617975435264",
  "text" : "RT @BTCticker: One Bitcoin now worth $3449.277. Market Cap $60.073 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072159027491205120",
    "text" : "One Bitcoin now worth $3449.277. Market Cap $60.073 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072159027491205120,
    "created_at" : "2018-12-10 16:00:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072160617975435264,
  "created_at" : "2018-12-10 16:06:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fundable",
      "indices" : [ 2, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ny7KMaoQEs",
      "expanded_url" : "http:\/\/bit.ly\/starkdrones",
      "display_url" : "bit.ly\/starkdrones"
    } ]
  },
  "geo" : { },
  "id_str" : "1072160473464930304",
  "text" : "A #fundable button have been added to our site via https:\/\/t.co\/ny7KMaoQEs",
  "id" : 1072160473464930304,
  "created_at" : "2018-12-10 16:05:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/69Qq78Oe5h",
      "expanded_url" : "https:\/\/steemit.com\/upfundition\/@etherstone\/kjxsb7jva",
      "display_url" : "steemit.com\/upfundition\/@e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072160212193284096",
  "text" : "Stark Drones is on Fundable \u2014 Steemit https:\/\/t.co\/69Qq78Oe5h",
  "id" : 1072160212193284096,
  "created_at" : "2018-12-10 16:04:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lava",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/1BWpoPFnxs",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-scientists-brew-lava-volcanoes.html",
      "display_url" : "phys.org\/news\/2018-12-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072155959655583744",
  "text" : "RT @physorg_com: Scientists brew #lava and blow it up to better understand volcanoes https:\/\/t.co\/1BWpoPFnxs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lava",
        "indices" : [ 16, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/1BWpoPFnxs",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-scientists-brew-lava-volcanoes.html",
        "display_url" : "phys.org\/news\/2018-12-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1072155757443985409",
    "text" : "Scientists brew #lava and blow it up to better understand volcanoes https:\/\/t.co\/1BWpoPFnxs",
    "id" : 1072155757443985409,
    "created_at" : "2018-12-10 15:47:06 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1072155959655583744,
  "created_at" : "2018-12-10 15:47:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "indices" : [ 3, 15 ],
      "id_str" : "30278532",
      "id" : 30278532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/tP4y4fyM5V",
      "expanded_url" : "https:\/\/trib.al\/hMIf51h",
      "display_url" : "trib.al\/hMIf51h"
    } ]
  },
  "geo" : { },
  "id_str" : "1072155611180265474",
  "text" : "RT @foodandwine: It's a Chicago institution at this point. https:\/\/t.co\/tP4y4fyM5V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/tP4y4fyM5V",
        "expanded_url" : "https:\/\/trib.al\/hMIf51h",
        "display_url" : "trib.al\/hMIf51h"
      } ]
    },
    "geo" : { },
    "id_str" : "1072151749044125696",
    "text" : "It's a Chicago institution at this point. https:\/\/t.co\/tP4y4fyM5V",
    "id" : 1072151749044125696,
    "created_at" : "2018-12-10 15:31:11 +0000",
    "user" : {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "protected" : false,
      "id_str" : "30278532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738810295301246977\/sJKDqlWh_normal.jpg",
      "id" : 30278532,
      "verified" : true
    }
  },
  "id" : 1072155611180265474,
  "created_at" : "2018-12-10 15:46:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072155195809902593",
  "text" : "RT @TipsyBartender: The Russian Elderflower - this one is super crisp and refreshing!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072153968409751552",
    "text" : "The Russian Elderflower - this one is super crisp and refreshing!",
    "id" : 1072153968409751552,
    "created_at" : "2018-12-10 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1072155195809902593,
  "created_at" : "2018-12-10 15:44:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072155164813987840",
  "text" : "Excited for what the future brings!!!",
  "id" : 1072155164813987840,
  "created_at" : "2018-12-10 15:44:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Fernandez",
      "screen_name" : "EA4HCD",
      "indices" : [ 3, 10 ],
      "id_str" : "1083494965",
      "id" : 1083494965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pocketqube",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "cubesat",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "space",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "satellite",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/prhgC9AWlp",
      "expanded_url" : "https:\/\/hackaday.io\/project\/162703-fossasat-1-open-source-satellite",
      "display_url" : "hackaday.io\/project\/162703\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072150445299257344",
  "text" : "RT @EA4HCD: FossaSat-1 Project shared on Hackaday! \nhttps:\/\/t.co\/prhgC9AWlp\n\n#pocketqube  #cubesat #space  #satellite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pocketqube",
        "indices" : [ 65, 76 ]
      }, {
        "text" : "cubesat",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "space",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "satellite",
        "indices" : [ 95, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/prhgC9AWlp",
        "expanded_url" : "https:\/\/hackaday.io\/project\/162703-fossasat-1-open-source-satellite",
        "display_url" : "hackaday.io\/project\/162703\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1071438892212150272",
    "text" : "FossaSat-1 Project shared on Hackaday! \nhttps:\/\/t.co\/prhgC9AWlp\n\n#pocketqube  #cubesat #space  #satellite",
    "id" : 1071438892212150272,
    "created_at" : "2018-12-08 16:18:32 +0000",
    "user" : {
      "name" : "Julian Fernandez",
      "screen_name" : "EA4HCD",
      "protected" : false,
      "id_str" : "1083494965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1045426349265960960\/k01gAkCm_normal.jpg",
      "id" : 1083494965,
      "verified" : false
    }
  },
  "id" : 1072150445299257344,
  "created_at" : "2018-12-10 15:26:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 21, 33 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/GutoBzjTBn",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5678084-Fundable-Graphics?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Fundable%20Graphics&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5678084-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072150106613403649",
  "text" : "Fundable Graphics by @gamer456148 https:\/\/t.co\/GutoBzjTBn",
  "id" : 1072150106613403649,
  "created_at" : "2018-12-10 15:24:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072149715880419328",
  "text" : "RT @BTCticker: One Bitcoin now worth $3491.230. Market Cap $60.803 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072143941972230144",
    "text" : "One Bitcoin now worth $3491.230. Market Cap $60.803 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072143941972230144,
    "created_at" : "2018-12-10 15:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072149715880419328,
  "created_at" : "2018-12-10 15:23:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/LYnbMQqmh6",
      "expanded_url" : "https:\/\/trib.al\/ecKFCSb",
      "display_url" : "trib.al\/ecKFCSb"
    } ]
  },
  "geo" : { },
  "id_str" : "1072149649190989825",
  "text" : "RT @epicurious: Step one? Skip the egg yolks. They're only a distraction.\nhttps:\/\/t.co\/LYnbMQqmh6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/LYnbMQqmh6",
        "expanded_url" : "https:\/\/trib.al\/ecKFCSb",
        "display_url" : "trib.al\/ecKFCSb"
      } ]
    },
    "geo" : { },
    "id_str" : "1072144917428879360",
    "text" : "Step one? Skip the egg yolks. They're only a distraction.\nhttps:\/\/t.co\/LYnbMQqmh6",
    "id" : 1072144917428879360,
    "created_at" : "2018-12-10 15:04:02 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1072149649190989825,
  "created_at" : "2018-12-10 15:22:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fundable",
      "screen_name" : "Fundable",
      "indices" : [ 41, 50 ],
      "id_str" : "17316055",
      "id" : 17316055
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072149546711568385\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/PBmdcBXOqa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuEKSXWXcAA1OfS.jpg",
      "id_str" : "1072149496912637952",
      "id" : 1072149496912637952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuEKSXWXcAA1OfS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PBmdcBXOqa"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1072149546711568385\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/PBmdcBXOqa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DuEKT7MXQAANVV6.jpg",
      "id_str" : "1072149523714228224",
      "id" : 1072149523714228224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DuEKT7MXQAANVV6.jpg",
      "sizes" : [ {
        "h" : 4096,
        "resize" : "fit",
        "w" : 1668
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 277
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/PBmdcBXOqa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072149546711568385",
  "text" : "The Stark Drones campaign is now live on @Fundable https:\/\/t.co\/PBmdcBXOqa",
  "id" : 1072149546711568385,
  "created_at" : "2018-12-10 15:22:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/JlM61NZvmF",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/918884334634283008",
      "display_url" : "minds.com\/newsfeed\/91888\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072149049564893190",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/JlM61NZvmF",
  "id" : 1072149049564893190,
  "created_at" : "2018-12-10 15:20:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072141844228829184",
  "text" : "RT @BarbaraCorcoran: I try not to resent. Nelson Mandela said it best: \u201CHolding on to anger is like drinking poison and waiting for your en\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072129306858528768",
    "text" : "I try not to resent. Nelson Mandela said it best: \u201CHolding on to anger is like drinking poison and waiting for your enemy to die.\u201D",
    "id" : 1072129306858528768,
    "created_at" : "2018-12-10 14:02:00 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1072141844228829184,
  "created_at" : "2018-12-10 14:51:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fundable",
      "screen_name" : "Fundable",
      "indices" : [ 124, 133 ],
      "id_str" : "17316055",
      "id" : 17316055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/T82kpT6exM",
      "expanded_url" : "https:\/\/www.fundable.com\/stark-drones-corporation",
      "display_url" : "fundable.com\/stark-drones-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1072141736946950146",
  "text" : "Stark Drones Corporation - Utilizing CAES and green tech to disrupt aerospace and other sectors https:\/\/t.co\/T82kpT6exM via @Fundable",
  "id" : 1072141736946950146,
  "created_at" : "2018-12-10 14:51:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RANDOM! \uD83E\uDD73\uD83E\uDD2F\uD83E\uDD2C\uD83E\uDD76\uD83E\uDD2E\uD83D\uDE08\uD83E\uDD13\uD83C\uDF0E",
      "screen_name" : "randomwrld",
      "indices" : [ 3, 14 ],
      "id_str" : "954897457770582016",
      "id" : 954897457770582016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072125498979958784",
  "text" : "RT @randomwrld: never stop learning, cause life never stops teaching",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialjukebox.com\" rel=\"nofollow\"\u003EThe Social Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072073537362542592",
    "text" : "never stop learning, cause life never stops teaching",
    "id" : 1072073537362542592,
    "created_at" : "2018-12-10 10:20:24 +0000",
    "user" : {
      "name" : "RANDOM! \uD83E\uDD73\uD83E\uDD2F\uD83E\uDD2C\uD83E\uDD76\uD83E\uDD2E\uD83D\uDE08\uD83E\uDD13\uD83C\uDF0E",
      "screen_name" : "randomwrld",
      "protected" : false,
      "id_str" : "954897457770582016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1080173935390584832\/w64yNPEE_normal.jpg",
      "id" : 954897457770582016,
      "verified" : false
    }
  },
  "id" : 1072125498979958784,
  "created_at" : "2018-12-10 13:46:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/l2VUxi8C1p",
      "expanded_url" : "https:\/\/trib.al\/SjvMqMA",
      "display_url" : "trib.al\/SjvMqMA"
    } ]
  },
  "geo" : { },
  "id_str" : "1072125375633870849",
  "text" : "RT @epicurious: This is the Official Soup of Having Been to Too Many Holiday Parties\nhttps:\/\/t.co\/l2VUxi8C1p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/l2VUxi8C1p",
        "expanded_url" : "https:\/\/trib.al\/SjvMqMA",
        "display_url" : "trib.al\/SjvMqMA"
      } ]
    },
    "geo" : { },
    "id_str" : "1072084273660915714",
    "text" : "This is the Official Soup of Having Been to Too Many Holiday Parties\nhttps:\/\/t.co\/l2VUxi8C1p",
    "id" : 1072084273660915714,
    "created_at" : "2018-12-10 11:03:03 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1072125375633870849,
  "created_at" : "2018-12-10 13:46:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072124938272825344",
  "text" : "RT @BTCticker: One Bitcoin now worth $3511.290. Market Cap $61.152 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072121283842895872",
    "text" : "One Bitcoin now worth $3511.290. Market Cap $61.152 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1072121283842895872,
    "created_at" : "2018-12-10 13:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072124938272825344,
  "created_at" : "2018-12-10 13:44:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/yGUR4Q3e1Q",
      "expanded_url" : "https:\/\/trib.al\/5bjyU3B",
      "display_url" : "trib.al\/5bjyU3B"
    } ]
  },
  "geo" : { },
  "id_str" : "1072124651906760704",
  "text" : "RT @epicurious: Nothing is more festive.\nhttps:\/\/t.co\/yGUR4Q3e1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/yGUR4Q3e1Q",
        "expanded_url" : "https:\/\/trib.al\/5bjyU3B",
        "display_url" : "trib.al\/5bjyU3B"
      } ]
    },
    "geo" : { },
    "id_str" : "1072008773919752192",
    "text" : "Nothing is more festive.\nhttps:\/\/t.co\/yGUR4Q3e1Q",
    "id" : 1072008773919752192,
    "created_at" : "2018-12-10 06:03:03 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1072124651906760704,
  "created_at" : "2018-12-10 13:43:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fact",
      "screen_name" : "Fact",
      "indices" : [ 3, 8 ],
      "id_str" : "2425231",
      "id" : 2425231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072124588421775361",
  "text" : "RT @Fact: The happier you are, the less sleep you require to function in everyday life. Sadness increases the urge to sleep more.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071851223513473024",
    "text" : "The happier you are, the less sleep you require to function in everyday life. Sadness increases the urge to sleep more.",
    "id" : 1071851223513473024,
    "created_at" : "2018-12-09 19:37:00 +0000",
    "user" : {
      "name" : "Fact",
      "screen_name" : "Fact",
      "protected" : false,
      "id_str" : "2425231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2969881129\/ab1629f03d646a755830fc704f690b8b_normal.jpeg",
      "id" : 2425231,
      "verified" : false
    }
  },
  "id" : 1072124588421775361,
  "created_at" : "2018-12-10 13:43:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I Am Devloper",
      "screen_name" : "iamdevloper",
      "indices" : [ 3, 15 ],
      "id_str" : "564919357",
      "id" : 564919357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072124450081071104",
  "text" : "RT @iamdevloper: TV show idea:\n\nMan vs Food but it\u2019s a 7 hour broadcast of you trying to fix a bug in front of a live audience.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072047167299301376",
    "text" : "TV show idea:\n\nMan vs Food but it\u2019s a 7 hour broadcast of you trying to fix a bug in front of a live audience.",
    "id" : 1072047167299301376,
    "created_at" : "2018-12-10 08:35:37 +0000",
    "user" : {
      "name" : "I Am Devloper",
      "screen_name" : "iamdevloper",
      "protected" : false,
      "id_str" : "564919357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1071055431215276033\/U9-RIlDs_normal.jpg",
      "id" : 564919357,
      "verified" : false
    }
  },
  "id" : 1072124450081071104,
  "created_at" : "2018-12-10 13:42:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1072124441050648576",
  "text" : "RT @BTCticker: One Bitcoin now worth $3474.89@bitstamp. High $3633.200. Low $3424.460. Market Cap $60.516 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1072121283461160961",
    "text" : "One Bitcoin now worth $3474.89@bitstamp. High $3633.200. Low $3424.460. Market Cap $60.516 Billion #bitcoin",
    "id" : 1072121283461160961,
    "created_at" : "2018-12-10 13:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1072124441050648576,
  "created_at" : "2018-12-10 13:42:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "indices" : [ 3, 14 ],
      "id_str" : "25170188",
      "id" : 25170188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/bvwDFxNxAj",
      "expanded_url" : "http:\/\/bonap.it\/Lc3KHL0",
      "display_url" : "bonap.it\/Lc3KHL0"
    } ]
  },
  "geo" : { },
  "id_str" : "1071974941350879232",
  "text" : "RT @bonappetit: The word of the day is: Salmon https:\/\/t.co\/bvwDFxNxAj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/bvwDFxNxAj",
        "expanded_url" : "http:\/\/bonap.it\/Lc3KHL0",
        "display_url" : "bonap.it\/Lc3KHL0"
      } ]
    },
    "geo" : { },
    "id_str" : "1071815758227955712",
    "text" : "The word of the day is: Salmon https:\/\/t.co\/bvwDFxNxAj",
    "id" : 1071815758227955712,
    "created_at" : "2018-12-09 17:16:04 +0000",
    "user" : {
      "name" : "Bon App\u00E9tit",
      "screen_name" : "bonappetit",
      "protected" : false,
      "id_str" : "25170188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308597170\/bon-appetit-twitter-icon_normal.jpg",
      "id" : 25170188,
      "verified" : true
    }
  },
  "id" : 1071974941350879232,
  "created_at" : "2018-12-10 03:48:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/velynKaTpk",
      "expanded_url" : "https:\/\/bit.ly\/2L8ElTw",
      "display_url" : "bit.ly\/2L8ElTw"
    } ]
  },
  "in_reply_to_status_id_str" : "1071973941751832578",
  "geo" : { },
  "id_str" : "1071974063449522176",
  "in_reply_to_user_id" : 210979938,
  "text" : "https:\/\/t.co\/velynKaTpk",
  "id" : 1071974063449522176,
  "in_reply_to_status_id" : 1071973941751832578,
  "created_at" : "2018-12-10 03:45:07 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/b2z63etbBg",
      "expanded_url" : "https:\/\/bit.ly\/2RLftDR",
      "display_url" : "bit.ly\/2RLftDR"
    } ]
  },
  "geo" : { },
  "id_str" : "1071973941751832578",
  "text" : "https:\/\/t.co\/b2z63etbBg",
  "id" : 1071973941751832578,
  "created_at" : "2018-12-10 03:44:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy Bambrough",
      "screen_name" : "BillyBambrough",
      "indices" : [ 3, 18 ],
      "id_str" : "753850129",
      "id" : 753850129
    }, {
      "name" : "Forbes Crypto",
      "screen_name" : "ForbesCrypto",
      "indices" : [ 114, 127 ],
      "id_str" : "902282851499917312",
      "id" : 902282851499917312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ethereum",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "Stellar",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "Bitcoin",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071970916404523008",
  "text" : "RT @BillyBambrough: #Ethereum And #Stellar Crash In 24 Hour Crypto And #Bitcoin Crunch -- Erasing $10 Billion via @ForbesCrypto https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forbes Crypto",
        "screen_name" : "ForbesCrypto",
        "indices" : [ 94, 107 ],
        "id_str" : "902282851499917312",
        "id" : 902282851499917312
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ethereum",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Stellar",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "Bitcoin",
        "indices" : [ 51, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/DkHoK8kLp9",
        "expanded_url" : "https:\/\/www.forbes.com\/sites\/billybambrough\/2018\/12\/07\/ethereum-and-stellar-crash-in-24-hour-crypto-crunch-erasing-10-billion\/#df306696a896",
        "display_url" : "forbes.com\/sites\/billybam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1071058094308892672",
    "text" : "#Ethereum And #Stellar Crash In 24 Hour Crypto And #Bitcoin Crunch -- Erasing $10 Billion via @ForbesCrypto https:\/\/t.co\/DkHoK8kLp9",
    "id" : 1071058094308892672,
    "created_at" : "2018-12-07 15:05:23 +0000",
    "user" : {
      "name" : "Billy Bambrough",
      "screen_name" : "BillyBambrough",
      "protected" : false,
      "id_str" : "753850129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872380995697336323\/JYOgnWov_normal.jpg",
      "id" : 753850129,
      "verified" : false
    }
  },
  "id" : 1071970916404523008,
  "created_at" : "2018-12-10 03:32:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oh boy what a shot",
      "screen_name" : "ohboywhatashot",
      "indices" : [ 3, 18 ],
      "id_str" : "210556794",
      "id" : 210556794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071967191585775617",
  "text" : "RT @ohboywhatashot: How much do you trust the EU?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071736798114660352",
    "text" : "How much do you trust the EU?",
    "id" : 1071736798114660352,
    "created_at" : "2018-12-09 12:02:19 +0000",
    "user" : {
      "name" : "Oh boy what a shot",
      "screen_name" : "ohboywhatashot",
      "protected" : false,
      "id_str" : "210556794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3677811051\/8c4259531e16ce358ed463771d0c5c3e_normal.jpeg",
      "id" : 210556794,
      "verified" : false
    }
  },
  "id" : 1071967191585775617,
  "created_at" : "2018-12-10 03:17:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ETHS",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/ja8UOSs4Su",
      "expanded_url" : "https:\/\/tokenregistry.medxprotocol.com\/applications\/ETHS",
      "display_url" : "tokenregistry.medxprotocol.com\/applications\/E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1071966075754082304",
  "text" : "Application for #ETHS pending registry: https:\/\/t.co\/ja8UOSs4Su",
  "id" : 1071966075754082304,
  "created_at" : "2018-12-10 03:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Parker",
      "screen_name" : "Wormbait__",
      "indices" : [ 3, 14 ],
      "id_str" : "381576198",
      "id" : 381576198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071963625169084416",
  "text" : "RT @Wormbait__: Confront today\u2019s negativity and overwhelm it with positivity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071830427592216576",
    "text" : "Confront today\u2019s negativity and overwhelm it with positivity.",
    "id" : 1071830427592216576,
    "created_at" : "2018-12-09 18:14:22 +0000",
    "user" : {
      "name" : "Eli Parker",
      "screen_name" : "Wormbait__",
      "protected" : false,
      "id_str" : "381576198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1078485717825871873\/s914OwZX_normal.jpg",
      "id" : 381576198,
      "verified" : false
    }
  },
  "id" : 1071963625169084416,
  "created_at" : "2018-12-10 03:03:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071963373150048256",
  "text" : "RT @BTCticker: One Bitcoin now worth $3569.300. Market Cap $62.160 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071962737641734144",
    "text" : "One Bitcoin now worth $3569.300. Market Cap $62.160 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1071962737641734144,
    "created_at" : "2018-12-10 03:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1071963373150048256,
  "created_at" : "2018-12-10 03:02:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CxMpym3cAO",
      "expanded_url" : "https:\/\/bit.ly\/2UvWgI4",
      "display_url" : "bit.ly\/2UvWgI4"
    } ]
  },
  "geo" : { },
  "id_str" : "1071963268607041536",
  "text" : "https:\/\/t.co\/CxMpym3cAO",
  "id" : 1071963268607041536,
  "created_at" : "2018-12-10 03:02:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/fzqb7tqifK",
      "expanded_url" : "https:\/\/trib.al\/BrNfyLx",
      "display_url" : "trib.al\/BrNfyLx"
    } ]
  },
  "geo" : { },
  "id_str" : "1071920732488257536",
  "text" : "RT @epicurious: Hello, peanut butter cup hot chocolate. \nhttps:\/\/t.co\/fzqb7tqifK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/fzqb7tqifK",
        "expanded_url" : "https:\/\/trib.al\/BrNfyLx",
        "display_url" : "trib.al\/BrNfyLx"
      } ]
    },
    "geo" : { },
    "id_str" : "1071917917539889154",
    "text" : "Hello, peanut butter cup hot chocolate. \nhttps:\/\/t.co\/fzqb7tqifK",
    "id" : 1071917917539889154,
    "created_at" : "2018-12-10 00:02:01 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1071920732488257536,
  "created_at" : "2018-12-10 00:13:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071920725504782341",
  "text" : "RT @BTCticker: One Bitcoin now worth $3572.128. Market Cap $62.209 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071917440823635968",
    "text" : "One Bitcoin now worth $3572.128. Market Cap $62.209 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1071917440823635968,
    "created_at" : "2018-12-10 00:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1071920725504782341,
  "created_at" : "2018-12-10 00:13:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071909672947466242",
  "text" : "RT @TipsyBartender: Pink Lemonade Slush - super refreshing! Tastes like an icy watermelon lemonade",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071766418297942016",
    "text" : "Pink Lemonade Slush - super refreshing! Tastes like an icy watermelon lemonade",
    "id" : 1071766418297942016,
    "created_at" : "2018-12-09 14:00:01 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1071909672947466242,
  "created_at" : "2018-12-09 23:29:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071909580848971781",
  "text" : "RT @elonmusk: If you have a Tesla built in past 2 years, definitely try Navigate on Autopilot. It will blow your mind. Automatically passes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071844948553609216",
    "text" : "If you have a Tesla built in past 2 years, definitely try Navigate on Autopilot. It will blow your mind. Automatically passes slow cars &amp; takes highway interchanges &amp; off-ramps.",
    "id" : 1071844948553609216,
    "created_at" : "2018-12-09 19:12:04 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1071909580848971781,
  "created_at" : "2018-12-09 23:28:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    }, {
      "name" : "J. Kenji \u201CIndividual Fun\u201D L\u00F3pez-Alt",
      "screen_name" : "kenjilopezalt",
      "indices" : [ 22, 36 ],
      "id_str" : "3793960033",
      "id" : 3793960033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071909473097302016",
  "text" : "RT @seriouseats: When @kenjilopezalt says \"the best roast potatoes of your life\" you stop everything and run to the kitchen. https:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "J. Kenji \u201CIndividual Fun\u201D L\u00F3pez-Alt",
        "screen_name" : "kenjilopezalt",
        "indices" : [ 5, 19 ],
        "id_str" : "3793960033",
        "id" : 3793960033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/dCJf8em2aA",
        "expanded_url" : "http:\/\/bit.ly\/2fOLA6H",
        "display_url" : "bit.ly\/2fOLA6H"
      } ]
    },
    "geo" : { },
    "id_str" : "1071539921955913729",
    "text" : "When @kenjilopezalt says \"the best roast potatoes of your life\" you stop everything and run to the kitchen. https:\/\/t.co\/dCJf8em2aA",
    "id" : 1071539921955913729,
    "created_at" : "2018-12-08 23:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1071909473097302016,
  "created_at" : "2018-12-09 23:28:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/mEmTYWqKaj",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/12\/use-vodka-for-crispier-fried-food.html",
      "display_url" : "seriouseats.com\/2016\/12\/use-vo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1071909424279810048",
  "text" : "RT @seriouseats: Want the crispiest fried chicken? Grab the vodka.\nhttps:\/\/t.co\/mEmTYWqKaj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/mEmTYWqKaj",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/12\/use-vodka-for-crispier-fried-food.html",
        "display_url" : "seriouseats.com\/2016\/12\/use-vo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1071795161229873152",
    "text" : "Want the crispiest fried chicken? Grab the vodka.\nhttps:\/\/t.co\/mEmTYWqKaj",
    "id" : 1071795161229873152,
    "created_at" : "2018-12-09 15:54:14 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1071909424279810048,
  "created_at" : "2018-12-09 23:28:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "instafood",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/M4RaclpcLD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrL1rudlZxd\/?utm_source=ig_twitter_share&igshid=10jgkn1vhsmcj",
      "display_url" : "instagram.com\/p\/BrL1rudlZxd\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1071909107370737664",
  "text" : "Sushi, sushi, sushi #foodie #instafood #foodpics https:\/\/t.co\/M4RaclpcLD",
  "id" : 1071909107370737664,
  "created_at" : "2018-12-09 23:27:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.tradingview.com\" rel=\"nofollow\"\u003ETradingView\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MS",
      "indices" : [ 35, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/n6xTj6sLgz",
      "expanded_url" : "http:\/\/www.tradingview.com\/chart\/MS\/j24ELyxc-Huge-Sell-off-for-Morgan-Stanley\/",
      "display_url" : "tradingview.com\/chart\/MS\/j24EL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1071110385002930177",
  "text" : "Huge Sell off for Morgan Stanley - #MS chart https:\/\/t.co\/n6xTj6sLgz",
  "id" : 1071110385002930177,
  "created_at" : "2018-12-07 18:33:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071057040255184897",
  "text" : "RT @BTCticker: One Bitcoin now worth $3414.663. Market Cap $59.454 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071056778383765506",
    "text" : "One Bitcoin now worth $3414.663. Market Cap $59.454 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1071056778383765506,
    "created_at" : "2018-12-07 15:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1071057040255184897,
  "created_at" : "2018-12-07 15:01:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Katchadourian",
      "screen_name" : "ashkatch",
      "indices" : [ 3, 12 ],
      "id_str" : "47178606",
      "id" : 47178606
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ashkatch\/status\/1071019977615048704\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/DNDyaUaCj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dt0G9j6VAAADubF.jpg",
      "id_str" : "1071019941065719808",
      "id" : 1071019941065719808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dt0G9j6VAAADubF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/DNDyaUaCj0"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ashkatch\/status\/1071019977615048704\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/DNDyaUaCj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dt0G9j6V4AEvZFv.jpg",
      "id_str" : "1071019941065777153",
      "id" : 1071019941065777153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dt0G9j6V4AEvZFv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1534
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1534
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/DNDyaUaCj0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071057021376569345",
  "text" : "RT @ashkatch: NORTHERN LIGHTS, LEVI, FINLAND https:\/\/t.co\/DNDyaUaCj0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ashkatch\/status\/1071019977615048704\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/DNDyaUaCj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dt0G9j6VAAADubF.jpg",
        "id_str" : "1071019941065719808",
        "id" : 1071019941065719808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dt0G9j6VAAADubF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/DNDyaUaCj0"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ashkatch\/status\/1071019977615048704\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/DNDyaUaCj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dt0G9j6V4AEvZFv.jpg",
        "id_str" : "1071019941065777153",
        "id" : 1071019941065777153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dt0G9j6V4AEvZFv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 899
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1534
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 509
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1534
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/DNDyaUaCj0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071019977615048704",
    "text" : "NORTHERN LIGHTS, LEVI, FINLAND https:\/\/t.co\/DNDyaUaCj0",
    "id" : 1071019977615048704,
    "created_at" : "2018-12-07 12:33:55 +0000",
    "user" : {
      "name" : "Ashley Katchadourian",
      "screen_name" : "ashkatch",
      "protected" : false,
      "id_str" : "47178606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1070466594613153792\/1odyIuNi_normal.jpg",
      "id" : 47178606,
      "verified" : false
    }
  },
  "id" : 1071057021376569345,
  "created_at" : "2018-12-07 15:01:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071056975595823104",
  "text" : "RT @TipsyBartender: Root Beer Float Jello Shots - These are perfect for a Friday night boozy dessert!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1071041642860146688",
    "text" : "Root Beer Float Jello Shots - These are perfect for a Friday night boozy dessert!",
    "id" : 1071041642860146688,
    "created_at" : "2018-12-07 14:00:01 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1071056975595823104,
  "created_at" : "2018-12-07 15:00:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070908518063112192",
  "text" : "RT @BTCticker: One Bitcoin now worth $3375.175. Market Cap $58.764 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070905777567776768",
    "text" : "One Bitcoin now worth $3375.175. Market Cap $58.764 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1070905777567776768,
    "created_at" : "2018-12-07 05:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070908518063112192,
  "created_at" : "2018-12-07 05:11:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 3, 14 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070904515631702016",
  "text" : "RT @MailOnline: World's first fully-functioning motorcycle made with the innovative method unveiled by German engineers https:\/\/t.co\/DND9GS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/DND9GSUraT",
        "expanded_url" : "https:\/\/dailym.ai\/2Rxgqzp",
        "display_url" : "dailym.ai\/2Rxgqzp"
      } ]
    },
    "geo" : { },
    "id_str" : "1070050370917937154",
    "text" : "World's first fully-functioning motorcycle made with the innovative method unveiled by German engineers https:\/\/t.co\/DND9GSUraT",
    "id" : 1070050370917937154,
    "created_at" : "2018-12-04 20:21:03 +0000",
    "user" : {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "protected" : false,
      "id_str" : "15438913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1062343276420833280\/ZcDwwG-p_normal.jpg",
      "id" : 15438913,
      "verified" : true
    }
  },
  "id" : 1070904515631702016,
  "created_at" : "2018-12-07 04:55:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim",
      "screen_name" : "MaximMag",
      "indices" : [ 3, 12 ],
      "id_str" : "18201114",
      "id" : 18201114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/xMoM98Scco",
      "expanded_url" : "https:\/\/www.maxim.com\/rides\/nera-e-bike-2018-11",
      "display_url" : "maxim.com\/rides\/nera-e-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070904472061259779",
  "text" : "RT @MaximMag: Check out pics and video of the first working motorcycle made entirely with a 3D printer.\nhttps:\/\/t.co\/xMoM98Scco",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/xMoM98Scco",
        "expanded_url" : "https:\/\/www.maxim.com\/rides\/nera-e-bike-2018-11",
        "display_url" : "maxim.com\/rides\/nera-e-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069637390883479553",
    "text" : "Check out pics and video of the first working motorcycle made entirely with a 3D printer.\nhttps:\/\/t.co\/xMoM98Scco",
    "id" : 1069637390883479553,
    "created_at" : "2018-12-03 17:00:01 +0000",
    "user" : {
      "name" : "Maxim",
      "screen_name" : "MaximMag",
      "protected" : false,
      "id_str" : "18201114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920032805693919232\/FWN6bElq_normal.jpg",
      "id" : 18201114,
      "verified" : true
    }
  },
  "id" : 1070904472061259779,
  "created_at" : "2018-12-07 04:54:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 80, 94 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070904027209195520",
  "text" : "RT @SpaceX: Dragon is on its way to the International Space Station. Capture by @Space_Station crew set for early Saturday morning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 68, 82 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070385014506844160",
    "text" : "Dragon is on its way to the International Space Station. Capture by @Space_Station crew set for early Saturday morning.",
    "id" : 1070385014506844160,
    "created_at" : "2018-12-05 18:30:48 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1070904027209195520,
  "created_at" : "2018-12-07 04:53:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "95023423",
      "id" : 95023423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070903831377182721",
  "text" : "RT @UberFacts: Playing video games can decrease the time it takes you to make decisions in real-life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070774133171085312",
    "text" : "Playing video games can decrease the time it takes you to make decisions in real-life.",
    "id" : 1070774133171085312,
    "created_at" : "2018-12-06 20:17:02 +0000",
    "user" : {
      "name" : "UberFacts",
      "screen_name" : "UberFacts",
      "protected" : false,
      "id_str" : "95023423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615696617165885440\/JDbUuo9H_normal.jpg",
      "id" : 95023423,
      "verified" : true
    }
  },
  "id" : 1070903831377182721,
  "created_at" : "2018-12-07 04:52:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/5FFpeBazBj",
      "expanded_url" : "https:\/\/trib.al\/fhXpLV5",
      "display_url" : "trib.al\/fhXpLV5"
    } ]
  },
  "geo" : { },
  "id_str" : "1070902836668588032",
  "text" : "RT @epicurious: Here\u2019s how to eat chestnuts without feeling like a woodland creature.\nhttps:\/\/t.co\/5FFpeBazBj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/5FFpeBazBj",
        "expanded_url" : "https:\/\/trib.al\/fhXpLV5",
        "display_url" : "trib.al\/fhXpLV5"
      } ]
    },
    "geo" : { },
    "id_str" : "1070902735204163584",
    "text" : "Here\u2019s how to eat chestnuts without feeling like a woodland creature.\nhttps:\/\/t.co\/5FFpeBazBj",
    "id" : 1070902735204163584,
    "created_at" : "2018-12-07 04:48:03 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1070902836668588032,
  "created_at" : "2018-12-07 04:48:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "php[architect]",
      "screen_name" : "phparch",
      "indices" : [ 3, 11 ],
      "id_str" : "42867427",
      "id" : 42867427
    }, {
      "name" : "MySQL",
      "screen_name" : "MySQL",
      "indices" : [ 104, 110 ],
      "id_str" : "44932521",
      "id" : 44932521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phpworld",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/RaXDBESshM",
      "expanded_url" : "https:\/\/buff.ly\/2M5b9vv",
      "display_url" : "buff.ly\/2M5b9vv"
    } ]
  },
  "geo" : { },
  "id_str" : "1070902791764353024",
  "text" : "RT @phparch: The world's most popular database was also this year's  #phpworld Training Sponsor. Thanks @MySQL! https:\/\/t.co\/RaXDBESshM htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MySQL",
        "screen_name" : "MySQL",
        "indices" : [ 91, 97 ],
        "id_str" : "44932521",
        "id" : 44932521
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phparch\/status\/1065012417044914176\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/SrNyBMzZ9K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DsevJikX4AAboV3.png",
        "id_str" : "1065012415329460224",
        "id" : 1065012415329460224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DsevJikX4AAboV3.png",
        "sizes" : [ {
          "h" : 570,
          "resize" : "fit",
          "w" : 1255
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 1255
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/SrNyBMzZ9K"
      } ],
      "hashtags" : [ {
        "text" : "phpworld",
        "indices" : [ 56, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/RaXDBESshM",
        "expanded_url" : "https:\/\/buff.ly\/2M5b9vv",
        "display_url" : "buff.ly\/2M5b9vv"
      } ]
    },
    "geo" : { },
    "id_str" : "1065012417044914176",
    "text" : "The world's most popular database was also this year's  #phpworld Training Sponsor. Thanks @MySQL! https:\/\/t.co\/RaXDBESshM https:\/\/t.co\/SrNyBMzZ9K",
    "id" : 1065012417044914176,
    "created_at" : "2018-11-20 22:42:01 +0000",
    "user" : {
      "name" : "php[architect]",
      "screen_name" : "phparch",
      "protected" : false,
      "id_str" : "42867427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3506410963\/3451e83c5c603ad57cf7c692c630c060_normal.png",
      "id" : 42867427,
      "verified" : false
    }
  },
  "id" : 1070902791764353024,
  "created_at" : "2018-12-07 04:48:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MySQL",
      "screen_name" : "MySQL",
      "indices" : [ 3, 9 ],
      "id_str" : "44932521",
      "id" : 44932521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070902633731362816",
  "text" : "RT @MySQL: VIDEO: Oracle Open World, MySQL Keynote. MySQL Analytics Service by Nipun Agarwal, VP Oracle Labs.\u00A0 Extreme performance with in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manage.involver.com\" rel=\"nofollow\"\u003EOracle Engage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 257, 280 ],
        "url" : "https:\/\/t.co\/kJXELopt3y",
        "expanded_url" : "http:\/\/ora.cl\/DP3pt",
        "display_url" : "ora.cl\/DP3pt"
      } ]
    },
    "geo" : { },
    "id_str" : "1070679284480647168",
    "text" : "VIDEO: Oracle Open World, MySQL Keynote. MySQL Analytics Service by Nipun Agarwal, VP Oracle Labs.\u00A0 Extreme performance with in memory analytics, fully integrated with MySQL, Real Time SQL Analytics, designed for massive elasticity. Watch it to learn more. https:\/\/t.co\/kJXELopt3y",
    "id" : 1070679284480647168,
    "created_at" : "2018-12-06 14:00:08 +0000",
    "user" : {
      "name" : "MySQL",
      "screen_name" : "MySQL",
      "protected" : false,
      "id_str" : "44932521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1240079072\/logo-mysql-170x170_normal.png",
      "id" : 44932521,
      "verified" : false
    }
  },
  "id" : 1070902633731362816,
  "created_at" : "2018-12-07 04:47:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070902337017995264",
  "text" : "RT @JayHoque: New Nikon Z 50mm f\/1.8 S lens review and comparison with the Sigma 50mm f\/1.4 DG HSM Art lens (Nikon wins): https:\/\/t.co\/P7Xi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/P7XikbWCIU",
        "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/06\/new-nikon-z-50mm-f-1-8-s-lens-review-and-comparison-with-the-sigma-50mm-f-1-4-dg-hsm-art-lens-nikon-wins.aspx\/",
        "display_url" : "nikonrumors.com\/2018\/12\/06\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070893950037356544",
    "text" : "New Nikon Z 50mm f\/1.8 S lens review and comparison with the Sigma 50mm f\/1.4 DG HSM Art lens (Nikon wins): https:\/\/t.co\/P7XikbWCIU",
    "id" : 1070893950037356544,
    "created_at" : "2018-12-07 04:13:08 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1070902337017995264,
  "created_at" : "2018-12-07 04:46:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070901502515048448",
  "text" : "Tech-wise been getting a lot done",
  "id" : 1070901502515048448,
  "created_at" : "2018-12-07 04:43:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/hlHVYd4YBq",
      "expanded_url" : "http:\/\/wecrypto.net",
      "display_url" : "wecrypto.net"
    } ]
  },
  "geo" : { },
  "id_str" : "1070901433447391232",
  "text" : "On my bucket list upgrading wecrypto, don't worry via https:\/\/t.co\/hlHVYd4YBq :)",
  "id" : 1070901433447391232,
  "created_at" : "2018-12-07 04:42:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/NKQuHnGCkd",
      "expanded_url" : "http:\/\/Minds.com",
      "display_url" : "Minds.com"
    }, {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/HTB7jwiyvC",
      "expanded_url" : "https:\/\/www.minds.com\/newsfeed\/917636639627890688",
      "display_url" : "minds.com\/newsfeed\/91763\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070901302778101761",
  "text" : "Shared via https:\/\/t.co\/NKQuHnGCkd https:\/\/t.co\/HTB7jwiyvC",
  "id" : 1070901302778101761,
  "created_at" : "2018-12-07 04:42:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Mayer",
      "screen_name" : "ashleymayer",
      "indices" : [ 3, 15 ],
      "id_str" : "18994034",
      "id" : 18994034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070867101005594626",
  "text" : "RT @ashleymayer: Today in NYC adventures I learned about express trains and how they don't make all the stops. \uD83D\uDE33",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070864567121690624",
    "text" : "Today in NYC adventures I learned about express trains and how they don't make all the stops. \uD83D\uDE33",
    "id" : 1070864567121690624,
    "created_at" : "2018-12-07 02:16:23 +0000",
    "user" : {
      "name" : "Ashley Mayer",
      "screen_name" : "ashleymayer",
      "protected" : false,
      "id_str" : "18994034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1033227403282153472\/zdfIv_-o_normal.jpg",
      "id" : 18994034,
      "verified" : false
    }
  },
  "id" : 1070867101005594626,
  "created_at" : "2018-12-07 02:26:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070867083188150273",
  "text" : "RT @BTCticker: One Bitcoin now worth $3379.808. Market Cap $58.844 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070860472704995328",
    "text" : "One Bitcoin now worth $3379.808. Market Cap $58.844 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1070860472704995328,
    "created_at" : "2018-12-07 02:00:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070867083188150273,
  "created_at" : "2018-12-07 02:26:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070857697321517061",
  "text" : "RT @BTCticker: One Bitcoin now worth $3341.793. Market Cap $58.182 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070852932332150787",
    "text" : "One Bitcoin now worth $3341.793. Market Cap $58.182 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1070852932332150787,
    "created_at" : "2018-12-07 01:30:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070857697321517061,
  "created_at" : "2018-12-07 01:49:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/PZVtxRB9iK",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/06\/elon-musk-la-test-tunnel-opening-date\/",
      "display_url" : "engadget.com\/2018\/12\/06\/elo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070857650848628736",
  "text" : "RT @engadget: Boring Company's LA tunnel event set for December 18th https:\/\/t.co\/PZVtxRB9iK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/PZVtxRB9iK",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/06\/elon-musk-la-test-tunnel-opening-date\/",
        "display_url" : "engadget.com\/2018\/12\/06\/elo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070855281079476224",
    "text" : "Boring Company's LA tunnel event set for December 18th https:\/\/t.co\/PZVtxRB9iK",
    "id" : 1070855281079476224,
    "created_at" : "2018-12-07 01:39:29 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1070857650848628736,
  "created_at" : "2018-12-07 01:48:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Sciutto",
      "screen_name" : "jimsciutto",
      "indices" : [ 3, 14 ],
      "id_str" : "22129280",
      "id" : 22129280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070857570104082432",
  "text" : "RT @jimsciutto: Dow Jones down 500 points - market is now negative for 2018.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070706602955689985",
    "text" : "Dow Jones down 500 points - market is now negative for 2018.",
    "id" : 1070706602955689985,
    "created_at" : "2018-12-06 15:48:41 +0000",
    "user" : {
      "name" : "Jim Sciutto",
      "screen_name" : "jimsciutto",
      "protected" : false,
      "id_str" : "22129280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1069665522575441920\/Jw0szR_X_normal.jpg",
      "id" : 22129280,
      "verified" : true
    }
  },
  "id" : 1070857570104082432,
  "created_at" : "2018-12-07 01:48:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Caltech",
      "screen_name" : "Caltech",
      "indices" : [ 95, 103 ],
      "id_str" : "16536844",
      "id" : 16536844
    }, {
      "name" : "Science Magazine",
      "screen_name" : "sciencemagazine",
      "indices" : [ 104, 120 ],
      "id_str" : "32372834",
      "id" : 32372834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fluoride",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070857519441084417",
  "text" : "RT @TechXplore_com: New battery concept based on #fluoride ions may increase battery lifespans @Caltech @sciencemagazine https:\/\/t.co\/oNmzs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caltech",
        "screen_name" : "Caltech",
        "indices" : [ 75, 83 ],
        "id_str" : "16536844",
        "id" : 16536844
      }, {
        "name" : "Science Magazine",
        "screen_name" : "sciencemagazine",
        "indices" : [ 84, 100 ],
        "id_str" : "32372834",
        "id" : 32372834
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fluoride",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/oNmzsN7Xp7",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-12-battery-concept-based-fluoride-ions.html",
        "display_url" : "techxplore.com\/news\/2018-12-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070754764563062784",
    "text" : "New battery concept based on #fluoride ions may increase battery lifespans @Caltech @sciencemagazine https:\/\/t.co\/oNmzsN7Xp7",
    "id" : 1070754764563062784,
    "created_at" : "2018-12-06 19:00:04 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1070857519441084417,
  "created_at" : "2018-12-07 01:48:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070857492480045063",
  "text" : "RT @TipsyBartender: Watermelon Hennyrita - one delicious watermelon cocktail",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070852391518359553",
    "text" : "Watermelon Hennyrita - one delicious watermelon cocktail",
    "id" : 1070852391518359553,
    "created_at" : "2018-12-07 01:28:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1070857492480045063,
  "created_at" : "2018-12-07 01:48:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "instafood",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/ZqzMbI9GWL",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrEXX0UF1hq\/?utm_source=ig_twitter_share&igshid=17efvu156htph",
      "display_url" : "instagram.com\/p\/BrEXX0UF1hq\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070857290138509313",
  "text" : "Friend bananas are awesome :) #foodie #instafood https:\/\/t.co\/ZqzMbI9GWL",
  "id" : 1070857290138509313,
  "created_at" : "2018-12-07 01:47:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "instafood",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0BGQZhx3P4",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrEXPtul1op\/?utm_source=ig_twitter_share&igshid=kiqy5p9k9pqi",
      "display_url" : "instagram.com\/p\/BrEXPtul1op\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070857062475882496",
  "text" : "Cookies, cookies, cookie #foodie #instafood https:\/\/t.co\/0BGQZhx3P4",
  "id" : 1070857062475882496,
  "created_at" : "2018-12-07 01:46:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 8, 15 ]
    }, {
      "text" : "instafood",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/jjb7FhhilU",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrEXKUWFxRU\/?utm_source=ig_twitter_share&igshid=16bfv8ueb3h0x",
      "display_url" : "instagram.com\/p\/BrEXKUWFxRU\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070856828219809793",
  "text" : "Not bad #foodie #instafood https:\/\/t.co\/jjb7FhhilU",
  "id" : 1070856828219809793,
  "created_at" : "2018-12-07 01:45:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unorganized & Lost",
      "screen_name" : "unorganzed_lost",
      "indices" : [ 3, 19 ],
      "id_str" : "765404118223433728",
      "id" : 765404118223433728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070850218780975104",
  "text" : "RT @unorganzed_lost: \"Excuses are born out of fear. Eliminate your fear and there will be no excuses.\" \u2014Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070730621255745542",
    "text" : "\"Excuses are born out of fear. Eliminate your fear and there will be no excuses.\" \u2014Unknown",
    "id" : 1070730621255745542,
    "created_at" : "2018-12-06 17:24:07 +0000",
    "user" : {
      "name" : "Unorganized & Lost",
      "screen_name" : "unorganzed_lost",
      "protected" : false,
      "id_str" : "765404118223433728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/902412049954643968\/U0bPBGl-_normal.jpg",
      "id" : 765404118223433728,
      "verified" : false
    }
  },
  "id" : 1070850218780975104,
  "created_at" : "2018-12-07 01:19:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070850105828364289",
  "text" : "RT @elonmusk: Boring Company product launch on Dec 18. More than a tunnel opening. Will include modded but fully road legal autonomous tran\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070834865619259393",
    "text" : "Boring Company product launch on Dec 18. More than a tunnel opening. Will include modded but fully road legal autonomous transport cars &amp; ground to tunnel car elevators.",
    "id" : 1070834865619259393,
    "created_at" : "2018-12-07 00:18:21 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1070850105828364289,
  "created_at" : "2018-12-07 01:18:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070850056528543744",
  "text" : "Really excited that Stark Drones is going places",
  "id" : 1070850056528543744,
  "created_at" : "2018-12-07 01:18:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/MXxQJNidMK",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/01\/american-tamale-pie-food-lab.html",
      "display_url" : "seriouseats.com\/2015\/01\/americ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070832416712024065",
  "text" : "RT @seriouseats: Cornbread AND chili in one dish. https:\/\/t.co\/MXxQJNidMK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/MXxQJNidMK",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2015\/01\/american-tamale-pie-food-lab.html",
        "display_url" : "seriouseats.com\/2015\/01\/americ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070786574126866432",
    "text" : "Cornbread AND chili in one dish. https:\/\/t.co\/MXxQJNidMK",
    "id" : 1070786574126866432,
    "created_at" : "2018-12-06 21:06:28 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1070832416712024065,
  "created_at" : "2018-12-07 00:08:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070832370624970752",
  "text" : "RT @BTCticker: One Bitcoin now worth $3477.490. Market Cap $60.545 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070830272558628865",
    "text" : "One Bitcoin now worth $3477.490. Market Cap $60.545 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1070830272558628865,
    "created_at" : "2018-12-07 00:00:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070832370624970752,
  "created_at" : "2018-12-07 00:08:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "indices" : [ 3, 18 ],
      "id_str" : "2471009922",
      "id" : 2471009922
    }, {
      "name" : "Massachusetts Institute of Technology (MIT)",
      "screen_name" : "MIT",
      "indices" : [ 78, 82 ],
      "id_str" : "15460048",
      "id" : 15460048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/s5fkc6Vg6D",
      "expanded_url" : "https:\/\/techxplore.com\/news\/2018-12-sun-renewable-energy-grid.html",
      "display_url" : "techxplore.com\/news\/2018-12-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070700788081704960",
  "text" : "RT @TechXplore_com: 'Sun in a box' would store renewable #energy for the grid @MIT https:\/\/t.co\/s5fkc6Vg6D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Massachusetts Institute of Technology (MIT)",
        "screen_name" : "MIT",
        "indices" : [ 58, 62 ],
        "id_str" : "15460048",
        "id" : 15460048
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 37, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/s5fkc6Vg6D",
        "expanded_url" : "https:\/\/techxplore.com\/news\/2018-12-sun-renewable-energy-grid.html",
        "display_url" : "techxplore.com\/news\/2018-12-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070578070686441472",
    "text" : "'Sun in a box' would store renewable #energy for the grid @MIT https:\/\/t.co\/s5fkc6Vg6D",
    "id" : 1070578070686441472,
    "created_at" : "2018-12-06 07:17:57 +0000",
    "user" : {
      "name" : "TechXplore",
      "screen_name" : "TechXplore_com",
      "protected" : false,
      "id_str" : "2471009922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462146809729519616\/Ri81vCkn_normal.png",
      "id" : 2471009922,
      "verified" : false
    }
  },
  "id" : 1070700788081704960,
  "created_at" : "2018-12-06 15:25:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/mQ7NLPdeh9",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2017\/12\/how-to-make-sous-vide-duck-confit.html",
      "display_url" : "seriouseats.com\/2017\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070700761955356673",
  "text" : "RT @seriouseats: Far easier than the traditional method. https:\/\/t.co\/mQ7NLPdeh9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/mQ7NLPdeh9",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2017\/12\/how-to-make-sous-vide-duck-confit.html",
        "display_url" : "seriouseats.com\/2017\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070696045775151104",
    "text" : "Far easier than the traditional method. https:\/\/t.co\/mQ7NLPdeh9",
    "id" : 1070696045775151104,
    "created_at" : "2018-12-06 15:06:44 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1070700761955356673,
  "created_at" : "2018-12-06 15:25:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instafood",
      "indices" : [ 32, 42 ]
    }, {
      "text" : "foodie",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/pUVg3wn0Vs",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrB2Vlel3hY\/?utm_source=ig_twitter_share&igshid=1lq12y8pcut87",
      "display_url" : "instagram.com\/p\/BrB2Vlel3hY\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070503617717784576",
  "text" : "Throw back to this master piece #instafood #foodie https:\/\/t.co\/pUVg3wn0Vs",
  "id" : 1070503617717784576,
  "created_at" : "2018-12-06 02:22:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instafood",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "foodie",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "foodchats",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/xRj7BpyLv5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrB2e2LFJxZ\/?utm_source=ig_twitter_share&igshid=1kqiu8jmwqzms",
      "display_url" : "instagram.com\/p\/BrB2e2LFJxZ\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070503499337592832",
  "text" : "Another throw back to a Philly I had #instafood #foodie #foodchats https:\/\/t.co\/xRj7BpyLv5",
  "id" : 1070503499337592832,
  "created_at" : "2018-12-06 02:21:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instafood",
      "indices" : [ 11, 21 ]
    }, {
      "text" : "foodie",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/DxGkumf7Xl",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrB2HwilxgL\/?utm_source=ig_twitter_share&igshid=cl499kmv2ujd",
      "display_url" : "instagram.com\/p\/BrB2HwilxgL\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070502699777568768",
  "text" : "Throw back #instafood #foodie https:\/\/t.co\/DxGkumf7Xl",
  "id" : 1070502699777568768,
  "created_at" : "2018-12-06 02:18:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "instafood",
      "indices" : [ 100, 110 ]
    }, {
      "text" : "foodpics",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/YkypzQDMZP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrB1w_lFa6A\/?utm_source=ig_twitter_share&igshid=11pjq01uju0cf",
      "display_url" : "instagram.com\/p\/BrB1w_lFa6A\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070501923206414336",
  "text" : "This is an old photo I have to remind everyone how much I like the sweet soft sugary butter #foodie #instafood #foodpics https:\/\/t.co\/YkypzQDMZP",
  "id" : 1070501923206414336,
  "created_at" : "2018-12-06 02:15:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070462044066013184",
  "text" : "RT @BTCticker: One Bitcoin now worth $3765.025. Market Cap $65.545 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070460343003037696",
    "text" : "One Bitcoin now worth $3765.025. Market Cap $65.545 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1070460343003037696,
    "created_at" : "2018-12-05 23:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070462044066013184,
  "created_at" : "2018-12-05 23:36:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070462005839060992",
  "text" : "RT @BTCticker: One Bitcoin now worth $3729.61@bitstamp. High $3913.620. Low $3662.350. Market Cap $64.922 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070460342147399680",
    "text" : "One Bitcoin now worth $3729.61@bitstamp. High $3913.620. Low $3662.350. Market Cap $64.922 Billion #bitcoin",
    "id" : 1070460342147399680,
    "created_at" : "2018-12-05 23:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070462005839060992,
  "created_at" : "2018-12-05 23:36:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070461938801479683",
  "text" : "RT @elonmusk: Engines stabilized rocket spin just in time, enabling an intact landing in water! Ships en route to rescue Falcon. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/1070399755526656000\/video\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/O3h8eCgGJ7",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070399664875130881\/pu\/img\/kXUcn0crNpIhUM-z.jpg",
        "id_str" : "1070399664875130881",
        "id" : 1070399664875130881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070399664875130881\/pu\/img\/kXUcn0crNpIhUM-z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/O3h8eCgGJ7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070399755526656000",
    "text" : "Engines stabilized rocket spin just in time, enabling an intact landing in water! Ships en route to rescue Falcon. https:\/\/t.co\/O3h8eCgGJ7",
    "id" : 1070399755526656000,
    "created_at" : "2018-12-05 19:29:23 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1070461938801479683,
  "created_at" : "2018-12-05 23:36:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "indices" : [ 3, 15 ],
      "id_str" : "30278532",
      "id" : 30278532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070461846954610688",
  "text" : "RT @foodandwine: The trick to these biscuits is baking them on a pile of grated cheddar, so the cheese melts, caramelizes, and results in c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/DY9FxLbhqN",
        "expanded_url" : "https:\/\/trib.al\/tRz4GgU",
        "display_url" : "trib.al\/tRz4GgU"
      } ]
    },
    "geo" : { },
    "id_str" : "1070360111095398406",
    "text" : "The trick to these biscuits is baking them on a pile of grated cheddar, so the cheese melts, caramelizes, and results in crispy, toasty \u201Cfeet.\u201D https:\/\/t.co\/DY9FxLbhqN",
    "id" : 1070360111095398406,
    "created_at" : "2018-12-05 16:51:51 +0000",
    "user" : {
      "name" : "Food & Wine",
      "screen_name" : "foodandwine",
      "protected" : false,
      "id_str" : "30278532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738810295301246977\/sJKDqlWh_normal.jpg",
      "id" : 30278532,
      "verified" : true
    }
  },
  "id" : 1070461846954610688,
  "created_at" : "2018-12-05 23:36:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/83r8MPDgTo",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/12\/how-to-make-hobak-beombeok.html",
      "display_url" : "seriouseats.com\/2018\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070461784153358337",
  "text" : "RT @seriouseats: A perfect \"something sweet\" for cold winter mornings. https:\/\/t.co\/83r8MPDgTo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/83r8MPDgTo",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2018\/12\/how-to-make-hobak-beombeok.html",
        "display_url" : "seriouseats.com\/2018\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070362166577033222",
    "text" : "A perfect \"something sweet\" for cold winter mornings. https:\/\/t.co\/83r8MPDgTo",
    "id" : 1070362166577033222,
    "created_at" : "2018-12-05 17:00:01 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1070461784153358337,
  "created_at" : "2018-12-05 23:35:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/1070446975642812416\/video\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/6Hv2aZhLjM",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070446808147476480\/pu\/img\/WNRGSJNN4p7AlSU1.jpg",
      "id_str" : "1070446808147476480",
      "id" : 1070446808147476480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070446808147476480\/pu\/img\/WNRGSJNN4p7AlSU1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/6Hv2aZhLjM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070461710702649344",
  "text" : "RT @elonmusk: Tracking shot of Falcon water landing https:\/\/t.co\/6Hv2aZhLjM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/elonmusk\/status\/1070446975642812416\/video\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/6Hv2aZhLjM",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070446808147476480\/pu\/img\/WNRGSJNN4p7AlSU1.jpg",
        "id_str" : "1070446808147476480",
        "id" : 1070446808147476480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1070446808147476480\/pu\/img\/WNRGSJNN4p7AlSU1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/6Hv2aZhLjM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070446975642812416",
    "text" : "Tracking shot of Falcon water landing https:\/\/t.co\/6Hv2aZhLjM",
    "id" : 1070446975642812416,
    "created_at" : "2018-12-05 22:37:01 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1070461710702649344,
  "created_at" : "2018-12-05 23:35:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070461611037609985",
  "text" : "RT @elonmusk: Grid fin hydraulic pump stalled, so Falcon landed just out to sea. Appears to be undamaged &amp; is transmitting data. Recovery s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070386062164283392",
    "text" : "Grid fin hydraulic pump stalled, so Falcon landed just out to sea. Appears to be undamaged &amp; is transmitting data. Recovery ship dispatched.",
    "id" : 1070386062164283392,
    "created_at" : "2018-12-05 18:34:58 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1070461611037609985,
  "created_at" : "2018-12-05 23:35:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070461544662749184",
  "text" : "RT @seriouseats: Complex, beefy, buttery, oozing with juices, and packed with flavor. It's hard to get more opulent than this.\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/GVuwBT2A2J",
        "expanded_url" : "https:\/\/www.seriouseats.com\/recipes\/2012\/12\/the-ultimate-beef-wellington-recipe.html",
        "display_url" : "seriouseats.com\/recipes\/2012\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1070460309029023744",
    "text" : "Complex, beefy, buttery, oozing with juices, and packed with flavor. It's hard to get more opulent than this.\nhttps:\/\/t.co\/GVuwBT2A2J",
    "id" : 1070460309029023744,
    "created_at" : "2018-12-05 23:30:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1070461544662749184,
  "created_at" : "2018-12-05 23:34:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 14, 21 ]
    }, {
      "text" : "instafood",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "foodchats",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/GjFlr8DyXZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrBjSSbl5x9\/?utm_source=ig_twitter_share&igshid=nrho83hj5wys",
      "display_url" : "instagram.com\/p\/BrBjSSbl5x9\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070461291884556288",
  "text" : "This is sushi #foodie #instafood #foodchats https:\/\/t.co\/GjFlr8DyXZ",
  "id" : 1070461291884556288,
  "created_at" : "2018-12-05 23:33:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "instafood",
      "indices" : [ 49, 59 ]
    }, {
      "text" : "foodchats",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NGbKUVtPYf",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BrBjL7dF6zw\/?utm_source=ig_twitter_share&igshid=1d84lsbscrf8h",
      "display_url" : "instagram.com\/p\/BrBjL7dF6zw\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070461278399983616",
  "text" : "Someone was eating soup and it wasn't me #foodie #instafood #foodchats https:\/\/t.co\/NGbKUVtPYf",
  "id" : 1070461278399983616,
  "created_at" : "2018-12-05 23:33:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodie",
      "indices" : [ 135, 142 ]
    }, {
      "text" : "instafood",
      "indices" : [ 143, 153 ]
    } ],
    "urls" : [ {
      "indices" : [ 154, 177 ],
      "url" : "https:\/\/t.co\/f9Uqzwglmb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bq_MaQrl2Ss\/?utm_source=ig_twitter_share&igshid=1w307abvgity7",
      "display_url" : "instagram.com\/p\/Bq_MaQrl2Ss\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1070129508769021952",
  "text" : "A fan told me to post a picture of their plate because they wants their food to almost get as much spotlight as my more delicious food #foodie #instafood https:\/\/t.co\/f9Uqzwglmb",
  "id" : 1070129508769021952,
  "created_at" : "2018-12-05 01:35:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070076872283832320",
  "text" : "RT @BarbaraCorcoran: Talkers never get ahead. Only the doers do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070060552750317568",
    "text" : "Talkers never get ahead. Only the doers do.",
    "id" : 1070060552750317568,
    "created_at" : "2018-12-04 21:01:31 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1070076872283832320,
  "created_at" : "2018-12-04 22:06:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070042444450930689",
  "text" : "RT @MikeWShell: If you aren\u2019t going to buy or sell, get away from the screen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070034993311821824",
    "text" : "If you aren\u2019t going to buy or sell, get away from the screen.",
    "id" : 1070034993311821824,
    "created_at" : "2018-12-04 19:19:57 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1070042444450930689,
  "created_at" : "2018-12-04 19:49:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070022997870870528",
  "text" : "RT @BTCticker: One Bitcoin now worth $3912.62@bitstamp. High $4033.980. Low $3730.000. Market Cap $68.101 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1070022451722158081",
    "text" : "One Bitcoin now worth $3912.62@bitstamp. High $4033.980. Low $3730.000. Market Cap $68.101 Billion #bitcoin",
    "id" : 1070022451722158081,
    "created_at" : "2018-12-04 18:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1070022997870870528,
  "created_at" : "2018-12-04 18:32:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    }, {
      "name" : "OnDeck",
      "screen_name" : "OnDeckCapital",
      "indices" : [ 102, 116 ],
      "id_str" : "20105935",
      "id" : 20105935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069990426873077762",
  "text" : "RT @BarbaraCorcoran: Got a question about financing or business loans? Ask me here, and my friends at @OnDeckCapital and I will answer on m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OnDeck",
        "screen_name" : "OnDeckCapital",
        "indices" : [ 81, 95 ],
        "id_str" : "20105935",
        "id" : 20105935
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BusinessUnusual",
        "indices" : [ 129, 145 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069969844416716801",
    "text" : "Got a question about financing or business loans? Ask me here, and my friends at @OnDeckCapital and I will answer on my podcast, #BusinessUnusual!",
    "id" : 1069969844416716801,
    "created_at" : "2018-12-04 15:01:04 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1069990426873077762,
  "created_at" : "2018-12-04 16:22:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "indices" : [ 3, 18 ],
      "id_str" : "234985874",
      "id" : 234985874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069990413237411845",
  "text" : "RT @TipsyBartender: Soco Lime Peach Shot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads-api.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069979641497178112",
    "text" : "Soco Lime Peach Shot",
    "id" : 1069979641497178112,
    "created_at" : "2018-12-04 15:40:00 +0000",
    "user" : {
      "name" : "Tipsy Bartender",
      "screen_name" : "TipsyBartender",
      "protected" : false,
      "id_str" : "234985874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/956687531482861568\/Onu8O_Nv_normal.jpg",
      "id" : 234985874,
      "verified" : true
    }
  },
  "id" : 1069990413237411845,
  "created_at" : "2018-12-04 16:22:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069804204955447296",
  "text" : "RT @BarbaraCorcoran: There\u2019s no such thing as an overnight success. I can show you my scars of a thousand things that didn\u2019t work, and just\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069728266624425990",
    "text" : "There\u2019s no such thing as an overnight success. I can show you my scars of a thousand things that didn\u2019t work, and just a handful of things that did.",
    "id" : 1069728266624425990,
    "created_at" : "2018-12-03 23:01:08 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1069804204955447296,
  "created_at" : "2018-12-04 04:02:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069804125280497665",
  "text" : "RT @BTCticker: One Bitcoin now worth $3834.803. Market Cap $66.748 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069803512647872513",
    "text" : "One Bitcoin now worth $3834.803. Market Cap $66.748 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069803512647872513,
    "created_at" : "2018-12-04 04:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069804125280497665,
  "created_at" : "2018-12-04 04:02:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/dIFd35i7JY",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/03\/microsoft-chrome-browser\/",
      "display_url" : "engadget.com\/2018\/12\/03\/mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069796327977037825",
  "text" : "RT @engadget: Microsoft rumor points to a Chromium replacement for Edge https:\/\/t.co\/dIFd35i7JY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/dIFd35i7JY",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/03\/microsoft-chrome-browser\/",
        "display_url" : "engadget.com\/2018\/12\/03\/mic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069789223547478017",
    "text" : "Microsoft rumor points to a Chromium replacement for Edge https:\/\/t.co\/dIFd35i7JY",
    "id" : 1069789223547478017,
    "created_at" : "2018-12-04 03:03:21 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1069796327977037825,
  "created_at" : "2018-12-04 03:31:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Network",
      "screen_name" : "FoodNetwork",
      "indices" : [ 3, 15 ],
      "id_str" : "20710809",
      "id" : 20710809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HolidayBakingChampionship",
      "indices" : [ 75, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069796164701184000",
  "text" : "RT @FoodNetwork: What\u2019s your hands-down absolute FAVORITE holiday dessert? #HolidayBakingChampionship",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HolidayBakingChampionship",
        "indices" : [ 58, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069773583759626241",
    "text" : "What\u2019s your hands-down absolute FAVORITE holiday dessert? #HolidayBakingChampionship",
    "id" : 1069773583759626241,
    "created_at" : "2018-12-04 02:01:12 +0000",
    "user" : {
      "name" : "Food Network",
      "screen_name" : "FoodNetwork",
      "protected" : false,
      "id_str" : "20710809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1067096807325360129\/xFuN3dHR_normal.jpg",
      "id" : 20710809,
      "verified" : true
    }
  },
  "id" : 1069796164701184000,
  "created_at" : "2018-12-04 03:30:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069796159504420864",
  "text" : "RT @BTCticker: One Bitcoin now worth $3838.675. Market Cap $66.815 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069795963819229184",
    "text" : "One Bitcoin now worth $3838.675. Market Cap $66.815 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069795963819229184,
    "created_at" : "2018-12-04 03:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069796159504420864,
  "created_at" : "2018-12-04 03:30:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "indices" : [ 3, 12 ],
      "id_str" : "14607140",
      "id" : 14607140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "electronic",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/RmhCarT9Sc",
      "expanded_url" : "https:\/\/wp.me\/pk3lN-1pdv",
      "display_url" : "wp.me\/pk3lN-1pdv"
    } ]
  },
  "geo" : { },
  "id_str" : "1069795696671363072",
  "text" : "RT @hackaday: New #electronic transistors use thin air https:\/\/t.co\/RmhCarT9Sc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "electronic",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/RmhCarT9Sc",
        "expanded_url" : "https:\/\/wp.me\/pk3lN-1pdv",
        "display_url" : "wp.me\/pk3lN-1pdv"
      } ]
    },
    "geo" : { },
    "id_str" : "1069788501468766215",
    "text" : "New #electronic transistors use thin air https:\/\/t.co\/RmhCarT9Sc",
    "id" : 1069788501468766215,
    "created_at" : "2018-12-04 03:00:29 +0000",
    "user" : {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "protected" : false,
      "id_str" : "14607140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699222440702926848\/8Pm7yZFb_normal.png",
      "id" : 14607140,
      "verified" : true
    }
  },
  "id" : 1069795696671363072,
  "created_at" : "2018-12-04 03:29:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069795636994850816",
  "text" : "RT @BTCticker: One Bitcoin now worth $3856.367. Market Cap $67.123 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069788411920347137",
    "text" : "One Bitcoin now worth $3856.367. Market Cap $67.123 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069788411920347137,
    "created_at" : "2018-12-04 03:00:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069795636994850816,
  "created_at" : "2018-12-04 03:28:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/DiESgVKhs1",
      "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/03\/nikon-lens-only-rebates-now-expired-free-battery-grip-offer-extended.aspx\/",
      "display_url" : "nikonrumors.com\/2018\/12\/03\/nik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069795626899116032",
  "text" : "RT @JayHoque: Nikon US lens-only rebates now expired, free battery grip offer extended: https:\/\/t.co\/DiESgVKhs1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/DiESgVKhs1",
        "expanded_url" : "https:\/\/nikonrumors.com\/2018\/12\/03\/nikon-lens-only-rebates-now-expired-free-battery-grip-offer-extended.aspx\/",
        "display_url" : "nikonrumors.com\/2018\/12\/03\/nik\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069794529363009537",
    "text" : "Nikon US lens-only rebates now expired, free battery grip offer extended: https:\/\/t.co\/DiESgVKhs1",
    "id" : 1069794529363009537,
    "created_at" : "2018-12-04 03:24:26 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1069795626899116032,
  "created_at" : "2018-12-04 03:28:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069781757128597505",
  "text" : "RT @BTCticker: One Bitcoin now worth $3865.210. Market Cap $67.276 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069780859400675328",
    "text" : "One Bitcoin now worth $3865.210. Market Cap $67.276 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069780859400675328,
    "created_at" : "2018-12-04 02:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069781757128597505,
  "created_at" : "2018-12-04 02:33:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/yhBQIf6wUM",
      "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1069675820770222080",
      "display_url" : "twitter.com\/SpaceX\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069779347836420096",
  "text" : "RT @elonmusk: 64 satellites \uD83D\uDEF0 on this flight! https:\/\/t.co\/yhBQIf6wUM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/yhBQIf6wUM",
        "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1069675820770222080",
        "display_url" : "twitter.com\/SpaceX\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069678336886984704",
    "text" : "64 satellites \uD83D\uDEF0 on this flight! https:\/\/t.co\/yhBQIf6wUM",
    "id" : 1069678336886984704,
    "created_at" : "2018-12-03 19:42:43 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1069779347836420096,
  "created_at" : "2018-12-04 02:24:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "indices" : [ 3, 12 ],
      "id_str" : "14607140",
      "id" : 14607140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/uyWdFNTWR5",
      "expanded_url" : "https:\/\/wp.me\/pk3lN-1pdL",
      "display_url" : "wp.me\/pk3lN-1pdL"
    } ]
  },
  "geo" : { },
  "id_str" : "1069779262662733826",
  "text" : "RT @hackaday: The Etch-a-Sketch updated for the cell phone generation. https:\/\/t.co\/uyWdFNTWR5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/uyWdFNTWR5",
        "expanded_url" : "https:\/\/wp.me\/pk3lN-1pdL",
        "display_url" : "wp.me\/pk3lN-1pdL"
      } ]
    },
    "geo" : { },
    "id_str" : "1069698070793895940",
    "text" : "The Etch-a-Sketch updated for the cell phone generation. https:\/\/t.co\/uyWdFNTWR5",
    "id" : 1069698070793895940,
    "created_at" : "2018-12-03 21:01:08 +0000",
    "user" : {
      "name" : "hackaday",
      "screen_name" : "hackaday",
      "protected" : false,
      "id_str" : "14607140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699222440702926848\/8Pm7yZFb_normal.png",
      "id" : 14607140,
      "verified" : true
    }
  },
  "id" : 1069779262662733826,
  "created_at" : "2018-12-04 02:23:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Kennedy \/ KSC",
      "screen_name" : "NASAKennedy",
      "indices" : [ 3, 15 ],
      "id_str" : "16580226",
      "id" : 16580226
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 123, 130 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069778535676547072",
  "text" : "RT @NASAKennedy: We are currently sitting at a 60% chance of favorable weather for liftoffof the Falcon 9 rocket launching @SpaceX CRS-16 t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 106, 113 ],
        "id_str" : "34743251",
        "id" : 34743251
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 128, 142 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NASAsocial",
        "indices" : [ 173, 184 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069628639929618432",
    "text" : "We are currently sitting at a 60% chance of favorable weather for liftoffof the Falcon 9 rocket launching @SpaceX CRS-16 to the @Space_Station tomorrow, Dec 4 @ 1:38pm ET.  #NASAsocial",
    "id" : 1069628639929618432,
    "created_at" : "2018-12-03 16:25:15 +0000",
    "user" : {
      "name" : "NASA Kennedy \/ KSC",
      "screen_name" : "NASAKennedy",
      "protected" : false,
      "id_str" : "16580226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456408200464433153\/X9YbZm5q_normal.jpeg",
      "id" : 16580226,
      "verified" : true
    }
  },
  "id" : 1069778535676547072,
  "created_at" : "2018-12-04 02:20:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ISS National Lab",
      "screen_name" : "ISS_CASIS",
      "indices" : [ 3, 13 ],
      "id_str" : "188046098",
      "id" : 188046098
    }, {
      "name" : "Marvel Entertainment",
      "screen_name" : "Marvel",
      "indices" : [ 121, 128 ],
      "id_str" : "15687962",
      "id" : 15687962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069778353501147141",
  "text" : "RT @ISS_CASIS: The winners of the 'Guardians of the Galaxy Space Station Challenge', presented by ISS National Lab &amp; @Marvel, developed inn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marvel Entertainment",
        "screen_name" : "Marvel",
        "indices" : [ 106, 113 ],
        "id_str" : "15687962",
        "id" : 15687962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 165, 170 ]
      }, {
        "text" : "biology",
        "indices" : [ 175, 183 ]
      }, {
        "text" : "TeamRocket",
        "indices" : [ 224, 235 ]
      }, {
        "text" : "TeamGroot",
        "indices" : [ 240, 250 ]
      } ],
      "urls" : [ {
        "indices" : [ 252, 275 ],
        "url" : "https:\/\/t.co\/wndhyW569a",
        "expanded_url" : "https:\/\/www.iss-casis.org\/press-releases\/two-student-projects-selected-from-guardians-of-the-galaxy-space-station-challenge\/",
        "display_url" : "iss-casis.org\/press-releases\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069705362364874752",
    "text" : "The winners of the 'Guardians of the Galaxy Space Station Challenge', presented by ISS National Lab &amp; @Marvel, developed innovative space experiments focused on #tech and #biology. Now, they're launching to space!  Meet #TeamRocket and #TeamGroot! https:\/\/t.co\/wndhyW569a",
    "id" : 1069705362364874752,
    "created_at" : "2018-12-03 21:30:07 +0000",
    "user" : {
      "name" : "ISS National Lab",
      "screen_name" : "ISS_CASIS",
      "protected" : false,
      "id_str" : "188046098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1067887841122803712\/zakQ4EB-_normal.jpg",
      "id" : 188046098,
      "verified" : true
    }
  },
  "id" : 1069778353501147141,
  "created_at" : "2018-12-04 02:20:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA JPL",
      "screen_name" : "NASAJPL",
      "indices" : [ 3, 11 ],
      "id_str" : "19802879",
      "id" : 19802879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069778281577267202",
  "text" : "RT @NASAJPL: We posted a graphic on Mars mission power generation last Friday with errors. To keep those errors from spreading farther, we'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA InSight",
        "screen_name" : "NASAInSight",
        "indices" : [ 175, 187 ],
        "id_str" : "407387443",
        "id" : 407387443
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 210, 233 ],
        "url" : "https:\/\/t.co\/qzQNE06T5x",
        "expanded_url" : "https:\/\/go.nasa.gov\/2KRhn3j",
        "display_url" : "go.nasa.gov\/2KRhn3j"
      } ]
    },
    "geo" : { },
    "id_str" : "1069660506271637511",
    "text" : "We posted a graphic on Mars mission power generation last Friday with errors. To keep those errors from spreading farther, we've deleted the tweet. For correct information on @NASAInSight's power, please visit https:\/\/t.co\/qzQNE06T5x",
    "id" : 1069660506271637511,
    "created_at" : "2018-12-03 18:31:52 +0000",
    "user" : {
      "name" : "NASA JPL",
      "screen_name" : "NASAJPL",
      "protected" : false,
      "id_str" : "19802879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1033103993709322240\/m7jGqR6X_normal.jpg",
      "id" : 19802879,
      "verified" : true
    }
  },
  "id" : 1069778281577267202,
  "created_at" : "2018-12-04 02:19:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA InSight",
      "screen_name" : "NASAInSight",
      "indices" : [ 3, 15 ],
      "id_str" : "407387443",
      "id" : 407387443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mars",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069778264779042816",
  "text" : "RT @NASAInSight: I landed on #Mars a week ago today. Here\u2019s what I\u2019ve been up to so far:\n\u2705 Snap first images\n\u2705 Open solar panels\n\u2705 Check he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mars",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069739758601924608",
    "text" : "I landed on #Mars a week ago today. Here\u2019s what I\u2019ve been up to so far:\n\u2705 Snap first images\n\u2705 Open solar panels\n\u2705 Check health status\n\u2705 Power on instruments\n\u2705 Take preliminary science data for calibration\n\nUpcoming:\n\uD83D\uDD32 Extend arm\n\uD83D\uDD32 Take pics of deck",
    "id" : 1069739758601924608,
    "created_at" : "2018-12-03 23:46:47 +0000",
    "user" : {
      "name" : "NASA InSight",
      "screen_name" : "NASAInSight",
      "protected" : false,
      "id_str" : "407387443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1062801236166987776\/VwIfJa9u_normal.jpg",
      "id" : 407387443,
      "verified" : true
    }
  },
  "id" : 1069778264779042816,
  "created_at" : "2018-12-04 02:19:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/QrxiMcikbP",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-spacex-satellites.html",
      "display_url" : "phys.org\/news\/2018-12-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069778176925200384",
  "text" : "RT @physorg_com: SpaceX launches 64 satellites at once https:\/\/t.co\/QrxiMcikbP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/QrxiMcikbP",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-spacex-satellites.html",
        "display_url" : "phys.org\/news\/2018-12-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069706211308826625",
    "text" : "SpaceX launches 64 satellites at once https:\/\/t.co\/QrxiMcikbP",
    "id" : 1069706211308826625,
    "created_at" : "2018-12-03 21:33:29 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1069778176925200384,
  "created_at" : "2018-12-04 02:19:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 3, 15 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "astronauts",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "Station",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/7VyiNzJArU",
      "expanded_url" : "https:\/\/phys.org\/news\/2018-12-astronauts-safely-aboard-international-space.html",
      "display_url" : "phys.org\/news\/2018-12-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069778164556148736",
  "text" : "RT @physorg_com: Three #astronauts safely aboard International Space #Station (Update) https:\/\/t.co\/7VyiNzJArU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sciencex.com\/\" rel=\"nofollow\"\u003EScience X Status Updates\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "astronauts",
        "indices" : [ 6, 17 ]
      }, {
        "text" : "Station",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/7VyiNzJArU",
        "expanded_url" : "https:\/\/phys.org\/news\/2018-12-astronauts-safely-aboard-international-space.html",
        "display_url" : "phys.org\/news\/2018-12-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069707379023990784",
    "text" : "Three #astronauts safely aboard International Space #Station (Update) https:\/\/t.co\/7VyiNzJArU",
    "id" : 1069707379023990784,
    "created_at" : "2018-12-03 21:38:08 +0000",
    "user" : {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "protected" : false,
      "id_str" : "17248121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555400719478444032\/ky9g4wh6_normal.png",
      "id" : 17248121,
      "verified" : true
    }
  },
  "id" : 1069778164556148736,
  "created_at" : "2018-12-04 02:19:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AP West Region",
      "screen_name" : "APWestRegion",
      "indices" : [ 3, 16 ],
      "id_str" : "4196031009",
      "id" : 4196031009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069778034666979328",
  "text" : "RT @APWestRegion: Life is beginning to get back to normal in Alaska after the 7.0 earthquake, but people are still coping with clogged road\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 180, 203 ],
        "url" : "https:\/\/t.co\/Sa75kSqTEO",
        "expanded_url" : "http:\/\/apne.ws\/l8oFfj1",
        "display_url" : "apne.ws\/l8oFfj1"
      } ]
    },
    "geo" : { },
    "id_str" : "1069759474011963392",
    "text" : "Life is beginning to get back to normal in Alaska after the 7.0 earthquake, but people are still coping with clogged roads, closed public buildings and nerve-wracking aftershocks. https:\/\/t.co\/Sa75kSqTEO",
    "id" : 1069759474011963392,
    "created_at" : "2018-12-04 01:05:08 +0000",
    "user" : {
      "name" : "AP West Region",
      "screen_name" : "APWestRegion",
      "protected" : false,
      "id_str" : "4196031009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666737273531031552\/fTMjFQC5_normal.png",
      "id" : 4196031009,
      "verified" : true
    }
  },
  "id" : 1069778034666979328,
  "created_at" : "2018-12-04 02:18:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777780081127424",
  "text" : "RT @SpaceX: Mr. Steven is stationed in the Pacific, as SpaceX will attempt to catch and recover the fairing this mission. https:\/\/t.co\/A7aB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1069657950464073728\/video\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/A7aBSJoFfc",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1069657799863353344\/pu\/img\/YEOqBKshZbttyirh.jpg",
        "id_str" : "1069657799863353344",
        "id" : 1069657799863353344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1069657799863353344\/pu\/img\/YEOqBKshZbttyirh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/A7aBSJoFfc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069657950464073728",
    "text" : "Mr. Steven is stationed in the Pacific, as SpaceX will attempt to catch and recover the fairing this mission. https:\/\/t.co\/A7aBSJoFfc",
    "id" : 1069657950464073728,
    "created_at" : "2018-12-03 18:21:43 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1069777780081127424,
  "created_at" : "2018-12-04 02:17:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1069777334268555265\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/pkBkj87L3f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtic0F2XcAUXxSg.jpg",
      "id_str" : "1069777330237829125",
      "id" : 1069777330237829125,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtic0F2XcAUXxSg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 716
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/pkBkj87L3f"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/woPdoS9sgR",
      "expanded_url" : "https:\/\/trib.al\/5KUJ5KH",
      "display_url" : "trib.al\/5KUJ5KH"
    } ]
  },
  "geo" : { },
  "id_str" : "1069777762892816384",
  "text" : "RT @epicurious: We found the most efficient way to fry latkes: \nhttps:\/\/t.co\/woPdoS9sgR https:\/\/t.co\/pkBkj87L3f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/epicurious\/status\/1069777334268555265\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/pkBkj87L3f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtic0F2XcAUXxSg.jpg",
        "id_str" : "1069777330237829125",
        "id" : 1069777330237829125,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtic0F2XcAUXxSg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 716
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/pkBkj87L3f"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/woPdoS9sgR",
        "expanded_url" : "https:\/\/trib.al\/5KUJ5KH",
        "display_url" : "trib.al\/5KUJ5KH"
      } ]
    },
    "geo" : { },
    "id_str" : "1069777334268555265",
    "text" : "We found the most efficient way to fry latkes: \nhttps:\/\/t.co\/woPdoS9sgR https:\/\/t.co\/pkBkj87L3f",
    "id" : 1069777334268555265,
    "created_at" : "2018-12-04 02:16:06 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1069777762892816384,
  "created_at" : "2018-12-04 02:17:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew E. Freedman",
      "screen_name" : "FreedmanAE",
      "indices" : [ 3, 14 ],
      "id_str" : "30601538",
      "id" : 30601538
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FreedmanAE\/status\/1069428581309255681\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/doGDc7Dujs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtdfm7CWoAIFx5y.jpg",
      "id_str" : "1069428558811013122",
      "id" : 1069428558811013122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtdfm7CWoAIFx5y.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/doGDc7Dujs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777510257356801",
  "text" : "RT @FreedmanAE: New build! It\u2019s a beauty. https:\/\/t.co\/doGDc7Dujs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FreedmanAE\/status\/1069428581309255681\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/doGDc7Dujs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtdfm7CWoAIFx5y.jpg",
        "id_str" : "1069428558811013122",
        "id" : 1069428558811013122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtdfm7CWoAIFx5y.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/doGDc7Dujs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069428581309255681",
    "text" : "New build! It\u2019s a beauty. https:\/\/t.co\/doGDc7Dujs",
    "id" : 1069428581309255681,
    "created_at" : "2018-12-03 03:10:17 +0000",
    "user" : {
      "name" : "Andrew E. Freedman",
      "screen_name" : "FreedmanAE",
      "protected" : false,
      "id_str" : "30601538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631663276041109504\/cRl8hies_normal.jpg",
      "id" : 30601538,
      "verified" : false
    }
  },
  "id" : 1069777510257356801,
  "created_at" : "2018-12-04 02:16:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strength",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "indomitablewill",
      "indices" : [ 113, 129 ]
    }, {
      "text" : "gandhi",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777444029284352",
  "text" : "RT @lorenridinger: \"Strength does not come from physical capacity. It comes from an indomitable will.\" #strength #indomitablewill #gandhi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "strength",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "indomitablewill",
        "indices" : [ 94, 110 ]
      }, {
        "text" : "gandhi",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069773402293051392",
    "text" : "\"Strength does not come from physical capacity. It comes from an indomitable will.\" #strength #indomitablewill #gandhi",
    "id" : 1069773402293051392,
    "created_at" : "2018-12-04 02:00:29 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 1069777444029284352,
  "created_at" : "2018-12-04 02:16:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethereum Classic",
      "screen_name" : "eth_classic",
      "indices" : [ 3, 15 ],
      "id_str" : "759252279862104064",
      "id" : 759252279862104064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777358964568069",
  "text" : "RT @eth_classic: Ethereum Classic is not ETCDEV\n\nEthereum Classic is IOHK, ETC Co-op, ETC Labs, ETCDEV, and a litany of volunteers.\n\nKeep C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/J4IYvC906j",
        "expanded_url" : "https:\/\/twitter.com\/pyskell\/status\/1069686408762351621",
        "display_url" : "twitter.com\/pyskell\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069710787210489856",
    "text" : "Ethereum Classic is not ETCDEV\n\nEthereum Classic is IOHK, ETC Co-op, ETC Labs, ETCDEV, and a litany of volunteers.\n\nKeep Calm, and Build On. https:\/\/t.co\/J4IYvC906j",
    "id" : 1069710787210489856,
    "created_at" : "2018-12-03 21:51:40 +0000",
    "user" : {
      "name" : "Ethereum Classic",
      "screen_name" : "eth_classic",
      "protected" : false,
      "id_str" : "759252279862104064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875555509738381313\/8o5g6CP1_normal.jpg",
      "id" : 759252279862104064,
      "verified" : true
    }
  },
  "id" : 1069777358964568069,
  "created_at" : "2018-12-04 02:16:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2X588VFBXm",
      "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/03\/battlefield-v-overture-release\/",
      "display_url" : "engadget.com\/2018\/12\/03\/bat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069777331466711041",
  "text" : "RT @engadget: The first major 'Battlefield V' update arrives December 4th https:\/\/t.co\/2X588VFBXm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.naytev.com\" rel=\"nofollow\"\u003ENaytev\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/2X588VFBXm",
        "expanded_url" : "https:\/\/www.engadget.com\/2018\/12\/03\/battlefield-v-overture-release\/",
        "display_url" : "engadget.com\/2018\/12\/03\/bat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069774123931451393",
    "text" : "The first major 'Battlefield V' update arrives December 4th https:\/\/t.co\/2X588VFBXm",
    "id" : 1069774123931451393,
    "created_at" : "2018-12-04 02:03:21 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 1069777331466711041,
  "created_at" : "2018-12-04 02:16:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 3, 10 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777167150710786",
  "text" : "RT @SpaceX: Falcon 9 first stage has landed on the Just Read the Instructions droneship\u2014completing this rocket booster\u2019s third launch and l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpaceX\/status\/1069663373485174784\/photo\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/DXqT7KH9sM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtg1HOVV4AA-PB5.jpg",
        "id_str" : "1069663309723459584",
        "id" : 1069663309723459584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtg1HOVV4AA-PB5.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 1069
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 1069
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 1069
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/DXqT7KH9sM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069663373485174784",
    "text" : "Falcon 9 first stage has landed on the Just Read the Instructions droneship\u2014completing this rocket booster\u2019s third launch and landing this year. https:\/\/t.co\/DXqT7KH9sM",
    "id" : 1069663373485174784,
    "created_at" : "2018-12-03 18:43:16 +0000",
    "user" : {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "protected" : false,
      "id_str" : "34743251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671865418701606912\/HECw8AzK_normal.jpg",
      "id" : 34743251,
      "verified" : true
    }
  },
  "id" : 1069777167150710786,
  "created_at" : "2018-12-04 02:15:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GLIZOCK \uD83C\uDF39",
      "screen_name" : "KeyGlock_1",
      "indices" : [ 3, 14 ],
      "id_str" : "1013540804827152386",
      "id" : 1013540804827152386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069777047965319169",
  "text" : "RT @KeyGlock_1: The moment you start winning, they start hating",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069623156804120576",
    "text" : "The moment you start winning, they start hating",
    "id" : 1069623156804120576,
    "created_at" : "2018-12-03 16:03:27 +0000",
    "user" : {
      "name" : "GLIZOCK \uD83C\uDF39",
      "screen_name" : "KeyGlock_1",
      "protected" : false,
      "id_str" : "1013540804827152386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1066459728312717313\/zhdU8iiU_normal.jpg",
      "id" : 1013540804827152386,
      "verified" : false
    }
  },
  "id" : 1069777047965319169,
  "created_at" : "2018-12-04 02:14:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "indices" : [ 3, 12 ],
      "id_str" : "20731304",
      "id" : 20731304
    }, {
      "name" : "Terrill Moore",
      "screen_name" : "TmmMcci",
      "indices" : [ 39, 47 ],
      "id_str" : "856827312",
      "id" : 856827312
    }, {
      "name" : "MCCI Corporation",
      "screen_name" : "MCCI",
      "indices" : [ 48, 53 ],
      "id_str" : "551743688",
      "id" : 551743688
    }, {
      "name" : "Luke Valenty",
      "screen_name" : "TinyFPGA",
      "indices" : [ 68, 77 ],
      "id_str" : "915976368571027457",
      "id" : 915976368571027457
    }, {
      "name" : "Lattice Semi",
      "screen_name" : "latticesemi",
      "indices" : [ 80, 92 ],
      "id_str" : "40975045",
      "id" : 40975045
    }, {
      "name" : "RISC-V",
      "screen_name" : "risc_v",
      "indices" : [ 95, 102 ],
      "id_str" : "2694452875",
      "id" : 2694452875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoRaWAN",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "IoT",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JXPcwPNdnZ",
      "expanded_url" : "https:\/\/adafru.it\/Dcn",
      "display_url" : "adafru.it\/Dcn"
    } ]
  },
  "geo" : { },
  "id_str" : "1069776732780199936",
  "text" : "RT @adafruit: Feather-compatible FPGAs @TmmMcci @MCCI #LoRaWAN #IoT @TinyFPGA\u2069 \u2066@latticesemi\u2069 \u2066@risc_v https:\/\/t.co\/JXPcwPNdnZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/blog.adafruit.com\" rel=\"nofollow\"\u003EAdafruit Blog Feed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Terrill Moore",
        "screen_name" : "TmmMcci",
        "indices" : [ 25, 33 ],
        "id_str" : "856827312",
        "id" : 856827312
      }, {
        "name" : "MCCI Corporation",
        "screen_name" : "MCCI",
        "indices" : [ 34, 39 ],
        "id_str" : "551743688",
        "id" : 551743688
      }, {
        "name" : "Luke Valenty",
        "screen_name" : "TinyFPGA",
        "indices" : [ 54, 63 ],
        "id_str" : "915976368571027457",
        "id" : 915976368571027457
      }, {
        "name" : "Lattice Semi",
        "screen_name" : "latticesemi",
        "indices" : [ 66, 78 ],
        "id_str" : "40975045",
        "id" : 40975045
      }, {
        "name" : "RISC-V",
        "screen_name" : "risc_v",
        "indices" : [ 81, 88 ],
        "id_str" : "2694452875",
        "id" : 2694452875
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoRaWAN",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "IoT",
        "indices" : [ 49, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/JXPcwPNdnZ",
        "expanded_url" : "https:\/\/adafru.it\/Dcn",
        "display_url" : "adafru.it\/Dcn"
      } ]
    },
    "geo" : { },
    "id_str" : "1069757435169120259",
    "text" : "Feather-compatible FPGAs @TmmMcci @MCCI #LoRaWAN #IoT @TinyFPGA\u2069 \u2066@latticesemi\u2069 \u2066@risc_v https:\/\/t.co\/JXPcwPNdnZ",
    "id" : 1069757435169120259,
    "created_at" : "2018-12-04 00:57:02 +0000",
    "user" : {
      "name" : "adafruit industries",
      "screen_name" : "adafruit",
      "protected" : false,
      "id_str" : "20731304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459501419813302272\/SCEy7D19_normal.png",
      "id" : 20731304,
      "verified" : true
    }
  },
  "id" : 1069776732780199936,
  "created_at" : "2018-12-04 02:13:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin O'Leary",
      "screen_name" : "kevinolearytv",
      "indices" : [ 3, 17 ],
      "id_str" : "32002507",
      "id" : 32002507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069775521649750016",
  "text" : "RT @kevinolearytv: Few things impress me more in a #SharkTank pitch than when an entrepreneur is honest about mistakes they've made, and LE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "Pranko",
        "indices" : [ 163, 170 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069418452170014720",
    "text" : "Few things impress me more in a #SharkTank pitch than when an entrepreneur is honest about mistakes they've made, and LEARNED from them instead of making excuses. #Pranko",
    "id" : 1069418452170014720,
    "created_at" : "2018-12-03 02:30:02 +0000",
    "user" : {
      "name" : "Kevin O'Leary",
      "screen_name" : "kevinolearytv",
      "protected" : false,
      "id_str" : "32002507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1067383195597889536\/cP6tNEt0_normal.jpg",
      "id" : 32002507,
      "verified" : true
    }
  },
  "id" : 1069775521649750016,
  "created_at" : "2018-12-04 02:08:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069775494105743360",
  "text" : "RT @BTCticker: One Bitcoin now worth $3879.077. Market Cap $67.517 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069773315911413760",
    "text" : "One Bitcoin now worth $3879.077. Market Cap $67.517 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069773315911413760,
    "created_at" : "2018-12-04 02:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069775494105743360,
  "created_at" : "2018-12-04 02:08:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "HireSanta",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069758128646963200",
  "text" : "RT @BarbaraCorcoran: Seasonal businesses can be tough, but they can be incredibly successful if you market well. #SharkTank #HireSanta",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 92, 102 ]
      }, {
        "text" : "HireSanta",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069412158503612421",
    "text" : "Seasonal businesses can be tough, but they can be incredibly successful if you market well. #SharkTank #HireSanta",
    "id" : 1069412158503612421,
    "created_at" : "2018-12-03 02:05:01 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1069758128646963200,
  "created_at" : "2018-12-04 00:59:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/kIcj0Z463J",
      "expanded_url" : "https:\/\/trib.al\/ZdzTjrC",
      "display_url" : "trib.al\/ZdzTjrC"
    } ]
  },
  "geo" : { },
  "id_str" : "1069758103024009216",
  "text" : "RT @epicurious: Allll the latkes.\nhttps:\/\/t.co\/kIcj0Z463J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/kIcj0Z463J",
        "expanded_url" : "https:\/\/trib.al\/ZdzTjrC",
        "display_url" : "trib.al\/ZdzTjrC"
      } ]
    },
    "geo" : { },
    "id_str" : "1069600158353113094",
    "text" : "Allll the latkes.\nhttps:\/\/t.co\/kIcj0Z463J",
    "id" : 1069600158353113094,
    "created_at" : "2018-12-03 14:32:04 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1069758103024009216,
  "created_at" : "2018-12-04 00:59:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692748125691906",
  "text" : "RT @BTCticker: One Bitcoin now worth $3827.07@bitstamp. High $4184.470. Low $3747.000. Market Cap $66.606 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069690261599600640",
    "text" : "One Bitcoin now worth $3827.07@bitstamp. High $4184.470. Low $3747.000. Market Cap $66.606 Billion #bitcoin",
    "id" : 1069690261599600640,
    "created_at" : "2018-12-03 20:30:06 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069692748125691906,
  "created_at" : "2018-12-03 20:39:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "indices" : [ 3, 14 ],
      "id_str" : "242435607",
      "id" : 242435607
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/1069649791024537600\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/vkQbIETYbn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtgo0ApW0AAMjrf.jpg",
      "id_str" : "1069649785492262912",
      "id" : 1069649785492262912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtgo0ApW0AAMjrf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 484
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/vkQbIETYbn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692731386150914",
  "text" : "RT @Anba_Ermia: \u0639\u0634\u064A\u0629 \u0639\u064A\u062F \u0627\u0644\u0634\u0647\u064A\u062F \u0627\u0644\u0639\u0638\u064A\u0645 \u0641\u064A\u0644\u0648\u0628\u0627\u062A\u064A\u0631 \u0645\u0631\u0642\u0648\u0631\u064A\u0648\u0633 https:\/\/t.co\/vkQbIETYbn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Anba_Ermia\/status\/1069649791024537600\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/vkQbIETYbn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Dtgo0ApW0AAMjrf.jpg",
        "id_str" : "1069649785492262912",
        "id" : 1069649785492262912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dtgo0ApW0AAMjrf.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 484
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/vkQbIETYbn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069649791024537600",
    "text" : "\u0639\u0634\u064A\u0629 \u0639\u064A\u062F \u0627\u0644\u0634\u0647\u064A\u062F \u0627\u0644\u0639\u0638\u064A\u0645 \u0641\u064A\u0644\u0648\u0628\u0627\u062A\u064A\u0631 \u0645\u0631\u0642\u0648\u0631\u064A\u0648\u0633 https:\/\/t.co\/vkQbIETYbn",
    "id" : 1069649791024537600,
    "created_at" : "2018-12-03 17:49:17 +0000",
    "user" : {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "protected" : false,
      "id_str" : "242435607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580148862\/4cf7cba83bbd8d24e3a9a21f82ebc51e_normal.jpeg",
      "id" : 242435607,
      "verified" : false
    }
  },
  "id" : 1069692731386150914,
  "created_at" : "2018-12-03 20:39:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692697076744192",
  "text" : "RT @BTCticker: One Bitcoin now worth $3830.097. Market Cap $66.664 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069682722195550209",
    "text" : "One Bitcoin now worth $3830.097. Market Cap $66.664 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069682722195550209,
    "created_at" : "2018-12-03 20:00:09 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069692697076744192,
  "created_at" : "2018-12-03 20:39:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692679007670274",
  "text" : "RT @elonmusk: Falcon fairing halves missed the net, but touched down softly in the water. Mr Steven is picking them up. Plan is to dry them\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069679948103847939",
    "text" : "Falcon fairing halves missed the net, but touched down softly in the water. Mr Steven is picking them up. Plan is to dry them out &amp; launch again. Nothing wrong with a little swim.",
    "id" : 1069679948103847939,
    "created_at" : "2018-12-03 19:49:07 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/972170159614906369\/0o9cdCOp_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 1069692679007670274,
  "created_at" : "2018-12-03 20:39:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "indices" : [ 3, 14 ],
      "id_str" : "32011659",
      "id" : 32011659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692642559168514",
  "text" : "RT @MikeWShell: Volatility targeting funds sell stocks when volatility increases. \n\nThey also buy stocks when volatility declines. \n\nYou ca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069692221979549696",
    "text" : "Volatility targeting funds sell stocks when volatility increases. \n\nThey also buy stocks when volatility declines. \n\nYou can probably see the potential for an edge trading volatility. $VIX",
    "id" : 1069692221979549696,
    "created_at" : "2018-12-03 20:37:54 +0000",
    "user" : {
      "name" : "Mike Shell \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "MikeWShell",
      "protected" : false,
      "id_str" : "32011659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1048181753238708224\/3r0NVK-8_normal.jpg",
      "id" : 32011659,
      "verified" : false
    }
  },
  "id" : 1069692642559168514,
  "created_at" : "2018-12-03 20:39:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069692620430077953",
  "text" : "R Studio is awesome :)",
  "id" : 1069692620430077953,
  "created_at" : "2018-12-03 20:39:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/6QuxE8bzH6",
      "expanded_url" : "https:\/\/dribbble.com\/shots\/5643476-Image-Exposure?utm_source=Twitter_Shot&utm_campaign=gamer456148&utm_content=Image%20Exposure&utm_medium=Social_Share",
      "display_url" : "dribbble.com\/shots\/5643476-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069676757106745344",
  "text" : "Image Exposure by @gamer456148 https:\/\/t.co\/6QuxE8bzH6",
  "id" : 1069676757106745344,
  "created_at" : "2018-12-03 19:36:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069606809185464324",
  "text" : "RT @BTCticker: One Bitcoin now worth $3970.784. Market Cap $69.109 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069478871681196032",
    "text" : "One Bitcoin now worth $3970.784. Market Cap $69.109 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069478871681196032,
    "created_at" : "2018-12-03 06:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069606809185464324,
  "created_at" : "2018-12-03 14:58:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069606742588342273",
  "text" : "RT @BarbaraCorcoran: It pays to have fun at work. Everybody wants to work for a fun boss, and a fun boss is always surrounded by happy and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069577387669692416",
    "text" : "It pays to have fun at work. Everybody wants to work for a fun boss, and a fun boss is always surrounded by happy and loyal teams.",
    "id" : 1069577387669692416,
    "created_at" : "2018-12-03 13:01:35 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1069606742588342273,
  "created_at" : "2018-12-03 14:58:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069392249795031040",
  "text" : "RT @BTCticker: One Bitcoin now worth $4092.500. Market Cap $71.226 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1069388279718576128",
    "text" : "One Bitcoin now worth $4092.500. Market Cap $71.226 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1069388279718576128,
    "created_at" : "2018-12-03 00:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1069392249795031040,
  "created_at" : "2018-12-03 00:45:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WAQNzo1TOr",
      "expanded_url" : "https:\/\/trib.al\/2p1hH2D",
      "display_url" : "trib.al\/2p1hH2D"
    } ]
  },
  "geo" : { },
  "id_str" : "1069392222959923200",
  "text" : "RT @epicurious: If you aren\u2019t already making baked apples\u2026 now\u2019s the time to start. \nhttps:\/\/t.co\/WAQNzo1TOr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/WAQNzo1TOr",
        "expanded_url" : "https:\/\/trib.al\/2p1hH2D",
        "display_url" : "trib.al\/2p1hH2D"
      } ]
    },
    "geo" : { },
    "id_str" : "1069387767401119744",
    "text" : "If you aren\u2019t already making baked apples\u2026 now\u2019s the time to start. \nhttps:\/\/t.co\/WAQNzo1TOr",
    "id" : 1069387767401119744,
    "created_at" : "2018-12-03 00:28:06 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1069392222959923200,
  "created_at" : "2018-12-03 00:45:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/aIXVaekrl6",
      "expanded_url" : "https:\/\/trib.al\/NivuJtL",
      "display_url" : "trib.al\/NivuJtL"
    } ]
  },
  "geo" : { },
  "id_str" : "1069075077315072000",
  "text" : "RT @epicurious: It really is the best ever. \nhttps:\/\/t.co\/aIXVaekrl6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/aIXVaekrl6",
        "expanded_url" : "https:\/\/trib.al\/NivuJtL",
        "display_url" : "trib.al\/NivuJtL"
      } ]
    },
    "geo" : { },
    "id_str" : "1068978066536480768",
    "text" : "It really is the best ever. \nhttps:\/\/t.co\/aIXVaekrl6",
    "id" : 1068978066536480768,
    "created_at" : "2018-12-01 21:20:06 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1069075077315072000,
  "created_at" : "2018-12-02 03:45:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "indices" : [ 3, 15 ],
      "id_str" : "2869531",
      "id" : 2869531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9rER0xjOwg",
      "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/05\/how-to-make-caramel-without-melting-sugar.html",
      "display_url" : "seriouseats.com\/2016\/05\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1069075059715772416",
  "text" : "RT @seriouseats: Want to know something crazy? Sugar doesn't melt; it undergoes thermal decomposition.\nhttps:\/\/t.co\/9rER0xjOwg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/9rER0xjOwg",
        "expanded_url" : "https:\/\/www.seriouseats.com\/2016\/05\/how-to-make-caramel-without-melting-sugar.html",
        "display_url" : "seriouseats.com\/2016\/05\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1069048506302685184",
    "text" : "Want to know something crazy? Sugar doesn't melt; it undergoes thermal decomposition.\nhttps:\/\/t.co\/9rER0xjOwg",
    "id" : 1069048506302685184,
    "created_at" : "2018-12-02 02:00:00 +0000",
    "user" : {
      "name" : "Serious Eats",
      "screen_name" : "seriouseats",
      "protected" : false,
      "id_str" : "2869531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883020631977144324\/Nhe2vc2D_normal.jpg",
      "id" : 2869531,
      "verified" : true
    }
  },
  "id" : 1069075059715772416,
  "created_at" : "2018-12-02 03:45:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "indices" : [ 3, 15 ],
      "id_str" : "798906869582544896",
      "id" : 798906869582544896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "Blockchain",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "Cryptocurrency",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068947910765805568",
  "text" : "RT @SmartcoinFr: Le cours du #Bitcoin est de 3673.55\u20AC\uD83C\uDDEA\uD83C\uDDFA  (4163.23$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smartcoin.fr\" rel=\"nofollow\"\u003EBitcoinPriceReal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Blockchain",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "Cryptocurrency",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1068835358828347393",
    "text" : "Le cours du #Bitcoin est de 3673.55\u20AC\uD83C\uDDEA\uD83C\uDDFA  (4163.23$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
    "id" : 1068835358828347393,
    "created_at" : "2018-12-01 11:53:02 +0000",
    "user" : {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "protected" : false,
      "id_str" : "798906869582544896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911003345342599168\/Yu2M7_bQ_normal.jpg",
      "id" : 798906869582544896,
      "verified" : false
    }
  },
  "id" : 1068947910765805568,
  "created_at" : "2018-12-01 19:20:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/jhWiKBzUi9",
      "expanded_url" : "http:\/\/bit.ly\/2RotMOr",
      "display_url" : "bit.ly\/2RotMOr"
    } ]
  },
  "geo" : { },
  "id_str" : "1068941248650797056",
  "text" : "RT @instructables: Learn to make a functional telescope from PVC pipes! https:\/\/t.co\/jhWiKBzUi9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/jhWiKBzUi9",
        "expanded_url" : "http:\/\/bit.ly\/2RotMOr",
        "display_url" : "bit.ly\/2RotMOr"
      } ]
    },
    "geo" : { },
    "id_str" : "1068908083253051392",
    "text" : "Learn to make a functional telescope from PVC pipes! https:\/\/t.co\/jhWiKBzUi9",
    "id" : 1068908083253051392,
    "created_at" : "2018-12-01 16:42:01 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1068941248650797056,
  "created_at" : "2018-12-01 18:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068941157990846465",
  "text" : "RT @BarbaraCorcoran: I\u2019ve always appreciated that my success was half me and half potluck. The luck was the fun part!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1068913139679399936",
    "text" : "I\u2019ve always appreciated that my success was half me and half potluck. The luck was the fun part!",
    "id" : 1068913139679399936,
    "created_at" : "2018-12-01 17:02:06 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 1068941157990846465,
  "created_at" : "2018-12-01 18:53:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]