Grailbird.data.tweets_2019_01 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080188557740986368",
  "text" : "RT @BTCticker: One Bitcoin now worth $3722.750. Market Cap $64.989 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080184416167739394",
    "text" : "One Bitcoin now worth $3722.750. Market Cap $64.989 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1080184416167739394,
    "created_at" : "2019-01-01 19:30:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1080188557740986368,
  "created_at" : "2019-01-01 19:46:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "instructables",
      "screen_name" : "instructables",
      "indices" : [ 3, 17 ],
      "id_str" : "7597362",
      "id" : 7597362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080188507736473600",
  "text" : "RT @instructables: Start the new year off right by learning new woodworking skills, check out this modern bench to get inspired. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/MXN4BBcpon",
        "expanded_url" : "http:\/\/bit.ly\/2CJonNf",
        "display_url" : "bit.ly\/2CJonNf"
      } ]
    },
    "geo" : { },
    "id_str" : "1080181878311841793",
    "text" : "Start the new year off right by learning new woodworking skills, check out this modern bench to get inspired. https:\/\/t.co\/MXN4BBcpon",
    "id" : 1080181878311841793,
    "created_at" : "2019-01-01 19:20:03 +0000",
    "user" : {
      "name" : "instructables",
      "screen_name" : "instructables",
      "protected" : false,
      "id_str" : "7597362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846770514374737920\/rKl8JMPT_normal.jpg",
      "id" : 7597362,
      "verified" : false
    }
  },
  "id" : 1080188507736473600,
  "created_at" : "2019-01-01 19:46:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ELNolsabir",
      "expanded_url" : "http:\/\/bit.ly\/teachtube",
      "display_url" : "bit.ly\/teachtube"
    } ]
  },
  "geo" : { },
  "id_str" : "1080188497967960064",
  "text" : "https:\/\/t.co\/ELNolsabir",
  "id" : 1080188497967960064,
  "created_at" : "2019-01-01 19:46:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Fowler",
      "screen_name" : "scott_fowler",
      "indices" : [ 3, 16 ],
      "id_str" : "17908195",
      "id" : 17908195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080160150533623808",
  "text" : "RT @scott_fowler: Kyle Allen throws one 57 yards in the air and absolutely couldn't throw it any better. Samuel catches it for a 53-yard TD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079470277434769409",
    "text" : "Kyle Allen throws one 57 yards in the air and absolutely couldn't throw it any better. Samuel catches it for a 53-yard TD, pending review. I thought it was a TD.",
    "id" : 1079470277434769409,
    "created_at" : "2018-12-30 20:12:24 +0000",
    "user" : {
      "name" : "Scott Fowler",
      "screen_name" : "scott_fowler",
      "protected" : false,
      "id_str" : "17908195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/349872338\/fowler_mug_shot_normal",
      "id" : 17908195,
      "verified" : true
    }
  },
  "id" : 1080160150533623808,
  "created_at" : "2019-01-01 17:53:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Police",
      "screen_name" : "UKPolice",
      "indices" : [ 3, 12 ],
      "id_str" : "42740629",
      "id" : 42740629
    }, {
      "name" : "Lexington Police",
      "screen_name" : "lexkypolice",
      "indices" : [ 14, 26 ],
      "id_str" : "2813501070",
      "id" : 2813501070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080159753349857282",
  "text" : "RT @UKPolice: @lexkypolice We feel your loss. We donut know what else to say. \uD83C\uDF69\uD83D\uDE30\uD83C\uDF69",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexington Police",
        "screen_name" : "lexkypolice",
        "indices" : [ 0, 12 ],
        "id_str" : "2813501070",
        "id" : 2813501070
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "1079842747782230016",
    "geo" : { },
    "id_str" : "1079906559633879046",
    "in_reply_to_user_id" : 2813501070,
    "text" : "@lexkypolice We feel your loss. We donut know what else to say. \uD83C\uDF69\uD83D\uDE30\uD83C\uDF69",
    "id" : 1079906559633879046,
    "in_reply_to_status_id" : 1079842747782230016,
    "created_at" : "2019-01-01 01:06:02 +0000",
    "in_reply_to_screen_name" : "lexkypolice",
    "in_reply_to_user_id_str" : "2813501070",
    "user" : {
      "name" : "UK Police",
      "screen_name" : "UKPolice",
      "protected" : false,
      "id_str" : "42740629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784022966292062208\/Lqo855Vi_normal.jpg",
      "id" : 42740629,
      "verified" : false
    }
  },
  "id" : 1080159753349857282,
  "created_at" : "2019-01-01 17:52:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 3, 14 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/avfwH7kUVC",
      "expanded_url" : "https:\/\/trib.al\/s6h6g6j",
      "display_url" : "trib.al\/s6h6g6j"
    } ]
  },
  "geo" : { },
  "id_str" : "1080153399600078848",
  "text" : "RT @epicurious: The trick is to treat it like it's a steak.\nhttps:\/\/t.co\/avfwH7kUVC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/avfwH7kUVC",
        "expanded_url" : "https:\/\/trib.al\/s6h6g6j",
        "display_url" : "trib.al\/s6h6g6j"
      } ]
    },
    "geo" : { },
    "id_str" : "1079877133873434625",
    "text" : "The trick is to treat it like it's a steak.\nhttps:\/\/t.co\/avfwH7kUVC",
    "id" : 1079877133873434625,
    "created_at" : "2018-12-31 23:09:06 +0000",
    "user" : {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "protected" : false,
      "id_str" : "16145224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656919506007162880\/IwTV0izS_normal.png",
      "id" : 16145224,
      "verified" : true
    }
  },
  "id" : 1080153399600078848,
  "created_at" : "2019-01-01 17:26:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liquor.com",
      "screen_name" : "Liquor",
      "indices" : [ 3, 10 ],
      "id_str" : "65716459",
      "id" : 65716459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/SUGeI79UVX",
      "expanded_url" : "http:\/\/bit.ly\/2TkAp4V",
      "display_url" : "bit.ly\/2TkAp4V"
    } ]
  },
  "geo" : { },
  "id_str" : "1080153268511223810",
  "text" : "RT @Liquor: Classics You Should Know: Aperol Spritz https:\/\/t.co\/SUGeI79UVX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/trueanthem.com\/\" rel=\"nofollow\"\u003EtrueAnthem\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/SUGeI79UVX",
        "expanded_url" : "http:\/\/bit.ly\/2TkAp4V",
        "display_url" : "bit.ly\/2TkAp4V"
      } ]
    },
    "geo" : { },
    "id_str" : "1079942917010194432",
    "text" : "Classics You Should Know: Aperol Spritz https:\/\/t.co\/SUGeI79UVX",
    "id" : 1079942917010194432,
    "created_at" : "2019-01-01 03:30:30 +0000",
    "user" : {
      "name" : "Liquor.com",
      "screen_name" : "Liquor",
      "protected" : false,
      "id_str" : "65716459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593877808063062017\/H2Mluuci_normal.png",
      "id" : 65716459,
      "verified" : true
    }
  },
  "id" : 1080153268511223810,
  "created_at" : "2019-01-01 17:26:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richardredhawk",
      "screen_name" : "richardredhawk",
      "indices" : [ 3, 18 ],
      "id_str" : "15080354",
      "id" : 15080354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shortribs",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080152959399481346",
  "text" : "RT @richardredhawk: Slow Cooker beef short ribs. Fall-apart beef served with a rich and red wine gravy. This is serious comfort  #shortribs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kitchen Sanctuary",
        "screen_name" : "KitchenSanc2ary",
        "indices" : [ 264, 280 ],
        "id_str" : "26327787",
        "id" : 26327787
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shortribs",
        "indices" : [ 109, 119 ]
      }, {
        "text" : "beefshortribs",
        "indices" : [ 120, 134 ]
      }, {
        "text" : "comfortfood",
        "indices" : [ 135, 147 ]
      }, {
        "text" : "dinnertonight",
        "indices" : [ 148, 162 ]
      }, {
        "text" : "winterfood",
        "indices" : [ 163, 174 ]
      }, {
        "text" : "SlowCooker",
        "indices" : [ 175, 186 ]
      }, {
        "text" : "slowcooked",
        "indices" : [ 187, 198 ]
      }, {
        "text" : "Beef",
        "indices" : [ 199, 204 ]
      }, {
        "text" : "Crockpot",
        "indices" : [ 205, 214 ]
      }, {
        "text" : "Recipe",
        "indices" : [ 215, 222 ]
      }, {
        "text" : "glutenfree",
        "indices" : [ 223, 234 ]
      } ],
      "urls" : [ {
        "indices" : [ 236, 259 ],
        "url" : "https:\/\/t.co\/u5rUaUkrEH",
        "expanded_url" : "https:\/\/www.kitchensanctuary.com\/crockpot-beef-short-ribs-with-rich-gravy\/?utm_source=twitter&utm_medium=Social&utm_campaign=SocialWarfare",
        "display_url" : "kitchensanctuary.com\/crockpot-beef-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1080127066329309184",
    "text" : "Slow Cooker beef short ribs. Fall-apart beef served with a rich and red wine gravy. This is serious comfort  #shortribs #beefshortribs #comfortfood #dinnertonight #winterfood #SlowCooker #slowcooked #Beef #Crockpot #Recipe #glutenfree  https:\/\/t.co\/u5rUaUkrEH via @KitchenSanc2ary",
    "id" : 1080127066329309184,
    "created_at" : "2019-01-01 15:42:15 +0000",
    "user" : {
      "name" : "richardredhawk",
      "screen_name" : "richardredhawk",
      "protected" : false,
      "id_str" : "15080354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2878028280\/d3197b11c47410fd2f782860369b2e3c_normal.jpeg",
      "id" : 15080354,
      "verified" : false
    }
  },
  "id" : 1080152959399481346,
  "created_at" : "2019-01-01 17:25:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Globalnews.ca",
      "screen_name" : "globalnews",
      "indices" : [ 3, 14 ],
      "id_str" : "116502194",
      "id" : 116502194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tjPkJETfUc",
      "expanded_url" : "https:\/\/trib.al\/bTfCtEw",
      "display_url" : "trib.al\/bTfCtEw"
    } ]
  },
  "geo" : { },
  "id_str" : "1080152790096318464",
  "text" : "RT @globalnews: \u201CWe set a record. Never before has a spacecraft explored anything so far away.\u201D\nhttps:\/\/t.co\/tjPkJETfUc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/tjPkJETfUc",
        "expanded_url" : "https:\/\/trib.al\/bTfCtEw",
        "display_url" : "trib.al\/bTfCtEw"
      } ]
    },
    "geo" : { },
    "id_str" : "1080092681425092609",
    "text" : "\u201CWe set a record. Never before has a spacecraft explored anything so far away.\u201D\nhttps:\/\/t.co\/tjPkJETfUc",
    "id" : 1080092681425092609,
    "created_at" : "2019-01-01 13:25:37 +0000",
    "user" : {
      "name" : "Globalnews.ca",
      "screen_name" : "globalnews",
      "protected" : false,
      "id_str" : "116502194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722490988120289280\/iF92VumO_normal.jpg",
      "id" : 116502194,
      "verified" : true
    }
  },
  "id" : 1080152790096318464,
  "created_at" : "2019-01-01 17:24:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/8T0DtKumYf",
      "expanded_url" : "https:\/\/fstoppers.com\/lighting\/you-dont-need-275m-maserati-try-automobile-light-painting-it-doesnt-hurt-323984?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/lighting\/you-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1080152449665646594",
  "text" : "RT @JayHoque: You Don't Need a $2.75M Maserati to Try Automobile Light-Painting, but It Doesn't Hurt: https:\/\/t.co\/8T0DtKumYf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/8T0DtKumYf",
        "expanded_url" : "https:\/\/fstoppers.com\/lighting\/you-dont-need-275m-maserati-try-automobile-light-painting-it-doesnt-hurt-323984?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/lighting\/you-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1080124109764415489",
    "text" : "You Don't Need a $2.75M Maserati to Try Automobile Light-Painting, but It Doesn't Hurt: https:\/\/t.co\/8T0DtKumYf",
    "id" : 1080124109764415489,
    "created_at" : "2019-01-01 15:30:30 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1080152449665646594,
  "created_at" : "2019-01-01 17:23:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bitcoin",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080152413435297792",
  "text" : "RT @BTCticker: One Bitcoin now worth $3680.44@bitstamp. High $3791.200. Low $3630.000. Market Cap $64.245 Billion #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bitcoin",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080124015862255618",
    "text" : "One Bitcoin now worth $3680.44@bitstamp. High $3791.200. Low $3630.000. Market Cap $64.245 Billion #bitcoin",
    "id" : 1080124015862255618,
    "created_at" : "2019-01-01 15:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1080152413435297792,
  "created_at" : "2019-01-01 17:22:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "indices" : [ 3, 12 ],
      "id_str" : "35078351",
      "id" : 35078351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/43n9U5LCUK",
      "expanded_url" : "https:\/\/fstoppers.com\/landscapes\/landscape-photography-challenge-new-year-shoot-just-using-telephoto-lens-323772?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
      "display_url" : "fstoppers.com\/landscapes\/lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1080152220132392961",
  "text" : "RT @JayHoque: Landscape Photography Challenge for the New Year: Shoot Just Using a Telephoto Lens: https:\/\/t.co\/43n9U5LCUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/43n9U5LCUK",
        "expanded_url" : "https:\/\/fstoppers.com\/landscapes\/landscape-photography-challenge-new-year-shoot-just-using-telephoto-lens-323772?utm_source=FS_RSS&utm_medium=RSS&utm_campaign=Main_RSS",
        "display_url" : "fstoppers.com\/landscapes\/lan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1080140448369442816",
    "text" : "Landscape Photography Challenge for the New Year: Shoot Just Using a Telephoto Lens: https:\/\/t.co\/43n9U5LCUK",
    "id" : 1080140448369442816,
    "created_at" : "2019-01-01 16:35:25 +0000",
    "user" : {
      "name" : "Jay Hoque",
      "screen_name" : "JayHoque",
      "protected" : false,
      "id_str" : "35078351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961957000203694081\/6e41LsqX_normal.jpg",
      "id" : 35078351,
      "verified" : false
    }
  },
  "id" : 1080152220132392961,
  "created_at" : "2019-01-01 17:22:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080152167242219521",
  "text" : "RT @BTCticker: One Bitcoin now worth $3726.788. Market Cap $65.058 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080131576288198656",
    "text" : "One Bitcoin now worth $3726.788. Market Cap $65.058 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1080131576288198656,
    "created_at" : "2019-01-01 16:00:10 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1080152167242219521,
  "created_at" : "2019-01-01 17:21:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151967983460353",
  "text" : "RT @AP: Scientists say NASA\u2019s New Horizons spacecraft has survived humanity's most distant encounter with another world 4 billion miles awa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/wDAgxapWHR",
        "expanded_url" : "http:\/\/apne.ws\/AETcf7f",
        "display_url" : "apne.ws\/AETcf7f"
      } ]
    },
    "geo" : { },
    "id_str" : "1080129689350537216",
    "text" : "Scientists say NASA\u2019s New Horizons spacecraft has survived humanity's most distant encounter with another world 4 billion miles away. https:\/\/t.co\/wDAgxapWHR",
    "id" : 1080129689350537216,
    "created_at" : "2019-01-01 15:52:40 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 1080151967983460353,
  "created_at" : "2019-01-01 17:21:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Rich",
      "screen_name" : "dataeditor",
      "indices" : [ 3, 14 ],
      "id_str" : "22816767",
      "id" : 22816767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151934215032832",
  "text" : "RT @dataeditor: hi what databases would you like to see me build this year",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080127097799098368",
    "text" : "hi what databases would you like to see me build this year",
    "id" : 1080127097799098368,
    "created_at" : "2019-01-01 15:42:22 +0000",
    "user" : {
      "name" : "Steven Rich",
      "screen_name" : "dataeditor",
      "protected" : false,
      "id_str" : "22816767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/959289173504024577\/hpiT5lTF_normal.jpg",
      "id" : 22816767,
      "verified" : true
    }
  },
  "id" : 1080151934215032832,
  "created_at" : "2019-01-01 17:21:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151917911777280",
  "text" : "RT @BTCticker: One Bitcoin now worth $3738.252. Market Cap $65.258 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080146666659958784",
    "text" : "One Bitcoin now worth $3738.252. Market Cap $65.258 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1080146666659958784,
    "created_at" : "2019-01-01 17:00:08 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1080151917911777280,
  "created_at" : "2019-01-01 17:21:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hackaday.io",
      "screen_name" : "hackadayio",
      "indices" : [ 3, 14 ],
      "id_str" : "2670064278",
      "id" : 2670064278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SolarPowerSupply",
      "indices" : [ 45, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151806334943244",
  "text" : "RT @hackadayio: \u2600\uFE0FHere is the most efficient #SolarPowerSupply ever designed by Patel Darshil. It does the work of solar power unit, effici\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SolarPowerSupply",
        "indices" : [ 29, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 251, 274 ],
        "url" : "https:\/\/t.co\/T40vBSERMj",
        "expanded_url" : "http:\/\/bit.ly\/2V9yRMS",
        "display_url" : "bit.ly\/2V9yRMS"
      } ]
    },
    "geo" : { },
    "id_str" : "1080131794408755200",
    "text" : "\u2600\uFE0FHere is the most efficient #SolarPowerSupply ever designed by Patel Darshil. It does the work of solar power unit, efficient timing delivery of power and a super capacitor UPS. You device can work upto 15 days without sunlight or further charging.\uD83D\uDD0C https:\/\/t.co\/T40vBSERMj",
    "id" : 1080131794408755200,
    "created_at" : "2019-01-01 16:01:02 +0000",
    "user" : {
      "name" : "Hackaday.io",
      "screen_name" : "hackadayio",
      "protected" : false,
      "id_str" : "2670064278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1009468685323591681\/4V860Lto_normal.jpg",
      "id" : 2670064278,
      "verified" : false
    }
  },
  "id" : 1080151806334943244,
  "created_at" : "2019-01-01 17:20:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vidIQ \uD83C\uDF89\uD83D\uDE80\uD83D\uDCC8",
      "screen_name" : "vidIQ",
      "indices" : [ 3, 9 ],
      "id_str" : "394213943",
      "id" : 394213943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151686860230659",
  "text" : "RT @vidIQ: \uD83C\uDF89\uD83C\uDFAF\uD83D\uDCC8Welcome to 2019! What is your YouTube New Year Resolution?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080129268879904768",
    "text" : "\uD83C\uDF89\uD83C\uDFAF\uD83D\uDCC8Welcome to 2019! What is your YouTube New Year Resolution?",
    "id" : 1080129268879904768,
    "created_at" : "2019-01-01 15:51:00 +0000",
    "user" : {
      "name" : "vidIQ \uD83C\uDF89\uD83D\uDE80\uD83D\uDCC8",
      "screen_name" : "vidIQ",
      "protected" : false,
      "id_str" : "394213943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000837588547\/3525fadd947ce31e6e4dd43f16e08794_normal.png",
      "id" : 394213943,
      "verified" : true
    }
  },
  "id" : 1080151686860230659,
  "created_at" : "2019-01-01 17:20:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1080151643386195968\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/Hj5ldRE01B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dv14MP7WkAAVLii.jpg",
      "id_str" : "1080151637468024832",
      "id" : 1080151637468024832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dv14MP7WkAAVLii.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1075,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Hj5ldRE01B"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080151643386195968",
  "text" : "This was a very lucky eBay find..... https:\/\/t.co\/Hj5ldRE01B",
  "id" : 1080151643386195968,
  "created_at" : "2019-01-01 17:19:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Daley",
      "screen_name" : "JDaIey",
      "indices" : [ 3, 10 ],
      "id_str" : "872695783",
      "id" : 872695783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080034741011861505",
  "text" : "RT @JDaIey: Who was consistently there for you this year?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079522466651881472",
    "text" : "Who was consistently there for you this year?",
    "id" : 1079522466651881472,
    "created_at" : "2018-12-30 23:39:47 +0000",
    "user" : {
      "name" : "Jordan Daley",
      "screen_name" : "JDaIey",
      "protected" : false,
      "id_str" : "872695783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1046874624607293441\/Dt_sXWPL_normal.jpg",
      "id" : 872695783,
      "verified" : true
    }
  },
  "id" : 1080034741011861505,
  "created_at" : "2019-01-01 09:35:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Price of Bitcoin",
      "screen_name" : "ThePriceOfBTC",
      "indices" : [ 3, 17 ],
      "id_str" : "1669448522",
      "id" : 1669448522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GDAX",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "bitstamp",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "kraken",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "gemini",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "cex",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080034622682157056",
  "text" : "RT @ThePriceOfBTC: $3693.48 #GDAX;\n$3691.30 #bitstamp;\n$3692.90 #kraken;\n$3693.07 #gemini;\n$3834.50 #cex;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/thepriceofbtc\" rel=\"nofollow\"\u003EThe Price of BTC\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GDAX",
        "indices" : [ 9, 14 ]
      }, {
        "text" : "bitstamp",
        "indices" : [ 25, 34 ]
      }, {
        "text" : "kraken",
        "indices" : [ 45, 52 ]
      }, {
        "text" : "gemini",
        "indices" : [ 63, 70 ]
      }, {
        "text" : "cex",
        "indices" : [ 81, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079988102108712960",
    "text" : "$3693.48 #GDAX;\n$3691.30 #bitstamp;\n$3692.90 #kraken;\n$3693.07 #gemini;\n$3834.50 #cex;",
    "id" : 1079988102108712960,
    "created_at" : "2019-01-01 06:30:03 +0000",
    "user" : {
      "name" : "The Price of Bitcoin",
      "screen_name" : "ThePriceOfBTC",
      "protected" : false,
      "id_str" : "1669448522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000315990996\/f887b3754251d65a36a085e194b152c4_normal.png",
      "id" : 1669448522,
      "verified" : false
    }
  },
  "id" : 1080034622682157056,
  "created_at" : "2019-01-01 09:34:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Amash",
      "screen_name" : "justinamash",
      "indices" : [ 3, 15 ],
      "id_str" : "233842454",
      "id" : 233842454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080034601479876608",
  "text" : "RT @justinamash: Happy New Year!\n\nA liberty revolution is coming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079965440347127808",
    "text" : "Happy New Year!\n\nA liberty revolution is coming.",
    "id" : 1079965440347127808,
    "created_at" : "2019-01-01 05:00:00 +0000",
    "user" : {
      "name" : "Justin Amash",
      "screen_name" : "justinamash",
      "protected" : false,
      "id_str" : "233842454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1062568344879091712\/jTRi-6Lm_normal.jpg",
      "id" : 233842454,
      "verified" : true
    }
  },
  "id" : 1080034601479876608,
  "created_at" : "2019-01-01 09:34:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080034536203972609",
  "text" : "RT @nytimes: Nancy Grace Roman was NASA's first chief astronomer, first woman in a leadership position and oversaw early planning for the H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 148, 171 ],
        "url" : "https:\/\/t.co\/aksoGK1BJu",
        "expanded_url" : "https:\/\/nyti.ms\/2CDTt8E",
        "display_url" : "nyti.ms\/2CDTt8E"
      } ]
    },
    "geo" : { },
    "id_str" : "1079512487555420161",
    "text" : "Nancy Grace Roman was NASA's first chief astronomer, first woman in a leadership position and oversaw early planning for the Hubble Space Telescope https:\/\/t.co\/aksoGK1BJu",
    "id" : 1079512487555420161,
    "created_at" : "2018-12-30 23:00:08 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/942784892882112513\/qV4xB0I3_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 1080034536203972609,
  "created_at" : "2019-01-01 09:34:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science News",
      "screen_name" : "ScienceNews",
      "indices" : [ 3, 15 ],
      "id_str" : "19402238",
      "id" : 19402238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/COcKrJkfGi",
      "expanded_url" : "http:\/\/ow.ly\/O5m930n9gyY",
      "display_url" : "ow.ly\/O5m930n9gyY"
    } ]
  },
  "geo" : { },
  "id_str" : "1080034446588313600",
  "text" : "RT @ScienceNews: The \u201Cmother of Hubble\u201D has died. https:\/\/t.co\/COcKrJkfGi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite Inc.\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/COcKrJkfGi",
        "expanded_url" : "http:\/\/ow.ly\/O5m930n9gyY",
        "display_url" : "ow.ly\/O5m930n9gyY"
      } ]
    },
    "geo" : { },
    "id_str" : "1079864202934784002",
    "text" : "The \u201Cmother of Hubble\u201D has died. https:\/\/t.co\/COcKrJkfGi",
    "id" : 1079864202934784002,
    "created_at" : "2018-12-31 22:17:43 +0000",
    "user" : {
      "name" : "Science News",
      "screen_name" : "ScienceNews",
      "protected" : false,
      "id_str" : "19402238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000564879746\/1b6204ccf804be6a180408c8f76ab923_normal.png",
      "id" : 19402238,
      "verified" : true
    }
  },
  "id" : 1080034446588313600,
  "created_at" : "2019-01-01 09:34:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gold Price",
      "screen_name" : "goldpricetweets",
      "indices" : [ 3, 19 ],
      "id_str" : "472488467",
      "id" : 472488467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gold",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "Price",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033854428205057",
  "text" : "RT @goldpricetweets: Zurich #Gold #Price Open: $1282.1 USD per oz 2019-01-01 08:00:57 CET",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/resourcetwit.com\/\" rel=\"nofollow\"\u003EResourcetwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gold",
        "indices" : [ 7, 12 ]
      }, {
        "text" : "Price",
        "indices" : [ 13, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079995894299222016",
    "text" : "Zurich #Gold #Price Open: $1282.1 USD per oz 2019-01-01 08:00:57 CET",
    "id" : 1079995894299222016,
    "created_at" : "2019-01-01 07:01:01 +0000",
    "user" : {
      "name" : "Gold Price",
      "screen_name" : "goldpricetweets",
      "protected" : false,
      "id_str" : "472488467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2022012912\/goldprices_normal.jpg",
      "id" : 472488467,
      "verified" : false
    }
  },
  "id" : 1080033854428205057,
  "created_at" : "2019-01-01 09:31:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SilverQuote",
      "screen_name" : "silverquote",
      "indices" : [ 3, 15 ],
      "id_str" : "528732350",
      "id" : 528732350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Silver",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "Price",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033809448534016",
  "text" : "RT @silverquote: London #Silver #Price Open: $15.47 USD per oz 2019-01-01 08:30:57 GMT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/resourcetwit.com\/\" rel=\"nofollow\"\u003EResourcetwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Silver",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "Price",
        "indices" : [ 15, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080018540298625024",
    "text" : "London #Silver #Price Open: $15.47 USD per oz 2019-01-01 08:30:57 GMT",
    "id" : 1080018540298625024,
    "created_at" : "2019-01-01 08:31:00 +0000",
    "user" : {
      "name" : "SilverQuote",
      "screen_name" : "silverquote",
      "protected" : false,
      "id_str" : "528732350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2021978988\/silverprices_normal.jpg",
      "id" : 528732350,
      "verified" : false
    }
  },
  "id" : 1080033809448534016,
  "created_at" : "2019-01-01 09:31:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "indices" : [ 3, 14 ],
      "id_str" : "40516848",
      "id" : 40516848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WordPress",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/TCuwqG0Bzv",
      "expanded_url" : "https:\/\/wpbeg.in\/2voRoJ5",
      "display_url" : "wpbeg.in\/2voRoJ5"
    } ]
  },
  "geo" : { },
  "id_str" : "1080033783959699456",
  "text" : "RT @wpbeginner: How to Increase or Decrease #WordPress JPEG Image Compression - https:\/\/t.co\/TCuwqG0Bzv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/buffer.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WordPress",
        "indices" : [ 28, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/TCuwqG0Bzv",
        "expanded_url" : "https:\/\/wpbeg.in\/2voRoJ5",
        "display_url" : "wpbeg.in\/2voRoJ5"
      } ]
    },
    "geo" : { },
    "id_str" : "1079893216063864837",
    "text" : "How to Increase or Decrease #WordPress JPEG Image Compression - https:\/\/t.co\/TCuwqG0Bzv",
    "id" : 1079893216063864837,
    "created_at" : "2019-01-01 00:13:00 +0000",
    "user" : {
      "name" : "WordPress Beginner",
      "screen_name" : "wpbeginner",
      "protected" : false,
      "id_str" : "40516848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731041180\/wpbeginnertwitterimg_normal.jpg",
      "id" : 40516848,
      "verified" : true
    }
  },
  "id" : 1080033783959699456,
  "created_at" : "2019-01-01 09:31:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "indices" : [ 3, 13 ],
      "id_str" : "1323280062",
      "id" : 1323280062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coindesk",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033551985324032",
  "text" : "RT @BTCticker: One Bitcoin now worth $3759.927. Market Cap $65.635 Billion. Based on #coindesk BPI #bitcoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitcointicker.co\" rel=\"nofollow\"\u003EBitCointicker\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coindesk",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080033417713078272",
    "text" : "One Bitcoin now worth $3759.927. Market Cap $65.635 Billion. Based on #coindesk BPI #bitcoin",
    "id" : 1080033417713078272,
    "created_at" : "2019-01-01 09:30:07 +0000",
    "user" : {
      "name" : "bitcointicker.co",
      "screen_name" : "BTCticker",
      "protected" : false,
      "id_str" : "1323280062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468397178\/5a917e3773cfd38e8bd0bab8f0e91f04_normal.png",
      "id" : 1323280062,
      "verified" : false
    }
  },
  "id" : 1080033551985324032,
  "created_at" : "2019-01-01 09:30:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strong Women",
      "screen_name" : "A_StrongWomen",
      "indices" : [ 3, 17 ],
      "id_str" : "1870258736",
      "id" : 1870258736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033536265121793",
  "text" : "RT @A_StrongWomen: The strongest people are not those who show strength in front of us, but those who win battles we know nothing about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/kucukbeyin.com\/\" rel=\"nofollow\"\u003E\u015Flsjgoeshgl\u0131eh\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1079959425199325185",
    "text" : "The strongest people are not those who show strength in front of us, but those who win battles we know nothing about.",
    "id" : 1079959425199325185,
    "created_at" : "2019-01-01 04:36:06 +0000",
    "user" : {
      "name" : "Strong Women",
      "screen_name" : "A_StrongWomen",
      "protected" : false,
      "id_str" : "1870258736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479388927459987457\/230bmLAZ_normal.jpeg",
      "id" : 1870258736,
      "verified" : false
    }
  },
  "id" : 1080033536265121793,
  "created_at" : "2019-01-01 09:30:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "indices" : [ 3, 15 ],
      "id_str" : "798906869582544896",
      "id" : 798906869582544896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "Blockchain",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "Cryptocurrency",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033527293509632",
  "text" : "RT @SmartcoinFr: Le cours du #Bitcoin est de 3270.45\u20AC\uD83C\uDDEA\uD83C\uDDFA  (3753.15$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smartcoin.fr\" rel=\"nofollow\"\u003EBitcoinPriceReal\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Blockchain",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "Cryptocurrency",
        "indices" : [ 65, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1080008982905978880",
    "text" : "Le cours du #Bitcoin est de 3270.45\u20AC\uD83C\uDDEA\uD83C\uDDFA  (3753.15$\uD83C\uDDFA\uD83C\uDDF8) #Blockchain #Cryptocurrency",
    "id" : 1080008982905978880,
    "created_at" : "2019-01-01 07:53:01 +0000",
    "user" : {
      "name" : "Smartcoin",
      "screen_name" : "SmartcoinFr",
      "protected" : false,
      "id_str" : "798906869582544896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911003345342599168\/Yu2M7_bQ_normal.jpg",
      "id" : 798906869582544896,
      "verified" : false
    }
  },
  "id" : 1080033527293509632,
  "created_at" : "2019-01-01 09:30:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/1080033511455768576\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/gFzP4yRBtv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Dv0MwAiX0AAjZVy.jpg",
      "id_str" : "1080033504556208128",
      "id" : 1080033504556208128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Dv0MwAiX0AAjZVy.jpg",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 400
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/gFzP4yRBtv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080033511455768576",
  "text" : "Wow, some people are just so sweet, you know??? \uD83E\uDD17\n\nAndrew, off the sour patch kids. Too much candy for you! https:\/\/t.co\/gFzP4yRBtv",
  "id" : 1080033511455768576,
  "created_at" : "2019-01-01 09:30:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]